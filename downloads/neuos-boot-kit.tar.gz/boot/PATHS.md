# neuOS boot paths — feasibility

## CPU machine code
Intel/AMD execute **machine code only**. Node.js never replaces that. V8 JIT-compiles JavaScript to machine code **after** a kernel is already running. `kernel.js` is userspace, not a CPU kernel.

## Motherboard chip (UEFI/BIOS)
A tiny program can live in flash, but it must be **signed** by the OEM / Intel / AMD. Unsigned neuOS on the chip will not boot on modern laptops and can brick the board. **Do not flash the chip.** Ship USB or factory-provisioned SSD instead.

## Three paths

| Path | Possible now | Success chance | How we verify |
| --- | --- | --- | --- |
| 1. Custom kernel | Research only | Low this year | Need GPU/Wi-Fi drivers per board |
| 2. JeOS (Buildroot/Yocto + Node + live initramfs) | Yes | High (Android-like) | `npm run usb`, QEMU, then a stick |
| 3. Thin client | After JeOS net | Medium | Image must bring up NIC then load LUI |

NodeOS is abandoned. Use Buildroot, not NodeOS.

## De-OS strategy

Whether the PC already has Windows/Linux or the disk is empty, power-on should land in neuOS.

| Track | Command | What the user sees |
| --- | --- | --- |
| Plant on a host that already has an OS | First screen → 이 기기에 심기, or `npm run boot:install` | Next graphical login opens the kiosk. Disk is not wiped. |
| USB for a machine with **no** OS | First screen → USB, or `npm run usb` / `sudo npm run usb -- /dev/sdX --yes` | Firmware boot menu → USB → neuOS kernel AI loop (JeOS). |
| Guest | First screen → 지금 체험 | Same kiosk without planting. **종료** still offers JeOS vs talk loop. |

`scripts/make-usb.sh` copies this repo, a Node binary, the **builder’s** `/boot/vmlinuz` + modules, and a tiny initramfs. It never flashes UEFI. It refuses to overwrite the disk that holds `/`.

Graphical kiosk on a bare stick still needs a fuller image (X/Electron). The stick’s first payload is the JeOS AI loop. Host plant is how this laptop stays a sleep-style open OS after login.

## Auto-run at startup

| Machine | Exact file | What it runs |
| --- | --- | --- |
| This Ubuntu (graphical login) | `~/.config/autostart/neuos.desktop` and `~/.config/systemd/user/neuos.service` | `scripts/open-neuos.sh` → kiosk |
| JeOS USB (no desktop) | `/boot/grub/grub.cfg` plus live `initrd` that finds `LABEL=NEUOS-ROOT` | `/sbin/neuos-init` → `node …/kernel.mjs` |

Public install page: `/welcome/` now, **os.neuavenue.com** in DNS ([docs/domain-landing.md](../docs/domain-landing.md)). Architecture: [implementation](../docs/architecture-implementation.md), [flow](../docs/architecture-flow.md).

Monitor: `data/boot-health.json` heartbeat from `boot/kernel.mjs`. **종료** refreshes it via `/api/boot-health?refresh=1` before offering JeOS or the talk loop.
