import { describe, expect, it } from 'vitest'
import os from 'node:os'
import path from 'node:path'
import { assertSafePlantDest, defaultPlantDir, ensureOsNeuFolder, isPlantCommand, isUninstallCommand, shouldSkip } from './plant.mjs'

describe('os.neu plant', () => {
  it('recognizes uninstall os.neu', () => {
    expect(isUninstallCommand('uninstall os.neu')).toBe(true)
    expect(isUninstallCommand('os.neu 제거')).toBe(true)
    expect(isUninstallCommand('install os.neu')).toBe(false)
  })

  it('recognizes the console install command', () => {
    expect(isPlantCommand('install os.neu')).toBe(true)
    expect(isPlantCommand('INSTALL OS.NEU')).toBe(true)
    expect(isPlantCommand('install firefox')).toBe(false)
  })

  it('defaults to the home os.neu folder', () => {
    expect(defaultPlantDir()).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('creates os.neu under a chosen parent', () => {
    expect(ensureOsNeuFolder(os.homedir())).toBe(path.join(os.homedir(), 'os.neu'))
    expect(ensureOsNeuFolder(path.join(os.homedir(), 'os.neu'))).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('refuses block devices and system roots', () => {
    expect(() => assertSafePlantDest('/dev/sda')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/proc/self')).toThrow('unsafe-dest')
  })

  it('does not copy secrets or builder keys onto a planted tree', () => {
    expect(shouldSkip('.env')).toBe(true)
    expect(shouldSkip('.env.local')).toBe(true)
    expect(shouldSkip('user-llm.json')).toBe(true)
    expect(shouldSkip('accounts.json')).toBe(true)
    expect(shouldSkip('kernel.mjs')).toBe(false)
  })
})
