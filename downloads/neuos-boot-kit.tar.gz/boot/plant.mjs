/**
 * Copy this tree into ~/os.neu (or a chosen folder). Never touches block devices.
 */
import { spawn, spawnSync } from 'node:child_process'
import { copyFile, cp, mkdir, readdir, symlink, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { destIsUsbStick } from './hostVolume.mjs'

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'coverage', '.cursor'])
const SKIP_FILES = new Set([
  '.env',
  'accounts.json',
  'analytics.json',
  'feedback.json',
  'user-llm.json',
  'boot-health.json',
  'user-monitor.json',
])

export function shouldSkip(name) {
  return SKIP_DIRS.has(name) || SKIP_FILES.has(name) || name.startsWith('.env.')
}

export function isPlantCommand(input) {
  const t = String(input || '').trim()
  return /^install\s+os\.neu\s*$/i.test(t) || /^install\s+osneu\s*$/i.test(t)
}

export function isUninstallCommand(input) {
  const t = String(input || '').trim()
  return /^(uninstall|remove|delete)\s+os\.neu\s*$/i.test(t) || /^os\.neu\s+(삭제|제거|uninstall|remove|delete)\s*$/i.test(t)
}

export function isOpenScreenCommand(input) {
  const t = String(input || '').trim()
  if (isPlantCommand(t) || isUninstallCommand(t)) return false
  return /^(open\s+(os\.neu|screen|neuos)|screen|open-neuos|스크린(\s*열기)?|화면\s*열기)\s*$/i.test(t)
}

export function isHelpCommand(input) {
  const t = String(input || '').trim()
  return /^(help|\?|도움|가이드|guide)\s*$/i.test(t)
}

export function homeTildePath(rel = '~/os.neu') {
  const raw = String(rel || '~/os.neu').trim() || '~/os.neu'
  return raw.replace(/^\/home\/[^/]+/, '~')
}

export function screenOpenCommand(rel = '~/os.neu') {
  return `bash ${homeTildePath(rel)}/scripts/open-neuos.sh`
}

export function printInstallInterfacesDialog(rel = '~/os.neu', extras = {}, log = console.log) {
  const homeRel = homeTildePath(rel)
  log('')
  log('┌──────────────────────────────────────────────┐')
  log('│  os.neu interfaces                           │')
  log('│  Apps icon · Desktop icon · USB graphics     │')
  log('│  then this machine’s os.neu screen           │')
  log('└──────────────────────────────────────────────┘')
  log(`  Apps:     ~/.local/share/applications/neuos.desktop`)
  log(`  Desktop:  ~/Desktop/neuos.desktop`)
  log(`  Screen:   ${homeRel}`)
  if (extras.kiosk) log(`  USB kiosk copied: ${extras.kiosk}`)
  log('USB console has no HTML wizard. This box is the install dialog.')
  log('')
}

export async function plantUsbGraphics(dest) {
  const toKiosk = path.join(dest, 'runtime/kiosk')
  const kioskSrc = [
    '/opt/neuos/runtime/kiosk',
    path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'runtime/kiosk'),
  ].find((dir) => existsSync(path.join(dir, 'cage')) || existsSync(path.join(dir, 'weston')) || existsSync(path.join(dir, 'seatd')))
  let copied = false
  if (kioskSrc && existsSync(kioskSrc)) {
    await mkdir(toKiosk, { recursive: true })
    await cp(kioskSrc, toKiosk, { recursive: true, force: true })
    copied = existsSync(path.join(toKiosk, 'cage')) || existsSync(path.join(toKiosk, 'weston'))
  }
  const fromDri = '/usr/lib/x86_64-linux-gnu/dri'
  const toDri = path.join(dest, 'runtime/dri')
  if (existsSync(fromDri)) {
    try {
      await mkdir(toDri, { recursive: true })
      for (const name of ['iris_dri.so', 'crocus_dri.so', 'i915_dri.so', 'zink_dri.so', 'swrast_dri.so', 'kms_swrast_dri.so']) {
        const src = path.join(fromDri, name)
        if (existsSync(src)) {
          await copyFile(src, path.join(toDri, name))
          copied = true
        }
      }
    } catch {
      /* USB plant as root can write here; Ubuntu user may find runtime owned by root */
    }
  }
  return copied ? toKiosk : ''
}

export function printScreenFallbackGuide(rel = '~/os.neu', log = console.log, code = 'OS-NEU-SX-000') {
  const homeRel = homeTildePath(rel)
  log('')
  log(`${code}  Screen did not open from USB. Files are already on this PC.`)
  log('You do not need to cd. Run one of these lines.')
  log('')
  log('This USB prompt, retry:')
  log('  open os.neu')
  log('')
  log('After Ubuntu login:')
  log(`  ${screenOpenCommand(homeRel)}`)
  log('')
  log('Same script:')
  log(`  bash ${homeRel}/scripts/screen.sh`)
}

export function defaultPlantDir() {
  return path.join(os.homedir() || '/root', 'os.neu')
}

export function assertSafePlantDest(dest) {
  const resolved = path.resolve(String(dest || ''))
  if (!resolved || resolved === '/' || resolved === '/home' || resolved === '/root') {
    throw new Error('unsafe-dest')
  }
  if (
    resolved.startsWith('/dev') ||
    resolved.startsWith('/sys') ||
    resolved.startsWith('/proc') ||
    resolved === '/boot' ||
    resolved.startsWith('/boot/')
  ) {
    throw new Error('unsafe-dest')
  }
  if (/^\/dev\//.test(resolved)) throw new Error('unsafe-dest')
  return resolved
}

export function ensureOsNeuFolder(dest) {
  const resolved = path.resolve(String(dest || defaultPlantDir()))
  const base = path.basename(resolved)
  const folder = base === 'os.neu' ? resolved : path.join(resolved, 'os.neu')
  return assertSafePlantDest(folder)
}

let job = {
  percent: 0,
  stage: 'idle',
  dest: '',
  error: '',
  files: 0,
  copied: 0,
}

export function plantStatus() {
  return { ...job }
}

async function walkFiles(dir, acc = []) {
  let entries = []
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return acc
  }
  for (const ent of entries) {
    if (shouldSkip(ent.name)) continue
    const full = path.join(dir, ent.name)
    if (ent.isDirectory()) await walkFiles(full, acc)
    else acc.push(full)
  }
  return acc
}

export async function listPlantDir(dir) {
  const resolved = path.resolve(String(dir || defaultPlantDir()))
  if (resolved.startsWith('/dev') || resolved.startsWith('/sys') || resolved.startsWith('/proc')) {
    throw new Error('unsafe-dest')
  }
  let entries = []
  try {
    entries = await readdir(resolved, { withFileTypes: true })
  } catch {
    return { ok: true, dir: resolved, exists: false, entries: [] }
  }
  return {
    ok: true,
    dir: resolved,
    exists: true,
    entries: entries
      .filter((ent) => !shouldSkip(ent.name) && !ent.name.startsWith('.'))
      .slice(0, 80)
      .map((ent) => ({
        name: ent.name,
        dir: ent.isDirectory(),
        path: path.join(resolved, ent.name),
      })),
  }
}

async function plantCopy(src, dest, onTick) {
  const safe = assertSafePlantDest(dest)
  await mkdir(safe, { recursive: true })
  const files = await walkFiles(src)
  job = { percent: 3, stage: 'copy', dest: safe, error: '', files: files.length, copied: 0 }
  onTick?.(job)
  for (const file of files) {
    const rel = path.relative(src, file)
    const target = path.join(safe, rel)
    await mkdir(path.dirname(target), { recursive: true })
    await copyFile(file, target)
    job.copied += 1
    job.percent = Math.min(68, 3 + Math.round((job.copied / Math.max(1, files.length)) * 65))
    if (job.copied % 12 === 0) onTick?.(job)
  }
  const kioskShim = path.join(safe, 'scripts/kiosk.sh')
  const screenScript = path.join(safe, 'scripts/screen.sh')
  if (existsSync(screenScript) && !existsSync(kioskShim)) {
    await writeFile(
      kioskShim,
      '#!/usr/bin/env bash\nexec bash "$(cd "$(dirname "$0")" && pwd)/screen.sh" "$@"\n',
    )
  }
  for (const script of [
    'scripts/screen.sh',
    'scripts/kiosk.sh',
    'scripts/open-neuos.sh',
    'scripts/install-autostart.sh',
    'scripts/install-linux.sh',
    'scripts/usb-screen.sh',
    'scripts/trust-launchers.sh',
    'scripts/osneu-session.sh',
    'scripts/install-osneu-session.sh',
  ]) {
    const full = path.join(safe, script)
    if (existsSync(full)) {
      try {
        spawn('chmod', ['+x', full], { stdio: 'ignore' })
      } catch {
        /* ignore */
      }
    }
  }
  return safe
}

async function linkHostNodeModules(dest, host) {
  if (!host?.homeMount) return false
  const plantedNm = path.join(dest, 'node_modules')
  if (existsSync(plantedNm)) return true
  const neu = path.join(host.homeMount, 'neuOS', 'node_modules')
  if (!existsSync(neu)) return false
  try {
    await symlink('../neuOS/node_modules', plantedNm)
    return true
  } catch {
    return false
  }
}

async function plantNpm(dest, onTick) {
  job.stage = 'npm'
  job.percent = 72
  onTick?.(job)
  if (existsSync(path.join(dest, 'node_modules', 'electron'))) {
    job.percent = 92
    job.stage = 'npm-ok'
    onTick?.(job)
    return true
  }
  return new Promise((resolve) => {
    const child = spawn('npm', ['install'], {
      cwd: dest,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    child.on('close', (code) => {
      job.percent = code === 0 ? 92 : 84
      job.stage = code === 0 ? 'npm-ok' : 'npm-skip'
      onTick?.(job)
      resolve(code === 0)
    })
    child.on('error', () => {
      job.stage = 'npm-skip'
      job.percent = 84
      onTick?.(job)
      resolve(false)
    })
  })
}

export function linuxDesktopFile({ execRoot, icon, autostart = false, iconPath = '' }) {
  const lines = [
    '[Desktop Entry]',
    'Type=Application',
    'Name=os.neu',
    'GenericName=os.neu screen',
    'Comment=os.neu screen — independent browser',
    'Keywords=os.neu;neuos;neuOS;screen;',
    `Exec=bash ${execRoot}/scripts/open-neuos.sh`,
    'TryExec=bash',
    `Path=${execRoot}`,
    `Icon=${iconPath || icon || 'os.neu'}`,
    'Terminal=false',
    'Categories=Utility;',
    'StartupWMClass=neuos',
    'StartupNotify=true',
  ]
  if (autostart) lines.push('X-GNOME-Autostart-enabled=true')
  return `${lines.join('\n')}\n`
}

export function linuxWaylandSession({ execRoot }) {
  return `[Desktop Entry]
Name=os.neu
Comment=os.neu screen on this machine — Ubuntu stays the kernel
Exec=bash ${execRoot}/scripts/osneu-session.sh
TryExec=bash
Type=Application
DesktopNames=os.neu
`
}

export function linuxUserService({ execRoot }) {
  return `[Unit]
Description=os.neu screen
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
WorkingDirectory=${execRoot}
ExecStart=/bin/bash ${execRoot}/scripts/open-neuos.sh
Restart=on-failure
RestartSec=3
Environment=DISPLAY=:0
Environment=NEUOS_SCREEN=1

[Install]
WantedBy=graphical-session.target
`
}

export async function installLinuxIcons(srcTree, home) {
  const sizes = [48, 64, 128, 256, 512]
  for (const size of sizes) {
    const from = path.join(srcTree, 'public/brand/hicolor', `${size}x${size}`, 'apps/os.neu.png')
    if (!existsSync(from)) continue
    const toDir = path.join(home, '.local/share/icons/hicolor', `${size}x${size}`, 'apps')
    await mkdir(toDir, { recursive: true })
    await copyFile(from, path.join(toDir, 'os.neu.png'))
  }
}

export async function writePlantAutostart(dest, opts = {}) {
  const home = opts.homeDir || os.homedir()
  const execRoot = opts.execRoot || dest
  const icon = 'os.neu'
  await installLinuxIcons(dest, home)
  const iconPath = existsSync(path.join(home, '.local/share/icons/hicolor/256x256/apps/os.neu.png'))
    ? path.join(home, '.local/share/icons/hicolor/256x256/apps/os.neu.png')
    : icon
  const launcher = linuxDesktopFile({ execRoot, icon, iconPath, autostart: false })
  const autoBody = linuxDesktopFile({ execRoot, icon, iconPath, autostart: true })
  const unit = linuxUserService({ execRoot })
  const session = linuxWaylandSession({ execRoot })

  const autoDir = path.join(home, '.config/autostart')
  const appDir = path.join(home, '.local/share/applications')
  const unitDir = path.join(home, '.config/systemd/user')
  const sessionDir = path.join(home, '.local/share/wayland-sessions')
  await mkdir(autoDir, { recursive: true })
  await mkdir(appDir, { recursive: true })
  await mkdir(unitDir, { recursive: true })
  await mkdir(sessionDir, { recursive: true })
  await writeFile(path.join(autoDir, 'neuos.desktop'), autoBody)
  await writeFile(path.join(appDir, 'neuos.desktop'), launcher)
  await writeFile(path.join(unitDir, 'neuos.service'), unit)
  await writeFile(path.join(sessionDir, 'os.neu.desktop'), session)

  const hostRoot = opts.hostRoot
  if (hostRoot && existsSync(path.join(hostRoot, 'usr/share'))) {
    const sysSess = path.join(hostRoot, 'usr/share/wayland-sessions')
    try {
      await mkdir(sysSess, { recursive: true })
      await writeFile(path.join(sysSess, 'os.neu.desktop'), session)
    } catch {
      /* no write on host /usr */
    }
  }

  const deskDir = path.join(home, 'Desktop')
  if (existsSync(deskDir)) {
    const deskFile = path.join(deskDir, 'neuos.desktop')
    await writeFile(deskFile, launcher)
    try {
      spawn('chmod', ['+x', deskFile], { stdio: 'ignore' })
    } catch {
      /* ignore */
    }
  }
}

export async function runPlant(src, dest, onTick, opts = {}) {
  job = { percent: 1, stage: 'start', dest: '', error: '', files: 0, copied: 0 }
  onTick?.(job)
  try {
    const folder = ensureOsNeuFolder(dest)
    if (destIsUsbStick(folder)) {
      throw new Error('usb-stick-not-host')
    }
    if (path.resolve(src) === path.resolve(folder)) {
      job.dest = folder
      job.percent = 100
      job.stage = 'done'
      onTick?.(job)
      return job
    }
    const safe = await plantCopy(src, folder, onTick)
    job.dest = safe
    await linkHostNodeModules(safe, opts.host)
    await plantNpm(safe, onTick)
    let kiosk = ''
    try {
      kiosk = await plantUsbGraphics(safe)
    } catch {
      kiosk = ''
    }
    try {
      await writePlantAutostart(safe, {
        homeDir: opts.autostartHome,
        execRoot: opts.execRoot,
        hostRoot: opts.host?.mount,
      })
    } catch {
      /* USB console may lack a desktop session */
    }
    const trustScript = path.join(safe, 'scripts/trust-launchers.sh')
    if (opts.host?.mount && opts.host?.user && opts.host?.osNeuRel) {
      const trust = path.posix.join(opts.host.osNeuRel, 'scripts/trust-launchers.sh')
      try {
        spawnSync('chroot', [opts.host.mount, '/bin/su', '-', opts.host.user, '-c', `bash ${trust}`], {
          timeout: 15_000,
          stdio: 'ignore',
        })
      } catch {
        /* gio may be missing in chroot */
      }
    } else if (existsSync(trustScript)) {
      try {
        spawnSync('bash', [trustScript], {
          env: { ...process.env, NEUOS_HOME: opts.autostartHome || os.homedir() },
          timeout: 10_000,
          stdio: 'ignore',
        })
      } catch {
        /* gio may be missing */
      }
    }
    job.kiosk = kiosk
    job.percent = 100
    job.stage = 'done'
    onTick?.(job)
    return job
  } catch (err) {
    job.error = String(err?.message || err)
    job.stage = 'error'
    onTick?.(job)
    throw err
  }
}

export function canLaunchGraphicalScreen() {
  if (process.env.NEUOS_JEOS === '1') return false
  return Boolean(process.env.DISPLAY || process.env.WAYLAND_DISPLAY)
}

export function usbScreenScript() {
  return path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts/usb-screen.sh')
}

export function launchUsbHostScreen(host, dest, go = 'lui') {
  const script = usbScreenScript()
  if (!host?.mount || !host?.user) {
    return { ok: false, reason: 'no-host', dest, go }
  }
  if (!existsSync(script)) {
    return { ok: false, reason: 'no-usb-screen-script', dest, go }
  }
  const env = {
    ...process.env,
    NEUOS_HOST_ROOT: host.mount,
    NEUOS_HOST_USER: host.user,
    NEUOS_HOST_DEST: host.osNeuRel || dest,
    NEUOS_GO: go,
  }
  if (process.env.NEUOS_USB_SCREEN_DRY === '1') {
    return { ok: true, dest, go, via: 'usb-host', dry: true }
  }
  const result = spawnSync('sh', [script], { env, stdio: 'inherit', encoding: 'utf8' })
  return {
    ok: result.status === 0,
    dest,
    go,
    via: 'usb-host',
    status: result.status,
    reason: result.status === 0 ? '' : 'usb-screen-failed',
  }
}

export function launchScreen(dest, go = 'lui', opts = {}) {
  if (process.env.NEUOS_JEOS === '1' && opts.host) {
    return launchUsbHostScreen(opts.host, dest, go)
  }
  if (!canLaunchGraphicalScreen()) {
    return { ok: false, reason: 'no-desktop', dest, go }
  }
  const named = [
    path.join(dest, 'scripts/screen.sh'),
    path.join(dest, 'scripts/kiosk.sh'),
  ]
  const fallback = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts/screen.sh')
  const script = named.find((full) => existsSync(full)) || fallback
  const cwd = existsSync(path.join(dest, 'scripts/screen.sh')) || existsSync(path.join(dest, 'scripts/kiosk.sh'))
    ? dest
    : path.dirname(path.dirname(script))
  const child = spawn('bash', [script], {
    cwd,
    env: { ...process.env, NEUOS_GO: go, HOME: os.homedir() },
    detached: true,
    stdio: 'ignore',
  })
  child.unref()
  return { ok: true, dest: cwd, go }
}
