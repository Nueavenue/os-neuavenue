/**
 * Copy this tree into ~/os.neu (or a chosen folder). Never touches block devices.
 */
import { spawn } from 'node:child_process'
import { copyFile, mkdir, readdir, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'coverage', '.cursor'])
const SKIP_FILES = new Set([
  '.env',
  'accounts.json',
  'analytics.json',
  'feedback.json',
  'user-llm.json',
  'boot-health.json',
  'user-monitor.json',
])

export function shouldSkip(name) {
  return SKIP_DIRS.has(name) || SKIP_FILES.has(name) || name.startsWith('.env.')
}

export function isPlantCommand(input) {
  const t = String(input || '').trim()
  return /^install\s+os\.neu\s*$/i.test(t) || /^install\s+osneu\s*$/i.test(t)
}

export function isUninstallCommand(input) {
  const t = String(input || '').trim()
  return /^(uninstall|remove|delete)\s+os\.neu\s*$/i.test(t) || /^os\.neu\s+(삭제|제거|uninstall|remove|delete)\s*$/i.test(t)
}

export function defaultPlantDir() {
  return path.join(os.homedir() || '/root', 'os.neu')
}

export function assertSafePlantDest(dest) {
  const resolved = path.resolve(String(dest || ''))
  if (!resolved || resolved === '/' || resolved === '/home' || resolved === '/root') {
    throw new Error('unsafe-dest')
  }
  if (
    resolved.startsWith('/dev') ||
    resolved.startsWith('/sys') ||
    resolved.startsWith('/proc') ||
    resolved === '/boot' ||
    resolved.startsWith('/boot/')
  ) {
    throw new Error('unsafe-dest')
  }
  if (/^\/dev\//.test(resolved)) throw new Error('unsafe-dest')
  return resolved
}

export function ensureOsNeuFolder(dest) {
  const resolved = path.resolve(String(dest || defaultPlantDir()))
  const base = path.basename(resolved)
  const folder = base === 'os.neu' ? resolved : path.join(resolved, 'os.neu')
  return assertSafePlantDest(folder)
}

let job = {
  percent: 0,
  stage: 'idle',
  dest: '',
  error: '',
  files: 0,
  copied: 0,
}

export function plantStatus() {
  return { ...job }
}

async function walkFiles(dir, acc = []) {
  let entries = []
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return acc
  }
  for (const ent of entries) {
    if (shouldSkip(ent.name)) continue
    const full = path.join(dir, ent.name)
    if (ent.isDirectory()) await walkFiles(full, acc)
    else acc.push(full)
  }
  return acc
}

export async function listPlantDir(dir) {
  const resolved = path.resolve(String(dir || defaultPlantDir()))
  if (resolved.startsWith('/dev') || resolved.startsWith('/sys') || resolved.startsWith('/proc')) {
    throw new Error('unsafe-dest')
  }
  let entries = []
  try {
    entries = await readdir(resolved, { withFileTypes: true })
  } catch {
    return { ok: true, dir: resolved, exists: false, entries: [] }
  }
  return {
    ok: true,
    dir: resolved,
    exists: true,
    entries: entries
      .filter((ent) => !shouldSkip(ent.name) && !ent.name.startsWith('.'))
      .slice(0, 80)
      .map((ent) => ({
        name: ent.name,
        dir: ent.isDirectory(),
        path: path.join(resolved, ent.name),
      })),
  }
}

async function plantCopy(src, dest, onTick) {
  const safe = assertSafePlantDest(dest)
  await mkdir(safe, { recursive: true })
  const files = await walkFiles(src)
  job = { percent: 3, stage: 'copy', dest: safe, error: '', files: files.length, copied: 0 }
  onTick?.(job)
  for (const file of files) {
    const rel = path.relative(src, file)
    const target = path.join(safe, rel)
    await mkdir(path.dirname(target), { recursive: true })
    await copyFile(file, target)
    job.copied += 1
    job.percent = Math.min(68, 3 + Math.round((job.copied / Math.max(1, files.length)) * 65))
    if (job.copied % 12 === 0) onTick?.(job)
  }
  // Older planted copies may still have scripts/kiosk.sh
  for (const script of ['scripts/screen.sh', 'scripts/kiosk.sh', 'scripts/open-neuos.sh', 'scripts/install-autostart.sh']) {
    const full = path.join(safe, script)
    if (existsSync(full)) {
      try {
        spawn('chmod', ['+x', full], { stdio: 'ignore' })
      } catch {
        /* ignore */
      }
    }
  }
  return safe
}

async function plantNpm(dest, onTick) {
  job.stage = 'npm'
  job.percent = 72
  onTick?.(job)
  return new Promise((resolve) => {
    const child = spawn('npm', ['install'], {
      cwd: dest,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    child.on('close', (code) => {
      job.percent = code === 0 ? 92 : 84
      job.stage = code === 0 ? 'npm-ok' : 'npm-skip'
      onTick?.(job)
      resolve(code === 0)
    })
    child.on('error', () => {
      job.stage = 'npm-skip'
      job.percent = 84
      onTick?.(job)
      resolve(false)
    })
  })
}

export async function writePlantAutostart(dest) {
  const auto = path.join(os.homedir(), '.config/autostart')
  await mkdir(auto, { recursive: true })
  const body = `[Desktop Entry]
Type=Application
Name=os.neu
Comment=os.neu screen
Exec=bash ${dest}/scripts/open-neuos.sh
Terminal=false
X-GNOME-Autostart-enabled=true
`
  await writeFile(path.join(auto, 'neuos.desktop'), body)
}

export async function runPlant(src, dest, onTick) {
  job = { percent: 1, stage: 'start', dest: '', error: '', files: 0, copied: 0 }
  onTick?.(job)
  try {
    const folder = ensureOsNeuFolder(dest)
    if (path.resolve(src) === path.resolve(folder)) {
      job.dest = folder
      job.percent = 100
      job.stage = 'done'
      onTick?.(job)
      return job
    }
    const safe = await plantCopy(src, folder, onTick)
    job.dest = safe
    await plantNpm(safe, onTick)
    try {
      await writePlantAutostart(safe)
    } catch {
      /* USB console may lack a desktop session */
    }
    job.percent = 100
    job.stage = 'done'
    onTick?.(job)
    return job
  } catch (err) {
    job.error = String(err?.message || err)
    job.stage = 'error'
    onTick?.(job)
    throw err
  }
}

export function launchScreen(dest, go = 'lui') {
  const named = [
    path.join(dest, 'scripts/screen.sh'),
    path.join(dest, 'scripts/kiosk.sh'),
  ]
  const fallback = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts/screen.sh')
  const script = named.find((full) => existsSync(full)) || fallback
  const cwd = existsSync(path.join(dest, 'scripts/screen.sh')) || existsSync(path.join(dest, 'scripts/kiosk.sh'))
    ? dest
    : path.dirname(path.dirname(script))
  const child = spawn('bash', [script], {
    cwd,
    env: { ...process.env, NEUOS_GO: go, HOME: os.homedir() },
    detached: true,
    stdio: 'ignore',
  })
  child.unref()
  return { ok: true, dest: cwd, go }
}
