#!/usr/bin/env bash
# Optional QEMU smoke. Needs qemu-system-x86_64. Does not download an ISO automatically
# if the network is blocked — place alpine-virt iso at boot/cache/*.iso yourself.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ISO="$(ls "$ROOT"/boot/cache/*.iso 2>/dev/null | head -n 1 || true)"
if ! command -v qemu-system-x86_64 >/dev/null; then
  echo "qemu-system-x86_64 missing — JeOS USB image is still the target, QEMU is optional."
  exit 0
fi
if [[ -z "$ISO" ]]; then
  echo "No ISO in boot/cache. Userspace kernel check only."
  node "$ROOT/boot/kernel.mjs" <<'EOF'
hardware
exit
EOF
  exit 0
fi
qemu-system-x86_64 -m 512 -cdrom "$ISO" -boot d -nographic -serial mon:stdio
