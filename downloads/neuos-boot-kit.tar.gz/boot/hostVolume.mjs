/**
 * Find the PC’s installed Linux home while booted from the os.neu USB.
 * Never treats the USB stick (NEUOS-ROOT / current /) as the plant target.
 */
import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, openSync, readFileSync, readSync, readdirSync, closeSync, writeFileSync } from 'node:fs'
import path from 'node:path'

export const HOST_MOUNT = '/mnt/osneu-host'
export const USB_LABELS = new Set(['NEUOS-ROOT', 'NEUOS-ESP'])

export function hostMountPoint() {
  return process.env.NEUOS_HOST_MOUNT || HOST_MOUNT
}

export function diskFromDevice(dev) {
  const base = String(dev || '')
    .trim()
    .replace(/^\/dev\//, '')
  if (!base) return ''
  if (/^(nvme|mmcblk|loop)/.test(base)) return base.replace(/p\d+$/, '')
  return base.replace(/\d+$/, '')
}

export function parseProcMounts(text) {
  const rows = []
  for (const line of String(text || '').split('\n')) {
    const parts = line.trim().split(/\s+/)
    if (parts.length < 3) continue
    rows.push({ device: parts[0], mount: parts[1], type: parts[2] })
  }
  return rows
}

export function rootDeviceFromMounts(rows) {
  const root = (rows || []).find((row) => row.mount === '/')
  return root?.device || ''
}

export function parseBlkid(text) {
  const out = []
  for (const line of String(text || '').split('\n')) {
    const trimmed = line.trim()
    if (!trimmed) continue
    const colon = trimmed.indexOf(':')
    if (colon < 1) continue
    const device = trimmed.slice(0, colon).trim()
    const rest = trimmed.slice(colon + 1)
    const meta = { device, type: '', label: '', uuid: '' }
    const type = rest.match(/\bTYPE="([^"]+)"/)
    const label = rest.match(/\bLABEL="([^"]+)"/)
    const uuid = rest.match(/\bUUID="([^"]+)"/)
    if (type) meta.type = type[1]
    if (label) meta.label = label[1]
    if (uuid) meta.uuid = uuid[1]
    out.push(meta)
  }
  return out
}

export function parsePasswd(text) {
  const users = []
  for (const line of String(text || '').split('\n')) {
    const parts = line.split(':')
    if (parts.length < 7) continue
    const [name, , uidStr, gidStr, , home, shell] = parts
    const uid = Number(uidStr)
    const gid = Number(gidStr)
    if (!name || Number.isNaN(uid)) continue
    users.push({ name, uid, gid, home, shell })
  }
  return users
}

export function isLoginUser(user) {
  if (!user || user.uid < 1000 || user.uid >= 65534) return false
  if (!user.home || !user.home.startsWith('/home/')) return false
  const shell = String(user.shell || '')
  if (/nologin|false|sync|halt$/i.test(shell)) return false
  return true
}

export function skipDiskReason({ disk, removable, labels, rootDisk }) {
  if (!disk) return 'empty'
  if (rootDisk && disk === rootDisk) return 'current-root'
  if (String(removable) === '1') return 'removable'
  const set = new Set(labels || [])
  for (const label of USB_LABELS) {
    if (set.has(label)) return 'neuos-usb'
  }
  return ''
}

export function pickHostUser(users, homeNames, preferName) {
  const login = (users || []).filter(isLoginUser)
  const homes = new Set(homeNames || [])
  const present = login.filter((user) => homes.has(path.basename(user.home)) || homes.has(user.name))
  const pool = present.length ? present : login
  if (preferName) {
    const hit = pool.find((user) => user.name === preferName)
    if (hit) return hit
  }
  return pool[0] || null
}

export function parseFstabHomeSource(fstab) {
  for (const line of String(fstab || '').split('\n')) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const parts = trimmed.split(/\s+/)
    if (parts.length >= 2 && parts[1] === '/home') return parts[0]
  }
  return ''
}

function readText(file) {
  try {
    return readFileSync(file, 'utf8')
  } catch {
    return ''
  }
}

function run(bin, args, ms = 3000) {
  try {
    return execFileSync(bin, args, { encoding: 'utf8', timeout: ms, stdio: ['ignore', 'pipe', 'pipe'] })
  } catch (err) {
    return String(err.stdout || '')
  }
}

function runBlkid() {
  for (const bin of ['/usr/sbin/blkid', '/sbin/blkid', '/usr/bin/blkid', '/bin/blkid']) {
    if (!existsSync(bin)) continue
    const out = run(bin, [])
    if (out.includes('TYPE=') || out.includes('LABEL=')) return out
  }
  return run('blkid', [])
}

function readRemovable(disk) {
  return readText(`/sys/block/${disk}/removable`).trim() || '0'
}

function listSysDisks() {
  try {
    return readdirSync('/sys/block').filter((name) => !/^(loop|ram|sr|fd|zram|dm-)/.test(name))
  } catch {
    return []
  }
}

export function isPartitionName(name) {
  const n = String(name || '')
  return /^(sd|vd|hd|xvd)[a-z]\d+$/.test(n) || /^nvme\d+n\d+p\d+$/.test(n) || /^mmcblk\d+p\d+$/.test(n)
}

export function listDevPartitions() {
  try {
    return readdirSync('/dev').filter(isPartitionName).map((name) => `/dev/${name}`).sort()
  } catch {
    return []
  }
}

export function skipNonLinuxFs(type) {
  return /^(vfat|fat|fat32|exfat|ntfs|ntfs3|iso9660|udf|swap|crypto_LUKS|BitLocker)$/i.test(String(type || ''))
}

export function linuxFs(type) {
  return /^(ext[234]|xfs|btrfs|f2fs)$/.test(String(type || ''))
}

export function fatSignatureInBootSector(buf) {
  if (!buf || buf.length < 0x5a) return false
  if (buf.toString('latin1', 0x52, 0x5a).startsWith('FAT')) return true
  if (buf.toString('latin1', 0x36, 0x3e).startsWith('FAT')) return true
  return false
}

export function looksLikeFatPartition(device) {
  try {
    const fd = openSync(device, 'r')
    const buf = Buffer.alloc(512)
    readSync(fd, buf, 0, 512, 0)
    closeSync(fd)
    return fatSignatureInBootSector(buf)
  } catch {
    return false
  }
}

export function tooSmallForLinuxRoot(sectors, siblingMax = 0) {
  const fourGiB = 4 * 1024 * 1024 * 2
  const n = Number(sectors) || 0
  if (n <= 0) return false
  if (n >= fourGiB) return false
  const sib = Number(siblingMax) || 0
  if (sib > n) return true
  return n < fourGiB
}

function partitionSectors(device) {
  const base = String(device || '').replace(/^\/dev\//, '')
  if (!base) return 0
  const disk = diskFromDevice(base)
  const fromPart = Number(readText(`/sys/block/${disk}/${base}/size`).trim())
  if (fromPart) return fromPart
  return Number(readText(`/sys/class/block/${base}/size`).trim()) || 0
}

function largestSiblingSectors(device) {
  const base = String(device || '').replace(/^\/dev\//, '')
  const disk = diskFromDevice(base)
  if (!disk) return 0
  let max = 0
  try {
    for (const name of readdirSync(`/sys/block/${disk}`)) {
      if (name === disk || !name.startsWith(disk)) continue
      const n = Number(readText(`/sys/block/${disk}/${name}/size`).trim()) || 0
      if (n > max) max = n
    }
  } catch {
    /* no sysfs */
  }
  return max
}

function probeDeviceType(device) {
  for (const bin of ['/usr/sbin/blkid', '/sbin/blkid', '/usr/bin/blkid']) {
    if (!existsSync(bin)) continue
    const parsed = parseBlkid(run(bin, [device], 2500))[0]
    if (parsed?.type) return parsed.type
  }
  return ''
}

function mountBin() {
  for (const bin of ['/usr/bin/mount', '/bin/mount', 'mount']) {
    if (bin === 'mount' || existsSync(bin)) return bin
  }
  return 'mount'
}

function loadStorageModules() {
  for (const name of [
    'ahci',
    'libahci',
    'libata',
    'ata_piix',
    'ata_generic',
    'nvme',
    'nvme_core',
    'sd_mod',
    'usb_storage',
    'uas',
    'ext4',
    'xfs',
    'btrfs',
  ]) {
    try {
      execFileSync('modprobe', [name], { timeout: 4000, stdio: 'ignore' })
    } catch {
      /* module missing on this kernel */
    }
  }
}

function rescanScsi() {
  try {
    for (const name of readdirSync('/sys/class/scsi_host')) {
      try {
        writeFileSync(`/sys/class/scsi_host/${name}/scan`, '- - -\n')
      } catch {
        /* not writable */
      }
    }
  } catch {
    /* no scsi_host */
  }
}

function settleDisks(log) {
  loadStorageModules()
  rescanScsi()
  let last = ''
  for (let i = 0; i < 8; i++) {
    const disks = listSysDisks().join(',')
    const parts = listDevPartitions().join(',')
    const key = `${disks}|${parts}`
    log(`block ${disks || 'none'}`)
    if (key === last && i >= 2) return
    last = key
    try {
      execFileSync('sleep', ['1'], { timeout: 2000, stdio: 'ignore' })
    } catch {
      break
    }
  }
}

function homeNamesUnder(root) {
  const dir = path.join(root, 'home')
  try {
    return readdirSync(dir, { withFileTypes: true })
      .filter((ent) => ent.isDirectory() && ent.name !== 'lost+found')
      .map((ent) => ent.name)
  } catch {
    return []
  }
}

function ensureMount(device, mountAt, type = '', opts = {}) {
  const fsType = type || probeDeviceType(device)
  if (skipNonLinuxFs(fsType)) {
    return { ok: false, reason: `skip-${fsType || 'fs'}` }
  }
  if (!opts.force) {
    if (looksLikeFatPartition(device) && !linuxFs(fsType)) {
      return { ok: false, reason: 'skip-fat' }
    }
    const sectors = partitionSectors(device)
    if (tooSmallForLinuxRoot(sectors, largestSiblingSectors(device))) {
      return { ok: false, reason: 'skip-small-efi' }
    }
  }
  mkdirSync(mountAt, { recursive: true })
  const mounts = parseProcMounts(readText('/proc/mounts'))
  const already = mounts.find((row) => row.mount === mountAt)
  if (already) {
    if (already.device === device || path.resolve(already.device) === path.resolve(device)) {
      return { ok: true, reason: 'already' }
    }
    try {
      execFileSync('umount', [mountAt], { timeout: 8000, stdio: 'ignore' })
    } catch {
      /* still try mount */
    }
  }
  const bin = mountBin()
  const attempts = []
  if (linuxFs(fsType)) attempts.push(['-t', fsType, '-o', 'rw', device, mountAt])
  attempts.push(['-o', 'rw', device, mountAt])
  attempts.push(['-t', 'ext4', '-o', 'rw', device, mountAt])
  attempts.push(['-t', 'xfs', '-o', 'rw', device, mountAt])
  let last = 'mount-fail'
  for (const args of attempts) {
    try {
      execFileSync(bin, args, { timeout: 15_000, stdio: 'ignore' })
      return { ok: true, reason: args.includes('-t') ? args[1] : fsType || 'auto' }
    } catch (err) {
      last = String(err.stderr || err.message || 'mount-fail').replace(/\s+/g, ' ').slice(0, 80)
    }
  }
  return { ok: false, reason: last }
}

function resolveFstabDevice(spec, records) {
  const raw = String(spec || '').trim()
  if (!raw) return ''
  if (raw.startsWith('/dev/')) return raw
  const uuid = raw.match(/^UUID=(.+)$/i)
  if (uuid) {
    const hit = records.find((row) => row.uuid === uuid[1])
    return hit?.device || `/dev/disk/by-uuid/${uuid[1]}`
  }
  const label = raw.match(/^LABEL=(.+)$/i)
  if (label) {
    const hit = records.find((row) => row.label === label[1])
    return hit?.device || `/dev/disk/by-label/${label[1]}`
  }
  return ''
}

function scoreProbe(root) {
  let score = 0
  const homes = homeNamesUnder(root)
  score += homes.length * 10
  if (existsSync(path.join(root, 'etc/passwd'))) score += 5
  for (const name of homes) {
    if (existsSync(path.join(root, 'home', name, 'neuOS'))) score += 50
    if (existsSync(path.join(root, 'home', name, 'os.neu'))) score += 20
    if (existsSync(path.join(root, 'home', name, '.bashrc'))) score += 2
  }
  return { score, homes }
}

/**
 * Mount the installed Linux root (not the USB) and pick ~/os.neu for that user.
 */
export function mountHostLinux(onTick) {
  const log = typeof onTick === 'function' ? onTick : () => {}
  const mountAt = hostMountPoint()
  const mounts = parseProcMounts(readText('/proc/mounts'))
  const rootDev = rootDeviceFromMounts(mounts)
  const rootDisk = diskFromDevice(rootDev)
  const records = parseBlkid(runBlkid())
  const disks = listSysDisks()
  const parts = listDevPartitions()
  const skipped = []
  const dropped = []
  const tried = []

  log('host probe v3')
  settleDisks(log)

  const diskReason = (disk) =>
    skipDiskReason({
      disk,
      removable: disks.includes(disk) ? readRemovable(disk) : '0',
      labels: records.filter((row) => diskFromDevice(row.device) === disk).map((row) => row.label).filter(Boolean),
      rootDisk,
    })

  let best = null
  for (const device of parts) {
    const disk = diskFromDevice(device)
    const reason = diskReason(disk)
    if (reason) {
      const tag = `${disk}=${reason}`
      if (!skipped.includes(tag)) skipped.push(tag)
      log(`skip ${device} ${reason}`)
      continue
    }
    const type = probeDeviceType(device)
    if (skipNonLinuxFs(type)) {
      dropped.push(`${device}:${type}`)
      log(`skip ${device} ${type}`)
      continue
    }
    log(`try ${device} ${type || 'unknown'}`)
    const mounted = ensureMount(device, mountAt, type, { force: true })
    tried.push(`${device} ${type || '?'} ${mounted.reason}`)
    if (!mounted.ok) {
      log(`fail ${device} ${mounted.reason}`)
      continue
    }
    const probed = scoreProbe(mountAt)
    log(`ok ${device} score=${probed.score} homes=${(probed.homes || []).join(',')}`)
    tried[tried.length - 1] += ` score=${probed.score}`
    if (!best || probed.score > best.score) {
      best = { device, type, ...probed, force: true }
    }
  }

  if (!best || best.score < 5) {
    return {
      ok: false,
      error: 'no-host-linux',
      root: rootDev,
      disks,
      skipped,
      parts,
      dropped,
      tried,
      hint: 'No Linux home. USB is sda; Ubuntu should be sdb2.',
    }
  }

  const remount = ensureMount(best.device, mountAt, best.type, { force: true })
  if (!remount.ok) {
    return { ok: false, error: 'mount-failed', hint: `Could not mount ${best.device}`, tried }
  }

  const fstabHome = parseFstabHomeSource(readText(path.join(mountAt, 'etc/fstab')))
  if (fstabHome && homeNamesUnder(mountAt).length === 0) {
    const homeDev = resolveFstabDevice(fstabHome, records)
    if (homeDev) {
      mkdirSync(path.join(mountAt, 'home'), { recursive: true })
      try {
        execFileSync('mount', ['-o', 'rw', homeDev, path.join(mountAt, 'home')], { timeout: 15_000, stdio: 'ignore' })
      } catch {
        /* home stays on root partition */
      }
    }
  }

  const users = parsePasswd(readText(path.join(mountAt, 'etc/passwd')))
  const homes = homeNamesUnder(mountAt)
  const user = pickHostUser(users, homes)
  if (!user) {
    return { ok: false, error: 'no-login-user', hint: 'Mounted Linux but found no /home user.' }
  }

  const homeRel = user.home.startsWith('/home/') ? user.home : `/home/${user.name}`
  const homeMount = path.join(mountAt, homeRel.replace(/^\//, ''))
  if (!existsSync(homeMount)) {
    return { ok: false, error: 'no-home-dir', hint: `No ${homeRel} on the internal disk.` }
  }

  return {
    ok: true,
    mount: mountAt,
    device: best.device,
    user: user.name,
    uid: user.uid,
    gid: user.gid,
    homeRel,
    homeMount,
    osNeuRel: path.posix.join(homeRel, 'os.neu'),
    osNeuPath: path.join(homeMount, 'os.neu'),
    neuOSPath: path.join(homeMount, 'neuOS'),
  }
}

export async function resolvePlantTarget(onTick) {
  if (process.env.NEUOS_JEOS === '1') {
    const host = mountHostLinux(onTick)
    if (!host.ok) return { dest: '', host: null, error: host.hint || host.error, detail: host }
    return { dest: host.osNeuPath, host, error: '', detail: host }
  }
  const home = process.env.HOME || '/root'
  return { dest: path.join(home, 'os.neu'), host: null, error: '' }
}

export function destIsUsbStick(dest) {
  if (process.env.NEUOS_JEOS !== '1') return false
  const resolved = path.resolve(String(dest || ''))
  const mountAt = hostMountPoint()
  if (resolved.startsWith(mountAt + path.sep) || resolved === mountAt) return false
  if (resolved === '/' || resolved === '/os.neu' || resolved.startsWith('/os.neu/')) return true
  if (resolved.startsWith('/opt/neuos')) return true
  if (resolved === '/root/os.neu' || resolved.startsWith('/root/os.neu/')) return true
  return false
}
