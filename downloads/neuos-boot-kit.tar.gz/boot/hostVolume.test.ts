import { describe, expect, it } from 'vitest'
import {
  destIsUsbStick,
  diskFromDevice,
  linuxFs,
  parseBlkid,
  parseFstabHomeSource,
  parsePasswd,
  parseProcMounts,
  pickHostUser,
  rootDeviceFromMounts,
  skipDiskReason,
  skipNonLinuxFs,
  tooSmallForLinuxRoot,
  isPartitionName,
  fatSignatureInBootSector,
} from './hostVolume.mjs'

describe('host volume from USB', () => {
  it('maps partition names back to the disk', () => {
    expect(diskFromDevice('/dev/sdb2')).toBe('sdb')
    expect(diskFromDevice('/dev/sdd2')).toBe('sdd')
    expect(diskFromDevice('/dev/nvme0n1p2')).toBe('nvme0n1')
  })

  it('skips EFI-sized partitions when a larger sibling exists', () => {
    const oneGiB = 1 * 1024 * 1024 * 2
    const twoHundredGiB = 200 * 1024 * 1024 * 2
    expect(tooSmallForLinuxRoot(oneGiB, twoHundredGiB)).toBe(true)
    expect(tooSmallForLinuxRoot(twoHundredGiB, twoHundredGiB)).toBe(false)
    expect(tooSmallForLinuxRoot(0, twoHundredGiB)).toBe(false)
  })

  it('detects FAT only at the boot-sector signature, not a stray FAT32 string', () => {
    const fat = Buffer.alloc(512, 0)
    fat.write('FAT32   ', 0x52, 'latin1')
    expect(fatSignatureInBootSector(fat)).toBe(true)
    const grub = Buffer.alloc(512, 0)
    grub.write('GRUB FAT32 leftover', 0, 'latin1')
    expect(fatSignatureInBootSector(grub)).toBe(false)
  })

  it('recognizes Linux partition device names', () => {
    expect(isPartitionName('sdb2')).toBe(true)
    expect(isPartitionName('sdb')).toBe(false)
    expect(isPartitionName('nvme0n1p2')).toBe(true)
  })

  it('does not treat EFI vfat or NTFS as the Linux home disk', () => {
    expect(skipNonLinuxFs('vfat')).toBe(true)
    expect(skipNonLinuxFs('ntfs')).toBe(true)
    expect(linuxFs('vfat')).toBe(false)
    expect(linuxFs('ext4')).toBe(true)
  })

  it('treats the USB root disk and NEUOS labels as off-limits', () => {
    expect(
      skipDiskReason({ disk: 'sdd', removable: '1', labels: ['NEUOS-ROOT'], rootDisk: 'sdd' }),
    ).toBe('current-root')
    expect(
      skipDiskReason({ disk: 'sdd', removable: '1', labels: ['NEUOS-ROOT'], rootDisk: 'sdb' }),
    ).toBe('removable')
    expect(
      skipDiskReason({ disk: 'sdb', removable: '0', labels: [], rootDisk: 'sdd' }),
    ).toBe('')
  })

  it('reads the live root device from /proc/mounts text', () => {
    const rows = parseProcMounts('/dev/sdd2 / ext4 rw 0 0\n/dev/sdb2 /mnt/osneu-host ext4 rw 0 0\n')
    expect(rootDeviceFromMounts(rows)).toBe('/dev/sdd2')
  })

  it('parses blkid labels so NEUOS-ROOT is not planted onto', () => {
    const rows = parseBlkid(`
/dev/sdb2: UUID="abc" TYPE="ext4"
/dev/sdd1: LABEL="NEUOS-ESP" TYPE="vfat"
/dev/sdd2: LABEL="NEUOS-ROOT" TYPE="ext4"
`)
    expect(rows[1].label).toBe('NEUOS-ESP')
    expect(rows[2].label).toBe('NEUOS-ROOT')
    expect(rows[0].type).toBe('ext4')
  })

  it('picks a real login home, not root', () => {
    const users = parsePasswd(`
root:x:0:0:root:/root:/bin/bash
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
billy-lee:x:1000:1000:Billy:/home/billy-lee:/bin/bash
`)
    const user = pickHostUser(users, ['billy-lee'])
    expect(user?.name).toBe('billy-lee')
    expect(user?.home).toBe('/home/billy-lee')
  })

  it('reads a separate /home from fstab', () => {
    expect(parseFstabHomeSource('UUID=xyz /home ext4 defaults 0 2\n')).toBe('UUID=xyz')
  })

  it('refuses USB stick folders while JeOS is on', () => {
    const prev = process.env.NEUOS_JEOS
    process.env.NEUOS_JEOS = '1'
    expect(destIsUsbStick('/os.neu')).toBe(true)
    expect(destIsUsbStick('/root/os.neu')).toBe(true)
    expect(destIsUsbStick('/mnt/osneu-host/home/billy-lee/os.neu')).toBe(false)
    if (prev === undefined) delete process.env.NEUOS_JEOS
    else process.env.NEUOS_JEOS = prev
  })
})
