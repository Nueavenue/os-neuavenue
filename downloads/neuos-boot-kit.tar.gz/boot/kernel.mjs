#!/usr/bin/env node
/**
 * JeOS userspace "kernel" for neuOS.
 * This is NOT UEFI firmware and NOT CPU machine code.
 * It runs on Node.js after a Linux kernel has already started.
 *
 * Safety: commands are allowlisted. Host reboot is refused unless NEUOS_JEOS=1.
 */
import { parseAppIntent, detectHost, planApp } from './hostProfile.mjs'
import { execFileSync } from 'node:child_process'
import { writeFileSync, mkdirSync } from 'node:fs'
import { createInterface } from 'node:readline'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HEALTH = path.join(ROOT, 'data', 'boot-health.json')
const ALLOW = new Map([
  ['network', ['ip', ['route', 'show']]],
  ['hardware', ['lscpu', []]],
  ['memory', ['free', ['-h']]],
])

mkdirSync(path.dirname(HEALTH), { recursive: true })

function beat(extra = {}) {
  const body = {
    ok: true,
    t: Date.now(),
    pid: process.pid,
    jeos: process.env.NEUOS_JEOS === '1',
    platform: process.platform,
    ...extra,
  }
  writeFileSync(HEALTH, JSON.stringify(body, null, 2))
  return body
}

function runAllow(name) {
  const spec = ALLOW.get(name)
  if (!spec) throw new Error(`not-allowlisted:${name}`)
  const [bin, args] = spec
  try {
    return execFileSync(bin, args, { encoding: 'utf8', timeout: 4000 })
  } catch (err) {
    return String(err.message || err)
  }
}

function interpret(input) {
  const t = input.toLowerCase()
  if (t === 'exit' || t === 'quit') return { type: 'exit' }
  if (t.includes('lui') || t.includes('loop') || t.includes('루프')) return { type: 'lui' }
  if (t.includes('reboot')) {
    if (process.env.NEUOS_JEOS === '1') return { type: 'reboot' }
    return { type: 'text', text: 'reboot refused on a host desktop. Set NEUOS_JEOS=1 only inside the USB image.' }
  }
  if (t.includes('network') || t.includes('네트워크')) return { type: 'cmd', name: 'network' }
  if (t.includes('hardware') || t.includes('cpu') || t.includes('하드웨어')) return { type: 'cmd', name: 'hardware' }
  if (t.includes('memory') || t.includes('ram') || t.includes('기억')) return { type: 'cmd', name: 'memory' }
  const app = parseAppIntent(input)
  if (app) return { type: 'app', intent: app }
  return { type: 'text', text: `AI: understood "${input}". Map more connectors in boot/kernel.mjs.` }
}

function ask(input) {
  const act = interpret(input)
  if (act.type === 'app') {
    const host = detectHost()
    const plan = planApp(host, act.intent)
    const reply = `${plan.next}\n${plan.command}${plan.url ? `\n${plan.url}` : ''}`
    const health = beat({ stage: 'app', last: input, act: 'app', app: act.intent.app })
    return { ok: true, act: 'app', reply, plan, health }
  }
  let reply = act.text ?? act.type
  if (act.type === 'cmd') reply = runAllow(act.name)
  const health = beat({ stage: 'ask', last: input, act: act.type })
  return { ok: true, act: act.type, reply, health }
}

const onceIdx = process.argv.indexOf('--once')
if (onceIdx >= 0) {
  const seed = process.argv[onceIdx + 1] ?? 'hardware'
  const act = interpret(seed)
  if (act.type === 'cmd') console.log(runAllow(act.name))
  else console.log(act.text ?? act.type)
  beat({ stage: 'once', last: seed })
  process.exit(0)
}

if (process.argv.includes('--health')) {
  console.log(JSON.stringify(beat({ stage: 'probe' })))
  process.exit(0)
}

const askIdx = process.argv.indexOf('--ask')
if (askIdx >= 0) {
  const seed = process.argv[askIdx + 1] ?? 'hardware'
  console.log(JSON.stringify(ask(seed)))
  process.exit(0)
}

const rl = createInterface({ input: process.stdin, output: process.stdout })
beat({ stage: 'boot' })
setInterval(() => beat({ stage: 'loop' }), 4000)
console.clear()
console.log('neuOS JeOS userspace')
console.log('Linux kernel + Node runtime. Not motherboard firmware.')
console.log('Type: hardware | network | memory | install firefox | exit')

function loop() {
  rl.question('\n[neuOS] > ', (input) => {
    const act = interpret(input.trim())
    if (act.type === 'exit') {
      beat({ stage: 'halt' })
      rl.close()
      return
    }
    if (act.type === 'reboot') {
      console.log('JeOS reboot requested (image only)')
      rl.close()
      return
    }
    if (act.type === 'cmd') {
      console.log(runAllow(act.name))
    } else if (act.type === 'app') {
      const host = detectHost()
      const plan = planApp(host, act.intent)
      console.log(plan.next)
      console.log(plan.command)
    } else if (act.type === 'lui') {
      console.log('return to talk loop (LUI)')
    } else {
      console.log(act.text ?? act.type)
    }
    beat({ stage: 'tick', last: input })
    loop()
  })
}

loop()
