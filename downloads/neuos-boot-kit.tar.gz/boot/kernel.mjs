#!/usr/bin/env node
/**
 * os.neu userspace kernel.
 * This is NOT UEFI firmware and NOT CPU machine code.
 * Technical USB boot chain: see docs/architecture-implementation.md.
 */
import { parseAppIntent, detectHost, planApp, searchCatalog } from './hostProfile.mjs'
import { destIsUsbStick, resolvePlantTarget } from './hostVolume.mjs'
import {
  defaultPlantDir,
  isHelpCommand,
  isOpenScreenCommand,
  isPlantCommand,
  isUninstallCommand,
  launchScreen,
  printInstallInterfacesDialog,
  printScreenFallbackGuide,
  runPlant,
} from './plant.mjs'
import { openPlantDialog, startPlantServer } from './plantServer.mjs'
import { completeText, pullPublicModel, writeLlmSettings } from './localLlm.mjs'
import { execFileSync } from 'node:child_process'
import { writeFileSync, mkdirSync, readFileSync } from 'node:fs'
import { createInterface } from 'node:readline'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HEALTH = path.join(ROOT, 'data', 'boot-health.json')

function loadLocalEnv() {
  let raw = ''
  try {
    raw = readFileSync(path.join(ROOT, '.env'), 'utf8')
  } catch {
    return
  }
  for (const line of raw.split('\n')) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const eq = trimmed.indexOf('=')
    if (eq < 1) continue
    const key = trimmed.slice(0, eq).trim()
    let value = trimmed.slice(eq + 1).trim()
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1)
    }
    if (key && process.env[key] == null) process.env[key] = value
  }
}

loadLocalEnv()

const COACH_SYSTEM = `You are os.neu Speak, a warm English speaking coach for the os.neu console (NeuSpeak method).
Reply in natural conversational English. Keep replies short (1-3 sentences).
Gently model correct phrasing if the learner made a mistake. End with a short question.`

async function coachText(message) {
  try {
    const result = await completeText({
      messages: [
        { role: 'system', content: COACH_SYSTEM },
        { role: 'user', content: message },
      ],
    })
    return result.text
  } catch {
    return 'Coach is offline here. Type hardware | network | memory | install firefox. Optional: save your own key after install os.neu.'
  }
}
const ALLOW = new Map([
  ['network', ['ip', ['route', 'show']]],
  ['hardware', ['lscpu', []]],
  ['memory', ['free', ['-h']]],
])

mkdirSync(path.dirname(HEALTH), { recursive: true })

function beat(extra = {}) {
  const body = {
    ok: true,
    t: Date.now(),
    pid: process.pid,
    jeos: process.env.NEUOS_JEOS === '1',
    platform: process.platform,
    ...extra,
  }
  writeFileSync(HEALTH, JSON.stringify(body, null, 2))
  return body
}

function runUninstall() {
  const script = path.join(ROOT, 'scripts/uninstall-autostart.sh')
  try {
    return execFileSync('bash', [script], { encoding: 'utf8', timeout: 15_000 })
  } catch (err) {
    return String(err.message || err)
  }
}

function runAllow(name) {
  const spec = ALLOW.get(name)
  if (!spec) throw new Error(`not-allowlisted:${name}`)
  const [bin, args] = spec
  try {
    return execFileSync(bin, args, { encoding: 'utf8', timeout: 4000 })
  } catch (err) {
    return String(err.message || err)
  }
}

function interpret(input) {
  const t = input.toLowerCase()
  if (t === 'exit' || t === 'quit') return { type: 'exit' }
  if (isPlantCommand(input)) return { type: 'plant' }
  if (isUninstallCommand(input)) return { type: 'uninstall' }
  if (isOpenScreenCommand(input)) return { type: 'open' }
  if (isHelpCommand(input)) return { type: 'help' }
  if (/^(cd\b|ls\b|pwd\b|bash\b|~\/|\/os\.neu|\/home)/i.test(String(input || '').trim())) return { type: 'help' }
  if (t.includes('lui') || t.includes('loop') || t.includes('루프')) return { type: 'lui' }
  if (t.includes('reboot')) {
    if (process.env.NEUOS_JEOS === '1') return { type: 'reboot' }
    return { type: 'text', text: 'reboot refused on a host desktop. USB image only.' }
  }
  if (t.includes('network') || t.includes('네트워크')) return { type: 'cmd', name: 'network' }
  if (t.includes('hardware') || t.includes('cpu') || t.includes('하드웨어')) return { type: 'cmd', name: 'hardware' }
  if (t.includes('memory') || t.includes('ram') || t.includes('기억')) return { type: 'cmd', name: 'memory' }
  const app = parseAppIntent(input)
  if (app) return { type: 'app', intent: app }
  return { type: 'coach', prompt: input }
}

async function ask(input) {
  const act = interpret(input)
  if (act.type === 'app') {
    const host = detectHost()
    const plan = planApp(host, act.intent)
    const reply = `${plan.next}\n${plan.command}${plan.url ? `\n${plan.url}` : ''}`
    const health = beat({ stage: 'app', last: input, act: 'app', app: act.intent.app })
    return { ok: true, act: 'app', reply, plan, health }
  }
  if (act.type === 'coach') {
    const reply = await coachText(act.prompt)
    const health = beat({ stage: 'ask', last: input, act: 'coach' })
    return { ok: true, act: 'coach', reply, health }
  }
  let reply = act.text ?? act.type
  if (act.type === 'cmd') reply = runAllow(act.name)
  const health = beat({ stage: 'ask', last: input, act: act.type })
  return { ok: true, act: act.type, reply, health }
}

const onceIdx = process.argv.indexOf('--once')
if (onceIdx >= 0) {
  const seed = process.argv[onceIdx + 1] ?? 'hardware'
  const act = interpret(seed)
  if (act.type === 'cmd') console.log(runAllow(act.name))
  else console.log(act.text ?? act.type)
  beat({ stage: 'once', last: seed })
  process.exit(0)
}

if (process.argv.includes('--health')) {
  console.log(JSON.stringify(beat({ stage: 'probe' })))
  process.exit(0)
}

const askIdx = process.argv.indexOf('--ask')
if (askIdx >= 0) {
  const seed = process.argv[askIdx + 1] ?? 'hardware'
  console.log(JSON.stringify(await ask(seed)))
  process.exit(0)
}

const rl = createInterface({ input: process.stdin, output: process.stdout })
beat({ stage: 'boot' })
setInterval(() => beat({ stage: 'loop' }), 4000)
console.clear()
console.log('os.neu')
console.log('Userspace shell. Not motherboard firmware.')
console.log('Type: install os.neu | open os.neu | help | uninstall os.neu | hardware | network | memory | install firefox | English line | exit')

function askLine(prompt) {
  return new Promise((resolve) => {
    rl.question(prompt, (line) => resolve(String(line || '').trim()))
  })
}

async function runPlantWizard() {
  if (process.env.NEUOS_JEOS === '1') {
    console.log('')
    console.log('Looking for this PC’s Linux home (not the USB)…')
    const target = await resolvePlantTarget((line) => console.log(line))
    if (!target.host || destIsUsbStick(target.dest)) {
      console.log(target.error || 'No Linux /home on this PC.')
      console.log('OS-NEU-IC-000  host Linux home not found (USB skipped; no mount).')
      const d = target.detail
      if (d) {
        console.log(`root ${d.root || '?'}`)
        console.log(`disks ${(d.disks || []).join(',') || 'none'}`)
        console.log(`skip ${(d.skipped || []).join(',') || 'none'}`)
        console.log(`drop ${(d.dropped || []).join(',') || 'none'}`)
        console.log(`tried ${(d.tried || []).join(' | ') || 'none'}`)
      }
      console.log('install os.neu copies onto the internal disk’s ~/os.neu, then opens the os.neu screen.')
      return
    }
    console.log('┌──────────────────────────────────────────────┐')
    console.log('│  install os.neu                              │')
    console.log(`│  ${String(target.host.osNeuRel).slice(0, 42).padEnd(42)}│`)
    console.log('│  this PC disk — not the USB stick            │')
    console.log('└──────────────────────────────────────────────┘')
    console.log('Copying onto this PC, then opening the os.neu screen…')
    console.log('USB has no install-wizard window. This console is the installer.')
    const job = await runPlant(ROOT, target.dest, (tick) => {
      process.stdout.write(`\r  ${String(tick.percent).padStart(3)}%  ${tick.stage}          `)
    }, {
      host: target.host,
      autostartHome: target.host.homeMount,
      execRoot: target.host.osNeuRel,
    })
    process.stdout.write('\n')
    const planted = job.dest || target.dest
    console.log(`Planted ${target.host.osNeuRel}`)
    printInstallInterfacesDialog(target.host.osNeuRel, { kiosk: job.kiosk })
    console.log('Opening the os.neu screen (in-app browser) on this session…')
    const launched = launchScreen(planted, 'lui', { host: target.host })
    if (launched.ok) {
      console.log(`Screen: ${target.host.osNeuRel}`)
      return
    }
    printScreenFallbackGuide(target.host.osNeuRel)
    if (launched.reason) console.log(`reason: ${launched.reason}`)
    return
  }

  const dest = defaultPlantDir()
  console.log('')
  console.log('┌──────────────────────────────────────────────┐')
  console.log('│  os.neu install                              │')
  console.log(`│  default folder: ${dest.slice(0, 28).padEnd(28)}│`)
  console.log('│  Opening the install panel…                  │')
  console.log('└──────────────────────────────────────────────┘')
  const { url } = await startPlantServer(4188)
  const opened = openPlantDialog(url)
  if (opened) {
    console.log(`Install panel: ${url}`)
    console.log('Steps: copy → search → public AI → os.neu screen.')
    console.log('Progress is in that panel. Guide: ' + url + 'guide')
    return
  }
  console.log(`No graphical display. Install panel is also at ${url}`)
  console.log(`TTY fallback will plant into ${dest}`)
  const chosen = (await askLine('folder > ')) || dest
  console.log('Copying…')
  const job = await runPlant(ROOT, chosen, (tick) => {
    process.stdout.write(`\r  ${String(tick.percent).padStart(3)}%  ${tick.stage}          `)
  })
  process.stdout.write('\n')
  const planted = job.dest || dest
  const query = await askLine('search app (firefox) or Enter to skip > ')
  if (query) {
    const apps = searchCatalog(query, detectHost())
    for (const row of apps) {
      console.log(`${row.app}: ${row.command}`)
    }
  }
  const pull = (await askLine('Download public AI on this PC? [y/N] > ')).toLowerCase()
  const ownKey = await askLine('Optional own OpenAI key (Enter to skip) > ')
  writeLlmSettings({ openaiKey: ownKey }, planted)
  if (pull === 'y' || pull === 'yes') {
    console.log('Receiving public AI…')
    const result = await pullPublicModel(planted)
    if (!result.ok) {
      console.log(result.hint || result.reason || 'public AI skipped')
      if (result.command) console.log(result.command)
    } else {
      console.log('Public AI is ready.')
    }
  }
  console.log('Opening the os.neu screen (docs · sheets · slides)…')
  const launched = launchScreen(planted, 'lui')
  if (launched.ok) {
    console.log(`Screen: ${launched.dest}`)
    return
  }
  printScreenFallbackGuide(planted)
}

async function runOpenScreen() {
  if (process.env.NEUOS_JEOS === '1') {
    console.log('Opening the os.neu screen from this USB session…')
    const target = await resolvePlantTarget((line) => console.log(line))
    if (!target.host || destIsUsbStick(target.dest)) {
      console.log(target.error || 'No Linux /home on this PC.')
      console.log('OS-NEU-IC-000  host Linux home not found (USB skipped; no mount).')
      const d = target.detail
      if (d) {
        console.log(`root ${d.root || '?'}`)
        console.log(`skip ${(d.skipped || []).join(',') || 'none'}`)
        console.log(`drop ${(d.dropped || []).join(',') || 'none'}`)
        console.log(`tried ${(d.tried || []).join(' | ') || 'none'}`)
      }
      printScreenFallbackGuide(undefined, console.log, 'OS-NEU-IC-000')
      return
    }
    const launched = launchScreen(target.dest, 'lui', { host: target.host })
    if (launched.ok) {
      console.log(`Screen: ${target.host.osNeuRel}`)
      return
    }
    printScreenFallbackGuide(target.host.osNeuRel)
    if (launched.reason) console.log(`reason: ${launched.reason}`)
    return
  }
  const dest = defaultPlantDir()
  console.log('Opening the os.neu screen…')
  const launched = launchScreen(dest, 'lui')
  if (launched.ok) {
    console.log(`Screen: ${launched.dest}`)
    return
  }
  printScreenFallbackGuide(dest)
}

function printConsoleHelp() {
  console.log('Type: install os.neu | open os.neu | uninstall os.neu | hardware | network | memory | help | exit')
  printScreenFallbackGuide()
}

async function openGuidePopup() {
  const { url } = await startPlantServer(4188)
  console.log('┌──────────────────────────────────────────────┐')
  console.log('│  os.neu install guide                        │')
  console.log(`│  ${`${url}guide`.slice(0, 42).padEnd(42)}│`)
  console.log('│  A window opens above this console if a      │')
  console.log('│  display exists.                             │')
  console.log('└──────────────────────────────────────────────┘')
  openPlantDialog(`${url}guide`)
}

function loop() {
  rl.question('\n[os.neu] > ', (input) => {
    void (async () => {
      const act = interpret(input.trim())
      if (act.type === 'exit') {
        beat({ stage: 'halt' })
        rl.close()
        return
      }
      if (act.type === 'reboot') {
        console.log('os.neu reboot requested (image only)')
        rl.close()
        return
      }
      if (act.type === 'plant') {
        await runPlantWizard()
      } else if (act.type === 'open') {
        await runOpenScreen()
      } else if (act.type === 'help') {
        printConsoleHelp()
      } else if (act.type === 'uninstall') {
        console.log(runUninstall())
      } else if (act.type === 'cmd') {
        console.log(runAllow(act.name))
      } else if (act.type === 'app') {
        const host = detectHost()
        const plan = planApp(host, act.intent)
        console.log(plan.next)
        console.log(plan.command)
      } else if (act.type === 'lui') {
        console.log('return to talk loop (LUI)')
      } else if (act.type === 'coach') {
        console.log(await coachText(act.prompt))
      } else {
        console.log(act.text ?? act.type)
      }
      beat({ stage: 'tick', last: input })
      loop()
    })()
  })
}

void openGuidePopup().finally(() => loop())
