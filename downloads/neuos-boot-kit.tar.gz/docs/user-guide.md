# User guide

No driver sandbox, bridge ports, or firmware internals. For people who turn the computer on and speak.

## What OS.neu does

Power on → NeuAvenue logo → an AI screen with no folders and no Start menu. The PC may already have Windows or Linux, or none.

Public home: **https://os.neuavenue.com** (alias `neuos.neuavenue.com`). The public landing is the **os.neu screen** (same app as local `http://127.0.0.1:5173/`). **Planting and USB burn with the files we ship now are Linux only.** There is no Windows or macOS installer yet. The landing still opens in any browser. Manual: top **Manual** icon. Tutorial markdown: [https://docs.neuavenue.com](https://docs.neuavenue.com). Local practice: `/welcome/` still ships as the static install sheet. School walkthrough: [student-usb-guide.md](./student-usb-guide.md). DNS: [domain-landing.md](./domain-landing.md).

## If the laptop already has an OS

This path is **Linux** with the current files (`install-autostart.sh`). Windows and macOS installers are not in this kit.

1. Open os.neu and choose **PC that already has an OS**.
2. Wait until progress reaches 100%. The disk is not wiped.
3. Hardware summary → body check → **JeOS DOS terminal** or **talk AI loop**.
4. The next graphical login opens the same screen.

## If there is no OS

1. Download the boot kit from the install home, or choose **USB without an OS** in os.neu.
2. If more than one stick is plugged in, pick **one**.
3. Test mode (`/?test=1`) prepares an image and does **not** format the stick. A real burn happens only after you confirm the printed command.
4. Reboot, open the firmware boot menu (ASUS: **F8**), choose USB. First screen is `[neuOS] >`. If you see `grub>` instead, follow [student-usb-guide.md](./student-usb-guide.md) step 6 or https://os.neuavenue.com/tutorial.

## Two screens after start

| Choice | What you see | When |
| --- | --- | --- |
| JeOS | Dark TTY prompt `[neuOS] >` | USB stick, or Exit → JeOS screen |
| Userspace AI loop | Talk line, WhatsApp-style chat | Everyday speaking on a planted login |

os.neu remembers whether you last installed from the DOS prompt or from the talk screen, and guides the next install the same way.

## Structure screen (optional)

The five titles **Four layers · Speech LUI · Eyes VLM · Brain Orchestrator · Hands Driver** are **not** things you have to learn to use os.neu. They are a behind-the-glass tour. You reach them from the **Layers / 구조** tile, or by saying you want to see how the screen works.

Everyday use stays: speak or type one line.

| Tab you see | Plain meaning | Do you need it? |
| --- | --- | --- |
| **Four layers** | Map of the four jobs stacked on the hidden PC | No. Overview only |
| **1. Speech LUI** | The full-screen talk face (mic + one line). “LUI” = language UI | No. You already use it |
| **2. Eyes VLM** | “Where is the Save button?” — looks at the screen and gets X,Y. “VLM” = vision model | No. Only if a job clicks in the sheet |
| **3. Brain Orchestrator** | Splits “write a report” into steps and retries if a step fails | No. The progress ticks are this |
| **4. Hands Driver** | The click/type hand. It must stay inside the os.neu box, not the Windows desktop | No. Shown as **live** only when real clicks are on |

Under the four jobs sits the hidden Windows/Linux. os.neu never asks you to name it.

If the English abbreviations feel like an error: they are builder names left on a student-facing tab. Closing the tour (⌂ / Back to talk) is the right next step.

## Installing or removing an app

Examples: `install chrome`, `install firefox`, `remove vscode`.

os.neu detects Ubuntu vs Windows vs macOS first, then shows one matching command plus an official download URL. You confirm before anything actually installs.

## Leave

Top-right **Exit** → health check → JeOS or talk screen. Not seeing a Windows desktop is expected.

## Practice

When the status bar says you are online, the speaker next to the prompt plays the English coach (NeuSpeak). The mic records a line and sends it to the coach. The JeOS console (`C:\NEUOS>`) also answers English sentences through the same OpenAI path. Keys stay in local `.env`, never in git.
