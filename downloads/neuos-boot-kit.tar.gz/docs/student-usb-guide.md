# Student guide: website to USB

For a student who opens **os.neuavenue.com**, downloads a file, and puts **os.neu v1.0** on a USB stick. **Burning the kit is Linux only** (`bash scripts/make-usb.sh`). There is no Windows or macOS installer in the current files.

The company site is [neuavenue.com](https://neuavenue.com/). os.neu lives on a **subdomain** with the same header and footer. DNS: [domain-landing.md](./domain-landing.md). Full USB boot recovery: [https://os.neuavenue.com/tutorial](https://os.neuavenue.com/tutorial).

USB 콘솔이 켜지면 화면 **위 가이드 패널**과 이 링크가 같이 열립니다: `http://127.0.0.1:4188/guide`

## One line

Browser → install home → **Download** → plug USB → confirm the burn command → reboot and start from USB → type `install os.neu`.

A browser cannot silently format a USB drive. Wiping the stick still needs a human confirmation (`sudo … --yes`).

## You need

- A computer with internet
- A USB stick that is empty or **OK to erase** (4 GB+)
- Do not use a stick that holds homework or photos

## 1. Open the site

| Address | Meaning |
| --- | --- |
| `https://os.neuavenue.com` | Canonical landing — **os.neu screen** (Vite). [Nueavenue/os-neuavenue](https://github.com/Nueavenue/os-neuavenue) |
| This laptop | `http://127.0.0.1:5173/` or `/welcome/` |

You should see the OS.neu splash, then install. Top **Manual** opens the same tutorial as [docs.neuavenue.com](https://docs.neuavenue.com). The static Download sheet remains at `/welcome/`.

## 2. Download

1. Click **Download boot kit** (`neuos-boot-kit.tar.gz`).
2. Check the Downloads folder.
3. If an ISO button works, that is a disk image. The kit is enough for the next step.

## 3. Plug in USB

Plug the stick into a **rear motherboard USB port** until the OS notices it.

## 4. os.neu 설치 패널

콘솔에 `[os.neu] >` 가 보이면 `install os.neu` 를 입력합니다. 설치 패널이 열리면 순서는 항상 같습니다.

1. **복사** — 설치 패널에서 기본 폴더(`~/os.neu`)를 확인하고 파일을 복사합니다. 하드디스크는 지우지 않습니다.
2. **검색** — firefox 같은 앱 이름을 찾습니다. 설치 명령을 보여 줄 뿐, 대신 지우거나 실행하지 않습니다.
3. **공개 AI** — 이 PC에서 공개 AI를 받을지 **스스로** 고릅니다. 회사 AI 열쇠는 붙여넣어도 되고 비워도 됩니다. 공용 열쇠는 없습니다.
4. **os.neu 화면** — 끝나면 문서 · 시트 · 슬라이드가 있는 화면이 열립니다.

패널이 없으면 콘솔이 같은 질문을 글자로 합니다.

## 5. Boot this PC from that USB (ASUS)

1. Leave the stick plugged in. Save work.
2. Power on. At the ASUS logo press **F8** several times (then Esc, then F12).
3. Choose **UEFI: … USB …**. Prefer the `UEFI:` line. Do not choose the internal Ubuntu SSD.
4. Success is a **dark text console** `[os.neu] >`. That is os.neu — not the graphical talk screen yet. After `install os.neu` the os.neu screen can open.

If Ubuntu or Windows opens, USB was not selected. Power off, reseat the stick, F8 again.

Boot Menu missing: **Del** (desktop) or **F2** (laptop) → **Boot Override** → USB. Do not set Boot Option #1 to USB forever. Do not flash BIOS.

## 6. If you see `grub>` instead of `[os.neu] >`

The USB started the boot menu program, but the menu file was not on the EFI partition. This is **not** the os.neu console. Recovery commands are in [architecture-implementation.md](./architecture-implementation.md) §5 and [https://os.neuavenue.com/tutorial](https://os.neuavenue.com/tutorial) step 4.

Give up: hold power, unplug USB, power on. Internal disk is not wiped.

## 7. If you see `payload not found` and BusyBox `#`

If the keyboard does **not** type at `#`, stop. Power off and boot Ubuntu (do not pick USB). Refresh the stick without wiping:

```
cd ~/neuOS
sudo bash scripts/make-usb.sh /dev/sdX --update
```

Then F8-boot USB again. Details: [architecture-implementation.md](./architecture-implementation.md).

## With an OS vs without

| Your computer | On the site / wizard |
| --- | --- |
| Windows or Linux already there | **Has an OS** → next login is os.neu. Disk not wiped |
| Empty disk, or USB-only | **USB without an OS** → firmware boot from the stick |

## If something fails

- Download fails → Wi-Fi, try again
- USB missing → another port, unplug and replug
- Progress stuck → confirm test mode, reopen os.neu
- Other PC only shows Windows → firmware USB boot (F8)
- `grub>` → https://os.neuavenue.com/tutorial step 4
- `payload not found` / BusyBox `#` → tutorial step 5

Internals (builders): [architecture-flow.md](./architecture-flow.md), [architecture-implementation.md](./architecture-implementation.md). This page is enough for a student.
