# 1. neuOS overview & definition

## One-line definition

**neuOS** is a company-branded AI shell that runs on existing Windows or Linux hardware so a beginner never has to see a desktop. Power-on should feel like opening a browser-shaped prompt, not like learning an operating system.

It is **not** a CPU kernel, **not** motherboard firmware, and **not** a replacement for Intel/AMD machine code. A hidden Linux (or Windows) kernel still boots. neuOS is the userspace product that occupies the screen after that.

## Why it exists

Three pain points drove the product:

1. Beginners do not know Windows, Linux, or macOS folders, start menus, or window chrome.
2. After power-on they want an AI prompt immediately — no “open a browser, then type a URL”.
3. Power-on should show a friendly hardware check, not a BIOS POST dump or a fault screen they cannot read.

## What “OS” means here

| Layer | Who owns it | User sees it? |
| --- | --- | --- |
| CPU / chipset | Intel, AMD, OEM | No |
| UEFI / BIOS | Signed motherboard firmware | No (do not flash) |
| Bootloader | GRUB on USB, or the host’s existing bootloader | Only if they pick USB in firmware |
| Hidden kernel | Linux (JeOS) or the already-installed OS | No |
| **neuOS userspace** | This repo | **Yes — the whole product** |

The company strategy is **de-OS**: whether the PC already has an OS or the disk is empty, the user is guided back into neuOS. From there they can plant neuOS on the host, burn a USB, or keep using the kiosk as a guest.

## Four product layers (the stack)

```
LUI  (말)     Language UI — brand kiosk, mic, one line
  ↓ intent
VLM  (눈)     Vision — find X,Y of controls on the screen
  ↓ boxes
Orchestrator (뇌)  Split the job, retry / heal on failure
  ↓ plan
Driver (손)   Click, type, hotkey — sandbox only
  ↓
Hidden host OS + hardware
```

These four layers are implemented in `src/engine/` and explained in-product on the Layer Studio screen (`phase: studio`).

## What ships today

- Fullscreen kiosk UI (Vite + React) with splash → install gate → hardware POST → network → talk loop or offline phone-home.
- Node bridge on `127.0.0.1:4178` (health, browse proxy, driver, VLM samples, boot-health, USB plan, host plant).
- Electron `BrowserView` so real sites open like Chrome (iframes cannot).
- JeOS userspace loop: `boot/kernel.mjs` writing `data/boot-health.json`.
- Host autostart (`npm run boot:install`) and USB/ISO packer (`npm run usb`).
- 12-locale copy with location-based language detect.
- Neuavenue logo on splash / status / window icon (`public/brand/`).
- Public install homepage at `/welcome/` (production target **os.neuavenue.com**, alias neuos.neuavenue.com) plus in-kiosk wizard.
- OS-aware app install/remove from JeOS DOS prompt or LUI, with a preference monitor (`data/user-monitor.json`).

## What neuOS is not (this quarter)

- A custom Linux kernel written from scratch.
- Unsigned UEFI on the motherboard chip (brick risk; no OEM keys).
- Abandoned NodeOS.
- A guarantee that DRM sites (Netflix / Widevine) play 100% in Electron.
- A full graphical kiosk on a bare USB with no X/Electron in the image — that stick currently hands off to the **TTY AI kernel loop**. Graphical kiosk is the host-plant path (`npm run kiosk` / login autostart).

## Name and version

- Product / repo: **neuOS** (`neuos` npm name)
- Version: `0.1.0`
- Runtime identity: `NEUOS_KIOSK=1`, `NEUOS_ELECTRON=1`, `NEUOS_JEOS=1`, `NEUOS_DRIVER=live|dry-run`
