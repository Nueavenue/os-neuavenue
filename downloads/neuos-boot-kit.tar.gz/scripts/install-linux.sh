#!/usr/bin/env bash
# Copy this tree to ~/os.neu, npm install, then plant the Linux launcher + service.
# Linux only. Does not wipe disks.
set -euo pipefail
if [[ "$(uname -s)" != "Linux" ]]; then
  echo "os.neu installer is Linux only. There is no Windows or macOS installer yet." >&2
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE"
if [[ -d "$HERE/os.neu" && -f "$HERE/os.neu/package.json" ]]; then
  SRC="$HERE/os.neu"
elif [[ -f "$HERE/../package.json" && -d "$HERE/../src" ]]; then
  SRC="$(cd "$HERE/.." && pwd)"
fi

DEST="${NEUOS_DEST:-$HOME/os.neu}"
mkdir -p "$DEST"
if [[ "$(cd "$SRC" && pwd)" != "$(cd "$DEST" && pwd)" ]]; then
  if command -v rsync >/dev/null; then
    rsync -a --delete \
      --exclude node_modules \
      --exclude .git \
      --exclude dist \
      --exclude .env \
      --exclude .env.* \
      "$SRC/" "$DEST/"
  else
    tar -C "$SRC" --exclude=node_modules --exclude=.git --exclude=dist --exclude=.env \
      -cf - . | tar -C "$DEST" -xf -
  fi
fi

chmod +x "$DEST/scripts/"*.sh 2>/dev/null || true
cd "$DEST"

if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
  echo "Need Node.js 20+ and npm on this Linux PC, then run: bash $DEST/scripts/install-linux.sh" >&2
  exit 2
fi

if [[ ! -d "$DEST/node_modules/electron" ]]; then
  npm install
fi

bash "$DEST/scripts/install-autostart.sh"
echo
echo "os.neu is on this Linux PC."
echo "Show Apps and the Desktop now have the os.neu icon. No cd."
echo "To start now: click os.neu, or bash $DEST/scripts/open-neuos.sh"
