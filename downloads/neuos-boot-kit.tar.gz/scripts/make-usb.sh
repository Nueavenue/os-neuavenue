#!/usr/bin/env bash
# Pack a bootable neuOS USB or ISO.
# Copies this repo + a Node binary + the builder's Linux kernel, then GRUB.
# Does not flash motherboard firmware. Refuses to write the disk that holds /.
#
#   bash scripts/make-usb.sh                 # ISO → dist/neuos-live.iso
#   bash scripts/make-usb.sh --list
#   bash scripts/make-usb.sh --plan /dev/sdb
#   sudo bash scripts/make-usb.sh /dev/sdb --yes
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
STAGE="$ROOT/dist/neuos-usb"
ISO="$ROOT/dist/neuos-live.iso"
YES=0
LIST=0
PLAN=0
TEST=0
DEVICE=""

usage() {
  cat <<EOF
neuOS USB / ISO builder (JeOS userspace, hidden Linux kernel)

  bash scripts/make-usb.sh                 write dist/neuos-live.iso
  bash scripts/make-usb.sh --list          show disks (USB candidates marked)
  bash scripts/make-usb.sh --plan DEV      print the wipe/write plan, do not write
  sudo bash scripts/make-usb.sh DEV --yes  partition DEV and install neuOS

The target PC boots this stick even if it has no installed OS.
Graphical kiosk still needs a host session (npm run boot:install) or a full
Buildroot image. The stick's first payload is the neuOS AI kernel loop.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --list) LIST=1; shift ;;
    --plan) PLAN=1; shift; DEVICE="${1:-}"; shift || true ;;
    --yes|-y) YES=1; shift ;;
    --test) TEST=1; shift ;;
    --iso) DEVICE=""; shift ;;
    /dev/*) DEVICE="$1"; shift ;;
    *) echo "unknown arg: $1" >&2; usage; exit 2 ;;
  esac
done

root_src() {
  findmnt -n -o SOURCE / 2>/dev/null || true
}

is_system_dev() {
  local dev="$1"
  local src
  src="$(root_src)"
  [[ -n "$src" && "$src" == "$dev"* ]]
}

list_disks() {
  echo "== block disks =="
  lsblk -o NAME,PATH,SIZE,MODEL,RM,TYPE,MOUNTPOINT
  echo
  echo "USB candidates (removable, not the / disk):"
  lsblk -dn -o PATH,SIZE,MODEL,RM,TYPE | awk '$4==1 && $5=="disk" {print}'
}

if [[ "$LIST" == 1 ]]; then
  list_disks
  exit 0
fi

copy_bin_with_libs() {
  local src="$1"
  local dest_dir="$2"
  mkdir -p "$dest_dir"
  local base
  base="$(basename "$src")"
  cp -a "$src" "$dest_dir/$base"
  if command -v ldd >/dev/null && ldd "$src" >/dev/null 2>&1; then
    ldd "$src" | awk '/=>/ {print $3} /^\// {print $1}' | while read -r lib; do
      [[ -z "$lib" || ! -e "$lib" ]] && continue
      local libdir="$STAGE$(dirname "$lib")"
      mkdir -p "$libdir"
      cp -a "$lib" "$libdir/" 2>/dev/null || true
    done
  fi
}

pack_initramfs() {
  local initdir
  initdir="$(mktemp -d)"
  mkdir -p "$initdir"/{bin,sbin,proc,sys,dev,newroot,lib,lib64,usr/bin}
  cp "$ROOT/boot/live/init" "$initdir/init"
  chmod +x "$initdir/init"
  if command -v busybox >/dev/null; then
    copy_bin_with_libs "$(command -v busybox)" "$initdir/bin"
    (cd "$initdir/bin" && ln -sf busybox sh && ln -sf busybox mount && ln -sf busybox umount && ln -sf busybox sleep && ln -sf busybox mkdir && ln -sf busybox echo && ln -sf busybox switch_root)
  else
    for bin in bash sh mount umount sleep mkdir echo ls; do
      if command -v "$bin" >/dev/null; then
        copy_bin_with_libs "$(command -v "$bin")" "$initdir/bin"
      fi
    done
    [[ -e $initdir/bin/sh ]] || ln -sf bash "$initdir/bin/sh"
  fi
  if command -v switch_root >/dev/null; then
    copy_bin_with_libs "$(command -v switch_root)" "$initdir/sbin"
  fi
  (cd "$initdir" && find . | cpio -o -H newc 2>/dev/null | gzip -9) > "$STAGE/boot/initrd.img"
  rm -rf "$initdir"
}

stage_tree() {
  rm -rf "$STAGE"
  mkdir -p "$STAGE"/{boot/grub,opt/neuos,sbin,usr/bin,etc}
  rsync -a --delete \
    --exclude node_modules \
    --exclude .git \
    --exclude dist \
    --exclude data/vlm-samples \
    "$ROOT/" "$STAGE/opt/neuos/"
  cp "$ROOT/boot/kernel.mjs" "$STAGE/opt/neuos/kernel.mjs"
  cp "$ROOT/boot/init/neuos-init" "$STAGE/sbin/neuos-init"
  chmod +x "$STAGE/sbin/neuos-init"
  cp "$ROOT/boot/init/inittab" "$STAGE/etc/inittab"

  local node
  node="$(command -v node)"
  mkdir -p "$STAGE/opt/neuos/runtime"
  copy_bin_with_libs "$node" "$STAGE/opt/neuos/runtime"
  ln -sfn /opt/neuos/runtime/node "$STAGE/usr/bin/node"

  if [[ "$TEST" != 1 ]]; then
    local kver
    kver="$(uname -r)"
    local vmlinuz=""
    for cand in "/boot/vmlinuz-$kver" /boot/vmlinuz /boot/vmlinuz-linux; do
      if [[ -f "$cand" ]]; then
        vmlinuz="$cand"
        break
      fi
    done
    if [[ -n "$vmlinuz" ]]; then
      cp "$vmlinuz" "$STAGE/boot/vmlinuz"
    else
      echo "WARN: no /boot/vmlinuz on this builder — ISO will not Linux-boot until you copy one." >&2
    fi
    if [[ -d "/lib/modules/$kver" ]]; then
      mkdir -p "$STAGE/lib/modules"
      rsync -a "/lib/modules/$kver" "$STAGE/lib/modules/"
    fi
    pack_initramfs
  else
    echo "TEST stage: skip kernel modules and initramfs"
    echo "neuOS test payload" > "$STAGE/boot/TEST"
  fi

  cat > "$STAGE/boot/grub/grub.cfg" <<'EOF'
set timeout=3
set default=0
insmod all_video
insmod gzio
insmod part_gpt
insmod ext2
search --label NEUOS-ROOT --set=root --no-floppy || search --file /opt/neuos/kernel.mjs --set=root
menuentry "neuOS" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw quiet loglevel=3
    initrd /boot/initrd.img
}
menuentry "neuOS (this ISO)" {
    linux /boot/vmlinuz quiet loglevel=3
    initrd /boot/initrd.img
}
EOF
  echo "staged $STAGE"
}

write_iso() {
  mkdir -p "$ROOT/dist"
  if command -v grub-mkrescue >/dev/null; then
    grub-mkrescue -o "$ISO" "$STAGE"
    echo "ISO $ISO"
  else
    echo "MISS grub-mkrescue — tree is in $STAGE"
    echo "Install: sudo apt install grub-pc-bin grub-efi-amd64-bin xorriso mtools"
    echo "Then re-run: bash scripts/make-usb.sh"
    return 0
  fi
}

if [[ -z "$DEVICE" ]]; then
  stage_tree
  if [[ "$TEST" == 1 ]]; then
    echo "TEST payload $STAGE (no disk write)"
    exit 0
  fi
  write_iso
  echo
  echo "Next: sudo dd if=$ISO of=/dev/sdX bs=4M status=progress conv=fsync"
  echo "  or: sudo bash scripts/make-usb.sh /dev/sdX --yes"
  exit 0
fi

if [[ ! -b "$DEVICE" ]]; then
  echo "not a block device: $DEVICE" >&2
  exit 1
fi

if is_system_dev "$DEVICE"; then
  echo "refusing to overwrite the disk that holds / ($DEVICE)" >&2
  exit 1
fi

rm_flag="$(lsblk -dn -o RM "$DEVICE" 2>/dev/null || echo 0)"
if [[ "$rm_flag" != "1" ]]; then
  echo "WARN: $DEVICE is not flagged removable (RM=1)." >&2
fi

echo "plan: wipe $DEVICE and install neuOS JeOS (kernel + /opt/neuos + GRUB)"
lsblk "$DEVICE"
if [[ "$PLAN" == 1 || "$YES" != 1 ]]; then
  echo
  echo "To write: sudo bash scripts/make-usb.sh $DEVICE --yes"
  exit 0
fi

if [[ "$(id -u)" != 0 ]]; then
  echo "USB write needs root. sudo bash scripts/make-usb.sh $DEVICE --yes" >&2
  exit 1
fi

stage_tree

wipefs -a "$DEVICE" || true
parted -s "$DEVICE" mklabel gpt
parted -s "$DEVICE" mkpart ESP fat32 1MiB 512MiB
parted -s "$DEVICE" set 1 esp on
parted -s "$DEVICE" mkpart ROOT ext4 512MiB 100%
sleep 1
ESP="${DEVICE}1"
ROOTP="${DEVICE}2"
if [[ "$DEVICE" == *[0-9] ]]; then
  ESP="${DEVICE}p1"
  ROOTP="${DEVICE}p2"
fi
mkfs.vfat -F 32 -n NEUOS-ESP "$ESP"
mkfs.ext4 -F -L NEUOS-ROOT "$ROOTP"

ESP_MNT="$(mktemp -d)"
ROOT_MNT="$(mktemp -d)"
mount "$ROOTP" "$ROOT_MNT"
mount "$ESP" "$ESP_MNT"
mkdir -p "$ESP_MNT/EFI" "$ROOT_MNT/boot"
rsync -a "$STAGE/" "$ROOT_MNT/"
if command -v grub-install >/dev/null; then
  grub-install --target=x86_64-efi --efi-directory="$ESP_MNT" --boot-directory="$ROOT_MNT/boot" --removable --recheck "$DEVICE" || true
  grub-install --target=i386-pc --boot-directory="$ROOT_MNT/boot" --recheck "$DEVICE" || true
fi
sync
umount "$ESP_MNT" "$ROOT_MNT"
rmdir "$ESP_MNT" "$ROOT_MNT"
echo "neuOS is on $DEVICE. Firmware boot menu → USB."
