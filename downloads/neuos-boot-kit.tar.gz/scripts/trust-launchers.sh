#!/usr/bin/env bash
# Mark os.neu launchers trusted for GNOME/Nautilus and refresh icon caches.
# No network. Does not wipe disks.
set -euo pipefail
HOME_DIR="${NEUOS_HOME:-$HOME}"
APP="${HOME_DIR}/.local/share/applications/neuos.desktop"
DESK="${HOME_DIR}/Desktop/neuos.desktop"
ICON_DIR="${HOME_DIR}/.local/share/icons/hicolor"

trust_one() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  chmod +x "$f" 2>/dev/null || true
  if command -v gio >/dev/null; then
    gio set "$f" metadata::trusted true 2>/dev/null || true
    gio set "$f" "metadata::trusted" yes 2>/dev/null || true
  fi
}

trust_one "$APP"
trust_one "$DESK"

if command -v gtk-update-icon-cache >/dev/null && [[ -d "$ICON_DIR" ]]; then
  gtk-update-icon-cache -f -t "$ICON_DIR" >/dev/null 2>&1 || true
fi
if command -v update-desktop-database >/dev/null; then
  update-desktop-database "${HOME_DIR}/.local/share/applications" >/dev/null 2>&1 || true
fi
if command -v xdg-desktop-menu >/dev/null; then
  xdg-desktop-menu forceupdate >/dev/null 2>&1 || true
fi
if command -v notify-send >/dev/null; then
  notify-send "os.neu" "Show Apps and Desktop have the os.neu icon." >/dev/null 2>&1 || true
fi

echo "trusted: $APP"
echo "trusted: $DESK"
