#!/usr/bin/env bash
# Graphical login entry point. Used by XDG autostart and systemd --user.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export HOME="${HOME:-/home/billy-lee}"
if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.nvm/nvm.sh"
fi
ulimit -n 65536 2>/dev/null || true
exec bash "$ROOT/scripts/kiosk.sh"
