#!/usr/bin/env bash
# Install user autostart so neuOS opens after graphical login.
# Does NOT change /etc/default/grub (that would replace systemd on this Ubuntu).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
AUTO="$HOME/.config/autostart"
USER_SYS="$HOME/.config/systemd/user"
mkdir -p "$AUTO" "$USER_SYS"
chmod +x "$ROOT/scripts/open-neuos.sh" "$ROOT/scripts/kiosk.sh" "$ROOT/boot/init/neuos-init"

sed "s|/home/billy-lee/neuOS|$ROOT|g" "$ROOT/boot/init/neuos.desktop" > "$AUTO/neuos.desktop"
sed "s|/home/billy-lee/neuOS|$ROOT|g" "$ROOT/boot/init/neuos.service" > "$USER_SYS/neuos.service"

if command -v systemctl >/dev/null && systemctl --user show-environment >/dev/null 2>&1; then
  systemctl --user daemon-reload
  systemctl --user enable neuos.service >/dev/null
  echo "enabled systemd --user neuos.service"
else
  echo "systemd --user not active in this shell; XDG autostart still installed"
fi

echo "autostart: $AUTO/neuos.desktop"
echo "unit:      $USER_SYS/neuos.service"
echo "JeOS USB templates stay in boot/init/ (inittab, grub.cfg, neuos-init)."
echo "Do not copy grub-default.snippet onto this workstation."
