#!/usr/bin/env bash
# Stop os.neu from opening at Ubuntu graphical login.
# Does NOT wipe disks. Does NOT delete this git tree (neuOS).
# Optional: --files removes only $HOME/os.neu if it is a planted copy.
set -euo pipefail
AUTO="${HOME}/.config/autostart/neuos.desktop"
UNIT_DIR="${HOME}/.config/systemd/user"
UNIT="${UNIT_DIR}/neuos.service"
PLANTED="${HOME}/os.neu"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILES=0
if [[ "${1:-}" == "--files" ]]; then
  FILES=1
fi

if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now neuos.service >/dev/null 2>&1 || true
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi

rm -f "$AUTO" "$UNIT"
echo "autostart removed: $AUTO"
echo "user unit removed: $UNIT"

if ((FILES)); then
  if [[ -d "$PLANTED" && "$PLANTED" != "$ROOT" ]]; then
    rm -rf "$PLANTED"
    echo "removed planted copy: $PLANTED"
  else
    echo "skip files: $PLANTED is missing or is this source tree ($ROOT)"
  fi
fi

echo "os.neu will not open at the next Ubuntu login."
echo "This Ubuntu desktop is unchanged. Disks were not wiped."
