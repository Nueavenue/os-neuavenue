import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/**/*.test.ts', 'server/**/*.test.ts', 'boot/**/*.test.ts', 'scripts/**/*.test.ts'],
  },
})
