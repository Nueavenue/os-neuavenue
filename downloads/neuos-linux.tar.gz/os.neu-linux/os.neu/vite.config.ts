import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist-web',
    emptyOutDir: true,
  },
  server: {
    host: true,
    port: 5173,
    watch: {
      usePolling: true,
      interval: 1000,
    },
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
  preview: {
    host: true,
    port: 4177,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
})
