import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { defineConfig, type Plugin } from 'vite'

const rootDir = path.dirname(fileURLToPath(import.meta.url))
const pkg = createRequire(import.meta.url)('./package.json') as { version?: string }
const OSNEU_VERSION = String(pkg.version || '1.0.15')

/** Provider+hook modules cannot Fast Refresh. Full reload keeps the seat from going black. */
function fullReloadProviders(): Plugin {
  const names = ['store.tsx', 'AppCatalogContext.tsx']
  const hit = (file: string) => names.some((name) => file.endsWith(name))
  return {
    name: 'full-reload-providers',
    handleHotUpdate({ file, server, modules }) {
      if (hit(file) || modules.some((mod) => Boolean(mod.file && hit(mod.file)))) {
        server.ws.send({ type: 'full-reload' })
        return []
      }
    },
  }
}

/** Serve public/*.html before SPA fallback (fixes /preview, /landing-samples). */
function servePublicHtml(): Plugin {
  return {
    name: 'serve-public-html',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const raw = req.url?.split('?')[0] ?? ''
        if (!raw || raw.startsWith('/@') || raw.startsWith('/src') || raw.startsWith('/node_modules')) {
          return next()
        }
        let rel = decodeURIComponent(raw)
        if (rel.endsWith('/')) rel += 'index.html'
        if (!rel.endsWith('.html')) return next()
        const abs = path.join(rootDir, 'public', rel)
        if (!abs.startsWith(path.join(rootDir, 'public'))) return next()
        if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return next()
        res.statusCode = 200
        res.setHeader('Content-Type', 'text/html; charset=utf-8')
        fs.createReadStream(abs).pipe(res)
      })
    },
  }
}

export default defineConfig({
  plugins: [fullReloadProviders(), react(), servePublicHtml()],
  define: {
    __OSNEU_VERSION__: JSON.stringify(OSNEU_VERSION),
  },
  build: {
    outDir: 'dist-web',
    emptyOutDir: true,
  },
  server: {
    host: true,
    port: 5173,
    watch: {
      usePolling: true,
      interval: 1000,
    },
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
  preview: {
    host: true,
    port: 4177,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
})
