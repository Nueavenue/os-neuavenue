# os.neu boot paths — feasibility

## CPU machine code
Intel/AMD execute **machine code only**. Node.js never replaces that. V8 JIT-compiles JavaScript to machine code **after** a kernel is already running. `kernel.js` is userspace, not a CPU kernel.

## Motherboard chip (UEFI/BIOS)
A tiny program can live in flash, but it must be **signed** by the OEM / Intel / AMD. Unsigned os.neu on the chip will not boot on modern laptops and can brick the board. **Do not flash the chip.** Ship USB or factory-provisioned SSD instead.

## Three paths

| Path | Possible now | Success chance | How we verify |
| --- | --- | --- | --- |
| 1. Custom kernel | Research only | Low this year | Need GPU/Wi-Fi drivers per board |
| 2. Ubuntu-based boot image (`make-usb.sh` copies the builder's Ubuntu generic kernel + Node + live initramfs) | VM verified | High in VM | QEMU/KVM. Real USB = OS-NEU-SX-000 OPEN. Buildroot/Yocto = research only, not implemented |
| 3. Thin client | After JeOS net | Medium | Image must bring up NIC then load LUI |

NodeOS is abandoned. Buildroot / Yocto is research only — not used by `scripts/make-usb.sh` (Ubuntu kernel image).

## De-OS strategy

Whether the PC already has Windows/Linux or the disk is empty, power-on should land in os.neu.

| Track | Command | What the user sees |
| --- | --- | --- |
| Plant on a host that already has an OS | First screen → **Plant on this PC**, or `npm run boot:install` | Next graphical login opens the os.neu screen. Disk is not wiped. |
| USB for a machine with **no** OS | First screen → USB, or `npm run usb` / `sudo npm run usb -- /dev/sdX --yes` | Firmware boot menu → USB → `[os.neu] >` Seat console loop. If `grub>` appears, load `grub.cfg` from `NEUOS-ROOT` (tutorial step 4). |
| Guest | First screen → **Try now** | Same os.neu screen without planting. **Exit** still offers JeOS vs talk loop. |

Graphical os.neu screen from USB: type `install os.neu`. That plants `~/os.neu` on the **PC disk** (not the stick), writes autostart, then opens the os.neu screen (in-app browser) in the same USB session. A compositor (`cage` / `weston`, staged onto the stick when apt can download them) plus the host’s Electron tree are required for that window. If the compositor cannot take a seat, the console prints `open os.neu` (retry) and `bash ~/os.neu/scripts/open-neuos.sh` for the Ubuntu terminal. Type `help` to see that guide again.

`scripts/make-usb.sh` copies this repo, a Node binary, the **builder’s** `/boot/vmlinuz` + modules, and a tiny initramfs. It never flashes UEFI. It refuses to overwrite the disk that holds `/`.

## Auto-run at startup

| Machine | Exact file | What it runs |
| --- | --- | --- |
| This Ubuntu (graphical login) | `~/.local/share/applications/neuos.desktop`, `~/Desktop/neuos.desktop`, `~/.config/autostart/neuos.desktop`, and systemd user `neuos.service` | Click the **os.neu** icon (no `cd`). Next login can also open the screen. The window is resizable. |
| JeOS USB (no desktop) | `/boot/grub/grub.cfg` on `NEUOS-ROOT`, copied also to ESP `/EFI/BOOT/grub.cfg` + live `initrd` that finds `LABEL=NEUOS-ROOT` | `/usr/sbin/neuos-init` → `node …/kernel.mjs` (`[os.neu] >`) |

Public install page: `/welcome/` now, **os.neuavenue.com** in DNS ([docs/domain-landing.md](../docs/domain-landing.md)). Architecture: [implementation](../docs/architecture-implementation.md), [flow](../docs/architecture-flow.md).

Monitor: `data/boot-health.json` heartbeat from `boot/kernel.mjs`. **Exit** refreshes it via `/api/boot-health?refresh=1` before offering JeOS or the talk loop.

## Automated virtual gate

Run `npm run boot:virt:console` before a physical USB walk, then
`npm run boot:virt:gui`. These commands use QEMU/KVM + OVMF and retain serial,
QMP, ISO, and screenshot evidence on the external data volume. See
[`docs/virtual-boot-automation.md`](../docs/virtual-boot-automation.md).

Observed 2026-10-26: console PASS. GUI now paints the os.neu landing chrome
(`…/runs/20261026T112501Z-588675`), not `OS-NEU-SX-002`. The virtual gate does
not close `OS-NEU-SX-000`; physical i915, EDID, input, and a USB stick walk
still require one final real-machine walk.

<!-- 2026-11-04 consistency v1.0 (PMO audit D-08) per D4 -->
