import { describe, expect, it } from 'vitest'
import {
  destIsUsbStick,
  diskFromDevice,
  parseBlkid,
  parseFstabHomeSource,
  parsePasswd,
  parseProcMounts,
  pickHostUser,
  rootDeviceFromMounts,
  skipDiskReason,
} from './hostVolume.mjs'

describe('host volume from USB', () => {
  it('maps partition names back to the disk', () => {
    expect(diskFromDevice('/dev/sdb2')).toBe('sdb')
    expect(diskFromDevice('/dev/sdd2')).toBe('sdd')
    expect(diskFromDevice('/dev/nvme0n1p2')).toBe('nvme0n1')
  })

  it('treats the USB root disk and NEUOS labels as off-limits', () => {
    expect(
      skipDiskReason({ disk: 'sdd', removable: '1', labels: ['NEUOS-ROOT'], rootDisk: 'sdd' }),
    ).toBe('current-root')
    expect(
      skipDiskReason({ disk: 'sdd', removable: '1', labels: ['NEUOS-ROOT'], rootDisk: 'sdb' }),
    ).toBe('removable')
    expect(
      skipDiskReason({ disk: 'sdb', removable: '0', labels: [], rootDisk: 'sdd' }),
    ).toBe('')
  })

  it('reads the live root device from /proc/mounts text', () => {
    const rows = parseProcMounts('/dev/sdd2 / ext4 rw 0 0\n/dev/sdb2 /mnt/osneu-host ext4 rw 0 0\n')
    expect(rootDeviceFromMounts(rows)).toBe('/dev/sdd2')
  })

  it('parses blkid labels so NEUOS-ROOT is not planted onto', () => {
    const rows = parseBlkid(`
/dev/sdb2: UUID="abc" TYPE="ext4"
/dev/sdd1: LABEL="NEUOS-ESP" TYPE="vfat"
/dev/sdd2: LABEL="NEUOS-ROOT" TYPE="ext4"
`)
    expect(rows[1].label).toBe('NEUOS-ESP')
    expect(rows[2].label).toBe('NEUOS-ROOT')
    expect(rows[0].type).toBe('ext4')
  })

  it('picks a real login home, not root', () => {
    const users = parsePasswd(`
root:x:0:0:root:/root:/bin/bash
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
billy-lee:x:1000:1000:Billy:/home/billy-lee:/bin/bash
`)
    const user = pickHostUser(users, ['billy-lee'])
    expect(user?.name).toBe('billy-lee')
    expect(user?.home).toBe('/home/billy-lee')
  })

  it('reads a separate /home from fstab', () => {
    expect(parseFstabHomeSource('UUID=xyz /home ext4 defaults 0 2\n')).toBe('UUID=xyz')
  })

  it('refuses USB stick folders while JeOS is on', () => {
    const prev = process.env.NEUOS_JEOS
    process.env.NEUOS_JEOS = '1'
    expect(destIsUsbStick('/os.neu')).toBe(true)
    expect(destIsUsbStick('/root/os.neu')).toBe(true)
    expect(destIsUsbStick('/mnt/osneu-host/home/billy-lee/os.neu')).toBe(false)
    if (prev === undefined) delete process.env.NEUOS_JEOS
    else process.env.NEUOS_JEOS = prev
  })
})
