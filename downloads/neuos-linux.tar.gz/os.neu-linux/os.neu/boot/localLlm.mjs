/**
 * Public on-device AI (Ollama) plus an optional user-owned cloud key.
 * Never ships a shared OpenAI key. USB / plant copies must not include .env.
 */
import { chmodSync, mkdirSync, readFileSync, renameSync, statfsSync, statSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

export const LOCAL_MODEL = 'llama3.2:1b'
export const OLLAMA_HOST = (process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').replace(/\/$/, '')

/** Fixed vendor-id list (matches CLOUD_ROUTES). HTTP dest is ignored elsewhere. */
export const ALLOWED_VENDOR_IDS = Object.freeze([
  'openai',
  'anthropic',
  'google',
  'moonshot',
  'xai',
  'qwen',
  'deepseek',
  'meta',
  'zai',
  'mistral',
  'perplexity',
])
export const KEY_VALUE_MAX = 512

export function llmSettingsPath(root = ROOT) {
  return path.join(root, 'data', 'user-llm.json')
}

export function defaultLlmSettings() {
  return { provider: 'auto', localModel: LOCAL_MODEL, openaiKey: '', pulled: false, vendorKeys: {} }
}

function clipKeyValue(value) {
  const text = String(value || '').trim()
  if (!text || text.length > KEY_VALUE_MAX) return ''
  return text
}

export function sanitizeVendorKeys(incoming, prev = {}) {
  const next = {}
  if (prev && typeof prev === 'object') {
    for (const [id, value] of Object.entries(prev)) {
      if (!ALLOWED_VENDOR_IDS.includes(id)) continue
      const kept = clipKeyValue(value)
      if (kept) next[id] = kept
    }
  }
  if (incoming && typeof incoming === 'object') {
    for (const [id, value] of Object.entries(incoming)) {
      if (!ALLOWED_VENDOR_IDS.includes(id)) continue
      const text = String(value || '').trim()
      if (!text) continue
      if (text.length > KEY_VALUE_MAX) continue
      next[id] = text
    }
  }
  return next
}

function tightenKeyFileMode(file) {
  try {
    chmodSync(file, 0o600)
  } catch {
    /* missing or not ours */
  }
}

export function readLlmSettings(root = ROOT) {
  const file = llmSettingsPath(root)
  tightenKeyFileMode(file)
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8'))
    const { dest: _ignoredDest, ...rest } = raw && typeof raw === 'object' ? raw : {}
    return {
      ...defaultLlmSettings(),
      ...rest,
      vendorKeys: sanitizeVendorKeys(rest.vendorKeys, {}),
    }
  } catch {
    return defaultLlmSettings()
  }
}

export function writeLlmSettings(partial, root = ROOT) {
  const prev = readLlmSettings(root)
  const incoming = partial && typeof partial === 'object' ? partial : {}
  const { dest: _ignoredDest, vendorKeys: incomingVendors, openaiKey, ...rest } = incoming
  const next = { ...prev, ...rest }
  if (typeof openaiKey === 'string') {
    const trimmed = openaiKey.trim()
    if (!trimmed) next.openaiKey = ''
    else if (trimmed.length <= KEY_VALUE_MAX) next.openaiKey = trimmed
  }
  next.vendorKeys = sanitizeVendorKeys(incomingVendors, prev.vendorKeys)
  delete next.dest
  const text = JSON.stringify(next, null, 2)
  if (!text || text.length <= 1) {
    throw new Error('llm-settings-empty')
  }
  const destFile = llmSettingsPath(root)
  const dir = path.dirname(destFile)
  mkdirSync(dir, { recursive: true })
  const tmp = path.join(dir, `.user-llm.${process.pid}.tmp`)
  try {
    writeFileSync(tmp, text, { mode: 0o600 })
    chmodSync(tmp, 0o600)
    if (statSync(tmp).size <= 1) throw new Error('llm-settings-empty')
    renameSync(tmp, destFile)
    chmodSync(destFile, 0o600)
  } catch (err) {
    console.error('[os.neu] llm settings write failed')
    throw err
  }
  return next
}

export function userOpenAiKey(root = ROOT) {
  return String(readLlmSettings(root).openaiKey || process.env.OPENAI_API_KEY || '').trim()
}

export function ollamaInstallHint() {
  return {
    reason: 'ollama-missing',
    hint: '이 PC에 공개 AI 도구(Ollama)가 없습니다. 설치한 뒤 다시 받으면 됩니다.',
    command: 'curl -fsSL https://ollama.com/install.sh | sh',
  }
}

let pullJob = {
  percent: 0,
  stage: 'idle',
  error: '',
  model: LOCAL_MODEL,
}

export function llmPullStatus() {
  return { ...pullJob }
}

export async function ollamaStatus() {
  try {
    const res = await fetch(`${OLLAMA_HOST}/api/tags`, { signal: AbortSignal.timeout(2000) })
    if (!res.ok) return { ok: false, models: [], hasDefault: false }
    const body = await res.json()
    const models = (body?.models || []).map((row) => String(row?.name || '')).filter(Boolean)
    const hasDefault = models.some((name) => name === LOCAL_MODEL || name.startsWith('llama3.2'))
    return { ok: true, models, hasDefault }
  } catch {
    return { ok: false, models: [], hasDefault: false }
  }
}

function parsePullLine(line, job) {
  try {
    const row = JSON.parse(line)
    if (row.error) {
      job.error = String(row.error)
      job.stage = 'error'
      return
    }
    if (row.status) job.stage = String(row.status)
    const total = Number(row.total || 0)
    const completed = Number(row.completed || 0)
    if (total > 0) job.percent = Math.min(99, Math.round((completed / total) * 100))
    if (row.status === 'success') {
      job.percent = 100
      job.stage = 'done'
    }
  } catch {
    /* ignore non-json */
  }
}

export async function pullPublicModel(root = ROOT) {
  pullJob = { percent: 4, stage: 'check', error: '', model: LOCAL_MODEL }
  const status = await ollamaStatus()
  if (!status.ok) {
    pullJob.stage = 'error'
    pullJob.error = ollamaInstallHint().reason
    return { ok: false, ...ollamaInstallHint(), ...pullJob }
  }
  if (status.hasDefault) {
    pullJob.percent = 100
    pullJob.stage = 'done'
    writeLlmSettings({ provider: 'auto', localModel: LOCAL_MODEL, pulled: true }, root)
    return { ok: true, skipped: true, ...pullJob }
  }
  pullJob.stage = 'pull'
  pullJob.percent = 8
  const res = await fetch(`${OLLAMA_HOST}/api/pull`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: LOCAL_MODEL, stream: true }),
  })
  if (!res.ok || !res.body) {
    pullJob.stage = 'error'
    pullJob.error = `pull-${res.status}`
    return { ok: false, reason: pullJob.error, ...pullJob }
  }
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buf = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += decoder.decode(value, { stream: true })
    const lines = buf.split('\n')
    buf = lines.pop() || ''
    for (const line of lines) parsePullLine(line, pullJob)
    if (pullJob.stage === 'error') return { ok: false, reason: pullJob.error, ...pullJob }
  }
  if (buf.trim()) parsePullLine(buf.trim(), pullJob)
  if (pullJob.stage === 'error') return { ok: false, reason: pullJob.error, ...pullJob }
  pullJob.percent = 100
  pullJob.stage = 'done'
  writeLlmSettings({ provider: 'auto', localModel: LOCAL_MODEL, pulled: true }, root)
  return { ok: true, ...pullJob }
}

function localOptions(model, extra = {}) {
  return {
    num_predict: numPredictFor(model),
    temperature: 0.3,
    ...extra,
  }
}

export async function chatLocal(messages, model = LOCAL_MODEL, extra = {}) {
  const res = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model,
      messages,
      stream: false,
      options: localOptions(model, extra),
      keep_alive: '45m',
    }),
    signal: AbortSignal.timeout(90_000),
  })
  if (!res.ok) throw new Error(`ollama-${res.status}`)
  const body = await res.json()
  const text = String(body?.message?.content || '').trim()
  if (!text) throw new Error('empty-local-reply')
  return { text, model, provider: 'local' }
}

/** Yield incremental assistant text from Ollama (token/stream chunks). */
export async function* streamChatLocal(messages, model = LOCAL_MODEL, extra = {}) {
  const res = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model,
      messages,
      stream: true,
      options: localOptions(model, extra),
      keep_alive: '45m',
    }),
    signal: AbortSignal.timeout(isSmallLocal(model) ? 120_000 : 300_000),
  })
  if (!res.ok || !res.body) throw new Error(`ollama-${res.status}`)
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buf = ''
  let full = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += decoder.decode(value, { stream: true })
    const lines = buf.split('\n')
    buf = lines.pop() || ''
    for (const line of lines) {
      const raw = line.trim()
      if (!raw) continue
      try {
        const row = JSON.parse(raw)
        const piece = String(row?.message?.content || '')
        if (piece) {
          full += piece
          yield { piece, full, model, provider: 'local', done: Boolean(row?.done) }
        }
        if (row?.done) return
      } catch {
        /* skip bad lines */
      }
    }
  }
  if (buf.trim()) {
    try {
      const row = JSON.parse(buf.trim())
      const piece = String(row?.message?.content || '')
      if (piece) {
        full += piece
        yield { piece, full, model, provider: 'local', done: true }
      }
    } catch {
      /* ignore */
    }
  }
  if (!full.trim()) throw new Error('empty-local-reply')
}

/** Load llama into RAM so the next user Ask AI starts sooner. */
export async function warmLocalModel(root = ROOT) {
  const status = await ollamaStatus()
  if (!status.ok) return { ok: false, reason: 'local-unavailable' }
  const settings = readLlmSettings(root)
  const name =
    status.models.includes(settings.localModel || LOCAL_MODEL)
      ? settings.localModel || LOCAL_MODEL
      : status.models[0] || LOCAL_MODEL
  const res = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model: name,
      messages: [{ role: 'user', content: 'hi' }],
      stream: false,
      options: { num_predict: 1 },
      keep_alive: '45m',
    }),
    signal: AbortSignal.timeout(90_000),
  })
  if (!res.ok) return { ok: false, reason: `ollama-${res.status}` }
  return { ok: true, model: name }
}

const CLOUD_ROUTES = {
  'claude-opus-5.5': { vendor: 'anthropic', api: 'anthropic', model: 'claude-opus-5-5' },
  'gpt-6-astra': { vendor: 'openai', api: 'openai', model: 'gpt-6' },
  'gemini-4-argon': { vendor: 'google', api: 'google', model: 'gemini-4' },
  'kimi-k3.1-pro': { vendor: 'moonshot', api: 'compat', model: 'kimi-k3.1', base: 'https://api.moonshot.ai/v1' },
  'grok-4.7': { vendor: 'xai', api: 'compat', model: 'grok-4-latest', base: 'https://api.x.ai/v1' },
  'qwen-3.8-max': { vendor: 'qwen', api: 'compat', model: 'qwen-max', base: 'https://dashscope.aliyuncs.com/compatible-mode/v1' },
  'deepseek-v4.1': { vendor: 'deepseek', api: 'compat', model: 'deepseek-chat', base: 'https://api.deepseek.com/v1' },
  'muse-spark-1.3': { vendor: 'meta', api: 'compat', model: 'llama-4-maverick', base: 'https://api.groq.com/openai/v1' },
  'glm-5.3': { vendor: 'zai', api: 'compat', model: 'glm-5', base: 'https://api.z.ai/api/paas/v4' },
  'mistral-large': { vendor: 'mistral', api: 'compat', model: 'mistral-large-latest', base: 'https://api.mistral.ai/v1' },
  'perplexity-sonar-pro': { vendor: 'perplexity', api: 'compat', model: 'sonar-pro', base: 'https://api.perplexity.ai' },
}

export function cloudRoute(model) {
  const id = String(model || '')
  if (CLOUD_ROUTES[id]) return CLOUD_ROUTES[id]
  if (id.startsWith('gpt-')) return { vendor: 'openai', api: 'openai', model: id }
  return null
}

export function userVendorKey(vendor, root = ROOT) {
  if (vendor === 'openai') return userOpenAiKey(root)
  const settings = readLlmSettings(root)
  const envName = `${String(vendor || '').toUpperCase()}_API_KEY`
  return String(settings.vendorKeys?.[vendor] || process.env[envName] || '').trim()
}

export function anyCloudKey(root = ROOT) {
  if (userOpenAiKey(root)) return true
  const keys = readLlmSettings(root).vendorKeys || {}
  return Object.values(keys).some((value) => String(value || '').trim())
}

const CLOUD_FETCH_MS = 90_000

function cloudFetchError(vendor, err) {
  const name = err instanceof Error ? err.name : ''
  if (name === 'TimeoutError' || name === 'AbortError') {
    if (vendor === 'openai') return new Error('openai-timeout')
    if (vendor === 'anthropic') return new Error('anthropic-timeout')
    if (vendor === 'google') return new Error('google-timeout')
    return new Error(`${vendor}-timeout`)
  }
  return err instanceof Error ? err : new Error(`${vendor}-network`)
}

export async function chatOpenAi(messages, model, key, base = 'https://api.openai.com/v1') {
  let res
  try {
    res = await fetch(`${String(base).replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model, messages, max_tokens: 4096 }),
      signal: AbortSignal.timeout(CLOUD_FETCH_MS),
    })
  } catch (err) {
    throw cloudFetchError('openai', err)
  }
  if (!res.ok) throw new Error(`openai-${res.status}`)
  const body = await res.json()
  const text = String(body?.choices?.[0]?.message?.content || '').trim()
  if (!text) throw new Error('empty-openai-reply')
  return { text, model, provider: 'openai' }
}

async function chatAnthropic(messages, model, key) {
  const system = messages.filter((row) => row.role === 'system').map((row) => row.content).join('\n')
  const rest = messages.filter((row) => row.role !== 'system').map((row) => ({
    role: row.role === 'assistant' ? 'assistant' : 'user',
    content: row.content,
  }))
  let res
  try {
    res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({ model, max_tokens: 4096, system: system || undefined, messages: rest }),
      signal: AbortSignal.timeout(CLOUD_FETCH_MS),
    })
  } catch (err) {
    throw cloudFetchError('anthropic', err)
  }
  if (!res.ok) throw new Error(`anthropic-${res.status}`)
  const body = await res.json()
  const text = (body?.content || []).map((part) => part.text || '').join('').trim()
  if (!text) throw new Error('empty-anthropic-reply')
  return { text, model, provider: 'anthropic' }
}

async function chatGemini(messages, model, key) {
  const contents = messages
    .filter((row) => row.role !== 'system')
    .map((row) => ({
      role: row.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: row.content }],
    }))
  const system = messages.filter((row) => row.role === 'system').map((row) => row.content).join('\n')
  let res
  try {
    res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          contents,
          systemInstruction: system ? { parts: [{ text: system }] } : undefined,
          generationConfig: { maxOutputTokens: 4096 },
        }),
        signal: AbortSignal.timeout(CLOUD_FETCH_MS),
      },
    )
  } catch (err) {
    throw cloudFetchError('google', err)
  }
  if (!res.ok) throw new Error(`google-${res.status}`)
  const body = await res.json()
  const text = String(body?.candidates?.[0]?.content?.parts?.[0]?.text || '').trim()
  if (!text) throw new Error('empty-google-reply')
  return { text, model, provider: 'google' }
}

async function chatCloud(messages, model, root = ROOT) {
  const route = cloudRoute(model)
  if (!route) throw new Error('no-llm')
  const key = userVendorKey(route.vendor, root)
  if (!key) throw new Error('no-llm')
  if (route.api === 'anthropic') return chatAnthropic(messages, route.model, key)
  if (route.api === 'google') return chatGemini(messages, route.model, key)
  return chatOpenAi(messages, route.model, key, route.base || 'https://api.openai.com/v1')
}

/** Office id → Ollama tag. Empty string means this id is not a local model. */
export function ollamaTag(model) {
  const id = String(model || '')
  if (cloudRoute(id) || id.startsWith('gpt-')) return ''
  if (id === 'os.neu-local' || id === LOCAL_MODEL) return LOCAL_MODEL
  if (id.startsWith('local:')) return id.slice('local:'.length)
  if (id.includes(':')) return id
  return ''
}

export function isSmallLocal(tag) {
  const name = String(tag || '')
  return name === LOCAL_MODEL || name.endsWith(':1b') || name.includes('1b')
}

/** 1B stays short. Larger local models may write more, still bounded so a CPU run can finish. */
export function numPredictFor(tag) {
  return isSmallLocal(tag) ? 120 : 1024
}

export function wantsLocalModel(model) {
  return Boolean(ollamaTag(model))
}

export const LLM_PULL_CATALOG = [
  { id: 'llama3.2:1b', bytes: 1_400_000_000 },
  { id: 'llama3.1:8b', bytes: 4_900_000_000 },
  { id: 'qwen2.5:7b', bytes: 4_700_000_000 },
  { id: 'gemma2:9b', bytes: 5_500_000_000 },
]

export function modelsDir() {
  if (process.env.OLLAMA_MODELS) return process.env.OLLAMA_MODELS
  return path.join(os.homedir(), '.ollama', 'models')
}

/** Free space on the disk that holds Ollama models (follows a symlink off the OS disk). */
export function diskFreeBytes(target = modelsDir()) {
  try {
    const stat = statfsSync(target)
    return Number(stat.bavail) * Number(stat.bsize)
  } catch {
    const stat = statfsSync('/')
    return Number(stat.bavail) * Number(stat.bsize)
  }
}

/** Refuse a pull that would fill the disk. 1GB is left free on purpose. */
export function pullRoom(id, free = diskFreeBytes()) {
  const card = LLM_PULL_CATALOG.find((row) => row.id === id)
  if (!card) return { ok: false, reason: 'unknown-model', id }
  const need = card.bytes + 1_000_000_000
  if (free < need) return { ok: false, reason: 'disk', id, free, need }
  return { ok: true, id, free, need }
}

export async function completeText({
  messages,
  model,
  root = ROOT,
} = {}) {
  const settings = readLlmSettings(root)
  const local = await ollamaStatus()
  const forceLocal = wantsLocalModel(model) || settings.provider === 'local'
  const forceCloud = Boolean(cloudRoute(model)) || settings.provider === 'openai'
  const useLocal =
    !forceCloud &&
    (forceLocal || settings.provider === 'auto') &&
    local.ok &&
    (local.hasDefault || local.models.length > 0)
  if (useLocal || (forceLocal && !forceCloud)) {
    if (!local.ok || (!local.hasDefault && local.models.length === 0)) {
      if (forceLocal && !userOpenAiKey(root)) throw new Error('local-unavailable')
    } else {
      const requested = ollamaTag(model)
      if (requested && !local.models.includes(requested) && !(requested === LOCAL_MODEL && local.hasDefault)) {
        throw new Error(`model-not-installed:${requested}`)
      }
      const localModel =
        requested && local.models.includes(requested)
          ? requested
          : settings.localModel && local.models.includes(settings.localModel)
            ? settings.localModel
            : local.models.includes(LOCAL_MODEL)
              ? LOCAL_MODEL
              : local.models[0] || LOCAL_MODEL
      try {
        return await chatLocal(messages, localModel)
      } catch (err) {
        if (err instanceof Error && err.message.startsWith('model-not-installed:')) throw err
        if (forceLocal && settings.provider === 'local') throw new Error('local-unavailable')
      }
    }
  }
  const cloudModel =
    cloudRoute(model) || String(model || '').startsWith('gpt-')
      ? model || 'gpt-4o-mini'
      : 'gpt-4o-mini'
  return await chatCloud(messages, cloudModel, root)
}

export async function llmReady(root = ROOT) {
  const local = await ollamaStatus()
  if (local.ok && (local.hasDefault || local.models.length > 0)) return { ok: true, via: 'local', ...local }
  if (anyCloudKey(root)) return { ok: true, via: 'openai', models: local.models, hasDefault: local.hasDefault }
  return { ok: false, via: 'none', ...local }
}
