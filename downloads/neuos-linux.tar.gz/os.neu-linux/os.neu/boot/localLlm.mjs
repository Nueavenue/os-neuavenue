/**
 * Public on-device AI (Ollama) plus an optional user-owned cloud key.
 * Never ships a shared OpenAI key. USB / plant copies must not include .env.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

export const LOCAL_MODEL = 'llama3.2:1b'
export const OLLAMA_HOST = (process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').replace(/\/$/, '')

export function llmSettingsPath(root = ROOT) {
  return path.join(root, 'data', 'user-llm.json')
}

export function defaultLlmSettings() {
  return { provider: 'auto', localModel: LOCAL_MODEL, openaiKey: '', pulled: false }
}

export function readLlmSettings(root = ROOT) {
  try {
    const raw = JSON.parse(readFileSync(llmSettingsPath(root), 'utf8'))
    return { ...defaultLlmSettings(), ...raw }
  } catch {
    return defaultLlmSettings()
  }
}

export function writeLlmSettings(partial, root = ROOT) {
  const next = { ...readLlmSettings(root), ...partial }
  mkdirSync(path.dirname(llmSettingsPath(root)), { recursive: true })
  writeFileSync(llmSettingsPath(root), JSON.stringify(next, null, 2))
  return next
}

export function userOpenAiKey(root = ROOT) {
  return String(readLlmSettings(root).openaiKey || process.env.OPENAI_API_KEY || '').trim()
}

export function ollamaInstallHint() {
  return {
    reason: 'ollama-missing',
    hint: '이 PC에 공개 AI 도구(Ollama)가 없습니다. 설치한 뒤 다시 받으면 됩니다.',
    command: 'curl -fsSL https://ollama.com/install.sh | sh',
  }
}

let pullJob = {
  percent: 0,
  stage: 'idle',
  error: '',
  model: LOCAL_MODEL,
}

export function llmPullStatus() {
  return { ...pullJob }
}

export async function ollamaStatus() {
  try {
    const res = await fetch(`${OLLAMA_HOST}/api/tags`, { signal: AbortSignal.timeout(2000) })
    if (!res.ok) return { ok: false, models: [], hasDefault: false }
    const body = await res.json()
    const models = (body?.models || []).map((row) => String(row?.name || '')).filter(Boolean)
    const hasDefault = models.some((name) => name === LOCAL_MODEL || name.startsWith('llama3.2'))
    return { ok: true, models, hasDefault }
  } catch {
    return { ok: false, models: [], hasDefault: false }
  }
}

function parsePullLine(line, job) {
  try {
    const row = JSON.parse(line)
    if (row.error) {
      job.error = String(row.error)
      job.stage = 'error'
      return
    }
    if (row.status) job.stage = String(row.status)
    const total = Number(row.total || 0)
    const completed = Number(row.completed || 0)
    if (total > 0) job.percent = Math.min(99, Math.round((completed / total) * 100))
    if (row.status === 'success') {
      job.percent = 100
      job.stage = 'done'
    }
  } catch {
    /* ignore non-json */
  }
}

export async function pullPublicModel(root = ROOT) {
  pullJob = { percent: 4, stage: 'check', error: '', model: LOCAL_MODEL }
  const status = await ollamaStatus()
  if (!status.ok) {
    pullJob.stage = 'error'
    pullJob.error = ollamaInstallHint().reason
    return { ok: false, ...ollamaInstallHint(), ...pullJob }
  }
  if (status.hasDefault) {
    pullJob.percent = 100
    pullJob.stage = 'done'
    writeLlmSettings({ provider: 'auto', localModel: LOCAL_MODEL, pulled: true }, root)
    return { ok: true, skipped: true, ...pullJob }
  }
  pullJob.stage = 'pull'
  pullJob.percent = 8
  const res = await fetch(`${OLLAMA_HOST}/api/pull`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: LOCAL_MODEL, stream: true }),
  })
  if (!res.ok || !res.body) {
    pullJob.stage = 'error'
    pullJob.error = `pull-${res.status}`
    return { ok: false, reason: pullJob.error, ...pullJob }
  }
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buf = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += decoder.decode(value, { stream: true })
    const lines = buf.split('\n')
    buf = lines.pop() || ''
    for (const line of lines) parsePullLine(line, pullJob)
    if (pullJob.stage === 'error') return { ok: false, reason: pullJob.error, ...pullJob }
  }
  if (buf.trim()) parsePullLine(buf.trim(), pullJob)
  if (pullJob.stage === 'error') return { ok: false, reason: pullJob.error, ...pullJob }
  pullJob.percent = 100
  pullJob.stage = 'done'
  writeLlmSettings({ provider: 'auto', localModel: LOCAL_MODEL, pulled: true }, root)
  return { ok: true, ...pullJob }
}

export async function chatLocal(messages, model = LOCAL_MODEL) {
  const res = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ model, messages, stream: false }),
  })
  if (!res.ok) throw new Error(`ollama-${res.status}`)
  const body = await res.json()
  const text = String(body?.message?.content || '').trim()
  if (!text) throw new Error('empty-local-reply')
  return { text, model, provider: 'local' }
}

export async function chatOpenAi(messages, model, key) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
    body: JSON.stringify({ model, messages }),
  })
  if (!res.ok) throw new Error(`openai-${res.status}`)
  const body = await res.json()
  const text = String(body?.choices?.[0]?.message?.content || '').trim()
  if (!text) throw new Error('empty-openai-reply')
  return { text, model, provider: 'openai' }
}

export function wantsLocalModel(model) {
  const id = String(model || '')
  return id === 'os.neu-local' || id.startsWith('local:') || id === LOCAL_MODEL
}

export async function completeText({
  messages,
  model,
  root = ROOT,
} = {}) {
  const settings = readLlmSettings(root)
  const local = await ollamaStatus()
  const forceLocal = wantsLocalModel(model)
  const forceCloud = String(model || '').startsWith('gpt-')
  const useLocal =
    (forceLocal || (!forceCloud && (settings.provider === 'local' || settings.provider === 'auto'))) &&
    local.ok &&
    (local.hasDefault || local.models.length > 0)
  if (useLocal) {
    const localModel = forceLocal || settings.provider === 'local' || settings.provider === 'auto'
      ? settings.localModel || local.models[0] || LOCAL_MODEL
      : LOCAL_MODEL
    try {
      return await chatLocal(messages, local.models.includes(localModel) ? localModel : local.models[0] || LOCAL_MODEL)
    } catch {
      if (forceLocal) throw new Error('local-unavailable')
    }
  }
  const key = userOpenAiKey(root)
  if (!key) throw new Error('no-llm')
  const cloudModel = forceCloud ? model : 'gpt-4o-mini'
  return await chatOpenAi(messages, cloudModel, key)
}

export async function llmReady(root = ROOT) {
  const local = await ollamaStatus()
  if (local.ok && (local.hasDefault || local.models.length > 0)) return { ok: true, via: 'local', ...local }
  if (userOpenAiKey(root)) return { ok: true, via: 'openai', models: local.models, hasDefault: local.hasDefault }
  return { ok: false, via: 'none', ...local }
}
