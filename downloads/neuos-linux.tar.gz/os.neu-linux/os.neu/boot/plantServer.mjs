import { createServer } from 'node:http'
import { mkdir, readFile } from 'node:fs/promises'
import { readFileSync, existsSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn, execFileSync } from 'node:child_process'
import { detectHost, searchCatalog } from './hostProfile.mjs'
import {
  llmPullStatus,
  ollamaInstallHint,
  pullPublicModel,
  writeLlmSettings,
} from './localLlm.mjs'
import {
  defaultPlantDir,
  ensureOsNeuFolder,
  launchScreen,
  listPlantDir,
  plantStatus,
  runPlant,
} from './plant.mjs'

const DIR = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(DIR, '..')
const HTML = readFileSync(path.join(DIR, 'plant-ui.html'), 'utf8')
const GUIDE = readFileSync(path.join(DIR, 'guide-ui.html'), 'utf8')
const GUIDE_MD = path.join(ROOT, 'docs/student-usb-guide.md')

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': '*',
  })
  res.end(JSON.stringify(body))
}

async function readBody(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  return Buffer.concat(chunks).toString('utf8')
}

export function startPlantServer(port = 4188) {
  const server = createServer((req, res) => {
    void (async () => {
      const url = new URL(req.url ?? '/', `http://127.0.0.1:${port}`)
      if (req.method === 'OPTIONS') {
        res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' })
        res.end()
        return
      }
      if (url.pathname === '/' && req.method === 'GET') {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
        res.end(HTML)
        return
      }
      if (url.pathname === '/guide' && req.method === 'GET') {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
        res.end(GUIDE)
        return
      }
      if (url.pathname === '/guide.md' && req.method === 'GET') {
        const body = existsSync(GUIDE_MD) ? await readFile(GUIDE_MD, 'utf8') : '# os.neu\n'
        res.writeHead(200, { 'content-type': 'text/markdown; charset=utf-8' })
        res.end(body)
        return
      }
      if (url.pathname === '/api/default' && req.method === 'GET') {
        json(res, 200, { ok: true, dest: defaultPlantDir() })
        return
      }
      if (url.pathname === '/api/list' && req.method === 'GET') {
        const dir = url.searchParams.get('dir') || defaultPlantDir()
        json(res, 200, await listPlantDir(dir))
        return
      }
      if (url.pathname === '/api/mkdir' && req.method === 'POST') {
        const payload = JSON.parse((await readBody(req)) || '{}')
        const dest = ensureOsNeuFolder(payload.dir || defaultPlantDir())
        await mkdir(dest, { recursive: true })
        json(res, 200, { ok: true, dest })
        return
      }
      if (url.pathname === '/api/start' && req.method === 'POST') {
        const payload = JSON.parse((await readBody(req)) || '{}')
        const dest = payload.dest || defaultPlantDir()
        void runPlant(ROOT, dest).catch(() => undefined)
        json(res, 200, { ok: true, dest })
        return
      }
      if (url.pathname === '/api/status' && req.method === 'GET') {
        json(res, 200, { ok: true, ...plantStatus() })
        return
      }
      if (url.pathname === '/api/catalog' && req.method === 'GET') {
        const q = url.searchParams.get('q') || ''
        json(res, 200, { ok: true, apps: searchCatalog(q, detectHost()) })
        return
      }
      if (url.pathname === '/api/llm/settings' && req.method === 'POST') {
        const payload = JSON.parse((await readBody(req)) || '{}')
        const dest = payload.dest || plantStatus().dest || defaultPlantDir()
        const next = writeLlmSettings(
          { openaiKey: String(payload.openaiKey || '').trim() },
          dest && existsSync(dest) ? dest : ROOT,
        )
        json(res, 200, { ok: true, dest, provider: next.provider, hasKey: Boolean(next.openaiKey) })
        return
      }
      if (url.pathname === '/api/llm/pull' && req.method === 'POST') {
        const payload = JSON.parse((await readBody(req)) || '{}')
        const dest = payload.dest || plantStatus().dest || ROOT
        void pullPublicModel(existsSync(dest) ? dest : ROOT).catch(() => undefined)
        json(res, 200, { ok: true, dest })
        return
      }
      if (url.pathname === '/api/llm/status' && req.method === 'GET') {
        const st = llmPullStatus()
        json(res, 200, {
          ok: true,
          ...st,
          ...(st.error === 'ollama-missing' ? ollamaInstallHint() : {}),
        })
        return
      }
      if (url.pathname === '/api/launch' && req.method === 'POST') {
        const payload = JSON.parse((await readBody(req)) || '{}')
        const dest = payload.dest || plantStatus().dest || defaultPlantDir()
        json(res, 200, launchScreen(dest, payload.go || 'lui'))
        return
      }
      json(res, 404, { ok: false })
    })().catch((err) => {
      json(res, 500, { ok: false, error: String(err?.message || err) })
    })
  })
  return new Promise((resolve, reject) => {
    server.once('error', (err) => {
      if (err && err.code === 'EADDRINUSE') {
        resolve({ server: null, port, url: `http://127.0.0.1:${port}/` })
        return
      }
      reject(err)
    })
    server.listen(port, '127.0.0.1', () => resolve({ server, port, url: `http://127.0.0.1:${port}/` }))
  })
}

export function openPlantDialog(url) {
  const display = process.env.DISPLAY || process.env.WAYLAND_DISPLAY
  if (!display) return false
  const bins = ['xdg-open', 'chromium', 'google-chrome', 'firefox']
  for (const bin of bins) {
    try {
      execFileSync('which', [bin], { stdio: 'ignore' })
    } catch {
      continue
    }
    try {
      const child = spawn(bin, [url], {
        detached: true,
        stdio: 'ignore',
        env: process.env,
      })
      child.unref()
      return true
    } catch {
      /* try next */
    }
  }
  return false
}
