#!/usr/bin/env bash
# Power-provider contract. Physical providers are intentionally dry-run until a
# separate DUT and Leader-approved PiKVM/WOL configuration exist.
set -euo pipefail

provider="${1:-}"
action="${2:-}"
case "$provider" in
  qemu|wol|pikvm) ;;
  *)
    echo "usage: bash boot/dut-power.sh <qemu|wol|pikvm> <power_on|boot_wait|capture|power_off>" >&2
    exit 2
    ;;
esac
case "$action" in
  power_on|boot_wait|capture|power_off) ;;
  *)
    echo "unsupported DUT action: $action" >&2
    exit 2
    ;;
esac

leader_host="${NEUOS_LEADER_HOST:-neuavenue}"
dut_host="${NEUOS_DUT_HOST:-unconfigured}"
if [[ "$provider" != "qemu" && "$dut_host" == "$leader_host" ]]; then
  echo "REFUSED: physical power provider cannot target the Leader workstation" >&2
  exit 3
fi

printf '{"provider":"%s","action":"%s","target":"%s","mode":"dry-run"}\n' \
  "$provider" "$action" "$dut_host"

if [[ "$provider" == "qemu" ]]; then
  case "$action" in
    power_on|boot_wait) echo "run: npm run boot:virt:gui" ;;
    capture) echo "evidence: \$NEUOS_VIRT_ROOT/runs/<run-id>/screen.ppm" ;;
    power_off) echo "QMP system_powerdown is owned by boot/try-qemu.sh" ;;
  esac
  exit 0
fi

echo "Physical execution is disabled until a separate DUT, wired management path,"
echo "and Leader-approved credentials are configured. No packet or API call was sent."

