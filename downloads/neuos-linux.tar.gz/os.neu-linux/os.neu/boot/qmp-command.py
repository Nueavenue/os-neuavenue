#!/usr/bin/env python3
"""Send one QMP command to an os.neu test VM."""

import argparse
import json
import socket


def receive_message(stream) -> dict:
    line = stream.readline()
    if not line:
        raise RuntimeError("QMP connection closed")
    return json.loads(line)


parser = argparse.ArgumentParser()
parser.add_argument("socket")
parser.add_argument("command")
parser.add_argument("--filename")
args = parser.parse_args()

with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
    client.connect(args.socket)
    stream = client.makefile("rwb", buffering=0)
    receive_message(stream)
    stream.write(b'{"execute":"qmp_capabilities"}\r\n')
    while "return" not in receive_message(stream):
        pass

    payload: dict[str, object] = {"execute": args.command}
    if args.filename:
        payload["arguments"] = {"filename": args.filename}
    stream.write(json.dumps(payload).encode() + b"\r\n")
    while True:
        response = receive_message(stream)
        if "return" in response or "error" in response:
            print(json.dumps(response))
            if "error" in response:
                raise SystemExit(1)
            break

