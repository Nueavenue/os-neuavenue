/**
 * Find the PC’s installed Linux home while booted from the os.neu USB.
 * Never treats the USB stick (NEUOS-ROOT / current /) as the plant target.
 */
import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, readdirSync } from 'node:fs'
import path from 'node:path'

export const HOST_MOUNT = '/mnt/osneu-host'
export const USB_LABELS = new Set(['NEUOS-ROOT', 'NEUOS-ESP'])

export function hostMountPoint() {
  return process.env.NEUOS_HOST_MOUNT || HOST_MOUNT
}

export function diskFromDevice(dev) {
  const base = String(dev || '')
    .trim()
    .replace(/^\/dev\//, '')
  if (!base) return ''
  if (/^(nvme|mmcblk|loop)/.test(base)) return base.replace(/p\d+$/, '')
  return base.replace(/\d+$/, '')
}

export function parseProcMounts(text) {
  const rows = []
  for (const line of String(text || '').split('\n')) {
    const parts = line.trim().split(/\s+/)
    if (parts.length < 3) continue
    rows.push({ device: parts[0], mount: parts[1], type: parts[2] })
  }
  return rows
}

export function rootDeviceFromMounts(rows) {
  const root = (rows || []).find((row) => row.mount === '/')
  return root?.device || ''
}

export function parseBlkid(text) {
  const out = []
  for (const line of String(text || '').split('\n')) {
    const trimmed = line.trim()
    if (!trimmed) continue
    const colon = trimmed.indexOf(':')
    if (colon < 1) continue
    const device = trimmed.slice(0, colon).trim()
    const rest = trimmed.slice(colon + 1)
    const meta = { device, type: '', label: '', uuid: '' }
    const type = rest.match(/\bTYPE="([^"]+)"/)
    const label = rest.match(/\bLABEL="([^"]+)"/)
    const uuid = rest.match(/\bUUID="([^"]+)"/)
    if (type) meta.type = type[1]
    if (label) meta.label = label[1]
    if (uuid) meta.uuid = uuid[1]
    out.push(meta)
  }
  return out
}

export function parsePasswd(text) {
  const users = []
  for (const line of String(text || '').split('\n')) {
    const parts = line.split(':')
    if (parts.length < 7) continue
    const [name, , uidStr, gidStr, , home, shell] = parts
    const uid = Number(uidStr)
    const gid = Number(gidStr)
    if (!name || Number.isNaN(uid)) continue
    users.push({ name, uid, gid, home, shell })
  }
  return users
}

export function isLoginUser(user) {
  if (!user || user.uid < 1000 || user.uid >= 65534) return false
  if (!user.home || !user.home.startsWith('/home/')) return false
  const shell = String(user.shell || '')
  if (/nologin|false|sync|halt$/i.test(shell)) return false
  return true
}

export function skipDiskReason({ disk, removable, labels, rootDisk }) {
  if (!disk) return 'empty'
  if (rootDisk && disk === rootDisk) return 'current-root'
  if (String(removable) === '1') return 'removable'
  const set = new Set(labels || [])
  for (const label of USB_LABELS) {
    if (set.has(label)) return 'neuos-usb'
  }
  return ''
}

export function pickHostUser(users, homeNames, preferName) {
  const login = (users || []).filter(isLoginUser)
  const homes = new Set(homeNames || [])
  const present = login.filter((user) => homes.has(path.basename(user.home)) || homes.has(user.name))
  const pool = present.length ? present : login
  if (preferName) {
    const hit = pool.find((user) => user.name === preferName)
    if (hit) return hit
  }
  return pool[0] || null
}

export function parseFstabHomeSource(fstab) {
  for (const line of String(fstab || '').split('\n')) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const parts = trimmed.split(/\s+/)
    if (parts.length >= 2 && parts[1] === '/home') return parts[0]
  }
  return ''
}

function readText(file) {
  try {
    return readFileSync(file, 'utf8')
  } catch {
    return ''
  }
}

function run(bin, args) {
  try {
    return execFileSync(bin, args, { encoding: 'utf8', timeout: 12_000, stdio: ['ignore', 'pipe', 'pipe'] })
  } catch (err) {
    return String(err.stdout || '')
  }
}

function readRemovable(disk) {
  return readText(`/sys/block/${disk}/removable`).trim() || '0'
}

function listSysDisks() {
  try {
    return readdirSync('/sys/block').filter((name) => !/^(loop|ram|sr|fd|zram|dm-)/.test(name))
  } catch {
    return []
  }
}

function linuxFs(type) {
  return /^(ext[234]|xfs|btrfs|f2fs)$/.test(String(type || ''))
}

function homeNamesUnder(root) {
  const dir = path.join(root, 'home')
  try {
    return readdirSync(dir, { withFileTypes: true })
      .filter((ent) => ent.isDirectory() && ent.name !== 'lost+found')
      .map((ent) => ent.name)
  } catch {
    return []
  }
}

function ensureMount(device, mountAt) {
  mkdirSync(mountAt, { recursive: true })
  const mounts = parseProcMounts(readText('/proc/mounts'))
  const already = mounts.find((row) => row.mount === mountAt)
  if (already) {
    if (already.device === device || path.resolve(already.device) === path.resolve(device)) return true
    try {
      execFileSync('umount', [mountAt], { timeout: 8000, stdio: 'ignore' })
    } catch {
      /* still try mount */
    }
  }
  try {
    execFileSync('mount', ['-o', 'rw', device, mountAt], { timeout: 15_000, stdio: 'ignore' })
    return true
  } catch {
    try {
      execFileSync('mount', ['-t', 'ext4', '-o', 'rw', device, mountAt], { timeout: 15_000, stdio: 'ignore' })
      return true
    } catch {
      return false
    }
  }
}

function resolveFstabDevice(spec, records) {
  const raw = String(spec || '').trim()
  if (!raw) return ''
  if (raw.startsWith('/dev/')) return raw
  const uuid = raw.match(/^UUID=(.+)$/i)
  if (uuid) {
    const hit = records.find((row) => row.uuid === uuid[1])
    return hit?.device || `/dev/disk/by-uuid/${uuid[1]}`
  }
  const label = raw.match(/^LABEL=(.+)$/i)
  if (label) {
    const hit = records.find((row) => row.label === label[1])
    return hit?.device || `/dev/disk/by-label/${label[1]}`
  }
  return ''
}

function scoreProbe(root) {
  let score = 0
  const homes = homeNamesUnder(root)
  score += homes.length * 10
  if (existsSync(path.join(root, 'etc/passwd'))) score += 5
  for (const name of homes) {
    if (existsSync(path.join(root, 'home', name, 'neuOS'))) score += 50
    if (existsSync(path.join(root, 'home', name, 'os.neu'))) score += 20
    if (existsSync(path.join(root, 'home', name, '.bashrc'))) score += 2
  }
  return { score, homes }
}

/**
 * Mount the installed Linux root (not the USB) and pick ~/os.neu for that user.
 */
export function mountHostLinux() {
  const mountAt = hostMountPoint()
  const mounts = parseProcMounts(readText('/proc/mounts'))
  const rootDev = rootDeviceFromMounts(mounts)
  const rootDisk = diskFromDevice(rootDev)
  const records = parseBlkid(run('blkid', []))
  const disks = listSysDisks()
  const candidates = []

  for (const rec of records) {
    const disk = diskFromDevice(rec.device)
    const labels = records.filter((row) => diskFromDevice(row.device) === disk).map((row) => row.label).filter(Boolean)
    const reason = skipDiskReason({
      disk,
      removable: disks.includes(disk) ? readRemovable(disk) : '0',
      labels,
      rootDisk,
    })
    if (reason) continue
    if (!linuxFs(rec.type)) continue
    candidates.push(rec)
  }

  if (!candidates.length) {
    for (const disk of disks) {
      const reason = skipDiskReason({
        disk,
        removable: readRemovable(disk),
        labels: records.filter((row) => diskFromDevice(row.device) === disk).map((row) => row.label),
        rootDisk,
      })
      if (reason) continue
      const fromBlkid = records.filter((row) => diskFromDevice(row.device) === disk)
      if (fromBlkid.length) {
        for (const rec of fromBlkid) {
          if (linuxFs(rec.type) || !rec.type) candidates.push(rec)
        }
        continue
      }
      try {
        const parts = readdirSync(`/sys/block/${disk}`)
        for (const name of parts) {
          if (name === disk || !name.startsWith(disk)) continue
          if (!/p?\d+$/.test(name.slice(disk.length))) continue
          candidates.push({ device: `/dev/${name}`, type: 'ext4', label: '', uuid: '' })
        }
      } catch {
        /* no sysfs */
      }
    }
  }

  let best = null
  for (const rec of candidates) {
    if (!ensureMount(rec.device, mountAt)) continue
    const probed = scoreProbe(mountAt)
    if (!best || probed.score > best.score) {
      best = { ...rec, ...probed }
    }
  }

  if (!best || best.score < 5) {
    return {
      ok: false,
      error: 'no-host-linux',
      hint: 'No Linux home on this PC. USB install needs an existing /home on the internal disk.',
    }
  }

  if (!ensureMount(best.device, mountAt)) {
    return { ok: false, error: 'mount-failed', hint: `Could not mount ${best.device}` }
  }

  const fstabHome = parseFstabHomeSource(readText(path.join(mountAt, 'etc/fstab')))
  if (fstabHome && homeNamesUnder(mountAt).length === 0) {
    const homeDev = resolveFstabDevice(fstabHome, records)
    if (homeDev) {
      mkdirSync(path.join(mountAt, 'home'), { recursive: true })
      try {
        execFileSync('mount', ['-o', 'rw', homeDev, path.join(mountAt, 'home')], { timeout: 15_000, stdio: 'ignore' })
      } catch {
        /* home stays on root partition */
      }
    }
  }

  const users = parsePasswd(readText(path.join(mountAt, 'etc/passwd')))
  const homes = homeNamesUnder(mountAt)
  const user = pickHostUser(users, homes)
  if (!user) {
    return { ok: false, error: 'no-login-user', hint: 'Mounted Linux but found no /home user.' }
  }

  const homeRel = user.home.startsWith('/home/') ? user.home : `/home/${user.name}`
  const homeMount = path.join(mountAt, homeRel.replace(/^\//, ''))
  if (!existsSync(homeMount)) {
    return { ok: false, error: 'no-home-dir', hint: `No ${homeRel} on the internal disk.` }
  }

  return {
    ok: true,
    mount: mountAt,
    device: best.device,
    user: user.name,
    uid: user.uid,
    gid: user.gid,
    homeRel,
    homeMount,
    osNeuRel: path.posix.join(homeRel, 'os.neu'),
    osNeuPath: path.join(homeMount, 'os.neu'),
    neuOSPath: path.join(homeMount, 'neuOS'),
  }
}

export async function resolvePlantTarget() {
  if (process.env.NEUOS_JEOS === '1') {
    const host = mountHostLinux()
    if (!host.ok) return { dest: '', host: null, error: host.hint || host.error }
    return { dest: host.osNeuPath, host, error: '' }
  }
  const home = process.env.HOME || '/root'
  return { dest: path.join(home, 'os.neu'), host: null, error: '' }
}

export function destIsUsbStick(dest) {
  if (process.env.NEUOS_JEOS !== '1') return false
  const resolved = path.resolve(String(dest || ''))
  const mountAt = hostMountPoint()
  if (resolved.startsWith(mountAt + path.sep) || resolved === mountAt) return false
  if (resolved === '/' || resolved === '/os.neu' || resolved.startsWith('/os.neu/')) return true
  if (resolved.startsWith('/opt/neuos')) return true
  if (resolved === '/root/os.neu' || resolved.startsWith('/root/os.neu/')) return true
  return false
}
