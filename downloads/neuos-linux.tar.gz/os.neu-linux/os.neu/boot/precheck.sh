#!/usr/bin/env bash
# Pre-check for os.neu USB / QEMU path. Does not flash firmware.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
need=0
VIRT_ROOT="${NEUOS_VIRT_ROOT:-/run/media/${USER:-billy-lee}/Data-02-4T/osneu-virt}"
echo "== os.neu pre-check =="
check() {
  local kind="$1"
  local name="$2"
  shift 2
  if "$@" >/dev/null 2>&1; then
    echo "OK   $name"
  else
    echo "MISS $name ($kind)"
    if [[ "$kind" == "need" ]]; then
      need=1
    fi
  fi
}

check need node node -v
check need npm npm -v
check need linux uname
check need qemu-system-x86_64 command -v qemu-system-x86_64
check need qemu-img command -v qemu-img
check need grub-mkrescue command -v grub-mkrescue
check need xorriso command -v xorriso
check need mtools command -v mcopy
check opt xdotool command -v xdotool
check need cpio command -v cpio
check need parted command -v parted

if [[ -c /dev/kvm && -r /dev/kvm && -w /dev/kvm ]]; then
  echo "OK   /dev/kvm acceleration"
else
  echo "MISS /dev/kvm acceleration (need)"
  need=1
fi

OVMF_CODE=""
for cand in \
  /usr/share/OVMF/OVMF_CODE_4M.fd \
  /usr/share/OVMF/OVMF_CODE.fd \
  /usr/share/ovmf/OVMF.fd; do
  if [[ -r "$cand" ]]; then
    OVMF_CODE="$cand"
    break
  fi
done
if [[ -n "$OVMF_CODE" ]]; then
  echo "OK   OVMF firmware $OVMF_CODE"
else
  echo "MISS OVMF firmware (need)"
  need=1
fi

if [[ -d "$VIRT_ROOT" || ( -d "$(dirname "$VIRT_ROOT")" && -w "$(dirname "$VIRT_ROOT")" ) ]]; then
  avail_kb="$(df -Pk "$(dirname "$VIRT_ROOT")" 2>/dev/null | awk 'NR==2 {print $4}')"
  if [[ "${avail_kb:-0}" -ge 5242880 ]]; then
    echo "OK   virtual evidence storage $VIRT_ROOT ($((avail_kb / 1024 / 1024)) GiB free)"
  else
    echo "MISS virtual evidence storage needs at least 5 GiB at $VIRT_ROOT"
    need=1
  fi
else
  echo "MISS virtual evidence parent is not writable: $(dirname "$VIRT_ROOT")"
  need=1
fi

echo
echo "UEFI chip flash: NOT available without OEM/Intel/AMD signing keys."
echo "os.neu USB image: possible. Custom kernel from scratch: not this quarter."
echo "Thin client: possible once network drivers exist in the micro image."
echo
if node "$ROOT/boot/kernel.mjs" --once hardware >/tmp/neuos-kernel-try.txt; then
  echo "OK   userspace kernel.js loop"
else
  echo "MISS userspace kernel.js loop"
  need=1
fi

if [[ -f data/boot-health.json ]]; then
  echo "OK   boot monitor file data/boot-health.json"
else
  echo "MISS boot monitor"
  need=1
fi

exit "$need"
