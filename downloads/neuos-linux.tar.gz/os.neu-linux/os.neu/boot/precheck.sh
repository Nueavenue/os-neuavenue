#!/usr/bin/env bash
# Pre-check for os.neu USB / QEMU path. Does not flash firmware.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
need=0
echo "== os.neu pre-check =="
check() {
  local kind="$1"
  local name="$2"
  shift 2
  if "$@" >/dev/null 2>&1; then
    echo "OK   $name"
  else
    echo "MISS $name ($kind)"
    if [[ "$kind" == "need" ]]; then
      need=1
    fi
  fi
}

check need node node -v
check need npm npm -v
check need linux uname
check opt qemu-system-x86_64 command -v qemu-system-x86_64
check opt grub-mkrescue command -v grub-mkrescue
check opt xorriso command -v xorriso
check opt mtools command -v mtools
check opt xdotool command -v xdotool
check opt cpio command -v cpio
check opt parted command -v parted

echo
echo "UEFI chip flash: NOT available without OEM/Intel/AMD signing keys."
echo "os.neu USB image: possible. Custom kernel from scratch: not this quarter."
echo "Thin client: possible once network drivers exist in the micro image."
echo
if node "$ROOT/boot/kernel.mjs" --once hardware >/tmp/neuos-kernel-try.txt; then
  echo "OK   userspace kernel.js loop"
else
  echo "MISS userspace kernel.js loop"
  need=1
fi

if [[ -f data/boot-health.json ]]; then
  echo "OK   boot monitor file data/boot-health.json"
else
  echo "MISS boot monitor"
  need=1
fi

exit "$need"
