/**
 * Copy this tree into ~/os.neu (or a chosen folder). Never touches block devices.
 */
import { spawn, spawnSync } from 'node:child_process'
import { copyFile, mkdir, readdir, symlink, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { destIsUsbStick } from './hostVolume.mjs'

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'coverage', '.cursor'])
const SKIP_FILES = new Set([
  '.env',
  'accounts.json',
  'analytics.json',
  'feedback.json',
  'user-llm.json',
  'boot-health.json',
  'user-monitor.json',
])

export function shouldSkip(name) {
  return SKIP_DIRS.has(name) || SKIP_FILES.has(name) || name.startsWith('.env.')
}

export function isPlantCommand(input) {
  const t = String(input || '').trim()
  return /^install\s+os\.neu\s*$/i.test(t) || /^install\s+osneu\s*$/i.test(t)
}

export function isUninstallCommand(input) {
  const t = String(input || '').trim()
  return /^(uninstall|remove|delete)\s+os\.neu\s*$/i.test(t) || /^os\.neu\s+(삭제|제거|uninstall|remove|delete)\s*$/i.test(t)
}

export function defaultPlantDir() {
  return path.join(os.homedir() || '/root', 'os.neu')
}

export function assertSafePlantDest(dest) {
  const resolved = path.resolve(String(dest || ''))
  if (!resolved || resolved === '/' || resolved === '/home' || resolved === '/root') {
    throw new Error('unsafe-dest')
  }
  if (
    resolved.startsWith('/dev') ||
    resolved.startsWith('/sys') ||
    resolved.startsWith('/proc') ||
    resolved === '/boot' ||
    resolved.startsWith('/boot/')
  ) {
    throw new Error('unsafe-dest')
  }
  if (/^\/dev\//.test(resolved)) throw new Error('unsafe-dest')
  return resolved
}

export function ensureOsNeuFolder(dest) {
  const resolved = path.resolve(String(dest || defaultPlantDir()))
  const base = path.basename(resolved)
  const folder = base === 'os.neu' ? resolved : path.join(resolved, 'os.neu')
  return assertSafePlantDest(folder)
}

let job = {
  percent: 0,
  stage: 'idle',
  dest: '',
  error: '',
  files: 0,
  copied: 0,
}

export function plantStatus() {
  return { ...job }
}

async function walkFiles(dir, acc = []) {
  let entries = []
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return acc
  }
  for (const ent of entries) {
    if (shouldSkip(ent.name)) continue
    const full = path.join(dir, ent.name)
    if (ent.isDirectory()) await walkFiles(full, acc)
    else acc.push(full)
  }
  return acc
}

export async function listPlantDir(dir) {
  const resolved = path.resolve(String(dir || defaultPlantDir()))
  if (resolved.startsWith('/dev') || resolved.startsWith('/sys') || resolved.startsWith('/proc')) {
    throw new Error('unsafe-dest')
  }
  let entries = []
  try {
    entries = await readdir(resolved, { withFileTypes: true })
  } catch {
    return { ok: true, dir: resolved, exists: false, entries: [] }
  }
  return {
    ok: true,
    dir: resolved,
    exists: true,
    entries: entries
      .filter((ent) => !shouldSkip(ent.name) && !ent.name.startsWith('.'))
      .slice(0, 80)
      .map((ent) => ({
        name: ent.name,
        dir: ent.isDirectory(),
        path: path.join(resolved, ent.name),
      })),
  }
}

async function plantCopy(src, dest, onTick) {
  const safe = assertSafePlantDest(dest)
  await mkdir(safe, { recursive: true })
  const files = await walkFiles(src)
  job = { percent: 3, stage: 'copy', dest: safe, error: '', files: files.length, copied: 0 }
  onTick?.(job)
  for (const file of files) {
    const rel = path.relative(src, file)
    const target = path.join(safe, rel)
    await mkdir(path.dirname(target), { recursive: true })
    await copyFile(file, target)
    job.copied += 1
    job.percent = Math.min(68, 3 + Math.round((job.copied / Math.max(1, files.length)) * 65))
    if (job.copied % 12 === 0) onTick?.(job)
  }
  // Older planted copies may still have scripts/kiosk.sh
  for (const script of [
    'scripts/screen.sh',
    'scripts/kiosk.sh',
    'scripts/open-neuos.sh',
    'scripts/install-autostart.sh',
    'scripts/install-linux.sh',
    'scripts/usb-screen.sh',
  ]) {
    const full = path.join(safe, script)
    if (existsSync(full)) {
      try {
        spawn('chmod', ['+x', full], { stdio: 'ignore' })
      } catch {
        /* ignore */
      }
    }
  }
  return safe
}

async function linkHostNodeModules(dest, host) {
  if (!host?.homeMount) return false
  const plantedNm = path.join(dest, 'node_modules')
  if (existsSync(plantedNm)) return true
  const neu = path.join(host.homeMount, 'neuOS', 'node_modules')
  if (!existsSync(neu)) return false
  try {
    await symlink('../neuOS/node_modules', plantedNm)
    return true
  } catch {
    return false
  }
}

async function plantNpm(dest, onTick) {
  job.stage = 'npm'
  job.percent = 72
  onTick?.(job)
  if (existsSync(path.join(dest, 'node_modules', 'electron'))) {
    job.percent = 92
    job.stage = 'npm-ok'
    onTick?.(job)
    return true
  }
  return new Promise((resolve) => {
    const child = spawn('npm', ['install'], {
      cwd: dest,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    child.on('close', (code) => {
      job.percent = code === 0 ? 92 : 84
      job.stage = code === 0 ? 'npm-ok' : 'npm-skip'
      onTick?.(job)
      resolve(code === 0)
    })
    child.on('error', () => {
      job.stage = 'npm-skip'
      job.percent = 84
      onTick?.(job)
      resolve(false)
    })
  })
}

export function linuxDesktopFile({ execRoot, icon, autostart = false }) {
  const lines = [
    '[Desktop Entry]',
    'Type=Application',
    'Name=os.neu',
    'Comment=os.neu screen — independent browser',
    `Exec=bash ${execRoot}/scripts/open-neuos.sh`,
    `Path=${execRoot}`,
    `Icon=${icon || 'os.neu'}`,
    'Terminal=false',
    'Categories=Network;WebBrowser;',
    'StartupWMClass=neuos',
    'StartupNotify=true',
  ]
  if (autostart) lines.push('X-GNOME-Autostart-enabled=true')
  return `${lines.join('\n')}\n`
}

export function linuxUserService({ execRoot }) {
  return `[Unit]
Description=os.neu screen
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
WorkingDirectory=${execRoot}
ExecStart=/bin/bash ${execRoot}/scripts/open-neuos.sh
Restart=on-failure
RestartSec=3
Environment=DISPLAY=:0
Environment=NEUOS_SCREEN=1

[Install]
WantedBy=graphical-session.target
`
}

export async function installLinuxIcons(srcTree, home) {
  const sizes = [48, 64, 128, 256, 512]
  for (const size of sizes) {
    const from = path.join(srcTree, 'public/brand/hicolor', `${size}x${size}`, 'apps/os.neu.png')
    if (!existsSync(from)) continue
    const toDir = path.join(home, '.local/share/icons/hicolor', `${size}x${size}`, 'apps')
    await mkdir(toDir, { recursive: true })
    await copyFile(from, path.join(toDir, 'os.neu.png'))
  }
}

export async function writePlantAutostart(dest, opts = {}) {
  const home = opts.homeDir || os.homedir()
  const execRoot = opts.execRoot || dest
  const icon = 'os.neu'
  const launcher = linuxDesktopFile({ execRoot, icon, autostart: false })
  const autoBody = linuxDesktopFile({ execRoot, icon, autostart: true })
  const unit = linuxUserService({ execRoot })
  await installLinuxIcons(dest, home)

  const autoDir = path.join(home, '.config/autostart')
  const appDir = path.join(home, '.local/share/applications')
  const unitDir = path.join(home, '.config/systemd/user')
  await mkdir(autoDir, { recursive: true })
  await mkdir(appDir, { recursive: true })
  await mkdir(unitDir, { recursive: true })
  await writeFile(path.join(autoDir, 'neuos.desktop'), autoBody)
  await writeFile(path.join(appDir, 'neuos.desktop'), launcher)
  await writeFile(path.join(unitDir, 'neuos.service'), unit)

  const deskDir = path.join(home, 'Desktop')
  if (existsSync(deskDir)) {
    const deskFile = path.join(deskDir, 'neuos.desktop')
    await writeFile(deskFile, launcher)
    try {
      spawn('chmod', ['+x', deskFile], { stdio: 'ignore' })
    } catch {
      /* ignore */
    }
  }
}

export async function runPlant(src, dest, onTick, opts = {}) {
  job = { percent: 1, stage: 'start', dest: '', error: '', files: 0, copied: 0 }
  onTick?.(job)
  try {
    const folder = ensureOsNeuFolder(dest)
    if (destIsUsbStick(folder)) {
      throw new Error('usb-stick-not-host')
    }
    if (path.resolve(src) === path.resolve(folder)) {
      job.dest = folder
      job.percent = 100
      job.stage = 'done'
      onTick?.(job)
      return job
    }
    const safe = await plantCopy(src, folder, onTick)
    job.dest = safe
    await linkHostNodeModules(safe, opts.host)
    await plantNpm(safe, onTick)
    try {
      await writePlantAutostart(safe, {
        homeDir: opts.autostartHome,
        execRoot: opts.execRoot,
      })
    } catch {
      /* USB console may lack a desktop session */
    }
    job.percent = 100
    job.stage = 'done'
    onTick?.(job)
    return job
  } catch (err) {
    job.error = String(err?.message || err)
    job.stage = 'error'
    onTick?.(job)
    throw err
  }
}

export function canLaunchGraphicalScreen() {
  if (process.env.NEUOS_JEOS === '1') return false
  return Boolean(process.env.DISPLAY || process.env.WAYLAND_DISPLAY)
}

export function usbScreenScript() {
  return path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts/usb-screen.sh')
}

export function launchUsbHostScreen(host, dest, go = 'lui') {
  const script = usbScreenScript()
  if (!host?.mount || !host?.user) {
    return { ok: false, reason: 'no-host', dest, go }
  }
  if (!existsSync(script)) {
    return { ok: false, reason: 'no-usb-screen-script', dest, go }
  }
  const env = {
    ...process.env,
    NEUOS_HOST_ROOT: host.mount,
    NEUOS_HOST_USER: host.user,
    NEUOS_HOST_DEST: host.osNeuRel || dest,
    NEUOS_GO: go,
  }
  if (process.env.NEUOS_USB_SCREEN_DRY === '1') {
    return { ok: true, dest, go, via: 'usb-host', dry: true }
  }
  const result = spawnSync('sh', [script], { env, stdio: 'inherit', encoding: 'utf8' })
  return {
    ok: result.status === 0,
    dest,
    go,
    via: 'usb-host',
    status: result.status,
    reason: result.status === 0 ? '' : 'usb-screen-failed',
  }
}

export function launchScreen(dest, go = 'lui', opts = {}) {
  if (process.env.NEUOS_JEOS === '1' && opts.host) {
    return launchUsbHostScreen(opts.host, dest, go)
  }
  if (!canLaunchGraphicalScreen()) {
    return { ok: false, reason: 'no-desktop', dest, go }
  }
  const named = [
    path.join(dest, 'scripts/screen.sh'),
    path.join(dest, 'scripts/kiosk.sh'),
  ]
  const fallback = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts/screen.sh')
  const script = named.find((full) => existsSync(full)) || fallback
  const cwd = existsSync(path.join(dest, 'scripts/screen.sh')) || existsSync(path.join(dest, 'scripts/kiosk.sh'))
    ? dest
    : path.dirname(path.dirname(script))
  const child = spawn('bash', [script], {
    cwd,
    env: { ...process.env, NEUOS_GO: go, HOME: os.homedir() },
    detached: true,
    stdio: 'ignore',
  })
  child.unref()
  return { ok: true, dest: cwd, go }
}
