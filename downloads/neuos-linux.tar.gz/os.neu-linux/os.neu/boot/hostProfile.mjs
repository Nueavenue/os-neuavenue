/**
 * Detect the machine neuOS is sitting on, and map “install Firefox”
 * to the right package command. Used by the os.neu prompt and the LUI.
 */
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import os from 'node:os'

export const CATALOG = {
  chrome: {
    apt: 'google-chrome-stable',
    dnf: 'google-chrome-stable',
    pacman: 'google-chrome',
    zypper: 'google-chrome-stable',
    winget: 'Google.Chrome',
    brew: 'google-chrome',
    url: 'https://www.google.com/chrome/',
  },
  firefox: {
    apt: 'firefox',
    dnf: 'firefox',
    pacman: 'firefox',
    zypper: 'firefox',
    winget: 'Mozilla.Firefox',
    brew: 'firefox',
    url: 'https://www.mozilla.org/firefox/download/',
  },
  vscode: {
    apt: 'code',
    dnf: 'code',
    pacman: 'code',
    zypper: 'code',
    winget: 'Microsoft.VisualStudioCode',
    brew: 'visual-studio-code',
    url: 'https://code.visualstudio.com/Download',
  },
  vlc: {
    apt: 'vlc',
    dnf: 'vlc',
    pacman: 'vlc',
    zypper: 'vlc',
    winget: 'VideoLAN.VLC',
    brew: 'vlc',
    url: 'https://www.videolan.org/vlc/',
  },
  node: {
    apt: 'nodejs',
    dnf: 'nodejs',
    pacman: 'nodejs',
    zypper: 'nodejs',
    winget: 'OpenJS.NodeJS.LTS',
    brew: 'node',
    url: 'https://nodejs.org/en/download',
  },
}

export function parseOsRelease(text) {
  const grab = (key) => {
    const line = text.split('\n').find((row) => row.startsWith(`${key}=`))
    if (!line) return ''
    return line.slice(key.length + 1).replace(/^"|"$/g, '').trim()
  }
  return { id: grab('ID').toLowerCase(), version: grab('VERSION_ID'), name: grab('PRETTY_NAME') }
}

export function pkgForDistro(id) {
  if (['ubuntu', 'debian', 'linuxmint', 'pop', 'elementary', 'raspbian'].includes(id)) return 'apt'
  if (['fedora', 'rhel', 'centos', 'rocky', 'almalinux'].includes(id)) return 'dnf'
  if (['arch', 'manjaro', 'endeavouros'].includes(id)) return 'pacman'
  if (id.includes('suse')) return 'zypper'
  return 'unknown'
}

export function detectHost() {
  const family = process.platform
  let distro = family
  let version = os.release()
  let pretty = family
  let pkg = 'unknown'
  if (family === 'linux' && existsSync('/etc/os-release')) {
    const parsed = parseOsRelease(readFileSync('/etc/os-release', 'utf8'))
    distro = parsed.id || distro
    version = parsed.version || version
    pretty = parsed.name || distro
    pkg = pkgForDistro(distro)
  } else if (family === 'win32') {
    distro = 'windows'
    pretty = 'Windows'
    pkg = 'winget'
  } else if (family === 'darwin') {
    distro = 'macos'
    pretty = 'macOS'
    pkg = 'brew'
  }
  return {
    family,
    distro,
    version,
    pretty,
    pkg,
    arch: os.arch(),
    hostname: os.hostname(),
    cores: os.cpus().length,
    memGb: Math.round(os.totalmem() / 1024 ** 3),
    platform: `${pretty} · ${os.arch()}`,
  }
}

export function searchCatalog(query, host = detectHost()) {
  const q = String(query || '')
    .trim()
    .toLowerCase()
  const aliases = [
    ['chrome', '크롬', 'chrome'],
    ['firefox', '파이어', 'firefox'],
    ['vscode', '코드', 'vscode', 'vs code'],
    ['vlc', '플레이어', 'vlc'],
    ['node', '노드', 'nodejs', 'node.js'],
  ]
  const keys = Object.keys(CATALOG)
  const matched = keys.filter((key) => {
    if (!q) return true
    if (key.includes(q)) return true
    const row = CATALOG[key]
    if (String(row.apt || '').includes(q)) return true
    const alias = aliases.find((row) => row[0] === key)
    return Boolean(alias && alias.some((word) => word.includes(q) || q.includes(word)))
  })
  const list = matched.length ? matched : keys
  return list.map((app) => {
    const plan = planApp(host, { kind: 'install', app, raw: `install ${app}` })
    return {
      app,
      command: plan.command,
      url: plan.url,
      package: plan.package,
      host: plan.host.pretty,
    }
  })
}

export function parseAppIntent(raw) {
  const t = String(raw || '').trim()
  if (!t) return null
  if (/^install\s+os\.neu\s*$/i.test(t) || /^install\s+osneu\s*$/i.test(t)) return null
  if (/^(uninstall|remove|delete)\s+os\.neu\s*$/i.test(t) || /^os\.neu\s+(삭제|제거|uninstall|remove|delete)\s*$/i.test(t)) {
    return null
  }
  const remove = /지우|삭제|uninstall|remove\b|purge|지워/i.test(t)
  const install = /설치|깔아|깔게|install\b|download|다운받|받아|get\s/i.test(t)
  if (!install && !remove && !/^(apt|dnf|pacman|winget|brew)\s/i.test(t)) return null
  let app = 'app'
  for (const key of Object.keys(CATALOG)) {
    const rx = new RegExp(key, 'i')
    if (rx.test(t)) app = key
  }
  if (app === 'app') {
    if (/크롬/i.test(t)) app = 'chrome'
    else if (/파이어/i.test(t)) app = 'firefox'
    else if (/코드|vscode/i.test(t)) app = 'vscode'
    else if (/vlc|플레이어/i.test(t)) app = 'vlc'
    else if (/노드/i.test(t)) app = 'node'
    else {
      const m = t.match(/(?:install|설치|깔)\s+([a-z0-9._-]+)/i)
      if (m) app = m[1].toLowerCase()
    }
  }
  return { kind: remove ? 'remove' : 'install', app, raw: t }
}

export function planApp(host, intent) {
  const row = CATALOG[intent.app]
  const pkgName = row ? row[host.pkg] || intent.app : intent.app
  let command = `# ${intent.app} on ${host.pretty}`
  if (intent.kind === 'remove') {
    if (host.pkg === 'apt') command = `sudo apt remove ${pkgName}`
    else if (host.pkg === 'dnf') command = `sudo dnf remove ${pkgName}`
    else if (host.pkg === 'pacman') command = `sudo pacman -R ${pkgName}`
    else if (host.pkg === 'zypper') command = `sudo zypper rm ${pkgName}`
    else if (host.pkg === 'winget') command = `winget uninstall ${pkgName}`
    else if (host.pkg === 'brew') command = `brew uninstall ${pkgName}`
  } else if (host.pkg === 'apt') command = `sudo apt update && sudo apt install -y ${pkgName}`
  else if (host.pkg === 'dnf') command = `sudo dnf install -y ${pkgName}`
  else if (host.pkg === 'pacman') command = `sudo pacman -S --noconfirm ${pkgName}`
  else if (host.pkg === 'zypper') command = `sudo zypper in -y ${pkgName}`
  else if (host.pkg === 'winget') command = `winget install -e --id ${pkgName}`
  else if (host.pkg === 'brew') command = `brew install ${pkgName}`
  else command = `Download for ${host.pretty}: ${row?.url || intent.app}`
  return {
    app: intent.app,
    kind: intent.kind,
    host,
    package: pkgName,
    command,
    url: row?.url || '',
    next:
      intent.kind === 'remove'
        ? `Confirm this remove command on ${host.pretty}, then run it.`
        : `Install command for ${host.pretty} (${host.pkg}). One line if the network is up.`,
  }
}

export function hardwareSnapshot() {
  const host = detectHost()
  let cpu = ''
  try {
    cpu = execFileSync('lscpu', ['-J'], { encoding: 'utf8', timeout: 3000 })
  } catch {
    cpu = `${host.cores} cores`
  }
  return { ...host, cpuBrief: typeof cpu === 'string' && cpu.length > 200 ? `${host.cores} threads` : cpu.trim() }
}
