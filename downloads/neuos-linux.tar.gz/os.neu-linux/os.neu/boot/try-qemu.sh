#!/usr/bin/env bash
# Automated UEFI boot and GUI evidence for os.neu. Never writes a physical disk.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODE="${1:-console}"
case "$MODE" in
  console|gui|evidence|open|auto) ;;
  *)
    echo "usage: bash boot/try-qemu.sh [console|gui|evidence|open]" >&2
    echo "       bash boot/try-qemu.sh auto   (GRUB splash + autostart entry, screenshots every 2s)" >&2
    exit 2
    ;;
esac

VIRT_ROOT="${NEUOS_VIRT_ROOT:-/run/media/${USER:-billy-lee}/Data-02-4T/osneu-virt}"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
RUN_DIR="$VIRT_ROOT/runs/$RUN_ID"
if [[ -n "${NEUOS_VIRT_STAGE_DIR:-}" ]]; then
  STAGE="$NEUOS_VIRT_STAGE_DIR"
else
  tmp_avail="$(df -B1 --output=avail /tmp 2>/dev/null | tail -1 | tr -d ' ')"
  # Data-02-4T is NTFS/fuseblk and drops +x. Prefer tmpfs when 3G is free.
  if [[ "${tmp_avail:-0}" -ge $((3 * 1024 * 1024 * 1024)) ]]; then
    STAGE="/tmp/neuos-virt-stage-$RUN_ID"
  else
    STAGE="$VIRT_ROOT/stage/$RUN_ID"
  fi
fi
ISO="$RUN_DIR/neuos-live.iso"
SERIAL="$RUN_DIR/serial.log"
QEMU_LOG="$RUN_DIR/qemu.log"
QMP="$RUN_DIR/qmp.sock"
SCREENSHOT="$RUN_DIR/screen.ppm"
mkdir -p "$RUN_DIR"
if [[ "$STAGE" == "$VIRT_ROOT/"* ]]; then
  mkdir -p "$VIRT_ROOT/stage"
fi
: > "$SERIAL"
: > "$QEMU_LOG"

bash "$ROOT/boot/precheck.sh"

OVMF_CODE=""
OVMF_VARS_TEMPLATE=""
for pair in \
  "/usr/share/OVMF/OVMF_CODE_4M.fd:/usr/share/OVMF/OVMF_VARS_4M.fd" \
  "/usr/share/OVMF/OVMF_CODE.fd:/usr/share/OVMF/OVMF_VARS.fd"; do
  code="${pair%%:*}"
  vars="${pair##*:}"
  if [[ -r "$code" && -r "$vars" ]]; then
    OVMF_CODE="$code"
    OVMF_VARS_TEMPLATE="$vars"
    break
  fi
done
if [[ -z "$OVMF_CODE" ]]; then
  echo "FAIL: OVMF CODE/VARS pair not found" >&2
  exit 3
fi
OVMF_VARS="$RUN_DIR/OVMF_VARS.fd"
cp "$OVMF_VARS_TEMPLATE" "$OVMF_VARS"

AUTOGUI=0
if [[ "$MODE" == "gui" || "$MODE" == "evidence" ]]; then
  AUTOGUI=1
fi
DISPLAY_FLAG="-display none"
if [[ "$MODE" == "open" || "${NEUOS_VIRT_DISPLAY:-}" == "gtk" ]]; then
  DISPLAY_FLAG="-display gtk,grab-on-hover=on,show-cursor=on"
fi
OPEN_FLAG=0
if [[ "$MODE" == "open" ]]; then
  OPEN_FLAG=1
fi
AUTOSTART_FLAG=0
if [[ "$MODE" == "auto" ]]; then
  AUTOSTART_FLAG=1
fi
NEUOS_ISO_PATH="$ISO" \
NEUOS_STAGE_DIR="$STAGE" \
NEUOS_VIRT_AUTOGUI="$AUTOGUI" \
NEUOS_VIRT_OPEN="$OPEN_FLAG" \
NEUOS_VIRT_AUTOSTART="$AUTOSTART_FLAG" \
  bash "$ROOT/scripts/make-usb.sh"
bash "$ROOT/boot/verify-virt-artifact.sh" "$STAGE" "$ISO"
# The ISO is self-contained. Drop the ~1.2G stage so /tmp quota cannot fill again.
if [[ -d "$STAGE" ]] && { [[ "$STAGE" == /tmp/neuos-virt-stage-* ]] || [[ "$STAGE" == "$VIRT_ROOT/stage/"* ]]; }; then
  rm -rf "$STAGE"
fi

qemu_pid=""
shutdown_vm() {
  if [[ -n "$qemu_pid" ]] && kill -0 "$qemu_pid" 2>/dev/null; then
    if [[ -S "$QMP" ]]; then
      python3 "$ROOT/boot/qmp-command.py" "$QMP" system_powerdown >/dev/null 2>&1 || true
      sleep 2
    fi
    kill "$qemu_pid" 2>/dev/null || true
    wait "$qemu_pid" 2>/dev/null || true
  fi
}
if [[ "$MODE" == "open" ]]; then
  # Interactive seat: do not die with the npm terminal (SIGHUP killed the
  # 21:53 window from pid 677386 after ~1 min).
  trap '' HUP
else
  trap shutdown_vm EXIT INT TERM
fi

setsid qemu-system-x86_64 \
  -name osneu-virt-$MODE \
  -machine q35,accel=kvm,vmport="${NEUOS_VIRT_VMPORT:-off}" \
  -cpu host \
  -smp 2 \
  -m 4096 \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
  -drive if=pflash,format=raw,file="$OVMF_VARS" \
  -cdrom "$ISO" \
  -boot order=d \
  -device virtio-vga \
  -device qemu-xhci \
  -device usb-kbd \
  -device virtio-keyboard-pci \
  -device virtio-tablet-pci \
  -netdev user,id=net0 \
  -device virtio-net-pci,netdev=net0 \
  $DISPLAY_FLAG \
  -serial file:"$SERIAL" \
  -qmp unix:"$QMP",server=on,wait=off \
  -no-reboot \
  >>"$QEMU_LOG" 2>&1 &
qemu_pid=$!

i=0
while [[ "$i" -lt 20 && ! -S "$QMP" ]]; do
  sleep 1
  i=$((i + 1))
done
if [[ ! -S "$QMP" ]]; then
  echo "FAIL: QMP socket did not appear; see $QEMU_LOG" >&2
  exit 4
fi
# q35 still registers a PS/2 mouse as current. Host clicks then miss JeOS.
# NEUOS_VIRT_SELECT_TABLET=0 keeps QEMU's own choice (comparison runs).
if [[ "${NEUOS_VIRT_SELECT_TABLET:-1}" == "1" ]]; then
  python3 "$ROOT/boot/qmp-select-tablet.py" "$QMP" || true
fi

deadline=$((SECONDS + 240))
success_marker="JeOS console. Type open os.neu"
if [[ "$MODE" == "gui" || "$MODE" == "evidence" ]]; then
  success_marker="NEUOS_VIRT_WINDOW_OK"
fi

if [[ "$MODE" == "open" ]]; then
  while (( SECONDS < deadline )); do
    if grep -Fq "$success_marker" "$SERIAL"; then
      # Guest psmouse can register a new mouse handler after boot; keep the tablet current.
      python3 "$ROOT/boot/qmp-select-tablet.py" "$QMP" || true
      printf 'READY: QEMU window is the JeOS console.\n'
      printf 'Type: open os.neu\n'
      printf 'Close the QEMU window when finished. This terminal may exit; the window stays.\n'
      printf 'evidence: %s\n' "$RUN_DIR"
      hold_pid="$qemu_pid"
      qemu_pid=""
      wait "$hold_pid" || true
      python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$SCREENSHOT" >/dev/null 2>&1 || true
      exit 0
    fi
    if ! kill -0 "$qemu_pid" 2>/dev/null; then
      break
    fi
    sleep 2
  done
  echo "FAIL: JeOS prompt not observed for interactive virt open" >&2
  echo "serial: $SERIAL" >&2
  exit 5
fi

if [[ "$MODE" == "auto" ]]; then
  # No keyboard: GRUB entry 3 must reach a painted window by itself. Frames
  # every 2s keep the splash steps as evidence.
  n=0
  while (( SECONDS < deadline )); do
    n=$((n + 1))
    python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$RUN_DIR/boot-$(printf '%03d' "$n").ppm" >/dev/null 2>&1 || true
    if grep -aFq "NEUOS_VIRT_WINDOW_OK" "$SERIAL"; then
      sleep 4
      python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$SCREENSHOT" >/dev/null 2>&1 || true
      grep -a 'NETDIAG ' "$SERIAL" | sed 's/^.*NETDIAG /NETDIAG /' | awk '!s[$0]++' || true
      printf 'SPLASH=%s AUTOSTART=%s FRAMES=%s\n' \
        "$(grep -aq NEUOS_SPLASH_SHOWN "$SERIAL" && echo shown || echo NOT_SEEN)" \
        "$(grep -aq NEUOS_AUTOSTART_BEGIN "$SERIAL" && echo begun || echo NOT_SEEN)" "$n"
      if grep -aq 'JeOS console. Type open os.neu' "$SERIAL" && ! grep -aq NEUOS_AUTOSTART_BEGIN "$SERIAL"; then
        echo "FAIL: window without the autostart marker" >&2
        exit 5
      fi
      printf 'PASS: autostart window painted without typing (NEUOS_VIRT_WINDOW_OK)\n'
      printf 'evidence: %s\n' "$RUN_DIR"
      exit 0
    fi
    if grep -aEq 'NEUOS_VIRT_GUI_(FAIL|TIMEOUT|EXIT)|NEUOS_AUTOSTART_RETURNED' "$SERIAL"; then
      break
    fi
    if ! kill -0 "$qemu_pid" 2>/dev/null; then
      break
    fi
    sleep 2
  done
  python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$SCREENSHOT" >/dev/null 2>&1 || true
  grep -a 'NETDIAG ' "$SERIAL" | sed 's/^.*NETDIAG /NETDIAG /' | awk '!s[$0]++' || true
  echo "FAIL: autostart window not observed" >&2
  echo "serial: $SERIAL" >&2
  exit 5
fi

while (( SECONDS < deadline )); do
  if grep -Fq "$success_marker" "$SERIAL"; then
    python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$SCREENSHOT" >/dev/null
    if [[ "$MODE" != "console" ]] \
      && ! python3 "$ROOT/boot/check-ppm.py" "$SCREENSHOT" >/dev/null 2>&1; then
      sleep 2
      continue
    fi
    printf 'PASS: %s\n' "$success_marker"
    printf 'evidence: %s\n' "$RUN_DIR"
    if [[ "$MODE" == "gui" || "$MODE" == "evidence" ]]; then
      # Window painted is not input. Move/click/type through QEMU's current
      # mouse and require counts at the kernel event node and inside the app.
      if [[ "${NEUOS_VIRT_SELECT_TABLET:-1}" == "1" ]]; then
        python3 "$ROOT/boot/qmp-select-tablet.py" "$QMP" || true
      fi
      sleep 4
      python3 "$ROOT/boot/qmp-input-probe.py" "$QMP" | tee "$RUN_DIR/input-probe.txt" || true
      sleep 14
      python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$RUN_DIR/after-input.ppm" >/dev/null 2>&1 || true
      kernel_ev="$(grep -a 'INPUT_EVENTS ' "$SERIAL" | tail -1 || true)"
      app_ev="$(grep -a 'APP_EVENTS ' "$SERIAL" | tail -1 || true)"
      selected="$(grep -o '"name": "[^"]*", "current": true' "$RUN_DIR/input-probe.txt" | head -1 | sed 's/"name": "//; s/", "current": true//' || true)"
      ptr_line="$(printf '%s' "$kernel_ev" | tr ';' '\n' | grep -E 'MOTION=[1-9]' | head -1 || true)"
      k_motion="$(printf '%s' "$ptr_line" | sed -n 's/.*MOTION=\([0-9]*\).*/\1/p')"
      # Buttons can arrive on a different node than motion (vmmouse); sum all nodes.
      k_down="$(printf '%s' "$kernel_ev" | grep -o 'BTN_DOWN=[0-9]*' | awk -F= '{s+=$2} END{print s+0}')"
      k_up="$(printf '%s' "$kernel_ev" | grep -o 'BTN_UP=[0-9]*' | awk -F= '{s+=$2} END{print s+0}')"
      a_move="$(printf '%s' "$app_ev" | sed -n 's/.*"mouseMove":\([0-9]*\).*/\1/p')"
      a_down="$(printf '%s' "$app_ev" | sed -n 's/.*"mouseDown":\([0-9]*\).*/\1/p')"
      a_char="$(printf '%s' "$app_ev" | sed -n 's/.*"char":\([0-9]*\).*/\1/p')"
      net="$(grep -a 'NETWORK:' "$SERIAL" | tail -1 | sed 's/.*NETWORK: *//' || true)"
      printf 'kernel: %s\n' "${kernel_ev:-none}"
      printf 'app:    %s\n' "${app_ev:-none}"
      printf 'QEMU_SELECTED_POINTER=%s\n' "${selected:-UNKNOWN}"
      printf 'POINTER_DEVICE=%s\n' "$(printf '%s' "$ptr_line" | sed 's/^ *//; s/ MOTION=.*//')"
      printf 'KERNEL_MOTION_FRAMES=%s BUTTON_PRESS=%s BUTTON_RELEASE=%s\n' "${k_motion:-0}" "${k_down:-0}" "${k_up:-0}"
      printf 'APP_MOUSEMOVE=%s APP_MOUSEDOWN=%s APP_CHAR=%s\n' "${a_move:-0}" "${a_down:-0}" "${a_char:-0}"
      printf 'NETWORK=%s\n' "${net:-UNKNOWN}"
      # A single mouseMove can be the synthetic pointer-enter. Require frames
      # with X/Y at the node, a press+release, app moves, the app click and typed chars.
      if (( ${k_motion:-0} >= 2 && ${k_down:-0} >= 1 && ${k_up:-0} >= 1 \
        && ${a_move:-0} >= 2 && ${a_down:-0} >= 1 && ${a_char:-0} >= 2 )); then
        printf 'INPUT PASS: motion frames + press/release at the node; moves, click and typed keys in the app\n'
      else
        printf 'INPUT FAIL: window up, pointer move+click+keys not proven end to end\n' >&2
        exit 6
      fi
      # Command stage: talk first (stays on the landing), then web (opens daf.neu on top).
      python3 "$ROOT/boot/qmp-input-probe.py" "$QMP" type "${NEUOS_VIRT_TALK:-hello}" | tee -a "$RUN_DIR/input-probe.txt" || true
      # webRequest onCompleted fires when the seat stream ends; a CPU model can
      # take minutes. Wait for it (bounded), then let the reply paint.
      t_end=$((SECONDS + ${NEUOS_VIRT_TALK_WAIT:-240}))
      while (( SECONDS < t_end )) && ! grep -aq 'APP_MARK .*API POST /api/seat/write' "$SERIAL"; do
        sleep 3
      done
      sleep 8
      python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$RUN_DIR/after-talk.ppm" >/dev/null 2>&1 || true
      # After a reply the box sits near the top (y≈240 on 1280x800).
      python3 "$ROOT/boot/qmp-input-probe.py" "$QMP" type "${NEUOS_VIRT_WEB:-open the web}" 640,240 | tee -a "$RUN_DIR/input-probe.txt" || true
      sleep 20
      python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$RUN_DIR/after-web.ppm" >/dev/null 2>&1 || true
      seat="$(grep -a 'APP_MARK .*API POST /api/seat/write' "$SERIAL" | tail -1 | sed 's/.*API /API /' || true)"
      daf="$(grep -a 'APP_MARK .*DAF_WINDOW' "$SERIAL" | tail -2 | sed 's/.*DAF_WINDOW/DAF_WINDOW/' | paste -sd' ' || true)"
      grep -a -E 'NET_PROBE_NODE|APP_MARK .*NET_PROBE|LLM_LOCAL' "$SERIAL" | sed 's/.*\(NET_PROBE\)/\1/; s/.*\(LLM_LOCAL\)/\1/' | awk '!s[$0]++' || true
      printf 'TALK_COMMAND=%s\n' "${seat:-NO_SEAT_WRITE_CALL_SEEN}"
      printf 'WEB_COMMAND=%s\n' "${daf:-NO_DAF_WINDOW_SEEN}"
      if [[ -n "$daf" ]] && [[ -n "$seat" ]]; then
        printf 'COMMAND PASS: talk reached /api/seat/write; web opened a daf.neu window (LLM answer judged from after-talk.ppm)\n'
        exit 0
      fi
      printf 'COMMAND FAIL: see after-talk.ppm / after-web.ppm and APP_MARK lines in serial\n' >&2
      exit 7
    fi
    exit 0
  fi
  if grep -Eq 'NEUOS_VIRT_GUI_(FAIL|TIMEOUT|EXIT)' "$SERIAL"; then
    break
  fi
  if ! kill -0 "$qemu_pid" 2>/dev/null; then
    break
  fi
  sleep 2
done

python3 "$ROOT/boot/qmp-command.py" "$QMP" screendump --filename "$SCREENSHOT" >/dev/null 2>&1 || true
echo "FAIL: marker '$success_marker' not observed" >&2
echo "serial: $SERIAL" >&2
echo "qemu: $QEMU_LOG" >&2
echo "screenshot: $SCREENSHOT" >&2
exit 5
