#!/usr/bin/env node
/**
 * os.neu boot splash on the Linux framebuffer (simpledrm, later i915 fbdev).
 * No Plymouth and no compositor: frames go straight to /dev/fb0 until cage
 * takes DRM master. The framebuffer is written only on a JeOS boot
 * (NEUOS_JEOS=1 and /etc/neuos-release); on a host desktop it refuses.
 *
 *   osneu-splash.mjs show                      reset steps, draw
 *   osneu-splash.mjs step <1-4> <state> [note] state = pending|run|ok|warn|fail
 *   osneu-splash.mjs note <text>
 *   osneu-splash.mjs release                   stop drawing, keep the frame until cage paints
 *   osneu-splash.mjs quit                      give the screen back to the text console
 *   osneu-splash.mjs ppm <out.ppm> <W>x<H> [--steps ok,run,pending,pending] [--note text]
 *   osneu-splash.mjs info
 */
import { closeSync, existsSync, openSync, readFileSync, readdirSync, writeFileSync, writeSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
export const STEPS = [
  'Mounting os.neu runtime',
  'Starting daf.neu network',
  'Connecting app.neu',
  'Preparing AI workspace',
]
export const TITLE = 'Initializing AI runtime\u2026'
const STATES = ['pending', 'run', 'ok', 'warn', 'fail']
const STATE_FILE = process.env.NEUOS_SPLASH_STATE || '/run/osneu-splash.json'
const ASSETS = process.env.NEUOS_SPLASH_ASSETS || path.join(HERE, 'assets')
const FB = process.env.NEUOS_FB || '/dev/fb0'

const C = {
  bgTop: [11, 20, 38],
  bgBottom: [4, 8, 18],
  title: [230, 237, 247],
  word: [255, 255, 255],
  track: [30, 42, 68],
  accent: [74, 144, 226],
  ring: [58, 74, 102],
  note: [107, 122, 147],
  ok: [63, 185, 80],
  warn: [210, 153, 34],
  fail: [229, 72, 77],
}
const LABEL = {
  pending: [91, 107, 134],
  run: [255, 255, 255],
  ok: [201, 212, 229],
  warn: [232, 199, 122],
  fail: [242, 167, 170],
}

// ---------- canvas ----------

function canvas(w, h) {
  return { w, h, px: new Uint8Array(w * h * 3) }
}

function fillGradient(cv, top, bottom) {
  const { w, h, px } = cv
  for (let y = 0; y < h; y++) {
    const t = h > 1 ? y / (h - 1) : 0
    const r = top[0] + (bottom[0] - top[0]) * t
    const g = top[1] + (bottom[1] - top[1]) * t
    const b = top[2] + (bottom[2] - top[2]) * t
    let i = y * w * 3
    for (let x = 0; x < w; x++, i += 3) {
      px[i] = r
      px[i + 1] = g
      px[i + 2] = b
    }
  }
}

function blend(cv, x, y, rgb, a) {
  if (a <= 0 || x < 0 || y < 0 || x >= cv.w || y >= cv.h) return
  if (a > 1) a = 1
  const i = (y * cv.w + x) * 3
  const px = cv.px
  px[i] += (rgb[0] - px[i]) * a
  px[i + 1] += (rgb[1] - px[i + 1]) * a
  px[i + 2] += (rgb[2] - px[i + 2]) * a
}

function fillRect(cv, x, y, w, h, rgb) {
  const x0 = Math.max(0, Math.round(x))
  const y0 = Math.max(0, Math.round(y))
  const x1 = Math.min(cv.w, Math.round(x + w))
  const y1 = Math.min(cv.h, Math.round(y + h))
  for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) blend(cv, xx, yy, rgb, 1)
}

/** Paint a shape given a signed coverage function over its bounding box (anti-aliased). */
function paint(cv, x0, y0, x1, y1, rgb, cover) {
  for (let y = Math.max(0, Math.floor(y0)); y < Math.min(cv.h, Math.ceil(y1)); y++) {
    for (let x = Math.max(0, Math.floor(x0)); x < Math.min(cv.w, Math.ceil(x1)); x++) {
      const a = cover(x + 0.5, y + 0.5)
      if (a > 0) blend(cv, x, y, rgb, a)
    }
  }
}

const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v)

function disc(cv, cx, cy, r, rgb) {
  paint(cv, cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, rgb, (x, y) => clamp01(r - Math.hypot(x - cx, y - cy) + 0.5))
}

function ring(cv, cx, cy, r, t, rgb) {
  paint(cv, cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, rgb, (x, y) => {
    const d = Math.hypot(x - cx, y - cy)
    return Math.min(clamp01(r - d + 0.5), clamp01(d - (r - t) + 0.5))
  })
}

function segDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax
  const dy = by - ay
  const t = clamp01(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy || 1))
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy))
}

function stroke(cv, pts, width, rgb) {
  const xs = pts.map((p) => p[0])
  const ys = pts.map((p) => p[1])
  const pad = width + 1
  paint(cv, Math.min(...xs) - pad, Math.min(...ys) - pad, Math.max(...xs) + pad, Math.max(...ys) + pad, rgb, (x, y) => {
    let d = Infinity
    for (let i = 0; i + 1 < pts.length; i++) d = Math.min(d, segDist(x, y, ...pts[i], ...pts[i + 1]))
    return clamp01(width / 2 - d + 0.5)
  })
}

// ---------- resampling (separable: bilinear up, area down) ----------

function weights(n, m) {
  const out = []
  if (m >= n) {
    for (let i = 0; i < m; i++) {
      const s = ((i + 0.5) * n) / m - 0.5
      const j = Math.floor(s)
      const f = s - j
      out.push([
        [Math.max(0, Math.min(n - 1, j)), 1 - f],
        [Math.max(0, Math.min(n - 1, j + 1)), f],
      ])
    }
    return out
  }
  const scale = n / m
  for (let i = 0; i < m; i++) {
    const a = i * scale
    const b = a + scale
    const row = []
    for (let j = Math.floor(a); j < Math.ceil(b); j++) {
      const w = Math.min(b, j + 1) - Math.max(a, j)
      if (w > 0) row.push([Math.min(n - 1, j), w / scale])
    }
    out.push(row)
  }
  return out
}

function resample(src, sw, sh, ch, dw, dh) {
  const wx = weights(sw, dw)
  const wy = weights(sh, dh)
  const mid = new Float32Array(dw * sh * ch)
  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < dw; x++) {
      for (let c = 0; c < ch; c++) {
        let v = 0
        for (const [j, w] of wx[x]) v += src[(y * sw + j) * ch + c] * w
        mid[(y * dw + x) * ch + c] = v
      }
    }
  }
  const out = new Float32Array(dw * dh * ch)
  for (let y = 0; y < dh; y++) {
    for (let x = 0; x < dw; x++) {
      for (let c = 0; c < ch; c++) {
        let v = 0
        for (const [j, w] of wy[y]) v += mid[(j * dw + x) * ch + c] * w
        out[(y * dw + x) * ch + c] = v
      }
    }
  }
  return out
}

// ---------- assets ----------

let assetCache
function loadAssets() {
  if (assetCache !== undefined) return assetCache
  assetCache = null
  try {
    const manifest = JSON.parse(readFileSync(path.join(ASSETS, 'manifest.json'), 'utf8'))
    const font = (f) => ({ ...f, blob: readFileSync(path.join(ASSETS, f.file)), cache: new Map() })
    assetCache = {
      regular: font(manifest.regular),
      bold: font(manifest.bold),
      logo: { ...manifest.logo, rgba: readFileSync(path.join(ASSETS, manifest.logo.file)) },
    }
  } catch {
    /* no assets on this build: shapes only, no text */
  }
  return assetCache
}

function glyph(font, ch, size) {
  const key = `${ch}:${size}`
  const hit = font.cache.get(key)
  if (hit) return hit
  const g = font.glyphs[ch] || font.glyphs['?']
  const s = size / font.px
  const out = { adv: g.adv * s, ox: g.ox * s, oy: g.oy * s, w: 0, h: 0, mask: null }
  if (g.w && g.h) {
    out.w = Math.max(1, Math.round(g.w * s))
    out.h = Math.max(1, Math.round(g.h * s))
    out.mask = resample(font.blob.subarray(g.off, g.off + g.w * g.h), g.w, g.h, 1, out.w, out.h)
  }
  font.cache.set(key, out)
  return out
}

export function textWidth(font, str, size) {
  let w = 0
  for (const ch of str) w += glyph(font, ch, size).adv
  return w
}

function drawText(cv, font, str, x, baseline, size, rgb, align = 'left') {
  if (!font) return
  let pen = align === 'center' ? x - textWidth(font, str, size) / 2 : x
  for (const ch of str) {
    const g = glyph(font, ch, size)
    if (g.mask) {
      const gx = Math.round(pen + g.ox)
      const gy = Math.round(baseline + g.oy)
      for (let y = 0; y < g.h; y++) {
        for (let x = 0; x < g.w; x++) {
          const a = g.mask[y * g.w + x]
          if (a > 1) blend(cv, gx + x, gy + y, rgb, a / 255)
        }
      }
    }
    pen += g.adv
  }
}

function drawLogo(cv, logo, cx, cy, size) {
  const s = Math.max(1, Math.round(size))
  const src = new Float32Array(logo.w * logo.h * 4)
  for (let i = 0; i < logo.w * logo.h; i++) {
    const a = logo.rgba[i * 4 + 3] / 255
    src[i * 4] = logo.rgba[i * 4] * a
    src[i * 4 + 1] = logo.rgba[i * 4 + 1] * a
    src[i * 4 + 2] = logo.rgba[i * 4 + 2] * a
    src[i * 4 + 3] = a
  }
  const img = resample(src, logo.w, logo.h, 4, s, s)
  const x0 = Math.round(cx - s / 2)
  const y0 = Math.round(cy - s / 2)
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const k = (y * s + x) * 4
      const a = img[k + 3]
      if (a <= 0.003) continue
      const dx = x0 + x
      const dy = y0 + y
      if (dx < 0 || dy < 0 || dx >= cv.w || dy >= cv.h) continue
      const i = (dy * cv.w + dx) * 3
      cv.px[i] = img[k] + cv.px[i] * (1 - a)
      cv.px[i + 1] = img[k + 1] + cv.px[i + 1] * (1 - a)
      cv.px[i + 2] = img[k + 2] + cv.px[i + 2] * (1 - a)
    }
  }
}

/** Brand-colour stand-in when the logo asset is missing. */
function drawLogoShapes(cv, cx, cy, size) {
  const r = size * 0.11
  const bars = [
    [[-0.22, -0.32], [-0.22, 0.02], [96, 174, 196]],
    [[0.02, -0.08], [0.3, 0.06], [126, 222, 126]],
    [[-0.28, 0.3], [0.04, 0.12], [74, 144, 226]],
  ]
  for (const [a, b, rgb] of bars) {
    stroke(cv, [[cx + a[0] * size, cy + a[1] * size], [cx + b[0] * size, cy + b[1] * size]], r * 1.4, rgb)
    disc(cv, cx + a[0] * size, cy + a[1] * size, r, rgb)
    disc(cv, cx + b[0] * size, cy + b[1] * size, r, rgb)
  }
}

function drawIcon(cv, state, cx, cy, r, u) {
  if (state === 'pending') {
    ring(cv, cx, cy, r, Math.max(1.5, 2 * u), C.ring)
    return
  }
  if (state === 'run') {
    ring(cv, cx, cy, r + 3 * u, Math.max(1, 1.5 * u), C.accent.map((v, i) => v * 0.5 + C.bgTop[i] * 0.5))
    disc(cv, cx, cy, r, C.accent)
    return
  }
  const fill = state === 'ok' ? C.ok : state === 'warn' ? C.warn : C.fail
  disc(cv, cx, cy, r, fill)
  const w = Math.max(1.5, 2.2 * u)
  if (state === 'ok') {
    stroke(cv, [[cx - r * 0.45, cy + r * 0.02], [cx - r * 0.1, cy + r * 0.38], [cx + r * 0.5, cy - r * 0.35]], w, [255, 255, 255])
  } else if (state === 'fail') {
    stroke(cv, [[cx - r * 0.38, cy - r * 0.38], [cx + r * 0.38, cy + r * 0.38]], w, [255, 255, 255])
    stroke(cv, [[cx + r * 0.38, cy - r * 0.38], [cx - r * 0.38, cy + r * 0.38]], w, [255, 255, 255])
  } else {
    stroke(cv, [[cx, cy - r * 0.5], [cx, cy + r * 0.12]], w, [20, 20, 20])
    disc(cv, cx, cy + r * 0.45, w * 0.6, [20, 20, 20])
  }
}

// ---------- frame ----------

export function normalizeState(raw = {}) {
  const steps = STEPS.map((_, i) => (STATES.includes(raw.steps?.[i]) ? raw.steps[i] : 'pending'))
  return { steps, note: String(raw.note || '').slice(0, 120), quit: Boolean(raw.quit) }
}

export function renderFrame(state, w, h) {
  const st = normalizeState(state)
  const cv = canvas(w, h)
  fillGradient(cv, C.bgTop, C.bgBottom)
  const a = loadAssets()
  const u = Math.min(h / 1080, w / 1440)
  const cx = w / 2

  const logoY = h * 0.34
  const logoSize = 190 * u
  if (a?.logo) drawLogo(cv, a.logo, cx, logoY, logoSize)
  else drawLogoShapes(cv, cx, logoY, logoSize)
  drawText(cv, a?.bold, 'os.neu', cx, logoY + logoSize / 2 + 78 * u, 60 * u, C.word, 'center')

  const titleY = h * 0.655
  drawText(cv, a?.regular, TITLE, cx, titleY, 28 * u, C.title, 'center')

  const barW = 440 * u
  const barH = Math.max(2, 4 * u)
  const barX = cx - barW / 2
  const barY = titleY + 22 * u
  const done = st.steps.filter((s) => s === 'ok' || s === 'warn').length
  const frac = Math.min(1, (done + (st.steps.includes('run') ? 0.5 : 0)) / STEPS.length)
  fillRect(cv, barX, barY, barW, barH, C.track)
  if (frac > 0) fillRect(cv, barX, barY, barW * frac, barH, st.steps.includes('fail') ? C.fail : C.accent)

  const rowH = 40 * u
  const r = 8 * u
  const listX = barX + 6 * u
  let y = barY + 54 * u
  STEPS.forEach((label, i) => {
    const s = st.steps[i]
    drawIcon(cv, s, listX + r, y - 8 * u, r, u)
    drawText(cv, a?.regular, label, listX + r * 2 + 16 * u, y, 22 * u, LABEL[s])
    y += rowH
  })

  if (st.note) drawText(cv, a?.regular, st.note, cx, h - 30 * u, 17 * u, C.note, 'center')
  return cv
}

export function toPpm(cv) {
  const head = Buffer.from(`P6\n${cv.w} ${cv.h}\n255\n`, 'ascii')
  return Buffer.concat([head, Buffer.from(cv.px.buffer, cv.px.byteOffset, cv.px.length)])
}

// ---------- framebuffer ----------

function readSys(p) {
  try {
    return readFileSync(p, 'utf8').trim()
  } catch {
    return ''
  }
}

export function fbInfo(dev = FB) {
  const sys = `/sys/class/graphics/${path.basename(dev)}`
  const [vw, vh] = readSys(`${sys}/virtual_size`).split(',').map(Number)
  const mode = /(\d+)x(\d+)/.exec(readSys(`${sys}/modes`).split('\n')[0] || '')
  const w = mode ? Number(mode[1]) : vw
  const h = mode ? Number(mode[2]) : vh
  const bpp = Number(readSys(`${sys}/bits_per_pixel`)) || 32
  const stride = Number(readSys(`${sys}/stride`)) || w * Math.ceil(bpp / 8)
  return { dev, name: readSys(`${sys}/name`), w, h, bpp, stride, ok: Boolean(w && h && existsSync(dev)) }
}

function toFb(cv, info) {
  const buf = Buffer.alloc(info.stride * info.h)
  const bytes = Math.ceil(info.bpp / 8)
  for (let y = 0; y < Math.min(cv.h, info.h); y++) {
    let o = y * info.stride
    let i = y * cv.w * 3
    for (let x = 0; x < Math.min(cv.w, info.w); x++, i += 3, o += bytes) {
      const r = cv.px[i]
      const g = cv.px[i + 1]
      const b = cv.px[i + 2]
      if (bytes === 2) {
        buf.writeUInt16LE(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3), o)
      } else {
        buf[o] = b
        buf[o + 1] = g
        buf[o + 2] = r
        if (bytes === 4) buf[o + 3] = 255
      }
    }
  }
  return buf
}

export function onJeos() {
  return process.env.NEUOS_JEOS === '1' && existsSync('/etc/neuos-release')
}

export function splashRequested() {
  return / neuos\.splash=1 /.test(` ${readSys('/proc/cmdline')} `)
}

/** fbcon owns the framebuffer while bound; unbind so the console stops painting over the splash. */
function setFbcon(bound) {
  let names = []
  try {
    names = readdirSync('/sys/class/vtconsole')
  } catch {
    return
  }
  for (const n of names) {
    const dir = `/sys/class/vtconsole/${n}`
    if (!/frame buffer/i.test(readSys(`${dir}/name`))) continue
    try {
      writeFileSync(`${dir}/bind`, bound ? '1' : '0')
    } catch {
      /* not root or no fbcon */
    }
  }
}

function readState() {
  try {
    return normalizeState(JSON.parse(readFileSync(STATE_FILE, 'utf8')))
  } catch {
    return normalizeState()
  }
}

function saveState(st) {
  if (!onJeos() && !process.env.NEUOS_SPLASH_STATE) return
  try {
    writeFileSync(STATE_FILE, JSON.stringify(st))
  } catch {
    /* /run not writable: draw anyway */
  }
}

function draw(st) {
  if (!onJeos()) return { ok: false, reason: 'not-jeos' }
  if (st.quit) return { ok: false, reason: 'quit' }
  const info = fbInfo()
  if (!info.ok) return { ok: false, reason: `no-framebuffer ${FB}` }
  setFbcon(false)
  const frame = toFb(renderFrame(st, info.w, info.h), info)
  const fd = openSync(FB, 'r+')
  try {
    writeSync(fd, frame, 0, frame.length, 0)
  } finally {
    closeSync(fd)
  }
  return { ok: true, info }
}

export function showSplash() {
  const st = normalizeState()
  st.steps[0] = 'run'
  saveState(st)
  return draw(st)
}

export function setStep(n, state, note) {
  const st = readState()
  const i = Number(n) - 1
  if (i >= 0 && i < STEPS.length && STATES.includes(state)) st.steps[i] = state
  if (note != null) st.note = String(note).slice(0, 120)
  saveState(st)
  return draw(st)
}

/** Stop drawing; fbcon stays unbound so the last frame holds until cage paints. */
export function releaseSplash() {
  const st = readState()
  st.quit = true
  saveState(st)
  return { ok: true }
}

export function quitSplash() {
  const st = readState()
  st.quit = true
  saveState(st)
  if (onJeos()) setFbcon(true)
  return { ok: true }
}

function main(argv) {
  const [cmd, ...rest] = argv
  if (cmd === 'ppm') {
    const [out, size = '1920x1080'] = rest
    const [w, h] = size.split('x').map(Number)
    const flag = (name) => {
      const k = rest.indexOf(name)
      return k >= 0 ? rest[k + 1] : undefined
    }
    const st = normalizeState({ steps: (flag('--steps') || 'run').split(','), note: flag('--note') })
    writeFileSync(out, toPpm(renderFrame(st, w, h)))
    console.log(`splash ppm ${out} ${w}x${h} assets=${loadAssets() ? 'yes' : 'none'}`)
    return 0
  }
  if (cmd === 'info') {
    console.log(JSON.stringify({ fb: fbInfo(), jeos: onJeos(), requested: splashRequested(), assets: Boolean(loadAssets()) }))
    return 0
  }
  let res
  if (cmd === 'show') res = showSplash()
  else if (cmd === 'step') res = setStep(rest[0], rest[1], rest.length > 2 ? rest.slice(2).join(' ') : undefined)
  else if (cmd === 'note') res = setStep(0, '', rest.join(' '))
  else if (cmd === 'release') res = releaseSplash()
  else if (cmd === 'quit') res = quitSplash()
  else {
    console.error('usage: osneu-splash.mjs show|step <n> <state> [note]|note <text>|release|quit|ppm <out> <W>x<H>|info')
    return 2
  }
  if (!res.ok && res.reason) console.error(`splash: ${res.reason} — framebuffer untouched`)
  return 0
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exitCode = main(process.argv.slice(2))
}
