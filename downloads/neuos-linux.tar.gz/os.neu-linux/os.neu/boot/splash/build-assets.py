#!/usr/bin/env python3
"""Pre-render the os.neu boot splash assets for boot/splash/osneu-splash.mjs.

The JeOS stick has no font stack outside Electron, so text is shipped as a
glyph atlas (8-bit alpha masks + metrics) and the logo as raw RGBA. Runs on
the build host (make-usb.sh). Output is generated, never committed.

usage: build-assets.py OUT_DIR [REPO_ROOT]
"""
import json
import os
import sys

from PIL import Image, ImageDraw, ImageFont

REF_PX = 96
LOGO_PX = 384
CHARS = [chr(c) for c in range(32, 127)] + ['\u2026', '\u00b7', '\u2014', '\u2192']

REGULAR = [
    '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
]
BOLD = [
    '/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
]


def first_font(paths):
    for p in paths:
        if os.path.isfile(p):
            return p
    raise SystemExit('FAIL: no splash font found (install fonts-noto-core or fonts-dejavu-core)')


def build_font(path, name, out_dir):
    font = ImageFont.truetype(path, REF_PX)
    ascent, descent = font.getmetrics()
    glyphs = {}
    blob = bytearray()
    for ch in CHARS:
        adv = font.getlength(ch)
        x0, y0, x1, y1 = font.getbbox(ch, anchor='ls')
        w, h = max(0, x1 - x0), max(0, y1 - y0)
        entry = {'adv': round(adv, 2), 'ox': x0, 'oy': y0, 'w': w, 'h': h, 'off': len(blob)}
        if w and h:
            img = Image.new('L', (w, h), 0)
            ImageDraw.Draw(img).text((-x0, -y0), ch, font=font, fill=255, anchor='ls')
            blob += img.tobytes()
        glyphs[ch] = entry
    with open(os.path.join(out_dir, f'{name}.a8'), 'wb') as fh:
        fh.write(bytes(blob))
    return {
        'file': f'{name}.a8',
        'source': os.path.basename(path),
        'px': REF_PX,
        'ascent': ascent,
        'descent': descent,
        'glyphs': glyphs,
    }


def build_logo(repo, out_dir):
    src = os.path.join(repo, 'public', 'brand', 'os.neu-app.png')
    img = Image.open(src).convert('RGBA').resize((LOGO_PX, LOGO_PX), Image.LANCZOS)
    with open(os.path.join(out_dir, 'logo.rgba'), 'wb') as fh:
        fh.write(img.tobytes())
    return {'file': 'logo.rgba', 'w': LOGO_PX, 'h': LOGO_PX, 'source': 'public/brand/os.neu-app.png'}


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    out_dir = sys.argv[1]
    repo = sys.argv[2] if len(sys.argv) > 2 else os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    os.makedirs(out_dir, exist_ok=True)
    manifest = {
        'version': 1,
        'regular': build_font(first_font(REGULAR), 'regular', out_dir),
        'bold': build_font(first_font(BOLD), 'bold', out_dir),
        'logo': build_logo(repo, out_dir),
    }
    with open(os.path.join(out_dir, 'manifest.json'), 'w') as fh:
        json.dump(manifest, fh, ensure_ascii=False)
    print(f"splash assets {out_dir} regular={manifest['regular']['source']} bold={manifest['bold']['source']}")


if __name__ == '__main__':
    main()
