import { execFileSync } from 'node:child_process'
import { mkdtempSync, readFileSync, statSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (path: string) => readFileSync(join(root, path), 'utf8')
const script = join(root, 'scripts/osneu-local-boot.sh')
const run = (dest: string, ...args: string[]) =>
  execFileSync('bash', [script, ...args], {
    env: { ...process.env, OSNEU_DESTDIR: dest, OSNEU_ROOT_UUID: '0000-test' },
    encoding: 'utf8',
  })

describe('os.neu local boot (GRUB entry on the PC disk)', () => {
  it('never partitions, formats or deletes', () => {
    const s = read('scripts/osneu-local-boot.sh')
    for (const bad of ['parted', 'mkfs', 'sgdisk', 'fdisk', 'wipefs', 'dd if=', 'rm -', 'grub-install', 'efibootmgr']) {
      expect(s).not.toContain(bad)
    }
    expect(s).toContain('MODE=plan')
    expect(s).toContain('refusing to overwrite')
  })

  it('applies into a prefix, keeps Ubuntu, and reverts without deleting', () => {
    const d = mkdtempSync(join(tmpdir(), 'olb-'))
    run(d, '--apply')
    const menu = readFileSync(join(d, 'etc/grub.d/42_osneu'), 'utf8')
    expect(menu).toContain("menuentry 'os.neu'")
    expect(menu).toContain('systemd.unit=osneu-kiosk.target')
    const linux = menu.split('\n').find((l) => l.includes('linux /boot/vmlinuz')) ?? ''
    expect(linux).not.toContain('splash')
    expect(linux).toContain('ro quiet systemd.unit=osneu-kiosk.target')
    expect(statSync(join(d, 'etc/grub.d/42_osneu')).mode & 0o111).not.toBe(0)
    const dropin = readFileSync(join(d, 'etc/default/grub.d/90-osneu.cfg'), 'utf8')
    expect(dropin).toContain('GRUB_TIMEOUT=10')
    expect(dropin).not.toContain('GRUB_DEFAULT')
    const svc = readFileSync(join(d, 'etc/systemd/system/osneu-kiosk.service'), 'utf8')
    expect(svc).toContain('PAMName=login')
    expect(svc).toContain('scripts/osneu-local-kiosk.sh')
    expect(readFileSync(join(d, 'etc/systemd/system/osneu-kiosk.target'), 'utf8')).toContain('Conflicts=rescue.service rescue.target display-manager.service')

    run(d, '--revert')
    expect(statSync(join(d, 'etc/grub.d/42_osneu')).mode & 0o111).toBe(0)
    expect(statSync(join(d, 'etc/grub.d/42_osneu')).size).toBeGreaterThan(1)
    expect(readFileSync(join(d, 'etc/default/grub.d/90-osneu.cfg'), 'utf8')).toContain('disabled by --revert')
    expect(statSync(join(d, 'etc/systemd/system/osneu-kiosk.service')).size).toBeGreaterThan(1)
  })

  it('hides boot status text only when OSNEU_QUIET_BOOT=1', () => {
    const d = mkdtempSync(join(tmpdir(), 'olb-'))
    execFileSync('bash', [script, '--apply'], {
      env: { ...process.env, OSNEU_DESTDIR: d, OSNEU_ROOT_UUID: '0000-test', OSNEU_QUIET_BOOT: '1' },
      encoding: 'utf8',
    })
    expect(readFileSync(join(d, 'etc/grub.d/42_osneu'), 'utf8')).toContain('quiet loglevel=3 systemd.show_status=false')
  })

  it('kiosk defaults to the cage session without wizard or power guard; sway is opt-in', () => {
    const k = read('scripts/osneu-local-kiosk.sh')
    expect(k).toContain('[ "${OSNEU_COMPOSITOR:-cage}" = sway ]')
    expect(k).toContain('export NEUOS_WIZARD="${NEUOS_WIZARD:-0}"')
    expect(k).toContain('export NEUOS_POWER_GUARD="${NEUOS_POWER_GUARD:-0}"')
    expect(read('electron/localboot.cjs')).toContain("process.env.NEUOS_POWER_GUARD === '0'")
  })

  it('sets os.neu as default only when asked', () => {
    const d = mkdtempSync(join(tmpdir(), 'olb-'))
    run(d, '--apply', '--default-osneu')
    expect(readFileSync(join(d, 'etc/default/grub.d/90-osneu.cfg'), 'utf8')).toContain("GRUB_DEFAULT='os.neu'")
  })

  it('refuses to overwrite a file it did not write', () => {
    const d = mkdtempSync(join(tmpdir(), 'olb-'))
    mkdirSync(join(d, 'etc/grub.d'), { recursive: true })
    writeFileSync(join(d, 'etc/grub.d/42_osneu'), '#!/bin/sh\n')
    expect(() => run(d, '--apply')).toThrow()
    expect(readFileSync(join(d, 'etc/grub.d/42_osneu'), 'utf8')).toBe('#!/bin/sh\n')
  })

  it('kiosk session matches the desktop Electron flags and keeps its own browser profile', () => {
    const k = read('scripts/osneu-local-kiosk.sh')
    expect(k).toContain('cage -s -m "$CAGE_OUTPUT" --')
    expect(k).toContain('CAGE_OUTPUT="${OSNEU_CAGE_OUTPUT:-last}"')
    expect(k).toContain('SCALE="${OSNEU_SCALE:-1}"')
    expect(k).toContain('export OSNEU_BOOT_DIR="$BOOT_DIR"')
    expect(k).toContain('LOG="$BOOT_DIR/session.log"')
    const c = read('scripts/osneu-logs-collect.sh')
    expect(c).toContain('usb-logs-pull.sh')
    expect(c).not.toMatch(/\brm\s+-/)
    const m = read('electron/main.cjs')
    expect(m).toContain("path.join(process.env.OSNEU_BOOT_DIR, 'marks.log')")
    expect(m).toContain('captureBootScreens(win)')
    expect(k).toContain('export OSNEU_ZOOM="${OSNEU_ZOOM:-2}"')
    expect(m).toContain('wc.setZoomFactor(zoom)')
    expect(m).toContain('ctl.view.setBounds(r)')
    expect(m).toContain('watchApiReasons(win)')
    expect(m).toMatch(/if \(localboot\.ACTIVE\) \{\s+openInSystemBrowser\(url\)/)
    expect(m).toContain('closeLoginBrowser()')
    expect(m).toContain('custom_chrome_frame: true')
    expect(m).toContain("'--new-window'")
    expect(m).not.toMatch(/`--app=\$\{url\}`/)
    expect(k).toContain('for_window [app_id="^(google-chrome|chromium)"] floating enable')
    expect(c).toContain('API_REASON')
    expect(c).toContain('LOGIN_(WINDOW|HANDOFF)')
    expect(k).toContain('"$APP" $SCALE_ARG $SANDBOX_ARGS --password-store="$PASSWORD_STORE"')
    expect(k).toContain('SANDBOX_ARGS="--no-sandbox --disable-gpu-sandbox"')
    expect(k).toMatch(/if \[ -u "\$helper" \] && .*then SANDBOX_ARGS=""; fi/)
    expect(k).toContain('PASSWORD_STORE=basic')
    expect(k).toContain('PASSWORD_STORE=gnome-libsecret')
    expect(k).toContain('gnome-keyring-daemon --start')
    expect(k).toContain('refusing root kiosk user')
    expect(k).toContain('export XDG_CONFIG_HOME="$HOME/.config/osneu-kiosk"')
    expect(k).toContain('export NEUOS_PACKAGED=1')
    expect(k).not.toContain('NEUOS_JEOS')
    expect(k).not.toMatch(/ozone-platform=drm/)
  })

  it('prefers sway + fcitx5 with Wayland IME, centred windows and a mid-screen console', () => {
    const k = read('scripts/osneu-local-kiosk.sh')
    expect(k).toContain('--enable-wayland-ime --wayland-text-input-version=3')
    expect(k).toContain('exec fcitx5 -d --replace')
    expect(k).toContain('include $XDG_CONFIG_HOME/sway/osneu-outputs.conf')
    expect(k).toContain('for_window [title="^(?!os\\\\.neu( v[0-9.]+| start)?\\$)"] floating enable')
    expect(k).toContain('for_window [title="^os\\\\.neu login\\$"] floating enable')
    expect(k).toContain('move position $DAF_X ppt 3 ppt')
    expect(k).toContain('workspace 1 output $PRIMARY')
    const m = read('electron/main.cjs')
    expect(m).toContain('show: !bootSplash')
    expect(m).toContain("title: 'os.neu start'")
    expect(k).toContain('app_id="^osneu-console')
    expect(k).toContain('bindsym Ctrl+Alt+t')
    expect(k).toContain('[ -s "$tmp" ]')
    expect(k).toContain("'[Groups/0/Items/1]' 'Name=hangul'")
    expect(k).toContain("'0=Control+space' '1=Hangul' '2=Alt_R'")
  })

  it('wizard detects fcitx5 addons by their addon .conf, finds sway, and saves on Next', () => {
    const lb = read('electron/localboot.cjs')
    expect(lb).toContain("'/usr/share/fcitx5/addon'")
    expect(lb).not.toMatch(/\$\{m\.addon\}\.so/)
    expect(lb).toContain('sway-ipc')
    expect(lb).toContain('await autoScale()')
    const js = read('electron/boot-wizard.js')
    expect(js).toContain("state.saveOnNext = () => $('#savelang').onclick()")
    expect(js).toContain("state.saveOnNext = () => $('#savedisp').onclick()")
  })

  it('electron main runs the local wizard and power guard only in the local kiosk', () => {
    const m = read('electron/main.cjs')
    expect(m).toContain("require('./localboot.cjs')")
    expect(m).toContain('localboot.early()')
    expect(m).toContain('localboot.guardWindow(win)')
    expect(m).toMatch(/localboot\.ACTIVE && process\.env\.NEUOS_WIZARD !== '0'/)
    const lb = read('electron/localboot.cjs')
    expect(lb).toContain("process.env.NEUOS_LOCAL_BOOT === '1'")
    expect(lb).toContain("refusing to write empty")
    const html = read('electron/boot-wizard.html')
    expect(html).toContain('boot-wizard.js')
    const js = read('electron/boot-wizard.js')
    for (const step of ['logo', 'diag', 'net', 'lang', 'display', 'llm', 'login', 'finish']) expect(js).toContain(`id: '${step}'`)
  })
})

describe('localboot helpers', async () => {
  const { createRequire } = await import('node:module')
  const req = createRequire(import.meta.url)
  it('splits nmcli terse output with escaped colons', async () => {
    const Module = req('node:module')
    const orig = Module._load
    Module._load = function (name: string, ...rest: unknown[]) {
      if (name === 'electron') return { app: { commandLine: { appendSwitch() {} } }, BrowserWindow: class {}, dialog: {} }
      return orig.call(this, name, ...rest)
    }
    try {
      const lb = req('../electron/localboot.cjs')
      expect(lb.splitTerse('*:My\\:Net:80:WPA2')).toEqual(['*', 'My:Net', '80', 'WPA2'])
      const p = lb.fcitxProfile(['hangul'])
      expect(p).toContain('Name=keyboard-us')
      expect(p).toContain('DefaultIM=hangul')
    } finally {
      Module._load = orig
    }
  })
})
