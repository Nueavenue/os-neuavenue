import { mkdtempSync, rmSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  defaultLlmSettings,
  llmReady,
  ollamaInstallHint,
  readLlmSettings,
  wantsLocalModel,
  writeLlmSettings,
} from './localLlm.mjs'

const roots: string[] = []

function tmpRoot() {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'neuos-llm-'))
  roots.push(dir)
  return dir
}

afterEach(() => {
  vi.unstubAllGlobals()
  for (const dir of roots.splice(0)) {
    rmSync(dir, { recursive: true, force: true })
  }
})

describe('local public AI settings', () => {
  it('treats os.neu-local as the on-device model', () => {
    expect(wantsLocalModel('os.neu-local')).toBe(true)
    expect(wantsLocalModel('gpt-4o-mini')).toBe(false)
  })

  it('stores an optional user key without calling it a shared key', () => {
    const root = tmpRoot()
    expect(readLlmSettings(root)).toEqual(defaultLlmSettings())
    const next = writeLlmSettings({ openaiKey: 'sk-user' }, root)
    expect(next.openaiKey).toBe('sk-user')
    expect(readLlmSettings(root).openaiKey).toBe('sk-user')
  })

  it('explains how to install Ollama when it is missing', () => {
    const hint = ollamaInstallHint()
    expect(hint.reason).toBe('ollama-missing')
    expect(hint.command).toContain('ollama.com/install.sh')
  })

  it('reports ready when Ollama lists a model', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({
        ok: true,
        json: async () => ({ models: [{ name: 'llama3.2:1b' }] }),
      })),
    )
    const ready = await llmReady(tmpRoot())
    expect(ready.ok).toBe(true)
    expect(ready.via).toBe('local')
  })

  it('is not ready when Ollama is down and no user key is saved', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('offline')
      }),
    )
    const ready = await llmReady(tmpRoot())
    expect(ready.ok).toBe(false)
    expect(ready.via).toBe('none')
  })
})
