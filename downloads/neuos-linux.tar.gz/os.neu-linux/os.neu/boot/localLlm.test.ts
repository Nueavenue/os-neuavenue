import { existsSync, mkdtempSync, rmSync, statSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  defaultLlmSettings,
  llmReady,
  numPredictFor,
  ollamaInstallHint,
  ollamaTag,
  pullRoom,
  readLlmSettings,
  wantsLocalModel,
  writeLlmSettings,
  llmCloudFallbackReason,
  llmSettingsPath,
  ALLOWED_VENDOR_IDS,
  KEY_VALUE_MAX,
} from './localLlm.mjs'

const roots: string[] = []

function tmpRoot() {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'neuos-llm-'))
  roots.push(dir)
  return dir
}

afterEach(() => {
  vi.unstubAllGlobals()
  for (const dir of roots.splice(0)) {
    rmSync(dir, { recursive: true, force: true })
  }
})

describe('local public AI settings', () => {
  it('treats os.neu-local as the on-device model', () => {
    expect(wantsLocalModel('os.neu-local')).toBe(true)
    expect(wantsLocalModel('llama3.1:8b')).toBe(true)
    expect(wantsLocalModel('gpt-4o-mini')).toBe(false)
    expect(ollamaTag('os.neu-local')).toBe('llama3.2:1b')
    expect(numPredictFor('llama3.2:1b')).toBe(120)
    expect(numPredictFor('llama3.1:8b')).toBe(1024)
  })

  it('refuses a large pull when free space cannot hold the file plus 1GB', () => {
    const tight = pullRoom('llama3.1:8b', 2_700_000_000)
    expect(tight.ok).toBe(false)
    expect(tight.reason).toBe('disk')
    const roomy = pullRoom('llama3.2:1b', 20_000_000_000)
    expect(roomy.ok).toBe(true)
  })

  it('stores an optional user key without calling it a shared key', () => {
    const root = tmpRoot()
    expect(readLlmSettings(root)).toEqual(defaultLlmSettings())
    const next = writeLlmSettings({ openaiKey: 'sk-user' }, root)
    expect(next.openaiKey).toBe('sk-user')
    expect(readLlmSettings(root).openaiKey).toBe('sk-user')
  })

  it('explains how to install Ollama when it is missing', () => {
    const hint = ollamaInstallHint()
    expect(hint.reason).toBe('ollama-missing')
    expect(hint.command).toContain('ollama.com/install.sh')
  })

  it('reports ready when Ollama lists a model', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({
        ok: true,
        json: async () => ({ models: [{ name: 'llama3.2:1b' }] }),
      })),
    )
    const ready = await llmReady(tmpRoot())
    expect(ready.ok).toBe(true)
    expect(ready.via).toBe('local')
  })

  it('does not treat Auto + os.neu-local as local-unavailable when Ollama is down', () => {
    expect(
      llmCloudFallbackReason({ provider: 'auto', localUp: false, hasKey: false, forceCloud: false }),
    ).toBe('no-llm')
    expect(
      llmCloudFallbackReason({ provider: 'auto', localUp: false, hasKey: true, forceCloud: false }),
    ).toBe('')
    expect(
      llmCloudFallbackReason({ provider: 'local', localUp: false, hasKey: false, forceCloud: false }),
    ).toBe('local-unavailable')
  })

  it('ignores dest, drops unknown vendors, caps value length, and writes owner-read only', () => {
    const root = tmpRoot()
    writeLlmSettings(
      {
        dest: '/tmp/osneu-should-not-receive-llm',
        openaiKey: 'sk-user',
        vendorKeys: {
          openai: 'ok-vendor',
          evil: 'nope',
          anthropic: 'a'.repeat(KEY_VALUE_MAX + 1),
        },
      },
      root,
    )
    const next = readLlmSettings(root)
    expect(next).not.toHaveProperty('dest')
    expect(existsSync('/tmp/osneu-should-not-receive-llm/data/user-llm.json')).toBe(false)
    expect(next.vendorKeys.openai).toBe('ok-vendor')
    expect(next.vendorKeys.evil).toBeUndefined()
    expect(next.vendorKeys.anthropic).toBeUndefined()
    expect(ALLOWED_VENDOR_IDS).toContain('openai')
    const mode = statSync(llmSettingsPath(root)).mode & 0o777
    expect(mode).toBe(0o600)
    expect(statSync(llmSettingsPath(root)).size).toBeGreaterThan(1)
  })

  it('is not ready when Ollama is down and no user key is saved', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('offline')
      }),
    )
    const ready = await llmReady(tmpRoot())
    expect(ready.ok).toBe(false)
    expect(ready.via).toBe('none')
  })
})
