#!/usr/bin/env python3
"""Drive the QEMU virtio tablet like a user: move, click the landing box, type.

Events go through QEMU's input layer to the current mouse (the harness selects
the virtio tablet), exactly where host GTK pointer events go. This proves the
guest side of the chain; it does not touch the host desktop.
"""

import json
import socket
import sys
import time

W, H = 1280, 800
ABS_MAX = 32767


def receive(stream) -> dict:
    line = stream.readline()
    if not line:
        raise RuntimeError("QMP connection closed")
    return json.loads(line)


def command(stream, name, arguments=None):
    msg = {"execute": name}
    if arguments is not None:
        msg["arguments"] = arguments
    stream.write(json.dumps(msg).encode() + b"\r\n")
    while True:
        reply = receive(stream)
        if "return" in reply or "error" in reply:
            return reply


def abs_move(x, y):
    return [
        {"type": "abs", "data": {"axis": "x", "value": int(x * ABS_MAX / W)}},
        {"type": "abs", "data": {"axis": "y", "value": int(y * ABS_MAX / H)}},
    ]


def button(down):
    return [{"type": "btn", "data": {"down": down, "button": "left"}}]


def key(qcode, down):
    return [{"type": "key", "data": {"down": down, "key": {"type": "qcode", "data": qcode}}}]


QCODE = {" ": "spc", ".": "dot", "-": "minus", "/": "slash"}


def tap(stream, qcode):
    command(stream, "input-send-event", {"events": key(qcode, True)})
    time.sleep(0.04)
    command(stream, "input-send-event", {"events": key(qcode, False)})
    time.sleep(0.06)


def type_command(stream, text, at=(637, 557)):
    """Click the landing box at `at`, replace its text, type `text`, press Enter.

    The box sits lower on the fresh landing and moves up once the console
    has output, so callers pass where it is for that stage.
    """
    cx, cy = at
    command(stream, "input-send-event", {"events": abs_move(cx, cy)})
    time.sleep(0.2)
    command(stream, "input-send-event", {"events": button(True)})
    time.sleep(0.08)
    command(stream, "input-send-event", {"events": button(False)})
    time.sleep(0.4)
    command(stream, "input-send-event", {"events": key("ctrl", True)})
    tap(stream, "a")
    command(stream, "input-send-event", {"events": key("ctrl", False)})
    tap(stream, "backspace")
    for ch in text.lower():
        q = QCODE.get(ch, ch)
        if not (len(q) == 1 and (q.isalnum())) and q not in QCODE.values():
            print(f"skip unsupported char {ch!r}", file=sys.stderr)
            continue
        tap(stream, q)
    tap(stream, "ret")
    print(f"typed command {text!r} + Enter in the landing box")


def main() -> int:
    if len(sys.argv) not in (2, 4, 5) or (len(sys.argv) >= 4 and sys.argv[2] != "type"):
        print("usage: qmp-input-probe.py <qmp.sock> [type '<text>' [x,y]]", file=sys.stderr)
        return 2
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(sys.argv[1])
        stream = client.makefile("rwb", buffering=0)
        receive(stream)
        command(stream, "qmp_capabilities")
        mice = command(stream, "query-mice").get("return", [])
        print("mice " + json.dumps(mice))
        if len(sys.argv) >= 4:
            at = (637, 557)
            if len(sys.argv) == 5:
                x, y = sys.argv[4].split(",")
                at = (int(x), int(y))
            type_command(stream, sys.argv[3], at)
            return 0
        for step in range(24):
            x = 200 + step * 40
            y = 200 + step * 15
            r = command(stream, "input-send-event", {"events": abs_move(x, y)})
            if "error" in r:
                print("move error " + json.dumps(r), file=sys.stderr)
                return 1
            time.sleep(0.05)
        # "Tell me what you want to do" box on the 1280x800 landing.
        cx, cy = 637, 557
        command(stream, "input-send-event", {"events": abs_move(cx, cy)})
        time.sleep(0.2)
        command(stream, "input-send-event", {"events": button(True)})
        time.sleep(0.08)
        command(stream, "input-send-event", {"events": button(False)})
        time.sleep(0.5)
        for q in ("h", "i"):
            command(stream, "input-send-event", {"events": key(q, True)})
            time.sleep(0.05)
            command(stream, "input-send-event", {"events": key(q, False)})
            time.sleep(0.1)
        print("probe sent: 25 moves, 1 left click at (637,557), keys h i")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
