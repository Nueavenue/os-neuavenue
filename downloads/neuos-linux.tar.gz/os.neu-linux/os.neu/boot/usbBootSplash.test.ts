import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
// @ts-expect-error plain ESM module without types
import { STEPS, TITLE, normalizeState, renderFrame, setStep, toPpm } from './splash/osneu-splash.mjs'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (path: string) => readFileSync(join(root, path), 'utf8')

describe('USB boot splash', () => {
  it('shows the four Leader-specified steps under the runtime title', () => {
    expect(TITLE).toBe('Initializing AI runtime\u2026')
    expect(STEPS).toEqual([
      'Mounting os.neu runtime',
      'Starting daf.neu network',
      'Connecting app.neu',
      'Preparing AI workspace',
    ])
  })

  it('renders a dark navy frame with the logo in the centre', () => {
    const cv = renderFrame({ steps: ['ok', 'run'] }, 320, 200)
    const px = (x: number, y: number) => Array.from(cv.px.slice((y * cv.w + x) * 3, (y * cv.w + x) * 3 + 3)) as number[]
    const [r, g, b] = px(2, 2)
    expect(b).toBeGreaterThan(r)
    expect(r + g + b).toBeLessThan(90)
    let lit = 0
    for (let y = 50; y < 90; y++) for (let x = 140; x < 180; x++) if (px(x, y).some((v) => v > 80)) lit++
    expect(lit).toBeGreaterThan(20)
    expect(toPpm(cv).subarray(0, 2).toString()).toBe('P6')
  })

  it('normalises unknown states and never touches a framebuffer off JeOS', () => {
    expect(normalizeState({ steps: ['ok', 'bogus'] }).steps).toEqual(['ok', 'pending', 'pending', 'pending'])
    expect(setStep(1, 'ok')).toEqual({ ok: false, reason: 'not-jeos' })
  })
})

describe('USB boot entries, autostart and diagnostics wiring', () => {
  const make = read('scripts/make-usb.sh')
  const init = read('boot/init/neuos-init')
  const screen = read('scripts/usb-screen-jeos.sh')
  const kernel = read('boot/kernel.mjs')
  const netdiag = read('scripts/osneu-netdiag.mjs')
  const harness = read('boot/try-qemu.sh')

  it('makes os.neu (splash + autostart) the default GRUB entry and keeps virt indexes', () => {
    const cfg = make.slice(make.indexOf('cat > "$STAGE/boot/grub/grub.cfg"'))
    const entries = [...cfg.matchAll(/menuentry "([^"]+)"/g)].map((m) => m[1])
    expect(entries.slice(0, 6)).toEqual([
      'os.neu',
      'neuOS (this ISO)',
      'neuOS automated GUI test',
      'os.neu (this ISO, splash + autostart)',
      'os.neu console (no autostart)',
      'os.neu network check (text)',
    ])
    expect(cfg).toContain('quiet loglevel=3 vt.global_cursor_default=0 init=/usr/sbin/neuos-init neuos.autostart=1 neuos.splash=1')
    expect(make).toContain("sed -i 's/^set default=0$/set default=3/'")
    expect(make).toContain('stage_splash_assets')
  })

  it('gives a USB stick one top-level os.neu entry, console and network check under Advanced', () => {
    const usb = make.slice(make.indexOf('if [[ -n "$DEVICE" ]]; then\n    cat > "$STAGE/boot/grub/grub.cfg"'))
    const body = usb.slice(0, usb.indexOf('\nEOF'))
    const top = body.split('\n').filter((l) => /^(menuentry|submenu) /.test(l))
    expect(top).toEqual(['menuentry "os.neu" {', 'submenu "Advanced (console · network check)" {'])
    const entries = [...body.matchAll(/menuentry "([^"]+)"/g)].map((m) => m[1])
    expect(entries).toEqual(['os.neu', 'os.neu console (type open.neu)', 'os.neu network check (text)'])
    expect(body).not.toContain('neuos.test=')
    expect(body.match(/root=LABEL=NEUOS-ROOT rw/g)?.length).toBe(3)
  })

  it('never mounts the PC internal disks while looking for NEUOS-ROOT', () => {
    const live = read('boot/live/init')
    const tryDev = live.slice(live.indexOf('try_dev() {'), live.indexOf('try_named() {'))
    expect(tryDev.indexOf('may_mount "$_dev" || return 1')).toBeGreaterThan(-1)
    expect(tryDev.indexOf('may_mount "$_dev" || return 1')).toBeLessThan(tryDev.indexOf('mount -t ext4'))
    const may = live.slice(live.indexOf('may_mount() {'), live.indexOf('try_dev() {'))
    expect(may).toContain('[ "$(label_of "$1")" = "NEUOS-ROOT" ] && return 0')
    expect(may).toContain('[ "$(removable_of "$1")" = "1" ]')
    expect(make).toContain('ln -sf busybox readlink')
  })

  it('waits two minutes for a slow stick and tells the user to change the port', () => {
    const live = read('boot/live/init')
    expect(live).toContain('ROOT_WAIT=120')
    expect(live).toContain('while [ "$i" -lt "$ROOT_WAIT" ]; do')
    expect(live).toContain('use a black USB 2.0 port')
    expect(live).not.toContain('payload not found after 40s')
  })

  it('launches Electron without GBM on the stick and pins libgbm1 to the staged libgallium', () => {
    const screen = read('scripts/usb-screen-jeos.sh')
    expect(screen).toContain(`echo "gpu='--disable-gpu'"`)
    expect(screen).toContain('retry under strace')
    const launches = screen.split('\n').filter((l) => l.includes("'$ELECTRON' '$APP'"))
    expect(launches.length).toBe(2)
    for (const l of launches) expect(l).not.toMatch(/ozone-platform=drm/)
    expect(screen).toContain("ELECTRON_ENABLE_STACK_DUMPING=1 '$ELECTRON' '$APP'")
    expect(screen).toContain("ELECTRON_ENABLE_STACK_DUMPING=1 \\$tr '$ELECTRON' '$APP'")
    expect(screen).toContain('-o /tmp/strace-electron.txt')
    expect(screen).not.toContain('/tmp/osneu-ld')
    expect(read('scripts/input-diag.mjs')).toContain("'/tmp/osneu-electron-crash.txt'")
    expect(make).toContain('/usr/bin/strace; do')
    for (const p of ['probe version', 'probe node', 'probe minapp-']) expect(screen).toContain(p)
    expect(screen).toContain("'framed-menu 1 1' 'framed-nomenu 1 0' 'frameless-menu 0 1' 'frameless-nomenu 0 0'")
    const main = read('electron/main.cjs')
    expect(main).toContain("process.env.NEUOS_JEOS === '1' && process.env.NEUOS_FRAME !== '1'")
    expect(main).toContain('? { frame: false, hasShadow: false }')
    expect(main.split('...JEOS_FRAME,').length - 1).toBe(4)
    expect(screen).toContain("'$APP/scripts/electron-minapp'")
    expect(read('scripts/electron-minapp/main.cjs')).toContain("mark('loaded')")
    expect(make).toContain("gbm_pkg=\"libgbm1${gbm_ver:+=$gbm_ver}\"")
    expect(make).toContain('/usr/lib/x86_64-linux-gnu/libgallium-*.so')
  })

  it('rewrites and reads back the stick electron by content, not size and mtime', () => {
    const screen = read('scripts/usb-screen-jeos.sh')
    expect(make).toContain("rsync -a --checksum --exclude='/bin' --exclude='/sbin'")
    expect(make).toContain('verify_electron_readback "$mnt" || return 1')
    expect(make.split('if ! verify_jeos_root "$ROOT_MNT"; then').length - 1).toBe(2)
    expect(make).toContain('echo 3 > /proc/sys/vm/drop_caches')
    expect(make).toContain('cmp "$STAGE/$rel" "$mnt/$rel"')
    expect(make).toContain('sha256sum electron > electron.sha256')
    expect(screen).toContain('/usr/bin/busybox sha256sum -c electron.sha256')
    expect(make).not.toMatch(/^clri <52428[90]>$/m)
    expect(make).toContain('($NF == "bin" || $NF == "sbin")')
  })

  it('never stages the builder key or personal data into the image', () => {
    for (const f of ['user-llm.json', 'accounts.json', 'oauth-handoff.json', 'browse-ledger.json']) {
      expect(make).toContain(`--exclude /data/${f}`)
    }
    expect(make).toContain('builder secrets/personal data staged into the image')
  })

  it('starts the splash in PID 1 before module loading, without a GPU driver', () => {
    expect(init).toContain('"$NODE" "$SPLASH_JS" show')
    expect(init.indexOf('"$SPLASH_JS" show')).toBeLessThan(init.indexOf('for m in ahci'))
    expect(init).toContain('`open os.neu` loads GPU')
  })

  it('runs diagnostics before the window and releases the splash to cage', () => {
    expect(screen.indexOf('netdiag connect --quiet')).toBeLessThan(screen.indexOf('if try_cage; then'))
    expect(screen.indexOf('netdiag ai --quiet')).toBeLessThan(screen.indexOf('splash release'))
    expect(screen.indexOf('splash release')).toBeLessThan(screen.indexOf('if try_cage; then'))
    expect(screen).toMatch(/trap '[^']*splash quit[^']*bootlog mark screen-exit[^']*' EXIT/)
    expect(screen).toContain('NETDIAG_JS" watch')
    expect(screen).not.toMatch(/'\$ELECTRON' '\$APP'[^\n]*ozone-platform=drm/)
  })

  it('autostarts once per boot straight into the screen, no display manager', () => {
    expect(kernel).toContain("bootArg('neuos.autostart=1')")
    expect(kernel).toContain('/run/osneu-autostart.done')
    expect(kernel).toContain('NEUOS_AUTOSTART_BEGIN')
    expect(kernel).toContain("bootArg('neuos.netdiag=console')")
    expect(kernel.indexOf('await runOpenScreen()')).toBeLessThan(kernel.indexOf('await quitSplash()'))
    const boot = kernel.slice(kernel.indexOf('async function bootActions'), kernel.indexOf("if (process.env.NEUOS_JEOS === '1') {\n  console.log('JeOS console."))
    expect(boot).toContain('await runOpenScreen()')
    expect(boot).not.toMatch(/gdm|lightdm|sddm/i)
  })

  it('checks in the Leader order and never prints a key value', () => {
    const order = ['checkLink()', 'checkWifi()', 'await checkDns()', 'await checkClock()', 'await checkProxy()', 'await checkTls()', 'await checkAppNeu()', 'await checkDaf()']
    const body = netdiag.slice(netdiag.indexOf('async function connect()'))
    const idx = order.map((s) => body.indexOf(s))
    expect(idx.every((v) => v >= 0)).toBe(true)
    expect([...idx].sort((a, b) => a - b)).toEqual(idx)
    expect(netdiag).toContain("'https://os.neuavenue.com/api/health'")
    expect(netdiag).toContain('https://api.openai.com/v1/models')
    expect(netdiag.match(/\$\{key\}/g)?.length).toBe(1)
    expect(netdiag).toContain('const FIX = JEOS &&')
    expect(harness).toContain('NEUOS_VIRT_AUTOSTART')
  })
})

describe('USB boot recorder (NEUOS-ESP/osneu-logs)', () => {
  const bootlog = read('scripts/osneu-bootlog.sh')
  const pull = read('scripts/usb-logs-pull.sh')
  const init = read('boot/init/neuos-init')
  const screen = read('scripts/usb-screen-jeos.sh')
  const make = read('scripts/make-usb.sh')

  it('runs only on the JeOS stick and never copies personal data', () => {
    expect(bootlog).toContain('[ "$NEUOS_JEOS" = "1" ] || exit 0')
    expect(bootlog).toContain('[ -f /etc/neuos-release ] || exit 0')
    const code = bootlog.split('\n').filter((l) => !l.trimStart().startsWith('#')).join('\n')
    expect(code).not.toMatch(/\/opt\/neuos\/data|user-llm|accounts\.json/)
    expect(code).toContain('for f in /tmp/osneu-* /tmp/weston/*.log /run/osneu-splash.json; do')
    expect(bootlog).toContain('iocharset=cp437')
  })

  it('records every boot stage, with a background snapshot for hangs', () => {
    expect(init).toContain('bootlog mark hold')
    expect(init).toContain('bootlog mark init')
    expect(init).toContain('"$BOOTLOG" watch')
    expect(init).toContain('bootlog mark node-exit')
    expect(init.indexOf('bootlog mark init')).toBeLessThan(init.indexOf('starting $NODE $KERNEL'))
    expect(screen).toContain('bootlog mark screen-start')
    expect(screen.indexOf('bootlog mark compositor-start')).toBeLessThan(screen.indexOf('if try_cage; then'))
  })

  it('never makes the boot wait for a snapshot and logs each screen step straight to the stick', () => {
    const mark = bootlog.slice(bootlog.indexOf('  mark)'), bootlog.indexOf('  note)'))
    expect(mark).toContain('( locked snap ) </dev/null >/dev/null 2>&1 &')
    expect(mark).not.toMatch(/^\s+locked snap\s*$/m)
    expect(bootlog).toContain('stage_line "watch t=${t}s"')
    expect(bootlog).toContain('bb rmdir "$LOCK"')
    expect(bootlog).not.toMatch(/^\s*rmdir /m)
    expect(bootlog).toContain('lock stuck (cannot clear $LOCK)')
    expect(make).toMatch(/for a in mkdir rmdir ls cat/)
    for (const s of ['kmods-start', 'kmods-done', 'netdiag-connect', 'netdiag-connect-done', 'netdiag-ai-done']) {
      expect(screen).toContain(`bootlog note ${s}`)
    }
  })

  it('stages the FAT charset module and reads the stick back read-only', () => {
    expect(make).toMatch(/for mod in nls_iso8859-1 nls_utf8/)
    expect(make).toContain('osneu-bootlog.sh')
    expect(pull).toContain('-o ro')
    expect(pull).toContain('REFUSE')
    expect(pull).not.toMatch(/\brm\b|mkfs|dd |--yes/)
  })
})
