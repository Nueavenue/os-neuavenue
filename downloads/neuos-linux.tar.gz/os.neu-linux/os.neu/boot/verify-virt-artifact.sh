#!/usr/bin/env bash
# Read-only verification of a staged virtual JeOS image.
set -euo pipefail

STAGE="${1:-}"
ISO="${2:-}"
if [[ -z "$STAGE" || -z "$ISO" ]]; then
  echo "usage: bash boot/verify-virt-artifact.sh <stage-dir> <iso>" >&2
  exit 2
fi

required=(
  boot/vmlinuz
  boot/initrd.img
  boot/grub/grub.cfg
  proc
  sys
  mnt
  etc/neuos-release
  etc/resolv.conf
  usr/sbin/neuos-init
  usr/bin/dash
  usr/bin/udevadm
  usr/lib/systemd/systemd-udevd
  usr/share/libinput/10-generic-keyboard.quirks
  usr/lib/x86_64-linux-gnu/libva.so.2
  usr/lib/x86_64-linux-gnu/libva-drm.so.2
  usr/lib/x86_64-linux-gnu/libweston-14/drm-backend.so
  opt/neuos/runtime/electron/electron
  usr/lib/x86_64-linux-gnu/libsoftokn3.so
  usr/lib/x86_64-linux-gnu/libfreeblpriv3.so
  usr/lib/x86_64-linux-gnu/libnssckbi.so
  usr/share/fonts/truetype/nanum/NanumGothic.ttf
  opt/neuos/scripts/usb-screen-jeos.sh
  opt/neuos/scripts/virt-gui-client.sh
  opt/neuos/scripts/input-diag.mjs
  usr/share/icons/DMZ-White/cursors
  usr/share/icons/default/index.theme
  usr/lib/udev/rules.d/61-neuos-virt-input.rules
  usr/lib/udev/hwdb.bin
)
for rel in "${required[@]}"; do
  if [[ ! -e "$STAGE/$rel" ]]; then
    echo "FAIL: staged virtual artifact missing $rel" >&2
    exit 3
  fi
done

if [[ ! -f "$ISO" ]]; then
  echo "FAIL: ISO missing: $ISO" >&2
  exit 3
fi
if command -v xorriso >/dev/null; then
  if ! xorriso -indev "$ISO" -find /usr/sbin/neuos-init -exec lsdl -- 2>/dev/null \
    | grep -q 'r-x'; then
    echo "FAIL: ISO neuos-init is not executable (RockRidge)" >&2
    exit 3
  fi
fi
grep -Fq 'console=ttyS0,115200n8' "$STAGE/boot/grub/grub.cfg"
grep -Fq 'neuos.test=gui' "$STAGE/boot/grub/grub.cfg"
lsinitramfs "$STAGE/boot/initrd.img" | grep -Fq 'usb-screen-jeos.sh'

ldpath="$STAGE/usr/lib/x86_64-linux-gnu:$STAGE/usr/lib/x86_64-linux-gnu/libweston-14:$STAGE/usr/lib/x86_64-linux-gnu/weston"
if LD_LIBRARY_PATH="$ldpath" ldd "$STAGE/usr/lib/x86_64-linux-gnu/libweston-14/drm-backend.so" \
  | grep -Fq 'not found'; then
  echo "FAIL: Weston DRM backend has unresolved libraries" >&2
  exit 4
fi

echo "PASS: virtual JeOS artifact is self-contained"

