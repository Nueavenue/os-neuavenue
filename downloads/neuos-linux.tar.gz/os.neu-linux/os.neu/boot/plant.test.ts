import { describe, expect, it } from 'vitest'
import os from 'node:os'
import path from 'node:path'
import { assertSafePlantDest, canLaunchGraphicalScreen, defaultPlantDir, ensureOsNeuFolder, isPlantCommand, isUninstallCommand, launchScreen, linuxDesktopFile, linuxUserService, shouldSkip } from './plant.mjs'
import { destIsUsbStick } from './hostVolume.mjs'

describe('os.neu plant', () => {
  it('recognizes uninstall os.neu', () => {
    expect(isUninstallCommand('uninstall os.neu')).toBe(true)
    expect(isUninstallCommand('os.neu 제거')).toBe(true)
    expect(isUninstallCommand('install os.neu')).toBe(false)
  })

  it('recognizes the console install command', () => {
    expect(isPlantCommand('install os.neu')).toBe(true)
    expect(isPlantCommand('INSTALL OS.NEU')).toBe(true)
    expect(isPlantCommand('install firefox')).toBe(false)
  })

  it('defaults to the home os.neu folder', () => {
    expect(defaultPlantDir()).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('creates os.neu under a chosen parent', () => {
    expect(ensureOsNeuFolder(os.homedir())).toBe(path.join(os.homedir(), 'os.neu'))
    expect(ensureOsNeuFolder(path.join(os.homedir(), 'os.neu'))).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('refuses block devices and system roots', () => {
    expect(() => assertSafePlantDest('/dev/sda')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/proc/self')).toThrow('unsafe-dest')
  })

  it('does not copy secrets or builder keys onto a planted tree', () => {
    expect(shouldSkip('.env')).toBe(true)
    expect(shouldSkip('.env.local')).toBe(true)
    expect(shouldSkip('user-llm.json')).toBe(true)
    expect(shouldSkip('accounts.json')).toBe(true)
    expect(shouldSkip('kernel.mjs')).toBe(false)
  })

  it('does not launch Electron on the USB JeOS console', () => {
    const prev = process.env.NEUOS_JEOS
    process.env.NEUOS_JEOS = '1'
    expect(canLaunchGraphicalScreen()).toBe(false)
    if (prev === undefined) delete process.env.NEUOS_JEOS
    else process.env.NEUOS_JEOS = prev
  })

  it('writes a Linux launcher that does not require cd', () => {
    const body = linuxDesktopFile({
      execRoot: '/home/billy-lee/os.neu',
      icon: 'os.neu',
    })
    expect(body).toContain('Exec=bash /home/billy-lee/os.neu/scripts/open-neuos.sh')
    expect(body).toContain('Categories=Network;WebBrowser;')
    expect(body).toContain('Icon=os.neu')
    expect(linuxUserService({ execRoot: '/home/billy-lee/os.neu' })).toContain('WantedBy=graphical-session.target')
  })

  it('USB install launches the host-chroot screen path, not a stick folder', () => {
    const prev = process.env.NEUOS_JEOS
    const dry = process.env.NEUOS_USB_SCREEN_DRY
    process.env.NEUOS_JEOS = '1'
    process.env.NEUOS_USB_SCREEN_DRY = '1'
    try {
      expect(destIsUsbStick('/os.neu')).toBe(true)
      const launched = launchScreen('/mnt/osneu-host/home/billy-lee/os.neu', 'lui', {
        host: {
          mount: '/mnt/osneu-host',
          user: 'billy-lee',
          osNeuRel: '/home/billy-lee/os.neu',
        },
      })
      expect(launched.ok).toBe(true)
      expect(launched.via).toBe('usb-host')
    } finally {
      if (prev === undefined) delete process.env.NEUOS_JEOS
      else process.env.NEUOS_JEOS = prev
      if (dry === undefined) delete process.env.NEUOS_USB_SCREEN_DRY
      else process.env.NEUOS_USB_SCREEN_DRY = dry
    }
  })
})
