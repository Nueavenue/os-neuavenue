#!/usr/bin/env python3
"""Fail when a QMP PPM screenshot is effectively all black."""

import sys
from pathlib import Path


def tokens_and_pixels(raw: bytes) -> bytes:
    index = 0
    tokens: list[bytes] = []
    while len(tokens) < 4:
        while index < len(raw) and raw[index] in b" \t\r\n":
            index += 1
        if index < len(raw) and raw[index] == ord("#"):
            while index < len(raw) and raw[index] != ord("\n"):
                index += 1
            continue
        start = index
        while index < len(raw) and raw[index] not in b" \t\r\n":
            index += 1
        tokens.append(raw[start:index])
    while index < len(raw) and raw[index] in b" \t\r\n":
        index += 1
    if tokens[0] != b"P6" or int(tokens[3]) != 255:
        raise ValueError("unsupported PPM")
    return raw[index:]


pixels = tokens_and_pixels(Path(sys.argv[1]).read_bytes())
lit = sum(1 for value in pixels if value > 8)
if lit < 1000:
    print(f"FAIL: GUI screenshot is black (lit_bytes={lit})", file=sys.stderr)
    raise SystemExit(1)
print(f"PASS: GUI screenshot has visible pixels (lit_bytes={lit})")

