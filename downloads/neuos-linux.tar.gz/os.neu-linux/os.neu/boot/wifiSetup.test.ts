import { pbkdf2Sync } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
// @ts-expect-error plain ESM module without types
import { networkBlock, parseScan, security, unescapeSsid } from '../scripts/osneu-wifi.mjs'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (path: string) => readFileSync(join(root, path), 'utf8')

describe('osneu-wifi helper', () => {
  it('keeps the strongest BSS per SSID and labels security', () => {
    const text = [
      'bssid / frequency / signal level / flags / ssid',
      'aa:aa:aa:aa:aa:01\t2412\t-71\t[WPA2-PSK-CCMP][ESS]\tHome',
      'aa:aa:aa:aa:aa:02\t5180\t-48\t[WPA2-PSK-CCMP][ESS]\tHome',
      'bb:bb:bb:bb:bb:01\t2437\t-60\t[ESS]\tCafe Free',
      'cc:cc:cc:cc:cc:01\t5200\t-66\t[RSN-SAE-CCMP][ESS]\tWPA3 Only',
      'dd:dd:dd:dd:dd:01\t2462\t-80\t[ESS]\t',
    ].join('\n')
    const nets = parseScan(text)
    expect(nets.map((n: { ssid: string }) => n.ssid)).toEqual(['Home', 'Cafe Free', 'WPA3 Only'])
    expect(nets[0]).toMatchObject({ signal: -48, freq: 5180, security: 'WPA2' })
    expect(nets[1].security).toBe('Open')
    expect(nets[2].security).toBe('WPA3')
    expect(security('[WPA2-EAP-CCMP][ESS]')).toBe('Enterprise')
  })

  it('decodes wpa_cli escaped SSIDs (Korean names)', () => {
    expect(unescapeSsid('\\xec\\x9a\\xb0\\xeb\\xa6\\xac\\xec\\xa7\\x91')).toBe('우리집')
    expect(unescapeSsid('a\\"b')).toBe('a"b')
  })

  it('writes the SSID as hex and the WPA2 key as a derived PSK', () => {
    const block = networkBlock('우리집', 'correct horse')
    expect(block).toContain(`ssid=${Buffer.from('우리집').toString('hex')}`)
    expect(block).toContain(`psk=${pbkdf2Sync('correct horse', '우리집', 4096, 32, 'sha1').toString('hex')}`)
    expect(block).toContain('key_mgmt=WPA-PSK WPA-PSK-SHA256 SAE')
    expect(networkBlock('Cafe', '')).toContain('key_mgmt=NONE')
    expect(networkBlock('X', 'has"quote')).not.toContain('sae_password')
  })

  it('never puts the password on a command line or outside RAM', () => {
    const src = read('scripts/osneu-wifi.mjs')
    expect(src).toContain("const CONF = `${RUN}/wpa.conf`")
    expect(src).toContain("const RUN = '/run/osneu-wifi'")
    expect(src).toContain('mode: 0o600')
    expect(src).not.toMatch(/save_config|set_network/)
    expect(src).toContain("readFileSync(0, 'utf8')")
    expect(src).not.toMatch(/log\([^)]*password/)
    const page = read('electron/wifi.js')
    expect(page).not.toMatch(/localStorage|sessionStorage|indexedDB/)
    expect(page).toContain("$('pw').value = ''")
    expect(page).toContain("if (!pw && ssid === selected && !selectedOpen) return msg(")
  })
})

describe('boot setup window (blurred splash + Wi-Fi card)', () => {
  const main = read('electron/main.cjs')
  const preload = read('electron/wifi-preload.cjs')
  const html = read('electron/wifi.html')
  const make = read('scripts/make-usb.sh')

  it('opens only on an offline JeOS seat, before the main window, without quitting in between', () => {
    expect(main).toMatch(/if \(process\.env\.NEUOS_JEOS === '1' && \(!hasDefaultRoute\(\) \|\| process\.env\.NEUOS_SETUP === '1'\)\) \{\s*setupBeforeMain = true\s*await openSetup\(\)/)
    expect(main.indexOf('await openSetup()')).toBeLessThan(main.indexOf('    createWindow()\n    setupBeforeMain = false'))
    expect(main).toContain('if (setupBeforeMain) return')
  })

  it('wires every preload channel to a handler on the setup window only', () => {
    const channels = [...preload.matchAll(/invoke\('([^']+)'/g)].map((m) => m[1])
    expect(channels.sort()).toEqual(['setup:diag', 'setup:done', 'setup:wifi:connect', 'setup:wifi:scan', 'setup:wifi:status'])
    for (const ch of channels) expect(main).toMatch(new RegExp(`(wc|setupWin\\.webContents)\\.ipc\\.handle\\('${ch}'`))
    expect(main).not.toMatch(/ipcMain\.handle\('setup:/)
  })

  it('shows the splash steps under a blur with a CSP and no remote code', () => {
    for (const s of ['Mounting os.neu runtime', 'Starting daf.neu network', 'Connecting app.neu', 'Preparing AI workspace']) expect(html).toContain(s)
    expect(html).toContain("script-src 'self'")
    expect(html).toMatch(/body\.blur #splash \{ filter: blur\(/)
    expect(html).not.toMatch(/https?:\/\//)
  })

  it('stages Wi-Fi drivers, firmware and the supplicant on the stick', () => {
    expect(make).toMatch(/for mod in rtw88_8822bu rtw88_8821cu/)
    expect(make).toContain('/lib/firmware/rtw88')
    expect(make).toContain('regulatory.db')
    expect(make).toMatch(/for b in \/usr\/sbin\/wpa_supplicant \/usr\/sbin\/wpa_cli/)
  })
})
