#!/usr/bin/env bash
# Read-only verification of a retained QEMU evidence directory.
set -euo pipefail

RUN_DIR="${1:-}"
MODE="${2:-gui}"
if [[ -z "$RUN_DIR" ]]; then
  echo "usage: bash boot/verify-virt-run.sh <run-dir> [console|gui|failure]" >&2
  exit 2
fi
case "$MODE" in
  console|gui|failure) ;;
  *) echo "FAIL: mode must be console, gui, or failure" >&2; exit 2 ;;
esac

for name in neuos-live.iso OVMF_VARS.fd serial.log qemu.log screen.ppm; do
  if [[ ! -e "$RUN_DIR/$name" ]]; then
    echo "FAIL: evidence missing $RUN_DIR/$name" >&2
    exit 3
  fi
done
for name in neuos-live.iso OVMF_VARS.fd serial.log screen.ppm; do
  if [[ ! -s "$RUN_DIR/$name" ]]; then
    echo "FAIL: evidence is empty $RUN_DIR/$name" >&2
    exit 3
  fi
done
if [[ "$(dd if="$RUN_DIR/screen.ppm" bs=2 count=1 status=none)" != "P6" ]]; then
  echo "FAIL: screen.ppm is not a QMP PPM screenshot" >&2
  exit 4
fi

case "$MODE" in
  console)
    grep -Fq 'JeOS console. Type open os.neu' "$RUN_DIR/serial.log"
    ;;
  gui)
    grep -Fq 'NEUOS_UDEV_READY' "$RUN_DIR/serial.log"
    grep -Fq 'NEUOS_VIRT_COMPOSITOR_READY' "$RUN_DIR/serial.log"
    grep -Fq 'NEUOS_VIRT_GUI_OK' "$RUN_DIR/serial.log"
    grep -Fq 'NEUOS_VIRT_WINDOW_OK' "$RUN_DIR/serial.log"
    python3 "$(dirname "$0")/check-ppm.py" "$RUN_DIR/screen.ppm"
    ;;
  failure)
    echo "failure markers:"
    grep -E 'FAIL|TIMEOUT|EXIT|panic|not found' "$RUN_DIR/serial.log" || true
    ;;
esac

echo "PASS: retained $MODE evidence is complete: $RUN_DIR"
