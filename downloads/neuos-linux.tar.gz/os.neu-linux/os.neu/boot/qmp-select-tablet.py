#!/usr/bin/env python3
"""Make the QEMU virtio tablet the current pointer. PS/2 stays unused."""

import json
import socket
import sys


def receive_message(stream) -> dict:
    line = stream.readline()
    if not line:
        raise RuntimeError("QMP connection closed")
    return json.loads(line)


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: qmp-select-tablet.py <qmp.sock>", file=sys.stderr)
        return 2
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(sys.argv[1])
        stream = client.makefile("rwb", buffering=0)
        receive_message(stream)
        stream.write(b'{"execute":"qmp_capabilities"}\r\n')
        while "return" not in receive_message(stream):
            pass
        stream.write(b'{"execute":"query-mice"}\r\n')
        mice = None
        while True:
            response = receive_message(stream)
            if "return" in response:
                mice = response["return"]
                break
            if "error" in response:
                print(json.dumps(response), file=sys.stderr)
                return 1
        tablet = next((m for m in mice if m.get("absolute") and "Tablet" in m.get("name", "")), None)
        if tablet is None:
            tablet = next((m for m in mice if m.get("absolute")), None)
        if tablet is None:
            print("no absolute tablet", file=sys.stderr)
            return 1
        idx = tablet["index"]
        stream.write(
            json.dumps(
                {
                    "execute": "human-monitor-command",
                    "arguments": {"command-line": f"mouse_set {idx}"},
                }
            ).encode()
            + b"\r\n"
        )
        while True:
            response = receive_message(stream)
            if "return" in response or "error" in response:
                if "error" in response:
                    print(json.dumps(response), file=sys.stderr)
                    return 1
                print(f"tablet current index={idx} name={tablet.get('name')}")
                return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
