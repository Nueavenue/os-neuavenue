/* os.neu local boot wizard (electron/boot-wizard.html). Talks only to
 * window.osneuWizard (electron/boot-wizard-preload.cjs). */
'use strict'

const api = window.osneuWizard
const $ = (sel) => document.querySelector(sel)
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

const STEPS = [
  { id: 'logo', label: 'os.neu' },
  { id: 'diag', label: '진단 · Diagnostics' },
  { id: 'net', label: '네트워크 · Network' },
  { id: 'lang', label: '언어 · Language' },
  { id: 'display', label: '화면 · Display' },
  { id: 'llm', label: 'LLM' },
  { id: 'login', label: '로그인 · Sign-in' },
  { id: 'finish', label: '시작 · Start' },
]

const state = { step: 0, config: {}, done: new Set(), diag: null, timer: null, busy: false }

function setMsg(text, kind) {
  const m = $('#msg')
  m.textContent = text || ''
  m.style.color = kind === 'bad' ? 'var(--bad)' : kind === 'ok' ? 'var(--ok)' : ''
}

function badge(st, text) {
  const cls = st === 'ok' || st === 'skip' ? 'ok' : st === 'warn' ? 'warn' : st === 'fail' ? 'bad' : 'run'
  return `<span class="st ${cls}">${esc(text || st)}</span>`
}

function renderNav() {
  $('#nav').innerHTML = STEPS.map((s, i) => {
    const cls = i === state.step ? 'on' : state.done.has(s.id) ? 'done' : ''
    return `<span class="${cls}">${i + 1}. ${esc(s.label)}</span>`
  }).join('')
  $('#back').disabled = state.step === 0
  $('#skip').style.visibility = ['logo', 'finish'].includes(STEPS[state.step].id) ? 'hidden' : 'visible'
  $('#next').textContent = STEPS[state.step].id === 'finish' ? 'os.neu 시작' : '다음'
}

function clearTimer() {
  if (state.timer) clearInterval(state.timer)
  state.timer = null
}

async function go(i) {
  clearTimer()
  state.saveOnNext = null
  state.step = Math.max(0, Math.min(STEPS.length - 1, i))
  setMsg('')
  renderNav()
  const s = STEPS[state.step]
  $('#main').innerHTML = ''
  await VIEWS[s.id]()
}

// ---------- 1. logo ----------

async function viewLogo() {
  $('#main').innerHTML = `<div class="logo"><img src="../public/brand/os.neu-app.png" alt=""><div class="name">os.neu</div>
    <div class="muted">설정을 확인합니다 · Checking setup…</div></div>`
  const st = await api.state()
  state.config = st.config || {}
  if (state.config.lang) state.done.add('lang')
  if (state.config.display) state.done.add('display')
  if (state.config.consent && state.config.consent.account) state.done.add('login')
  setTimeout(() => {
    if (STEPS[state.step].id === 'logo') {
      state.done.add('logo')
      void go(state.step + 1)
    }
  }, 1800)
}

// ---------- 2. four diagnostics ----------

const GROUPS = [
  { title: 'os.neu runtime', ids: [] },
  { title: 'daf.neu network', ids: ['link', 'wifi', 'dns', 'clock', 'proxy', 'tls', 'daf'] },
  { title: 'app.neu', ids: ['appneu'] },
  { title: 'AI workspace', ids: ['llm', 'prompt'] },
]
const RANK = { ok: 0, skip: 0, warn: 1, fail: 2 }

function groupState(g, d) {
  if (!g.ids.length) return d.runtime.ok ? ['ok', `bridge ${d.runtime.body.llm ? `· llm ${d.runtime.body.llm}` : ''}`] : ['fail', `bridge HTTP ${d.runtime.status}`]
  const checks = g.ids.map((id) => [id, d.report.checks && d.report.checks[id]]).filter(([, c]) => c)
  if (!checks.length) return ['warn', 'no result']
  let worst = 'ok'
  for (const [, c] of checks) if ((RANK[c.state] || 0) > RANK[worst]) worst = c.state
  return [worst, checks.map(([id, c]) => `${id}: ${c.state}${c.detail ? ` — ${c.detail}` : ''}`).join('\n')]
}

async function viewDiag() {
  const main = $('#main')
  const draw = (d) => {
    main.innerHTML = `<h2>네 가지 진단 · Four checks</h2><p class="sub">부팅 스플래시와 같은 4단계입니다. 실패해도 다음 단계에서 고칠 수 있습니다.</p>` +
      GROUPS.map((g) => {
        const [st, detail] = d ? groupState(g, d) : ['run', '확인 중…']
        return `<div class="card"><div class="row"><span class="grow">${esc(g.title)}</span>${badge(st, d ? st : '…')}</div><div class="detail">${esc(detail)}</div></div>`
      }).join('') + `<button id="rediag">다시 진단 · Re-run</button>`
    const r = $('#rediag')
    if (r) r.onclick = () => void viewDiag()
  }
  draw(null)
  state.busy = true
  try {
    state.diag = await api.diag()
  } finally {
    state.busy = false
  }
  if (STEPS[state.step].id !== 'diag') return
  draw(state.diag)
  const all = GROUPS.every((g) => groupState(g, state.diag)[0] === 'ok')
  state.done.add('diag')
  if (groupState(GROUPS[1], state.diag)[0] !== 'fail') state.done.add('net')
  if (groupState(GROUPS[3], state.diag)[0] === 'ok') state.done.add('llm')
  renderNav()
  if (all && state.config.wizardDoneAt) {
    setMsg('이전 설정이 그대로이고 진단이 모두 정상입니다. 곧 os.neu를 시작합니다.', 'ok')
    void go(STEPS.findIndex((s) => s.id === 'finish'))
  }
}

// ---------- 3. network ----------

async function viewNet() {
  const main = $('#main')
  main.innerHTML = `<h2>네트워크 · Network</h2><p class="sub">유선이 연결되어 있으면 그대로 다음으로 넘어가면 됩니다. Wi-Fi는 이름을 고르고 비밀번호를 입력하세요.</p>
    <div id="netst" class="card muted">확인 중…</div>
    <div class="row" style="margin:12px 0"><button id="scan">Wi-Fi 검색 · Scan</button><span class="muted" id="scanmsg"></span></div>
    <div id="ssids" class="list"></div>
    <div class="card" id="joinbox" style="display:none">
      <div class="row"><span class="grow">SSID <b id="selssid"></b></span></div>
      <div class="row" style="margin-top:8px"><input id="ssid" class="grow" placeholder="SSID (숨김 네트워크는 직접 입력)">
      <input id="pw" class="grow" type="password" placeholder="비밀번호 · Password" autocomplete="off"><button id="join" class="pri">연결 · Connect</button></div>
    </div>`
  const showStatus = async () => {
    const s = await api.netStatus()
    $('#netst').innerHTML = !s.ok
      ? `${badge('fail', 'nmcli')} <span class="detail">${esc(s.error)}</span>`
      : s.devices.map((d) => `<div class="row"><span class="grow">${esc(d.device)} (${esc(d.type)})</span><span class="muted">${esc(d.connection || '')}</span>${badge(d.state === 'connected' ? 'ok' : 'warn', d.state)}</div>`).join('') || '장치 없음 · No network device'
    if (s.online) state.done.add('net')
    renderNav()
    return s
  }
  const pick = (ssid) => {
    $('#joinbox').style.display = ''
    $('#ssid').value = ssid
    $('#selssid').textContent = ssid
    document.querySelectorAll('.ssid').forEach((el) => el.classList.toggle('sel', el.dataset.ssid === ssid))
    $('#pw').focus()
  }
  $('#scan').onclick = async () => {
    $('#scanmsg').textContent = '검색 중…'
    const r = await api.wifiScan()
    $('#scanmsg').textContent = r.ok ? `${r.networks.length}개` : r.error
    $('#ssids').innerHTML = (r.networks || []).map((n) =>
      `<div class="card ssid row" data-ssid="${esc(n.ssid)}"><span class="grow">${esc(n.ssid)}${n.active ? ' ✓' : ''}</span><span class="muted">${esc(n.security || 'open')}</span><span class="st">${n.signal}%</span></div>`).join('')
    document.querySelectorAll('.ssid').forEach((el) => (el.onclick = () => pick(el.dataset.ssid)))
    $('#joinbox').style.display = ''
  }
  $('#join').onclick = async () => {
    const ssid = $('#ssid').value.trim()
    if (!ssid) return setMsg('SSID를 입력하세요', 'bad')
    setMsg('연결 중…')
    $('#join').disabled = true
    const r = await api.wifiConnect(ssid, $('#pw').value)
    $('#join').disabled = false
    $('#pw').value = ''
    setMsg(r.ok ? `${ssid} 연결됨` : `연결 실패: ${r.error}`, r.ok ? 'ok' : 'bad')
    await showStatus()
  }
  await showStatus()
}

// ---------- 4. language and input ----------

async function viewLang() {
  const l = await api.langList()
  const cur = state.config.lang || 'ko'
  const curIm = new Set(state.config.inputMethods || ['hangul'])
  $('#main').innerHTML = `<h2>언어 · 입력기 · Language and input</h2>
    <p class="sub">화면 언어는 os.neu를 다시 시작할 때 적용됩니다. 입력 전환은 Ctrl+Space 입니다.</p>
    <div class="card"><div class="row"><span class="grow">화면 언어 · Display language</span>
      <select id="lang">${l.langs.map((x) => `<option value="${esc(x.id)}" ${x.id === cur ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select></div></div>
    <div class="card">${l.fcitx ? '' : `<div class="detail" style="color:var(--warn)">fcitx5가 설치되지 않아 한글 등 입력기를 쓸 수 없습니다 (Leader: sudo apt install fcitx5 fcitx5-hangul).</div>`}
      ${l.methods.map((m) => `<label class="chk"><input type="checkbox" value="${esc(m.id)}" ${m.id === 'keyboard-us' ? 'checked disabled' : curIm.has(m.id) ? 'checked' : ''} ${m.installed ? '' : 'disabled'}>
        <span>${esc(m.label)} ${m.installed ? '' : '<span class="muted">(미설치 · not installed)</span>'}</span></label>`).join('')}
      <div class="row" style="margin-top:8px"><input id="imtest" class="grow" placeholder="여기서 입력을 시험해 보세요 · Try typing here"></div>
    </div>
    <button id="savelang" class="pri">저장 · Save</button>`
  state.saveOnNext = () => $('#savelang').onclick()
  $('#savelang').onclick = async () => {
    const methods = [...document.querySelectorAll('input[type=checkbox]:checked:not(:disabled)')].map((el) => el.value)
    const r = await api.langSave($('#lang').value, methods)
    if (r.ok) {
      state.config = r.config
      state.done.add('lang')
      renderNav()
    }
    setMsg(r.ok ? '저장됨 · 입력기 다시 읽음' : r.error, r.ok ? 'ok' : 'bad')
  }
}

// ---------- 5. displays ----------

async function viewDisplay() {
  const d = await api.displayList()
  const saved = d.saved || state.config.display || {}
  const main = $('#main')
  if (!d.ok || d.compositor !== 'sway') {
    main.innerHTML = `<h2>화면 · Displays</h2><div class="card">${badge(d.ok ? 'warn' : 'fail', d.compositor || 'unknown')}
      <div class="detail">${esc(d.note || d.error || '모니터 정보를 읽지 못했습니다 · could not read monitors')}</div></div>`
    return
  }
  state.saveOnNext = () => $('#savedisp').onclick()
  const opts = d.outputs.map((o) => `<option value="${esc(o.name)}" ${o.name === saved.primary ? 'selected' : ''}>${esc(o.name)} — ${esc(o.model)}</option>`).join('')
  const scale = saved.scale || 2
  main.innerHTML = `<h2>화면 · Displays</h2><p class="sub">모니터 ${d.outputs.length}대를 찾았습니다. os.neu 창은 주 모니터 가운데에 표시됩니다.</p>
    ${d.outputs.map((o) => `<div class="card row"><span class="grow">${esc(o.name)} <span class="muted">${esc(o.model)}</span></span>
      <span class="muted">${o.width}×${o.height} @${o.scale}x</span>${badge(o.active ? 'ok' : 'warn', o.active ? 'on' : 'off')}</div>`).join('')}
    <div class="grid" style="margin-top:12px">
      <div class="card"><div class="muted">모드 · Mode</div>
        <label class="chk"><input type="radio" name="mode" value="single" ${saved.mode !== 'dual' ? 'checked' : ''}> 싱글 · 주 모니터만 사용</label>
        <label class="chk"><input type="radio" name="mode" value="dual" ${saved.mode === 'dual' ? 'checked' : ''} ${d.outputs.length < 2 ? 'disabled' : ''}> 듀얼 · 두 모니터 모두 사용</label></div>
      <div class="card"><div class="muted">주 모니터 · Primary</div><select id="primary" style="width:100%;margin:8px 0">${opts}</select>
        <div class="muted">배율 · Scale</div><select id="scale">${[1, 1.25, 1.5, 2].map((s) => `<option ${s === scale ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
    </div>
    <button id="savedisp" class="pri">적용 · Apply</button>`
  $('#savedisp').onclick = async () => {
    const mode = document.querySelector('input[name=mode]:checked').value
    const r = await api.displaySave({ mode, primary: $('#primary').value, scale: Number($('#scale').value) })
    if (r.ok) state.done.add('display')
    renderNav()
    setMsg(r.ok ? '적용됨' : `적용 실패: ${r.error}`, r.ok ? 'ok' : 'bad')
  }
}

// ---------- 6. LLM ----------

async function viewLlm() {
  const main = $('#main')
  main.innerHTML = `<h2>LLM</h2><div class="card muted">확인 중…</div>`
  const s = await api.llmStatus()
  const ready = s.ready || {}
  if (s.hasKey || ready.ok) state.done.add('llm')
  renderNav()
  main.innerHTML = `<h2>LLM</h2><p class="sub">키는 이 컴퓨터의 os.neu 설정에만 저장되며 화면과 로그에 표시하지 않습니다.</p>
    <div class="card row"><span class="grow">현재 · Current</span><span class="muted">${esc(s.provider || ready.via || '—')}${s.keyHint ? ` · ${esc(s.keyHint)}` : ''}</span>
      ${badge(ready.ok ? 'ok' : 'warn', ready.ok ? `ready (${ready.via || ''})` : 'not ready')}</div>
    <div class="card"><div class="muted">OpenAI API key ${s.hasKey ? '(바꾸려면 새 키 입력 · enter a new key to replace)' : ''}</div>
      <div class="row" style="margin-top:8px"><input id="key" class="grow" type="password" autocomplete="off" placeholder="sk-…"><button id="savekey" class="pri">저장 · Save</button></div></div>`
  $('#savekey').onclick = async () => {
    const k = $('#key').value
    $('#key').value = ''
    const r = await api.llmSave(k)
    setMsg(r.ok ? '키 저장됨' : `저장 실패: ${r.error}`, r.ok ? 'ok' : 'bad')
    if (r.ok) void viewLlm()
  }
}

// ---------- 7. sign-in and consent ----------

async function viewLogin() {
  const main = $('#main')
  main.innerHTML = `<h2>로그인 · 정보 제공 동의</h2><div class="card muted">확인 중…</div>`
  const s = await api.loginStatus()
  const c = s.consent || {}
  main.innerHTML = `<h2>로그인 · 정보 제공 동의 · Sign-in and consent</h2>
    <p class="sub">os.neu는 Google 계정 인증이 필요합니다. 여기서는 상태만 확인하고, 실제 로그인은 os.neu 화면에서 합니다.</p>
    <div class="card row"><span class="grow">app.neu 인증 서버 (Supabase)</span>${badge(s.supabase ? 'ok' : 'fail', s.supabase ? 'configured' : 'not configured')}</div>
    <div class="card row"><span class="grow">accounts.google.com</span>${badge(s.googleReachable ? 'ok' : 'fail', s.googleReachable ? 'reachable' : `unreachable (${s.googleStatus})`)}</div>
    ${s.googleError ? `<div class="detail">${esc(s.googleError)}</div>` : ''}
    <div class="card row"><span class="grow">os.neu 로그인 · Signed in</span>${s.signedIn ? badge('ok', esc(s.user.email || s.user.name || 'yes')) : badge('warn', 'os.neu 화면에서 Google로 로그인 필요')}</div>
    <div class="card">
      <label class="chk"><input type="checkbox" id="cdiag" ${c.diagnostics ? 'checked' : ''}><span>부팅 진단 결과(네트워크·LLM 상태, 키 값 제외)를 이 컴퓨터에 기록하는 데 동의합니다.</span></label>
      <label class="chk"><input type="checkbox" id="cacct" ${c.account ? 'checked' : ''}><span>Google 계정 기본 정보(이메일·이름)를 os.neu 로그인에 사용하는 데 동의합니다. (필수)</span></label>
      ${c.at ? `<div class="detail">마지막 동의: ${esc(c.at)}</div>` : ''}
    </div>
    <button id="saveconsent" class="pri">동의 저장 · Save consent</button> <button id="relogin">다시 확인 · Re-check</button>`
  $('#relogin').onclick = () => void viewLogin()
  $('#saveconsent').onclick = async () => {
    const saved = await api.consent({ diagnostics: $('#cdiag').checked, account: $('#cacct').checked })
    state.config = saved
    if (saved.consent && saved.consent.account) state.done.add('login')
    renderNav()
    setMsg('동의 저장됨', 'ok')
  }
  if (c.account && s.supabase && s.googleReachable) state.done.add('login')
  renderNav()
}

// ---------- 8. finish ----------

async function viewFinish() {
  const missing = STEPS.filter((s) => !['logo', 'finish'].includes(s.id) && !state.done.has(s.id)).map((s) => s.label)
  const accountOk = (state.config.consent && state.config.consent.account) || false
  $('#main').innerHTML = `<h2>os.neu 시작 · Start</h2>
    <div class="card">${missing.length ? `<div>확인되지 않은 단계: ${esc(missing.join(', '))}</div><div class="detail">나중에 os.neu 안에서 바꿀 수 있습니다.</div>` : '모든 단계가 확인되었습니다.'}</div>
    ${accountOk ? '' : `<div class="card" style="color:var(--warn)">Google 계정 정보 사용 동의가 없으면 os.neu 로그인 후 일부 기능이 제한됩니다.</div>`}
    <div class="card muted">창을 닫거나 최소화하면 재부팅/종료를 묻습니다. 콘솔은 Ctrl+Alt+T.</div>
    <div class="muted" id="count"></div>`
  if (!missing.length) {
    let n = 5
    const tick = () => {
      $('#count').textContent = `${n}초 후 자동 시작 · Starting in ${n}s (다른 단계를 누르면 취소)`
      if (n-- <= 0) {
        clearTimer()
        void api.finish()
      }
    }
    tick()
    state.timer = setInterval(tick, 1000)
  }
}

const VIEWS = { logo: viewLogo, diag: viewDiag, net: viewNet, lang: viewLang, display: viewDisplay, llm: viewLlm, login: viewLogin, finish: viewFinish }

$('#next').onclick = () => {
  if (state.busy) return
  const id = STEPS[state.step].id
  if (id === 'finish') {
    clearTimer()
    void api.finish()
    return
  }
  const save = state.saveOnNext
  void Promise.resolve(save ? save() : null).finally(() => go(state.step + 1))
}
$('#skip').onclick = () => void go(state.step + 1)
$('#back').onclick = () => void go(state.step - 1)
$('#nav').onclick = (e) => {
  const idx = [...$('#nav').children].indexOf(e.target)
  if (idx >= 0) void go(idx)
}
$('#pw-reboot').onclick = () => {
  if (confirm('재부팅할까요? (GRUB 메뉴에서 Ubuntu를 고를 수 있습니다)')) void api.power('reboot')
}
$('#pw-off').onclick = () => {
  if (confirm('컴퓨터를 끌까요?')) void api.power('poweroff')
}

void go(0)
