const { contextBridge, ipcRenderer } = require('electron')

// Boot setup screen only (electron/wifi.html). The password goes straight to
// the main process and on to osneu-wifi.mjs stdin; nothing here stores it.
contextBridge.exposeInMainWorld('osneuSetup', {
  status: () => ipcRenderer.invoke('setup:wifi:status'),
  scan: () => ipcRenderer.invoke('setup:wifi:scan'),
  connect: (ssid, password) => ipcRenderer.invoke('setup:wifi:connect', { ssid, password }),
  diag: (mode) => ipcRenderer.invoke('setup:diag', mode),
  done: (result) => ipcRenderer.invoke('setup:done', result),
})
