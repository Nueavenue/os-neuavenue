const { contextBridge, ipcRenderer } = require('electron')

// Local SSD boot wizard only (electron/boot-wizard.html). Wi-Fi passwords and
// LLM keys go straight to the main process; nothing here stores them.
contextBridge.exposeInMainWorld('osneuWizard', {
  state: () => ipcRenderer.invoke('wizard:state'),
  diag: () => ipcRenderer.invoke('wizard:diag'),
  netStatus: () => ipcRenderer.invoke('wizard:net:status'),
  wifiScan: () => ipcRenderer.invoke('wizard:wifi:scan'),
  wifiConnect: (ssid, password) => ipcRenderer.invoke('wizard:wifi:connect', { ssid, password }),
  langList: () => ipcRenderer.invoke('wizard:lang:list'),
  langSave: (lang, methods) => ipcRenderer.invoke('wizard:lang:save', { lang, methods }),
  displayList: () => ipcRenderer.invoke('wizard:display:list'),
  displaySave: (p) => ipcRenderer.invoke('wizard:display:save', p),
  llmStatus: () => ipcRenderer.invoke('wizard:llm:status'),
  llmSave: (key) => ipcRenderer.invoke('wizard:llm:save', key),
  loginStatus: () => ipcRenderer.invoke('wizard:login:status'),
  consent: (c) => ipcRenderer.invoke('wizard:consent', c),
  power: (kind) => ipcRenderer.invoke('wizard:power', kind),
  finish: () => ipcRenderer.invoke('wizard:finish'),
})
