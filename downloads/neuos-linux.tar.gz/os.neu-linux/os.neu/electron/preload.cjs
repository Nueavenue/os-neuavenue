const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('neuos', {
  browse: {
    go: (url) => ipcRenderer.invoke('browse:go', url),
    hide: () => ipcRenderer.invoke('browse:hide'),
    bounds: (rect) => ipcRenderer.invoke('browse:bounds', rect),
    back: () => ipcRenderer.invoke('browse:back'),
    newWindow: (url) => ipcRenderer.invoke('browse:newWindow', url),
    onDownload: (cb) => {
      const listen = (_event, row) => cb(row)
      ipcRenderer.on('browse:download', listen)
      return () => ipcRenderer.removeListener('browse:download', listen)
    },
    openDownload: (id) => ipcRenderer.invoke('browse:download-open', id),
    showDownload: (id) => ipcRenderer.invoke('browse:download-show', id),
    devtools: (rect) => ipcRenderer.invoke('browse:devtools', rect),
  },
  plant: {
    pick: () => ipcRenderer.invoke('plant:pick'),
    defaultPath: () => ipcRenderer.invoke('plant:default'),
  },
  quit: () => ipcRenderer.invoke('app:quit'),
  setFullscreen: (on) => ipcRenderer.invoke('app:fullscreen', on),
  windowState: () => ipcRenderer.invoke('app:window'),
  windowMode: () => ipcRenderer.invoke('app:window'),
  setWindowMode: (mode) => ipcRenderer.invoke('app:window', mode),
})
