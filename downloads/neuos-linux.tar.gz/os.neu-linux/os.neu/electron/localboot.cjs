// Local SSD kiosk only (scripts/osneu-local-kiosk.sh sets NEUOS_LOCAL_BOOT=1):
// the boot wizard shown before the os.neu window, and a power choice in place
// of close/minimize. The USB JeOS path keeps electron/wifi.html.
const { app, BrowserWindow, dialog } = require('electron')
const { execFile } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const ACTIVE = process.env.NEUOS_LOCAL_BOOT === '1'
const CONFIG_HOME = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config')
const CONFIG = path.join(CONFIG_HOME, 'osneu', 'kiosk.json')
const SWAY_OUTPUTS = path.join(CONFIG_HOME, 'sway', 'osneu-outputs.conf')
const FCITX_PROFILE = path.join(CONFIG_HOME, 'fcitx5', 'profile')
const FCITX_ADDON_CONF = '/usr/share/fcitx5/addon'
const FCITX_CONFIG = path.join(CONFIG_HOME, 'fcitx5', 'config')

const LANGS = [
  ['ko', '한국어'],
  ['en-US', 'English'],
  ['ja', '日本語'],
  ['zh-CN', '简体中文'],
  ['zh-TW', '繁體中文'],
  ['es', 'Español'],
  ['fr', 'Français'],
  ['de', 'Deutsch'],
  ['vi', 'Tiếng Việt'],
  ['th', 'ไทย'],
]
const INPUT_METHODS = [
  { id: 'keyboard-us', label: 'English (US keyboard)', addon: null },
  { id: 'hangul', label: '한국어 (Hangul)', addon: 'hangul' },
  { id: 'mozc', label: '日本語 (Mozc)', addon: 'mozc' },
  { id: 'pinyin', label: '中文 (Pinyin)', addon: 'pinyin' },
  { id: 'chewing', label: '中文 (Chewing)', addon: 'chewing' },
  { id: 'unikey', label: 'Tiếng Việt (Unikey)', addon: 'unikey' },
  { id: 'libthai', label: 'ไทย (LibThai)', addon: 'libthai' },
]

function readConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG, 'utf8'))
  } catch {
    return {}
  }
}

// Same-path replace via a sibling temp file; never leaves an empty file.
function writeFileSafe(file, text) {
  if (!text) throw new Error(`refusing to write empty ${file}`)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const tmp = `${file}.${process.pid}.tmp`
  fs.writeFileSync(tmp, text)
  fs.renameSync(tmp, file)
}

function writeConfig(patch) {
  const next = { ...readConfig(), ...patch }
  writeFileSafe(CONFIG, JSON.stringify(next, null, 2) + '\n')
  return next
}

function run(cmd, args, timeoutMs = 20_000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: timeoutMs, maxBuffer: 4 << 20 }, (err, stdout, stderr) => {
      resolve({ code: err ? (typeof err.code === 'number' ? err.code : -1) : 0, out: String(stdout), err: String(stderr) })
    })
  })
}

// Must run before app 'ready': Chromium reads --lang once.
function early() {
  if (!ACTIVE) return
  const lang = readConfig().lang
  if (lang) app.commandLine.appendSwitch('lang', lang)
}

// ---------- network (NetworkManager) ----------

// nmcli -t escapes ':' and '\' with a backslash.
function splitTerse(line) {
  const out = []
  let cur = ''
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (c === '\\' && i + 1 < line.length) {
      cur += line[++i]
    } else if (c === ':') {
      out.push(cur)
      cur = ''
    } else {
      cur += c
    }
  }
  out.push(cur)
  return out
}

async function networkStatus() {
  const r = await run('nmcli', ['-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device'])
  if (r.code !== 0) return { ok: false, error: (r.err || 'nmcli failed').trim(), devices: [] }
  const devices = r.out
    .split('\n')
    .filter(Boolean)
    .map(splitTerse)
    .map(([device, type, state, connection]) => ({ device, type, state, connection }))
    .filter((d) => (d.type === 'ethernet' || d.type === 'wifi') && d.state !== 'unmanaged')
  return { ok: true, online: devices.some((d) => d.state === 'connected'), devices }
}

async function wifiScan() {
  const r = await run('nmcli', ['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list', '--rescan', 'yes'], 30_000)
  if (r.code !== 0) return { ok: false, error: (r.err || 'nmcli failed').trim(), networks: [] }
  const seen = new Map()
  for (const line of r.out.split('\n').filter(Boolean)) {
    const [inUse, ssid, signal, security] = splitTerse(line)
    if (!ssid) continue
    const prev = seen.get(ssid)
    const n = { ssid, signal: Number(signal) || 0, security: security || '', active: inUse === '*' }
    if (!prev || n.signal > prev.signal) seen.set(ssid, n)
  }
  return { ok: true, networks: [...seen.values()].sort((a, b) => b.signal - a.signal) }
}

async function wifiConnect(ssid, password) {
  if (!ssid) return { ok: false, error: 'SSID is empty' }
  const args = ['device', 'wifi', 'connect', ssid]
  if (password) args.push('password', password)
  const r = await run('nmcli', args, 60_000)
  return r.code === 0 ? { ok: true } : { ok: false, error: (r.err || r.out || 'connect failed').trim().split('\n')[0] }
}

// ---------- language and input methods (fcitx5) ----------

function inputMethods() {
  const fcitx = fs.existsSync('/usr/bin/fcitx5')
  return {
    fcitx,
    langs: LANGS.map(([id, label]) => ({ id, label })),
    methods: INPUT_METHODS.map((m) => ({
      id: m.id,
      label: m.label,
      installed: m.addon === null ? true : fcitx && fs.existsSync(path.join(FCITX_ADDON_CONF, `${m.addon}.conf`)),
    })),
  }
}

function fcitxProfile(ids) {
  const items = ['keyboard-us', ...ids.filter((id) => id !== 'keyboard-us')]
  const lines = ['[Groups/0]', 'Name=Default', 'Default Layout=us', `DefaultIM=${items[items.length - 1]}`, '']
  items.forEach((id, i) => lines.push(`[Groups/0/Items/${i}]`, `Name=${id}`, 'Layout=', ''))
  lines.push('[GroupOrder]', '0=Default', '')
  return lines.join('\n')
}

// Ctrl+Space, the Korean 한/영 key, and Right Alt (what many Korean keyboards
// send for 한/영 under the us layout) switch input methods.
const FCITX_HOTKEYS = [
  '[Hotkey]',
  'EnumerateWithTriggerKeys=True',
  '',
  '[Hotkey/TriggerKeys]',
  '0=Control+space',
  '1=Hangul',
  '2=Alt_R',
  '',
].join('\n')

async function saveLanguage(lang, methods) {
  const known = new Set(INPUT_METHODS.map((m) => m.id))
  const ids = (Array.isArray(methods) ? methods : []).map(String).filter((id) => known.has(id))
  const cfg = writeConfig({ lang: LANGS.some(([id]) => id === lang) ? lang : 'ko', inputMethods: ids })
  if (fs.existsSync('/usr/bin/fcitx5')) {
    writeFileSafe(FCITX_PROFILE, fcitxProfile(ids))
    if (!fs.existsSync(FCITX_CONFIG)) writeFileSafe(FCITX_CONFIG, FCITX_HOTKEYS)
    await run('fcitx5-remote', ['-r'], 5_000)
  }
  return { ok: true, config: cfg, restartForLanguage: true }
}

// ---------- displays (sway) ----------

// sway exports SWAYSOCK to what it starts; fall back to its socket in the
// runtime dir in case the variable did not reach this process.
function swaySock() {
  if (process.env.SWAYSOCK) return process.env.SWAYSOCK
  const dir = process.env.XDG_RUNTIME_DIR || `/run/user/${process.getuid()}`
  try {
    const sock = fs.readdirSync(dir).find((n) => /^sway-ipc\..*\.sock$/.test(n))
    if (sock) process.env.SWAYSOCK = path.join(dir, sock)
  } catch {
    /* no runtime dir */
  }
  return process.env.SWAYSOCK || ''
}

async function displays() {
  if (!swaySock()) {
    return { ok: true, compositor: 'cage', outputs: [], note: 'cage: 모든 모니터를 한 화면으로 씁니다. 모니터별 배치·배율은 sway 필요 · cage spans every monitor; sway gives per-monitor layout and scale' }
  }
  const r = await run('swaymsg', ['-t', 'get_outputs', '-r'])
  if (r.code !== 0) return { ok: false, compositor: 'sway', error: `swaymsg rc=${r.code} ${(r.err || r.out).trim()}`, outputs: [] }
  let list
  try {
    list = JSON.parse(r.out)
  } catch (err) {
    return { ok: false, compositor: 'sway', error: `swaymsg output not JSON: ${err}`, outputs: [] }
  }
  const outputs = list.map((o) => ({
    name: o.name,
    model: [o.make, o.model].filter(Boolean).join(' '),
    active: o.active,
    width: o.current_mode ? o.current_mode.width : 0,
    height: o.current_mode ? o.current_mode.height : 0,
    scale: o.scale || 1,
  }))
  return { ok: true, compositor: 'sway', outputs, saved: readConfig().display || null }
}

// Until the wizard saves a layout, 4K outputs get scale 2 for this session so
// the wizard and os.neu are readable (sway leaves 28-32" 4K panels at 1).
async function autoScale() {
  if (!swaySock()) return
  const d = await displays()
  console.error(`[osneu-wizard] outputs ${JSON.stringify(d.outputs || d.error || [])}`)
  if (readConfig().display) return
  for (const o of d.outputs || []) {
    if (o.active && o.width >= 3200 && o.scale < 2) await run('swaymsg', ['output', o.name, 'scale', '2'])
  }
}

async function saveDisplay(p) {
  const mode = p && p.mode === 'dual' ? 'dual' : 'single'
  const scale = [1, 1.25, 1.5, 2].includes(Number(p && p.scale)) ? Number(p.scale) : 2
  const d = await displays()
  const names = d.outputs.map((o) => o.name)
  const primary = names.includes(p && p.primary) ? p.primary : names[0]
  const lines = ['# written by the os.neu boot wizard (electron/localboot.cjs)']
  for (const name of names) {
    if (mode === 'single' && name !== primary) lines.push(`output ${name} disable`)
    else lines.push(`output ${name} enable scale ${scale}`)
  }
  if (primary) lines.push(`workspace 1 output ${primary}`, `focus output ${primary}`)
  writeConfig({ display: { mode, primary, scale } })
  if (d.compositor !== 'sway') return { ok: true, applied: false }
  writeFileSafe(SWAY_OUTPUTS, lines.join('\n') + '\n')
  const r = await run('swaymsg', ['reload'])
  return { ok: r.code === 0, applied: r.code === 0, error: r.code === 0 ? '' : r.err.trim() }
}

// ---------- LLM and sign-in (local bridge) ----------

let uiSession = ''

async function uiSessionToken(base) {
  if (uiSession) return uiSession
  try {
    const res = await fetch(new URL('/api/ui-session', base), { signal: AbortSignal.timeout(4000) })
    uiSession = String(res.headers.get('x-osneu-ui') || '').trim()
  } catch {
    uiSession = ''
  }
  return uiSession
}

async function bridge(base, pathname, init) {
  try {
    const token = await uiSessionToken(base)
    const headers = { ...(init && init.headers ? init.headers : {}), ...(token ? { 'x-osneu-ui': token } : {}) }
    const res = await fetch(new URL(pathname, base), { ...init, headers, signal: AbortSignal.timeout(15_000) })
    return { status: res.status, body: await res.json().catch(() => ({})) }
  } catch (err) {
    return { status: 0, body: { ok: false, error: String(err && err.message ? err.message : err) } }
  }
}

async function llmStatus(base) {
  const [s, r] = await Promise.all([bridge(base, '/api/llm/settings'), bridge(base, '/api/llm/ready')])
  const b = s.body || {}
  return { ok: s.status === 200, provider: b.provider, hasKey: Boolean(b.hasKey), keyHint: b.keyHint || '', ready: r.body || {} }
}

async function llmSaveKey(base, key) {
  const k = String(key || '').trim()
  if (!k) return { ok: false, error: 'key is empty' }
  const r = await bridge(base, '/api/llm/settings', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ openaiKey: k }),
  })
  return { ok: r.status === 200 && r.body.ok !== false, error: r.body.error || '' }
}

// The os.neu session token lives in the app origin's localStorage. Read it on
// the bridge's JSON health page (no app code runs there) and keep it in this
// process only.
async function readAppToken(base) {
  const w = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true } })
  try {
    await w.loadURL(new URL('/api/health', base).toString())
    return String((await w.webContents.executeJavaScript("localStorage.getItem('os.neu.token') || ''")) || '')
  } catch {
    return ''
  } finally {
    w.destroy()
  }
}

async function googleReach() {
  try {
    const r = await fetch('https://accounts.google.com/', { method: 'HEAD', signal: AbortSignal.timeout(15_000) })
    return { status: r.status, error: '' }
  } catch (err) {
    const cause = err && err.cause ? err.cause.code || err.cause.message : ''
    return { status: 0, error: [err && err.message, cause].filter(Boolean).join(': ') }
  }
}

async function loginStatus(base) {
  const [health, g] = await Promise.all([bridge(base, '/api/health'), googleReach()])
  const google = g.status
  const token = await readAppToken(base)
  let user = null
  if (token) {
    const me = await bridge(base, '/api/auth/me', { headers: { 'x-osneu-token': token } })
    user = me.body && me.body.user ? { email: me.body.user.email || '', name: me.body.user.name || me.body.user.full_name || '' } : null
  }
  return {
    ok: true,
    supabase: Boolean(health.body && health.body.supabase),
    googleReachable: google > 0 && google < 500,
    googleStatus: google,
    googleError: g.error,
    signedIn: Boolean(user),
    user,
    consent: readConfig().consent || null,
  }
}

// ---------- wizard window ----------

/**
 * @param {{ base: string, icon: any, diag: (mode: string) => Promise<any> }} deps
 * @returns {Promise<void>} resolves when the user finishes the wizard
 */
async function openWizard(deps) {
  await autoScale().catch((err) => console.error(`[osneu-wizard] autoScale ${err}`))
  const w = new BrowserWindow({
    width: 1100,
    height: 720,
    center: true,
    backgroundColor: '#0a1020',
    title: 'os.neu setup',
    icon: deps.icon,
    frame: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'boot-wizard-preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  const ipc = w.webContents.ipc
  ipc.handle('wizard:state', () => ({ config: readConfig(), version: app.getVersion() }))
  ipc.handle('wizard:diag', async () => {
    const health = await bridge(deps.base, '/api/health')
    await deps.diag('connect')
    const report = await deps.diag('ai')
    return { runtime: { ok: health.status === 200, status: health.status, body: health.body }, report }
  })
  ipc.handle('wizard:net:status', () => networkStatus())
  ipc.handle('wizard:wifi:scan', () => wifiScan())
  ipc.handle('wizard:wifi:connect', (_e, p) => wifiConnect(String((p && p.ssid) || ''), String((p && p.password) || '')))
  ipc.handle('wizard:lang:list', () => inputMethods())
  ipc.handle('wizard:lang:save', (_e, p) => saveLanguage(String((p && p.lang) || ''), p && p.methods))
  ipc.handle('wizard:display:list', () => displays())
  ipc.handle('wizard:display:save', (_e, p) => saveDisplay(p))
  ipc.handle('wizard:llm:status', () => llmStatus(deps.base))
  ipc.handle('wizard:llm:save', (_e, key) => llmSaveKey(deps.base, key))
  ipc.handle('wizard:login:status', () => loginStatus(deps.base))
  ipc.handle('wizard:consent', (_e, c) =>
    writeConfig({ consent: { diagnostics: Boolean(c && c.diagnostics), account: Boolean(c && c.account), at: new Date().toISOString() } }),
  )
  ipc.handle('wizard:power', (_e, kind) => power(String(kind)))
  return new Promise((resolve) => {
    let done = false
    ipc.handle('wizard:finish', () => {
      done = true
      writeConfig({ wizardDoneAt: new Date().toISOString() })
      w.close()
    })
    w.on('closed', () => resolve(done))
    void w.loadFile(path.join(__dirname, 'boot-wizard.html'))
  })
}

// ---------- power ----------

function power(kind) {
  if (kind === 'reboot') return run('systemctl', ['reboot'])
  if (kind === 'poweroff') return run('systemctl', ['poweroff'])
  return Promise.resolve({ code: 2 })
}

const POWER_TEXT = {
  ko: {
    buttons: ['취소', '재부팅 (GRUB 메뉴에서 Ubuntu 선택)', '컴퓨터 종료'],
    message: 'os.neu 화면을 닫을까요?',
    detail: '키오스크 모드에서는 창을 닫거나 내리면 컴퓨터를 재부팅하거나 종료합니다.',
    fail: '전원 명령이 거부되었습니다',
  },
  en: {
    buttons: ['Cancel', 'Restart (pick Ubuntu in the GRUB menu)', 'Shut down'],
    message: 'Close the os.neu screen?',
    detail: 'In kiosk mode, closing or minimizing restarts or shuts down the computer.',
    fail: 'The power command was refused',
  },
}

let asking = false
async function askPower(win) {
  if (asking || !win || win.isDestroyed()) return
  asking = true
  try {
    const t = POWER_TEXT[String(readConfig().lang || 'ko').startsWith('ko') ? 'ko' : 'en']
    const { response } = await dialog.showMessageBox(win, {
      type: 'question',
      title: 'os.neu',
      buttons: t.buttons,
      cancelId: 0,
      defaultId: 0,
      message: t.message,
      detail: t.detail,
      noLink: true,
    })
    if (response === 0) return
    const r = await power(response === 1 ? 'reboot' : 'poweroff')
    if (r.code !== 0) dialog.showErrorBox('os.neu', `${t.fail}: ${(r.err || '').trim()}`)
  } finally {
    asking = false
  }
}

function guardWindow(win) {
  if (!ACTIVE || process.env.NEUOS_POWER_GUARD === '0') return
  win.on('close', (e) => {
    if (app.isQuitting) return
    e.preventDefault()
    void askPower(win)
  })
  win.on('minimize', () => {
    win.restore()
    void askPower(win)
  })
}

module.exports = { ACTIVE, early, openWizard, guardWindow, readConfig, fcitxProfile, splitTerse }
