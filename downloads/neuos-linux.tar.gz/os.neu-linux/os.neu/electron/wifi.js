// Boot setup screen: splash look, Wi-Fi card on a blurred splash when the seat
// is offline, then the same four diagnostics steps as the boot splash.
const api = window.osneuSetup
const $ = (id) => document.getElementById(id)
const rank = { ok: 0, skip: 0, warn: 1, fail: 2 }

function step(i, state, note = '') {
  const li = $(`s${i}`)
  li.className = state
  li.querySelector('.note').textContent = note ? `— ${note}` : ''
}

function worst(checks, names) {
  let out = 'ok'
  for (const n of names) {
    const s = checks[n]?.state || 'skip'
    if (rank[s] > rank[out]) out = s
  }
  return out
}

function short(text) {
  const t = String(text || '')
  return t.length > 70 ? `${t.slice(0, 67)}…` : t
}

function msg(text, kind = '') {
  $('msg').textContent = text
  $('msg').className = kind
}

function busy(on) {
  for (const id of ['ssid', 'pw', 'go', 'rescan', 'show', 'skip']) $(id).disabled = on
}

let selected = ''
let selectedOpen = false

function renderList(networks) {
  const list = $('list')
  list.textContent = ''
  if (!networks.length) {
    const li = document.createElement('li')
    li.className = 'empty'
    li.textContent = 'No networks found. Rescan, or type the network name.'
    list.appendChild(li)
    return
  }
  for (const n of networks) {
    const li = document.createElement('li')
    const name = document.createElement('span')
    name.textContent = n.ssid
    const meta = document.createElement('span')
    meta.className = 'meta'
    const bars = n.signal >= -55 ? '▂▄▆█' : n.signal >= -67 ? '▂▄▆' : n.signal >= -78 ? '▂▄' : '▂'
    meta.textContent = `${n.security === 'Open' ? 'open' : n.security} · ${bars}`
    li.append(name, meta)
    li.addEventListener('click', () => {
      selected = n.ssid
      selectedOpen = n.security === 'Open'
      $('ssid').value = n.ssid
      for (const x of list.children) x.classList.toggle('sel', x === li)
      $('pw').disabled = n.security === 'Open'
      if (n.security === 'Open') $('pw').value = ''
      ;(n.security === 'Open' ? $('go') : $('pw')).focus()
    })
    list.appendChild(li)
  }
}

async function rescan() {
  msg('Searching for networks…')
  $('rescan').disabled = true
  const r = await api.scan()
  $('rescan').disabled = false
  if (!r.ok) {
    renderList([])
    msg(r.error || 'Wi-Fi scan failed', 'err')
    return
  }
  renderList(r.networks)
  msg(r.networks.length ? `Wi-Fi adapter ${r.iface} ready` : '')
}

function showCard(note) {
  document.body.classList.add('blur')
  step(1, 'warn', note || 'needs a network')
  step(2, '')
  step(3, '')
  setTimeout(() => $('ssid').focus(), 300)
}

async function diagnose() {
  document.body.classList.remove('blur')
  $('title').textContent = 'Initializing AI runtime…'
  step(1, 'run')
  step(2, '')
  step(3, '')
  const c = (await api.diag('connect')).checks || {}
  const net = worst(c, ['link', 'dns', 'clock', 'proxy', 'tls', 'daf'])
  const netNote = net === 'ok' ? `${c.link?.detail?.split(' ').slice(0, 2).join(' ') || 'online'}` : short([c.link, c.dns, c.tls, c.daf].find((x) => x && x.state !== 'ok' && x.state !== 'skip')?.detail)
  step(1, net, netNote)
  if (c.link?.state === 'fail' || c.dns?.state === 'fail') {
    showCard(short(c.link?.state === 'fail' ? c.link.detail : c.dns.detail))
    msg('Still no internet on this network. Pick another network or check the password.', 'err')
    return
  }
  step(2, c.appneu?.state || 'warn', short(c.appneu?.detail))
  step(3, 'run')
  const a = (await api.diag('ai')).checks || {}
  const llm = a.llm?.state || 'warn'
  step(3, llm, llm === 'ok' ? 'AI key ready' : a.llm?.key === 'present' ? short(a.llm.detail) : 'add your own OpenAI key in os.neu')
  $('title').textContent = 'os.neu is ready'
  setTimeout(() => api.done({ online: true }), 1500)
}

$('card').addEventListener('submit', async (e) => {
  e.preventDefault()
  const ssid = $('ssid').value.trim() || selected
  const pw = $('pw').disabled ? '' : $('pw').value
  if (!ssid) return msg('Choose a network first.', 'err')
  if (!pw && ssid === selected && !selectedOpen) return msg(`Enter the password for ${ssid}.`, 'err')
  if (pw && (pw.length < 8 || pw.length > 63)) return msg('Wi-Fi passwords are 8–63 characters.', 'err')
  busy(true)
  msg(`Connecting to ${ssid}…`)
  const r = await api.connect(ssid, pw)
  busy(false)
  $('pw').value = ''
  if (!r.ok) return msg(r.error || 'Could not connect', 'err')
  msg(`Connected · ${r.ip}`, 'ok')
  await diagnose()
})

$('rescan').addEventListener('click', rescan)
$('show').addEventListener('click', () => {
  const pw = $('pw')
  pw.type = pw.type === 'password' ? 'text' : 'password'
  $('show').textContent = pw.type === 'password' ? 'Show' : 'Hide'
})
$('skip').addEventListener('click', () => api.done({ online: false }))
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') api.done({ online: false })
})

;(async () => {
  const st = await api.status()
  if (st.online) return diagnose()
  showCard()
  await rescan()
})()
