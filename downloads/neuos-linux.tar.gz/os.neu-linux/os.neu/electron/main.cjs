const { app, BrowserWindow, BrowserView, ipcMain, session, dialog, shell, Menu, clipboard } = require('electron')
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const http = require('node:http')
const net = require('node:net')
const path = require('node:path')
const localboot = require('./localboot.cjs')

const PROTOCOL = 'osneu'
const WEB_HOME = 'https://www.neuavenue.com'
process.env.NEUOS_ELECTRON = '1'

/** @type {import('node:child_process').ChildProcess | null} */
let bridgeChild = null

function isPackagedRuntime() {
  return app.isPackaged || process.env.NEUOS_PACKAGED === '1'
}

function treeRoot() {
  return app.isPackaged ? process.resourcesPath : path.join(__dirname, '..')
}

function brandIcon() {
  return path.join(treeRoot(), 'public', 'brand', 'os.neu-app.png')
}

function uiHomeUrl() {
  if (process.env.NEUOS_UI_URL) return process.env.NEUOS_UI_URL
  if (isPackagedRuntime()) {
    const port = process.env.NEUOS_BRIDGE_PORT || '4178'
    return `http://127.0.0.1:${port}`
  }
  return process.env.NEUOS_DEV_URL ?? 'http://127.0.0.1:5173'
}

/** True only for os.neu's own screen (bridge, dev server, or a local file). */
function isOwnUiUrl(raw) {
  try {
    const u = new URL(String(raw || ''))
    if (u.protocol === 'file:') return true
    const own = [uiHomeUrl(), `http://127.0.0.1:${process.env.NEUOS_BRIDGE_PORT || '4178'}`]
    return own.some((x) => {
      try {
        return new URL(x).origin === u.origin
      } catch {
        return false
      }
    })
  } catch {
    return false
  }
}

function findListenPort(start) {
  const first = Number(start) > 0 ? Number(start) : 4178
  return new Promise((resolve, reject) => {
    const tryPort = (port) => {
      if (port > first + 10) {
        reject(new Error('OS-NEU-SX-001  no free os.neu bridge port'))
        return
      }
      const probe = net.createServer()
      probe.once('error', () => tryPort(port + 1))
      probe.listen(port, '127.0.0.1', () => {
        probe.close(() => resolve(port))
      })
    }
    tryPort(first)
  })
}

function fetchUiSessionToken(port) {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/api/ui-session`, (res) => {
      const raw = res.headers['x-osneu-ui']
      res.resume()
      resolve(typeof raw === 'string' && raw.trim() ? raw.trim() : '')
    })
    req.on('error', () => resolve(''))
    req.setTimeout(2000, () => {
      req.destroy()
      resolve('')
    })
  })
}

function attachUiSessionHeader(port, token) {
  if (!token) return
  const urls = [
    `http://127.0.0.1:${port}/api/*`,
    `http://localhost:${port}/api/*`,
    'http://127.0.0.1:5173/api/*',
    'http://localhost:5173/api/*',
    'http://127.0.0.1:4177/api/*',
    'http://localhost:4177/api/*',
  ]
  session.defaultSession.webRequest.onBeforeSendHeaders({ urls }, (details, cb) => {
    const headers = { ...details.requestHeaders, 'x-osneu-ui': token }
    cb({ requestHeaders: headers })
  })
}

async function bindUiSessionToken() {
  const port = process.env.NEUOS_BRIDGE_PORT || '4178'
  const token = await fetchUiSessionToken(port)
  if (!token) {
    appMark('UI_SESSION missing')
    return
  }
  attachUiSessionHeader(port, token)
  appMark('UI_SESSION attached')
}

function waitBridgeHealth(port, ms) {
  const deadline = Date.now() + ms
  return new Promise((resolve) => {
    const tick = () => {
      const req = http.get(`http://127.0.0.1:${port}/api/health`, (res) => {
        res.resume()
        if (res.statusCode === 200) resolve(true)
        else retry()
      })
      req.on('error', retry)
      req.setTimeout(2000, () => {
        req.destroy()
        retry()
      })
    }
    const retry = () => {
      if (Date.now() > deadline) resolve(false)
      else setTimeout(tick, 200)
    }
    tick()
  })
}

function startPackagedBridge(port) {
  const root = treeRoot()
  const script = path.join(root, 'dist-bridge', 'index.mjs')
  if (!fs.existsSync(script)) {
    throw new Error(`os.neu bridge bundle missing: ${script}`)
  }
  const child = spawn(process.execPath, [script], {
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: '1',
      NEUOS_PACKAGED: '1',
      NEUOS_BRIDGE_PORT: String(port),
      NEUOS_WEB_DIR: path.join(root, 'dist-web'),
      NEUOS_ROOT: root,
      NEUOS_SCREEN: process.env.NEUOS_SCREEN || '1',
      ...(process.env.NEUOS_DRIVER ? { NEUOS_DRIVER: process.env.NEUOS_DRIVER } : {}),
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  })
  child.stdout?.on('data', (chunk) => process.stdout.write(chunk))
  child.stderr?.on('data', (chunk) => process.stderr.write(chunk))
  child.on('exit', (code, signal) => {
    appMark(`BRIDGE exit code=${code} signal=${signal || ''}`)
    if (code && !app.isQuitting) {
      dialog.showErrorBox('os.neu', 'The os.neu bridge stopped. Restart the app.')
      app.quit()
    }
  })
  bridgeChild = child
  return child
}

function stopPackagedBridge() {
  if (!bridgeChild || bridgeChild.killed) return
  try {
    bridgeChild.kill()
  } catch {
    /* already gone */
  }
  bridgeChild = null
}

if (process.defaultApp) {
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient(PROTOCOL, process.execPath, [path.resolve(process.argv[1])])
  }
} else {
  app.setAsDefaultProtocolClient(PROTOCOL)
}

function linuxSuidSandboxOk() {
  if (process.platform !== 'linux') return true
  try {
    const helper = path.join(path.dirname(process.execPath), 'chrome-sandbox')
    const st = fs.statSync(helper)
    return st.uid === 0 && (st.mode & 0o4000) !== 0
  } catch {
    return false
  }
}

function recordSandboxException(reason) {
  const row = `${JSON.stringify({ t: new Date().toISOString(), reason })}\n`
  try {
    const dir = path.join(treeRoot(), 'data')
    fs.mkdirSync(dir, { recursive: true })
    fs.appendFileSync(path.join(dir, 'sandbox-exceptions.jsonl'), row)
  } catch {
    console.error('[os.neu] sandbox exception record failed')
  }
  console.warn(`[os.neu] chromium sandbox exception: ${reason}`)
}

// Chromium sandbox stays on when the SUID helper is present (P1-⑤).
// If the helper is missing, record the reason then disable so desktop still starts.
if (!linuxSuidSandboxOk()) {
  const reason = process.env.NEUOS_JEOS === '1' ? 'kiosk-linux-suid-helper-missing' : 'linux-suid-helper-missing'
  recordSandboxException(reason)
  app.commandLine.appendSwitch('no-sandbox')
  app.commandLine.appendSwitch('disable-gpu-sandbox')
}
localboot.early()

// Electron 38 dereferences a null Linux UI theme when it builds a framed
// window on Wayland where GTK did not initialise (fixed in 43.8 / 44.5,
// electron#54365). The USB kiosk has no title bar to lose. On Wayland a
// frameless window still draws a GTK drop shadow unless hasShadow is false.
const JEOS_FRAME =
  process.env.NEUOS_JEOS === '1' && process.env.NEUOS_FRAME !== '1'
    ? { frame: false, hasShadow: false }
    : {}

/** @type {BrowserWindow | null} */
let win = null
/** @type {Electron.Session | null} */
let browseSession = null
/** @type {Map<string, { rec: object, item?: Electron.DownloadItem }>} */
const downloads = new Map()
let downloadSeq = 0
/** @type {{ filePath: string, openAfter: boolean } | null} */
let pendingSaveAs = null
const guestContents = new WeakSet()

/**
 * Each os.neu browser window (the primary app window, plus any secondary
 * "New window" instances — WO-BROWSER-WINDOW-1 follow-up) gets its own
 * browsing controller: its own BrowserView, devtools view, and in-flight
 * navigation state. Keyed by the owning BrowserWindow's id so IPC handlers
 * can resolve "which window's browser is this call for" from the sender.
 * @typedef {{ win: Electron.BrowserWindow, view: Electron.BrowserView | null, dtView: Electron.BrowserView | null, lastGoodUrl: string, restoring: boolean, pendingLoadFinish: ((payload: object) => void) | null }} BrowseController
 * @type {Map<number, BrowseController>}
 */
const controllers = new Map()

function controllerForSender(sender) {
  const bw = BrowserWindow.fromWebContents(sender)
  return (bw && controllers.get(bw.id)) || null
}

function platformUaToken() {
  if (process.platform === 'win32') return 'Windows NT 10.0; Win64; x64'
  if (process.platform === 'darwin') return 'Macintosh; Intel Mac OS X 10_15_7'
  return 'X11; Linux x86_64'
}

function chromeUA() {
  const chrome = process.versions.chrome || '124.0.0.0'
  return `Mozilla/5.0 (${platformUaToken()}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`
}

/** Google blocks Electron Chromium on accounts.*; Firefox UA is the known guest workaround. */
function firefoxUA() {
  return `Mozilla/5.0 (${platformUaToken()}; rv:128.0) Gecko/20100101 Firefox/128.0`
}

/** Leader GRANT 2026-11-22: rewrite IdP request UA inside daf.neu browse session. */
function installBrowseIdpUa(sess) {
  if (!sess || sess.__osneuIdpUa) return
  sess.__osneuIdpUa = true
  const filter = {
    urls: [
      'https://accounts.google.com/*',
      'https://accounts.youtube.com/*',
      'https://login.microsoftonline.com/*',
      'https://login.live.com/*',
      'https://appleid.apple.com/*',
      'https://github.com/login*',
      'https://github.com/sessions/*',
    ],
  }
  sess.webRequest.onBeforeSendHeaders(filter, (details, callback) => {
    const headers = { ...details.requestHeaders }
    headers['User-Agent'] = firefoxUA()
    for (const key of Object.keys(headers)) {
      if (/^sec-ch-ua/i.test(key)) delete headers[key]
    }
    callback({ requestHeaders: headers })
  })
}

function findProtocolUrl(argv) {
  const list = Array.isArray(argv) ? argv : []
  return list.find((arg) => typeof arg === 'string' && arg.startsWith(`${PROTOCOL}://`)) || ''
}

function parseOAuthDeepLink(raw) {
  // Preferred (WO-AUTH-ELECTRON-PKCE-1): osneu://oauth?status=success&handoff=…
  // (opaque wake, no token). Legacy fallback: osneu://oauth?token=…&handoff=….
  try {
    const url = new URL(String(raw || ''))
    if (url.protocol !== `${PROTOCOL}:`) return null
    const host = url.hostname || ''
    const pathName = (url.pathname || '').replace(/^\//, '')
    const kind = host || pathName.split('/')[0] || ''
    if (kind === 'focus' || pathName === 'focus') {
      return { token: '', handoff: '', focusOnly: true }
    }
    if (kind !== 'oauth' && pathName !== 'oauth' && !pathName.startsWith('oauth')) return null
    const token = String(url.searchParams.get('token') || '').trim()
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    const status = String(url.searchParams.get('status') || '').trim()
    const hasWake = status === 'success' && Boolean(handoff)
    if (!token && !hasWake) return { token: '', handoff: '', focusOnly: true }
    return { token, handoff, focusOnly: false }
  } catch {
    return null
  }
}

function focusMainWindow() {
  // `win` (the primary window) can be closed by the user while the app stays
  // alive because a secondary "New window" instance is still open — calling
  // any method on that destroyed BrowserWindow throws "Object has been
  // destroyed", crashing the main process (hit during the Google OAuth
  // deep-link handoff, reported 2026-09-02). Fall back to focusing whichever
  // os.neu window is still open instead of assuming `win` is it.
  if (win && !win.isDestroyed()) {
    if (win.isMinimized()) win.restore()
    win.show()
    win.focus()
    return
  }
  for (const ctl of controllers.values()) {
    if (ctl.win && !ctl.win.isDestroyed()) {
      if (ctl.win.isMinimized()) ctl.win.restore()
      ctl.win.show()
      ctl.win.focus()
      return
    }
  }
}

function deliverOAuthDeepLink(raw) {
  const payload = parseOAuthDeepLink(raw)
  if (!payload) {
    // Any other osneu://… still focuses the shell.
    if (String(raw || '').startsWith(`${PROTOCOL}://`)) {
      focusMainWindow()
      return true
    }
    return false
  }
  focusMainWindow()
  if (payload.focusOnly || (!payload.token && !payload.handoff)) return true
  try {
    // Opaque wake (preferred): payload.token is '' — renderer fetches the
    // session itself via the existing handoff-poll endpoint. Legacy: token
    // is present (fallback path, pre-Console-PKCE-setup).
    win?.webContents.send('auth:oauth', { token: payload.token, handoff: payload.handoff })
  } catch {
    /* window may be closing */
  }
  return true
}

// Host-only identity-provider check (Google/Microsoft/Apple/GitHub login).
// Deliberately does NOT special-case `about:blank`/empty — that's handled by
// callers that need it (see `isAuthUrl` below). Split out for
// WO-UI-NEU-DAF-BLANK-POPUP-121 / OS-NEU-DAF-001: the guest popup handler
// must NOT treat a blank/empty `window.open()` as an IdP redirect.
function isIdpHost(url) {
  try {
    const host = new URL(url).hostname
    return (
      host === 'accounts.google.com' ||
      host === 'accounts.youtube.com' ||
      host === 'login.microsoftonline.com' ||
      host === 'login.live.com' ||
      host === 'appleid.apple.com' ||
      (host === 'github.com' && /\/login/.test(url))
    )
  } catch {
    return false
  }
}

// Kept for existing callers (did-fail-load / loadInView restore guards) —
// behavior unchanged: blank/empty still counts as "auth-like" there so a
// failed/empty load doesn't bounce the guest back to lastGoodUrl. Only the
// new setWindowOpenHandler popup-routing decision uses the narrower
// `isIdpHost` above instead of this.
function isAuthUrl(url) {
  if (!url || url === 'about:blank') return true
  return isIdpHost(url)
}

// WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND — per-origin pop-up policy
// (Default | Allow | Block). Keyed on the *opener* page's hostname (the
// guest page calling window.open), persisted to a small JSON file so a
// Leader/Block choice survives an app restart. Default = no entry.
/** @type {Map<string, 'allow' | 'block'>} */
const sitePolicy = new Map()

function sitePolicyFilePath() {
  return path.join(app.getPath('userData'), 'popup-site-policy.json')
}

function loadSitePolicy() {
  try {
    const raw = fs.readFileSync(sitePolicyFilePath(), 'utf8')
    const obj = JSON.parse(raw)
    if (obj && typeof obj === 'object') {
      for (const [host, policy] of Object.entries(obj)) {
        if (policy === 'allow' || policy === 'block') sitePolicy.set(host, policy)
      }
    }
  } catch {
    /* first run, or corrupt file — start with an empty (Default-only) store */
  }
}

function saveSitePolicy() {
  try {
    const file = sitePolicyFilePath()
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, JSON.stringify(Object.fromEntries(sitePolicy), null, 2))
  } catch {
    /* best effort — a failed write just means the choice won't survive restart */
  }
}

function hostOfUrl(url) {
  try {
    return new URL(String(url || '')).hostname
  } catch {
    return ''
  }
}

function getSitePolicy(host) {
  if (!host) return 'default'
  return sitePolicy.get(host) || 'default'
}

function setSitePolicy(host, policy) {
  if (!host) return
  if (policy === 'allow' || policy === 'block') sitePolicy.set(host, policy)
  else sitePolicy.delete(host)
  saveSitePolicy()
}

function emitPopupBlocked(ctl, host) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  try {
    ctl.win.webContents.send('browse:popup-blocked', { host })
  } catch {
    /* window may be closing */
  }
}

function isLoopbackUrl(url) {
  try {
    const host = new URL(url).hostname
    return host === 'localhost' || host === '127.0.0.1' || host === '::1'
  } catch {
    return false
  }
}

function emitBrowseNavigated(ctl, url, title) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  if (!url || !/^https?:\/\//i.test(url)) return
  try {
    ctl.win.webContents.send('browse:navigated', {
      href: url,
      title: typeof title === 'string' && title.trim() ? title.trim() : undefined,
    })
  } catch {
    /* window may be closing */
  }
}

function emitBrowseOpenTab(ctl, url) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  if (!url || !/^https?:\/\//i.test(url)) return
  try {
    ctl.win.webContents.send('browse:open-tab', { href: url })
  } catch {
    /* window may be closing */
  }
}

function emitBrowseInspect(ctl) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  try {
    ctl.win.webContents.send('browse:inspect')
  } catch {
    /* window may be closing */
  }
}

function httpHref(raw) {
  const s = String(raw || '').trim()
  if (!/^https?:\/\//i.test(s)) return ''
  try {
    return new URL(s).toString()
  } catch {
    return ''
  }
}

function filenameFromUrl(href) {
  try {
    const last = path.basename(new URL(href).pathname)
    if (last && last !== '/' && last !== '.') return last
  } catch {
    /* ignore */
  }
  return 'download'
}

const browsePermissionMemory = new Map()

function requestingOrigin(wc, details) {
  const href = (details && details.requestingUrl) || (wc && wc.getURL && wc.getURL()) || ''
  try {
    return href ? new URL(href).origin : 'this site'
  } catch {
    return 'this site'
  }
}

function isSiteSensitivePermission(permission) {
  return (
    permission === 'media' ||
    permission === 'mediaKeySystem' ||
    permission === 'clipboard-sanitized-write' ||
    permission === 'clipboard-read'
  )
}

function permissionKindLabel(permission) {
  if (permission === 'media' || permission === 'mediaKeySystem') return 'microphone / camera'
  if (permission === 'clipboard-sanitized-write' || permission === 'clipboard-read') return 'clipboard'
  return String(permission || 'permission')
}

function confirmBrowsePermission(wc, permission, callback, details) {
  if (!isSiteSensitivePermission(permission)) {
    callback(false)
    return
  }
  const origin = requestingOrigin(wc, details)
  const key = `${origin}|${permission}`
  if (browsePermissionMemory.has(key)) {
    callback(Boolean(browsePermissionMemory.get(key)))
    return
  }
  const parent = (wc && BrowserWindow.fromWebContents(wc)) || win || undefined
  const opts = {
    type: 'question',
    buttons: ['Allow', 'Deny'],
    defaultId: 1,
    cancelId: 1,
    noLink: true,
    title: 'os.neu',
    message: `${origin} wants ${permissionKindLabel(permission)}`,
    detail: 'daf.neu asks once per site.',
  }
  const ask = parent ? dialog.showMessageBox(parent, opts) : dialog.showMessageBox(opts)
  ask
    .then(({ response }) => {
      const allowed = response === 0
      browsePermissionMemory.set(key, allowed)
      callback(allowed)
    })
    .catch(() => callback(false))
}

function applyBrowseSessionPolicy(sess) {
  if (!sess) return
  sess.setUserAgent(chromeUA())
  installBrowseIdpUa(sess)
  sess.setPermissionRequestHandler((wc, permission, callback, details) => {
    confirmBrowsePermission(wc, permission, callback, details)
  })
}

function openHrefInWindow(href, opts) {
  const target = httpHref(href)
  if (!target) return
  // Leader GRANT 2026-11-22: IdP stays in daf.neu browse windows (not system Chrome).
  createBrowserAppWindow(target, opts)
}

async function saveHrefAs(contents, href, openAfter) {
  const target = httpHref(href)
  if (!target) return
  const owner =
    BrowserWindow.fromWebContents(contents) || BrowserWindow.getFocusedWindow() || win
  if (!owner || owner.isDestroyed()) return
  const result = await dialog.showSaveDialog(owner, {
    title: openAfter ? 'Open link as' : 'Save link as',
    defaultPath: path.join(app.getPath('downloads'), filenameFromUrl(target)),
  })
  if (result.canceled || !result.filePath) return
  try {
    fs.mkdirSync(path.dirname(result.filePath), { recursive: true })
  } catch {
    /* dialog already chose the path */
  }
  pendingSaveAs = { filePath: result.filePath, openAfter: Boolean(openAfter) }
  const sess = contents.session || browseSession
  if (sess) sess.downloadURL(target)
}

// WO-UI-NEU-DAF-SITE-POPUP-121 / OS-NEU-DAF-000: a real popup (explicit
// width/height features, e.g. `window.open(url, 'popup', 'width=450,height=480')`)
// must not be routed into the shared in-app tab strip. Returns the requested
// { width, height } when `features` looks popup-sized, else null.
function popupFeatureSize(features) {
  if (!features || typeof features !== 'string') return null
  const map = {}
  for (const part of features.split(',')) {
    const [rawKey, rawVal] = part.split('=')
    const key = rawKey?.trim().toLowerCase()
    if (!key) continue
    map[key] = rawVal?.trim() ?? ''
  }
  const width = Number(map.width)
  const height = Number(map.height)
  if (Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0) {
    return { width: Math.round(width), height: Math.round(height) }
  }
  return null
}

function attachGuest(guest, ctl) {
  guestContents.add(guest)
  guest.setUserAgent(chromeUA())
  guest.setWindowOpenHandler(({ url, features, disposition }) => {
    // Leader GRANT 2026-11-22: site "Sign in with Google" must finish inside
    // the daf.neu guest partition (persist:neuos-browse) so the opener site
    // gets the cookie. Seat os.neu Login still uses shell.openExternal via
    // auth.ts / browse:openExternal. IdP opens as a child BrowserWindow.
    if (isIdpHost(url)) {
      const parentWin = ctl?.win && !ctl.win.isDestroyed() ? ctl.win : undefined
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: 520,
          height: 740,
          parent: parentWin,
          modal: false,
          show: false,
          autoHideMenuBar: true,
          ...JEOS_FRAME,
          backgroundColor: '#ffffff',
          title: 'os.neu',
          icon: brandIcon(),
          webPreferences: {
            session: browseSession,
            contextIsolation: true,
            sandbox: true,
          },
        },
      }
    }
    // WO-UI-NEU-DAF-BLANK-POPUP-121 / OS-NEU-DAF-001: `about:blank` (or an
    // empty target) is NOT an IdP redirect — Korean identity/sign-up flows
    // (e.g. agriedu.net client_sign_up) open a blank child window first, then
    // navigate or `document.write` into it. Previously `isAuthUrl` treated
    // that blank open as auth-like and denied it, so the site's OWN "pop-up
    // blocked" message fired even though os.neu never asked the user for
    // permission. Blank/empty now falls through to the same child-window
    // path as a featured popup, below.
    const isBlankOpen = !url || url === 'about:blank'
    if (!isBlankOpen && !/^https?:\/\//i.test(url)) {
      return { action: 'deny' }
    }
    // Per-origin Default | Allow | Block (UI-B26 AMEND), keyed on the
    // *opener* page's host — not the target. Block stops every window.open
    // from that origin (blank or featured) and surfaces os.neu's own panel
    // instead of the site's silent/alert-style blocker message. There is no
    // global allow-all: Allow only escalates *this* origin.
    const openerHost = hostOfUrl(guest.getURL())
    const policy = getSitePolicy(openerHost)
    if (policy === 'block') {
      emitPopupBlocked(ctl, openerHost)
      return { action: 'deny' }
    }
    // Popup-featured window.open (or Chromium's own 'new-window'
    // disposition), a blank/empty window.open (identity popups), or an
    // Allowed origin all become a real child BrowserWindow. The shared
    // BrowserView backs every in-app tab, so routing a popup into that tab
    // strip instead pushes the current page out of view, and the popup's own
    // `window.close()` then bubbles up to the *window* hosting that shared
    // view — i.e. all of daf.neu — instead of closing just the popup
    // (OS-NEU-DAF-000).
    const size = popupFeatureSize(features)
    if (isBlankOpen || size || disposition === 'new-window' || policy === 'allow') {
      const parentWin = ctl?.win && !ctl.win.isDestroyed() ? ctl.win : undefined
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: size?.width || 480,
          height: size?.height || 600,
          parent: parentWin,
          modal: false,
          show: false,
          autoHideMenuBar: true,
          ...JEOS_FRAME,
          backgroundColor: '#ffffff',
          title: 'os.neu',
          icon: brandIcon(),
          webPreferences: {
            session: browseSession,
            contextIsolation: true,
            sandbox: true,
          },
        },
      }
    }
    // Plain target=_blank / foreground-tab without popup features → keep the
    // existing in-app tab behavior (WO-BROWSER-WINDOW-1), unchanged.
    emitBrowseOpenTab(ctl, url)
    return { action: 'deny' }
  })
  // The child BrowserWindow created above by the 'allow' action above needs
  // the same guest policy attached to its own webContents — auth links still
  // escape to the system browser, and a popup opened *from* a popup (nested)
  // still becomes its own child rather than hijacking this one. `ctl.win` here
  // is the popup window itself, so nav-tracking IPC sends below are harmless
  // no-ops (a bare popup has no preload/React listener for them).
  guest.on('did-create-window', (childWindow, details) => {
    const childCtl = {
      win: childWindow,
      view: null,
      dtView: null,
      lastGoodUrl: details?.url || '',
      restoring: false,
      pendingLoadFinish: null,
    }
    attachGuest(childWindow.webContents, childCtl)
    childWindow.once('ready-to-show', () => {
      if (!childWindow.isDestroyed()) childWindow.show()
    })
    // Belt-and-suspenders, matching createWindow()/createBrowserAppWindow(): if
    // ready-to-show never fires, don't leave the popup invisible forever.
    childWindow.webContents.once('did-finish-load', () => {
      if (!childWindow.isDestroyed() && !childWindow.isVisible()) childWindow.show()
    })
  })
  guest.on('will-redirect', (event, url) => {
    if (/^(https?:|about:)/i.test(url)) return
    event.preventDefault()
  })
  guest.on('did-fail-load', (_event, code, _desc, failedUrl, isMain) => {
    if (!isMain || code === -3 || ctl.restoring) return
    if (isAuthUrl(failedUrl)) return
    // Never bounce a failed loopback (e.g. Ollama :11434) back to the last public site.
    if (isLoopbackUrl(failedUrl)) return
    if (ctl.lastGoodUrl && failedUrl !== ctl.lastGoodUrl) {
      ctl.restoring = true
      void guest.loadURL(ctl.lastGoodUrl).finally(() => {
        ctl.restoring = false
      })
    }
  })
  guest.on('did-navigate', (_event, url) => {
    if (ctl.restoring) return
    if (/^https?:\/\//i.test(url) && !isAuthUrl(url) && !isLoopbackUrl(url)) ctl.lastGoodUrl = url
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('did-navigate-in-page', (_event, url, isMainFrame) => {
    if (!isMainFrame || ctl.restoring) return
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('did-redirect-navigation', (_event, url, isInPlace, isMainFrame) => {
    if (!isMainFrame || ctl.restoring) return
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('page-title-updated', (_event, title) => {
    if (ctl.restoring) return
    emitBrowseNavigated(ctl, guest.getURL(), title)
  })
}

/** Renderer chrome pulse. If it stops, hide the guest so it cannot sit on a black hole. */
const seatPulseAt = new Map()
const SEAT_STALE_MS = 4000

function hideSeatViews(ctl) {
  ctl?.view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  hideDevTools(ctl)
}

function watchSeatRenderer(bw) {
  const wc = bw.webContents
  const tick = setInterval(() => {
    if (bw.isDestroyed() || wc.isDestroyed()) {
      clearInterval(tick)
      return
    }
    const last = seatPulseAt.get(wc.id) || 0
    if (!last || Date.now() - last < SEAT_STALE_MS) return
    hideSeatViews(controllers.get(bw.id))
    seatPulseAt.set(wc.id, Date.now())
    wc.reload()
  }, 1000)
  bw.on('closed', () => {
    clearInterval(tick)
    seatPulseAt.delete(wc.id)
  })
  wc.on('render-process-gone', () => {
    hideSeatViews(controllers.get(bw.id))
    if (!wc.isDestroyed()) {
      seatPulseAt.set(wc.id, Date.now())
      wc.reload()
    }
  })
  wc.on('unresponsive', () => {
    hideSeatViews(controllers.get(bw.id))
  })
}

ipcMain.handle('seat:pulse', (evt) => {
  seatPulseAt.set(evt.sender.id, Date.now())
  return { ok: true }
})

/** Registers a fresh browsing controller for `bw` and cleans it up on close. */
function makeController(bw) {
  /** @type {BrowseController} */
  const ctl = { win: bw, view: null, dtView: null, lastGoodUrl: '', restoring: false, pendingLoadFinish: null }
  controllers.set(bw.id, ctl)
  bw.on('closed', () => controllers.delete(bw.id))
  watchSeatRenderer(bw)
  return ctl
}

/** Gives a browsing controller its own BrowserView, attached to its own window. */
function attachBrowseView(ctl, sess) {
  const browseSess = sess || browseSession
  const view = new BrowserView({
    webPreferences: {
      session: browseSess,
      contextIsolation: true,
      sandbox: true,
      javascript: true,
      images: true,
      webviewTag: false,
    },
  })
  view.setBackgroundColor('#ffffff')
  ctl.win.addBrowserView(view)
  view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  ctl.view = view
  attachGuest(view.webContents, ctl)
  return view
}

/**
 * "New window" (WO-BROWSER-WINDOW-1 follow-up, issue B1): a bare BrowserWindow
 * loading the raw target page has no address bar, tabs, or bookmarks — "no
 * functionability" per Leader's verify. Real parity with the primary window
 * means loading *our own renderer* (same as `createWindow`) in a second
 * window, routed straight to the browser phase with its target pre-opened —
 * it gets the full `LandingBrowser`/`BrowserChrome` UI (tabs, address bar,
 * bookmarks, history) for free, backed by its own BrowserView/controller so
 * it never fights the primary window's shared view.
 *
 * WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): titled `os.neu` this stacked
 * with the primary window's own `os.neu` StatusBar and Chrome's omnibox —
 * three address surfaces, "어느 URL을 치나" (Leader capture, Control NOTE
 * 2026-09-12). Title this `daf.neu` instead (this window *is* the product
 * browser), and parent it to the primary os.neu window so it opens in front
 * of it, closes independently, and is never mistaken for a second os.neu
 * desktop. Not modal (parent stays interactive/visible) and not
 * alwaysOnTop (only above its own parent, not every app).
 */
function createBrowserAppWindow(initialUrl, opts) {
  const privateMode = Boolean(opts && opts.private)
  let sess = browseSession
  if (privateMode) {
    sess = session.fromPartition(`daf-private-${Date.now()}`)
    applyBrowseSessionPolicy(sess)
    watchDownloads(sess)
  }
  const child = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 480,
    minHeight: 540,
    backgroundColor: '#0b0c0a',
    icon: brandIcon(),
    title: privateMode ? 'daf.neu · private' : 'daf.neu',
    show: false,
    autoHideMenuBar: true,
    ...JEOS_FRAME,
    resizable: true,
    maximizable: true,
    fullscreenable: true,
    parent: win && !win.isDestroyed() ? win : undefined,
    modal: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  const ctl = makeController(child)
  attachBrowseView(ctl, sess)

  // Electron syncs a BrowserWindow's native title to its page's
  // `document.title` by default — our own renderer's <title> is the static
  // "os.neu …" from the renderer title, which would silently clobber the
  // `title: 'daf.neu'` above the instant this window's page finishes
  // loading. Lock it so the OS-level title bar / taskbar entry for this
  // window stays `daf.neu` (the whole point of UI-B17: one product name per
  // window, no more stacked "os.neu" surfaces).
  child.on('page-title-updated', (event) => {
    event.preventDefault()
  })

  let target
  try {
    target = new URL(uiHomeUrl())
  } catch {
    target = new URL('http://127.0.0.1:5173')
  }
  target.searchParams.set('go', 'landing')
  if (initialUrl) target.searchParams.set('openTarget', initialUrl)
  void child.loadURL(target.toString())
  let host = '?'
  try {
    host = new URL(initialUrl || WEB_HOME).host
  } catch {
    /* keep ? */
  }
  appMark(`DAF_WINDOW created target_host=${host}`)
  child.webContents.once('did-finish-load', () => appMark('DAF_WINDOW did-finish-load'))
  child.once('ready-to-show', () => {
    child.show()
    child.maximize()
    child.focus()
    child.moveTop()
  })
  // Belt-and-suspenders: if `ready-to-show` never fires (e.g. renderer load
  // error), don't leave the window invisible forever — same fallback the
  // primary window uses in createWindow().
  child.webContents.once('did-finish-load', () => {
    if (!child.isDestroyed() && !child.isVisible()) {
      child.show()
      child.focus()
      child.moveTop()
    }
  })
  return child
}

function markWindowReady() {
  try {
    fs.writeFileSync('/tmp/osneu-window-ok', '1')
  } catch {
    /* JeOS /tmp may be missing; serial marker still helps the virt harness */
  }
  process.stdout.write('NEUOS_VIRT_WINDOW_OK\n')
}

// One line per app milestone. JeOS: /tmp for scripts/input-diag.mjs follow.
// Local boot (OSNEU_BOOT_DIR from osneu-local-kiosk.sh): that boot's folder.
function appMarkFile() {
  if (process.env.OSNEU_BOOT_DIR) return path.join(process.env.OSNEU_BOOT_DIR, 'marks.log')
  if (process.env.NEUOS_JEOS === '1') return '/tmp/osneu-app-marks.log'
  return ''
}

function appMark(line) {
  const file = appMarkFile()
  if (!file) return
  try {
    fs.appendFileSync(file, `${new Date().toISOString()} ${line}\n`)
  } catch {
    /* folder missing */
  }
}

function captureBootScreens(target) {
  const dir = process.env.OSNEU_BOOT_DIR
  if (!dir) return
  for (const sec of [3, 20]) {
    setTimeout(() => {
      if (!target || target.isDestroyed()) return
      target.webContents
        .capturePage()
        .then((img) => {
          const name = `screen-${String(sec).padStart(2, '0')}s.png`
          fs.writeFileSync(path.join(dir, name), img.toPNG())
          const { width, height } = img.getSize()
          appMark(`SCREEN_CAPTURE ${name} ${width}x${height}`)
        })
        .catch((err) => appMark(`SCREEN_CAPTURE failed ${err instanceof Error ? err.message : err}`))
    }, sec * 1000)
  }
}

// JeOS only: method, path and status of renderer calls to the local bridge,
// plus the landing's two network-probe URLs (src/engine/network.ts).
// Paths only — no query strings, bodies or headers.
const NET_PROBE_URLS = ['https://www.gstatic.com/generate_204*', 'https://cloudflare.com/cdn-cgi/trace*']
function watchLocalApi() {
  if (!appMarkFile()) return
  const bridge = `127.0.0.1:${process.env.NEUOS_BRIDGE_PORT || '4178'}`
  const filter = { urls: [`http://${bridge}/api/*`, ...NET_PROBE_URLS] }
  const label = (u) => {
    try {
      const x = new URL(u)
      return x.host === bridge ? `API` : `NET_PROBE ${x.host}`
    } catch {
      return 'API'
    }
  }
  const pathOf = (u) => {
    try {
      return new URL(u).pathname
    } catch {
      return u
    }
  }
  session.defaultSession.webRequest.onCompleted(filter, (d) => {
    const p = pathOf(d.url)
    if (p === '/api/health') return
    appMark(`${label(d.url)} ${d.method} ${p} ${d.statusCode}`)
  })
  session.defaultSession.webRequest.onErrorOccurred(filter, (d) => {
    const p = pathOf(d.url)
    if (p === '/api/health') return
    appMark(`${label(d.url)} ${d.method} ${p} ERROR ${d.error}`)
  })
}

// Local boot only: the reason field of failed bridge replies and the state of
// the Google login handoff poll. Whitelisted fields only, secrets masked.
const REASON_FIELDS = ['ok', 'status', 'reason', 'error', 'message', 'code', 'detail', 'provider', 'model']
function maskSecrets(text) {
  return String(text)
    .replace(/sk-[A-Za-z0-9_-]{6,}/g, 'sk-***')
    .replace(/eyJ[A-Za-z0-9_.-]{10,}/g, 'eyJ***')
    .replace(/[A-Fa-f0-9]{32,}/g, '<hex>')
}
function summarizeReply(body) {
  let data
  try {
    data = JSON.parse(body)
  } catch {
    return `text="${maskSecrets(String(body).slice(0, 160)).replace(/\s+/g, ' ')}"`
  }
  if (!data || typeof data !== 'object') return `value=${maskSecrets(String(data).slice(0, 80))}`
  const parts = []
  for (const key of REASON_FIELDS) {
    const v = data[key]
    if (v === undefined || v === null || typeof v === 'object') continue
    parts.push(`${key}=${maskSecrets(String(v).slice(0, 160)).replace(/\s+/g, ' ')}`)
  }
  if ('session' in data || 'token' in data || 'access_token' in data) {
    parts.push(`session=${data.session || data.token || data.access_token ? 'present' : 'none'}`)
  }
  return parts.join(' ') || `keys=${Object.keys(data).slice(0, 8).join(',')}`
}
function watchApiReasons(bw) {
  if (!process.env.OSNEU_BOOT_DIR) return
  const bridge = `127.0.0.1:${process.env.NEUOS_BRIDGE_PORT || '4178'}`
  const dbg = bw.webContents.debugger
  const pending = new Map()
  const lastHandoff = { value: '' }
  try {
    dbg.attach('1.3')
  } catch (err) {
    appMark(`API_REASON off ${err instanceof Error ? err.message : err}`)
    return
  }
  dbg.on('message', (_e, method, params) => {
    if (method === 'Network.responseReceived') {
      const res = params.response || {}
      let p = ''
      try {
        const u = new URL(res.url)
        if (u.host !== bridge || !u.pathname.startsWith('/api/')) return
        p = u.pathname
      } catch {
        return
      }
      const handoff = p.startsWith('/api/auth/oauth/')
      if (res.status >= 400 || handoff) pending.set(params.requestId, { p, status: res.status, handoff })
      return
    }
    if (method !== 'Network.loadingFinished' && method !== 'Network.loadingFailed') return
    const hit = pending.get(params.requestId)
    if (!hit) return
    pending.delete(params.requestId)
    if (method === 'Network.loadingFailed') {
      appMark(`API_REASON ${hit.status} ${hit.p} load-failed ${params.errorText || ''}`)
      return
    }
    dbg
      .sendCommand('Network.getResponseBody', { requestId: params.requestId })
      .then(({ body, base64Encoded }) => {
        const text = base64Encoded ? Buffer.from(body, 'base64').toString('utf8') : body
        const line = `${hit.status} ${hit.p} ${summarizeReply(text)}`
        if (hit.handoff) {
          if (line === lastHandoff.value) return
          lastHandoff.value = line
          appMark(`LOGIN_HANDOFF ${line}`)
          if (/session=present|status=(done|success|complete)/.test(line)) closeLoginBrowser()
          return
        }
        appMark(`API_REASON ${line}`)
      })
      .catch(() => appMark(`API_REASON ${hit.status} ${hit.p} body-unavailable`))
  })
  dbg.on('detach', (_e, reason) => appMark(`API_REASON detached ${reason}`))
  dbg.sendCommand('Network.enable').catch((err) => appMark(`API_REASON off ${err instanceof Error ? err.message : err}`))
}

// Local boot: page zoom instead of Chromium's scale flag (which offsets the
// mouse on Wayland). Applied once per page; the user's later zoom is kept.
function installKioskZoom() {
  const zoom = Number(process.env.OSNEU_ZOOM || 0)
  if (!localboot.ACTIVE || !(zoom > 0) || zoom === 1) return
  appMark(`ZOOM page=${zoom}`)
  app.on('web-contents-created', (_e, wc) => {
    wc.on('did-finish-load', () => {
      if (wc.isDestroyed()) return
      if (Math.abs(wc.getZoomFactor() - 1) < 0.01) wc.setZoomFactor(zoom)
    })
  })
}

// Local boot: company logo while the bridge and the os.neu screen load. The
// os.neu window stays hidden until it has painted and the logo had its time.
let bootSplash = null
let bootSplashAt = 0
function showBootSplash() {
  if (!localboot.ACTIVE || process.env.OSNEU_SPLASH === '0') return
  let logo = ''
  try {
    logo = fs.readFileSync(path.join(__dirname, '..', 'public', 'brand', 'neuavenue-logo.png')).toString('base64')
  } catch (err) {
    appMark(`SPLASH logo missing ${err instanceof Error ? err.message : err}`)
    return
  }
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>os.neu start</title><style>
html,body{margin:0;height:100%;background:#fff;overflow:hidden}
body{display:flex;align-items:center;justify-content:center}
img{width:min(56vw,1100px);height:auto;animation:in 900ms ease-out both}
@keyframes in{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:none}}
</style></head><body><img alt="Neuavenue" src="data:image/png;base64,${logo}"></body></html>`
  bootSplash = new BrowserWindow({
    width: 1280,
    height: 800,
    backgroundColor: '#ffffff',
    title: 'os.neu start',
    frame: false,
    autoHideMenuBar: true,
    webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false },
  })
  bootSplash.on('page-title-updated', (event) => event.preventDefault())
  bootSplash.on('closed', () => {
    bootSplash = null
  })
  bootSplashAt = Date.now()
  void bootSplash.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`)
  appMark('SPLASH shown')
}

function closeBootSplash(then) {
  const minMs = Number(process.env.OSNEU_SPLASH_MS || 2500)
  const wait = Math.max(0, bootSplashAt + minMs - Date.now())
  setTimeout(() => {
    if (bootSplash && !bootSplash.isDestroyed()) {
      bootSplash.close()
      appMark('SPLASH closed')
    }
    if (then) then()
  }, bootSplash ? wait : 0)
}

// Renderer rects are CSS pixels; view bounds are window pixels.
function zoomedRect(sender, rect) {
  if (!rect) return { x: 0, y: 0, width: 0, height: 0 }
  let z = 1
  try {
    z = sender.getZoomFactor() || 1
  } catch {
    z = 1
  }
  return {
    x: Math.round((rect.x || 0) * z),
    y: Math.round((rect.y || 0) * z),
    width: Math.max(0, Math.round((rect.width || 0) * z)),
    height: Math.max(0, Math.round((rect.height || 0) * z)),
  }
}

// Local boot: Google refuses sign-in inside embedded Electron windows, so the
// login page opens in Google Chrome (own profile). sway floats it above
// os.neu; it is closed once the login handoff reports a session.
const SYSTEM_BROWSERS = ['/usr/bin/google-chrome-stable', '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/snap/bin/chromium']
let loginBrowser = null

// sway draws no title buttons, so Chrome must draw its own frame (close,
// minimize, maximize, resize edges). --app windows ignore this; normal ones honour it.
function ensureChromeOwnFrame(profile) {
  const file = path.join(profile, 'Default', 'Preferences')
  let prefs = {}
  try {
    prefs = JSON.parse(fs.readFileSync(file, 'utf8')) || {}
  } catch {
    prefs = {}
  }
  if (prefs.browser && prefs.browser.custom_chrome_frame === true) return
  prefs.browser = { ...(prefs.browser || {}), custom_chrome_frame: true }
  const text = JSON.stringify(prefs)
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true })
    const tmp = `${file}.${process.pid}.tmp`
    fs.writeFileSync(tmp, text)
    if (fs.statSync(tmp).size > 1) fs.renameSync(tmp, file)
    appMark('LOGIN_BROWSER frame=chrome')
  } catch (err) {
    appMark(`LOGIN_BROWSER frame pref failed ${err.message}`)
  }
}

function openInSystemBrowser(url) {
  const bin = SYSTEM_BROWSERS.find((p) => fs.existsSync(p))
  if (!bin) {
    appMark('LOGIN_BROWSER none, using in-app window')
    openInAppWindow(url)
    return
  }
  let where = 'invalid-url'
  try {
    const u = new URL(url)
    where = `${u.host}${u.pathname}`
  } catch {
    /* keep */
  }
  const profile = path.join(app.getPath('userData'), 'login-browser')
  let running = false
  try {
    fs.lstatSync(path.join(profile, 'SingletonLock'))
    running = true
  } catch {
    running = false
  }
  if (!running) ensureChromeOwnFrame(profile)
  const child = spawn(
    bin,
    [`--user-data-dir=${profile}`, '--new-window', '--window-size=1100,820', '--no-first-run', '--no-default-browser-check', url],
    { stdio: 'ignore' },
  )
  loginBrowser = child
  appMark(`LOGIN_BROWSER open ${path.basename(bin)} ${where}`)
  child.on('error', (err) => appMark(`LOGIN_BROWSER error ${err.message}`))
  child.on('exit', (code, signal) => {
    appMark(`LOGIN_BROWSER exit code=${code} signal=${signal || ''}`)
    if (loginBrowser === child) loginBrowser = null
  })
}

function closeLoginBrowser() {
  if (!loginBrowser) return
  try {
    loginBrowser.kill('SIGTERM')
  } catch {
    /* already gone */
  }
  loginBrowser = null
  focusMainWindow()
}

// Local boot has no desktop browser for shell.openExternal, so links (Google
// login included) open in an os.neu window. The login window closes itself
// after the bridge callback page loads.
function openInAppWindow(url) {
  const bridge = `127.0.0.1:${process.env.NEUOS_BRIDGE_PORT || '4178'}`
  const where = (u) => {
    try {
      const x = new URL(u)
      return `${x.host}${x.pathname}`
    } catch {
      return 'invalid-url'
    }
  }
  const login = new BrowserWindow({
    width: 1100,
    height: 820,
    backgroundColor: '#0b0c0a',
    icon: brandIcon(),
    title: 'os.neu login',
    autoHideMenuBar: true,
    parent: win && !win.isDestroyed() ? win : undefined,
    webPreferences: {
      session: browseSession || session.defaultSession,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  appMark(`LOGIN_WINDOW open ${where(url)}`)
  login.on('page-title-updated', (event) => event.preventDefault())
  const wc = login.webContents
  wc.setWindowOpenHandler(({ url: next }) => {
    void wc.loadURL(next)
    return { action: 'deny' }
  })
  wc.on('will-navigate', (event, next) => {
    if (String(next).startsWith(`${PROTOCOL}://`)) {
      event.preventDefault()
      appMark('LOGIN_WINDOW deep-link')
      deliverOAuthDeepLink(next)
      if (!login.isDestroyed()) login.close()
    }
  })
  wc.on('did-navigate', (_e, next, code) => {
    appMark(`LOGIN_WINDOW navigate ${code} ${where(next)}`)
    let u
    try {
      u = new URL(next)
    } catch {
      return
    }
    if (u.host === bridge && u.pathname === '/api/auth/callback') {
      setTimeout(() => {
        if (!login.isDestroyed()) login.close()
        focusMainWindow()
      }, 2000)
    }
  })
  wc.on('did-fail-load', (_e, code, desc, failed) => appMark(`LOGIN_WINDOW fail ${code} ${desc} ${where(failed)}`))
  login.on('closed', () => appMark('LOGIN_WINDOW closed'))
  void login.loadURL(url)
}

// JeOS only: counts of input the page itself received (last stage of the input
// chain). scripts/input-diag.mjs reads this file; no event content is stored.
function watchAppInput(bw) {
  if (process.env.NEUOS_JEOS !== '1') return
  const counts = { mouseMove: 0, mouseDown: 0, mouseUp: 0, mouseWheel: 0, keyDown: 0, rawKeyDown: 0, char: 0 }
  let dirty = false
  bw.webContents.on('input-event', (_evt, input) => {
    if (input && Object.prototype.hasOwnProperty.call(counts, input.type)) {
      counts[input.type]++
      dirty = true
    }
  })
  const tick = setInterval(() => {
    if (bw.isDestroyed()) {
      clearInterval(tick)
      return
    }
    if (!dirty) return
    dirty = false
    try {
      fs.writeFileSync('/tmp/osneu-app-input.json', JSON.stringify(counts))
    } catch {
      /* /tmp missing */
    }
  }, 2000)
  try {
    fs.writeFileSync('/tmp/osneu-app-input.json', JSON.stringify(counts))
  } catch {
    /* /tmp missing */
  }
}

// ---------- JeOS boot setup: Wi-Fi + diagnostics (electron/wifi.html) ----------
// Offline USB seat: the splash look, blurred, with a Wi-Fi card; then the same
// four steps as the boot splash (daf.neu network, app.neu, AI workspace).

function hasDefaultRoute() {
  try {
    return fs
      .readFileSync('/proc/net/route', 'utf8')
      .split('\n')
      .slice(1)
      .some((l) => l.trim().split(/\s+/)[1] === '00000000')
  } catch {
    return true
  }
}

function runNodeScript(script, args, input, timeoutMs) {
  const stickNode = path.join(treeRoot(), 'runtime', 'node')
  const cmd = fs.existsSync(stickNode) ? stickNode : process.execPath
  const env = cmd === stickNode ? { ...process.env } : { ...process.env, ELECTRON_RUN_AS_NODE: '1' }
  return new Promise((resolve) => {
    const child = spawn(cmd, [path.join(treeRoot(), 'scripts', script), ...args], { env, stdio: ['pipe', 'pipe', 'ignore'] })
    let out = ''
    const timer = setTimeout(() => child.kill('SIGKILL'), timeoutMs)
    child.stdout.on('data', (b) => {
      out += b
    })
    child.on('error', () => {
      clearTimeout(timer)
      resolve({ code: -1, out })
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      resolve({ code, out })
    })
    child.stdin.end(input ? JSON.stringify(input) : '')
  })
}

async function wifiCall(cmd, input) {
  const r = await runNodeScript('osneu-wifi.mjs', [cmd], input, cmd === 'connect' ? 60_000 : 30_000)
  const line = r.out.trim().split('\n').pop() || ''
  try {
    return JSON.parse(line)
  } catch {
    return { ok: false, error: `Wi-Fi helper failed (exit ${r.code})` }
  }
}

async function netdiagChecks(mode) {
  await runNodeScript('osneu-netdiag.mjs', [mode, '--quiet'], null, 60_000)
  try {
    return JSON.parse(fs.readFileSync('/tmp/osneu-netdiag.json', 'utf8'))
  } catch {
    return { checks: {} }
  }
}

// Host (non-JeOS) runs of osneu-netdiag.mjs only report, into os.tmpdir().
async function hostNetdiag(mode) {
  await runNodeScript('osneu-netdiag.mjs', [mode, '--quiet'], null, 60_000)
  try {
    return JSON.parse(fs.readFileSync(path.join(require('node:os').tmpdir(), 'osneu-netdiag-host.json'), 'utf8'))
  } catch {
    return { checks: {} }
  }
}

/** @type {BrowserWindow | null} */
let setupWin = null
let setupDone = null
// The setup window closes before the main window opens; do not quit in between.
let setupBeforeMain = false

function openSetup() {
  if (setupWin && !setupWin.isDestroyed()) {
    setupWin.focus()
    return setupDone
  }
  setupWin = new BrowserWindow({
    width: 1280,
    height: 800,
    backgroundColor: '#0a1020',
    title: 'os.neu setup',
    icon: brandIcon(),
    autoHideMenuBar: true,
    ...JEOS_FRAME,
    parent: win && !win.isDestroyed() ? win : undefined,
    modal: Boolean(win && !win.isDestroyed()),
    webPreferences: {
      preload: path.join(__dirname, 'wifi-preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  if (process.env.NEUOS_SCREEN === '1') setupWin.maximize()
  appMark('SETUP_WINDOW opened (offline seat)')
  setupDone = new Promise((resolve) => {
    let result = { online: hasDefaultRoute() }
    setupWin.on('closed', () => {
      setupWin = null
      appMark(`SETUP_WINDOW closed online=${result.online}`)
      resolve(result)
    })
    setupWin.webContents.ipc.handle('setup:done', (_e, r) => {
      result = { online: Boolean(r && r.online) || hasDefaultRoute() }
      setupWin?.close()
    })
  })
  const wc = setupWin.webContents
  wc.ipc.handle('setup:wifi:status', () => wifiCall('status'))
  wc.ipc.handle('setup:wifi:scan', () => wifiCall('scan'))
  wc.ipc.handle('setup:wifi:connect', (_e, p) => wifiCall('connect', { ssid: String(p?.ssid || ''), password: String(p?.password || '') }))
  wc.ipc.handle('setup:diag', (_e, mode) => netdiagChecks(mode === 'ai' ? 'ai' : 'connect'))
  void setupWin.loadFile(path.join(__dirname, 'wifi.html'))
  setupWin.show()
  setupWin.focus()
  return setupDone
}

function createWindow() {
  const ua = chromeUA()
  app.userAgentFallback = ua
  session.defaultSession.setUserAgent(ua)
  // os.neu UI session (Speak / in-app). daf.neu uses browseSession per-site confirm (P0-③).
  // Any other origin that lands in this session gets the same per-site confirm.
  session.defaultSession.setPermissionRequestHandler((wc, permission, callback, details) => {
    const from = (details && details.requestingUrl) || (wc && wc.getURL && wc.getURL()) || ''
    if (!isOwnUiUrl(from)) {
      confirmBrowsePermission(wc, permission, callback, details)
      return
    }
    callback(
      permission === 'media' ||
        permission === 'notifications' ||
        permission === 'clipboard-sanitized-write' ||
        permission === 'fullscreen' ||
        permission === 'pointerLock' ||
        permission === 'storage-access',
    )
  })
  browseSession = session.fromPartition('persist:neuos-browse')
  browseSession.setUserAgent(ua)
  installBrowseIdpUa(browseSession)
  browseSession.setPermissionRequestHandler((wc, permission, callback, details) => {
    confirmBrowsePermission(wc, permission, callback, details)
  })

  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 480,
    minHeight: 540,
    backgroundColor: '#0b0c0a',
    icon: brandIcon(),
    title: 'os.neu',
    show: !bootSplash,
    autoHideMenuBar: true,
    ...JEOS_FRAME,
    resizable: true,
    maximizable: true,
    fullscreenable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })

  localboot.guardWindow(win)
  const ctl = makeController(win)
  attachBrowseView(ctl)
  watchDownloads(browseSession)
  win.on('closed', () => {
    win = null
  })

  void win.loadURL(uiHomeUrl())
  appMark(`APP_WINDOW created url=${uiHomeUrl()} (loadURL issued; not yet painted)`)
  win.webContents.on('did-navigate', (_e, url, code, status) => appMark(`APP_WINDOW navigate ${code} ${status || ''} ${url}`))
  win.webContents.once('did-finish-load', () => {
    const [w, h] = win ? win.getContentSize() : [0, 0]
    appMark(`APP_WINDOW did-finish-load title=${win ? win.webContents.getTitle() : ''} size=${w}x${h}`)
    markWindowReady()
    captureBootScreens(win)
  })
  if (bootSplash) {
    const reveal = () => {
      if (win && !win.isDestroyed() && !win.isVisible()) {
        win.show()
        if (process.env.NEUOS_SCREEN === '1') win.maximize()
        win.focus()
      }
    }
    win.webContents.once('did-finish-load', () => closeBootSplash(reveal))
    setTimeout(() => closeBootSplash(reveal), 20_000)
  }
  win.webContents.on('did-fail-load', (_e, code, desc) => appMark(`APP_WINDOW did-fail-load ${code} ${desc}`))
  win.webContents.on('render-process-gone', (_e, d) => appMark(`APP_RENDERER gone reason=${d && d.reason}`))
  watchAppInput(win)
  watchLocalApi()
  watchApiReasons(win)
  win.on('close', () => appMark('APP_WINDOW close requested'))
  if (process.env.NEUOS_JEOS === '1') {
    win.webContents.on('before-input-event', (_e, input) => {
      if (input.type === 'keyDown' && input.control && input.alt && String(input.key).toLowerCase() === 'w') {
        void openSetup().then((r) => {
          if (r.online) win?.reload()
        })
      }
    })
  }
  if (bootSplash) return
  win.once('ready-to-show', () => {
    win?.show()
    win?.focus()
    if (process.env.NEUOS_SCREEN === '1') win?.maximize()
  })
  if (process.env.NEUOS_SCREEN === '1') {
    win.maximize()
  }
  win.show()
  win.focus()
}

function uniqueSavePath(filename) {
  const dir = app.getPath('downloads')
  const ext = path.extname(filename)
  const base = path.basename(filename, ext) || 'download'
  let dest = path.join(dir, filename || 'download')
  let i = 1
  while (fs.existsSync(dest)) {
    dest = path.join(dir, `${base} (${i})${ext}`)
    i += 1
  }
  return dest
}

function emitDownload(rec) {
  // Downloads happen on the shared browsing session's partition regardless
  // of which window's view triggered them — broadcast to every open os.neu
  // browser window's renderer so each one's download panel stays in sync.
  for (const ctl of controllers.values()) {
    if (ctl.win && !ctl.win.isDestroyed()) ctl.win.webContents.send('browse:download', rec)
  }
}

function watchDownloads(sess) {
  if (!sess || sess.__neuosDownloads) return
  sess.__neuosDownloads = true
  sess.on('will-download', (_event, item) => {
    const id = `dl-${Date.now()}-${downloadSeq}`
    downloadSeq += 1
    const choice = pendingSaveAs
    pendingSaveAs = null
    const filename = item.getFilename() || (choice ? path.basename(choice.filePath) : 'download')
    const rec = {
      id,
      filename,
      url: item.getURL(),
      path: choice?.filePath || uniqueSavePath(filename),
      mime: item.getMimeType(),
      bytes: item.getTotalBytes() || 0,
      received: 0,
      state: 'progress',
      t: Date.now(),
      openAfter: Boolean(choice?.openAfter),
    }
    item.setSavePath(rec.path)
    downloads.set(id, { rec, item })
    emitDownload(rec)
    item.on('updated', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.bytes = item.getTotalBytes() || rec.bytes
      rec.state = state === 'interrupted' ? 'failed' : 'progress'
      emitDownload({ ...rec })
    })
    item.once('done', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.state = state === 'completed' ? 'done' : state === 'cancelled' ? 'cancelled' : 'failed'
      emitDownload({ ...rec })
      if (rec.openAfter && rec.state === 'done' && rec.path) {
        void shell.openPath(rec.path)
      }
    })
  })
}

function ensureDevTools(ctl) {
  if (!ctl?.win || !ctl.view) return
  if (!ctl.dtView) {
    const dtView = new BrowserView({
      webPreferences: {
        sandbox: false,
        contextIsolation: true,
      },
    })
    dtView.setBackgroundColor('#1b1c17')
    ctl.win.addBrowserView(dtView)
    dtView.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    ctl.dtView = dtView
  }
  ctl.view.webContents.setDevToolsWebContents(ctl.dtView.webContents)
}

function hideDevTools(ctl) {
  ctl?.dtView?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  if (ctl?.view?.webContents.isDevToolsOpened()) ctl.view.webContents.closeDevTools()
}

// Only one navigation can be in flight on a given window's BrowserView at a
// time. If a newer loadInView() call supersedes an older one (e.g. quickly
// typing a URL in tab A then switching/navigating tab B before A finishes),
// Chromium aborts A's load with did-fail-load code -3 (ERR_ABORTED).
// Previously that was silently ignored, so A's promise never resolved and
// its tab stayed stuck on "loading" forever — the caller had to hit Reload
// to recover (reported while verifying WO-BROWSER-SESSION-1). Track the
// pending finish() on the controller so a superseded call resolves
// immediately instead of hanging.
function loadInView(ctl, url) {
  return new Promise((resolve) => {
    if (!ctl?.view) {
      resolve({ ok: false, reason: 'no-view' })
      return
    }
    if (ctl.pendingLoadFinish) {
      const superseded = ctl.pendingLoadFinish
      ctl.pendingLoadFinish = null
      superseded({ ok: false, reason: 'superseded' })
    }
    const wc = ctl.view.webContents
    const finish = (payload) => {
      wc.removeListener('did-finish-load', onOk)
      wc.removeListener('did-fail-load', onFail)
      if (ctl.pendingLoadFinish === finish) ctl.pendingLoadFinish = null
      resolve(payload)
    }
    ctl.pendingLoadFinish = finish
    const onFail = (_e, code, desc, failedUrl, isMain) => {
      if (!isMain) return
      // Aborted because a newer navigation superseded this one — already
      // resolved above; nothing left to do for this stale request.
      if (code === -3) return
      if (isAuthUrl(failedUrl) || isAuthUrl(url)) {
        finish({ ok: false, reason: desc || String(code), href: failedUrl })
        return
      }
      // Loopback failures must not silently restore www.neuavenue.com.
      if (isLoopbackUrl(url) || isLoopbackUrl(failedUrl)) {
        finish({ ok: false, reason: desc || String(code), href: failedUrl || url })
        return
      }
      if (ctl.lastGoodUrl && failedUrl !== ctl.lastGoodUrl) {
        ctl.restoring = true
        void wc.loadURL(ctl.lastGoodUrl).finally(() => {
          ctl.restoring = false
        })
        finish({ ok: true, href: ctl.lastGoodUrl, restored: true, reason: desc || String(code) })
        return
      }
      finish({ ok: false, reason: desc || String(code), href: failedUrl })
    }
    const onOk = () => {
      const href = wc.getURL()
      if (!href || href === 'about:blank') {
        finish({ ok: true, href: url })
        return
      }
      if (/^https?:\/\//i.test(href) && !isAuthUrl(href) && !isLoopbackUrl(href)) ctl.lastGoodUrl = href
      finish({ ok: true, href })
    }
    wc.on('did-finish-load', onOk)
    wc.on('did-fail-load', onFail)
    void wc.loadURL(url, { userAgent: isIdpHost(url) ? firefoxUA() : chromeUA() })
  })
}

ipcMain.handle('browse:go', async (evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, reason: 'http(s) only' }
  }
  return loadInView(controllerForSender(evt.sender), url)
})

ipcMain.handle('browse:back', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  if (hist?.canGoBack?.()) {
    hist.goBack()
    return { ok: true, href: wc.getURL() }
  }
  if (wc.canGoBack()) {
    wc.goBack()
    return { ok: true, href: wc.getURL() }
  }
  if (ctl.lastGoodUrl) {
    return loadInView(ctl, ctl.lastGoodUrl)
  }
  return { ok: false, reason: 'no-back' }
})

ipcMain.handle('browse:forward', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  if (hist?.canGoForward?.()) {
    hist.goForward()
    return { ok: true, href: wc.getURL() }
  }
  if (typeof wc.canGoForward === 'function' && wc.canGoForward()) {
    wc.goForward()
    return { ok: true, href: wc.getURL() }
  }
  return { ok: false, reason: 'no-forward' }
})

ipcMain.handle('browse:reload', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  ctl.view.webContents.reload()
  return { ok: true, href: ctl.view.webContents.getURL() }
})

ipcMain.handle('browse:mute', async (evt, muted) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  ctl.view.webContents.setAudioMuted(Boolean(muted))
  return { ok: true, muted: ctl.view.webContents.isAudioMuted() }
})

ipcMain.handle('browse:zoom', async (evt, delta) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const cur = wc.getZoomFactor()
  let next = cur
  if (delta === 'in') next = Math.min(3, cur + 0.1)
  else if (delta === 'out') next = Math.max(0.5, cur - 0.1)
  else if (delta === 'reset') next = 1
  else if (typeof delta === 'number' && Number.isFinite(delta)) next = Math.min(3, Math.max(0.5, delta))
  wc.setZoomFactor(next)
  return { ok: true, zoom: next }
})

ipcMain.handle('browse:nav', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  return {
    ok: true,
    href: wc.getURL(),
    canGoBack: Boolean(hist?.canGoBack?.() ?? wc.canGoBack?.()),
    canGoForward: Boolean(hist?.canGoForward?.() ?? wc.canGoForward?.()),
    zoom: wc.getZoomFactor(),
  }
})

// Guards against a single "New window" click spawning two windows. Some
// input stacks (touch-emulated click, fast pointerdown+click pairs under
// Wayland) can replay one logical click as two IPC invokes a few ms apart;
// without this a user reported two windows opening per click (Leader
// verify, 2026-09-02). Keyed per-sender so distinct windows/tabs never
// dedupe each other's legitimate calls.
const newWindowGuard = new WeakMap()
const NEW_WINDOW_DEBOUNCE_MS = 800

ipcMain.handle('browse:newWindow', async (evt, url) => {
  const now = Date.now()
  const last = newWindowGuard.get(evt.sender) || 0
  if (now - last < NEW_WINDOW_DEBOUNCE_MS) {
    return { ok: true, deduped: true }
  }
  newWindowGuard.set(evt.sender, now)
  // Leader GRANT 2026-11-22: IdP URLs stay in a daf.neu browser window so
  // site Google SSO can complete. Seat Login still uses browse:openExternal.
  const href = typeof url === 'string' && /^https?:\/\//i.test(url) ? url : WEB_HOME
  // Full parity with the primary window's browser — real tabs, address bar,
  // bookmarks — not a bare page (WO-BROWSER-WINDOW-1 follow-up, issue B1):
  // load our own renderer in a second window instead of the raw target.
  createBrowserAppWindow(href)
  return { ok: true, idp: isAuthUrl(href) }
})

ipcMain.handle('browse:hide', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  ctl?.view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  hideDevTools(ctl)
  return { ok: true }
})

ipcMain.handle('browse:snapshot', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false, reason: 'no-view' }
  const box = ctl.view.getBounds()
  if (box.width < 8 || box.height < 8) return { ok: false, reason: 'hidden' }
  try {
    const img = await ctl.view.webContents.capturePage()
    if (img.isEmpty()) return { ok: false, reason: 'empty' }
    return {
      ok: true,
      dataUrl: img.toDataURL(),
      href: ctl.view.webContents.getURL() || ctl.lastGoodUrl || undefined,
    }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'capture-failed' }
  }
})

function xfoBlocksFrames(value) {
  if (!value) return false
  const v = String(value).toLowerCase()
  return v.includes('deny') || v.includes('sameorigin') || v.includes('allow-from')
}

function cspBlocksFrames(value) {
  if (!value) return false
  const match = /frame-ancestors\s+([^;]+)/i.exec(String(value))
  if (!match) return false
  const tokens = match[1].trim().toLowerCase().split(/\s+/)
  if (tokens.includes("'none'") || tokens.includes('none')) return true
  if (tokens.includes('*')) return false
  return true
}

ipcMain.handle('browse:framePolicy', async (_evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, blocked: true, reason: 'bad-url' }
  }
  return await new Promise((resolve) => {
    let done = false
    const finish = (payload) => {
      if (done) return
      done = true
      resolve(payload)
    }
    const timer = setTimeout(() => finish({ ok: false, blocked: true, reason: 'timeout' }), 4000)
    try {
      const req = net.request({ method: 'GET', url, redirect: 'follow' })
      req.on('response', (res) => {
        const headers = res.headers || {}
        const xfo = headers['x-frame-options']
        const csp = headers['content-security-policy']
        const xfoVal = Array.isArray(xfo) ? xfo.join(' ') : xfo
        const cspVal = Array.isArray(csp) ? csp.join(' ') : csp
        try {
          req.abort()
        } catch {
          /* already closed */
        }
        clearTimeout(timer)
        const blocked = xfoBlocksFrames(xfoVal) || cspBlocksFrames(cspVal)
        finish({
          ok: true,
          blocked,
          reason: blocked ? (xfoVal ? 'x-frame-options' : 'csp') : 'allow',
        })
      })
      req.on('error', (err) => {
        clearTimeout(timer)
        finish({ ok: false, blocked: true, reason: err instanceof Error ? err.message : 'net-error' })
      })
      req.end()
    } catch (err) {
      clearTimeout(timer)
      finish({ ok: false, blocked: true, reason: err instanceof Error ? err.message : 'request-failed' })
    }
  })
})

// WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND — renderer reads/writes the
// per-origin Default | Allow | Block choice from the address-bar site panel.
ipcMain.handle('browse:sitePolicy:get', async (_evt, url) => {
  const host = hostOfUrl(url)
  return { ok: true, host, policy: getSitePolicy(host) }
})

ipcMain.handle('browse:sitePolicy:set', async (_evt, payload) => {
  const host = hostOfUrl(payload?.url)
  const policy = payload?.policy
  if (!host) return { ok: false, reason: 'bad-url' }
  if (policy !== 'default' && policy !== 'allow' && policy !== 'block') {
    return { ok: false, reason: 'bad-policy' }
  }
  setSitePolicy(host, policy)
  return { ok: true, host, policy: getSitePolicy(host) }
})

ipcMain.handle('browse:openExternal', async (_evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, reason: 'http(s) only' }
  }
  if (localboot.ACTIVE) {
    openInSystemBrowser(url)
    return { ok: true }
  }
  await shell.openExternal(url)
  return { ok: true }
})

ipcMain.handle('browse:bounds', async (evt, rect) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view || !rect) return { ok: false }
  const r = zoomedRect(evt.sender, rect)
  if (r.width < 8 || r.height < 8) {
    ctl.view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    return { ok: true, hidden: true }
  }
  ctl.view.setBounds(r)
  return { ok: true }
})

ipcMain.handle('browse:devtools', async (evt, rect) => {
  const ctl = controllerForSender(evt.sender)
  const r = rect ? zoomedRect(evt.sender, rect) : null
  if (!r || r.width < 8 || r.height < 8) {
    hideDevTools(ctl)
    return { ok: true, hidden: true }
  }
  ensureDevTools(ctl)
  if (!ctl?.dtView || !ctl.view) return { ok: false }
  ctl.dtView.setBounds(r)
  if (!ctl.view.webContents.isDevToolsOpened()) {
    ctl.view.webContents.openDevTools()
  }
  return { ok: true }
})

ipcMain.handle('browse:download-open', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  const err = await shell.openPath(row.rec.path)
  return { ok: !err }
})

ipcMain.handle('browse:download-show', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  shell.showItemInFolder(row.rec.path)
  return { ok: true }
})

ipcMain.handle('files:save', async (_evt, payload) => {
  if (!win || !payload) return { ok: false }
  const filters = Array.isArray(payload.filters) ? payload.filters : [{ name: 'Text', extensions: ['txt'] }]
  const result = await dialog.showSaveDialog(win, {
    title: 'Save document',
    defaultPath: typeof payload.defaultPath === 'string' ? payload.defaultPath : 'document.txt',
    filters,
  })
  if (result.canceled || !result.filePath) return { ok: false, reason: 'cancelled' }
  try {
    if (Array.isArray(payload.bytes)) {
      fs.writeFileSync(result.filePath, Buffer.from(payload.bytes))
    } else {
      fs.writeFileSync(result.filePath, String(payload.text || ''), 'utf8')
    }
    return { ok: true, path: result.filePath }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'write-failed' }
  }
})

ipcMain.handle('plant:pick', async () => {
  if (!win) return { ok: false }
  const result = await dialog.showOpenDialog(win, {
    title: 'os.neu folder',
    defaultPath: path.join(app.getPath('home'), 'os.neu'),
    properties: ['openDirectory', 'createDirectory'],
  })
  if (result.canceled || !result.filePaths[0]) return { ok: false }
  return { ok: true, path: result.filePaths[0] }
})

// Resolves to the window that actually sent the IPC call, not always the
// primary `win` — every secondary "New window" instance renders its own
// StatusBar with this same resize/fullscreen button, but the handlers below
// used to always act on the primary window regardless of sender, so the
// button silently did nothing from a secondary window (reported 2026-09-02).
function windowForSender(sender) {
  const bw = BrowserWindow.fromWebContents(sender)
  return bw && !bw.isDestroyed() ? bw : win
}

ipcMain.handle('app:fullscreen', async (evt, on) => {
  const target = windowForSender(evt.sender)
  if (typeof on === 'boolean') target?.setFullScreen(on)
  return { ok: true, fullscreen: Boolean(target?.isFullScreen()), maximized: Boolean(target?.isMaximized()) }
})

ipcMain.handle('app:window', async (evt, mode) => {
  const target = windowForSender(evt.sender)
  if (mode === 'windowed') {
    target?.setFullScreen(false)
    target?.unmaximize()
    target?.setSize(1280, 800)
    target?.center()
  } else if (mode === 'maximized') {
    target?.setFullScreen(false)
    target?.maximize()
  } else if (mode === 'fullscreen') {
    target?.setFullScreen(true)
  }
  return {
    ok: true,
    fullscreen: Boolean(target?.isFullScreen()),
    maximized: Boolean(target?.isMaximized()),
  }
})

/** File→Quit / Exit Quit: close this window only. Last window → window-all-closed. */
function closeSenderWindow(target) {
  const bw = target && !target.isDestroyed() ? target : win
  if (!bw || bw.isDestroyed()) return
  const ctl = controllers.get(bw.id)
  if (ctl) {
    ctl.view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    hideDevTools(ctl)
  }
  try {
    bw.setFullScreen(false)
  } catch {
    /* already gone */
  }
  bw.close()
}

function guestOf(bw) {
  const ctl = bw && controllers.get(bw.id)
  const guest = ctl?.view?.webContents
  return guest && !guest.isDestroyed() ? guest : null
}

function goBackContents(nav) {
  if (!nav || nav.isDestroyed()) return
  if (typeof nav.canGoBack === 'function' && nav.canGoBack()) nav.goBack()
}

function chromeMenuTemplate(ownerWin, nav) {
  return [
    {
      label: 'File',
      submenu: [
        {
          label: 'Back',
          accelerator: process.platform === 'darwin' ? 'Cmd+[' : 'Alt+Left',
          click: (_item, focused) => {
            const bw =
              (ownerWin && !ownerWin.isDestroyed() && ownerWin) ||
              (focused && !focused.isDestroyed() && focused) ||
              BrowserWindow.getFocusedWindow() ||
              win
            const clicked = nav && !nav.isDestroyed() ? nav : null
            const guest = guestOf(bw)
            goBackContents(clicked || guest || bw?.webContents || null)
          },
        },
        {
          label: 'Quit',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: (_item, focused) => {
            const target =
              (ownerWin && !ownerWin.isDestroyed() && ownerWin) ||
              (focused && !focused.isDestroyed() && focused) ||
              BrowserWindow.getFocusedWindow() ||
              win
            closeSenderWindow(target)
          },
        },
      ],
    },
    { role: 'editMenu' },
    { role: 'viewMenu' },
    { role: 'windowMenu' },
  ]
}

function contextMenuPoint(contents, params) {
  let x = params.x
  let y = params.y
  const owner =
    BrowserWindow.fromWebContents(contents) ||
    BrowserWindow.getFocusedWindow() ||
    win
  const ctl = owner ? controllers.get(owner.id) : null
  const guest = ctl?.view?.webContents
  if (ctl?.view && guest && contents === guest) {
    const box = ctl.view.getBounds()
    x += box.x
    y += box.y
  }
  return { owner, ctl, x, y }
}

function popupPageContextMenu(contents, params) {
  if (!contents || contents.isDestroyed()) return
  const { owner, ctl, x, y } = contextMenuPoint(contents, params)
  if (!owner || owner.isDestroyed()) return
  const link = httpHref(params.linkURL)
  const page = httpHref(contents.getURL())
  const address = link || page
  const hasLink = Boolean(link)
  const selected = String(params.selectionText || '').trim()
  const shown = selected.length > 24 ? `${selected.slice(0, 24)}…` : selected
  const canBack = Boolean(contents.navigationHistory?.canGoBack?.() || contents.canGoBack?.())
  const canForward = Boolean(contents.navigationHistory?.canGoForward?.() || contents.canGoForward?.())
  const openLinkTab = (href) => {
    if (!href) return
    if (ctl) emitBrowseOpenTab(ctl, href)
    else openHrefInWindow(href)
  }
  const rows = []
  if (selected) {
    rows.push(
      {
        label: 'Copy',
        click: () => clipboard.writeText(selected),
      },
      {
        label: `Search SearXNG for "${shown}"`,
        click: () => openLinkTab(`https://searx.be/search?q=${encodeURIComponent(selected)}`),
      },
      { type: 'separator' },
    )
  }
  rows.push(
    {
      label: 'Back',
      enabled: canBack,
      click: () => {
        if (!contents.isDestroyed()) contents.goBack()
      },
    },
    {
      label: 'Forward',
      enabled: canForward,
      click: () => {
        if (!contents.isDestroyed()) contents.goForward()
      },
    },
    {
      label: 'Reload',
      click: () => {
        if (!contents.isDestroyed()) contents.reload()
      },
    },
    { type: 'separator' },
    {
      label: 'Save as…',
      enabled: Boolean(page),
      click: () => {
        void saveHrefAs(contents, page, false)
      },
    },
    {
      label: 'Print…',
      click: () => {
        if (!contents.isDestroyed()) contents.print()
      },
    },
    {
      label: 'Translate to Korean',
      enabled: Boolean(page),
      click: () => {
        if (!page) return
        contents.loadURL(`https://translate.google.com/translate?sl=auto&tl=ko&u=${encodeURIComponent(page)}`)
      },
    },
  )
  if (hasLink) {
    rows.push(
      { type: 'separator' },
      { label: 'Open link in new tab', click: () => openLinkTab(link) },
      { label: 'Open link in new window', click: () => openHrefInWindow(link) },
      { label: 'Open link in private window', click: () => openHrefInWindow(link, { private: true }) },
      { label: 'Save link as…', click: () => void saveHrefAs(contents, link, false) },
      { label: 'Copy link address', click: () => clipboard.writeText(link) },
    )
  }
  rows.push(
    { type: 'separator' },
    {
      label: 'View page source',
      enabled: Boolean(page),
      click: () => {
        if (page) openLinkTab(`view-source:${page}`)
      },
    },
    {
      label: 'Inspect',
      click: () => {
        if (ctl) emitBrowseInspect(ctl)
        else if (!contents.isDestroyed()) contents.openDevTools({ mode: 'detach' })
      },
    },
  )
  Menu.buildFromTemplate(rows).popup({ window: owner, x, y })
}

function popupChromeMenu(contents, params) {
  if (!contents || contents.isDestroyed()) return
  const url = String(contents.getURL?.() || '')
  if (url.startsWith('devtools:')) return
  if (guestContents.has(contents)) {
    popupPageContextMenu(contents, params)
    return
  }
  const { owner, x, y } = contextMenuPoint(contents, params)
  if (!owner || owner.isDestroyed()) return
  const menu = Menu.buildFromTemplate(chromeMenuTemplate(owner, contents))
  menu.popup({ window: owner, x, y })
}

function installAppMenu() {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate(chromeMenuTemplate(BrowserWindow.getFocusedWindow() || win, null)),
  )
}

function installChromeContextMenus() {
  app.on('web-contents-created', (_event, contents) => {
    contents.on('context-menu', (_e, params) => {
      popupChromeMenu(contents, params)
    })
  })
}

ipcMain.handle('app:version', async () => {
  try {
    return { ok: true, version: String(app.getVersion() || '') }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'version-error' }
  }
})

ipcMain.handle('app:quit', async (evt) => {
  closeSenderWindow(windowForSender(evt.sender))
  return { ok: true }
})

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', (_event, commandLine) => {
    const deep = findProtocolUrl(commandLine)
    if (deep) deliverOAuthDeepLink(deep)
    // Always raise the shell — even if the deep link only asks to focus.
    focusMainWindow()
  })

  app.on('open-url', (event, url) => {
    event.preventDefault()
    deliverOAuthDeepLink(url)
  })

  app.whenReady().then(async () => {
    showBootSplash()
    if (isPackagedRuntime()) {
      try {
        const port = await findListenPort(process.env.NEUOS_BRIDGE_PORT || 4178)
        process.env.NEUOS_BRIDGE_PORT = String(port)
        appMark(`BRIDGE start port=${port}`)
        startPackagedBridge(port)
        const ready = await waitBridgeHealth(port, 20_000)
        appMark(`BRIDGE health ${ready ? 'ok' : 'FAILED after 20s'}`)
        if (!ready) {
          dialog.showErrorBox('os.neu', 'OS-NEU-SX-002  os.neu bridge did not become ready.')
          stopPackagedBridge()
          app.quit()
          return
        }
      } catch (err) {
        dialog.showErrorBox('os.neu', err instanceof Error ? err.message : String(err))
        stopPackagedBridge()
        app.quit()
        return
      }
    }
    loadSitePolicy()
    installChromeContextMenus()
    installAppMenu()
    installKioskZoom()
    if (process.env.NEUOS_JEOS === '1' && (!hasDefaultRoute() || process.env.NEUOS_SETUP === '1')) {
      setupBeforeMain = true
      await openSetup()
    } else if (localboot.ACTIVE && process.env.NEUOS_WIZARD !== '0') {
      setupBeforeMain = true
      await new Promise((resolve) => closeBootSplash(resolve))
      await localboot.openWizard({ base: uiHomeUrl(), icon: brandIcon(), diag: hostNetdiag })
    }
    await bindUiSessionToken()
    createWindow()
    setupBeforeMain = false
    const deep = findProtocolUrl(process.argv)
    if (deep) {
      win?.webContents.once('did-finish-load', () => {
        deliverOAuthDeepLink(deep)
      })
    }
  })

  app.on('before-quit', () => {
    appMark('APP quit')
    if (loginBrowser) loginBrowser.kill('SIGTERM')
    app.isQuitting = true
    stopPackagedBridge()
  })
  app.on('child-process-gone', (_e, d) => appMark(`APP_CHILD gone type=${d && d.type} reason=${d && d.reason}`))

  app.on('window-all-closed', () => {
    if (setupBeforeMain) return
    app.quit()
  })
}
