const { app, BrowserWindow, BrowserView, ipcMain, session, dialog, shell } = require('electron')
const fs = require('node:fs')
const path = require('node:path')

const DEV = process.env.NEUOS_DEV_URL ?? 'http://127.0.0.1:5173'
process.env.NEUOS_ELECTRON = '1'

function linuxSuidSandboxOk() {
  if (process.platform !== 'linux') return true
  try {
    const helper = path.join(path.dirname(process.execPath), 'chrome-sandbox')
    const st = fs.statSync(helper)
    return st.uid === 0 && (st.mode & 0o4000) !== 0
  } catch {
    return false
  }
}

// npm-installed Electron cannot use the SUID helper unless chrome-sandbox is
// root:root mode 4755. Without this switch Chromium aborts before the window.
if (!linuxSuidSandboxOk()) {
  app.commandLine.appendSwitch('no-sandbox')
  app.commandLine.appendSwitch('disable-gpu-sandbox')
}

/** @type {BrowserView | null} */
let view = null
/** @type {BrowserView | null} */
let dtView = null
/** @type {BrowserWindow | null} */
let win = null
/** @type {Electron.Session | null} */
let browseSession = null
let lastGoodUrl = ''
let restoring = false
/** @type {Map<string, { rec: object, item?: Electron.DownloadItem }>} */
const downloads = new Map()
let downloadSeq = 0

function chromeUA() {
  const chrome = process.versions.chrome || '124.0.0.0'
  return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`
}

function isAuthUrl(url) {
  if (!url || url === 'about:blank') return true
  try {
    const host = new URL(url).hostname
    return (
      host === 'accounts.google.com' ||
      host === 'accounts.youtube.com' ||
      host === 'login.microsoftonline.com' ||
      host === 'login.live.com' ||
      host === 'appleid.apple.com' ||
      (host === 'github.com' && /\/login/.test(url))
    )
  } catch {
    return false
  }
}

function attachGuest(guest) {
  guest.setUserAgent(chromeUA())
  guest.setWindowOpenHandler(({ url }) => {
    if (url === 'about:blank' || /^https?:\/\//i.test(url)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: 520,
          height: 740,
          autoHideMenuBar: true,
          webPreferences: {
            session: browseSession || undefined,
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: false,
            javascript: true,
          },
        },
      }
    }
    return { action: 'deny' }
  })
  guest.on('will-redirect', (event, url) => {
    if (/^(https?:|about:)/i.test(url)) return
    event.preventDefault()
  })
  guest.on('did-fail-load', (_event, code, _desc, failedUrl, isMain) => {
    if (!isMain || code === -3 || restoring) return
    if (isAuthUrl(failedUrl)) return
    if (lastGoodUrl && failedUrl !== lastGoodUrl) {
      restoring = true
      void guest.loadURL(lastGoodUrl).finally(() => {
        restoring = false
      })
    }
  })
  guest.on('did-navigate', (_event, url) => {
    if (restoring) return
    if (/^https?:\/\//i.test(url) && !isAuthUrl(url)) lastGoodUrl = url
  })
}

function createWindow() {
  const ua = chromeUA()
  app.userAgentFallback = ua
  session.defaultSession.setUserAgent(ua)
  session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(
      permission === 'media' ||
        permission === 'notifications' ||
        permission === 'clipboard-sanitized-write' ||
        permission === 'fullscreen' ||
        permission === 'pointerLock' ||
        permission === 'storage-access',
    )
  })
  browseSession = session.fromPartition('persist:neuos-browse')
  browseSession.setUserAgent(ua)
  browseSession.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(
      permission === 'media' ||
        permission === 'notifications' ||
        permission === 'clipboard-sanitized-write' ||
        permission === 'fullscreen' ||
        permission === 'pointerLock' ||
        permission === 'storage-access',
    )
  })

  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 880,
    minHeight: 540,
    backgroundColor: '#0b0c0a',
    icon: path.join(__dirname, '..', 'public', 'brand', 'os.neu-app.png'),
    title: 'os.neu',
    autoHideMenuBar: true,
    resizable: true,
    maximizable: true,
    fullscreenable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })

  view = new BrowserView({
    webPreferences: {
      session: browseSession,
      contextIsolation: true,
      sandbox: false,
      javascript: true,
      images: true,
      webviewTag: false,
    },
  })
  view.setBackgroundColor('#ffffff')
  win.addBrowserView(view)
  view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  attachGuest(view.webContents)
  watchDownloads(browseSession)

  void win.loadURL(DEV)
  if (process.env.NEUOS_SCREEN === '1') {
    win.maximize()
  }
}

function uniqueSavePath(filename) {
  const dir = app.getPath('downloads')
  const ext = path.extname(filename)
  const base = path.basename(filename, ext) || 'download'
  let dest = path.join(dir, filename || 'download')
  let i = 1
  while (fs.existsSync(dest)) {
    dest = path.join(dir, `${base} (${i})${ext}`)
    i += 1
  }
  return dest
}

function emitDownload(rec) {
  win?.webContents.send('browse:download', rec)
}

function watchDownloads(sess) {
  if (!sess || sess.__neuosDownloads) return
  sess.__neuosDownloads = true
  sess.on('will-download', (_event, item) => {
    const id = `dl-${Date.now()}-${downloadSeq}`
    downloadSeq += 1
    const rec = {
      id,
      filename: item.getFilename() || 'download',
      url: item.getURL(),
      path: uniqueSavePath(item.getFilename() || 'download'),
      mime: item.getMimeType(),
      bytes: item.getTotalBytes() || 0,
      received: 0,
      state: 'progress',
      t: Date.now(),
    }
    item.setSavePath(rec.path)
    downloads.set(id, { rec, item })
    emitDownload(rec)
    item.on('updated', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.bytes = item.getTotalBytes() || rec.bytes
      rec.state = state === 'interrupted' ? 'failed' : 'progress'
      emitDownload({ ...rec })
    })
    item.once('done', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.state = state === 'completed' ? 'done' : state === 'cancelled' ? 'cancelled' : 'failed'
      emitDownload({ ...rec })
    })
  })
}

function ensureDevTools() {
  if (!win || !view) return
  if (!dtView) {
    dtView = new BrowserView({
      webPreferences: {
        sandbox: false,
        contextIsolation: true,
      },
    })
    dtView.setBackgroundColor('#1b1c17')
    win.addBrowserView(dtView)
    dtView.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  }
  view.webContents.setDevToolsWebContents(dtView.webContents)
}

function hideDevTools() {
  dtView?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  if (view?.webContents.isDevToolsOpened()) view.webContents.closeDevTools()
}

function loadInView(url) {
  return new Promise((resolve) => {
    if (!view) {
      resolve({ ok: false, reason: 'no-view' })
      return
    }
    const wc = view.webContents
    const finish = (payload) => {
      wc.removeListener('did-finish-load', onOk)
      wc.removeListener('did-fail-load', onFail)
      resolve(payload)
    }
    const onOk = () => {
      const href = wc.getURL()
      if (!href || href === 'about:blank') {
        finish({ ok: true, href: url })
        return
      }
      if (/^https?:\/\//i.test(href) && !isAuthUrl(href)) lastGoodUrl = href
      finish({ ok: true, href })
    }
    const onFail = (_e, code, desc, failedUrl, isMain) => {
      if (!isMain || code === -3) return
      if (isAuthUrl(failedUrl) || isAuthUrl(url)) {
        finish({ ok: false, reason: desc || String(code), href: failedUrl })
        return
      }
      if (lastGoodUrl && failedUrl !== lastGoodUrl) {
        restoring = true
        void wc.loadURL(lastGoodUrl).finally(() => {
          restoring = false
        })
        finish({ ok: true, href: lastGoodUrl, restored: true, reason: desc || String(code) })
        return
      }
      finish({ ok: false, reason: desc || String(code), href: failedUrl })
    }
    wc.on('did-finish-load', onOk)
    wc.on('did-fail-load', onFail)
    void wc.loadURL(url, { userAgent: chromeUA() })
  })
}

ipcMain.handle('browse:go', async (_evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, reason: 'http(s) only' }
  }
  return loadInView(url)
})

ipcMain.handle('browse:back', async () => {
  if (!view) return { ok: false }
  const wc = view.webContents
  if (wc.canGoBack()) {
    wc.goBack()
    return { ok: true, href: wc.getURL() }
  }
  if (lastGoodUrl) {
    return loadInView(lastGoodUrl)
  }
  return { ok: false, reason: 'no-back' }
})

ipcMain.handle('browse:newWindow', async (_evt, url) => {
  const child = new BrowserWindow({
    width: 1280,
    height: 800,
    backgroundColor: '#0b0c0a',
    autoHideMenuBar: true,
    webPreferences: {
      session: browseSession || undefined,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  })
  const href = typeof url === 'string' && /^https?:\/\//i.test(url) ? url : DEV
  void child.loadURL(href, { userAgent: chromeUA() })
  return { ok: true }
})

ipcMain.handle('browse:hide', async () => {
  view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  hideDevTools()
  return { ok: true }
})

ipcMain.handle('browse:bounds', async (_evt, rect) => {
  if (!view || !rect) return { ok: false }
  const width = Math.max(0, Math.round(rect.width))
  const height = Math.max(0, Math.round(rect.height))
  if (width < 8 || height < 8) {
    view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    return { ok: true, hidden: true }
  }
  view.setBounds({
    x: Math.round(rect.x),
    y: Math.round(rect.y),
    width,
    height,
  })
  return { ok: true }
})

ipcMain.handle('browse:devtools', async (_evt, rect) => {
  const width = Math.max(0, Math.round(rect?.width || 0))
  const height = Math.max(0, Math.round(rect?.height || 0))
  if (!rect || width < 8 || height < 8) {
    hideDevTools()
    return { ok: true, hidden: true }
  }
  ensureDevTools()
  if (!dtView || !view) return { ok: false }
  dtView.setBounds({
    x: Math.round(rect.x),
    y: Math.round(rect.y),
    width,
    height,
  })
  if (!view.webContents.isDevToolsOpened()) {
    view.webContents.openDevTools()
  }
  return { ok: true }
})

ipcMain.handle('browse:download-open', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  const err = await shell.openPath(row.rec.path)
  return { ok: !err }
})

ipcMain.handle('browse:download-show', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  shell.showItemInFolder(row.rec.path)
  return { ok: true }
})

ipcMain.handle('plant:default', async () => {
  const dest = path.join(app.getPath('home'), 'os.neu')
  return { ok: true, path: dest }
})

ipcMain.handle('plant:pick', async () => {
  if (!win) return { ok: false }
  const result = await dialog.showOpenDialog(win, {
    title: 'os.neu folder',
    defaultPath: path.join(app.getPath('home'), 'os.neu'),
    properties: ['openDirectory', 'createDirectory'],
  })
  if (result.canceled || !result.filePaths[0]) return { ok: false }
  return { ok: true, path: result.filePaths[0] }
})

ipcMain.handle('app:fullscreen', async (_event, on) => {
  if (typeof on === 'boolean') win?.setFullScreen(on)
  return { ok: true, fullscreen: Boolean(win?.isFullScreen()), maximized: Boolean(win?.isMaximized()) }
})

ipcMain.handle('app:window', async (_event, mode) => {
  if (mode === 'windowed') {
    win?.setFullScreen(false)
    win?.unmaximize()
    win?.setSize(1280, 800)
    win?.center()
  } else if (mode === 'maximized') {
    win?.setFullScreen(false)
    win?.maximize()
  } else if (mode === 'fullscreen') {
    win?.setFullScreen(true)
  }
  return {
    ok: true,
    fullscreen: Boolean(win?.isFullScreen()),
    maximized: Boolean(win?.isMaximized()),
  }
})

ipcMain.handle('app:quit', async () => {
  view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  hideDevTools()
  try {
    win?.setFullScreen(false)
  } catch {
    /* already gone */
  }
  win?.close()
  app.quit()
  setTimeout(() => app.exit(0), 500)
  return { ok: true }
})

app.whenReady().then(() => {
  createWindow()
})

app.on('web-contents-created', (_event, contents) => {
  if (contents.getType() === 'window') attachGuest(contents)
})

app.on('window-all-closed', () => {
  app.quit()
})
