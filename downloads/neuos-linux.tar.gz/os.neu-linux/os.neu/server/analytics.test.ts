import { describe, expect, it } from 'vitest'
import { normalizeFeedback } from './analytics.ts'

describe('normalizeFeedback', () => {
  it('keeps title and body when both are filled', () => {
    expect(normalizeFeedback('  Slow boot  ', '  It waited.  ')).toEqual({
      title: 'Slow boot',
      body: 'It waited.',
    })
  })

  it('uses the filled field when the other is empty', () => {
    expect(normalizeFeedback('', 'Only a message')).toEqual({
      title: 'Only a message',
      body: 'Only a message',
    })
    expect(normalizeFeedback('Only a title', '   ')).toEqual({
      title: 'Only a title',
      body: 'Only a title',
    })
  })

  it('rejects a blank post', () => {
    expect(() => normalizeFeedback('  ', '')).toThrow('empty-feedback')
  })
})
