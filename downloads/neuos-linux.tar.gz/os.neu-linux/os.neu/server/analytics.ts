import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { supabaseAddFeedback, supabaseListFeedback } from './supabase.ts'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const EVENTS = path.join(ROOT, 'data', 'analytics.json')
const FEEDBACK = path.join(ROOT, 'data', 'feedback.json')

export type TrackEvent = {
  t: number
  session: string
  email?: string
  kind: 'view' | 'click' | 'login' | 'logout' | 'open-app' | 'feedback'
  screen: string
  label?: string
}

export type FeedbackPost = {
  id: string
  t: number
  email?: string
  name?: string
  title: string
  body: string
}

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    const raw = JSON.parse(await readFile(file, 'utf8')) as T
    return raw
  } catch {
    return fallback
  }
}

async function writeJson(file: string, body: unknown) {
  await mkdir(path.dirname(file), { recursive: true })
  await writeFile(file, JSON.stringify(body, null, 2))
}

export async function appendTrack(event: TrackEvent) {
  const rows = await readJson<TrackEvent[]>(EVENTS, [])
  rows.push(event)
  await writeJson(EVENTS, rows.slice(-4000))
  return event
}

export function normalizeFeedback(title: string, body: string) {
  const nextTitle = String(title || '').trim()
  const nextBody = String(body || '').trim()
  if (!nextTitle && !nextBody) throw new Error('empty-feedback')
  return {
    title: nextTitle || nextBody.slice(0, 48),
    body: nextBody || nextTitle,
  }
}

export async function addFeedback(post: Omit<FeedbackPost, 'id' | 't'> & { id?: string; t?: number }) {
  const text = normalizeFeedback(post.title, post.body)
  const rows = await readJson<FeedbackPost[]>(FEEDBACK, [])
  const next: FeedbackPost = {
    id: post.id || `fb-${Date.now()}`,
    t: post.t || Date.now(),
    email: post.email,
    name: post.name,
    title: text.title,
    body: text.body,
  }
  rows.push(next)
  await writeJson(FEEDBACK, rows.slice(-500))
  let cloud = false
  try {
    const saved = await supabaseAddFeedback({
      name: next.name,
      email: next.email,
      title: next.title,
      body: next.body,
    })
    if (saved?.id) {
      next.id = saved.id
      cloud = true
    }
  } catch {
    /* local row already saved */
  }
  return { ...next, cloud }
}

export async function listFeedback() {
  const local = await readJson<FeedbackPost[]>(FEEDBACK, [])
  try {
    const cloud = await supabaseListFeedback()
    if (!cloud.length) return local
    const seen = new Set(cloud.map((row) => `${row.email || ''}|${row.title}|${row.body}`))
    const extra = local.filter((row) => !seen.has(`${row.email || ''}|${row.title}|${row.body}`))
    return [...cloud, ...extra].sort((a, b) => b.t - a.t)
  } catch {
    return local
  }
}

export async function adminStats() {
  const events = await readJson<TrackEvent[]>(EVENTS, [])
  const feedback = await listFeedback()
  const byEmail = new Map<
    string,
    { email: string; first: number; last: number; views: number; clicks: number; logins: number; logouts: number }
  >()
  const clicks: Record<string, number> = {}
  const logoutScreens: Record<string, number> = {}
  const screens: Record<string, number> = {}

  for (const event of events) {
    const key = event.email || `anon:${event.session.slice(0, 8)}`
    const row = byEmail.get(key) || {
      email: event.email || key,
      first: event.t,
      last: event.t,
      views: 0,
      clicks: 0,
      logins: 0,
      logouts: 0,
    }
    row.first = Math.min(row.first, event.t)
    row.last = Math.max(row.last, event.t)
    if (event.kind === 'view') row.views += 1
    if (event.kind === 'click' || event.kind === 'open-app') row.clicks += 1
    if (event.kind === 'login') row.logins += 1
    if (event.kind === 'logout') row.logouts += 1
    byEmail.set(key, row)
    if (event.kind === 'click' || event.kind === 'open-app') {
      const label = event.label || event.screen
      clicks[label] = (clicks[label] || 0) + 1
    }
    if (event.kind === 'logout') {
      logoutScreens[event.screen] = (logoutScreens[event.screen] || 0) + 1
    }
    if (event.kind === 'view') {
      screens[event.screen] = (screens[event.screen] || 0) + 1
    }
  }

  return {
    ok: true,
    users: [...byEmail.values()].sort((a, b) => b.last - a.last),
    clicks,
    logoutScreens,
    screens,
    events: events.slice(-300).reverse(),
    feedback: feedback.slice().reverse(),
    totals: {
      events: events.length,
      users: byEmail.size,
      feedback: feedback.length,
    },
  }
}
