import { execFile } from 'node:child_process'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

export type UsbDisk = {
  name: string
  path: string
  size: string
  model: string
  removable: boolean
  system: boolean
}

type LsblkNode = {
  name?: string
  path?: string
  size?: string | number
  model?: string | null
  rm?: boolean | string | number
  type?: string
  mountpoint?: string | null
  mountpoints?: Array<string | null>
  children?: LsblkNode[]
}

function truthy(value: boolean | string | number | undefined): boolean {
  return value === true || value === 1 || value === '1' || value === 'true'
}

function mountsOf(node: LsblkNode): string[] {
  const fromArray = (node.mountpoints ?? []).filter((m): m is string => Boolean(m))
  if (fromArray.length) return fromArray
  return node.mountpoint ? [node.mountpoint] : []
}

function walk(node: LsblkNode, visit: (n: LsblkNode) => void) {
  visit(node)
  for (const child of node.children ?? []) walk(child, visit)
}

export function systemDeviceNames(nodes: LsblkNode[]): Set<string> {
  const names = new Set<string>()
  for (const disk of nodes) {
    let holdsRoot = false
    walk(disk, (n) => {
      if (mountsOf(n).includes('/')) holdsRoot = true
    })
    if (holdsRoot && disk.name) names.add(disk.name)
  }
  return names
}

export function parseLsblk(payload: { blockdevices?: LsblkNode[] }): UsbDisk[] {
  const disks = (payload.blockdevices ?? []).filter((n) => (n.type ?? 'disk') === 'disk')
  const system = systemDeviceNames(disks)
  return disks.map((disk) => {
    const name = disk.name ?? ''
    const pathName = disk.path ?? (name ? `/dev/${name}` : '')
    return {
      name,
      path: pathName,
      size: String(disk.size ?? ''),
      model: disk.model ?? '',
      removable: truthy(disk.rm),
      system: system.has(name),
    }
  })
}

export function usbCandidates(disks: UsbDisk[]): UsbDisk[] {
  return disks.filter((d) => d.removable && !d.system)
}

export function burnCommand(device: string): string {
  return `sudo bash scripts/make-usb.sh ${device} --yes`
}

export async function listBlockDisks(): Promise<UsbDisk[]> {
  try {
    const { stdout } = await execFileAsync('lsblk', ['-J', '-o', 'NAME,PATH,SIZE,MODEL,RM,TYPE,MOUNTPOINT,MOUNTPOINTS'], {
      timeout: 4000,
    })
    return parseLsblk(JSON.parse(stdout) as { blockdevices?: LsblkNode[] })
  } catch {
    return []
  }
}
