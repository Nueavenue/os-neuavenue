import { DEFAULT_SEARXNG_ORIGIN, isSearchEngineId, type SearchEngineId } from '../src/engine/searchEngines.ts'

export type SearchHit = { title: string; href: string; snippet: string }

function wikiLang(query: string) {
  return /[\uac00-\ud7a3]/.test(query) ? 'ko' : 'en'
}

async function fromWikipedia(query: string): Promise<SearchHit[]> {
  const lang = wikiLang(query)
  const href = `https://${lang}.wikipedia.org/w/api.php?action=opensearch&limit=5&namespace=0&format=json&search=${encodeURIComponent(query)}`
  const res = await fetch(href, { signal: AbortSignal.timeout(8_000) })
  if (!res.ok) return []
  const body = (await res.json()) as [string, string[], string[], string[]]
  const titles = body[1] || []
  const snippets = body[2] || []
  const links = body[3] || []
  return titles.map((title, i) => ({
    title,
    href: links[i] || '',
    snippet: snippets[i] || '',
  }))
}

async function fromSearx(query: string, origin: string): Promise<SearchHit[]> {
  const href = `${origin.replace(/\/$/, '')}/search?q=${encodeURIComponent(query)}&format=json`
  const res = await fetch(href, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(8_000),
  })
  if (!res.ok) return []
  const body = (await res.json()) as { results?: Array<{ title?: string; url?: string; content?: string }> }
  return (body.results || []).slice(0, 6).map((row) => ({
    title: String(row.title || '').trim(),
    href: String(row.url || '').trim(),
    snippet: String(row.content || '').trim().slice(0, 220),
  }))
}

export async function searchSnippets(
  query: string,
  engine: string,
  searxOrigin = DEFAULT_SEARXNG_ORIGIN,
): Promise<{ engine: SearchEngineId | 'wikipedia'; query: string; hits: SearchHit[] }> {
  const q = query.trim()
  const id: SearchEngineId = isSearchEngineId(engine) ? engine : 'searxng'
  if (!q) return { engine: id, query: q, hits: [] }
  let hits: SearchHit[] = []
  if (id === 'searxng' || id === 'wikipedia') {
    try {
      hits = id === 'wikipedia' ? await fromWikipedia(q) : await fromSearx(q, searxOrigin)
    } catch {
      hits = []
    }
  }
  if (!hits.length) {
    try {
      hits = await fromWikipedia(q)
    } catch {
      hits = []
    }
  }
  return { engine: hits.length && !hits[0]?.href.includes('wikipedia') ? id : hits.length ? 'wikipedia' : id, query: q, hits }
}
