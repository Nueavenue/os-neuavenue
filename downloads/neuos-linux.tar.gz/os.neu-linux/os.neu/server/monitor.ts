import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DIR = path.join(ROOT, 'data')
const LOG = path.join(DIR, 'user-monitor.json')
const PREF = path.join(DIR, 'user-preference.json')

export type MonitorEvent = {
  t: number
  source: 'prompt' | 'lui' | 'wizard'
  kind: 'install' | 'remove' | 'choice' | 'start'
  app?: string
  hostOs?: string
  pkg?: string
  remembered?: 'prompt' | 'neuos'
  note?: string
}

export type Preference = {
  installSurface: 'prompt' | 'neuos'
  lastHostOs?: string
  updatedAt: number
}

export async function readPreference(): Promise<Preference> {
  try {
    return JSON.parse(await readFile(PREF, 'utf8')) as Preference
  } catch {
    return { installSurface: 'neuos', updatedAt: 0 }
  }
}

export async function rememberSurface(surface: 'prompt' | 'neuos', hostOs?: string) {
  const next: Preference = { installSurface: surface, lastHostOs: hostOs, updatedAt: Date.now() }
  await mkdir(DIR, { recursive: true })
  await writeFile(PREF, JSON.stringify(next, null, 2))
  return next
}

export async function readMonitor(): Promise<MonitorEvent[]> {
  try {
    const raw = JSON.parse(await readFile(LOG, 'utf8')) as MonitorEvent[]
    return Array.isArray(raw) ? raw : []
  } catch {
    return []
  }
}

export async function appendMonitor(event: MonitorEvent): Promise<MonitorEvent[]> {
  const rows = await readMonitor()
  rows.push(event)
  const clipped = rows.slice(-200)
  await mkdir(DIR, { recursive: true })
  await writeFile(LOG, JSON.stringify(clipped, null, 2))
  if (event.source === 'prompt' || event.source === 'lui') {
    await rememberSurface(event.source === 'prompt' ? 'prompt' : 'neuos', event.hostOs)
  }
  return clipped
}
