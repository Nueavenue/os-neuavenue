import { openaiKey } from './env.ts'
export { transcribeUtterance } from './transcribe.ts'

const CHAT_MODEL = process.env.MODEL_NAME || 'gpt-audio-1.5'
const TEXT_MODEL = process.env.JUDGE_MODEL || 'gpt-4o-mini'
const COACH_VOICE = process.env.COACH_VOICE || 'alloy'

export const COACH_SYSTEM_PROMPT = `You are OS.neu Speak v1.0, a warm English speaking coach for the OS.neu first screen (NeuSpeak method).
The learner may speak Korean or another language. Understand what they said, then reply in natural conversational English, like a friendly native-speaking tutor.
Keep replies short (1-3 sentences). If the learner made a grammar or word-choice mistake, gently model the correct phrasing inside your reply.
When they ask you to do something on this computer (check internet, open a browser, install software), first restate what you heard and ask them to look at the screen and confirm. After they confirm, use any facts in their message (online/offline, which page opened, install command) and ask them to say whether they see it.
Filter rambling or off-topic audio into one clear English idea. Do not dump a boring status line. Offer a choice or a next tiny step.
Always end with a short follow-up question to keep them talking.`

export type CoachAudio = { data: string; format: string }
export type CoachReply = { reply: string; audio?: CoachAudio }

function headers(): HeadersInit {
  const key = openaiKey()
  if (!key) throw new Error('openai-unconfigured')
  return { authorization: `Bearer ${key}`, 'content-type': 'application/json' }
}

export function speakReady(): boolean {
  return Boolean(openaiKey())
}

export async function coachChat(
  message: string,
  history: CoachTurn[] = [],
  opts: { audio?: boolean } = {},
): Promise<CoachReply> {
  const text = message.trim()
  if (!text) throw new Error('empty')
  const prior = history
    .filter((turn) => turn.content.trim())
    .slice(-8)
    .map((turn) => ({ role: turn.role, content: turn.content }))
  const messages = [
    { role: 'system' as const, content: COACH_SYSTEM_PROMPT },
    ...prior,
    { role: 'user' as const, content: text },
  ]
  if (opts.audio === false) {
    return await chatTextOnly(messages)
  }
  try {
    return await chatWithAudio(messages)
  } catch {
    return await chatTextOnly(messages)
  }
}

export type CoachTurn = { role: 'user' | 'assistant'; content: string }

async function chatWithAudio(
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>,
): Promise<CoachReply> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({
      model: CHAT_MODEL,
      modalities: ['text', 'audio'],
      audio: { voice: COACH_VOICE, format: 'wav' },
      messages,
    }),
  })
  if (!res.ok) throw new Error(`openai-${res.status}`)
  const body = (await res.json()) as {
    choices?: Array<{
      message?: { content?: string | null; audio?: { transcript?: string; data?: string } }
    }>
  }
  const messageOut = body.choices?.[0]?.message
  const reply = (messageOut?.audio?.transcript ?? messageOut?.content ?? '').trim()
  if (!reply) throw new Error('empty-reply')
  const data = messageOut?.audio?.data
  return data ? { reply, audio: { data, format: 'wav' } } : { reply }
}

async function chatTextOnly(
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>,
): Promise<CoachReply> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { ...headers() },
    body: JSON.stringify({
      model: TEXT_MODEL,
      messages,
    }),
  })
  if (!res.ok) throw new Error(`openai-${res.status}`)
  const body = (await res.json()) as {
    choices?: Array<{ message?: { content?: string | null } }>
  }
  const reply = (body.choices?.[0]?.message?.content ?? '').trim()
  if (!reply) throw new Error('empty-reply')
  return { reply }
}

