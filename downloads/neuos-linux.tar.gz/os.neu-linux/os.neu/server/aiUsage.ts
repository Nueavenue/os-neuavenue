import { appendFile, mkdir, readFile } from 'node:fs/promises'
import path from 'node:path'

export const DEFAULT_BRIDGE_AI_LIMIT = 200

export function dayKey(at: Date): string {
  return `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, '0')}-${String(at.getDate()).padStart(2, '0')}`
}

export function parseAiDailyLimit(raw: string | undefined): number {
  if (raw === undefined || raw === '') return DEFAULT_BRIDGE_AI_LIMIT
  const n = Number(raw)
  if (!Number.isFinite(n) || n < 0) return DEFAULT_BRIDGE_AI_LIMIT
  return Math.floor(n)
}

export type AiUsageGate = {
  consume: (route: string) => Promise<{ allowed: boolean; limit: number; dayCount: number }>
}

/** Append-only AI call ledger. No prompt text and no keys. */
export function createAiUsageGate(opts: { dir: string; limit: number; now?: () => Date }): AiUsageGate {
  const file = path.join(opts.dir, 'ai-usage.jsonl')
  let day = ''
  let allowed = 0
  let loaded = false
  const now = opts.now || (() => new Date())

  async function load() {
    if (loaded) return
    loaded = true
    const today = dayKey(now())
    day = today
    allowed = 0
    try {
      const raw = await readFile(file, 'utf8')
      for (const line of raw.split('\n')) {
        if (!line.trim()) continue
        try {
          const row = JSON.parse(line) as { day?: string; result?: string }
          if (row.day === today && row.result === 'allowed') allowed += 1
        } catch {
          /* skip a bad line */
        }
      }
    } catch {
      /* first run — file appears on the first append */
    }
  }

  async function consume(route: string) {
    await load()
    const today = dayKey(now())
    if (day !== today) {
      day = today
      allowed = 0
    }
    const limit = opts.limit
    const result = limit > 0 && allowed >= limit ? 'limited' : 'allowed'
    const line = `${JSON.stringify({
      t: now().toISOString(),
      day: today,
      route,
      vendor: 'n/a',
      model: 'n/a',
      result,
    })}\n`
    await mkdir(opts.dir, { recursive: true })
    await appendFile(file, line)
    if (result === 'allowed') allowed += 1
    return { allowed: result === 'allowed', limit, dayCount: allowed }
  }

  return { consume }
}
