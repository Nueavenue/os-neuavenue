import { randomBytes, timingSafeEqual } from 'node:crypto'

export const UI_TOKEN_HEADER = 'x-osneu-ui'
export const UI_TOKEN_META = 'osneu-ui-token'

const DEV_UI_PORTS = [5173, 4177]

export function createUiToken(): string {
  return randomBytes(32).toString('base64url')
}

export function normalizeHost(host: string | undefined): string {
  return String(host || '')
    .trim()
    .toLowerCase()
    .split(',')[0]
    .trim()
}

export function allowedHosts(port: number): string[] {
  return [`127.0.0.1:${port}`, `localhost:${port}`]
}

export function hostAllowed(host: string | undefined, port: number): boolean {
  const got = normalizeHost(host)
  return allowedHosts(port).includes(got)
}

export function extraOriginsFromEnv(env: NodeJS.ProcessEnv = process.env): string[] {
  const out: string[] = []
  for (const key of ['NEUOS_UI_URL', 'NEUOS_DEV_URL'] as const) {
    const raw = String(env[key] || '').trim()
    if (!raw) continue
    try {
      const origin = new URL(raw).origin
      if (origin.startsWith('http://127.0.0.1') || origin.startsWith('http://localhost')) out.push(origin)
    } catch {
      /* ignore bad env URL */
    }
  }
  return out
}

export function allowedOrigins(port: number, env: NodeJS.ProcessEnv = process.env): string[] {
  const list = [
    `http://127.0.0.1:${port}`,
    `http://localhost:${port}`,
    ...DEV_UI_PORTS.flatMap((p) => [`http://127.0.0.1:${p}`, `http://localhost:${p}`]),
    ...extraOriginsFromEnv(env),
  ]
  return [...new Set(list)]
}

export function originAllowed(origin: string | undefined, port: number, env: NodeJS.ProcessEnv = process.env): boolean {
  const got = String(origin || '').trim()
  if (!got) return false
  return allowedOrigins(port, env).includes(got)
}

export function needsOriginCheck(method: string): boolean {
  const m = method.toUpperCase()
  return m === 'POST' || m === 'PUT' || m === 'PATCH' || m === 'DELETE'
}

export function requiresUiToken(method: string, pathname: string): boolean {
  if (!needsOriginCheck(method)) return false
  return pathname.startsWith('/api/')
}

export function isAiSpendRoute(method: string, pathname: string): boolean {
  if (method.toUpperCase() !== 'POST') return false
  return (
    pathname === '/api/speak/chat' ||
    pathname === '/api/speak/asr' ||
    pathname === '/api/seat/write' ||
    pathname === '/api/office/assist' ||
    pathname === '/api/office/assist/stream'
  )
}

export function uiTokenOk(got: string | undefined, expected: string): boolean {
  const a = Buffer.from(String(got || ''))
  const b = Buffer.from(String(expected || ''))
  if (!a.length || !b.length || a.length !== b.length) {
    if (b.length) timingSafeEqual(b, b)
    return false
  }
  return timingSafeEqual(a, b)
}

export type GuardDecision =
  | { ok: true; corsOrigin?: string }
  | { ok: false; status: 401 | 403; reason: 'host' | 'origin' | 'ui-token'; corsOrigin?: string }

export function guardBridgeRequest(opts: {
  host?: string
  origin?: string
  method: string
  pathname: string
  uiHeader?: string
  uiToken: string
  port: number
  env?: NodeJS.ProcessEnv
}): GuardDecision {
  const method = String(opts.method || 'GET').toUpperCase()
  const env = opts.env || process.env
  if (!hostAllowed(opts.host, opts.port)) {
    return { ok: false, status: 403, reason: 'host' }
  }
  const origin = String(opts.origin || '').trim()
  const corsOrigin = origin && originAllowed(origin, opts.port, env) ? origin : undefined
  if (origin && !corsOrigin) {
    if (method === 'OPTIONS' || needsOriginCheck(method)) {
      return { ok: false, status: 403, reason: 'origin' }
    }
  }
  if (requiresUiToken(method, opts.pathname) && !uiTokenOk(opts.uiHeader, opts.uiToken)) {
    return { ok: false, status: 401, reason: 'ui-token', corsOrigin }
  }
  return { ok: true, corsOrigin }
}

export function applyAllowListCors(res: { setHeader(name: string, value: string): void }, corsOrigin?: string) {
  if (!corsOrigin) return
  res.setHeader('access-control-allow-origin', corsOrigin)
  res.setHeader('vary', 'Origin')
  res.setHeader('access-control-allow-headers', 'content-type, x-osneu-token, x-osneu-ui, x-neuos-openai-key')
  res.setHeader('access-control-allow-methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS')
}

export function publicLlmSettingsView(input: {
  provider?: string
  localModel?: string
  hasKey: boolean
  vendorHas: Record<string, boolean>
  ready: unknown
  installed: unknown
  diskFreeBytes: number
}) {
  return {
    ok: true as const,
    provider: input.provider,
    localModel: input.localModel,
    hasKey: input.hasKey,
    vendorHas: input.vendorHas,
    ready: input.ready,
    installed: input.installed,
    diskFreeBytes: input.diskFreeBytes,
  }
}

export function vendorHasFromKeys(vendorKeys: Record<string, unknown> | undefined): Record<string, boolean> {
  const out: Record<string, boolean> = {}
  for (const [name, value] of Object.entries(vendorKeys || {})) {
    out[name] = Boolean(String(value || '').trim())
  }
  return out
}
