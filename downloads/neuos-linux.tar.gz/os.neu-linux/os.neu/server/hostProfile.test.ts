import { describe, expect, it } from 'vitest'
import { parseOsRelease, pkgForDistro, parseAppIntent, planApp, searchCatalog } from '../boot/hostProfile.mjs'

describe('host OS aware installs', () => {
  it('maps ubuntu to apt', () => {
    const parsed = parseOsRelease('ID=ubuntu\nVERSION_ID="24.04"\nPRETTY_NAME="Ubuntu 24.04"\n')
    expect(parsed.id).toBe('ubuntu')
    expect(pkgForDistro(parsed.id)).toBe('apt')
  })

  it('turns 크롬 설치 into an apt chrome command on ubuntu-like host', () => {
    const intent = parseAppIntent('크롬 설치해줘')
    expect(intent?.kind).toBe('install')
    expect(intent?.app).toBe('chrome')
    const plan = planApp(
      {
        pretty: 'Ubuntu',
        pkg: 'apt',
        family: 'linux',
        distro: 'ubuntu',
        version: '24',
        arch: 'x64',
        hostname: 'box',
        cores: 8,
        memGb: 16,
        platform: 'Ubuntu',
      },
      intent,
    )
    expect(plan.command).toContain('apt')
    expect(plan.command).toContain('google-chrome-stable')
  })

  it('maps node.js on ubuntu to apt nodejs', () => {
    const intent = parseAppIntent('install node.js')
    expect(intent?.app).toBe('node')
    const plan = planApp(
      {
        pretty: 'Ubuntu',
        pkg: 'apt',
        family: 'linux',
        distro: 'ubuntu',
        version: '26',
        arch: 'x64',
        hostname: 'box',
        cores: 8,
        memGb: 16,
        platform: 'Ubuntu',
      },
      intent,
    )
    expect(plan.command).toContain('apt')
    expect(plan.command).toContain('nodejs')
    expect(plan.url).toContain('nodejs.org')
  })

  it('does not treat install os.neu as a host package', () => {
    expect(parseAppIntent('install os.neu')).toBeNull()
    expect(parseAppIntent('uninstall os.neu')).toBeNull()
  })

  it('maps winget on windows', () => {
    const intent = parseAppIntent('install firefox')
    const plan = planApp(
      {
        pretty: 'Windows',
        pkg: 'winget',
        family: 'win32',
        distro: 'windows',
        version: '10',
        arch: 'x64',
        hostname: 'pc',
        cores: 4,
        memGb: 8,
        platform: 'Windows',
      },
      intent,
    )
    expect(plan.command).toContain('winget')
    expect(plan.command).toContain('Mozilla.Firefox')
  })

  it('searches the catalog without running sudo', () => {
    const rows = searchCatalog('firefox', {
      pretty: 'Ubuntu',
      pkg: 'apt',
      family: 'linux',
      distro: 'ubuntu',
      version: '24',
      arch: 'x64',
      hostname: 'box',
      cores: 8,
      memGb: 16,
      platform: 'Ubuntu',
    })
    expect(rows.some((row) => row.app === 'firefox')).toBe(true)
    expect(rows[0].command).toContain('apt')
    expect(rows[0].command).not.toMatch(/dd if=/)
  })
})
