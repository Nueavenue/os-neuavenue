import {
  completeText,
  llmReady,
  streamChatLocal,
  wantsLocalModel,
  LOCAL_MODEL,
  isSmallLocal,
  ollamaStatus,
  ollamaTag,
  anyCloudKey,
} from '../boot/localLlm.mjs'
import { isRepeatingDraft, tidyDraft } from '../src/engine/draftText.ts'

export const OFFICE_MODELS = ['os.neu-local', 'gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1'] as const
export type OfficeModel = (typeof OFFICE_MODELS)[number]

export async function officeReady() {
  const ready = await llmReady()
  return ready.ok
}

function pickModel(raw: string): string {
  if (OFFICE_MODELS.includes(raw as OfficeModel)) return raw
  if (String(raw || '').startsWith('gpt-')) return raw
  if (ollamaTag(raw)) return raw
  if (raw && !String(raw).includes(':') && raw !== 'os.neu-local') return raw
  return 'os.neu-local'
}

const DOC_STYLE =
  'Write one memo, once, in the user language. ' +
  'Shape: a short title, one sentence of purpose, then three different sections (prepare, buy, check). ' +
  'Each section has at most four bullets, and the bullets must say different things. ' +
  'Do not repeat a heading, a bullet, or a paragraph. ' +
  'Do not write placeholders such as [Insert Date] or [Insert Amount]. ' +
  'If a date, price, or shop is unknown, write "확인 필요" once and move on. ' +
  'Do not invent prices, dates, hotels, restaurants, tickets, or store names. Do not claim you searched the web. ' +
  'The reader already lives where they said. Do not tell them to learn their own language or use a translator. ' +
  'Plain text only: no # headings and no ** bold.\n' +
  'Example shape only — use the user topic, do not copy this topic:\n' +
  '제목\n' +
  '목적: 한 문장.\n' +
  '준비\n' +
  '- 서로 다른 항목\n' +
  '살 것\n' +
  '- 확인 필요\n' +
  '확인\n' +
  '- 서로 다른 항목'

function pageIsJustTheAsk(instruction: string, content: string) {
  const ask = instruction.split('\n')[0].trim()
  const page = content.trim()
  if (!page || !ask) return !page
  if (isRepeatingDraft(page) || /\[insert /i.test(page)) return true
  return page === ask || (page.startsWith(ask) && page.length < ask.length + 48)
}

function systemFor(
  app: 'sheet' | 'doc' | 'slides',
  local: boolean,
  mode: 'write' | 'rewrite' = 'write',
  model = '',
) {
  if (mode === 'rewrite') {
    return local
      ? 'Rewrite only the selected text. Return the replacement only. Keep length similar unless asked.'
      : 'Rewrite the selected passage. Return only the replacement text, no preamble.'
  }
  if (local) {
    if (app === 'sheet')
      return (
        'Spreadsheet helper. Reply with one markdown pipe table of DISPLAY values only. ' +
        'One header row, then up to 10 data rows, at most 6 columns. ' +
        'Each cell is what a person reads on screen (labels, months, 확인 필요). ' +
        'No Excel formulas, no leading =, no cell addresses (A1, B2), no source code, no commentary. ' +
        'Do not invent revenue. Unknown numbers: 확인 필요.'
      )
    if (app === 'slides')
      return 'Slide helper. 8 to 12 slides. Each slide starts with # or ## then a title, then 3 to 5 bullets. Write full talking points, not one-word labels.'
    const small = isSmallLocal(ollamaTag(model) || 'llama3.2:1b')
    return small ? `${DOC_STYLE} Keep it to about 16 lines.` : `${DOC_STYLE} About 40 to 80 lines. Fill the page.`
  }
  if (app === 'sheet') {
    return (
      'You write spreadsheet content people read on screen. ' +
      'Reply with one markdown pipe table of DISPLAY values only: one header row, then 12 to 20 data rows, at most 8 columns. Use a report-like sheet when the user asked for a document-shaped table. ' +
      'No Excel formulas, no leading =, no cell addresses (A1), no source dumps, no commentary. ' +
      'Do not invent revenue. Unknown numbers: 확인 필요.'
    )
  }
  if (app === 'slides') {
    return (
      'You write a slide deck as JSON only — no markdown, no code fences, no commentary. ' +
      'Schema: {"version":1,"title":"optional deck title","slides":[...]} 8 to 12 slides. ' +
      'Each slide is one of: ' +
      '{"layout":"title","title":"string","body":"optional subtitle"}; ' +
      '{"layout":"bullets","title":"string","bullets":["max 6 short lines"]}; ' +
      '{"layout":"table","title":"string","table":{"headers":["max 5"],"rows":[["max 5 cols"], "max 8 rows"]}}. ' +
      'Only use numbers the user gave you in the instruction or current content — never invent NeuAvenue revenue, ARR, or KPI figures; ' +
      'if you must illustrate with made-up numbers, label the slide title or a cell "EXAMPLE". Reply with the JSON object only.'
    )
  }
  return `You write a document. ${DOC_STYLE}`
}

export function buildOfficeMessages(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
}) {
  const model = pickModel(String(input.model || ''))
  const local = wantsLocalModel(model)
  const mode = input.mode === 'rewrite' ? 'rewrite' : 'write'
  const system = systemFor(input.app, local, mode, model)
  const instruction = input.instruction.trim()
  const content = input.content || ''
  const shown = pageIsJustTheAsk(instruction, content)
    ? '(empty — write the memo once; do not echo the instruction)'
    : content.slice(0, local ? 1200 : 6000)
  const user =
    mode === 'rewrite'
      ? `Instruction: ${instruction}\nSelected text:\n${(input.selection || '').slice(0, 2000)}`
      : `Instruction: ${instruction}\nCurrent content:\n${shown}`
  return {
    model,
    local,
    messages: [
      { role: 'system' as const, content: system },
      { role: 'user' as const, content: user },
    ],
  }
}

export async function officeAssist(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
}): Promise<{ ok: boolean; text: string; model: string; provider?: string }> {
  const built = buildOfficeMessages(input)
  const history = (input.history || []).slice(-8).map((row) => ({
    role: row.role,
    content: row.content.slice(0, 1500),
  }))
  const messages = [built.messages[0], ...history, built.messages[1]]
  const result = await completeText({
    model: built.model,
    messages,
  })
  return { ok: true, text: result.text, model: result.model, provider: result.provider }
}

export async function* officeAssistStream(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
}) {
  const built = buildOfficeMessages(input)
  const history = (input.history || [])
    .filter((row) => row.role !== 'assistant' || (!isRepeatingDraft(row.content) && !/\[insert /i.test(row.content)))
    .slice(-4)
    .map((row) => ({
      role: row.role,
      content: row.content.slice(0, built.local ? 600 : 1500),
    }))
  const messages = [built.messages[0], ...history, built.messages[1]]

  if (built.local) {
    const status = await ollamaStatus()
    if (!status.ok) throw new Error('local-unavailable')
    const requested = ollamaTag(built.model) || LOCAL_MODEL
    const has =
      status.models.includes(requested) || (requested === LOCAL_MODEL && status.hasDefault)
    if (!has) throw new Error(`model-not-installed:${requested}`)
    const small = isSmallLocal(requested)
    for await (const chunk of streamChatLocal(messages, requested, {
      num_predict: small ? 400 : 1600,
      temperature: 0.55,
      repeat_penalty: 1.2,
      repeat_last_n: 256,
    })) {
      const full = tidyDraft(String(chunk.full || ''))
      const stop = isRepeatingDraft(String(chunk.full || ''))
      yield { ...chunk, full, done: Boolean(chunk.done) || stop }
      if (stop) return
    }
    return
  }

  if (!anyCloudKey()) throw new Error('no-llm')
  if (!key) throw new Error('no-llm')
  // Cloud path: one-shot then fake stream for typing UX
  const result = await completeText({ model: built.model, messages })
  const text = result.text
  const step = Math.max(1, Math.floor(text.length / 48))
  let full = ''
  for (let i = 0; i < text.length; i += step) {
    const piece = text.slice(i, i + step)
    full += piece
    yield { piece, full, model: result.model, provider: result.provider || 'openai', done: i + step >= text.length }
  }
}
