import { completeText, llmReady, wantsLocalModel } from '../boot/localLlm.mjs'

export const OFFICE_MODELS = ['os.neu-local', 'gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1'] as const
export type OfficeModel = (typeof OFFICE_MODELS)[number]

export async function officeReady() {
  const ready = await llmReady()
  return ready.ok
}

function pickModel(raw: string): string {
  return OFFICE_MODELS.includes(raw as OfficeModel) ? raw : 'os.neu-local'
}

export async function officeAssist(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
}): Promise<{ ok: boolean; text: string; model: string; provider?: string }> {
  const model = pickModel(String(input.model || ''))
  const app = input.app
  const system =
    app === 'sheet'
      ? 'You write spreadsheet content. Reply as TSV (tab-separated) with a header row, then up to 8 data rows. No markdown.'
      : app === 'slides'
        ? 'You write a short slide deck. Reply as markdown: each slide starts with ## title, then 2-5 bullet lines. Max 6 slides.'
        : 'You write a document. Reply with a title on the first line, then the body. Keep it useful and concise.'
  const result = await completeText({
    model: wantsLocalModel(model) ? 'os.neu-local' : model,
    messages: [
      { role: 'system', content: system },
      {
        role: 'user',
        content: `Instruction: ${input.instruction.trim()}\nCurrent content:\n${(input.content || '').slice(0, 6000)}`,
      },
    ],
  })
  return { ok: true, text: result.text, model: result.model, provider: result.provider }
}
