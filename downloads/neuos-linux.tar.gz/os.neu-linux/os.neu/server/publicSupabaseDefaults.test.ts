import { describe, expect, it } from 'vitest'
import {
  applyPublicSupabaseDefaults,
  PUBLIC_SUPABASE_DEFAULTS,
} from './publicSupabaseDefaults.ts'

function jwtPayload(token: string) {
  const part = token.split('.')[1] || ''
  return JSON.parse(Buffer.from(part, 'base64url').toString('utf8')) as { role?: string }
}

describe('public Supabase defaults (WS-4)', () => {
  it('ships the publishable anon role and never a service_role token', () => {
    expect(PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_URL).toMatch(/^https:\/\/.+\.supabase\.co$/)
    expect(jwtPayload(PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_ANON_KEY).role).toBe('anon')
    expect(JSON.stringify(PUBLIC_SUPABASE_DEFAULTS)).not.toMatch(/service_role/)
  })

  it('fills empty env and leaves an explicit override', () => {
    const empty: NodeJS.ProcessEnv = { PUBLIC_SUPABASE_URL: '', PUBLIC_SUPABASE_ANON_KEY: '' }
    applyPublicSupabaseDefaults(empty)
    expect(empty.PUBLIC_SUPABASE_URL).toBe(PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_URL)
    expect(empty.PUBLIC_SUPABASE_ANON_KEY).toBe(PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_ANON_KEY)

    const custom: NodeJS.ProcessEnv = {
      PUBLIC_SUPABASE_URL: 'https://other.supabase.co',
      PUBLIC_SUPABASE_ANON_KEY: 'user-anon',
    }
    applyPublicSupabaseDefaults(custom)
    expect(custom.PUBLIC_SUPABASE_URL).toBe('https://other.supabase.co')
    expect(custom.PUBLIC_SUPABASE_ANON_KEY).toBe('user-anon')
  })
})
