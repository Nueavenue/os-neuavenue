import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  supabaseEnabled,
  supabaseSignIn,
  supabaseSignOut,
  supabaseSignUp,
  supabaseUser,
} from './supabase.ts'


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const FILE = path.join(ROOT, 'data', 'accounts.json')

export const ADMIN_EMAILS = new Set(['billylee96312@gmail.com', 'billylee96312@gmailcom'])

export type AccountRecord = {
  name: string
  email: string
  salt: string
  hash: string
  createdAt: number
}

export type PublicUser = {
  name: string
  email: string
  admin: boolean
}

type Store = {
  accounts: AccountRecord[]
  sessions: Array<{ token: string; email: string; createdAt: number }>
}

function normalizeEmail(raw: string) {
  return String(raw || '').trim().toLowerCase()
}

export function isAdminEmail(email: string) {
  return ADMIN_EMAILS.has(normalizeEmail(email))
}

async function load(): Promise<Store> {
  try {
    const raw = JSON.parse(await readFile(FILE, 'utf8')) as Store
    return {
      accounts: Array.isArray(raw.accounts) ? raw.accounts : [],
      sessions: Array.isArray(raw.sessions) ? raw.sessions : [],
    }
  } catch {
    return { accounts: [], sessions: [] }
  }
}

async function save(store: Store) {
  await mkdir(path.dirname(FILE), { recursive: true })
  await writeFile(FILE, JSON.stringify(store, null, 2))
}

function toPublic(row: AccountRecord): PublicUser {
  return { name: row.name, email: row.email, admin: isAdminEmail(row.email) }
}

function hashPassword(password: string, salt: string) {
  return scryptSync(password, salt, 32)
}

export async function registerAccount(name: string, email: string, password: string) {
  const neat = normalizeEmail(email)
  const label = name.trim()
  const pass = String(password || '')
  if (!label || !neat || pass.length < 4) throw new Error('invalid-account')
  if (supabaseEnabled()) {
    const cloud = await supabaseSignUp(label, neat, pass)
    if (cloud) return cloud
  }
  const store = await load()
  if (store.accounts.some((row) => row.email === neat)) throw new Error('email-taken')
  const salt = randomBytes(16).toString('hex')
  const hash = hashPassword(pass, salt).toString('hex')
  const row: AccountRecord = { name: label, email: neat, salt, hash, createdAt: Date.now() }
  store.accounts.push(row)
  const token = randomBytes(24).toString('hex')
  store.sessions.push({ token, email: neat, createdAt: Date.now() })
  await save(store)
  return { token, user: toPublic(row) }
}

export async function loginAccount(email: string, password: string) {
  const neat = normalizeEmail(email)
  if (supabaseEnabled()) {
    try {
      const cloud = await supabaseSignIn(neat, String(password || ''))
      if (cloud) return cloud
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'bad-credentials'
      try {
        return await loginLocal(neat, String(password || ''))
      } catch {
        throw new Error(reason)
      }
    }
  }
  return loginLocal(neat, String(password || ''))
}

async function loginLocal(neat: string, password: string) {
  const store = await load()
  const row = store.accounts.find((item) => item.email === neat)
  if (!row) throw new Error('bad-credentials')
  const actual = Buffer.from(row.hash, 'hex')
  const next = hashPassword(password, row.salt)
  if (actual.length !== next.length || !timingSafeEqual(actual, next)) throw new Error('bad-credentials')
  const token = randomBytes(24).toString('hex')
  store.sessions.push({ token, email: neat, createdAt: Date.now() })
  store.sessions = store.sessions.slice(-400)
  await save(store)
  return { token, user: toPublic(row) }
}

export async function userFromToken(token: string): Promise<PublicUser | null> {
  if (!token) return null
  const cloud = await supabaseUser(token)
  if (cloud) return cloud
  const store = await load()
  const session = store.sessions.find((row) => row.token === token)
  if (!session) return null
  const row = store.accounts.find((item) => item.email === session.email)
  return row ? toPublic(row) : null
}

export async function logoutToken(token: string) {
  await supabaseSignOut(token)
  const store = await load()
  store.sessions = store.sessions.filter((row) => row.token !== token)
  await save(store)
}

export async function listAccounts(): Promise<PublicUser[]> {
  const store = await load()
  return store.accounts.map(toPublic)
}
