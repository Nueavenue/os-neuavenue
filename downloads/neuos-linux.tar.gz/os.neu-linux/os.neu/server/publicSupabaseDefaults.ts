/**
 * Public (anon) Supabase defaults for packaged os.neu.
 * Never add service_role / secret keys here. .env still overrides.
 */
export const PUBLIC_SUPABASE_DEFAULTS = {
  PUBLIC_SUPABASE_URL: 'https://mizwgfnfdkovbbwncstc.supabase.co',
  PUBLIC_SUPABASE_ANON_KEY:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1pendnZm5mZGtvdmJid25jc3RjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1MzAxNjMsImV4cCI6MjA5MDEwNjE2M30.wcm9Q8apy9OgRqXVqHENRAyC5N2LeIo-Y3IUfwXk54c',
} as const

export function applyPublicSupabaseDefaults(env: NodeJS.ProcessEnv = process.env) {
  const url = String(env.PUBLIC_SUPABASE_URL || '').trim()
  const anon = String(env.PUBLIC_SUPABASE_ANON_KEY || '').trim()
  if (!url) env.PUBLIC_SUPABASE_URL = PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_URL
  if (!anon) env.PUBLIC_SUPABASE_ANON_KEY = PUBLIC_SUPABASE_DEFAULTS.PUBLIC_SUPABASE_ANON_KEY
}
