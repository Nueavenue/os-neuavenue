import { mkdir, writeFile, readdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
export const SAMPLE_DIR = path.join(root, 'data', 'vlm-samples')

export type SampleBox = {
  id: string
  label: string
  x: number
  y: number
  w: number
  h: number
  confidence?: number
}

export type VisionSample = {
  id: string
  query: string
  capturedAt: number
  boxes: SampleBox[]
  image?: string
}

export async function saveSample(sample: VisionSample): Promise<{ id: string; json: string }> {
  await mkdir(SAMPLE_DIR, { recursive: true })
  const id = sample.id || `vlm-${Date.now()}`
  const jsonPath = path.join(SAMPLE_DIR, `${id}.json`)
  const record = {
    id,
    query: sample.query,
    capturedAt: sample.capturedAt || Date.now(),
    boxes: sample.boxes,
    image: `${id}.png`,
  }
  await writeFile(jsonPath, JSON.stringify(record, null, 2), 'utf8')
  if (sample.image?.startsWith('data:image')) {
    const b64 = sample.image.split(',')[1] ?? ''
    await writeFile(path.join(SAMPLE_DIR, `${id}.png`), Buffer.from(b64, 'base64'))
  }
  return { id, json: jsonPath }
}

export async function listSamples(): Promise<number> {
  try {
    const files = await readdir(SAMPLE_DIR)
    return files.filter((f) => f.endsWith('.json')).length
  } catch {
    return 0
  }
}

export function rankBoxes(boxes: SampleBox[], query: string): SampleBox[] {
  const q = query.toLowerCase()
  return [...boxes].sort((a, b) => score(b, q) - score(a, q))
}

function score(box: SampleBox, q: string): number {
  const hay = `${box.id} ${box.label}`.toLowerCase()
  let s = box.confidence ?? 0.5
  if (hay.includes(q)) s += 0.3
  if (q.includes('save') && hay.includes('save')) s += 0.3
  if (q.includes('저장') && hay.includes('save')) s += 0.3
  if (q.includes('title') && hay.includes('title')) s += 0.3
  if (q.includes('제목') && hay.includes('title')) s += 0.3
  return s
}

export async function infer(input: {
  query: string
  boxes?: SampleBox[]
  image?: string
}): Promise<{ source: 'remote' | 'graph'; boxes: SampleBox[] }> {
  const remote = process.env.NEUOS_VLM_URL
  if (remote && input.image) {
    try {
      const res = await fetch(remote, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ query: input.query, image: input.image }),
        signal: AbortSignal.timeout(8000),
      })
      if (res.ok) {
        const data = (await res.json()) as { boxes?: SampleBox[] }
        if (data.boxes?.length) return { source: 'remote', boxes: data.boxes }
      }
    } catch {
      // fall through to graph labels collected for fine-tuning
    }
  }
  return { source: 'graph', boxes: rankBoxes(input.boxes ?? [], input.query) }
}
