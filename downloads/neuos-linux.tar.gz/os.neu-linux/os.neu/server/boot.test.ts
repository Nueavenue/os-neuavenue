import { execFileSync } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
import { readBootHealth } from './boot.ts'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const KERNEL = path.join(ROOT, 'boot', 'kernel.mjs')

describe('boot-health kernel', () => {
  it('writes a heartbeat and answers --ask', () => {
    const healthRaw = execFileSync(process.execPath, [KERNEL, '--health'], { encoding: 'utf8' })
    const health = JSON.parse(healthRaw) as { ok: boolean; stage: string }
    expect(health.ok).toBe(true)
    expect(health.stage).toBe('probe')

    const askedRaw = execFileSync(process.execPath, [KERNEL, '--ask', 'hardware'], { encoding: 'utf8' })
    const asked = JSON.parse(askedRaw) as { act: string; reply: string }
    expect(asked.act).toBe('cmd')
    expect(asked.reply.length).toBeGreaterThan(8)

    const loop = execFileSync(process.execPath, [KERNEL, '--ask', '루프'], { encoding: 'utf8' })
    expect(JSON.parse(loop).act).toBe('lui')

    const appRaw = execFileSync(process.execPath, [KERNEL, '--ask', 'install firefox'], { encoding: 'utf8' })
    const app = JSON.parse(appRaw) as { act: string; plan?: { command: string } }
    expect(app.act).toBe('app')
    expect(app.plan?.command).toMatch(/apt|dnf|pacman|winget|brew|Download/)
  })

  it('reads the heartbeat file', async () => {
    const row = await readBootHealth()
    expect(row.missing).toBe(false)
    expect(row.t).toBeGreaterThan(0)
  })
})
