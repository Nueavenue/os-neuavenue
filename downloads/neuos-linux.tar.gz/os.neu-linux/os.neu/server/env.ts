import { readFileSync } from 'node:fs'
import path from 'node:path'

/** Load KEY=value from a local .env without printing values. */
export function loadLocalEnv(root: string) {
  const file = path.join(root, '.env')
  let raw = ''
  try {
    raw = readFileSync(file, 'utf8')
  } catch {
    return
  }
  for (const line of raw.split('\n')) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const eq = trimmed.indexOf('=')
    if (eq < 1) continue
    const key = trimmed.slice(0, eq).trim()
    let value = trimmed.slice(eq + 1).trim()
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1)
    }
    if (key && process.env[key] == null) process.env[key] = value
  }
}

export function openaiKey(): string {
  return process.env.OPENAI_API_KEY?.trim() ?? ''
}
