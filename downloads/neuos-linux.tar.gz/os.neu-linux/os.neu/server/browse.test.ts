import { createServer } from 'node:http'
import { describe, expect, it } from 'vitest'
import { fetchPage } from './browse.ts'
import { infer, saveSample } from './vlm.ts'

describe('browse proxy', () => {
  it('rejects non-http schemes', async () => {
    const page = await fetchPage('file:///etc/passwd')
    expect(page.ok).toBe(false)
    expect(page.status).toBe(400)
  })

  it('rewrites html through the same origin', async () => {
    const server = createServer((_req, res) => {
      res.writeHead(200, { 'content-type': 'text/html', 'x-frame-options': 'DENY' })
      res.end('<html><head><title>box</title></head><body>hello-neuos</body></html>')
    })
    await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
    const addr = server.address()
    if (!addr || typeof addr === 'string') throw new Error('no port')
    const page = await fetchPage(`http://127.0.0.1:${addr.port}/`)
    server.close()
    expect(page.body.toString()).toContain('hello-neuos')
    expect(page.body.toString()).toContain('<base href=')
  })
})

describe('vlm dataset', () => {
  it('stores labeled boxes for fine-tuning', async () => {
    const saved = await saveSample({
      id: `test-${Date.now()}`,
      query: '저장',
      capturedAt: Date.now(),
      boxes: [{ id: 'save', label: '저장', x: 10, y: 12, w: 40, h: 18, confidence: 0.9 }],
    })
    expect(saved.json).toContain('vlm-samples')
    const ranked = await infer({
      query: '저장',
      boxes: [
        { id: 'title', label: '제목', x: 0, y: 0, w: 80, h: 20 },
        { id: 'save', label: '저장', x: 10, y: 12, w: 40, h: 18 },
      ],
    })
    expect(ranked.source).toBe('graph')
    expect(ranked.boxes[0]?.id).toBe('save')
  })
})
