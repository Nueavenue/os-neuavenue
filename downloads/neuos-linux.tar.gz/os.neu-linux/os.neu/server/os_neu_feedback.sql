-- Paste in Supabase → SQL editor once, so os.neu feedback Save can write to the cloud.
-- Anon insert/select is enough for the bridge using PUBLIC_SUPABASE_ANON_KEY.

create table if not exists public.os_neu_feedback (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text,
  email text,
  title text not null,
  body text not null
);

alter table public.os_neu_feedback enable row level security;

drop policy if exists "os_neu_feedback_insert" on public.os_neu_feedback;
create policy "os_neu_feedback_insert"
  on public.os_neu_feedback
  for insert
  to anon, authenticated
  with check (true);

drop policy if exists "os_neu_feedback_select" on public.os_neu_feedback;
create policy "os_neu_feedback_select"
  on public.os_neu_feedback
  for select
  to anon, authenticated
  using (true);
