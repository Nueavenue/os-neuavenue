import { execFile } from 'node:child_process'
import { existsSync, realpathSync } from 'node:fs'
import { mkdir, writeFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import path from 'node:path'
import { promisify } from 'node:util'
import {
  craftSandboxRoot,
  isAllowedCraftCli,
  isInsideSandbox,
  prepareCraftConvert,
  type CraftSurface,
} from '../src/engine/craftConvert.ts'
import { planCraftJob } from '../src/engine/craftPlan.ts'
import { detectCraftBinsOnHost } from './craftDetectHttp.ts'

const execFileAsync = promisify(execFile)

function reply(
  res: ServerResponse,
  body: { converted: boolean; reason: string; path?: string },
) {
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify({ ok: true, ...body }))
}

async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  const raw = Buffer.concat(chunks).toString('utf8')
  if (!raw.trim()) return {}
  const parsed = JSON.parse(raw) as unknown
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : {}
}

function asSurface(value: unknown): CraftSurface | null {
  return value === 'doc' || value === 'sheet' || value === 'slides' ? value : null
}

export async function handleCraftConvert(req: IncomingMessage, res: ServerResponse) {
  try {
    const payload = await readJson(req)
    const surface = asSurface(payload.surface)
    if (!surface) {
      reply(res, { converted: false, reason: 'no-office-intent' })
      return
    }
    const bins = await detectCraftBinsOnHost()
    const job = planCraftJob(surface, bins)
    if (job.reason !== 'cli-ready' || !job.cliPath) {
      reply(res, { converted: false, reason: job.reason === 'no-office-intent' ? 'no-office-intent' : 'cli-missing' })
      return
    }
    if (!isAllowedCraftCli(job.cliPath)) {
      reply(res, { converted: false, reason: 'cli-missing' })
      return
    }
    const sandbox = craftSandboxRoot(process.env)
    await mkdir(sandbox, { recursive: true })
    const root = realpathSync(sandbox)
    const prep = prepareCraftConvert({
      sandbox: root,
      surface,
      title: String(payload.title || 'Seat'),
      body: String(payload.body || ''),
    })
    if ('error' in prep) {
      reply(res, { converted: false, reason: 'convert-failed' })
      return
    }
    const inAbs = path.resolve(root, prep.inRel)
    const outAbs = path.resolve(root, prep.outRel)
    if (!isInsideSandbox(root, inAbs) || !isInsideSandbox(root, outAbs)) {
      reply(res, { converted: false, reason: 'convert-failed' })
      return
    }
    await writeFile(inAbs, prep.inputText, 'utf8')
    try {
      await execFileAsync(job.cliPath, prep.argv, { cwd: root, timeout: 30_000, shell: false })
    } catch {
      reply(res, { converted: false, reason: 'convert-failed' })
      return
    }
    if (!existsSync(outAbs)) {
      reply(res, { converted: false, reason: 'convert-failed' })
      return
    }
    const outReal = realpathSync(outAbs)
    if (!isInsideSandbox(root, outReal)) {
      reply(res, { converted: false, reason: 'convert-failed' })
      return
    }
    reply(res, { converted: true, reason: 'converted', path: outReal })
  } catch {
    reply(res, { converted: false, reason: 'convert-failed' })
  }
}
