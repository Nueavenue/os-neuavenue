import { describe, expect, it } from 'vitest'
import { extensionFor } from './transcribe.ts'

describe('extensionFor', () => {
  it('uses webm for opus recordings', () => {
    expect(extensionFor('audio/webm;codecs=opus')).toBe('webm')
  })

  it('maps wav and mp4', () => {
    expect(extensionFor('audio/wav')).toBe('wav')
    expect(extensionFor('audio/mp4')).toBe('mp4')
  })
})
