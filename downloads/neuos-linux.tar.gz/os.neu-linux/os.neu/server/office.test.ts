import { describe, expect, it } from 'vitest'
import { buildOfficeMessages, OFFICE_MODELS } from './office.ts'

describe('office models', () => {
  it('lists the on-device public AI first', () => {
    expect(OFFICE_MODELS[0]).toBe('os.neu-local')
  })

  it('keeps the selected local model and drops a looping page', () => {
    const built = buildOfficeMessages({
      model: 'gemma2:9b',
      app: 'doc',
      instruction: '포항 출장 준비해주고 여행지 구매 출장 메모해줘',
      content:
        '* 포항 출장 준비\n+ 일자: [Insert Date]\n+ 출장지: 포항시\n+ 출장비: [Insert Amount]\n* 포항 출장 준비\n+ 일자: [Insert Date]\n+ 출장지: 포항시\n+ 출장비: [Insert Amount]',
    })
    expect(built.model).toBe('gemma2:9b')
    expect(built.messages[1].content).toContain('(empty — write the memo once')
    expect(built.messages[0].content).toContain('확인 필요')
  })

  it('asks the sheet writer for a display table, not formula source', () => {
    const built = buildOfficeMessages({
      model: 'qwen2.5:7b',
      app: 'sheet',
      instruction: '구글 작년 매출 엑셀 표 제작해줘',
    })
    expect(built.messages[0].content).toContain('DISPLAY')
    expect(built.messages[0].content).toContain('A1')
    expect(built.messages[0].content).toContain('확인 필요')
  })
})
