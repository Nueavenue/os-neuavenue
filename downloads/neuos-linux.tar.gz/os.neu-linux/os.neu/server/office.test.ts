import { describe, expect, it } from 'vitest'
import { OFFICE_MODELS } from './office.ts'

describe('office models', () => {
  it('lists the on-device public AI first', () => {
    expect(OFFICE_MODELS[0]).toBe('os.neu-local')
  })
})
