import { describe, expect, it } from 'vitest'
import { heuristicPackMatch, hybridImageHtml, IMAGE_TO_HTML_SYSTEM } from './imageToHtml'

describe('imageToHtml', () => {
  it('heuristic matches cream + dark palette to product-structure', () => {
    expect(
      heuristicPackMatch({
        background: '#ece8d8',
        palette: ['#ece8d8', '#eeedee', '#111112', '#222222', '#e8a090'],
      }),
    ).toBe('product-structure')
  })

  it('hybrid scaffold embeds image and editable overlays', () => {
    const html = hybridImageHtml({
      dataUrl: 'data:image/png;base64,aaa',
      title: '제품 구조',
      originalHint: 'product-structure',
      analysis: {
        background: '#ECE3D2',
        ink: '#14181D',
        accent: '#BC4F2B',
        soft: '#4A4D52',
        fontFamily: 'Inter, sans-serif',
        width: 2774,
        height: 1557,
        regions: [{ left: 96, top: 90, width: 1600, height: 80, fontSize: 48 }],
      },
    })
    expect(html).toContain('data-import="hybrid"')
    expect(html).toContain('contenteditable')
    expect(html).toContain('product-structure')
    expect(html.length).toBeGreaterThan(400)
  })

  it('system prompt requires editable DOM not screenshot wrapper', () => {
    expect(IMAGE_TO_HTML_SYSTEM).toMatch(/1920/)
    expect(IMAGE_TO_HTML_SYSTEM).toMatch(/not as a background screenshot/i)
  })
})
