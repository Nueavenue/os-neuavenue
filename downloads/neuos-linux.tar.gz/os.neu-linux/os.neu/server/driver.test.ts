import { mkdtempSync, statSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { driverConsentPath, driverLiveEnabled, readDriverConsent, writeDriverConsent } from './driver.ts'

const roots: string[] = []

function tmpRoot() {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'neuos-driver-'))
  roots.push(dir)
  return dir
}

afterEach(() => {
  delete process.env.NEUOS_DRIVER
})

describe('driver consent (P0-②)', () => {
  it('is off by default and stays off when env asks for live without consent', () => {
    const root = tmpRoot()
    process.env.NEUOS_DRIVER = 'live'
    expect(readDriverConsent(root).on).toBe(false)
    expect(driverLiveEnabled(root)).toBe(false)
  })

  it('turns on only after consent and can be forced off', () => {
    const root = tmpRoot()
    const next = writeDriverConsent(true, root)
    expect(next.on).toBe(true)
    expect(driverLiveEnabled(root)).toBe(true)
    const mode = statSync(driverConsentPath(root)).mode & 0o777
    expect(mode).toBe(0o600)
    expect(statSync(driverConsentPath(root)).size).toBeGreaterThan(1)
    process.env.NEUOS_DRIVER = 'off'
    expect(driverLiveEnabled(root)).toBe(false)
  })
})
