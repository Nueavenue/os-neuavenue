import { createReadStream, existsSync, readFileSync, statSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import path from 'node:path'

const MIME: Record<string, string> = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json',
  '.map': 'application/json',
  '.md': 'text/markdown; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
}

export function packagedWebDir() {
  const raw = String(process.env.NEUOS_WEB_DIR || '').trim()
  return raw ? path.resolve(raw) : ''
}

/** Map a URL path onto dist-web. Rejects traversal. SPA falls back to index.html. */
export function resolveWebFile(webRoot: string, pathname: string) {
  const root = path.resolve(webRoot)
  let rel = decodeURIComponent(pathname.split('?')[0] || '/')
  if (!rel.startsWith('/')) rel = `/${rel}`
  if (rel === '/') rel = '/index.html'
  const abs = path.resolve(root, `.${rel}`)
  if (abs !== root && !abs.startsWith(root + path.sep)) return null
  if (existsSync(abs) && statSync(abs).isFile()) return abs
  const index = path.join(root, 'index.html')
  if (existsSync(index) && statSync(index).isFile()) return index
  return null
}

export function injectUiTokenHtml(html: string, token: string): string {
  const safe = String(token || '').replace(/[^A-Za-z0-9_-]/g, '')
  if (!safe) return html
  const meta = `<meta name="osneu-ui-token" content="${safe}">`
  if (/<meta\s+name="osneu-ui-token"/i.test(html)) {
    return html.replace(/<meta\s+name="osneu-ui-token"[^>]*>/i, meta)
  }
  if (html.includes('</head>')) return html.replace('</head>', `${meta}</head>`)
  return `${meta}${html}`
}

export function tryServePackagedWeb(req: IncomingMessage, res: ServerResponse, pathname: string, token = '') {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false
  if (pathname.startsWith('/api/')) return false
  const webRoot = packagedWebDir()
  if (!webRoot) return false
  const file = resolveWebFile(webRoot, pathname)
  if (!file) return false
  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream'
  if (req.method === 'HEAD') {
    res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store' })
    res.end()
    return true
  }
  if (type.startsWith('text/html') && token) {
    const html = injectUiTokenHtml(readFileSync(file, 'utf8'), token)
    res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store' })
    res.end(html)
    return true
  }
  res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store' })
  createReadStream(file).pipe(res)
  return true
}
