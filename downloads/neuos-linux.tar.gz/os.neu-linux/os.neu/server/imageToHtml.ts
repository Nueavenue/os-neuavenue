/**
 * Image → editable 1920×1080 HTML (Vision LLM path).
 * OCR not required: multimodal model reads layout + text.
 * Falls back with explicit reason when no cloud vision key.
 */
import { chatOpenAi, userOpenAiKey, anyCloudKey } from '../boot/localLlm.mjs'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

export const IMAGE_TO_HTML_SYSTEM = `You convert one presentation screenshot into a single editable HTML slide.
Return ONLY a full HTML document in a \`\`\`html fence (or raw <!DOCTYPE html>...).
Requirements:
- Canvas exactly 1920×1080 (.slide-container), absolute positioned text/shapes
- Recreate visible Korean/English text as real DOM text (not as a background screenshot)
- Preserve cream/paper or dark theme colors from the image
- Prefer Inter + Noto Sans KR
- No invented revenue / USB-shipped / AI OS claims; use Trusted Agent Seat wording if product claims appear
- No markdown outside the HTML
- Do not wrap the slide as an <img> of the screenshot — rebuild as HTML so fonts can be edited later`

export type ImageToHtmlInput = {
  image: string
  model?: string
  instruction?: string
  packHints?: Array<{ id: string; file: string; label?: string }>
  analysis?: {
    background?: string
    ink?: string
    accent?: string
    palette?: string[]
  }
}

export type ImageToHtmlResult = {
  ok: boolean
  html?: string
  source?: string
  reason?: string
  model?: string
  matchedSlideId?: string
}

function extractHtml(text: string): string | null {
  if (!text) return null
  const fence = text.match(/```html\s*([\s\S]*?)```/i)
  if (fence) return fence[1].trim()
  const doc = text.match(/(<!DOCTYPE html[\s\S]*<\/html>)/i)
  if (doc) return doc[1].trim()
  if (/<div[^>]*slide-container/i.test(text) && text.length > 400) {
    return `<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>Imported</title></head><body>${text}</body></html>`
  }
  return null
}

function pickVisionModel(raw?: string): string {
  const m = String(raw || '').trim()
  if (/^gpt-4o/.test(m) || /^gpt-4\.1/.test(m) || m === 'gpt-4o-mini') return m
  // Prefer a vision-capable OpenAI default when key exists
  if (userOpenAiKey()) return 'gpt-4o'
  return m || 'gpt-4o'
}

/** Heuristic: cream paper + dark right rail → PSST product-structure family. */
export function heuristicPackMatch(analysis?: ImageToHtmlInput['analysis']): string | null {
  const bg = String(analysis?.background || '').toLowerCase()
  const palette = (analysis?.palette || []).map((c) => c.toLowerCase())
  const cream =
    /^#e[0-9a-f]{5}$/i.test(bg) ||
    palette.some((c) => /^#e[89a-f][0-9a-f]{4}$/i.test(c) || c.includes('ece') || c.includes('e8e'))
  const dark =
    palette.some((c) => /^#1[0-9a-f]{5}$/i.test(c) || /^#2[0-9a-f]{5}$/i.test(c) || c === '#111112' || c === '#222222')
  if (cream && dark) return 'product-structure'
  return null
}

export async function loadPackSlideHtml(slideFile: string, packPublicDir?: string): Promise<string | null> {
  const bases = [
    packPublicDir,
    path.join(root, 'public', 'psst-ir-pack', 'slides'),
    path.join(root, 'public', 'html-templates'),
  ].filter(Boolean) as string[]
  for (const base of bases) {
    const candidates = [
      path.join(base, slideFile),
      path.join(base, 'slides', slideFile),
      path.join(root, 'public', 'psst-ir-pack', 'slides', slideFile),
    ]
    for (const file of candidates) {
      try {
        const html = await readFile(file, 'utf8')
        if (html && html.length > 200) return html
      } catch {
        /* try next */
      }
    }
  }
  return null
}

export async function imageToHtml(input: ImageToHtmlInput): Promise<ImageToHtmlResult> {
  const image = String(input.image || '')
  if (!image.startsWith('data:image')) {
    return { ok: false, reason: 'need-data-url' }
  }

  // Pack match is a Reject→원본 hint only. Never short-circuit to the same pack HTML
  // for every cream+dark upload — that made re-imports look like "이전 화면 그대로".
  const matched = heuristicPackMatch(input.analysis)

  if (!anyCloudKey() || !userOpenAiKey()) {
    return {
      ok: false,
      reason: 'no-vision-key',
      matchedSlideId: matched || undefined,
    }
  }

  const model = pickVisionModel(input.model)
  const hintLines = (input.packHints || [])
    .slice(0, 24)
    .map((h) => `- ${h.id} · ${h.file} · ${h.label || ''}`)
    .join('\n')
  const userText = [
    input.instruction || 'Rebuild this screenshot as an editable 1920×1080 HTML slide.',
    input.analysis
      ? `Palette hint: bg=${input.analysis.background} ink=${input.analysis.ink} accent=${input.analysis.accent}`
      : '',
    hintLines ? `If this matches a known pack slide, recreate that layout. Known slides:\n${hintLines}` : '',
  ]
    .filter(Boolean)
    .join('\n\n')

  const key = userOpenAiKey()
  if (!key) {
    return { ok: false, reason: 'no-vision-key', matchedSlideId: matched || undefined }
  }

  try {
    // Call OpenAI vision path directly (skip local text-only Ollama).
    const result = await chatOpenAi(
      [
        { role: 'system', content: IMAGE_TO_HTML_SYSTEM },
        {
          role: 'user',
          content: [
            { type: 'text', text: userText },
            { type: 'image_url', image_url: { url: image } },
          ],
        },
      ],
      model,
      key,
    )
    const html = extractHtml(result.text)
    if (!html || html.length < 400) {
      return { ok: false, reason: 'no-html-in-vision-reply', model: result.model }
    }
    return {
      ok: true,
      html,
      source: 'vision:' + (result.provider || 'openai') + ':' + result.model,
      reason: 'Vision LLM rebuilt editable HTML — fonts/text are editable DOM',
      model: result.model,
      matchedSlideId: matched || undefined,
    }
  } catch (err) {
    return {
      ok: false,
      reason: err instanceof Error ? err.message : 'vision-error',
      matchedSlideId: matched || undefined,
    }
  }
}

/** Offline scaffold: keep screenshot as underlay + editable text slots (fonts editable on overlays). */
export function hybridImageHtml(opts: {
  dataUrl: string
  analysis: { background: string; ink: string; accent: string; soft: string; fontFamily: string; regions: Array<{ left: number; top: number; width: number; height: number; fontSize: number }>; width: number; height: number }
  title?: string
  originalHint?: string
}): string {
  const a = opts.analysis
  const overlays = (a.regions.length ? a.regions : [{ left: 96, top: 200, width: 1400, height: 120, fontSize: 48 }])
    .slice(0, 5)
    .map((r, idx) => {
      const label = idx === 0 ? (opts.title || '제목을 입력 · 폰트 수정 가능') : `텍스트 ${idx + 1} · 클릭 후 Agent로 교체`
      return `<p contenteditable="true" data-edit="1" style="position:absolute;left:${r.left}px;top:${r.top}px;width:${r.width}px;margin:0;padding:8px;font-size:${r.fontSize}px;font-weight:${idx === 0 ? 800 : 600};line-height:1.25;color:${a.ink};font-family:${a.fontFamily};background:rgba(236,227,210,.72);border:1px dashed ${a.accent};z-index:5;">${label.replace(/[<>]/g, '')}</p>`
    })
    .join('\n')
  const hint = opts.originalHint
    ? `<p style="position:absolute;left:96px;top:1000px;margin:0;font-size:14px;color:${a.accent};z-index:6;">원본 후보: ${opts.originalHint} · Reject 후 원본 슬라이드 열기</p>`
    : `<p style="position:absolute;left:96px;top:1000px;margin:0;font-size:14px;color:${a.soft};z-index:6;">Vision 대기/실패 · 배경=스크린샷 · 위 텍스트 레이어만 폰트 편집 가능</p>`
  return `<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8"><title>Image hybrid</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+KR:wght@400;700;800&display=swap" rel="stylesheet">
<style>body{margin:0;overflow:hidden;background:${a.background};font-family:${a.fontFamily};}</style>
</head><body>
<div class="slide-container" data-import="hybrid" style="position:relative;width:1920px;height:1080px;background:${a.background};overflow:hidden;">
  <img alt="" src="${opts.dataUrl.replace(/"/g, '')}" style="position:absolute;left:0;top:0;width:1920px;height:1080px;object-fit:fill;z-index:1;opacity:.92;" />
  ${overlays}
  ${hint}
</div>
</body></html>`
}
