import { describe, expect, it } from 'vitest'
import { parseLsblk, usbCandidates } from './usb.ts'

const sample = {
  blockdevices: [
    {
      name: 'nvme0n1',
      path: '/dev/nvme0n1',
      size: '512G',
      model: 'INTERNAL',
      rm: '0',
      type: 'disk',
      mountpoint: null,
      children: [
        {
          name: 'nvme0n1p2',
          path: '/dev/nvme0n1p2',
          type: 'part',
          mountpoint: '/',
          rm: '0',
        },
      ],
    },
    {
      name: 'sdb',
      path: '/dev/sdb',
      size: '15G',
      model: 'Cruzer',
      rm: true,
      type: 'disk',
      mountpoint: null,
      children: [],
    },
  ],
}

describe('usb disk filter', () => {
  it('marks the disk that holds / as system and keeps removable sticks', () => {
    const disks = parseLsblk(sample)
    const internal = disks.find((d) => d.name === 'nvme0n1')
    const stick = disks.find((d) => d.name === 'sdb')
    expect(internal?.system).toBe(true)
    expect(internal?.removable).toBe(false)
    expect(stick?.system).toBe(false)
    expect(stick?.removable).toBe(true)
    expect(usbCandidates(disks).map((d) => d.path)).toEqual(['/dev/sdb'])
  })
})
