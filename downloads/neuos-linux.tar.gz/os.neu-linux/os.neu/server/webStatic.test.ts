import { mkdirSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { describe, expect, it } from 'vitest'
import { injectUiTokenHtml, resolveWebFile } from './webStatic.ts'

describe('packaged web static (WS-1)', () => {
  it('serves index.html for / and rejects path traversal', () => {
    const root = path.join(os.tmpdir(), `osneu-webstatic-${process.pid}`)
    mkdirSync(root, { recursive: true })
    writeFileSync(path.join(root, 'index.html'), '<!doctype html><title>os.neu v1.0</title>')
    writeFileSync(path.join(root, 'app.js'), 'ok')

    expect(resolveWebFile(root, '/')).toBe(path.join(root, 'index.html'))
    expect(resolveWebFile(root, '/app.js')).toBe(path.join(root, 'app.js'))
    expect(resolveWebFile(root, '/missing')).toBe(path.join(root, 'index.html'))
    expect(resolveWebFile(root, '/../etc/passwd')).toBeNull()
  })

  it('injects the UI token meta into index.html', () => {
    const html = injectUiTokenHtml('<!doctype html><html><head></head><body></body></html>', 'tok_unit-test')
    expect(html.includes('name="osneu-ui-token"')).toBe(true)
    expect(html.includes('content="tok_unit-test"')).toBe(true)
  })
})
