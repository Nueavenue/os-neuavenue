import dns from 'node:dns'

dns.setDefaultResultOrder('ipv4first')

const MAX_BYTES = 8_000_000
const TIMEOUT_MS = 12_000

function isHttpUrl(raw: string): URL | null {
  try {
    const url = new URL(raw)
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null
    return url
  } catch {
    return null
  }
}

export async function fetchPage(target: string): Promise<{
  ok: boolean
  status: number
  contentType: string
  body: Buffer
  finalUrl: string
  reason?: string
}> {
  const url = isHttpUrl(target)
  if (!url) {
    return {
      ok: false,
      status: 400,
      contentType: 'text/plain; charset=utf-8',
      body: Buffer.from('Only http(s) addresses can be opened.'),
      finalUrl: target,
      reason: 'bad-url',
    }
  }

  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS)
  try {
    const res = await fetch(url, {
      redirect: 'follow',
      signal: ctrl.signal,
      headers: {
        'user-agent':
          'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 neuOS/0.1',
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      },
    })
    const buf = Buffer.from(await res.arrayBuffer())
    if (buf.length > MAX_BYTES) {
      return {
        ok: false,
        status: 413,
        contentType: 'text/plain; charset=utf-8',
        body: Buffer.from('That page is too large.'),
        finalUrl: res.url,
        reason: 'too-large',
      }
    }
    const contentType = res.headers.get('content-type') ?? 'text/html; charset=utf-8'
    let body = buf
    if (contentType.includes('text/html')) {
      let html = buf.toString('utf8')
      const base = `<base href="${escapeAttr(res.url)}">`
      if (/<head[^>]*>/i.test(html)) {
        html = html.replace(/<head[^>]*>/i, (m) => `${m}\n${base}`)
      } else {
        html = `${base}\n${html}`
      }
      body = Buffer.from(html, 'utf8')
    }
    return {
      ok: res.ok,
      status: res.status,
      contentType,
      body,
      finalUrl: res.url,
    }
  } catch (err) {
    const reason = err instanceof Error ? err.message : 'fetch-failed'
    return {
      ok: false,
      status: 502,
      contentType: 'text/html; charset=utf-8',
      body: Buffer.from(errorPage(target, reason)),
      finalUrl: target,
      reason,
    }
  } finally {
    clearTimeout(timer)
  }
}

function escapeAttr(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')
}

function escapeHtml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function errorPage(url: string, reason: string): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>OS.neu v1.0</title>
<style>body{font-family:sans-serif;background:#0b0c0a;color:#f4efe6;padding:48px}</style>
</head><body><h1>That address could not be opened</h1>
<p>${escapeHtml(url)}</p><p>${escapeHtml(reason)}</p></body></html>`
}
