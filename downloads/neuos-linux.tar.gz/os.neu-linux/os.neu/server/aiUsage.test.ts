import { mkdtemp, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { describe, expect, it } from 'vitest'
import { createAiUsageGate, parseAiDailyLimit } from './aiUsage.ts'

describe('bridge AI usage gate', () => {
  it('defaults the daily limit and accepts zero as unlimited', () => {
    expect(parseAiDailyLimit(undefined)).toBe(200)
    expect(parseAiDailyLimit('0')).toBe(0)
    expect(parseAiDailyLimit('-3')).toBe(200)
  })

  it('allows up to the limit, then answers limited, and appends one line per call', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'osneu-ai-usage-'))
    const gate = createAiUsageGate({ dir, limit: 2, now: () => new Date(2026, 10, 5, 11) })
    expect((await gate.consume('/api/office/assist')).allowed).toBe(true)
    expect((await gate.consume('/api/seat/write')).allowed).toBe(true)
    const limited = await gate.consume('/api/speak/chat')
    expect(limited.allowed).toBe(false)
    expect(limited.limit).toBe(2)
    const raw = await readFile(path.join(dir, 'ai-usage.jsonl'), 'utf8')
    expect(raw.split('\n').filter(Boolean)).toHaveLength(3)
    expect(raw.includes('prompt')).toBe(false)
    expect(raw.includes('sk-')).toBe(false)
    expect(raw.includes('"result":"limited"')).toBe(true)
  })
})
