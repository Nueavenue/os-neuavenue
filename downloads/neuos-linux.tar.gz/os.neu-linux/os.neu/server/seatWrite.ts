import {
  completeText,
  isSmallLocal,
  llmReady,
  LOCAL_MODEL,
  ollamaStatus,
  ollamaTag,
  streamChatLocal,
  wantsLocalModel,
} from '../boot/localLlm.mjs'
import { isRepeatingDraft } from '../src/engine/draftText.ts'
import { officeSurface } from '../src/engine/intents.ts'
import { SEAT_PREDICT } from '../src/engine/seatRun.ts'
import { buildOfficeMessages } from './office.ts'

const SYSTEM = [
  'Write the full answer in the same language as the user sentence.',
  'If the user wrote Korean Hangul, write only Hangul Korean. Do not mix English, Vietnamese, or romanized Korean.',
  'There is no line cap. Write a full answer — several short paragraphs, not one sentence.',
  'Do not repeat a heading, bullet, or paragraph.',
  'Do not write [Insert Date] or [Insert Amount].',
  'If a number, date, or name is not in the user sentence or the search notes, write "확인 필요" instead of inventing it.',
  'If search notes are present, use them. Do not claim you opened a browser window.',
  'Do not send email, pay, or publish.',
].join(' ')

export async function* seatWriteStream(
  model: string,
  instruction: string,
  app?: 'doc' | 'sheet' | 'slides' | null,
) {
  const ready = await llmReady()
  if (!ready.ok) throw new Error('no-llm')
  const text = instruction.trim()
  if (!text) throw new Error('empty')
  const surface = app || officeSurface(text)
  const messages =
    surface === 'sheet' || surface === 'doc' || surface === 'slides'
      ? buildOfficeMessages({ model, app: surface, instruction: text }).messages
      : [
          { role: 'system' as const, content: SYSTEM },
          { role: 'user' as const, content: text },
        ]
  const local = wantsLocalModel(model) || model === 'os.neu-local'
  if (local) {
    const status = await ollamaStatus()
    if (!status.ok) throw new Error('local-unavailable')
    const requested = ollamaTag(model) || LOCAL_MODEL
    const has = status.models.includes(requested) || (requested === LOCAL_MODEL && status.hasDefault)
    if (!has) throw new Error(`model-not-installed:${requested}`)
    const predict = isSmallLocal(requested) ? SEAT_PREDICT.small : SEAT_PREDICT.large
    for await (const chunk of streamChatLocal(messages, requested, {
      num_predict: predict,
      temperature: 0.6,
      repeat_penalty: 1.25,
      repeat_last_n: 256,
    })) {
      const full = String(chunk.full || '')
      const stop = isRepeatingDraft(full)
      yield { full, done: Boolean(chunk.done) || stop }
      if (stop) return
    }
    return
  }
  const result = await completeText({ model, messages })
  yield { full: String(result.text || ''), done: true }
}
