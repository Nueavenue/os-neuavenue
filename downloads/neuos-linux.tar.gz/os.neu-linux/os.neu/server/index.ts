import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { execFile } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { promisify } from 'node:util'
import { fetchPage } from './browse.ts'
import { askJeos, probeBootHealth, readBootHealth } from './boot.ts'
import { act, detectBackend } from './driver.ts'
import { buildInstallerPack, buildLinuxScreenPack, isoPath, linuxPackPath, sendFile } from './download.ts'
import { detectHost, hardwareSnapshot, parseAppIntent, planApp, searchCatalog } from '../boot/hostProfile.mjs'
import {
  defaultPlantDir,
  ensureOsNeuFolder,
  launchScreen,
  listPlantDir,
  plantStatus,
  runPlant,
} from '../boot/plant.mjs'
import { llmPullStatus, llmReady, ollamaInstallHint, pullPublicModel, writeLlmSettings } from '../boot/localLlm.mjs'
import { appendMonitor, readMonitor, readPreference } from './monitor.ts'
import { loadLocalEnv } from './env.ts'
import { coachChat, speakReady, transcribeUtterance } from './speak.ts'
import {
  isAdminEmail,
  listAccounts,
  loginAccount,
  logoutToken,
  registerAccount,
  userFromToken,
} from './auth.ts'
import { addFeedback, adminStats, appendTrack, listFeedback, type TrackEvent } from './analytics.ts'
import { officeAssist, officeReady } from './office.ts'
import { saveBrowseLedger, readBrowseLedger } from './browseLedger.ts'
import { supabaseEnabled } from './supabase.ts'
import { burnCommand, listBlockDisks, usbCandidates } from './usb.ts'
import { infer, listSamples, saveSample } from './vlm.ts'

const execFileAsync = promisify(execFile)
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
loadLocalEnv(ROOT)

const PORT = Number(process.env.NEUOS_BRIDGE_PORT ?? 4178)

function json(res: ServerResponse, status: number, body: unknown) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

async function readRaw(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  return Buffer.concat(chunks)
}

async function readBody(req: IncomingMessage): Promise<string> {
  return (await readRaw(req)).toString('utf8')
}

export async function route(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const host = req.headers.host ?? '127.0.0.1'
  const url = new URL(req.url ?? '/', `http://${host}`)
  res.setHeader('access-control-allow-origin', '*')
  res.setHeader('access-control-allow-headers', 'content-type, x-osneu-token')
  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }

  if (url.pathname === '/api/health' && req.method === 'GET') {
    const driver = await detectBackend()
    json(res, 200, {
      ok: true,
      driver: driver.backend,
      live: driver.live,
      vlm: process.env.NEUOS_VLM_URL ? 'remote' : 'graph',
      browse: process.env.NEUOS_ELECTRON === '1' ? 'electron' : 'proxy',
      supabase: supabaseEnabled(),
      speak: speakReady() ? 'openai' : 'off',
      llm: (await llmReady()).via,
      display: process.env.DISPLAY,
      detail: driver.detail,
      samples: await listSamples(),
    })
    return
  }

  if (url.pathname === '/api/demo' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'x-frame-options': 'DENY' })
    res.end(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>OS.neu v1.0 demo</title></head>
<body style="font-family:sans-serif;padding:40px;background:#fff;color:#111">
<h1>NEUOS_BROWSER_OK</h1>
<p>The address-bar proxy passed an iframe block.</p>
</body></html>`)
    return
  }

  if (url.pathname === '/api/browse' && req.method === 'GET') {
    const target = url.searchParams.get('url') ?? ''
    const page = await fetchPage(target)
    res.writeHead(page.status, {
      'content-type': page.contentType,
      'x-frame-options': 'SAMEORIGIN',
      'content-security-policy': "frame-ancestors 'self'",
      'cache-control': 'no-store',
      'x-neuos-final-url': page.finalUrl,
    })
    res.end(page.body)
    return
  }

  if (url.pathname === '/api/driver/act' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const result = await act(payload)
    json(res, result.ok ? 200 : 400, result)
    return
  }

  if (url.pathname === '/api/vlm/infer' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const result = await infer(payload)
    json(res, 200, result)
    return
  }

  if (url.pathname === '/api/vlm/sample' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const saved = await saveSample(payload)
    json(res, 200, { ok: true, ...saved })
    return
  }

  if (url.pathname === '/api/speak/status' && req.method === 'GET') {
    json(res, 200, { ok: true, ready: speakReady() })
    return
  }

  if (url.pathname === '/api/speak/chat' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      message?: string
      history?: Array<{ role?: string; content?: string }>
      audio?: boolean
    }
    try {
      const history = (payload.history ?? [])
        .filter((turn) => turn.role === 'user' || turn.role === 'assistant')
        .map((turn) => ({ role: turn.role as 'user' | 'assistant', content: String(turn.content ?? '') }))
      const result = await coachChat(String(payload.message ?? ''), history, {
        audio: payload.audio === true,
      })
      json(res, 200, { ok: true, ...result })
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'coach-error'
      json(res, reason === 'openai-unconfigured' ? 503 : 502, { ok: false, reason: 'coach-unavailable' })
    }
    return
  }

  if (url.pathname === '/api/speak/asr' && req.method === 'POST') {
    const type = String(req.headers['content-type'] ?? 'audio/webm')
    const buf = await readRaw(req)
    try {
      const transcript = await transcribeUtterance(buf, type)
      json(res, transcript ? 200 : 422, { ok: Boolean(transcript), transcript, reason: transcript ? undefined : 'empty-transcript' })
    } catch {
      json(res, 502, { ok: false, reason: 'asr-unavailable' })
    }
    return
  }

  if (url.pathname === '/api/boot-health' && req.method === 'GET') {
    const refresh = url.searchParams.get('refresh') === '1'
    const health = refresh ? await probeBootHealth() : await readBootHealth()
    json(res, 200, health)
    return
  }

  if (url.pathname === '/api/jeos/ask' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { text?: string }
    const result = await askJeos(String(payload.text ?? ''))
    if (result.act === 'app' && result.plan) {
      const plan = result.plan
      await appendMonitor({
        t: Date.now(),
        source: 'prompt',
        kind: plan.kind === 'remove' ? 'remove' : 'install',
        app: plan.app,
        hostOs: plan.host?.pretty,
        pkg: plan.host?.pkg,
        remembered: 'prompt',
        note: plan.command,
      })
    }
    json(res, 200, result)
    return
  }

  if (url.pathname === '/api/usb/disks' && req.method === 'GET') {
    const disks = await listBlockDisks()
    json(res, 200, {
      ok: true,
      disks,
      usb: usbCandidates(disks),
      iso: 'dist/neuos-live.iso',
      command: 'bash scripts/make-usb.sh',
    })
    return
  }

  if (url.pathname === '/api/usb/plan' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { device?: string }
    const device = String(payload.device ?? '')
    if (!device.startsWith('/dev/')) {
      json(res, 400, { ok: false, reason: 'device path required' })
      return
    }
    json(res, 200, {
      ok: true,
      device,
      command: burnCommand(device),
      allow: process.env.NEUOS_USB_ALLOW === '1',
    })
    return
  }

  if (url.pathname === '/api/launchers' && req.method === 'GET') {
    const home = process.env.HOME || ''
    json(res, 200, {
      ok: true,
      apps: existsSync(path.join(home, '.local/share/applications/neuos.desktop')),
      desktop: existsSync(path.join(home, 'Desktop/neuos.desktop')),
      autostart: existsSync(path.join(home, '.config/autostart/neuos.desktop')),
    })
    return
  }

  if (url.pathname === '/api/install/host' && req.method === 'POST') {
    const script = path.join(ROOT, 'scripts', 'install-autostart.sh')
    const { stdout, stderr } = await execFileAsync('bash', [script], { timeout: 20_000 })
    json(res, 200, { ok: true, stdout, stderr })
    return
  }

  if (url.pathname === '/api/uninstall/status' && req.method === 'GET') {
    const home = process.env.HOME || ''
    const autostart = existsSync(path.join(home, '.config/autostart/neuos.desktop'))
    const unit = existsSync(path.join(home, '.config/systemd/user/neuos.service'))
    const planted = existsSync(path.join(home, 'os.neu'))
    json(res, 200, { ok: true, autostart, unit, planted, forced: autostart || unit })
    return
  }

  if (url.pathname === '/api/uninstall' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { files?: boolean }
    const script = path.join(ROOT, 'scripts', 'uninstall-autostart.sh')
    const args = payload.files ? [script, '--files'] : [script]
    const { stdout, stderr } = await execFileAsync('bash', args, { timeout: 20_000 })
    await appendMonitor({
      t: Date.now(),
      source: 'wizard',
      kind: 'remove',
      app: 'os.neu',
      note: payload.files ? 'uninstall-autostart+files' : 'uninstall-autostart',
    })
    json(res, 200, { ok: true, stdout, stderr, files: Boolean(payload.files) })
    return
  }

  if (url.pathname === '/api/plant/default' && req.method === 'GET') {
    json(res, 200, { ok: true, dest: defaultPlantDir() })
    return
  }

  if (url.pathname === '/api/plant/list' && req.method === 'GET') {
    const dir = url.searchParams.get('dir') || defaultPlantDir()
    json(res, 200, await listPlantDir(dir))
    return
  }

  if (url.pathname === '/api/plant/mkdir' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dir?: string }
    const dest = ensureOsNeuFolder(payload.dir || defaultPlantDir())
    const { mkdir } = await import('node:fs/promises')
    await mkdir(dest, { recursive: true })
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/plant/start' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string }
    const dest = payload.dest || defaultPlantDir()
    void runPlant(ROOT, dest).catch(() => undefined)
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/plant/status' && req.method === 'GET') {
    json(res, 200, { ok: true, ...plantStatus() })
    return
  }

  if (url.pathname === '/api/plant/launch' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string; go?: string }
    const dest = payload.dest || plantStatus().dest || defaultPlantDir()
    json(res, 200, launchScreen(dest, payload.go || 'lui'))
    return
  }

  if ((url.pathname === '/api/guide' || url.pathname === '/guide') && req.method === 'GET') {
    const file = path.join(ROOT, 'boot/guide-ui.html')
    if (existsSync(file)) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
      res.end(await readFile(file, 'utf8'))
      return
    }
  }

  if ((url.pathname === '/api/guide.md' || url.pathname === '/guide.md') && req.method === 'GET') {
    const file = path.join(ROOT, 'docs/student-usb-guide.md')
    res.writeHead(200, { 'content-type': 'text/markdown; charset=utf-8' })
    res.end(existsSync(file) ? await readFile(file, 'utf8') : '# os.neu\n')
    return
  }

  if (url.pathname === '/api/catalog' && req.method === 'GET') {
    json(res, 200, { ok: true, apps: searchCatalog(url.searchParams.get('q') || '', detectHost()) })
    return
  }

  if (url.pathname === '/api/llm/settings' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string; openaiKey?: string }
    const dest = payload.dest || plantStatus().dest || ROOT
    const next = writeLlmSettings({ openaiKey: String(payload.openaiKey || '').trim() }, existsSync(dest) ? dest : ROOT)
    json(res, 200, { ok: true, dest, hasKey: Boolean(next.openaiKey) })
    return
  }

  if (url.pathname === '/api/llm/pull' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string }
    const dest = payload.dest || plantStatus().dest || ROOT
    void pullPublicModel(existsSync(dest) ? dest : ROOT).catch(() => undefined)
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/llm/status' && req.method === 'GET') {
    const st = llmPullStatus()
    json(res, 200, {
      ok: true,
      ...st,
      ...(st.error === 'ollama-missing' ? ollamaInstallHint() : {}),
    })
    return
  }

  if (url.pathname === '/api/llm/ready' && req.method === 'GET') {
    json(res, 200, await llmReady())
    return
  }

  if (url.pathname === '/api/host-profile' && req.method === 'GET') {
    json(res, 200, { ok: true, ...hardwareSnapshot() })
    return
  }

  if (url.pathname === '/api/apps/plan' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { text?: string; source?: 'prompt' | 'lui' | 'wizard' }
    const intent = parseAppIntent(String(payload.text ?? ''))
    if (!intent) {
      json(res, 400, { ok: false, reason: 'not-an-app-intent' })
      return
    }
    const host = detectHost()
    const plan = planApp(host, intent)
    const source = payload.source === 'prompt' || payload.source === 'wizard' ? payload.source : 'lui'
    await appendMonitor({
      t: Date.now(),
      source,
      kind: intent.kind,
      app: intent.app,
      hostOs: host.pretty,
      pkg: host.pkg,
      remembered: source === 'prompt' ? 'prompt' : 'neuos',
      note: plan.command,
    })
    json(res, 200, { ok: true, plan, preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/monitor' && req.method === 'GET') {
    json(res, 200, { ok: true, events: await readMonitor(), preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/monitor' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      source?: 'prompt' | 'lui' | 'wizard'
      kind?: 'install' | 'remove' | 'choice' | 'start'
      app?: string
      note?: string
    }
    const host = detectHost()
    const events = await appendMonitor({
      t: Date.now(),
      source: payload.source ?? 'wizard',
      kind: payload.kind ?? 'start',
      app: payload.app,
      hostOs: host.pretty,
      pkg: host.pkg,
      note: payload.note,
    })
    json(res, 200, { ok: true, events, preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/install/run' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      mode?: 'host' | 'usb'
      device?: string
      test?: boolean
    }
    const test = payload.test !== false
    const host = detectHost()
    const steps: string[] = [`host ${host.pretty} ${host.pkg}`]
    if (payload.mode === 'host') {
      const script = path.join(ROOT, 'scripts', 'install-autostart.sh')
      const { stdout } = await execFileAsync('bash', [script], { timeout: 20_000 })
      steps.push(stdout.trim() || 'autostart written')
      await appendMonitor({
        t: Date.now(),
        source: 'wizard',
        kind: 'choice',
        hostOs: host.pretty,
        note: 'plant-host',
      })
      json(res, 200, { ok: true, percent: 100, test, steps, wiped: false, host })
      return
    }
    if (payload.mode === 'usb') {
      const args = test ? ['scripts/make-usb.sh', '--test'] : ['scripts/make-usb.sh']
      if (!test && payload.device) {
        json(res, 200, {
          ok: true,
          percent: 40,
          test: false,
          steps: [...steps, 'live burn is sudo-only'],
          command: burnCommand(String(payload.device)),
          wiped: false,
          host,
        })
        return
      }
      const { stdout } = await execFileAsync('bash', args, { timeout: 120_000, cwd: ROOT })
      steps.push(stdout.trim().slice(-400) || 'usb staged')
      await appendMonitor({
        t: Date.now(),
        source: 'wizard',
        kind: 'choice',
        hostOs: host.pretty,
        note: test ? 'usb-test' : 'usb-iso',
      })
      json(res, 200, {
        ok: true,
        percent: 100,
        test: true,
        steps,
        wiped: false,
        host,
        command: payload.device ? burnCommand(payload.device) : 'bash scripts/make-usb.sh',
      })
      return
    }
    json(res, 400, { ok: false, reason: 'mode host|usb' })
    return
  }

  if (url.pathname === '/api/download/pack' && req.method === 'GET') {
    const file = await buildInstallerPack()
    sendFile(res, file, 'neuos-boot-kit.tar.gz', 'application/gzip')
    return
  }

  if ((url.pathname === '/api/download/linux' || url.pathname === '/downloads/neuos-linux.tar.gz') && req.method === 'GET') {
    const existing = linuxPackPath()
    const file = existing || (await buildLinuxScreenPack())
    sendFile(res, file, 'neuos-linux.tar.gz', 'application/gzip')
    return
  }

  if (url.pathname === '/api/download/iso' && req.method === 'GET') {
    const file = isoPath()
    if (!file) {
      json(res, 404, { ok: false, reason: 'run npm run usb first', pack: '/api/download/pack' })
      return
    }
    sendFile(res, file, 'neuos-live.iso', 'application/octet-stream')
    return
  }

  const token = String(req.headers['x-osneu-token'] ?? '')
  const authed = token ? await userFromToken(token) : null

  if (url.pathname === '/api/auth/register' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { name?: string; email?: string; password?: string }
    try {
      const result = await registerAccount(String(payload.name ?? ''), String(payload.email ?? ''), String(payload.password ?? ''))
      json(res, 200, { ok: true, ...result })
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'register-error'
      json(res, reason === 'email-taken' ? 409 : 400, { ok: false, reason })
    }
    return
  }

  if (url.pathname === '/api/auth/login' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { email?: string; password?: string }
    try {
      const result = await loginAccount(String(payload.email ?? ''), String(payload.password ?? ''))
      json(res, 200, { ok: true, ...result })
    } catch {
      json(res, 401, { ok: false, reason: 'bad-credentials' })
    }
    return
  }

  if (url.pathname === '/api/auth/logout' && req.method === 'POST') {
    if (token) await logoutToken(token)
    json(res, 200, { ok: true })
    return
  }

  if (url.pathname === '/api/auth/me' && req.method === 'GET') {
    json(res, 200, { ok: true, user: authed })
    return
  }

  if (url.pathname === '/api/track' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      session?: string
      kind?: TrackEvent['kind']
      screen?: string
      label?: string
    }
    const event = await appendTrack({
      t: Date.now(),
      session: String(payload.session || 'anon'),
      email: authed?.email,
      kind: payload.kind === 'click' || payload.kind === 'login' || payload.kind === 'logout' || payload.kind === 'open-app' || payload.kind === 'feedback' ? payload.kind : 'view',
      screen: String(payload.screen || 'unknown'),
      label: payload.label,
    })
    json(res, 200, { ok: true, event })
    return
  }

  if (url.pathname === '/api/feedback' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { title?: string; body?: string }
    try {
      const post = await addFeedback({
        email: authed?.email,
        name: authed?.name,
        title: String(payload.title ?? ''),
        body: String(payload.body ?? ''),
      })
      await appendTrack({
        t: Date.now(),
        session: 'feedback',
        email: authed?.email,
        kind: 'feedback',
        screen: 'feedback',
        label: post.title,
      })
      json(res, 200, { ok: true, post, cloud: Boolean(post.cloud) })
    } catch {
      json(res, 400, { ok: false, reason: 'empty-feedback' })
    }
    return
  }

  if (url.pathname === '/api/feedback' && req.method === 'GET') {
    json(res, 200, { ok: true, posts: await listFeedback() })
    return
  }

  if (url.pathname === '/api/browse/ledger' && req.method === 'POST') {
    if (!authed?.email) {
      json(res, 401, { ok: false, reason: 'sign-in' })
      return
    }
    const payload = JSON.parse(await readBody(req) || '{}')
    const saved = await saveBrowseLedger(authed.email, payload)
    json(res, 200, { ok: true, saved: Boolean(saved) })
    return
  }

  if (url.pathname === '/api/browse/ledger' && req.method === 'GET') {
    if (!authed?.email) {
      json(res, 401, { ok: false, reason: 'sign-in' })
      return
    }
    json(res, 200, { ok: true, row: await readBrowseLedger(authed.email) })
    return
  }

  if (url.pathname === '/api/office/assist' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      model?: string
      app?: 'sheet' | 'doc' | 'slides'
      instruction?: string
      content?: string
    }
    if (!(await officeReady())) {
      json(res, 503, { ok: false, reason: 'no-llm' })
      return
    }
    const app = payload.app === 'doc' || payload.app === 'slides' ? payload.app : 'sheet'
    try {
      const result = await officeAssist({
        model: payload.model,
        app,
        instruction: String(payload.instruction ?? ''),
        content: payload.content,
      })
      json(res, 200, result)
    } catch (err) {
      json(res, 502, { ok: false, reason: err instanceof Error ? err.message : 'assist-error' })
    }
    return
  }

  if (url.pathname === '/api/admin/stats' && req.method === 'GET') {
    if (!authed || !isAdminEmail(authed.email)) {
      json(res, 403, { ok: false, reason: 'admin-only' })
      return
    }
    const stats = await adminStats()
    json(res, 200, { ...stats, accounts: await listAccounts() })
    return
  }

  json(res, 404, { ok: false, reason: 'not-found' })
}

const server = createServer((req, res) => {
  void route(req, res).catch((err: unknown) => {
    json(res, 500, { ok: false, reason: err instanceof Error ? err.message : 'bridge-error' })
  })
})

server.listen(PORT, '127.0.0.1', () => {
      process.stdout.write(`os.neu v1.0 bridge http://127.0.0.1:${PORT}\n`)
})
