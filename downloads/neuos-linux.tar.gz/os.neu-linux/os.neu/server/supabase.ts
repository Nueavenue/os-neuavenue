export type CloudUser = {
  name: string
  email: string
  admin: boolean
}

export type CloudSession = {
  token: string
  user: CloudUser
  needsConfirm?: boolean
}

function isAdminMailbox(email: string) {
  const neat = email.trim().toLowerCase()
  return neat === 'billylee96312@gmail.com' || neat === 'billylee96312@gmailcom'
}

type AuthUserJson = {
  id?: string
  email?: string
  user_metadata?: { name?: string; full_name?: string }
}

function config() {
  const url = String(process.env.PUBLIC_SUPABASE_URL || '')
    .trim()
    .replace(/\/$/, '')
  const anon = String(process.env.PUBLIC_SUPABASE_ANON_KEY || '').trim()
  if (!url || !anon) return null
  return { url, anon }
}

export function supabaseEnabled() {
  return Boolean(config())
}

function publicUser(row: AuthUserJson): CloudUser | null {
  const email = String(row.email || '').trim().toLowerCase()
  if (!email) return null
  const meta = row.user_metadata || {}
  const name = String(meta.name || meta.full_name || email.split('@')[0] || 'os.neu').trim()
  return { name, email, admin: isAdminMailbox(email) }
}

async function gotrue(path: string, init: RequestInit = {}) {
  const cfg = config()
  if (!cfg) return null
  const headers = new Headers(init.headers)
  headers.set('apikey', cfg.anon)
  if (!headers.has('authorization')) headers.set('authorization', `Bearer ${cfg.anon}`)
  if (init.body && !headers.has('content-type')) headers.set('content-type', 'application/json')
  const res = await fetch(`${cfg.url}${path}`, { ...init, headers })
  const text = await res.text()
  let body: Record<string, unknown> = {}
  if (text) {
    try {
      body = JSON.parse(text) as Record<string, unknown>
    } catch {
      body = { msg: text }
    }
  }
  return { ok: res.ok, status: res.status, body }
}

function authError(body: Record<string, unknown>, status: number, fallback: string) {
  const msg = String(body.error_description || body.msg || body.error || body.message || body.code || fallback).toLowerCase()
  if (msg.includes('already') || msg.includes('registered') || msg.includes('exists')) return 'email-taken'
  if (msg.includes('password') && (msg.includes('6') || msg.includes('least') || msg.includes('weak') || status === 422)) {
    if (msg.includes('already') || msg.includes('registered')) return 'email-taken'
    return 'weak-password'
  }
  if (msg.includes('invalid login') || msg.includes('invalid_grant') || msg.includes('credentials')) return 'bad-credentials'
  if (msg.includes('email')) return 'invalid-account'
  if (status === 422) return 'email-taken'
  return fallback
}

function sessionFrom(body: Record<string, unknown>): CloudSession | null {
  const token = String(body.access_token || '')
  const rawUser = (body.user || body) as AuthUserJson
  const user = publicUser(rawUser)
  if (token && user) return { token, user }
  if (user && !token) return { token: '', user, needsConfirm: true }
  return null
}

export async function supabaseSignUp(name: string, email: string, password: string): Promise<CloudSession | null> {
  const res = await gotrue('/auth/v1/signup', {
    method: 'POST',
    body: JSON.stringify({
      email,
      password,
      data: { name, full_name: name },
    }),
  })
  if (!res) return null
  if (!res.ok) throw new Error(authError(res.body, res.status, 'invalid-account'))
  return sessionFrom(res.body)
}

export async function supabaseSignIn(email: string, password: string): Promise<CloudSession | null> {
  const res = await gotrue('/auth/v1/token?grant_type=password', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  })
  if (!res) return null
  if (!res.ok) throw new Error(authError(res.body, res.status, 'bad-credentials'))
  const session = sessionFrom(res.body)
  if (!session?.token) throw new Error('bad-credentials')
  return session
}

export async function supabaseUser(token: string): Promise<CloudUser | null> {
  if (!token || token.split('.').length !== 3) return null
  const cfg = config()
  if (!cfg) return null
  const res = await gotrue('/auth/v1/user', {
    headers: { authorization: `Bearer ${token}` },
  })
  if (!res?.ok) return null
  return publicUser(res.body as AuthUserJson)
}

export async function supabaseSignOut(token: string) {
  if (!token || token.split('.').length !== 3) return
  await gotrue('/auth/v1/logout', {
    method: 'POST',
    headers: { authorization: `Bearer ${token}` },
  })
}

const TABLES = ['os_neu_feedback', 'feedback']

export type CloudFeedback = {
  id: string
  t: number
  name?: string
  email?: string
  title: string
  body: string
}

async function rest(path: string, init: RequestInit = {}) {
  const cfg = config()
  if (!cfg) return null
  const headers = new Headers(init.headers)
  headers.set('apikey', cfg.anon)
  headers.set('authorization', `Bearer ${cfg.anon}`)
  if (init.body && !headers.has('content-type')) headers.set('content-type', 'application/json')
  const res = await fetch(`${cfg.url}/rest/v1/${path}`, { ...init, headers })
  const text = await res.text()
  let body: unknown = text
  if (text) {
    try {
      body = JSON.parse(text)
    } catch {
      body = { message: text }
    }
  }
  return { ok: res.ok, status: res.status, body }
}

function mapRow(row: Record<string, unknown>): CloudFeedback | null {
  const title = String(row.title || '').trim()
  const body = String(row.body || row.message || '').trim()
  if (!title && !body) return null
  const created = row.created_at || row.t
  const t =
    typeof created === 'number'
      ? created
      : created
        ? Date.parse(String(created))
        : Date.now()
  return {
    id: String(row.id || `fb-${t}`),
    t: Number.isFinite(t) ? t : Date.now(),
    name: row.name ? String(row.name) : undefined,
    email: row.email ? String(row.email) : undefined,
    title: title || body.slice(0, 48),
    body: body || title,
  }
}

export async function supabaseAddFeedback(post: {
  name?: string
  email?: string
  title: string
  body: string
}): Promise<CloudFeedback | null> {
  const payload = {
    name: post.name || null,
    email: post.email || null,
    title: post.title,
    body: post.body,
  }
  for (const table of TABLES) {
    const res = await rest(`${table}`, {
      method: 'POST',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(payload),
    })
    if (!res) return null
    if (res.status === 404 || res.status === 300) continue
    if (!res.ok) continue
    const row = Array.isArray(res.body) ? res.body[0] : res.body
    if (row && typeof row === 'object') return mapRow(row as Record<string, unknown>)
    return {
      id: `fb-${Date.now()}`,
      t: Date.now(),
      name: post.name,
      email: post.email,
      title: post.title,
      body: post.body,
    }
  }
  return null
}

export async function supabaseListFeedback(): Promise<CloudFeedback[]> {
  for (const table of TABLES) {
    const res = await rest(`${table}?select=*&order=created_at.desc`)
    if (!res) return []
    if (res.status === 404) continue
    if (!res.ok || !Array.isArray(res.body)) continue
    return res.body
      .map((row) => (row && typeof row === 'object' ? mapRow(row as Record<string, unknown>) : null))
      .filter((row): row is CloudFeedback => Boolean(row))
  }
  return []
}
