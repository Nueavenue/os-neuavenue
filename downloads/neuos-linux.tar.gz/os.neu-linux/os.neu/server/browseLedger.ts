import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const FILE = path.join(ROOT, 'data', 'browse-ledger.json')

type Store = Record<string, unknown>

async function load(): Promise<Store> {
  try {
    return JSON.parse(await readFile(FILE, 'utf8')) as Store
  } catch {
    return {}
  }
}

async function save(store: Store) {
  await mkdir(path.dirname(FILE), { recursive: true })
  await writeFile(FILE, JSON.stringify(store, null, 2))
}

export async function saveBrowseLedger(email: string, ledger: unknown) {
  const neat = email.trim().toLowerCase()
  if (!neat) return null
  const store = await load()
  store[neat] = { t: Date.now(), ledger }
  await save(store)
  return store[neat]
}

export async function readBrowseLedger(email: string) {
  const store = await load()
  return store[email.trim().toLowerCase()] ?? null
}
