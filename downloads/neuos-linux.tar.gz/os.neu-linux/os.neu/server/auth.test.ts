import { describe, expect, it } from 'vitest'
import { isAdminEmail } from './auth.ts'

describe('admin email', () => {
  it('only treats the configured mailbox as admin', () => {
    expect(isAdminEmail('billylee96312@gmail.com')).toBe(true)
    expect(isAdminEmail('BillyLee96312@gmail.com')).toBe(true)
    expect(isAdminEmail('someone@gmail.com')).toBe(false)
  })
})
