import { spawn } from 'node:child_process'
import { mkdir } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { craftSandboxRoot, isAllowedCraftCli } from '../src/engine/craftConvert.ts'
import { craftMcpArgv, craftMcpCliPath } from '../src/engine/craftMcp.ts'
import { detectCraftBinsOnHost } from './craftDetectHttp.ts'

const PING_MS = 8_000

function reply(
  res: ServerResponse,
  body: { mcp: boolean; reason?: string; tools?: number },
) {
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify({ ok: true, ...body }))
}

async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  const raw = Buffer.concat(chunks).toString('utf8')
  if (!raw.trim()) return {}
  try {
    const parsed = JSON.parse(raw) as unknown
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : {}
  } catch {
    return {}
  }
}

function frame(msg: object) {
  const body = JSON.stringify(msg)
  return `Content-Length: ${Buffer.byteLength(body, 'utf8')}\r\n\r\n${body}`
}

function parseMcpMessages(buf: string) {
  const messages: Array<Record<string, unknown>> = []
  let rest = buf
  while (rest.length) {
    const match = rest.match(/Content-Length:\s*(\d+)\r?\n\r?\n/)
    if (!match || match.index == null) break
    const len = Number(match[1])
    const start = match.index + match[0].length
    const json = rest.slice(start, start + len)
    try {
      const parsed = JSON.parse(json) as unknown
      if (parsed && typeof parsed === 'object') messages.push(parsed as Record<string, unknown>)
    } catch {
      /* ignore partial */
    }
    rest = rest.slice(start + len)
  }
  if (!messages.length) {
    for (const line of buf.split(/\r?\n/)) {
      const text = line.trim()
      if (!text.startsWith('{')) continue
      try {
        const parsed = JSON.parse(text) as unknown
        if (parsed && typeof parsed === 'object') messages.push(parsed as Record<string, unknown>)
      } catch {
        /* ignore */
      }
    }
  }
  return messages
}

function toolsFromMessages(messages: Array<Record<string, unknown>>) {
  let initialize = false
  let tools = 0
  let listed = false
  for (const msg of messages) {
    if (msg.error) continue
    const result = msg.result && typeof msg.result === 'object' ? (msg.result as Record<string, unknown>) : null
    if (!result) continue
    if (Array.isArray(result.tools)) {
      listed = true
      tools = result.tools.length
    }
    if (result.protocolVersion || result.serverInfo || result.capabilities) initialize = true
  }
  return { initialize, listed, tools }
}

function pingMcpStdio(cliPath: string, argv: string[], cwd: string) {
  return new Promise<{ mcp: boolean; tools: number }>((resolve) => {
    let settled = false
    const finish = (mcp: boolean, tools = 0) => {
      if (settled) return
      settled = true
      try {
        child.kill('SIGTERM')
      } catch {
        /* already gone */
      }
      resolve({ mcp, tools })
    }
    const child = spawn(cliPath, argv, { cwd, shell: false, stdio: ['pipe', 'pipe', 'pipe'] })
    let stdout = ''
    const timer = setTimeout(() => finish(false), PING_MS)
    const consider = () => {
      const { initialize, listed, tools } = toolsFromMessages(parseMcpMessages(stdout))
      if (listed) {
        clearTimeout(timer)
        finish(true, tools)
      } else if (initialize && stdout.includes('tools/list')) {
        /* wait for list */
      }
    }
    child.stdout?.on('data', (chunk) => {
      stdout += String(chunk)
      const { initialize, listed, tools } = toolsFromMessages(parseMcpMessages(stdout))
      if (initialize && !listed) {
        try {
          child.stdin?.write(
            frame({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }),
          )
        } catch {
          /* stdin closed */
        }
      }
      if (listed) {
        clearTimeout(timer)
        finish(true, tools)
        return
      }
      consider()
    })
    child.on('error', () => {
      clearTimeout(timer)
      finish(false)
    })
    child.on('exit', () => {
      clearTimeout(timer)
      const { initialize, listed, tools } = toolsFromMessages(parseMcpMessages(stdout))
      finish(initialize || listed, listed ? tools : 0)
    })
    try {
      child.stdin?.write(
        frame({
          jsonrpc: '2.0',
          id: 1,
          method: 'initialize',
          params: {
            protocolVersion: '2024-11-05',
            capabilities: {},
            clientInfo: { name: 'os.neu', version: '1.0.0' },
          },
        }),
      )
    } catch {
      clearTimeout(timer)
      finish(false)
    }
  })
}

export async function handleCraftMcp(req: IncomingMessage, res: ServerResponse) {
  try {
    const payload = await readJson(req)
    if (payload.action !== 'ping') {
      reply(res, { mcp: false, reason: 'mcp-failed' })
      return
    }
    const bins = await detectCraftBinsOnHost()
    const cliPath = craftMcpCliPath(bins)
    if (!cliPath || !isAllowedCraftCli(cliPath)) {
      reply(res, { mcp: false, reason: 'cli-missing' })
      return
    }
    const sandbox = craftSandboxRoot(process.env)
    const argv = craftMcpArgv({ sandbox, readRoot: sandbox, writeRoot: sandbox })
    if (!argv) {
      reply(res, { mcp: false, reason: 'mcp-failed' })
      return
    }
    await mkdir(sandbox, { recursive: true })
    const result = await pingMcpStdio(cliPath, argv, sandbox)
    if (!result.mcp) {
      reply(res, { mcp: false, reason: 'mcp-failed' })
      return
    }
    reply(res, { mcp: true, tools: result.tools })
  } catch {
    reply(res, { mcp: false, reason: 'mcp-failed' })
  }
}
