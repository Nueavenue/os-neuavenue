import { describe, expect, it } from 'vitest'
import {
  allowedOrigins,
  createUiToken,
  guardBridgeRequest,
  hostAllowed,
  isAiSpendRoute,
  originAllowed,
  publicLlmSettingsView,
  requiresUiToken,
  uiTokenOk,
  vendorHasFromKeys,
} from './bridgeGuard.ts'

const PORT = 4178
const TOKEN = 'a'.repeat(43)

describe('bridgeGuard P0-①', () => {
  it('allows only loopback Host with the bridge port', () => {
    expect(hostAllowed('127.0.0.1:4178', PORT)).toBe(true)
    expect(hostAllowed('localhost:4178', PORT)).toBe(true)
    expect(hostAllowed('127.0.0.1', PORT)).toBe(false)
    expect(hostAllowed('evil.test:4178', PORT)).toBe(false)
    expect(hostAllowed(undefined, PORT)).toBe(false)
  })

  it('keeps the Vite and preview origins on the allow-list', () => {
    const origins = allowedOrigins(PORT)
    expect(origins).toContain('http://127.0.0.1:5173')
    expect(origins).toContain('http://localhost:5173')
    expect(origins).toContain('http://127.0.0.1:4177')
    expect(originAllowed('http://127.0.0.1:5173', PORT)).toBe(true)
    expect(originAllowed('https://example.com', PORT)).toBe(false)
  })

  it('requires the UI token on write / AI / install POSTs, not on health', () => {
    expect(requiresUiToken('GET', '/api/health')).toBe(false)
    expect(requiresUiToken('GET', '/api/llm/settings')).toBe(false)
    expect(requiresUiToken('POST', '/api/office/assist')).toBe(true)
    expect(requiresUiToken('POST', '/api/install/run')).toBe(true)
    expect(requiresUiToken('POST', '/api/llm/settings')).toBe(true)
    expect(isAiSpendRoute('POST', '/api/seat/write')).toBe(true)
    expect(isAiSpendRoute('GET', '/api/seat/write')).toBe(false)
  })

  it('rejects a bad Host, a foreign Origin on POST, and a missing token', () => {
    expect(
      guardBridgeRequest({
        host: 'evil.test:4178',
        method: 'GET',
        pathname: '/api/health',
        uiToken: TOKEN,
        port: PORT,
      }),
    ).toEqual({ ok: false, status: 403, reason: 'host' })

    expect(
      guardBridgeRequest({
        host: '127.0.0.1:4178',
        origin: 'https://example.com',
        method: 'POST',
        pathname: '/api/office/assist',
        uiHeader: TOKEN,
        uiToken: TOKEN,
        port: PORT,
      }),
    ).toEqual({ ok: false, status: 403, reason: 'origin' })

    expect(
      guardBridgeRequest({
        host: '127.0.0.1:4178',
        origin: 'http://127.0.0.1:5173',
        method: 'POST',
        pathname: '/api/office/assist',
        uiToken: TOKEN,
        port: PORT,
      }),
    ).toEqual({ ok: false, status: 401, reason: 'ui-token', corsOrigin: 'http://127.0.0.1:5173' })

    expect(
      guardBridgeRequest({
        host: '127.0.0.1:4178',
        origin: 'http://127.0.0.1:5173',
        method: 'POST',
        pathname: '/api/office/assist',
        uiHeader: TOKEN,
        uiToken: TOKEN,
        port: PORT,
      }),
    ).toEqual({ ok: true, corsOrigin: 'http://127.0.0.1:5173' })
  })

  it('compares UI tokens without leaking length-1 misses as equal', () => {
    const token = createUiToken()
    expect(uiTokenOk(token, token)).toBe(true)
    expect(uiTokenOk('', token)).toBe(false)
    expect(uiTokenOk('nope', token)).toBe(false)
  })

  it('publishes settings without any key fragment', () => {
    const view = publicLlmSettingsView({
      provider: 'auto',
      localModel: 'os.neu-local',
      hasKey: true,
      vendorHas: vendorHasFromKeys({ openai: 'secret-value-not-returned', gemini: '' }),
      ready: { ok: true, via: 'openai' },
      installed: [],
      diskFreeBytes: 1,
    })
    const raw = JSON.stringify(view)
    expect(view.hasKey).toBe(true)
    expect(view.vendorHas.openai).toBe(true)
    expect(view.vendorHas.gemini).toBe(false)
    expect(raw.includes('secret')).toBe(false)
    expect(raw.includes('keyHint')).toBe(false)
    expect(raw.includes('vendorHints')).toBe(false)
    expect(Object.hasOwn(view, 'keyHint')).toBe(false)
  })
})
