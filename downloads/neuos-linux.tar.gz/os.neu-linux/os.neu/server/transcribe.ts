import { File } from 'node:buffer'
import { openaiKey } from './env.ts'

const TRANSCRIBE_MODEL = process.env.TRANSCRIBE_MODEL || 'gpt-transcribe'

// B-002 / OpenAI: gpt-transcribe infers codec from the filename extension, not
// only Content-Type. A mismatched name (mp3 bytes as *.webm) is rejected.
const EXTENSION_BY_CONTENT_TYPE: Record<string, string> = {
  'audio/webm': 'webm',
  'audio/mp4': 'mp4',
  'audio/mpeg': 'mp3',
  'audio/mp3': 'mp3',
  'audio/wav': 'wav',
  'audio/x-wav': 'wav',
  'audio/m4a': 'm4a',
  'audio/x-m4a': 'm4a',
  'audio/ogg': 'ogg',
}

export function extensionFor(contentType: string): string {
  const base = contentType.split(';')[0]?.trim().toLowerCase()
  return EXTENSION_BY_CONTENT_TYPE[base ?? ''] ?? 'webm'
}

async function postTranscription(key: string, file: File, model: string): Promise<string> {
  const form = new FormData()
  form.append('file', file, file.name)
  form.append('model', model)
  const res = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { authorization: `Bearer ${key}` },
    body: form,
  })
  if (!res.ok) {
    const detail = await res.text().catch(() => '')
    throw new Error(`openai-${res.status}${detail ? `:${detail.slice(0, 180)}` : ''}`)
  }
  const body = (await res.json()) as { text?: string }
  return body.text?.trim() ?? ''
}

/** Clip ASR — same contract as B-002 transcribe.ts. Do not force language=. */
export async function transcribeUtterance(buffer: Buffer, contentType: string): Promise<string> {
  const key = openaiKey()
  if (!key) throw new Error('openai-unconfigured')
  if (buffer.length < 200) return ''
  const type = (contentType.split(';')[0] || 'audio/webm').trim().toLowerCase()
  const ext = extensionFor(contentType)
  const file = new File([new Uint8Array(buffer)], `utterance.${ext}`, { type })
  const models = [...new Set([TRANSCRIBE_MODEL, 'whisper-1', 'gpt-4o-mini-transcribe'])]
  let last = ''
  for (const model of models) {
    try {
      const text = await postTranscription(key, file, model)
      if (text) return text
      last = 'empty-transcript'
    } catch (err) {
      last = err instanceof Error ? err.message : 'asr-error'
      console.error('[asr]', model, last)
    }
  }
  if (last === 'empty-transcript') return ''
  throw new Error('asr-unavailable')
}
