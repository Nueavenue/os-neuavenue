import { execFile } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const KERNEL = path.join(ROOT, 'boot', 'kernel.mjs')
const HEALTH = path.join(ROOT, 'data', 'boot-health.json')
const STALE_MS = 15_000

export type BootHealth = {
  ok: boolean
  t: number
  pid?: number
  jeos?: boolean
  platform?: string
  stage?: string
  last?: string
  act?: string
  stale?: boolean
  ageMs?: number
  missing?: boolean
}

function decorate(raw: BootHealth): BootHealth {
  const ageMs = Math.max(0, Date.now() - (raw.t || 0))
  return {
    ...raw,
    ok: raw.ok !== false,
    ageMs,
    stale: ageMs > STALE_MS,
    missing: false,
  }
}

export async function readBootHealth(): Promise<BootHealth> {
  try {
    const raw = JSON.parse(await readFile(HEALTH, 'utf8')) as BootHealth
    return decorate(raw)
  } catch {
    return { ok: false, t: 0, missing: true, stale: true, ageMs: 0 }
  }
}

async function runKernel(args: string[]): Promise<string> {
  const { stdout } = await execFileAsync(process.execPath, [KERNEL, ...args], {
    timeout: args[0] === '--ask' ? 55_000 : 8000,
    cwd: ROOT,
  })
  return stdout.trim()
}

export async function probeBootHealth(): Promise<BootHealth> {
  try {
    const stdout = await runKernel(['--health'])
    return decorate(JSON.parse(stdout) as BootHealth)
  } catch {
    const existing = await readBootHealth()
    return { ...existing, ok: false, missing: existing.missing }
  }
}

export type JeosAsk = {
  ok: boolean
  act: string
  reply: string
  health: BootHealth
  plan?: {
    app: string
    kind: 'install' | 'remove'
    command: string
    url?: string
    host?: { pretty?: string; pkg?: string }
  }
}

export async function askJeos(text: string): Promise<JeosAsk> {
  const seed = text.trim() || 'hardware'
  const stdout = await runKernel(['--ask', seed])
  const parsed = JSON.parse(stdout) as JeosAsk & { health: BootHealth }
  return {
    ok: true,
    act: parsed.act,
    reply: String(parsed.reply ?? ''),
    health: decorate(parsed.health),
    plan: parsed.plan,
  }
}
