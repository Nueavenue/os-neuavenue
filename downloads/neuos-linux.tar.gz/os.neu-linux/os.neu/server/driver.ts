import { execFile, spawn } from 'node:child_process'
import { promisify } from 'node:util'
import { linuxCommand, planDriver, windowsScript, type DriverRequest } from '../src/engine/driverPlan.ts'

const execFileAsync = promisify(execFile)

export type DriverBackend = 'xdotool' | 'win32' | 'dry-run'

async function hasBin(bin: string): Promise<boolean> {
  try {
    await execFileAsync(process.platform === 'win32' ? 'where' : 'which', [bin])
    return true
  } catch {
    return false
  }
}

export async function detectBackend(): Promise<{
  backend: DriverBackend
  live: boolean
  detail: string
}> {
  const live = process.env.NEUOS_DRIVER === 'live'
  if (process.platform === 'win32') {
    return {
      backend: 'win32',
      live,
      detail: live ? 'Win32 SendInput / user32.dll' : 'Win32 ready · live clicks in the os.neu screen',
    }
  }
  if (await hasBin('xdotool')) {
    const display = process.env.DISPLAY ?? '(none)'
    return {
      backend: 'xdotool',
      live,
      detail: live
        ? `xdotool live click · DISPLAY=${display}`
        : `xdotool installed · DISPLAY=${display} · dev is dry-run, os.neu screen is live`,
    }
  }
  return {
    backend: 'dry-run',
    live: false,
    detail: 'xdotool missing. sudo apt install xdotool',
  }
}

function run(cmd: string, args: string[], env?: NodeJS.ProcessEnv): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { env: { ...process.env, ...env } })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (d: Buffer) => {
      stdout += d.toString()
    })
    child.stderr.on('data', (d: Buffer) => {
      stderr += d.toString()
    })
    child.on('error', reject)
    child.on('close', (code) => {
      if (code === 0) resolve({ stdout, stderr })
      else reject(new Error(stderr || `${cmd} exited ${code}`))
    })
  })
}

export async function act(req: DriverRequest): Promise<{
  ok: boolean
  backend: DriverBackend
  dryRun: boolean
  command?: string[]
  reason?: string
}> {
  const planned = planDriver(req)
  if (!planned.ok) {
    return { ok: false, backend: 'dry-run', dryRun: true, reason: planned.reason }
  }
  const detected = await detectBackend()
  const windowId = process.env.NEUOS_WINDOW_ID
  const execute = detected.live && detected.backend !== 'dry-run'

  if (planned.kind === 'isolate') {
    return {
      ok: true,
      backend: detected.backend,
      dryRun: !execute,
      command: ['sandbox', 'isolate'],
    }
  }

  const command = detected.backend === 'win32' ? ['powershell', 'SendInput'] : linuxCommand(planned, windowId)

  if (!execute) {
    return { ok: true, backend: detected.backend, dryRun: true, command }
  }

  if (detected.backend === 'xdotool') {
    const bin = command[0]
    const args = command.slice(1)
    await run(bin, args)
    return { ok: true, backend: 'xdotool', dryRun: false, command }
  }

  if (detected.backend === 'win32') {
    const script = windowsScript(planned)
    await run('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
      NEU_X: String(planned.x),
      NEU_Y: String(planned.y),
      NEU_TEXT: planned.text ?? '',
    })
    return { ok: true, backend: 'win32', dryRun: false, command: ['powershell', 'SendInput'] }
  }

  return {
    ok: true,
    backend: 'dry-run',
    dryRun: true,
    command,
  }
}
