import { execFile, spawn } from 'node:child_process'
import { chmodSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'
import { linuxCommand, planDriver, windowsScript, type DriverRequest } from '../src/engine/driverPlan.ts'

const DRIVER_ROOT = process.env.NEUOS_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

export type DriverConsent = { on: boolean; at: string }

export function driverConsentPath(root = DRIVER_ROOT) {
  return path.join(root, 'data', 'driver-consent.json')
}

export function readDriverConsent(root = DRIVER_ROOT): DriverConsent {
  const file = driverConsentPath(root)
  try {
    chmodSync(file, 0o600)
  } catch {
    /* missing */
  }
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as { on?: unknown; at?: unknown }
    return { on: Boolean(raw?.on), at: String(raw?.at || '') }
  } catch {
    return { on: false, at: '' }
  }
}

export function writeDriverConsent(on: boolean, root = DRIVER_ROOT): DriverConsent {
  const next: DriverConsent = { on: Boolean(on), at: new Date().toISOString() }
  const text = JSON.stringify(next)
  if (!text || text.length <= 1) throw new Error('driver-consent-empty')
  const file = driverConsentPath(root)
  const dir = path.dirname(file)
  mkdirSync(dir, { recursive: true })
  const tmp = path.join(dir, `.driver-consent.${process.pid}.tmp`)
  writeFileSync(tmp, text, { mode: 0o600 })
  chmodSync(tmp, 0o600)
  if (statSync(tmp).size <= 1) throw new Error('driver-consent-empty')
  renameSync(tmp, file)
  chmodSync(file, 0o600)
  return next
}

/** Live screen control is off unless the user consented and env is not forced off. */
export function driverLiveEnabled(root = DRIVER_ROOT): boolean {
  if (process.env.NEUOS_DRIVER === 'off') return false
  return readDriverConsent(root).on
}

const execFileAsync = promisify(execFile)

export type DriverBackend = 'xdotool' | 'win32' | 'dry-run'

async function hasBin(bin: string): Promise<boolean> {
  try {
    await execFileAsync(process.platform === 'win32' ? 'where' : 'which', [bin])
    return true
  } catch {
    return false
  }
}

export async function detectBackend(): Promise<{
  backend: DriverBackend
  live: boolean
  detail: string
}> {
  const live = driverLiveEnabled()
  if (process.platform === 'win32') {
    return {
      backend: 'win32',
      live,
      detail: live ? 'Win32 SendInput / user32.dll' : 'Win32 ready · live clicks in the os.neu screen',
    }
  }
  if (await hasBin('xdotool')) {
    const display = process.env.DISPLAY ?? '(none)'
    return {
      backend: 'xdotool',
      live,
      detail: live
        ? `xdotool live click · DISPLAY=${display}`
        : `xdotool installed · DISPLAY=${display} · dev is dry-run, os.neu screen is live`,
    }
  }
  return {
    backend: 'dry-run',
    live: false,
    detail: 'xdotool missing. sudo apt install xdotool',
  }
}

function run(cmd: string, args: string[], env?: NodeJS.ProcessEnv): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { env: { ...process.env, ...env } })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (d: Buffer) => {
      stdout += d.toString()
    })
    child.stderr.on('data', (d: Buffer) => {
      stderr += d.toString()
    })
    child.on('error', reject)
    child.on('close', (code) => {
      if (code === 0) resolve({ stdout, stderr })
      else reject(new Error(stderr || `${cmd} exited ${code}`))
    })
  })
}

export async function act(req: DriverRequest): Promise<{
  ok: boolean
  backend: DriverBackend
  dryRun: boolean
  command?: string[]
  reason?: string
}> {
  const planned = planDriver(req)
  if (!planned.ok) {
    return { ok: false, backend: 'dry-run', dryRun: true, reason: planned.reason }
  }
  const detected = await detectBackend()
  const windowId = process.env.NEUOS_WINDOW_ID
  const execute = detected.live && detected.backend !== 'dry-run'

  if (planned.kind === 'isolate') {
    return {
      ok: true,
      backend: detected.backend,
      dryRun: !execute,
      command: ['sandbox', 'isolate'],
    }
  }

  const command = detected.backend === 'win32' ? ['powershell', 'SendInput'] : linuxCommand(planned, windowId)

  if (!execute) {
    return { ok: true, backend: detected.backend, dryRun: true, command }
  }

  if (detected.backend === 'xdotool') {
    const bin = command[0]
    const args = command.slice(1)
    await run(bin, args)
    return { ok: true, backend: 'xdotool', dryRun: false, command }
  }

  if (detected.backend === 'win32') {
    const script = windowsScript(planned)
    await run('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
      NEU_X: String(planned.x),
      NEU_Y: String(planned.y),
      NEU_TEXT: planned.text ?? '',
    })
    return { ok: true, backend: 'win32', dryRun: false, command: ['powershell', 'SendInput'] }
  }

  return {
    ok: true,
    backend: 'dry-run',
    dryRun: true,
    command,
  }
}
