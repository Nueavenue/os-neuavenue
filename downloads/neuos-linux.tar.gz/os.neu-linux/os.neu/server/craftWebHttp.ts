import { createReadStream, existsSync, statSync } from 'node:fs'
import { realpathSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import path from 'node:path'
import { isInsideSandbox } from '../src/engine/craftConvert.ts'
import { craftWebFileRel, craftWebHref, craftWebRoot, joinCraftWebFile, planCraftWeb } from '../src/engine/craftWeb.ts'

const PORT = Number(process.env.NEUOS_BRIDGE_PORT ?? 4178)

function mimeFor(file: string) {
  if (file.endsWith('.html')) return 'text/html; charset=utf-8'
  if (file.endsWith('.js') || file.endsWith('.mjs')) return 'text/javascript; charset=utf-8'
  if (file.endsWith('.css')) return 'text/css; charset=utf-8'
  if (file.endsWith('.wasm')) return 'application/wasm'
  if (file.endsWith('.json')) return 'application/json; charset=utf-8'
  if (file.endsWith('.svg')) return 'image/svg+xml'
  if (file.endsWith('.png')) return 'image/png'
  return 'application/octet-stream'
}

function webRootOnDisk() {
  const root = craftWebRoot(process.env)
  if (!root) return null
  try {
    if (!existsSync(root) || !statSync(root).isDirectory()) return null
    const real = realpathSync(root)
    const index = path.join(real, 'index.html')
    if (!existsSync(index)) return null
    return real
  } catch {
    return null
  }
}

export function handleCraftWebApi(_req: IncomingMessage, res: ServerResponse) {
  try {
    const root = webRootOnDisk()
    const planned = planCraftWeb(process.env, PORT, Boolean(root))
    const href = planned.present ? planned.href || craftWebHref(PORT) : undefined
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(
      JSON.stringify({
        ok: true,
        present: Boolean(planned.present && href),
        ...(href ? { href, word: href } : {}),
      }),
    )
  } catch {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(JSON.stringify({ ok: true, present: false }))
  }
}

export function handleCraftWebStatic(req: IncomingMessage, res: ServerResponse) {
  const root = webRootOnDisk()
  if (!root) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' })
    res.end('missing')
    return
  }
  const host = req.headers.host ?? '127.0.0.1'
  const url = new URL(req.url ?? '/', `http://${host}`)
  const rel = craftWebFileRel(url.pathname)
  const file = rel ? joinCraftWebFile(root, rel) : null
  if (!file) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' })
    res.end('missing')
    return
  }
  try {
    const resolved = realpathSync(file)
    if (!isInsideSandbox(root, resolved) || !existsSync(resolved) || !statSync(resolved).isFile()) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' })
      res.end('missing')
      return
    }
    res.writeHead(200, { 'content-type': mimeFor(resolved), 'cache-control': 'no-store' })
    createReadStream(resolved).pipe(res)
  } catch {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' })
    res.end('missing')
  }
}
