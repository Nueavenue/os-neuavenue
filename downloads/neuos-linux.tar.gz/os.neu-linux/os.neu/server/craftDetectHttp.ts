import { execFile } from 'node:child_process'
import { constants } from 'node:fs'
import { accessSync } from 'node:fs'
import { homedir } from 'node:os'
import { promisify } from 'node:util'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { CRAFT_CLI, craftBinDirFromEnv, detectCraftBins, sidecarCliPath } from '../src/engine/craftDetect.ts'

const execFileAsync = promisify(execFile)

function isExec(path: string) {
  try {
    accessSync(path, constants.X_OK)
    return true
  } catch {
    return false
  }
}

async function whichCli(name: string): Promise<string | null> {
  try {
    const cmd = process.platform === 'win32' ? 'where' : 'which'
    const { stdout } = await execFileAsync(cmd, [name], { timeout: 1500 })
    const line = String(stdout || '')
      .trim()
      .split(/\r?\n/)[0]
    return line || null
  } catch {
    return null
  }
}

export async function detectCraftBinsOnHost() {
  const sidecar = craftBinDirFromEnv(process.env, homedir())
  const map = {
    [CRAFT_CLI.wordcraft]: (await whichCli(CRAFT_CLI.wordcraft)) || sidecarCliPath(sidecar, CRAFT_CLI.wordcraft, isExec),
    [CRAFT_CLI.gridcraft]: (await whichCli(CRAFT_CLI.gridcraft)) || sidecarCliPath(sidecar, CRAFT_CLI.gridcraft, isExec),
    [CRAFT_CLI.deckcraft]: (await whichCli(CRAFT_CLI.deckcraft)) || sidecarCliPath(sidecar, CRAFT_CLI.deckcraft, isExec),
  }
  return detectCraftBins(map)
}

export async function handleCraftDetect(_req: IncomingMessage, res: ServerResponse) {
  try {
    const bins = await detectCraftBinsOnHost()
    const present = Boolean(bins.wordcraft || bins.gridcraft || bins.deckcraft)
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(JSON.stringify({ ok: true, present, ...bins }))
  } catch {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(JSON.stringify({ ok: true, present: false, wordcraft: null, gridcraft: null, deckcraft: null }))
  }
}
