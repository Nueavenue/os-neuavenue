import { describe, expect, it } from 'vitest'
import { fromCountry, fromNavigator } from './catalog'

describe('locale detect', () => {
  it('maps country codes', () => {
    expect(fromCountry('KR')).toBe('ko')
    expect(fromCountry('US')).toBe('en')
    expect(fromCountry('JP')).toBe('ja')
    expect(fromCountry('XX')).toBe(null)
  })

  it('uses navigator language then timezone', () => {
    expect(fromNavigator('ko-KR')).toBe('ko')
    expect(fromNavigator('en-US')).toBe('en')
    expect(fromNavigator('xx', 'Asia/Seoul')).toBe('ko')
    expect(fromNavigator('xx')).toBe('en')
  })
})
