import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { COPY, type Copy, type Locale } from './catalog'
import { detectLocaleFromNetwork, detectLocaleNow, saveLocale } from './detect'

type I18n = {
  locale: Locale
  copy: Copy
  setLocale: (locale: Locale) => void
}

const Ctx = createContext<I18n | null>(null)

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => detectLocaleNow())

  useEffect(() => {
    let cancelled = false
    void detectLocaleFromNetwork().then((next) => {
      if (!cancelled && next) setLocaleState(next)
    })
    return () => {
      cancelled = true
    }
  }, [])

  const setLocale = useCallback((next: Locale) => {
    saveLocale(next)
    setLocaleState(next)
  }, [])

  const value = useMemo<I18n>(
    () => ({ locale, copy: COPY[locale], setLocale }),
    [locale, setLocale],
  )

  return (
    <Ctx.Provider value={value}>
      <div dir={locale === 'ar' ? 'rtl' : 'ltr'} lang={locale} className="i18n-root">
        {children}
      </div>
    </Ctx.Provider>
  )
}

export function useI18n(): I18n {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('LocaleProvider missing')
  return ctx
}
