import { fromCountry, fromNavigator, isLocale, type Locale } from './catalog'

const KEY = 'neuos.lang'

export function readSavedLocale(): Locale | null {
  try {
    const saved = localStorage.getItem(KEY)
    return saved && isLocale(saved) ? saved : null
  } catch {
    return null
  }
}

export function saveLocale(locale: Locale) {
  try {
    localStorage.setItem(KEY, locale)
  } catch {
    // ignore quota
  }
}

export function detectLocaleNow(): Locale {
  const saved = readSavedLocale()
  if (saved) return saved
  const lang = typeof navigator === 'undefined' ? 'en' : navigator.language
  const zone =
    typeof Intl === 'undefined' ? undefined : Intl.DateTimeFormat().resolvedOptions().timeZone
  return fromNavigator(lang, zone)
}

export async function detectLocaleFromNetwork(): Promise<Locale | null> {
  if (readSavedLocale()) return null
  try {
    const res = await fetch('https://cloudflare.com/cdn-cgi/trace', { cache: 'no-store' })
    const text = await res.text()
    const loc = text.match(/loc=([A-Z]{2})/i)?.[1]
    return fromCountry(loc)
  } catch {
    return null
  }
}
