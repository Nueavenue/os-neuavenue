export type Phase =
  | 'splash'
  | 'install'
  | 'post'
  | 'network'
  | 'lui'
  | 'landing'
  | 'workspace'
  | 'studio'
  | 'jeos'
  | 'announce'
  | 'plant'
  | 'admin'

export type CheckStatus = 'pending' | 'running' | 'ok' | 'warn' | 'fail'

export type HardwareCheck = {
  id: string
  title: string
  meaning: string
  detail: string
  status: CheckStatus
}

export type HardwareReport = {
  checks: HardwareCheck[]
  healthy: boolean
  capturedAt: number
}

export type IntentKind =
  | 'sheet-report'
  | 'doc'
  | 'web'
  | 'hardware'
  | 'studio'
  | 'talk'
  | 'app-install'
  | 'slides'

export type Intent = {
  kind: IntentKind
  raw: string
}

export type StepStatus = 'queued' | 'running' | 'done' | 'heal' | 'fail'

export type LayerId = 'lui' | 'vlm' | 'orchestrator' | 'driver'

export type PipelineStep = {
  id: string
  title: string
  detail: string
  layer: LayerId
  status: StepStatus
  healNote?: string
}

export type Pipeline = {
  id: string
  goal: string
  steps: PipelineStep[]
  createdAt: number
}

export type UiElement = {
  id: string
  label: string
  x: number
  y: number
  w: number
  h: number
  confidence: number
}

export type VisionFrame = {
  query: string
  elements: UiElement[]
  capturedAt: number
  source: 'pixel-graph' | 'remote-vlm'
}

export type DriverEvent = {
  id: string
  kind: 'click' | 'type' | 'hotkey' | 'open' | 'isolate'
  label: string
  at: number
}

export type DriverState = {
  cursor: { x: number; y: number; visible: boolean }
  sandbox: 'idle' | 'isolated'
  events: DriverEvent[]
}

export type SandboxApp = 'none' | 'sheet' | 'doc' | 'web' | 'slides'

export type ChatTurn = {
  id: string
  role: 'user' | 'neu'
  text: string
  pending?: boolean
  typing?: boolean
}

export type NetworkState = {
  online: boolean
  probed: boolean
  label: string
}
