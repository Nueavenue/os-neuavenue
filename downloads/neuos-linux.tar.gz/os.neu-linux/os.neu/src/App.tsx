import { useEffect, useRef } from 'react'
import { NeuralField } from './components/NeuralField'
import { probeNetwork } from './engine/network'
import { bootAfterSplash, phaseFromQuery, shouldRunBootTimer } from './engine/bootRoute'
import { useScreen } from './hooks/useScreen'
import { AdminDashboard } from './screens/AdminDashboard'
import { AnnounceScreen } from './screens/AnnounceScreen'
import { BootSplash } from './screens/BootSplash'
import { ExitDialog } from './components/ExitDialog'
import { ManualDialog } from './components/ManualDialog'
import { DownloadDialog } from './components/DownloadDialog'
import { HardwarePost } from './screens/HardwarePost'
import { InstallGate } from './screens/InstallGate'
import { JeosLoop } from './screens/JeosLoop'
import { LandingBrowser } from './screens/LandingBrowser'
import { LayerStudio } from './screens/LayerStudio'
import { LuiShell } from './screens/LuiShell'
import { NetworkGate } from './screens/NetworkGate'
import { PlantInstall } from './screens/PlantInstall'
import { Workspace } from './screens/Workspace'
import { LocaleProvider } from './i18n/LocaleContext'
import { NeuProvider, useNeu } from './state/store'

function Shell() {
  const neu = useNeu()
  const phaseRef = useRef(neu.phase)
  phaseRef.current = neu.phase
  useScreen()

  useEffect(() => {
    let cancelled = false
    void probeNetwork().then((network) => {
      if (!cancelled) neu.setNetwork(network)
    })
    const params = new URLSearchParams(window.location.search)
    if (params.get('test') === '1') {
      sessionStorage.setItem('neuos.test', '1')
    }
    const routed = phaseFromQuery(params.get('go'))
    if (routed) {
      neu.go(routed)
      return () => {
        cancelled = true
      }
    }
    const planted = Boolean(sessionStorage.getItem('neuos.install'))
    const timer = window.setTimeout(() => {
      if (cancelled || !shouldRunBootTimer(phaseRef.current)) return
      neu.go(bootAfterSplash(planted))
    }, 1800)
    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [neu.go, neu.setNetwork])

  useEffect(() => {
    if (neu.phase !== 'landing') {
      void window.neuos?.browse?.hide()
      void window.neuos?.browse?.devtools?.(null)
    }
  }, [neu.phase])

  if (neu.screenGone) {
    return <div className="os-screen os-gone" aria-hidden />
  }

  return (
    <div className="os-screen">
      <NeuralField />
      {neu.phase === 'splash' ? <BootSplash /> : null}
      {neu.phase === 'install' ? <InstallGate /> : null}
      {neu.phase === 'post' ? <HardwarePost onDone={() => neu.go('announce')} /> : null}
      {neu.phase === 'announce' ? <AnnounceScreen /> : null}
      {neu.phase === 'network' ? <NetworkGate /> : null}
      {neu.phase === 'lui' ? <LuiShell /> : null}
      {neu.phase === 'landing' ? <LandingBrowser /> : null}
      {neu.phase === 'workspace' ? <Workspace /> : null}
      {neu.phase === 'studio' ? <LayerStudio /> : null}
      {neu.phase === 'admin' ? <AdminDashboard /> : null}
      {neu.phase === 'plant' ? <PlantInstall /> : null}
      {neu.phase === 'jeos' ? <JeosLoop /> : null}
      <ExitDialog />
      <ManualDialog />
      <DownloadDialog />
    </div>
  )
}

export default function App() {
  return (
    <LocaleProvider>
      <NeuProvider>
        <Shell />
      </NeuProvider>
    </LocaleProvider>
  )
}
