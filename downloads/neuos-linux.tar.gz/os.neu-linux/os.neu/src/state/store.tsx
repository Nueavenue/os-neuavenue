import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  type ReactNode,
} from 'react'
import { decideChromeX } from '../engine/chromeX'
import { actDriver, coachChat, fetchBootHealth, fetchBridgeStatus, planAppInstall, recordVisionSample, sandboxRect, uninstallHost, type BootHealth, type BridgeStatus } from '../engine/bridge'
import { playCoachAudio, rememberCoach, speakBrowser } from '../engine/coachAudio'
import { idleDriver, isolate, moveCursor, pushEvent } from '../engine/drivers'
import { WEB_HOME } from '../engine/browser'
import { isAffirmative, isNegative, parseGuide, type PendingGuide } from '../engine/guide'
import { classifyIntent, replyToTalk } from '../engine/intents'
import { probeNetwork } from '../engine/network'
import { withStep } from '../engine/orchestrator'
import { centerOf, harvestUiGraph, pick } from '../engine/vlm'
import { fetchMe, trackEvent, type AuthUser } from '../engine/auth'
import type {
  ChatTurn,
  DriverState,
  HardwareReport,
  NetworkState,
  Phase,
  Pipeline,
  SandboxApp,
  VisionFrame,
} from '../types'

export type NeuState = {
  phase: Phase
  hardware: HardwareReport | null
  network: NetworkState
  chats: ChatTurn[]
  pipeline: Pipeline | null
  vision: VisionFrame | null
  driver: DriverState
  sandbox: SandboxApp
  busy: boolean
  savedSheet: boolean
  savedDoc: boolean
  bridge: BridgeStatus | null
  exitOpen: boolean
  bootHealth: BootHealth | null
  pendingGuide: PendingGuide | null
  browseTarget: string | null
  previousPhase: Phase | null
  officeModel: string
  account: AuthUser | null
  authPanel: 'none' | 'login' | 'feedback'
  screenGone: boolean
  installIntent: 'none' | 'host' | 'usb'
  manualOpen: boolean
  downloadOpen: boolean
}

type Action =
  | { type: 'phase'; phase: Phase }
  | { type: 'hardware'; report: HardwareReport }
  | { type: 'network'; network: NetworkState }
  | { type: 'chat'; turn: ChatTurn }
  | { type: 'patch-chat'; id: string; patch: Partial<ChatTurn> }
  | { type: 'drop-chat'; id: string }
  | { type: 'pipeline'; pipeline: Pipeline | null }
  | { type: 'vision'; vision: VisionFrame | null }
  | { type: 'driver'; driver: DriverState }
  | { type: 'sandbox'; sandbox: SandboxApp }
  | { type: 'busy'; busy: boolean }
  | { type: 'saved-sheet'; value: boolean }
  | { type: 'saved-doc'; value: boolean }
  | { type: 'bridge'; bridge: BridgeStatus | null }
  | { type: 'exit'; open: boolean }
  | { type: 'boot-health'; health: BootHealth | null }
  | { type: 'pending-guide'; guide: PendingGuide | null }
  | { type: 'browse-target'; href: string | null }
  | { type: 'previous-phase'; phase: Phase | null }
  | { type: 'office-model'; model: string }
  | { type: 'account'; account: AuthUser | null }
  | { type: 'auth-panel'; panel: 'none' | 'login' | 'feedback' }
  | { type: 'screen-gone'; value: boolean }
  | { type: 'install-intent'; intent: 'none' | 'host' | 'usb' }
  | { type: 'manual'; open: boolean }
  | { type: 'download'; open: boolean }

const initial: NeuState = {
  phase: 'splash',
  hardware: null,
  network: { online: false, probed: false, label: 'Checking' },
  chats: [],
  pipeline: null,
  vision: null,
  driver: idleDriver(),
  sandbox: 'none',
  busy: false,
  savedSheet: false,
  savedDoc: false,
  bridge: null,
  exitOpen: false,
  bootHealth: null,
  pendingGuide: null,
  browseTarget: null,
  previousPhase: null,
  officeModel: 'os.neu-local',
  account: null,
  authPanel: 'none',
  screenGone: false,
  installIntent: 'none',
  manualOpen: false,
  downloadOpen: false,
}

function reducer(state: NeuState, action: Action): NeuState {
  switch (action.type) {
    case 'phase':
      if (action.phase === state.phase) return state
      return { ...state, previousPhase: state.phase, phase: action.phase }
    case 'hardware':
      return { ...state, hardware: action.report }
    case 'network':
      return { ...state, network: action.network }
    case 'chat':
      return { ...state, chats: [...state.chats.slice(-18), action.turn] }
    case 'patch-chat':
      return {
        ...state,
        chats: state.chats.map((turn) => (turn.id === action.id ? { ...turn, ...action.patch } : turn)),
      }
    case 'drop-chat':
      return { ...state, chats: state.chats.filter((turn) => turn.id !== action.id) }
    case 'pipeline':
      return { ...state, pipeline: action.pipeline }
    case 'vision':
      return { ...state, vision: action.vision }
    case 'driver':
      return { ...state, driver: action.driver }
    case 'sandbox':
      return { ...state, sandbox: action.sandbox }
    case 'busy':
      return { ...state, busy: action.busy }
    case 'saved-sheet':
      return { ...state, savedSheet: action.value }
    case 'saved-doc':
      return { ...state, savedDoc: action.value }
    case 'bridge':
      return { ...state, bridge: action.bridge }
    case 'exit':
      return { ...state, exitOpen: action.open }
    case 'boot-health':
      return { ...state, bootHealth: action.health }
    case 'pending-guide':
      return { ...state, pendingGuide: action.guide }
    case 'browse-target':
      return { ...state, browseTarget: action.href }
    case 'previous-phase':
      return { ...state, previousPhase: action.phase }
    case 'office-model':
      return { ...state, officeModel: action.model }
    case 'account':
      return { ...state, account: action.account }
    case 'auth-panel':
      return { ...state, authPanel: action.panel }
    case 'screen-gone':
      return { ...state, screenGone: action.value, exitOpen: false }
    case 'install-intent':
      return { ...state, installIntent: action.intent }
    case 'manual':
      return { ...state, manualOpen: action.open, downloadOpen: action.open ? false : state.downloadOpen }
    case 'download':
      return { ...state, downloadOpen: action.open, manualOpen: action.open ? false : state.manualOpen }
    default:
      return state
  }
}

type NeuApi = NeuState & {
  go: (phase: Phase) => void
  setHardware: (report: HardwareReport) => void
  setNetwork: (network: NetworkState) => void
  submit: (text: string, opts?: { userId?: string }) => Promise<void>
  runPipelineOn: (root: HTMLElement) => Promise<void>
  goHome: () => void
  openExit: () => Promise<void>
  closeExit: () => void
  chooseJeos: () => void
  chooseLoop: () => void
  quitApp: () => Promise<void>
  uninstallAndLeave: (files?: boolean) => Promise<void>
  goBack: () => void
  openOffice: (app: 'sheet' | 'doc' | 'slides') => void
  setOfficeModel: (model: string) => void
  setAccount: (account: AuthUser | null) => void
  setAuthPanel: (panel: 'none' | 'login' | 'feedback') => void
  clearBrowseTarget: () => void
  openWeb: (href?: string) => void
  appendNeu: (text: string) => void
  beginChat: (role: 'user' | 'neu') => string
  patchChat: (id: string, patch: Partial<ChatTurn>) => void
  dropChat: (id: string) => void
  openPath: (kind: 'host' | 'usb' | 'guest') => void
  clearInstallIntent: () => void
  openManual: () => void
  closeManual: () => void
  openDownload: () => void
  closeDownload: () => void
  chromeX: () => void
}

const Ctx = createContext<NeuApi | null>(null)

function wait(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms))
}

type Dispatch = (action: Action) => void

function coachHistory(chats: ChatTurn[]) {
  return chats
    .filter((turn) => turn.text.trim() && !turn.pending)
    .slice(-8)
    .map((turn) => ({
      role: turn.role === 'user' ? ('user' as const) : ('assistant' as const),
      content: turn.text,
    }))
}

async function pushCoach(
  dispatch: Dispatch,
  message: string,
  fallback?: string,
  history: ChatTurn[] = [],
) {
  const prior = coachHistory(history)
  const id = `n-${Date.now()}`
  dispatch({
    type: 'chat',
    turn: { id, role: 'neu', text: '', pending: true },
  })
  try {
    const coach = await coachChat(message, prior, { audio: false })
    const text = coach.ok && coach.reply ? coach.reply : fallback ?? message
    rememberCoach(text, coach.audio)
    dispatch({
      type: 'patch-chat',
      id,
      patch: { text, pending: false, typing: true },
    })
    speakBrowser(text)
    if (coach.audio) void playCoachAudio()
  } catch {
    const text = fallback ?? message
    rememberCoach(text)
    dispatch({
      type: 'patch-chat',
      id,
      patch: { text, pending: false, typing: true },
    })
    speakBrowser(text)
  }
}

export function NeuProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial)

  useEffect(() => {
    void fetchBridgeStatus().then((bridge) => {
      if (bridge) dispatch({ type: 'bridge', bridge })
    })
    void fetchMe().then((user) => {
      if (user) dispatch({ type: 'account', account: user })
    })
  }, [])

  const accountRef = useRef(state.account)
  accountRef.current = state.account
  const phaseRef = useRef(state.phase)
  phaseRef.current = state.phase

  const go = useCallback((phase: Phase) => {
    if (phase === 'admin' && !accountRef.current?.admin) return
    const from = phaseRef.current
    if (from !== phase) dispatch({ type: 'previous-phase', phase: from })
    dispatch({ type: 'phase', phase })
    void trackEvent('view', phase)
  }, [])

  const setHardware = useCallback((report: HardwareReport) => {
    dispatch({ type: 'hardware', report })
  }, [])

  const setNetwork = useCallback((network: NetworkState) => {
    dispatch({ type: 'network', network })
  }, [])

  const goHome = useCallback(() => {
    dispatch({ type: 'pipeline', pipeline: null })
    dispatch({ type: 'vision', vision: null })
    dispatch({ type: 'sandbox', sandbox: 'none' })
    dispatch({ type: 'driver', driver: idleDriver() })
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'auth-panel', panel: 'none' })
    dispatch({
      type: 'phase',
      phase: state.network.online ? 'lui' : 'landing',
    })
  }, [state.network.online])

  const closeExit = useCallback(() => {
    dispatch({ type: 'exit', open: false })
  }, [])

  const openExit = useCallback(async () => {
    dispatch({ type: 'exit', open: true })
    dispatch({ type: 'boot-health', health: null })
    try {
      const health = await fetchBootHealth(true)
      dispatch({ type: 'boot-health', health })
    } catch {
      dispatch({
        type: 'boot-health',
        health: { ok: false, t: 0, missing: true, stale: true, ageMs: 0 },
      })
    }
  }, [])

  const chooseJeos = useCallback(() => {
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'phase', phase: 'jeos' })
  }, [])

  const chooseLoop = useCallback(() => {
    dispatch({ type: 'exit', open: false })
    dispatch({
      type: 'phase',
      phase: state.network.online ? 'lui' : 'landing',
    })
  }, [state.network.online])

  const quitApp = useCallback(async () => {
    void trackEvent('logout', state.phase, 'quit')
    void window.neuos?.browse?.hide()
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'screen-gone', value: true })
    if (window.neuos?.quit) {
      try {
        await window.neuos.quit()
        return
      } catch {
        /* still try to close */
      }
    }
    window.close()
  }, [state.phase])

  const setOfficeModel = useCallback((model: string) => {
    dispatch({ type: 'office-model', model })
  }, [])

  const setAccount = useCallback((account: AuthUser | null) => {
    dispatch({ type: 'account', account })
  }, [])

  const setAuthPanel = useCallback((panel: 'none' | 'login' | 'feedback') => {
    dispatch({ type: 'auth-panel', panel })
  }, [])

  const openOffice = useCallback((app: 'sheet' | 'doc' | 'slides') => {
    dispatch({ type: 'previous-phase', phase: state.phase })
    dispatch({ type: 'pipeline', pipeline: null })
    dispatch({ type: 'sandbox', sandbox: app })
    dispatch({ type: 'phase', phase: 'workspace' })
    void trackEvent('open-app', 'workspace', app)
  }, [state.phase])

  const goBack = useCallback(() => {
    const prev = state.previousPhase
    if (prev && prev !== state.phase && prev !== 'splash') {
      dispatch({ type: 'phase', phase: prev })
      void trackEvent('view', prev, 'back')
      return
    }
    goHome()
  }, [state.previousPhase, state.phase, goHome])

  const openPath = useCallback(
    (kind: 'host' | 'usb' | 'guest') => {
      sessionStorage.setItem('neuos.install', kind)
      void trackEvent('click', phaseRef.current, `path-${kind}`)
      if (kind === 'guest') {
        const boot = ['splash', 'install', 'post', 'announce', 'network']
        if (boot.includes(phaseRef.current)) go('post')
        else goHome()
        return
      }
      dispatch({ type: 'install-intent', intent: kind })
      go('install')
    },
    [go, goHome],
  )

  const clearInstallIntent = useCallback(() => {
    dispatch({ type: 'install-intent', intent: 'none' })
  }, [])

  const openManual = useCallback(() => {
    dispatch({ type: 'manual', open: true })
  }, [])

  const closeManual = useCallback(() => {
    dispatch({ type: 'manual', open: false })
  }, [])

  const openDownload = useCallback(() => {
    dispatch({ type: 'download', open: true })
  }, [])

  const closeDownload = useCallback(() => {
    dispatch({ type: 'download', open: false })
  }, [])

  const chromeX = useCallback(() => {
    const action = decideChromeX({
      phase: state.phase,
      previousPhase: state.previousPhase,
      windowFullscreen: false,
      domFullscreen: Boolean(document.fullscreenElement),
    })
    if (action === 'quit') {
      void quitApp()
      return
    }
    if (action === 'leave-fullscreen') {
      if (document.fullscreenElement) void document.exitFullscreen()
      void window.neuos?.setFullscreen?.(false)
      return
    }
    if (action === 'back') {
      const prev = state.previousPhase
      if (prev && prev !== state.phase) {
        dispatch({ type: 'phase', phase: prev })
        void trackEvent('view', prev, 'chrome-x')
      }
      return
    }
    goHome()
  }, [state.previousPhase, state.phase, quitApp, goHome])

  const uninstallAndLeave = useCallback(async (files = false) => {
    try {
      await uninstallHost(files)
    } catch {
      /* still leave Ubuntu usable even if the bridge is down */
    }
    sessionStorage.removeItem('neuos.install')
    await quitApp()
  }, [quitApp])

  const clearBrowseTarget = useCallback(() => {
    dispatch({ type: 'browse-target', href: null })
  }, [])

  const openWeb = useCallback((href = 'https://www.neuavenue.com') => {
    dispatch({ type: 'browse-target', href })
    dispatch({ type: 'sandbox', sandbox: 'web' })
    dispatch({ type: 'phase', phase: 'landing' })
  }, [])

  const appendNeu = useCallback((text: string) => {
    const line = text.trim()
    if (!line) return
    dispatch({
      type: 'chat',
      turn: { id: `n-${Date.now()}`, role: 'neu', text: line, typing: true },
    })
  }, [])

  const beginChat = useCallback((role: 'user' | 'neu') => {
    const id = `${role === 'user' ? 'u' : 'n'}-${Date.now()}`
    dispatch({
      type: 'chat',
      turn: { id, role, text: '', pending: true },
    })
    return id
  }, [])

  const patchChat = useCallback((id: string, patch: Partial<ChatTurn>) => {
    dispatch({ type: 'patch-chat', id, patch })
  }, [])

  const dropChat = useCallback((id: string) => {
    dispatch({ type: 'drop-chat', id })
  }, [])

  const submit = useCallback(
    async (text: string, opts?: { userId?: string }) => {
      const raw = text.trim()
      if (!raw) return

      if (opts?.userId) {
        dispatch({
          type: 'patch-chat',
          id: opts.userId,
          patch: { text: raw, pending: false, typing: false },
        })
      } else {
        dispatch({
          type: 'chat',
          turn: { id: `u-${Date.now()}`, role: 'user', text: raw, typing: true },
        })
      }

      const pending = state.pendingGuide
      const prior = state.chats
      if (pending && isNegative(raw)) {
        dispatch({ type: 'pending-guide', guide: null })
        dispatch({ type: 'busy', busy: true })
        await pushCoach(dispatch, 'The learner said no. Cancel the computer task and ask what they want instead.', 'Okay. What should we do instead?', prior)
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (pending && isAffirmative(raw)) {
        dispatch({ type: 'busy', busy: true })
        if (pending.stage === 'confirm') {
          let facts = ''
          let online = state.network.online
          if (pending.wantsNet) {
            const net = await probeNetwork()
            dispatch({ type: 'network', network: net })
            online = net.online
            facts += net.online
              ? ` Internet is on (${net.label}).`
              : ' Internet looks offline.'
          }
          if (pending.wantsBrowser && online) {
            const href = pending.browseUrl || WEB_HOME
            dispatch({ type: 'browse-target', href })
            dispatch({ type: 'sandbox', sandbox: 'web' })
            dispatch({ type: 'phase', phase: 'landing' })
            dispatch({
              type: 'pending-guide',
              guide: { ...pending, stage: 'see-page' },
            })
            await pushCoach(
              dispatch,
              `The learner confirmed. Facts:${facts} Opened ${href}. Ask them in English to look at the page and say if they see it.`,
              `${facts} I opened ${href}. Do you see that page?`.trim(),
              prior,
            )
            dispatch({ type: 'busy', busy: false })
            return
          }
          let install = ''
          if (pending.installQuery) {
            try {
              const result = await planAppInstall(pending.installQuery, 'lui')
              const plan = result.plan
              install = plan ? ` ${plan.next ?? ''} ${plan.command}` : ''
            } catch {
              install = ' Could not build the install command yet.'
            }
          }
          dispatch({ type: 'pending-guide', guide: null })
          dispatch({ type: 'phase', phase: 'lui' })
          await pushCoach(
            dispatch,
            `The learner confirmed. Facts:${facts}${install} Speak those facts in English and ask what they see.`,
            `${facts}${install} What do you see?`.trim(),
            prior,
          )
          dispatch({ type: 'busy', busy: false })
          return
        }

        if (pending.stage === 'see-page') {
          let install = ''
          if (pending.installQuery) {
            try {
              const result = await planAppInstall(pending.installQuery, 'lui')
              const plan = result.plan
              install = plan ? `${plan.next ?? ''} ${plan.command}`.trim() : ''
            } catch {
              install = 'Could not build the install command yet.'
            }
          }
          dispatch({ type: 'pending-guide', guide: null })
          await pushCoach(
            dispatch,
            `The learner sees the page. Give the next step in English.${install ? ` Install command: ${install}` : ''} Ask if they want you to repeat it.`,
            install || 'Good. What should we do next?',
            prior,
          )
          dispatch({ type: 'busy', busy: false })
          return
        }
        dispatch({ type: 'busy', busy: false })
      }

      if (pending) {
        dispatch({ type: 'busy', busy: true })
        await pushCoach(
          dispatch,
          'The learner did not clearly say yes or no. Ask them again to look at the screen and say yes or no.',
          'Please look at this screen and say yes or no.',
          prior,
        )
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (/^install\s+os\.neu\b/i.test(raw) || /^install\s+osneu\b/i.test(raw)) {
        dispatch({ type: 'phase', phase: 'plant' })
        return
      }
      if (/^(uninstall|remove|delete)\s+os\.neu\b/i.test(raw) || /^os\.neu\s+(삭제|제거)/i.test(raw)) {
        dispatch({ type: 'exit', open: true })
        return
      }

      const guided = parseGuide(raw)
      if (guided) {
        dispatch({ type: 'pending-guide', guide: { ...guided, stage: 'confirm' } })
        dispatch({ type: 'busy', busy: true })
        await pushCoach(
          dispatch,
          `The learner asked: "${raw}". Restate that in one English sentence and ask them to look at this screen and say yes or no before we check the internet or open a browser.`,
          guided.confirm,
          prior,
        )
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      const intent = classifyIntent(raw)

      if (intent.kind === 'talk') {
        if (state.network.online) {
          dispatch({ type: 'busy', busy: true })
          await pushCoach(dispatch, raw, replyToTalk(raw), prior)
          dispatch({ type: 'busy', busy: false })
          dispatch({ type: 'phase', phase: 'lui' })
          return
        }
        dispatch({
          type: 'chat',
          turn: { id: `n-${Date.now()}`, role: 'neu', text: replyToTalk(raw) },
        })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (intent.kind === 'app-install') {
        try {
          const result = await planAppInstall(raw, 'lui')
          const plan = result.plan
          const line = plan
            ? `${plan.next ?? ''} ${plan.command}`.trim()
            : 'Could not read this PC’s base yet.'
          if (state.network.online) {
            dispatch({ type: 'busy', busy: true })
            await pushCoach(
              dispatch,
              `The learner asked to install software: "${raw}". Restate it, then give this command and ask them to confirm before running it: ${line}`,
              line,
              prior,
            )
            dispatch({ type: 'busy', busy: false })
          } else {
            dispatch({
              type: 'chat',
              turn: { id: `n-${Date.now()}`, role: 'neu', text: line },
            })
          }
          if (result.preference?.installSurface === 'prompt') {
            dispatch({ type: 'phase', phase: 'jeos' })
          } else {
            dispatch({ type: 'phase', phase: 'lui' })
          }
        } catch {
          dispatch({
            type: 'chat',
            turn: { id: `n-${Date.now()}`, role: 'neu', text: 'Could not build an install guide.' },
          })
        }
        return
      }

      if (intent.kind === 'studio') {
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: 'Opening the four layers. Speech to the screen, eyes to pixels, brain to a plan, hands to clicks.',
          },
        })
        dispatch({ type: 'phase', phase: 'studio' })
        return
      }

      if (intent.kind === 'hardware') {
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: 'Back to the same check screen as right after power-on.',
          },
        })
        dispatch({ type: 'phase', phase: 'post' })
        return
      }

      if (intent.kind === 'web') {
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: state.network.online
              ? 'Opening www.neuavenue.com. Surf from there.'
              : 'No outside connection. The local landing page is home.',
          },
        })
        if (state.network.online) {
          dispatch({ type: 'browse-target', href: 'https://www.neuavenue.com' })
        }
        dispatch({ type: 'sandbox', sandbox: 'web' })
        dispatch({ type: 'phase', phase: 'landing' })
        return
      }

      if (intent.kind === 'sheet-report') {
        openOffice('sheet')
        return
      }
      if (intent.kind === 'doc') {
        openOffice('doc')
        return
      }
      if (intent.kind === 'slides') {
        openOffice('slides')
        return
      }
    },
    [state.busy, state.network, state.pendingGuide, openOffice],
  )

  const runPipelineOn = useCallback(
    async (root: HTMLElement) => {
      if (!state.pipeline || state.busy) return
      dispatch({ type: 'busy', busy: true })
      let pipeline = state.pipeline
      let driver = state.driver

      const box = sandboxRect(root)
      let sampled = false

      const look = (query: string) => {
        const frame = harvestUiGraph(root, query)
        dispatch({ type: 'vision', vision: frame })
        if (!sampled) {
          sampled = true
          void recordVisionSample({
            id: `vlm-${pipeline.id}`,
            query,
            capturedAt: Date.now(),
            boxes: frame.elements,
          })
        }
        return frame
      }

      const send = async (
        kind: 'click' | 'type' | 'hotkey' | 'isolate',
        label: string,
        extra?: { x?: number; y?: number; text?: string; keys?: string },
      ) => {
        try {
          const result = await actDriver({
            kind,
            sandbox: box,
            x: extra?.x !== undefined ? box.left + extra.x : undefined,
            y: extra?.y !== undefined ? box.top + extra.y : undefined,
            text: extra?.text,
            keys: extra?.keys,
          })
          const tag = result.dryRun ? `${label} · dry ${result.backend}` : `${label} · ${result.backend}`
          driver = pushEvent(driver, kind === 'isolate' ? 'isolate' : kind, tag)
        } catch {
          driver = pushEvent(driver, kind === 'isolate' ? 'isolate' : kind, `${label} · no bridge`)
        }
        dispatch({ type: 'driver', driver })
      }

      const mark = (id: string, status: 'running' | 'done' | 'heal' | 'fail', healNote?: string) => {
        pipeline = withStep(pipeline, id, { status, healNote })
        dispatch({ type: 'pipeline', pipeline })
      }

      try {
        for (const step of pipeline.steps) {
          mark(step.id, 'running')
          await wait(420)

          const title = step.title.toLowerCase()
          const mentions = (...needles: string[]) => needles.some((n) => title.includes(n.toLowerCase()))

          if (step.layer === 'vlm') {
            const query = mentions('save', '저장')
              ? 'save'
              : mentions('title', '제목')
                ? 'title'
                : 'input'
            look(query)
            await wait(360)
            mark(step.id, 'done')
            continue
          }

          if (mentions('isolate', 'open browser', '연다', '격리')) {
            driver = isolate(driver)
            dispatch({ type: 'driver', driver })
            await send('isolate', 'App isolated in its own space')
            mark(step.id, 'done')
            continue
          }

          const frame = harvestUiGraph(root, step.title)
          dispatch({ type: 'vision', vision: frame })

          const targetId = mentions('title', '제목')
            ? 'title'
            : mentions('body', 'numbers', 'sentences', 'fill', '본문', '숫자', '문장')
              ? state.sandbox === 'doc'
                ? 'editor'
                : 'cell-0-0'
              : mentions('save', '저장')
                ? 'save'
                : mentions('address', '주소')
                  ? 'url'
                  : 'title'

          const el = pick(frame, targetId)

          if (mentions('click save', '저장을 실행') && el) {
            mark(step.id, 'heal', 'Save was missed on the first look. Retrying with a hotkey.')
            await wait(500)
            await send('hotkey', 'Ctrl+S', { keys: 'ctrl+s' })
            if (state.sandbox === 'sheet') dispatch({ type: 'saved-sheet', value: true })
            if (state.sandbox === 'doc') dispatch({ type: 'saved-doc', value: true })
            mark(step.id, 'done', 'Healed save with a keyboard shortcut.')
            continue
          }

          if (el) {
            const pt = centerOf(el)
            driver = moveCursor(driver, pt.x, pt.y)
            const typing = mentions('type', 'fill', '입력', '채운', '받아')
            await send(
              typing ? 'type' : 'click',
              `${el.label} @ ${pt.x}, ${pt.y}`,
              typing
                ? { x: pt.x, y: pt.y, text: typing ? 'Weekly progress report' : undefined }
                : { x: pt.x, y: pt.y },
            )
            await wait(280)
          } else {
            await send('click', 'No target — falling back to the keyboard')
          }

          if (mentions('save to', 'click save', '남긴', '저장을')) {
            if (state.sandbox === 'sheet') dispatch({ type: 'saved-sheet', value: true })
            if (state.sandbox === 'doc') dispatch({ type: 'saved-doc', value: true })
          }

          mark(step.id, 'done')
        }
      } finally {
        dispatch({ type: 'busy', busy: false })
      }
    },
    [state.busy, state.driver, state.pipeline, state.sandbox],
  )

  const api = useMemo<NeuApi>(
    () => ({
      ...state,
      go,
      setHardware,
      setNetwork,
      submit,
      runPipelineOn,
      goHome,
      openExit,
      closeExit,
      chooseJeos,
      chooseLoop,
      quitApp,
      uninstallAndLeave,
      goBack,
      openOffice,
      setOfficeModel,
      setAccount,
      setAuthPanel,
      clearBrowseTarget,
      openWeb,
      appendNeu,
      beginChat,
      patchChat,
      dropChat,
      openPath,
      clearInstallIntent,
      openManual,
      closeManual,
      openDownload,
      closeDownload,
      chromeX,
    }),
    [state, go, setHardware, setNetwork, submit, runPipelineOn, goHome, openExit, closeExit, chooseJeos, chooseLoop, quitApp, uninstallAndLeave, goBack, openOffice, setOfficeModel, setAccount, setAuthPanel, clearBrowseTarget, openWeb, appendNeu, beginChat, patchChat, dropChat, openPath, clearInstallIntent, openManual, closeManual, openDownload, closeDownload, chromeX],
  )

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>
}

export function useNeu(): NeuApi {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('NeuProvider missing')
  return ctx
}
