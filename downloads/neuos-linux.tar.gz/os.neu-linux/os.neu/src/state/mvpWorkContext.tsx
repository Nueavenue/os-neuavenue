import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { importLegacy, logActivity, mirrorWork, recordSource, snapshotWorkDoc } from '../engine/workspaceLog'
import {
  addSource,
  attachWorkDoc,
  createWork,
  loadActiveWorkId,
  loadWorks,
  setActiveWorkId,
  upsertWork,
  type MvpAudience,
  type MvpPending,
  type MvpSource,
  type MvpWork,
} from '../engine/mvpWork'

export type MvpTab = 'doc' | 'web'

type MvpApi = {
  /** Live works only; trashed rows are in `trashed`. */
  works: MvpWork[]
  trashed: MvpWork[]
  active: MvpWork | null
  pending: MvpPending | null
  tab: MvpTab
  saveOpen: boolean
  setTab: (tab: MvpTab) => void
  setSaveOpen: (open: boolean) => void
  setPending: (pending: MvpPending | null) => void
  patchPending: (patch: Partial<MvpPending>) => void
  startWork: (opts: {
    prompt: string
    audience?: MvpAudience
    audienceNote?: string
    docId: string
  }) => MvpWork
  openWork: (id: string) => MvpWork | null
  clearActive: () => void
  /** Returns the stored savedAt, or null when there is no active work. */
  markSaved: () => number | null
  attachSource: (source: Omit<MvpSource, 'id' | 'addedAt'> & { id?: string }) => void
  /** Keep a Doc id on the active work so This-work rail lists it after Sheets round-trips. */
  attachDoc: (docId: string) => void
  /** Hides the work (trash); nothing is erased. */
  trashWork: (id: string) => void
  restoreWork: (id: string) => void
  refresh: () => void
}

const Ctx = createContext<MvpApi | null>(null)

export function MvpWorkProvider({ children }: { children: ReactNode }) {
  const [allWorks, setWorks] = useState<MvpWork[]>(() => loadWorks())
  const [activeId, setActiveId] = useState<string | null>(() => loadActiveWorkId())
  const [pending, setPending] = useState<MvpPending | null>(null)
  const [tab, setTab] = useState<MvpTab>('doc')
  const [saveOpen, setSaveOpen] = useState(false)

  const works = useMemo(() => allWorks.filter((row) => !row.deletedAt), [allWorks])
  const trashed = useMemo(() => allWorks.filter((row) => row.deletedAt), [allWorks])
  const active = useMemo(() => works.find((row) => row.id === activeId) || null, [works, activeId])

  const refresh = useCallback(() => setWorks(loadWorks()), [])

  useEffect(() => {
    void importLegacy().catch(() => {
      /* workspace log is best-effort */
    })
  }, [])

  const patchPending = useCallback((patch: Partial<MvpPending>) => {
    setPending((prev) => (prev ? { ...prev, ...patch } : null))
  }, [])

  const startWork = useCallback(
    (opts: { prompt: string; audience?: MvpAudience; audienceNote?: string; docId: string }) => {
      const work = createWork({
        prompt: opts.prompt,
        audience: opts.audience,
        audienceNote: opts.audienceNote,
        docId: opts.docId,
      })
      const next = upsertWork(loadWorks(), work)
      setWorks(next)
      setActiveId(work.id)
      setActiveWorkId(work.id)
      mirrorWork(next.find((row) => row.id === work.id))
      logActivity('work.start', { title: work.prompt, workId: work.id })
      setPending(null)
      setTab('doc')
      return work
    },
    [],
  )

  const openWork = useCallback((id: string) => {
    const rows = loadWorks()
    const hit = rows.find((row) => row.id === id && !row.deletedAt) || null
    setWorks(rows)
    if (!hit) return null
    setActiveId(hit.id)
    setActiveWorkId(hit.id)
    setTab('doc')
    return hit
  }, [])

  const clearActive = useCallback(() => {
    setActiveId(null)
    setActiveWorkId(null)
    setPending(null)
    setTab('doc')
    setSaveOpen(false)
  }, [])

  const markSaved = useCallback((): number | null => {
    if (!activeId) return null
    const rows = loadWorks()
    const hit = rows.find((row) => row.id === activeId)
    if (!hit) return null
    const at = Date.now()
    const next = upsertWork(rows, { ...hit, savedAt: at })
    setWorks(next)
    const stored = next.find((row) => row.id === activeId)
    if (stored) {
      mirrorWork(stored)
      snapshotWorkDoc(stored)
      logActivity('work.save', { app: 'doc', title: stored.title, workId: stored.id })
    }
    return at
  }, [activeId])

  const attachSource = useCallback(
    (source: Omit<MvpSource, 'id' | 'addedAt'> & { id?: string }) => {
      if (!activeId) return
      const rows = loadWorks()
      const hit = rows.find((row) => row.id === activeId)
      if (!hit) return
      const next = upsertWork(rows, addSource(hit, source))
      setWorks(next)
      const stored = next.find((row) => row.id === activeId)
      const added = stored?.sources.find((row) => row.url === source.url)
      if (stored && added) {
        mirrorWork(stored)
        recordSource(stored, added)
      }
    },
    [activeId],
  )

  const attachDoc = useCallback(
    (docId: string) => {
      if (!activeId) return
      const rows = loadWorks()
      const hit = rows.find((row) => row.id === activeId)
      if (!hit) return
      const next = upsertWork(rows, attachWorkDoc(hit, docId))
      setWorks(next)
      const stored = next.find((row) => row.id === activeId)
      if (stored) mirrorWork(stored)
    },
    [activeId],
  )

  const setDeleted = useCallback((id: string, deletedAt: number | null) => {
    const rows = loadWorks()
    const hit = rows.find((row) => row.id === id)
    if (!hit) return
    const next = upsertWork(rows, { ...hit, deletedAt })
    setWorks(next)
    const stored = next.find((row) => row.id === id)
    if (stored) {
      mirrorWork(stored)
      logActivity(deletedAt ? 'work.delete' : 'work.restore', { title: stored.title, workId: stored.id })
    }
  }, [])

  const trashWork = useCallback(
    (id: string) => {
      if (id === activeId) clearActive()
      setDeleted(id, Date.now())
    },
    [activeId, clearActive, setDeleted],
  )

  const restoreWork = useCallback((id: string) => setDeleted(id, null), [setDeleted])

  const api = useMemo<MvpApi>(
    () => ({
      works,
      trashed,
      active,
      pending,
      tab,
      saveOpen,
      setTab,
      setSaveOpen,
      setPending,
      patchPending,
      startWork,
      openWork,
      clearActive,
      markSaved,
      attachSource,
      attachDoc,
      trashWork,
      restoreWork,
      refresh,
    }),
    [
      works,
      trashed,
      active,
      pending,
      tab,
      saveOpen,
      patchPending,
      startWork,
      openWork,
      clearActive,
      markSaved,
      attachSource,
      attachDoc,
      trashWork,
      restoreWork,
      refresh,
    ],
  )

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>
}

export function useMvpWork(): MvpApi {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('MvpWorkProvider missing')
  return ctx
}

export function useMvpWorkOrNull(): MvpApi | null {
  return useContext(Ctx)
}
