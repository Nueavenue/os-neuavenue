import { createContext, useContext } from 'react'
import type { AuthUser } from '../engine/auth'
import type { ChatTurn, HardwareReport, NetworkState, Phase } from '../types'
import type { NeuState } from './store'

export type NeuApi = NeuState & {
  go: (phase: Phase) => void
  setHardware: (report: HardwareReport) => void
  setNetwork: (network: NetworkState) => void
  submit: (text: string, opts?: { userId?: string }) => Promise<void>
  runPipelineOn: (root: HTMLElement) => Promise<void>
  goHome: () => void
  openExit: () => Promise<void>
  closeExit: () => void
  chooseJeos: () => void
  chooseLoop: () => void
  quitApp: () => Promise<void>
  uninstallAndLeave: (files?: boolean) => Promise<void>
  goBack: () => void
  openOffice: (app: 'sheet' | 'doc' | 'slides') => void
  openConsole: (text: string, href?: string | null) => void
  setSeatDump: (dump: { ask: string; body: string; turnId: string; done: boolean } | null) => void
  setOfficeModel: (model: string) => void
  setAccount: (account: AuthUser | null) => void
  setAuthPanel: (panel: 'none' | 'login' | 'feedback') => void
  clearBrowseTarget: () => void
  openWeb: (href?: string) => void
  openDaf: (href?: string) => void
  dismissDafPopup: () => void
  toggleVitality: () => void
  appendNeu: (text: string) => void
  beginChat: (role: 'user' | 'neu') => string
  patchChat: (id: string, patch: Partial<ChatTurn>) => void
  dropChat: (id: string) => void
  openPath: (kind: 'host' | 'usb' | 'guest') => void
  clearInstallIntent: () => void
  openManual: () => void
  closeManual: () => void
  openDownload: () => void
  closeDownload: () => void
  setChromeMenuOpen: (open: boolean) => void
  toggleChromeMenu: () => void
  chromeX: () => void
}

export const NeuContext = createContext<NeuApi | null>(null)

export function useNeu(): NeuApi {
  const ctx = useContext(NeuContext)
  if (!ctx) throw new Error('NeuProvider missing')
  return ctx
}
