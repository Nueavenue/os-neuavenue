import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { initGa4 } from './engine/ga4'
import { installSeatGuard } from './engine/seatReload'
import { ensureUiToken } from './engine/uiSession'

installSeatGuard()
void initGa4()
void ensureUiToken()

const root = document.getElementById('root')
if (!root) throw new Error('os.neu root missing')

createRoot(root).render(<App />)
