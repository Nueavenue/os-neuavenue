import { DriverCursor } from '../components/DriverCursor'
import { LayerRail } from '../components/LayerRail'
import { PipelineRail } from '../components/PipelineRail'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { TalkDrawer } from '../components/TalkDrawer'
import { VisionOverlay } from '../components/VisionOverlay'
import { DocApp } from '../components/apps/DocApp'
import { SheetApp } from '../components/apps/SheetApp'
import { SlidesApp } from '../components/apps/SlidesApp'
import { useNeu } from '../state/store'

export function Workspace() {
  const neu = useNeu()

  return (
    <section className="screen lui workspace">
      <StatusBar />
      <LayerRail
        active={['lui', 'vlm', 'orchestrator', 'driver']}
        onOpen={() => neu.go('studio')}
      />
      <div className={`workspace-body${neu.pipeline ? ' has-plan' : ''}`}>
        {neu.pipeline ? <PipelineRail pipeline={neu.pipeline} /> : null}
        <div className="panel office-panel">
          <div className="stage sandbox">
            {neu.sandbox === 'doc' ? <DocApp /> : null}
            {neu.sandbox === 'slides' ? <SlidesApp /> : null}
            {neu.sandbox === 'sheet' || neu.sandbox === 'none' ? <SheetApp /> : null}
            <VisionOverlay frame={neu.vision} />
            <DriverCursor driver={neu.driver} />
          </div>
        </div>
      </div>
      <StepNav onBack={() => neu.goBack()} />
      <TalkDrawer />
    </section>
  )
}
