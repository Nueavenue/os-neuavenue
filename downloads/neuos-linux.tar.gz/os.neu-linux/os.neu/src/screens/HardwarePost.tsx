import { useEffect, useState } from 'react'
import { inspectHardware } from '../engine/hardware'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'
import type { CheckStatus, HardwareCheck } from '../types'

const LABEL: Record<CheckStatus, string> = {
  pending: 'Wait',
  running: 'Checking',
  ok: 'OK',
  warn: 'Caution',
  fail: 'Fault',
}

const LABEL_KO: Record<CheckStatus, string> = {
  pending: '대기',
  running: '점검 중',
  ok: '정상',
  warn: '주의',
  fail: '고장',
}

const TITLE_KO: Record<string, string> = {
  display: '화면',
  think: '생각 장치',
  memory: '작업 메모리',
  storage: '저장 공간',
  audio: '소리',
  power: '전원',
}

export function HardwarePost({ onDone, embedded = false }: { onDone: () => void; embedded?: boolean }) {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const setHardware = neu.setHardware
  const [attempt, setAttempt] = useState(0)
  const [checks, setChecks] = useState<HardwareCheck[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      const placeholders: HardwareCheck[] = [
        { id: 'display', title: 'Screen', meaning: 'Display', detail: '', status: 'pending' },
        { id: 'think', title: 'Thinking unit', meaning: 'Processor', detail: '', status: 'pending' },
        { id: 'memory', title: 'Working memory', meaning: 'RAM', detail: '', status: 'pending' },
        { id: 'storage', title: 'Storage', meaning: 'Disk', detail: '', status: 'pending' },
        { id: 'audio', title: 'Sound', meaning: 'Mic and speakers', detail: '', status: 'pending' },
        { id: 'power', title: 'Power', meaning: 'Battery', detail: '', status: 'pending' },
      ]
      setChecks(placeholders)
      const report = await inspectHardware()
      if (cancelled) return

      for (let i = 0; i < report.checks.length; i += 1) {
        setChecks((prev) =>
          prev.map((row, idx) => (idx === i ? { ...row, status: 'running' } : row)),
        )
        await new Promise((r) => window.setTimeout(r, 140))
        if (cancelled) return
        const next = report.checks[i]
        setChecks((prev) => prev.map((row, idx) => (idx === i ? next : row)))
      }
      setHardware(report)
      setReady(true)
    }
    void run()
    return () => {
      cancelled = true
    }
  }, [attempt, setHardware])

  const failed = checks.filter((c) => c.status === 'fail')
  const canContinue = ready && failed.length === 0
  const blocked = ready && failed.length > 0

  return (
    <section className={`screen post${embedded ? ' embedded' : ''}`}>
      {embedded ? null : <StatusBar />}
      <div className="post-body">
        <div className="post-head">
          <h2>{ko ? '전원을 켠 직후' : 'Right after power-on'}</h2>
          <p>
            {ko
              ? '짧은 몸 점검입니다. 문제가 있으면 쉬운 말로 알려 드립니다.'
              : 'A short body check. If something is wrong, we say so in plain words.'}
          </p>
        </div>
        <div className="checks">
          {checks.map((check) => (
            <article key={check.id} className={`check ${check.status}`}>
              <div>
                <b>{ko ? TITLE_KO[check.id] ?? check.title : check.title}</b>
              </div>
              <div className={`badge ${check.status}`}>{(ko ? LABEL_KO : LABEL)[check.status]}</div>
              {check.detail ? <div className="detail">{check.detail}</div> : null}
            </article>
          ))}
        </div>
        {blocked ? (
          <div className="repair">
            <b>{ko ? '고친 뒤 다시 해 보세요.' : 'Fix it, then try again.'}</b>
            <p>
              {failed.map((f) => f.detail).join(' ')}{' '}
              {ko
                ? '케이블, 충전기, 마이크를 확인하고 점검을 다시 실행하세요.'
                : 'Check cables, charger, and mic, then run the check again.'}
            </p>
            <div className="row-actions">
              <button
                type="button"
                className="btn primary"
                onClick={() => {
                  setReady(false)
                  setChecks([])
                  setAttempt((n) => n + 1)
                }}
              >
                {ko ? '다시 점검' : 'Check again'}
              </button>
            </div>
          </div>
        ) : null}
        {embedded ? null : (
          <StepNav onBack={() => neu.go('install')} onNext={canContinue ? onDone : undefined} />
        )}
      </div>
    </section>
  )
}
