import { useEffect, useState } from 'react'
import { inspectHardware } from '../engine/hardware'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useNeu } from '../state/store'
import type { CheckStatus, HardwareCheck } from '../types'

const LABEL: Record<CheckStatus, string> = {
  pending: 'Wait',
  running: 'Checking',
  ok: 'OK',
  warn: 'Caution',
  fail: 'Fault',
}

export function HardwarePost({ onDone }: { onDone: () => void }) {
  const neu = useNeu()
  const setHardware = neu.setHardware
  const [attempt, setAttempt] = useState(0)
  const [checks, setChecks] = useState<HardwareCheck[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      const placeholders: HardwareCheck[] = [
        { id: 'display', title: 'Screen', meaning: 'Display', detail: '', status: 'pending' },
        { id: 'think', title: 'Thinking unit', meaning: 'Processor', detail: '', status: 'pending' },
        { id: 'memory', title: 'Working memory', meaning: 'RAM', detail: '', status: 'pending' },
        { id: 'storage', title: 'Storage', meaning: 'Disk', detail: '', status: 'pending' },
        { id: 'audio', title: 'Sound', meaning: 'Mic and speakers', detail: '', status: 'pending' },
        { id: 'power', title: 'Power', meaning: 'Battery', detail: '', status: 'pending' },
      ]
      setChecks(placeholders)
      const report = await inspectHardware()
      if (cancelled) return

      for (let i = 0; i < report.checks.length; i += 1) {
        setChecks((prev) =>
          prev.map((row, idx) => (idx === i ? { ...row, status: 'running' } : row)),
        )
        await new Promise((r) => window.setTimeout(r, 140))
        if (cancelled) return
        const next = report.checks[i]
        setChecks((prev) => prev.map((row, idx) => (idx === i ? next : row)))
      }
      setHardware(report)
      setReady(true)
    }
    void run()
    return () => {
      cancelled = true
    }
  }, [attempt, setHardware])

  const failed = checks.filter((c) => c.status === 'fail')
  const canContinue = ready && failed.length === 0
  const blocked = ready && failed.length > 0

  return (
    <section className="screen post">
      <StatusBar />
      <div className="post-body">
        <div className="post-head">
          <h2>Right after power-on</h2>
          <p>A short body check. If something is wrong, we say so in plain words.</p>
        </div>
        <div className="checks">
          {checks.map((check) => (
            <article key={check.id} className={`check ${check.status}`}>
              <div>
                <b>{check.title}</b>
              </div>
              <div className={`badge ${check.status}`}>{LABEL[check.status]}</div>
              {check.detail ? <div className="detail">{check.detail}</div> : null}
            </article>
          ))}
        </div>
        {blocked ? (
          <div className="repair">
            <b>Fix it, then try again.</b>
            <p>
              {failed.map((f) => f.detail).join(' ')} Check cables, charger, and mic, then run the check
              again.
            </p>
            <div className="row-actions">
              <button
                type="button"
                className="btn primary"
                onClick={() => {
                  setReady(false)
                  setChecks([])
                  setAttempt((n) => n + 1)
                }}
              >
                Check again
              </button>
            </div>
          </div>
        ) : null}
        <StepNav onBack={() => neu.go('install')} onNext={canContinue ? onDone : undefined} />
      </div>
    </section>
  )
}
