import { BrandMark } from '../components/BrandMark'
import { BrandTitle } from '../components/BrandTitle'
import { StatusBar } from '../components/StatusBar'
import { useI18n } from '../i18n/LocaleContext'

export function BootSplash() {
  const { copy } = useI18n()
  return (
    <section className="screen splash">
      <StatusBar />
      <BrandTitle />
      <div className="splash-logo">
        <BrandMark word={false} size="lockup" />
      </div>
      <p>{copy.tagline}</p>
      <p className="splash-linux">{copy.installLinuxOnly}</p>
    </section>
  )
}
