import { useState } from 'react'
import { LayerRail } from '../components/LayerRail'
import { PhoneHome } from '../components/PhoneHome'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { TalkDrawer } from '../components/TalkDrawer'
import { SheetApp } from '../components/apps/SheetApp'
import { useNeu } from '../state/store'
import type { LayerId } from '../types'

const CHAPTERS: { id: LayerId | 'stack'; title: string }[] = [
  { id: 'stack', title: 'Four layers' },
  { id: 'lui', title: '1. Speech LUI' },
  { id: 'vlm', title: '2. Eyes VLM' },
  { id: 'orchestrator', title: '3. Brain Orchestrator' },
  { id: 'driver', title: '4. Hands Driver' },
]

export function LayerStudio() {
  const neu = useNeu()
  const [chapter, setChapter] = useState<(typeof CHAPTERS)[number]['id']>('stack')

  return (
    <section className="screen studio">
      <StatusBar />
      <LayerRail active={['lui', 'vlm', 'orchestrator', 'driver']} onOpen={() => undefined} />
      <nav className="studio-nav">
        {CHAPTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            className={chapter === item.id ? 'on' : ''}
            onClick={() => setChapter(item.id)}
          >
            {item.title}
          </button>
        ))}
        <button type="button" className="icon-btn" aria-label="Home" onClick={neu.goHome}>
          ⌂
        </button>
      </nav>
      <article className="chapter">
        {chapter === 'stack' ? <StackChapter /> : null}
        {chapter === 'lui' ? <LuiChapter /> : null}
        {chapter === 'vlm' ? <VlmChapter /> : null}
        {chapter === 'orchestrator' ? <BrainChapter /> : null}
        {chapter === 'driver' ? <HandChapter /> : null}
      </article>
      <StepNav
        onBack={() => neu.goHome()}
        onNext={() => {
          const idx = CHAPTERS.findIndex((item) => item.id === chapter)
          const next = CHAPTERS[idx + 1]
          if (next) setChapter(next.id)
        }}
        nextDisabled={chapter === 'driver'}
      />
      <TalkDrawer />
    </section>
  )
}

function StackChapter() {
  return (
    <>
      <h2>The user never sees an OS</h2>
      <p className="lede">
        These four layers run on existing Windows, Linux, or Mac hardware. The desktop is never
        shown.
      </p>
      <div className="stack">
        <div className="stack-row">
          <div>
            <b>LUI · speech</b>
            <div>Full-screen company brand. One mic, one line.</div>
          </div>
          <span className="mono">intent</span>
        </div>
        <div className="stack-row">
          <div>
            <b>VLM · eyes</b>
            <div>One capture yields X, Y for each control.</div>
          </div>
          <span className="mono">vision</span>
        </div>
        <div className="stack-row">
          <div>
            <b>Orchestrator · brain</b>
            <div>Splits the job and heals on failure.</div>
          </div>
          <span className="mono">plan</span>
        </div>
        <div className="stack-row">
          <div>
            <b>Driver · hands</b>
            <div>Clicks and typing leave only inside the sandbox.</div>
          </div>
          <span className="mono">hardware</span>
        </div>
        <div className="stack-row">
          <div>
            <b>Hardware &amp; host OS</b>
            <div>Hidden layer. The user does not need its name.</div>
          </div>
          <span className="mono">host</span>
        </div>
      </div>
    </>
  )
}

function LuiChapter() {
  return (
    <>
      <h2>os.neu screen</h2>
      <p className="lede">
        Start menu, folder icons, and the taskbar leave the eyes. After boot this layer owns the
        monitor.
      </p>
      <div className="spec-grid">
        <div className="spec">
          <b>Hidden</b>
          <span>Desktop, file explorer, window chrome, host OS name</span>
        </div>
        <div className="spec">
          <b>Kept</b>
          <span>Brand, clock, connection, one prompt line, mic</span>
        </div>
        <div className="spec">
          <b>Input</b>
          <span>Voice first. Typing is backup. Mouse hunting is not required.</span>
        </div>
        <div className="spec">
          <b>Fallback</b>
          <span>Without a connection, a landing home still opens in the same frame.</span>
        </div>
      </div>
    </>
  )
}

function VlmChapter() {
  return (
    <>
      <h2>Eyes that pull coordinates from pixels</h2>
      <p className="lede">
        After learning sheet, document, and tool layouts, a screenshot is enough to find Save and
        the input field. Today the sandbox DOM is the labeled truth so a VLM fine-tune pipeline can
        start.
      </p>
      <div className="panel" style={{ height: 280, position: 'relative' }}>
        <div className="sandbox" style={{ height: '100%' }}>
          <SheetApp />
        </div>
      </div>
    </>
  )
}

function BrainChapter() {
  return (
    <>
      <h2>A brain that splits work and heals</h2>
      <p className="lede">
        “Open Excel and write a report” expands into [run → find coordinates → type → save]. If Save
        is missed, a heal loop retries with Ctrl+S.
      </p>
      <div className="spec-grid">
        <div className="spec">
          <b>Dynamic pipeline</b>
          <span>Each intent builds a fresh step graph.</span>
        </div>
        <div className="spec">
          <b>Self-heal</b>
          <span>On a missed click, replan with a hotkey or another anchor.</span>
        </div>
        <div className="spec">
          <b>Stop rule</b>
          <span>If the same step cannot heal three times, say why in plain language.</span>
        </div>
      </div>
    </>
  )
}

function HandChapter() {
  const neu = useNeu()
  return (
    <>
      <h2>Hands only move inside the cage</h2>
      <p className="lede">
        Linux uses{' '}
        <a href="https://github.com/jordansissel/xdotool" target="_blank" rel="noreferrer">
          xdotool
        </a>
        . Windows uses{' '}
        <a href="https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-sendinput">
          Win32 SendInput
        </a>
        . Coordinates outside the sandbox never fire.
      </p>
      <div className="spec-grid">
        <div className="spec">
          <b>Bridge now</b>
          <span>{neu.bridge?.detail ?? 'Waiting for the bridge'}</span>
        </div>
        <div className="spec">
          <b>click(x, y)</b>
          <span>Move the virtual pointer to the eyes’ coordinates.</span>
        </div>
        <div className="spec">
          <b>type / hotkey</b>
          <span>Keyboard signals only enter the sandbox.</span>
        </div>
        <div className="spec">
          <b>VLM samples</b>
          <span>
            Capture + box labels collect under data/vlm-samples.{' '}
            <a href="https://huggingface.co/docs/transformers/main/en/tasks/object_detection">
              Fine-tune
            </a>
          </span>
        </div>
      </div>
      <div style={{ marginTop: 16, border: '1px solid var(--line)', borderRadius: 16, overflow: 'hidden' }}>
        <PhoneHome />
      </div>
    </>
  )
}
