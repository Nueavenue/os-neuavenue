import { useEffect, useRef, useState } from 'react'
import { normalizeAddress, proxySrc, isAuthHost, HOME_HOST, WEB_HOME, GOOGLE_SIGNIN } from '../engine/browser'
import {
  deleteVisit,
  editVisit,
  hostOf,
  loadLedger,
  recordTool,
  saveLedger,
  suggestTools,
  upsertDownload,
  upsertVisit,
  type DownloadRecord,
} from '../engine/browseLedger'
import { BrowserChrome, type BrowserTab, type ChromeMenu } from '../components/BrowserChrome'
import { LayerRail } from '../components/LayerRail'
import { PhoneHome } from '../components/PhoneHome'
import { SiteIdentity } from '../components/SiteIdentity'
import { StatusBar } from '../components/StatusBar'
import { TalkDrawer } from '../components/TalkDrawer'
import { logoutRequest, trackEvent } from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

const HOME = HOME_HOST
const BOOKMARK_KEY = 'os.neu.bookmarks'
export type DevtoolsDock = 'hidden' | 'left' | 'top'

function isLoopback(href: string) {
  try {
    const host = new URL(href).hostname
    return host === 'localhost' || host === '127.0.0.1' || host === '::1'
  } catch {
    return false
  }
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export function LandingBrowser() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const email = neu.account?.email || null
  const [tabs, setTabs] = useState<BrowserTab[]>([{ id: 't1', title: 'Home', url: HOME }])
  const [activeId, setActiveId] = useState('t1')
  const [url, setUrl] = useState(HOME)
  const [href, setHref] = useState<string | null>(null)
  const [status, setStatus] = useState<'home' | 'loading' | 'ready' | 'error'>('home')
  const [error, setError] = useState('')
  const [ledger, setLedger] = useState(() => loadLedger(email))
  const [bookmarks, setBookmarks] = useState<BrowserTab[]>(() => readJson<BrowserTab[]>(BOOKMARK_KEY, []))
  const [chromeMenu, setChromeMenu] = useState(false)
  const [dock, setDock] = useState<DevtoolsDock>('hidden')
  const [forcedMenu, setForcedMenu] = useState<ChromeMenu>('none')
  const [identityOpen, setIdentityOpen] = useState(false)
  const paneRef = useRef<HTMLDivElement>(null)
  const toolsRef = useRef<HTMLDivElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const dragRef = useRef<{ x: number; y: number } | null>(null)
  const prevRef = useRef<{ url: string; href: string | null }>({ url: HOME, href: null })
  const electron = typeof window !== 'undefined' && Boolean(window.neuos?.browse)
  const goUrlRef = useRef<(next: string) => Promise<void>>(async () => {})

  useEffect(() => {
    setLedger(loadLedger(email))
  }, [email])

  useEffect(() => {
    saveLedger(email, ledger)
    if (!email) return
    const timer = window.setTimeout(() => {
      void fetch('/api/browse/ledger', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-osneu-token': localStorage.getItem('os.neu.token') || '' },
        body: JSON.stringify(ledger),
      }).catch(() => {})
    }, 800)
    return () => window.clearTimeout(timer)
  }, [email, ledger])

  const patchTab = (id: string, patch: Partial<BrowserTab>) => {
    setTabs((rows) => rows.map((tab) => (tab.id === id ? { ...tab, ...patch } : tab)))
  }

  const remember = (next: string, title?: string) => {
    setLedger((cur) =>
      recordTool(
        upsertVisit(cur, { url: next, title: title || hostOf(next) }),
        'visit',
        next,
      ),
    )
    void trackEvent('view', 'landing', next)
  }

  useEffect(() => {
    const off = window.neuos?.browse.onDownload?.((rec: DownloadRecord) => {
      setLedger((cur) => recordTool(upsertDownload(cur, rec), 'download', rec.filename))
    })
    return () => off?.()
  }, [])

  useEffect(() => {
    const pane = paneRef.current
    if (!electron || !pane || !window.neuos) return
    if (neu.exitOpen || neu.authPanel !== 'none' || identityOpen || chromeMenu || status === 'home' || status === 'error' || !href) {
      void window.neuos.browse.hide()
      void window.neuos.browse.devtools?.(null)
      return
    }
    const send = () => {
      const box = pane.getBoundingClientRect()
      void window.neuos?.browse.bounds({
        x: Math.round(box.left),
        y: Math.round(box.top),
        width: Math.round(box.width),
        height: Math.round(box.height),
      })
      const tools = toolsRef.current?.getBoundingClientRect()
      if (dock === 'hidden' || !tools || tools.width < 8 || tools.height < 8) {
        void window.neuos?.browse.devtools?.(null)
        return
      }
      void window.neuos?.browse.devtools?.({
        x: Math.round(tools.left),
        y: Math.round(tools.top),
        width: Math.round(tools.width),
        height: Math.round(tools.height),
      })
    }
    const ro = new ResizeObserver(send)
    ro.observe(pane)
    if (bodyRef.current) ro.observe(bodyRef.current)
    if (toolsRef.current) ro.observe(toolsRef.current)
    window.addEventListener('resize', send)
    send()
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', send)
    }
  }, [electron, href, neu.exitOpen, neu.authPanel, identityOpen, chromeMenu, status, dock])

  useEffect(() => {
    return () => {
      void window.neuos?.browse.hide()
      void window.neuos?.browse.devtools?.(null)
    }
  }, [])

  const goHome = () => {
    prevRef.current = { url, href }
    setHref(null)
    setUrl(HOME)
    setStatus('home')
    setError('')
    patchTab(activeId, { title: 'Home', url: HOME })
    void window.neuos?.browse.hide()
    void window.neuos?.browse.devtools?.(null)
  }

  const restorePrev = () => {
    const prev = prevRef.current
    setUrl(prev.url)
    setHref(prev.href)
    setStatus(prev.href ? 'ready' : 'home')
    setError('')
    if (!prev.href) void window.neuos?.browse.hide()
  }

  const openIdentityWindow = async (target: string) => {
    if (window.neuos?.browse?.newWindow) {
      await window.neuos.browse.newWindow(target)
      return
    }
    window.open(target, 'osneu-id', 'popup=yes,width=480,height=740')
  }

  const goUrl = async (next: string) => {
    const parsed = normalizeAddress(next)
    if (parsed.kind === 'home') {
      goHome()
      return
    }
    if (parsed.kind === 'invalid') {
      setStatus('error')
      setError(parsed.reason)
      return
    }
    if (!neu.network.online && !isLoopback(parsed.href)) {
      setStatus('error')
      setError(copy.offlineHint)
      restorePrev()
      return
    }
    if (isAuthHost(parsed.href)) {
      setIdentityOpen(true)
      await openIdentityWindow(parsed.href)
      return
    }
    prevRef.current = { url, href }
    setUrl(parsed.href)
    setHref(parsed.href)
    setStatus('loading')
    setError('')
    patchTab(activeId, { url: parsed.href, title: hostOf(parsed.href) })
    if (window.neuos?.browse) {
      const result = await window.neuos.browse.go(parsed.href)
      if (result.restored && result.href) {
        setUrl(result.href)
        setHref(result.href)
        setStatus('ready')
        patchTab(activeId, { url: result.href, title: hostOf(result.href) })
        return
      }
      if (!result.ok) {
        restorePrev()
        return
      }
      const finalHref = result.href || parsed.href
      setStatus('ready')
      setUrl(finalHref)
      setHref(finalHref)
      remember(finalHref, hostOf(finalHref))
      patchTab(activeId, { url: finalHref, title: hostOf(finalHref) })
    }
  }
  useEffect(() => {
    goUrlRef.current = goUrl
  })

  useEffect(() => {
    if (!neu.browseTarget) return
    const target = neu.browseTarget
    neu.clearBrowseTarget()
    void goUrlRef.current(target)
  }, [neu.browseTarget, neu.clearBrowseTarget])

  const openDevtools = (next: DevtoolsDock) => {
    setDock(next)
    if (next !== 'hidden') {
      setLedger((cur) => recordTool(cur, 'devtools', next))
      void trackEvent('click', 'landing', `devtools-${next}`)
    }
  }

  const showProxy = Boolean(href) && !electron && status !== 'error' && status !== 'home'
  const assigned = suggestTools(ledger, ko)

  return (
    <section className="screen lui">
      <StatusBar />
      <LayerRail active={['lui', 'driver']} onOpen={() => neu.go('studio')} />
      <BrowserChrome
        tabs={tabs}
        activeId={activeId}
        url={url}
        visits={ledger.visits}
        bookmarks={bookmarks}
        downloads={ledger.downloads}
        tools={assigned}
        account={neu.account}
        ko={ko}
        locale={locale}
        electron={electron}
        onSelectTab={(id) => {
          const tab = tabs.find((item) => item.id === id)
          setActiveId(id)
          if (!tab || tab.url === HOME) goHome()
          else void goUrl(tab.url)
        }}
        onNewTab={() => {
          const id = `t-${Date.now()}`
          setTabs((rows) => [...rows, { id, title: 'New tab', url: HOME }])
          setActiveId(id)
          goHome()
        }}
        onCloseTab={(id) => {
          setTabs((rows) => {
            const next = rows.filter((tab) => tab.id !== id)
            if (!next.length) return rows
            if (id === activeId) {
              const fallback = next[next.length - 1]
              setActiveId(fallback.id)
              if (fallback.url === HOME) goHome()
              else void goUrl(fallback.url)
            }
            return next
          })
        }}
        onNewWindow={() => {
          void window.neuos?.browse.newWindow?.(href || undefined)
        }}
        onUrl={(value) => void goUrl(value)}
        onHome={goHome}
        onBack={() => {
          if (window.neuos?.browse.back) {
            void window.neuos.browse.back().then((result) => {
              if (result.ok && result.href) {
                setUrl(result.href)
                setHref(result.href)
                setStatus('ready')
                remember(result.href, hostOf(result.href))
                return
              }
              restorePrev()
            })
            return
          }
          restorePrev()
        }}
        onBookmark={() => {
          if (!href) return
          const item: BrowserTab = { id: `b-${Date.now()}`, title: hostOf(href), url: href }
          setBookmarks((rows) => {
            const list = [item, ...rows.filter((row) => row.url !== href)].slice(0, 40)
            localStorage.setItem(BOOKMARK_KEY, JSON.stringify(list))
            return list
          })
          setLedger((cur) => recordTool(cur, 'bookmark', href))
        }}
        onOpenSaved={(saved) => void goUrl(saved)}
        onAddVisit={(next, title) => {
          const parsed = normalizeAddress(next)
          const href = parsed.kind === 'url' ? parsed.href : next
          setLedger((cur) => recordTool(upsertVisit(cur, { url: href, title }), 'history-add', href))
        }}
        onEditVisit={(id, patch) => {
          setLedger((cur) => recordTool(editVisit(cur, id, patch), 'history-edit', patch.url))
        }}
        onDeleteVisit={(id) => {
          setLedger((cur) => recordTool(deleteVisit(cur, id), 'history-delete', id))
        }}
        onOpenDownload={(id) => {
          void window.neuos?.browse.openDownload?.(id)
        }}
        onShowDownload={(id) => {
          void window.neuos?.browse.showDownload?.(id)
        }}
        onRunTool={(tool) => {
          setLedger((cur) => recordTool(cur, tool.id, tool.label))
          void trackEvent('open-app', 'landing', tool.id)
          if (tool.run === 'devtools') openDevtools(dock === 'hidden' ? 'left' : dock)
          else if (tool.run === 'office-doc') neu.openOffice('doc')
          else if (tool.run === 'office-sheet') neu.openOffice('sheet')
          else if (tool.run === 'downloads') {
            setForcedMenu('downloads')
            window.setTimeout(() => setForcedMenu('none'), 0)
          }
          else if (tool.href) void goUrl(tool.href)
        }}
        onRequestSignIn={() => neu.setAuthPanel('login')}
        onAskIdentity={() => setIdentityOpen(true)}
        onSignOut={() => {
          void logoutRequest()
          neu.setAccount(null)
        }}
        onMenuChange={setChromeMenu}
        openMenu={forcedMenu}
      >
        <div className={`browse-body dock-${dock}`} ref={bodyRef}>
          <button
            type="button"
            className="devtools-hidebar"
            aria-label={ko ? '개발툴' : 'DevTools'}
            title={ko ? '끌어 위나 왼쪽에 붙이거나, 눌러서 엽니다.' : 'Drag to the top or left, or click to open.'}
            onPointerDown={(event) => {
              dragRef.current = { x: event.clientX, y: event.clientY }
              event.currentTarget.setPointerCapture(event.pointerId)
            }}
            onPointerMove={(event) => {
              const start = dragRef.current
              if (!start) return
              const dx = event.clientX - start.x
              const dy = event.clientY - start.y
              if (dy < -40 && Math.abs(dy) > Math.abs(dx)) openDevtools('top')
              else if (dx > 36) openDevtools('left')
            }}
            onPointerUp={(event) => {
              const start = dragRef.current
              dragRef.current = null
              if (!start) return
              if (Math.hypot(event.clientX - start.x, event.clientY - start.y) < 8) {
                openDevtools(dock === 'hidden' ? 'left' : 'hidden')
              }
            }}
          >
            <i />
          </button>
          {dock === 'left' ? <div className="devtools-slot" ref={toolsRef} /> : null}
          <div className="browse-column">
            {dock === 'top' ? <div className="devtools-slot top" ref={toolsRef} /> : null}
            <div className={`browse-stage${showProxy ? ' has-frame' : ''}`} ref={paneRef}>
              {status === 'home' || !href ? <PhoneHome /> : null}
              {showProxy ? (
                <iframe
                  className="browse-frame"
                  title="Guest page"
                  src={proxySrc(href as string)}
                  sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-modals"
                  onLoad={() => setStatus('ready')}
                  onError={() => {
                    setStatus('ready')
                    setIdentityOpen(true)
                  }}
                />
              ) : null}
              {status === 'loading' && !showProxy ? <div className="browse-loading">{copy.opening}</div> : null}
              {status === 'error' ? (
                <div className="browse-error">
                  <b>{copy.browseFail}</b>
                  <p>{error}</p>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </BrowserChrome>
      <SiteIdentity
        open={identityOpen}
        site={href || WEB_HOME}
        account={neu.account}
        electron={electron}
        ko={ko}
        onClose={() => setIdentityOpen(false)}
        onGoogle={() => {
          setIdentityOpen(false)
          void openIdentityWindow(GOOGLE_SIGNIN)
        }}
        onOsNeu={() => {
          setIdentityOpen(false)
          neu.setAuthPanel('login')
        }}
      />
      <TalkDrawer />
    </section>
  )
}
