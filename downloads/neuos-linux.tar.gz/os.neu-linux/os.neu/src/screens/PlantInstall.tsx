import { useEffect, useState } from 'react'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

type DirList = {
  ok: boolean
  dir: string
  exists?: boolean
  dest?: string
  entries?: Array<{ name: string; dir: boolean; path: string }>
  percent?: number
  stage?: string
  error?: string
  hint?: string
  command?: string
  apps?: Array<{ app: string; command: string }>
}

async function j(path: string, init?: RequestInit): Promise<DirList> {
  const res = await fetch(path, init)
  return (await res.json()) as DirList
}

export function PlantInstall() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [dest, setDest] = useState('')
  const [tree, setTree] = useState<DirList | null>(null)
  const [step, setStep] = useState<'copy' | 'search' | 'ai' | 'done'>('copy')
  const [percent, setPercent] = useState(0)
  const [stage, setStage] = useState('')
  const [error, setError] = useState('')
  const [copying, setCopying] = useState(false)
  const [query, setQuery] = useState('')
  const [apps, setApps] = useState<Array<{ app: string; command: string }>>([])
  const [ownKey, setOwnKey] = useState('')
  const [guideOpen, setGuideOpen] = useState(true)
  const [guideMd, setGuideMd] = useState('')

  useEffect(() => {
    void j('/api/plant/default').then((body) => setDest(body.dest || body.dir || ''))
    void fetch('/api/guide.md')
      .then((res) => res.text())
      .then((text) => setGuideMd(text))
      .catch(() => setGuideMd(''))
  }, [])

  const showTree = async (dir: string, pick = false) => {
    let target = dir
    if (pick && window.neuos?.plant) {
      const picked = await window.neuos.plant.pick()
      if (picked?.ok && picked.path) target = picked.path
    }
    const body = await j(`/api/plant/list?dir=${encodeURIComponent(target)}`)
    setDest(body.dir)
    setTree(body)
  }

  const makeFolder = async () => {
    const body = await j('/api/plant/mkdir', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ dir: dest }),
    })
    setDest(body.dest || dest)
    await showTree(body.dest || dest)
  }

  const loadApps = async (q: string) => {
    const body = await j(`/api/catalog?q=${encodeURIComponent(q)}`)
    setApps(body.apps ?? [])
  }

  const install = async () => {
    setCopying(true)
    setError('')
    await j('/api/plant/start', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ dest }),
    })
    const tick = window.setInterval(async () => {
      const st = await j('/api/plant/status')
      setPercent(st.percent ?? 0)
      setStage(st.stage ?? '')
      if (st.stage === 'done') {
        window.clearInterval(tick)
        setDest(st.dest || dest)
        sessionStorage.setItem('neuos.install', 'host')
        setStep('search')
        setCopying(false)
        void loadApps('')
      }
      if (st.stage === 'error') {
        window.clearInterval(tick)
        setError(st.error || 'install failed')
        setCopying(false)
      }
    }, 400)
  }

  const saveKey = async () => {
    await j('/api/llm/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ dest, openaiKey: ownKey }),
    })
  }

  const skipAi = async () => {
    await saveKey()
    setStep('done')
  }

  const pullAi = async () => {
    await saveKey()
    setCopying(true)
    setError('')
    await j('/api/llm/pull', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ dest }),
    })
    const tick = window.setInterval(async () => {
      const st = await j('/api/llm/status')
      setPercent(st.percent ?? 0)
      setStage(st.stage ?? '')
      if (st.stage === 'done' || st.stage === 'error') {
        window.clearInterval(tick)
        setCopying(false)
        if (st.stage === 'error') setError(st.hint || st.error || st.command || 'public AI skipped')
        setStep('done')
      }
    }, 500)
  }

  const openPictureApp = async () => {
    await j('/api/plant/launch', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ dest, go: 'lui' }),
    })
    neu.go('lui')
  }

  const stepLabel = ko
    ? ['1 복사', '2 검색', '3 공개 AI', '4 화면']
    : ['1 Copy', '2 Search', '3 Public AI', '4 Screen']
  const active = step === 'copy' ? 0 : step === 'search' ? 1 : step === 'ai' ? 2 : 3

  return (
    <section className="screen plant">
      <StatusBar />
      {guideOpen ? (
        <aside className="plant-guide">
          <div className="plant-guide-head">
            <strong>{ko ? '가이드 패널' : 'Guide panel'}</strong>
            <a href="/api/guide" target="_blank" rel="noreferrer">
              {ko ? '링크 열기' : 'Open link'}
            </a>
            <button type="button" onClick={() => setGuideOpen(false)}>
              {ko ? '닫기' : 'Close'}
            </button>
          </div>
          <pre>{guideMd || (ko ? '가이드를 불러오는 중…' : 'Loading guide…')}</pre>
        </aside>
      ) : (
        <button type="button" className="plant-guide-link" onClick={() => setGuideOpen(true)}>
          {ko ? '가이드 패널 열기' : 'Open guide panel'}
        </button>
      )}
      <div className="plant-dialog">
        <h2>os.neu</h2>
        <p className="plant-steps">
          {stepLabel.map((label, index) => (
            <span key={label} className={index === active ? 'on' : ''}>
              {label}
            </span>
          ))}
        </p>
        {step === 'copy' ? (
          <>
            <p>{ko ? '설치 패널에서 폴더를 고른 뒤 파일을 복사합니다.' : 'In the install panel, pick a folder, then copy files.'}</p>
            <input className="plant-path" value={dest} onChange={(e) => setDest(e.target.value)} />
            {!copying ? (
              <>
                <div className="plant-actions">
                  <button type="button" onClick={() => void showTree(dest, true)}>
                    {ko ? '위치 확인' : 'Location'}
                  </button>
                  <button type="button" className="primary" onClick={() => void install()}>
                    {ko ? '복사' : 'Copy'}
                  </button>
                </div>
                <StepNav onBack={() => neu.go('install')} />
              </>
            ) : null}
            {tree && !copying ? (
              <div className="plant-tree">
                <button type="button" className="plant-card" onClick={() => void showTree(tree.dir.replace(/\/[^/]+\/?$/, '') || '/')}>
                  … {ko ? '상위 폴더' : 'Parent'}
                </button>
                {(tree.entries ?? [])
                  .filter((entry) => entry.dir)
                  .map((entry) => (
                    <button
                      key={entry.path}
                      type="button"
                      className={`plant-card${entry.name === 'os.neu' ? ' on' : ''}`}
                      onClick={() => void showTree(entry.path)}
                    >
                      <span>{entry.name}</span>
                      <span>{ko ? '열기' : 'Open'}</span>
                    </button>
                  ))}
                <button type="button" className="plant-card" onClick={() => void makeFolder()}>
                  {ko ? '이 위치에 os.neu 폴더 만들기' : 'Create os.neu here'}
                </button>
              </div>
            ) : null}
          </>
        ) : null}
        {step === 'search' ? (
          <>
            <p>{ko ? '설치할 앱을 검색하세요. 명령만 보여 주고 하드는 지우지 않습니다.' : 'Search an app. Commands are shown; disks are not wiped.'}</p>
            <input className="plant-path" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="firefox" />
            <div className="plant-actions">
              <button type="button" onClick={() => void loadApps(query)}>
                {ko ? '검색' : 'Search'}
              </button>
            </div>
            <StepNav onBack={() => setStep('copy')} onNext={() => setStep('ai')} />
            <div className="plant-tree">
              {apps.map((row) => (
                <button
                  key={row.app}
                  type="button"
                  className="plant-card"
                  onClick={() => void navigator.clipboard?.writeText(row.command)}
                >
                  <span>{row.app}</span>
                  <span>{row.command}</span>
                </button>
              ))}
            </div>
          </>
        ) : null}
        {step === 'ai' ? (
          <>
            <p>{ko ? '이 PC에서 공개 AI를 받을지 스스로 고르세요. 회사 열쇠는 선택입니다.' : 'Choose whether to download public AI on this PC. Your own key is optional.'}</p>
            <textarea className="plant-path plant-key" value={ownKey} onChange={(e) => setOwnKey(e.target.value)} placeholder="OpenAI" />
            <div className="plant-actions">
              <button type="button" onClick={() => void skipAi()}>
                {ko ? '건너뛰기' : 'Skip'}
              </button>
              <button type="button" className="primary" onClick={() => void pullAi()}>
                {ko ? '공개 AI 받기' : 'Get public AI'}
              </button>
            </div>
            <StepNav onBack={() => setStep('search')} />
          </>
        ) : null}
        {copying || step === 'done' ? (
          <>
            <div className="plant-bar">
              <i style={{ width: `${percent}%` }} />
            </div>
            <p className="plant-pct">
              {percent}% · {stage}
            </p>
            {error ? <p className="plant-error">{error}</p> : null}
          </>
        ) : null}
        {step === 'done' ? (
          <>
            <p>{ko ? '문서 · 시트 · 슬라이드가 있는 os.neu 화면을 엽니다.' : 'Open the os.neu screen with docs · sheets · slides.'}</p>
            <div className="plant-actions">
              <button type="button" className="primary" onClick={() => void openPictureApp()}>
                {ko ? 'os.neu 화면 열기' : 'Open os.neu screen'}
              </button>
            </div>
            <StepNav onBack={() => setStep('ai')} onNext={() => void openPictureApp()} />
          </>
        ) : null}
      </div>
    </section>
  )
}
