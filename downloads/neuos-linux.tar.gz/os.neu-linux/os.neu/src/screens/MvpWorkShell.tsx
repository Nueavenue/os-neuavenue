import { useEffect, useState } from 'react'
import { DocApp } from '../components/apps/DocApp'
import { MvpSaveDialog } from '../components/MvpSaveDialog'
import { PromptDock } from '../components/PromptDock'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { formatSavedAt } from '../engine/mvpWork'
import { listArtifacts, onWorkspaceChange, type WsArtifact } from '../engine/workspaceDb'
import { requestOpenArtifact } from '../engine/workspaceLog'
import { useI18n } from '../i18n/LocaleContext'
import { useMvpWork } from '../state/mvpWorkContext'
import { useNeu } from '../state/neuContext'

export function MvpWorkShell() {
  const neu = useNeu()
  const mvp = useMvpWork()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const work = mvp.active
  const [urlDraft, setUrlDraft] = useState('https://')
  const [webHint, setWebHint] = useState('')
  const [artifacts, setArtifacts] = useState<WsArtifact[]>([])
  const workId = work?.id ?? ''

  useEffect(() => {
    if (!workId) return
    let live = true
    const load = () =>
      void listArtifacts()
        .then((rows) => {
          if (live) setArtifacts(rows.filter((row) => row.workId === workId && row.app !== 'doc'))
        })
        .catch(() => undefined)
    load()
    const off = onWorkspaceChange(load)
    return () => {
      live = false
      off()
    }
  }, [workId])

  if (!work) {
    return (
      <section className="screen lui workspace mvp-work">
        <StatusBar />
        <div className="mvp-work-empty">
          <p>{ko ? '열린 작업이 없습니다. 새 작업에서 시작해 주세요.' : 'No open work. Start from New work.'}</p>
          <button type="button" onClick={() => neu.go('lui')}>
            {ko ? '새 작업으로' : 'Go to New work'}
          </button>
        </div>
      </section>
    )
  }

  const workOutputs = artifacts.length ? (
    <>
      <b>{ko ? '이 작업의 다른 결과물' : 'Other outputs'}</b>
      <ul>
        {artifacts.map((row) => (
          <li key={row.id}>
            <button
              type="button"
              onClick={() => {
                requestOpenArtifact(row.id, row.app)
                neu.openOffice(row.app)
              }}
            >
              <span>{row.app === 'sheet' ? (ko ? '시트' : 'Sheet') : ko ? '슬라이드' : 'Slides'}</span>
              {row.title}
            </button>
          </li>
        ))}
      </ul>
    </>
  ) : null

  const openPage = () => {
    const href = urlDraft.trim()
    if (!/^https?:\/\//i.test(href)) {
      setWebHint(ko ? 'http(s) 주소를 입력하세요.' : 'Enter an http(s) URL.')
      return
    }
    setWebHint('')
    neu.openWeb(href)
    neu.go('landing')
  }

  const addCurrent = () => {
    const href = urlDraft.trim()
    if (!/^https?:\/\//i.test(href)) {
      setWebHint(ko ? '추가할 주소를 입력하세요.' : 'Enter a URL to add.')
      return
    }
    let title = href
    try {
      title = new URL(href).hostname
    } catch {
      /* keep */
    }
    mvp.attachSource({ title, url: href, status: 'added' })
    setWebHint(ko ? '이번 작업 자료에 넣었습니다.' : 'Added to this work’s sources.')
  }

  return (
    <section className="screen lui workspace mvp-work">
      <StatusBar />
      <div className="mvp-work-top">
        <div className="mvp-work-title">
          <strong>{work.title}</strong>
          <span>{formatSavedAt(work.savedAt, ko)}</span>
        </div>
        <div className="mvp-work-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={mvp.tab === 'doc'} className={mvp.tab === 'doc' ? 'on' : ''} onClick={() => mvp.setTab('doc')}>
            {ko ? '문서' : 'Doc'}
          </button>
          <button type="button" role="tab" aria-selected={mvp.tab === 'web'} className={mvp.tab === 'web' ? 'on' : ''} onClick={() => mvp.setTab('web')}>
            {ko ? '웹 탐색' : 'Web'}
          </button>
        </div>
      </div>
      <div className="mvp-work-body">
        <div className="mvp-work-main">
          {mvp.tab === 'doc' ? (
            <div className="mvp-doc-stage">
              <DocApp
                scope={
                  work.docId
                    ? {
                        docIds: [work.docId],
                        outputs: workOutputs,
                        onAll: () => {
                          mvp.clearActive()
                          neu.openOffice('doc')
                        },
                      }
                    : undefined
                }
              />
            </div>
          ) : (
            <div className="mvp-web-stage">
              <p className="mvp-web-lead">
                {ko
                  ? '주소를 열고 자료를 고른 뒤 [자료로 추가]를 누르세요. 페이지는 daf.neu에서 열립니다.'
                  : 'Open a URL, then Add as source. Pages open in daf.neu.'}
              </p>
              <div className="mvp-web-bar">
                <input value={urlDraft} onChange={(e) => setUrlDraft(e.target.value)} aria-label={ko ? '웹 주소' : 'Web address'} />
                <button type="button" onClick={openPage}>
                  {ko ? '열기' : 'Open'}
                </button>
                <button type="button" className="primary" onClick={addCurrent}>
                  {ko ? '자료로 추가' : 'Add as source'}
                </button>
              </div>
              {webHint ? <p className="mvp-web-hint">{webHint}</p> : null}
              <button
                type="button"
                className="mvp-web-draft"
                onClick={() => {
                  mvp.setTab('doc')
                }}
              >
                {ko ? '문서 초안 만들기 / 문서로 돌아가기' : 'Back to document draft'}
              </button>
            </div>
          )}
        </div>
        <aside className="mvp-sources" aria-label={ko ? '참고 자료' : 'Sources'}>
          <p className="mvp-sources-title">{mvp.tab === 'doc' ? (ko ? '이 작업의 근거' : 'Sources for this work') : ko ? '이번 작업 자료' : 'Sources'}</p>
          {work.sources.length ? (
            <ul>
              {work.sources.map((src, i) => (
                <li key={src.id}>
                  <button type="button" onClick={() => { setUrlDraft(src.url); mvp.setTab('web'); neu.openWeb(src.url); neu.go('landing') }}>
                    {i + 1}. {src.title}
                  </button>
                  <small>{src.status}</small>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mvp-sources-empty">{ko ? '아직 추가한 자료가 없습니다.' : 'No sources yet.'}</p>
          )}
          <div className="mvp-sources-actions">
            <button type="button" onClick={() => mvp.setSaveOpen(true)}>
              {ko ? '저장' : 'Save'}
            </button>
            <button
              type="button"
              onClick={() => {
                mvp.setTab('web')
              }}
            >
              {ko ? '추가 조사' : 'More research'}
            </button>
          </div>
        </aside>
      </div>
      <div className="mvp-work-dock">
        <PromptDock
          onSubmit={(text) => {
            void neu.submit(text)
          }}
          hideThread
        />
      </div>
      <StepNav onBack={() => neu.go('lui')} />
      <MvpSaveDialog />
    </section>
  )
}
