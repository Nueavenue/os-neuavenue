import { BrandMark } from '../components/BrandMark'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useNeu } from '../state/store'
import { appendStart } from '../engine/bridge'

export function AnnounceScreen() {
  const neu = useNeu()

  const pick = async (which: 'jeos' | 'loop') => {
    try {
      await appendStart(which)
    } catch {
      /* monitor optional */
    }
    if (which === 'jeos') neu.chooseJeos()
    else {
      neu.closeExit()
      neu.go('network')
    }
  }

  return (
    <section className="screen announce">
      <StatusBar />
      <BrandMark size="lockup" word={false} />
      <h2>OS.neu v1.0 is ready</h2>
      <p>
        Pick how you want to talk to this PC. Neither choice opens Windows or Ubuntu folders. You
        can switch later with Exit.
      </p>
      <div className="exit-choices">
        <button type="button" className="install-card" onClick={() => void pick('jeos')}>
          <b>OS.neu console</b>
          <span>
            Chat or type commands like hardware, memory, network, or install firefox. Good when you
            want a command line. os.neu stays on screen.
          </span>
        </button>
        <button type="button" className="install-card" onClick={() => void pick('loop')}>
          <b>Talk screen</b>
          <span>
            Full-screen chat. Tap the mic, speak, tap again. OS.neu answers in text and, when
            online, with a speaker voice.
          </span>
        </button>
      </div>
      <StepNav onBack={() => neu.go('post')} onNext={() => void pick('loop')} />
    </section>
  )
}
