import { useState } from 'react'
import { StatusBar } from '../components/StatusBar'
import { useI18n } from '../i18n/LocaleContext'
import { HardwarePost } from './HardwarePost'
import { InstallGate } from './InstallGate'
import { LuiShell } from './LuiShell'

/**
 * WO-UI-NEU-ONE-PAGE-LANDING-121 — one scroll landing.
 *
 * Same face on hosted web, desktop plant, and the os.neu app: stacks the
 * four blocks Leader named instead of gating them behind splash→install→
 * post→lui as separate Next-only screens. Blocks 2–4 reuse the existing
 * `InstallGate` / `HardwarePost` / `LuiShell` screens verbatim via their
 * `embedded` prop (suppresses each screen's own StatusBar + StepNav only —
 * no other markup, copy, or logic changed) so their card actions (Plant /
 * USB / hardware check / the one-box + mic) keep running the same code.
 *
 * Leader 2026-10-20: Block 1 default is English (was BLOCK1-KO-UNTIL-EN).
 * Leader 2026-10-20: InstallGate + HardwarePost sit under a hide bar
 * directly below the hero; closed until the user opens it.
 */
export function OnePageLanding() {
  const [foldOpen, setFoldOpen] = useState(false)
  const { locale } = useI18n()
  const ko = locale === 'ko'

  return (
    <section className="screen one-page-landing">
      <StatusBar />
      <div className="one-page-scroll">
        <div className="install-copy landing-hero">
          {ko ? (
            <>
              <h2>os.neu — 지금 쓰는 PC 위의 Trusted Agent Seat</h2>
              <p>
                내 Ubuntu 또는 Windows 위에서 돌아가는 Agent Operating Layer입니다. 그 안의 daf.neu 브라우저로
                Word·PowerPoint·Excel 호환 문서를 편집합니다. 원하는 LLM을 연결해 온라인이든 오프라인이든 일을
                마칩니다.
              </p>
            </>
          ) : (
            <>
              <h2>os.neu — the Trusted Agent Seat on the PC you already have</h2>
              <p>
                An Agent Operating Layer that runs on top of your own Ubuntu or Windows. In it, the daf.neu browser
                edits office files (Word, PowerPoint, and Excel compatible). Connect the LLM you want and finish your
                work online or offline.
              </p>
            </>
          )}
        </div>
        <div className="landing-fold">
          <button
            type="button"
            className="landing-fold-bar"
            aria-expanded={foldOpen}
            aria-controls="landing-fold-body"
            onClick={() => setFoldOpen((open) => !open)}
          >
            <span className="landing-fold-label">
              {foldOpen
                ? ko
                  ? '심기·USB·몸 점검 닫기'
                  : 'Hide plant, USB, and body check'
                : ko
                  ? '심기·USB·몸 점검'
                  : 'Plant, USB, and body check'}
            </span>
            <span className="landing-fold-caret" aria-hidden>
              {foldOpen ? '▴' : '▾'}
            </span>
          </button>
          {foldOpen ? (
            <div id="landing-fold-body" className="landing-fold-body">
              <InstallGate embedded />
              <HardwarePost embedded onDone={() => undefined} />
            </div>
          ) : null}
        </div>
        <LuiShell embedded />
      </div>
    </section>
  )
}
