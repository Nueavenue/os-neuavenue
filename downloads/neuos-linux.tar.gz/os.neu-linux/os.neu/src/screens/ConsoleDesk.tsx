import { useEffect, useRef, useState } from 'react'
import { AppCatalogNested } from '../components/AppCatalogRail'
import { BrandTitle } from '../components/BrandTitle'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { seatErrorKo, streamSeatWrite } from '../engine/seatClient'
import {
  addTopic,
  appendTopicItem,
  itemsFor,
  loadTopicStore,
  renameTopic,
  selectTopic,
  type SeatTopicStore,
} from '../engine/seatTopics'
import {
  composeSeatFile,
  evidenceDetail,
  finishSeat,
  prepareSeat,
  releaseGate,
  verdictDetail,
  type SeatPrepared,
  type SeatStep,
} from '../engine/seatRun'
import { createPromptDraft, loadDocProjects, upsertDocProject } from '../engine/docProjects'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

const PREPARE_MS = 30_000
const LINE_MS = 90

function saveBody(ask: string, prepared: SeatPrepared, body: string, steps: SeatStep[]) {
  const full = composeSeatFile({
    request: prepared.request,
    body,
    plan: prepared.plan,
    verdict: verdictDetail(steps),
    evidence: evidenceDetail(steps),
  })
  const title = (ask.slice(0, 42) || 'Seat').replace(/\s+/g, ' ')
  const { node } = createPromptDraft(loadDocProjects(), ask || title)
  const rows = loadDocProjects()
  const saved = rows.find((row) => row.id === node.id)
  if (saved) upsertDocProject(rows, { ...saved, title, name: title, body: full, updated: Date.now() })
  return title
}

export function ConsoleDesk() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const ask = neu.consoleAsk || ''
  const tick = neu.consoleTick
  const [stage, setStage] = useState<'prepare' | 'dump'>('prepare')
  const [percent, setPercent] = useState(0)
  const [log, setLog] = useState<string[]>([])
  const [gate, setGate] = useState<'web' | 'send' | null>(null)
  const [webHref, setWebHref] = useState<string | null>(null)
  const [topics, setTopics] = useState<SeatTopicStore>(() => loadTopicStore())
  const [draftTopic, setDraftTopic] = useState('')
  const [rename, setRename] = useState('')
  const preparedRef = useRef<SeatPrepared | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const bodyRef = useRef('')
  const queueRef = useRef<string[]>([])
  const dumpedRef = useRef(false)
  const seenRef = useRef(0)
  const scroller = useRef<HTMLDivElement>(null)

  const pushLines = (text: string, already: number) => {
    const lines = text.replace(/\r\n/g, '\n').split('\n')
    if (lines.length <= already) return already
    queueRef.current.push(...lines.slice(already))
    return lines.length
  }

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight })
  }, [log, stage, percent])

  useEffect(() => {
    const id = window.setInterval(() => {
      const next = queueRef.current.shift()
      if (next === undefined) return
      setLog((rows) => [...rows, next])
    }, LINE_MS)
    return () => window.clearInterval(id)
  }, [])

  useEffect(() => {
    if (!ask) return
    abortRef.current?.abort()
    dumpedRef.current = false
    seenRef.current = 0
    bodyRef.current = ''
    queueRef.current = []
    preparedRef.current = null
    setLog([])
    setGate(null)
    setWebHref(null)
    setStage('prepare')
    setPercent(0)
    const prepared = prepareSeat({
      text: ask,
      model: neu.officeModel,
      account: neu.account,
      phase: 'console',
      online: neu.network.online,
      webHref: neu.consoleHref,
    })
    preparedRef.current = prepared
    setGate(prepared.gate)
    setWebHref(prepared.webHref)
    const started = Date.now()
    const tick = window.setInterval(() => {
      const p = Math.min(100, Math.round(((Date.now() - started) / PREPARE_MS) * 100))
      setPercent(p)
      if (p >= 100) {
        window.clearInterval(tick)
        setStage('dump')
      }
    }, 120)
    if (prepared.gate) {
      return () => {
        window.clearInterval(tick)
      }
    }
    const ctrl = new AbortController()
    abortRef.current = ctrl
    void streamSeatWrite(neu.officeModel, ask, (full) => {
      bodyRef.current = full
      if (dumpedRef.current) seenRef.current = pushLines(full, seenRef.current)
    }, ctrl.signal).then((result) => {
      const current = preparedRef.current
      if (!current) return
      const reason = result.ok ? undefined : seatErrorKo(result.reason || '')
      const steps = finishSeat(current, { body: result.text, modelError: result.ok ? undefined : reason })
      const shown = result.text || reason || ''
      bodyRef.current = shown
      if (dumpedRef.current) seenRef.current = pushLines(shown, seenRef.current)
      if (result.text.trim()) {
        saveBody(ask, current, result.text, steps)
        setTopics(appendTopicItem(loadTopicStore(), { ask, body: shown }))
      }
    })
    return () => {
      window.clearInterval(tick)
      ctrl.abort()
    }
  }, [ask, tick, neu.account, neu.consoleHref, neu.network.online, neu.officeModel])

  useEffect(() => {
    if (stage !== 'dump' || dumpedRef.current) return
    dumpedRef.current = true
    const prepared = preparedRef.current
    const header = [
      'console operation system',
      ask ? `> ${ask}` : '',
      ...(prepared?.steps || []).filter((row) => row.detail).map((row) => `[${row.n}] ${row.name} · ${row.status} · ${row.detail}`),
      '',
    ].filter((row) => row !== '')
    queueRef.current.push(...header)
    if (bodyRef.current) seenRef.current = pushLines(bodyRef.current, seenRef.current)
  }, [ask, stage])

  const choose = (choice: 'draft' | 'open-url' | 'stop') => {
    const current = preparedRef.current
    if (!current) return
    const released = releaseGate(current, choice)
    preparedRef.current = released
    setGate(null)
    if (choice === 'open-url' && webHref) neu.openWeb(webHref)
    if (choice === 'stop') {
      const steps = finishSeat(released, { body: '' })
      queueRef.current.push(...steps.filter((row) => row.detail).map((row) => `[${row.n}] ${row.name} · ${row.status} · ${row.detail}`))
      return
    }
    const ctrl = new AbortController()
    abortRef.current?.abort()
    abortRef.current = ctrl
    seenRef.current = 0
    void streamSeatWrite(neu.officeModel, ask, (full) => {
      bodyRef.current = full
      if (dumpedRef.current) seenRef.current = pushLines(full, seenRef.current)
    }, ctrl.signal).then((result) => {
      const next = preparedRef.current
      if (!next) return
      const reason = result.ok ? undefined : seatErrorKo(result.reason || '')
      const steps = finishSeat(next, { body: result.text, modelError: result.ok ? undefined : reason })
      if (result.text.trim()) {
        saveBody(ask, next, result.text, steps)
        setTopics(appendTopicItem(loadTopicStore(), { ask, body: result.text }))
      }
      if (dumpedRef.current) seenRef.current = pushLines(result.text || reason || '', seenRef.current)
    })
  }

  const history = itemsFor(topics, topics.activeId)

  return (
    <section className="screen console-desk">
      <StatusBar />
      <div className="console-layout">
        <aside className="console-topics" aria-label={ko ? '토픽별 목록' : 'List by topic'}>
          <AppCatalogNested />
          <h2>{ko ? 'list by topic' : 'list by topic'}</h2>
          <ul>
            {topics.topics.map((topic) => (
              <li key={topic.id}>
                <button
                  type="button"
                  className={topic.id === topics.activeId ? 'on' : ''}
                  onClick={() => setTopics(selectTopic(loadTopicStore(), topic.id))}
                >
                  {topic.id === 'start' ? (ko ? `${topic.title} (기본)` : `${topic.title} (default)`) : topic.title}
                </button>
              </li>
            ))}
          </ul>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (!draftTopic.trim()) return
              setTopics(addTopic(loadTopicStore(), draftTopic))
              setDraftTopic('')
            }}
          >
            <input value={draftTopic} onChange={(e) => setDraftTopic(e.target.value)} placeholder={ko ? '토픽 추가' : 'Add topic'} />
            <button type="submit">{ko ? '추가' : 'Add'}</button>
          </form>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (!rename.trim()) return
              setTopics(renameTopic(loadTopicStore(), topics.activeId, rename))
              setRename('')
            }}
          >
            <input value={rename} onChange={(e) => setRename(e.target.value)} placeholder={ko ? '선택한 이름 수정' : 'Rename selected'} />
            <button type="submit">{ko ? '수정' : 'Rename'}</button>
          </form>
          <ol className="console-history">
            {history.map((row) => (
              <li key={row.id}>
                <button type="button" onClick={() => neu.openConsole(row.ask)}>
                  {row.ask || row.body.slice(0, 40)}
                </button>
              </li>
            ))}
          </ol>
        </aside>
        <div className="console-main">
          <header className="console-head">
            <strong>os.neu console</strong>
            <span>v1.0</span>
          </header>
          {stage === 'prepare' ? (
            <div className="console-prepare" aria-busy="true">
              <BrandTitle wave />
              <p className="console-going">displaying is going on...</p>
              <div className="progress-track" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}>
                <div className="progress-fill" style={{ width: `${percent}%` }} />
              </div>
              <b className="progress-label">{percent}%</b>
            </div>
          ) : (
            <div className="console-dump" ref={scroller}>
              {log.map((line, index) => (
                <p key={`${index}-${line.slice(0, 12)}`} className="console-line">
                  {line || ' '}
                </p>
              ))}
              {gate ? (
                <div className="seat-run-actions">
                  {gate === 'web' ? (
                    <button type="button" onClick={() => choose('open-url')} disabled={!webHref}>
                      {ko ? '주소만 열기' : 'Open URL only'}
                    </button>
                  ) : null}
                  <button type="button" onClick={() => choose('draft')}>
                    {ko ? '초안만 쓰기' : 'Draft only'}
                  </button>
                  <button type="button" onClick={() => choose('stop')}>
                    {ko ? '멈추기' : 'Stop'}
                  </button>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </div>
      <StepNav onBack={() => neu.goBack()} />
    </section>
  )
}
