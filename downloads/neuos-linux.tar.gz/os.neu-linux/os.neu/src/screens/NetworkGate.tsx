import { useEffect, useRef } from 'react'
import { probeNetwork } from '../engine/network'
import { BrandMark } from '../components/BrandMark'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useNeu } from '../state/store'

export function NetworkGate() {
  const neu = useNeu()
  const leaveRef = useRef(false)

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      const network = await probeNetwork()
      if (cancelled || leaveRef.current) return
      neu.setNetwork(network)
      window.setTimeout(() => {
        if (cancelled || leaveRef.current) return
        neu.go(network.online ? 'lui' : 'landing')
      }, 900)
    }
    void run()
    return () => {
      cancelled = true
    }
  }, [neu.go, neu.setNetwork])

  const leave = (phase: 'announce' | 'lui' | 'landing') => {
    leaveRef.current = true
    neu.go(phase)
  }

  return (
    <section className="screen network-gate">
      <StatusBar />
      <BrandMark />
      <h2>Checking if we can reach outside</h2>
      <p>
        If there is a connection, we go to the talk screen. If not, a local home still opens inside
        the browser, like a phone.
      </p>
      <p style={{ color: 'var(--mint)' }}>{neu.network.label}</p>
      <StepNav
        onBack={() => leave('announce')}
        onNext={() => leave(neu.network.online ? 'lui' : 'landing')}
      />
    </section>
  )
}
