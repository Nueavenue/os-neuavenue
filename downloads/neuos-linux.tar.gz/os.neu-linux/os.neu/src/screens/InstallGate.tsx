import { PathTitle } from '../components/PathRail'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useNeu } from '../state/store'
import { useI18n } from '../i18n/LocaleContext'
import {
  fetchHostProfile,
  fetchUsbDisks,
  planUsb,
  runInstall,
  type HostProfile,
  type UsbDisk,
} from '../engine/bridge'
import { detectGuestOsNow, packForGuestOs } from '../engine/detectOs'
import { useEffect, useState } from 'react'

function remember(kind: 'host' | 'usb' | 'guest') {
  sessionStorage.setItem('neuos.install', kind)
}

function isTest() {
  return new URLSearchParams(window.location.search).get('test') === '1' || sessionStorage.getItem('neuos.test') === '1'
}

type Step = 'choice' | 'usb' | 'progress' | 'specs' | 'linux-dl' | 'os-miss'

export function InstallGate() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const test = isTest()
  const [step, setStep] = useState<Step>('choice')
  const [usb, setUsb] = useState<UsbDisk[]>([])
  const [picked, setPicked] = useState('')
  const [command, setCommand] = useState('bash scripts/make-usb.sh')
  const [percent, setPercent] = useState(0)
  const [log, setLog] = useState<string[]>([])
  const [host, setHost] = useState<HostProfile | null>(null)
  const [mode, setMode] = useState<'host' | 'usb'>('host')
  const [guestOs, setGuestOs] = useState('')

  useEffect(() => {
    if (test) sessionStorage.setItem('neuos.test', '1')
    void fetchUsbDisks()
      .then((list) => {
        setUsb(list.usb)
        setCommand(list.command)
        if (list.usb.length === 1) setPicked(list.usb[0].path)
      })
      .catch(() => undefined)
  }, [test])

  const afterProgress = async () => {
    try {
      setHost(await fetchHostProfile())
    } catch {
      setHost(null)
    }
    setStep('specs')
  }

  const run = async (nextMode: 'host' | 'usb') => {
    setMode(nextMode)
    setStep('progress')
    setPercent(8)
    setLog(['Detecting the host operating system'])
    remember(nextMode)
    const tick = window.setInterval(() => {
      setPercent((n) => Math.min(92, n + 7))
    }, 280)
    try {
      const result = await runInstall({
        mode: nextMode,
        device: picked || undefined,
        test: true,
      })
      window.clearInterval(tick)
      setPercent(100)
      setLog(result.steps?.length ? result.steps : ['Install steps finished'])
      if (result.command) setCommand(result.command)
      await afterProgress()
    } catch {
      window.clearInterval(tick)
      setPercent(100)
      setLog((rows) => [...rows, 'Bridge unreachable. Continuing in try-now.'])
      await afterProgress()
    }
  }

  const chooseWithOs = () => {
    void (async () => {
      const os = detectGuestOsNow()
      setGuestOs(os)
      let bridged = false
      try {
        const res = await fetch('/api/health', { signal: AbortSignal.timeout(800) })
        bridged = res.ok
      } catch {
        bridged = false
      }
      if (bridged && os === 'linux') {
        void run('host')
        return
      }
      const pack = packForGuestOs(os, window.location.hostname)
      if (pack.available && pack.href) {
        window.open(pack.href, '_blank', 'noopener,noreferrer')
        setStep('linux-dl')
        remember('host')
        return
      }
      setStep('os-miss')
    })()
  }

  const chooseWithoutOs = () => {
    setStep('usb')
  }

  const confirmUsb = async () => {
    if (usb.length > 1 && !picked) return
    try {
      const plan = await planUsb(picked)
      if (plan.command) setCommand(plan.command)
    } catch {
      /* keep */
    }
    void run('usb')
  }

  useEffect(() => {
    if (neu.installIntent === 'usb') {
      setStep('usb')
      neu.clearInstallIntent()
    }
    if (neu.installIntent === 'host') {
      neu.clearInstallIntent()
      chooseWithOs()
    }
  }, [neu.installIntent])

  return (
    <section className="screen install-gate">
      <StatusBar />
      {test ? <div className="test-banner">Test mode · disks are not wiped</div> : null}
      {step === 'choice' ? (
        <div className="install-copy">
          <h2>{copy.installTitle}</h2>
          <p>{copy.installLead}</p>
          <p className="install-linux-note">{copy.installLinuxOnly}</p>
          <div className="install-cards">
            <button type="button" className="install-card" onClick={chooseWithOs}>
              <PathTitle kind="host" label={copy.installHost} />
              <span>{copy.installHostHint}</span>
            </button>
            <button type="button" className="install-card" onClick={chooseWithoutOs}>
              <PathTitle kind="usb" label={copy.installUsb} />
              <span>{copy.installUsbHint}</span>
            </button>
            <button type="button" className="install-card" onClick={() => neu.openPath('guest')}>
              <PathTitle kind="guest" label={copy.installGuest} />
              <span>{copy.installGuestHint}</span>
            </button>
          </div>
          <StepNav onNext={() => neu.openPath('guest')} />
        </div>
      ) : null}

      {step === 'usb' ? (
        <div className="dialog-card">
          <h2>Pick a USB stick</h2>
          <p>
            {usb.length > 1
              ? 'More than one stick is plugged in. Choose one device to burn. Test mode does not wipe it.'
              : usb.length === 1
                ? 'This stick will be used. Test mode does not touch real partitions.'
                : 'No USB stick found. Download the boot kit and burn it on another PC.'}
          </p>
          <ul className="usb-list">
            {usb.map((disk) => (
              <li key={disk.path}>
                <button
                  type="button"
                  className={`chip ${picked === disk.path ? 'on' : ''}`}
                  onClick={() => setPicked(disk.path)}
                >
                  {disk.path} · {disk.size} {disk.model}
                </button>
              </li>
            ))}
          </ul>
          <code className="install-cmd">{command}</code>
          <StepNav
            onBack={() => setStep('choice')}
            onNext={() => void confirmUsb()}
            nextDisabled={usb.length > 1 && !picked}
          />
        </div>
      ) : null}

      {step === 'progress' ? (
        <div className="dialog-card">
          <h2>Planting OS.neu v1.0</h2>
          <p>{mode === 'host' ? 'Connecting graphical OS.neu to this login.' : 'Preparing a USB image.'}</p>
          <div className="progress-track" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}>
            <div className="progress-fill" style={{ width: `${percent}%` }} />
          </div>
          <b className="progress-label">{percent}%</b>
          <pre className="jeos-console">{log.join('\n')}</pre>
        </div>
      ) : null}

      {step === 'specs' ? (
        <div className="dialog-card">
          <h2>Starting on this hardware</h2>
          <p>We show what you can use now, not the host OS name.</p>
          {host ? (
            <ul className="spec-list">
              <li>Device name · {host.hostname}</li>
              <li>Detected base · {host.pretty} ({host.pkg})</li>
              <li>Thinking unit · {host.cores} cores · {host.arch}</li>
              <li>Memory · about {host.memGb}GB</li>
            </ul>
          ) : (
            <p>Could not read the profile. Continuing to the body check.</p>
          )}
          <StepNav onBack={() => setStep('choice')} onNext={() => neu.go('post')} />
        </div>
      ) : null}

      {step === 'linux-dl' ? (
        <div className="dialog-card">
          <h2>{ko ? 'Linux 팩을 받는 중' : 'Linux pack downloading'}</h2>
          <p>
            {ko
              ? '새 창에서 neuos-linux.tar.gz 를 받습니다. 웹 페이지는 이 PC 폴더에 직접 쓰지 못합니다. 받은 뒤 install.sh 를 실행하면 Show Apps와 바탕화면에 os.neu 아이콘이 생깁니다.'
              : 'A new tab downloads neuos-linux.tar.gz. A web page cannot write into this PC’s folders. After you run the installer, os.neu appears in Show Apps and on the Desktop.'}
          </p>
          <code className="install-cmd">tar -xzf neuos-linux.tar.gz && bash os.neu-linux/install.sh</code>
          <StepNav onBack={() => setStep('choice')} onNext={() => neu.go('post')} />
        </div>
      ) : null}

      {step === 'os-miss' ? (
        <div className="dialog-card">
          <h2>{ko ? '이 운영체제용 파일이 없습니다' : 'No pack for this OS yet'}</h2>
          <p>
            {ko
              ? `이 브라우저는 ${guestOs || 'unknown'} 로 보입니다. 지금 심기·앱 아이콘·독립 스크린은 Linux만 됩니다. Windows·macOS·ChromeOS 는 각 OS용 설치 파일이 따로 필요합니다. 웹 사이트는 CPU/RAM 하드웨어를 읽지 않습니다.`
              : `This browser looks like ${guestOs || 'unknown'}. Plant, app icon, and the independent screen are Linux only today. Windows, macOS, and ChromeOS need their own installers. The public site does not read CPU or RAM.`}
          </p>
          <StepNav onBack={() => setStep('choice')} onNext={() => neu.go('post')} />
        </div>
      ) : null}
    </section>
  )
}
