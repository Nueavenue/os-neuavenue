import { BrandTitle } from '../components/BrandTitle'
import { ChatThread } from '../components/ChatThread'
import { LayerRail } from '../components/LayerRail'
import { PromptDock } from '../components/PromptDock'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { WEB_HOME } from '../engine/browser'
import { trackEvent } from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function LuiShell() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const active = neu.busy
    ? (['lui', 'vlm', 'orchestrator', 'driver'] as const)
    : (['lui'] as const)
  const apps = [
    { id: 'doc', label: locale === 'ko' ? '문서' : 'Docs', run: () => neu.openOffice('doc') },
    { id: 'sheet', label: locale === 'ko' ? '시트' : 'Sheets', run: () => neu.openOffice('sheet') },
    { id: 'slides', label: locale === 'ko' ? '슬라이드' : 'Slides', run: () => neu.openOffice('slides') },
    { id: 'web', label: locale === 'ko' ? '인터넷' : 'Web', run: () => neu.openWeb(WEB_HOME) },
  ]

  return (
    <section className="screen lui google-home">
      <StatusBar />
      <LayerRail active={[...active]} onOpen={() => neu.go('studio')} />
      <div className="lui-main google">
        <div className="lui-copy">
          <BrandTitle as="h2" wave />
          <p>{copy.askHint}</p>
        </div>
        <ChatThread
          turns={neu.chats.slice(-12)}
          empty={
            locale === 'ko'
              ? '가운데 칸에 적거나, 오른쪽 마이크로 말하면 내 말이 오른쪽에 나타납니다.'
              : 'Type in the box, or tap the mic. Your line appears on the right.'
          }
        />
        <PromptDock onSubmit={(text, opts) => void neu.submit(text, opts)} hideThread />
        <div className="office-shortcuts">
          {apps.map((app) => (
            <button
              key={app.id}
              type="button"
              className="office-shortcut"
              onClick={() => {
                void trackEvent('click', 'lui', app.id)
                app.run()
              }}
            >
              {app.label}
            </button>
          ))}
        </div>
        <div className="chips">
          {copy.chips.map((item, index) => (
            <button
              key={item}
              type="button"
              className="chip"
              onClick={() => {
                void trackEvent('click', 'lui', item)
                if (index === 0) neu.openOffice('sheet')
                else if (index === 1) neu.openWeb(WEB_HOME)
                else void neu.submit(item)
              }}
            >
              {item}
            </button>
          ))}
        </div>
        <StepNav onBack={() => neu.go('announce')} />
      </div>
    </section>
  )
}
