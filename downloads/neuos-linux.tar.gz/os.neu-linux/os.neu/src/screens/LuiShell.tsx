import { useState } from 'react'
import { BrandTitle } from '../components/BrandTitle'
import { ChatThread } from '../components/ChatThread'
import { FirstRunModelCard, firstRunLater, markFirstRunLater } from '../components/FirstRunModelCard'
import { LayerRail } from '../components/LayerRail'
import { MvpPurposeCard } from '../components/MvpPurposeCard'
import { BrowserGlyph } from '../components/PathGlyphs'
import { PromptDock } from '../components/PromptDock'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { enrichPrompt, formatWorkTime, needsPurposeConfirm, startsMvpWork } from '../engine/mvpWork'
import { stagePromptDoc } from '../engine/docProjects'
import { WEB_HOME } from '../engine/browser'
import { requestSeatRun } from '../engine/seatBus'
import { openMyWork, openSettings, setPromptDraft } from '../engine/settingsBus'
import { useAiPrefs } from '../hooks/useAiPrefs'
import { trackEvent } from '../engine/auth'
import { clearPromptTags, readPromptTags, setPromptOfficeTag } from '../engine/promptTags'
import { useI18n } from '../i18n/LocaleContext'
import { useMvpWork } from '../state/mvpWorkContext'
import { useNeu } from '../state/neuContext'

const MVP_CHIPS_KO = ['서비스 비교 보고서', '자료로 문서 만들기'] as const
const MVP_CHIPS_EN = ['Service comparison report', 'Make a document from sources'] as const

export function LuiShell({ embedded = false }: { embedded?: boolean } = {}) {
  const neu = useNeu()
  const mvp = useMvpWork()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const active = neu.busy
    ? (['lui', 'vlm', 'orchestrator', 'driver'] as const)
    : (['lui'] as const)
  const askHint = ko
    ? '오늘 어떤 일을 시작할까요?'
    : locale === 'en'
      ? 'What would you like to start today?'
      : copy.askHint
  const chips = ko ? MVP_CHIPS_KO : locale === 'en' ? MVP_CHIPS_EN : copy.chips
  const recent = mvp.works.slice(0, 3)
  const prefs = useAiPrefs()
  const noModel = !prefs.defaultModel
  const [modelGate, setModelGate] = useState<{ line: string; office: 'doc' | null } | null>(null)
  const [later, setLater] = useState(firstRunLater)

  const pickModel = (line: string) => {
    setModelGate(null)
    setPromptDraft(line)
    openSettings('ai')
  }

  const beginWork = (prompt: string, audience = mvp.pending?.audience || '', audienceNote = mvp.pending?.audienceNote || '') => {
    const draft = {
      prompt,
      audience: audience as 'team' | 'customer' | 'other' | '',
      audienceNote,
      docId: null as string | null,
      title: '',
      id: '',
      sources: [],
      createdAt: 0,
      updatedAt: 0,
      savedAt: null,
    }
    clearPromptTags()
    const instruction = enrichPrompt(draft)
    const node = stagePromptDoc(instruction)
    try {
      sessionStorage.setItem('os.neu.seat.file', node.id)
    } catch {
      /* private mode */
    }
    mvp.startWork({
      prompt,
      audience: draft.audience,
      audienceNote,
      docId: node.id,
    })
    requestSeatRun({
      text: instruction,
      model: neu.officeModel,
      account: neu.account,
      phase: neu.phase,
      online: neu.network.online,
      fileId: node.id,
      webHref: null,
    })
    void trackEvent('click', 'lui', 'mvp-start')
    neu.openOffice('doc')
  }

  const onSubmit = async (text: string, opts?: { userId?: string }) => {
    const line = text.trim()
    if (!line) return
    const tags = readPromptTags()
    const office = tags.office === 'doc' || tags.include === 'doc' ? 'doc' : null
    if (startsMvpWork(line, office)) {
      if (noModel && !later) {
        setModelGate({ line, office })
        void trackEvent('click', 'lui', 'first-run-model')
        return
      }
      startFlow(line, office)
      return
    }
    await neu.submit(line, opts)
  }

  const startFlow = (line: string, office: 'doc' | null) => {
    if (needsPurposeConfirm(line, office)) {
      mvp.setPending({ prompt: line, audience: '', audienceNote: '' })
      void trackEvent('click', 'lui', 'mvp-purpose')
      return
    }
    beginWork(line)
  }

  const chipText = (item: string) => {
    if (item === MVP_CHIPS_KO[0] || item === MVP_CHIPS_EN[0]) {
      return ko
        ? '고객관리 서비스 세 곳을 비교해서 우리 팀에 맞는 보고서를 만들어 줘.'
        : 'Compare three CRM services and write a report for our team.'
    }
    if (item === MVP_CHIPS_KO[1] || item === MVP_CHIPS_EN[1]) {
      return ko
        ? '웹에서 찾은 자료로 짧은 업무 보고서를 만들어 줘.'
        : 'Make a short work report from web sources.'
    }
    return item
  }

  return (
    <section className={`screen lui google-home${embedded ? ' embedded' : ''}`}>
      {embedded ? null : <StatusBar />}
      <LayerRail active={[...active]} onOpen={() => neu.go('studio')} />
      <div className="lui-main google bolt-spacing">
        <div className="lui-copy">
          <BrandTitle as="h2" wave />
          <p>{askHint}</p>
        </div>
        {noModel && later && !modelGate ? (
          <p className="settings-note" role="status">
            {ko ? '아직 켜진 AI가 없습니다. 초안이 시작되지 않습니다. ' : "No AI is on yet — drafts won't start. "}
            <button type="button" className="chip" onClick={() => openSettings('ai')}>
              {ko ? 'AI 고르기' : 'Pick AI'}
            </button>
          </p>
        ) : null}
        <PromptDock onSubmit={(text, opts) => void onSubmit(text, opts)} hideThread tall />
        <div className="mvp-office-row" aria-label={ko ? '문서·시트·슬라이드 — 프롬프트에 넣기' : 'Docs / Sheets / Slides — add to prompt'}>
          {(['doc', 'sheet', 'slides'] as const).map((app) => (
            <button key={app} type="button" className="chip" onClick={() => setPromptOfficeTag(app)}>
              {app === 'doc' ? (ko ? '문서' : 'Docs') : app === 'sheet' ? (ko ? '시트' : 'Sheets') : ko ? '슬라이드' : 'Slides'}
            </button>
          ))}
          <button
            type="button"
            className="chip is-browser"
            onClick={() => {
              void trackEvent('click', 'lui', 'web')
              neu.openDaf(WEB_HOME)
            }}
          >
            <BrowserGlyph /> daf.neu
          </button>
        </div>
        <div className="home-console-well">
          <p className="home-console-label">output · console operation system</p>
          <div className="home-console-plugins">
            <button
              type="button"
              onClick={() => {
                const href = window.prompt(ko ? '웹 주소' : 'Link URL', 'https://')
                if (href && href.trim() && href !== 'https://') neu.openDaf(href.trim())
              }}
            >
              {ko ? 'URL 연결' : 'Link URL'}
            </button>
            <button
              type="button"
              onClick={() => document.getElementById('osneu-console-file')?.click()}
            >
              {ko ? '파일 연결' : 'Link file'}
            </button>
            <button type="button" onClick={() => openMyWork()}>
              {ko ? 'app.neu에서 찾기' : 'Find in app.neu'}
            </button>
            <input
              id="osneu-console-file"
              type="file"
              hidden
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) setPromptDraft(file.name)
                e.currentTarget.value = ''
              }}
            />
          </div>
          <div id="osneu-home-console" className="home-console" />
          {modelGate ? (
            <FirstRunModelCard
              prompt={modelGate.line}
              onConnect={() => pickModel(modelGate.line)}
              onLocal={() => pickModel(modelGate.line)}
              onLater={() => {
                const gate = modelGate
                markFirstRunLater()
                setLater(true)
                setModelGate(null)
                startFlow(gate.line, gate.office)
              }}
            />
          ) : mvp.pending ? (
            <MvpPurposeCard
              onEdit={() => {
                const text = mvp.pending?.prompt || ''
                mvp.setPending(null)
                setPromptDraft(text)
              }}
              onStart={() => {
                if (!mvp.pending) return
                beginWork(mvp.pending.prompt, mvp.pending.audience, mvp.pending.audienceNote)
              }}
            />
          ) : (
            <ChatThread
              turns={neu.chats.slice(-12)}
              empty={
                ko
                  ? '프롬프트 아래 콘솔에 답이 나타납니다. 비교·보고서는 자료 확인과 문서 작성으로 이어집니다.'
                  : 'Answers land in the console under the prompt. Comparison reports continue into sources and a document.'
              }
            />
          )}
        </div>
        {recent.length ? (
          <div className="mvp-recent" aria-label={ko ? '최근 작업' : 'Recent work'}>
            <p className="mvp-recent-label">{ko ? '최근 작업' : 'Recent work'}</p>
            {recent.map((row) => (
              <button
                key={row.id}
                type="button"
                className="mvp-recent-item"
                onClick={() => {
                  mvp.openWork(row.id)
                  neu.openOffice('doc')
                }}
              >
                <span>{row.title}</span>
                <small>{formatWorkTime(row, ko)} · {ko ? '이어하기' : 'Continue'}</small>
              </button>
            ))}
          </div>
        ) : null}
        <div className="chips">
          {chips.map((item) => (
            <button
              key={item}
              type="button"
              className="chip"
              onClick={() => {
                void trackEvent('click', 'lui', item)
                void onSubmit(chipText(item))
              }}
            >
              {item}
            </button>
          ))}
        </div>
        {embedded ? null : <StepNav onBack={() => neu.go('announce')} />}
      </div>
    </section>
  )
}
