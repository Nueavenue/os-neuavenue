import { ChatThread, type ChatBubble } from '../components/ChatThread'
import { CrmDialog, CrmGlyph } from '../components/CrmDialog'
import { HardwareMenu } from '../components/HardwareMenu'
import { PromptDock } from '../components/PromptDock'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { TopicMenu } from '../components/TopicMenu'
import { askJeos } from '../engine/bridge'
import { useAppVersionLabel } from '../hooks/useAppVersionLabel'
import { rememberCoach, speakBrowser } from '../engine/coachAudio'
import {
  findTopic,
  greetingFor,
  loadTalkPack,
  saveTalkPack,
  type ConsoleTopic,
  type TalkPack,
} from '../engine/consoleTopics'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'
import { useEffect, useState } from 'react'

export function JeosLoop() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const ver = useAppVersionLabel()
  const email = neu.account?.email || null
  const [pack, setPack] = useState(() => loadTalkPack(email))
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState(ko ? 'hardware · network · memory · 말하기' : 'hardware · network · memory · talk')
  const [crmOpen, setCrmOpen] = useState(false)

  useEffect(() => {
    setPack(loadTalkPack(email))
  }, [email])

  const commit = (next: TalkPack) => {
    setPack(next)
    saveTalkPack(email, next)
  }

  const topic = findTopic(pack, pack.activeTopicId)
  const turns = pack.threads[topic.id] ?? [greetingFor(topic, ko)]

  const persistTurns = (id: string, nextTurns: ChatBubble[]) => {
    setPack((prev) => {
      const next = { ...prev, threads: { ...prev.threads, [id]: nextTurns } }
      saveTalkPack(email, next)
      return next
    })
  }

  useEffect(() => {
    const dump = neu.seatDump
    if (!dump) return
    setBusy(!dump.done)
    const topicId = pack.activeTopicId
    const userId = `${dump.turnId}-u`
    setPack((prev) => {
      const intro = prev.threads[topicId] ?? [greetingFor(findTopic(prev, topicId), ko)]
      const kept = intro.filter((row) => row.id !== dump.turnId && row.id !== userId)
      const body =
        dump.body ||
        (dump.done ? (ko ? '출력이 비어 있습니다.' : 'No output yet.') : ko ? '작성 중…' : 'Writing…')
      const nextTurns: ChatBubble[] = [
        ...kept,
        { id: userId, role: 'user', text: dump.ask },
        { id: dump.turnId, role: 'neu', text: body },
      ]
      const next = { ...prev, threads: { ...prev.threads, [topicId]: nextTurns } }
      if (dump.done) saveTalkPack(email, next)
      return next
    })
    setStage(ko ? '출력 · console operation system' : 'output · console operation system')
    if (dump.done) {
      neu.setSeatDump(null)
      setBusy(false)
    }
    // live dump from Draft only / OS.neu console
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [neu.seatDump])

  const pickTopic = (nextTopic: ConsoleTopic) => {
    setPack((prev) => {
      const group = prev.groups.find((row) => row.topics.some((item) => item.id === nextTopic.id))
      const next: TalkPack = {
        ...prev,
        activeTopicId: nextTopic.id,
        activeGroupId: group?.id || prev.activeGroupId,
        threads: prev.threads[nextTopic.id]?.length
          ? prev.threads
          : { ...prev.threads, [nextTopic.id]: [greetingFor(nextTopic, ko)] },
      }
      saveTalkPack(email, next)
      return next
    })
  }

  const send = async (text: string, target: ConsoleTopic = topic) => {
    const raw = text.trim()
    if (!raw || busy) return
    setBusy(true)
    const userTurn: ChatBubble = { id: `u-${Date.now()}`, role: 'user', text: raw }
    const base = (pack.threads[target.id] ?? [greetingFor(target, ko)]).concat(userTurn)
    persistTurns(target.id, base)
    try {
      const result = await askJeos(raw)
      setStage(result.health.stage ?? result.act)
      if (result.act === 'lui') {
        neu.chooseLoop()
        return
      }
      const reply = result.reply.trim() || result.act
      persistTurns(target.id, [...base, { id: `n-${Date.now()}`, role: 'neu', text: reply }])
      if (result.act === 'coach' || neu.network.online) {
        rememberCoach(reply)
        if (neu.network.online) speakBrowser(reply)
      }
    } catch {
      persistTurns(target.id, [...base, { id: `e-${Date.now()}`, role: 'neu', text: 'OS.neu is unreachable' }])
    } finally {
      setBusy(false)
    }
  }

  const leadTopic = (next: ConsoleTopic) => {
    pickTopic(next)
    void send(locale === 'ko' ? next.seed : next.seedEn, next)
  }

  return (
    <section className="screen jeos-loop">
      <StatusBar />
      <HardwareMenu />
      <TopicMenu
        pack={pack}
        account={neu.account}
        onPack={commit}
        onPick={pickTopic}
        onAsk={leadTopic}
        onSignIn={() => neu.setAuthPanel('login')}
      />
      <div className="jeos-head">
        <h2>OS.neu {ver}</h2>
        <p>{ko ? '가운데에서 말하고, 오른쪽 칸에서 주제를 고릅니다.' : 'Talk in the center. Pick a topic on the right tile.'}</p>
        <span className="pill ok">{stage}</span>
      </div>
      <article className="jeos-chat">
        <header className="jeos-chat-head">
          <div>
            <small>{ko ? '콘솔' : 'Console'}</small>
            <b>{ko ? topic.title : topic.titleEn}</b>
          </div>
          <button
            type="button"
            className="crm-launch"
            onClick={() => setCrmOpen(true)}
            aria-label={ko ? 'neuCRM 열기' : 'Open neuCRM'}
            title={ko ? 'neuCRM — 프로모션 · 캠페인' : 'neuCRM — promotion and campaign'}
          >
            <CrmGlyph />
          </button>
        </header>
        <ChatThread turns={turns.slice(-16)} />
      </article>
      <StepNav onBack={() => neu.go('announce')} onNext={() => neu.chooseLoop()} />
      <PromptDock onSubmit={(text) => void send(text)} disabled={busy} placeholder={`Speak or type to os.neu ${ver}`} hideThread />
      <CrmDialog open={crmOpen} onClose={() => setCrmOpen(false)} />
    </section>
  )
}
