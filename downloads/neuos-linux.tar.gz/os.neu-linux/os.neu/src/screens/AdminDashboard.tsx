import { useEffect, useState } from 'react'
import { fetchAdminStats } from '../engine/auth'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { useNeu } from '../state/store'
import { useI18n } from '../i18n/LocaleContext'

type Stats = {
  users?: Array<{ email: string; first: number; last: number; views: number; clicks: number; logins: number; logouts: number }>
  clicks?: Record<string, number>
  logoutScreens?: Record<string, number>
  screens?: Record<string, number>
  events?: Array<{ t: number; email?: string; kind: string; screen: string; label?: string }>
  feedback?: Array<{ t: number; name?: string; email?: string; title: string; body: string }>
  totals?: { events: number; users: number; feedback: number }
}

function when(t: number) {
  return new Date(t).toLocaleString()
}

export function AdminDashboard() {
  const neu = useNeu()
  const { locale } = useI18n()
  const [stats, setStats] = useState<Stats | null>(null)
  const [error, setError] = useState('')
  const ko = locale === 'ko'

  useEffect(() => {
    void fetchAdminStats().then((body) => {
      if (!body || body.ok === false) {
        setError(String(body?.reason || 'admin-only'))
        return
      }
      setStats(body as Stats)
    })
  }, [])

  if (!neu.account?.admin) {
    return (
      <section className="screen lui">
        <StatusBar />
        <p className="wa-empty">{ko ? '관리자만 볼 수 있습니다.' : 'Admins only.'}</p>
        <StepNav onBack={() => neu.goBack()} />
      </section>
    )
  }

  return (
    <section className="screen admin">
      <StatusBar />
      <div className="admin-wrap">
        <h2>{ko ? '관리자 대시보드' : 'Admin dashboard'}</h2>
        <p>{ko ? '일반 사용자에게는 이 화면과 아이콘이 보이지 않습니다.' : 'Hidden from regular users.'}</p>
        {error ? <p className="plant-error">{error}</p> : null}
        <div className="admin-kpis">
          <div><b>{stats?.totals?.users ?? 0}</b><span>{ko ? '유입 사용자' : 'Users'}</span></div>
          <div><b>{stats?.totals?.events ?? 0}</b><span>{ko ? '이벤트' : 'Events'}</span></div>
          <div><b>{stats?.totals?.feedback ?? 0}</b><span>{ko ? '피드백' : 'Feedback'}</span></div>
        </div>
        <h3>{ko ? '사용자 유입 시간' : 'Inflow times'}</h3>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Email</th>
              <th>{ko ? '처음' : 'First'}</th>
              <th>{ko ? '최근' : 'Last'}</th>
              <th>Views</th>
              <th>Clicks</th>
              <th>Login</th>
              <th>Logout</th>
            </tr>
          </thead>
          <tbody>
            {(stats?.users ?? []).map((row) => (
              <tr key={row.email}>
                <td>{row.email}</td>
                <td>{when(row.first)}</td>
                <td>{when(row.last)}</td>
                <td>{row.views}</td>
                <td>{row.clicks}</td>
                <td>{row.logins}</td>
                <td>{row.logouts}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="admin-grid">
          <div>
            <h3>{ko ? '버튼 클릭' : 'Button clicks'}</h3>
            <ul>
              {Object.entries(stats?.clicks ?? {}).map(([key, n]) => (
                <li key={key}>{key}: {n}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3>{ko ? '로그아웃 화면' : 'Logout screens'}</h3>
            <ul>
              {Object.entries(stats?.logoutScreens ?? {}).map(([key, n]) => (
                <li key={key}>{key}: {n}</li>
              ))}
            </ul>
          </div>
        </div>
        <h3>{ko ? '피드백 게시판' : 'Feedback board'}</h3>
        {(stats?.feedback ?? []).map((post) => (
          <article key={post.t + post.title} className="feedback-card">
            <b>{post.title}</b>
            <small>{post.name || post.email || 'anon'} · {when(post.t)}</small>
            <p>{post.body}</p>
          </article>
        ))}
        <StepNav onBack={() => neu.goBack()} />
      </div>
    </section>
  )
}
