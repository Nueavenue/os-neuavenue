import { useEffect } from 'react'

/** Keep F11 from fighting the in-app ×. Do not go fullscreen on a click or drag. */
export function useScreen() {
  useEffect(() => {
    const blockMenu = (event: Event) => event.preventDefault()
    document.addEventListener('contextmenu', blockMenu)

    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'F11') event.preventDefault()
    }
    window.addEventListener('keydown', onKey)

    return () => {
      document.removeEventListener('contextmenu', blockMenu)
      window.removeEventListener('keydown', onKey)
    }
  }, [])
}
