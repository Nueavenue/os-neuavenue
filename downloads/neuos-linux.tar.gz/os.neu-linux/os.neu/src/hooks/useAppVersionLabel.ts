import { useEffect, useState } from 'react'
import { appVersionLabel, resolveAppVersionLabel } from '../engine/appVersion'

/** Brand / chrome version: vite bake first, then Electron package version. */
export function useAppVersionLabel(): string {
  const [ver, setVer] = useState(appVersionLabel)
  useEffect(() => {
    let cancelled = false
    void resolveAppVersionLabel().then((next) => {
      if (!cancelled) setVer(next)
    })
    return () => {
      cancelled = true
    }
  }, [])
  return ver
}
