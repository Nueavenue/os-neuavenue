import { useEffect, useState } from 'react'
import { loadAiPrefs, loadUsage, type AiPrefs, type AiUsage } from '../engine/aiPrefs'

export function useAiPrefs(): AiPrefs {
  const [prefs, setPrefs] = useState(() => loadAiPrefs())
  useEffect(() => {
    const refresh = () => setPrefs(loadAiPrefs())
    window.addEventListener('osneu:ai-prefs', refresh)
    window.addEventListener('storage', refresh)
    return () => {
      window.removeEventListener('osneu:ai-prefs', refresh)
      window.removeEventListener('storage', refresh)
    }
  }, [])
  return prefs
}

export function useAiUsage(): AiUsage {
  const [usage, setUsage] = useState(() => loadUsage())
  useEffect(() => {
    const refresh = () => setUsage(loadUsage())
    window.addEventListener('osneu:ai-usage', refresh)
    return () => window.removeEventListener('osneu:ai-usage', refresh)
  }, [])
  return usage
}
