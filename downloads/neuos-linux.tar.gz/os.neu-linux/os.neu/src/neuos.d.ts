export type BrowseRect = { x: number; y: number; width: number; height: number }

export type BrowseDownload = {
  id: string
  filename: string
  url: string
  path?: string
  mime?: string
  bytes?: number
  received?: number
  state: 'progress' | 'done' | 'failed' | 'cancelled'
  t: number
}

export type NeuosBrowse = {
  go: (url: string) => Promise<{ ok: boolean; href?: string; reason?: string; restored?: boolean }>
  hide: () => Promise<{ ok: boolean }>
  bounds: (rect: BrowseRect) => Promise<{ ok: boolean }>
  back?: () => Promise<{ ok: boolean; href?: string }>
  newWindow?: (url?: string) => Promise<{ ok: boolean }>
  onDownload?: (cb: (row: BrowseDownload) => void) => () => void
  openDownload?: (id: string) => Promise<{ ok: boolean }>
  showDownload?: (id: string) => Promise<{ ok: boolean }>
  devtools?: (rect: BrowseRect | null) => Promise<{ ok: boolean }>
}

export type NeuosPlant = {
  pick: () => Promise<{ ok: boolean; path?: string }>
  defaultPath: () => Promise<{ ok: boolean; path?: string }>
}

declare global {
  interface Window {
    neuos?: {
      browse: NeuosBrowse
      plant?: NeuosPlant
      quit?: () => Promise<{ ok: boolean }>
      setFullscreen?: (on: boolean) => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      windowState?: () => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      windowMode?: () => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      setWindowMode?: (mode: 'windowed' | 'maximized' | 'fullscreen') => Promise<{
        ok: boolean
        fullscreen?: boolean
        maximized?: boolean
      }>
    }
  }
}

export {}
