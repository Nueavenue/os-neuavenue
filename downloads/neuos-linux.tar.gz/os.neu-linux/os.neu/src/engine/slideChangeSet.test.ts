import { describe, expect, it } from 'vitest'
import { wantsFullDeckReplace, type RecipeSlide } from './slidesRecipe'
import {
  applyChangeSet,
  canApply,
  proposeCreateSlide,
  proposeDeckRewrite,
  proposeDeleteSlides,
  proposeDuplicateSlide,
  proposeElementEdit,
  proposeMergeSlides,
  proposeQaFix,
  proposeUnavailable,
  proposeVerifyFact,
  qaSummaryText,
  rejectChangeSet,
  restoreVersion,
  runQa,
  snapshotVersion,
  undoVersion,
  withDeckConfirm,
} from './slideChangeSet'
import { FIT_BUDGETS } from './contentFitter'

const deck: RecipeSlide[] = [
  { layout: 'title', title: 'Cover', body: 'Hello', bullets: [], table: null },
  {
    layout: 'bullets',
    title: 'Why',
    body: 'Fast\nLocal\nPrivate',
    bullets: ['Fast', 'Local', 'Private'],
    table: null,
  },
  {
    layout: 'table',
    title: 'Numbers',
    body: '',
    bullets: [],
    table: { headers: ['Metric', 'Value'], rows: [['Users', '10']] },
  },
]

function snap(slides: RecipeSlide[]) {
  return JSON.stringify(slides)
}

describe('slideChangeSet', () => {
  it('element edit with "10 slides" in the extra does not replace other slides', () => {
    const extra = 'Please make 10 slides about the market'
    expect(wantsFullDeckReplace(extra)).toBe(true)
    const others = snap(deck.slice(1))
    const change = proposeElementEdit(deck, 0, { kind: 'title' }, 'New cover', {
      extra,
      reason: extra,
    })
    expect(change.scope).toBe('element')
    expect(change.afterSlides[0].title).toBe('New cover')
    expect(change.afterSlides[0].body).toBe('Hello')
    expect(snap(change.afterSlides.slice(1))).toBe(others)
    const applied = applyChangeSet(change, false)
    expect(applied.ok).toBe(true)
    if (applied.ok) expect(snap(applied.slides.slice(1))).toBe(others)
  })

  it('reject leaves the live deck to the caller; apply writes only the ChangeSet afterSlides', () => {
    const change = proposeDeleteSlides(deck, [1])
    expect(change.status).toBe('proposed')
    expect(change.afterSlides).toHaveLength(2)
    const rejected = rejectChangeSet(change)
    expect(rejected.status).toBe('rejected')
    expect(deck).toHaveLength(3)
    const applied = applyChangeSet(change, false)
    expect(applied.ok).toBe(true)
    if (applied.ok) {
      expect(applied.slides.map((s) => s.title)).toEqual(['Cover', 'Numbers'])
      expect(applied.slides).toHaveLength(2)
    }
  })

  it('undo after delete restore puts the slide back', () => {
    const v0 = snapshotVersion(deck, 0, 'start')
    const del = proposeDeleteSlides(deck, [1])
    const applied = applyChangeSet(del, false)
    expect(applied.ok).toBe(true)
    if (!applied.ok) return
    const v1 = snapshotVersion(applied.slides, applied.index, 'deleted')
    const versions = [v0, v1]
    const undone = undoVersion(versions, 1)
    expect(undone?.snap.slides.map((s) => s.title)).toEqual(['Cover', 'Why', 'Numbers'])
    const restored = restoreVersion(versions, v0.id)
    expect(restored?.snap.slides).toHaveLength(3)
  })

  it('create is blocked at MAX_SLIDES', () => {
    const full = Array.from({ length: 20 }, (_, i) => ({
      layout: 'title' as const,
      title: `S${i}`,
      body: '',
      bullets: [] as string[],
      table: null,
    }))
    const change = proposeCreateSlide(full, 0)
    expect(change.applyBlocked).toBe('cap')
    expect(applyChangeSet(change, false).ok).toBe(false)
    expect(proposeDuplicateSlide(full, 0).applyBlocked).toBe('cap')
  })

  it('merge keeps MAX_BULLETS and says so', () => {
    const long: RecipeSlide[] = [
      { layout: 'bullets', title: 'A', body: '1\n2\n3\n4', bullets: ['1', '2', '3', '4'], table: null },
      { layout: 'bullets', title: 'B', body: '5\n6\n7', bullets: ['5', '6', '7'], table: null },
    ]
    const change = proposeMergeSlides(long, 0, 1)
    expect(change.afterSlides).toHaveLength(1)
    expect(change.afterSlides[0].body.split('\n')).toHaveLength(6)
    expect(change.capMessage).toMatch(/6/)
  })

  it('entire-deck rewrite needs confirm', () => {
    const next = [{ layout: 'title' as const, title: 'Only', body: '', bullets: [], table: null }]
    const change = proposeDeckRewrite(deck, next, false, 'rewrite deck')
    expect(change.applyBlocked).toBe('needs-confirm')
    expect(canApply(change, false)).toBe(false)
    const confirmed = withDeckConfirm(change, true)
    expect(canApply(confirmed, true)).toBe(true)
  })

  it('QA lists a real overflow and does not claim a grammar check', () => {
    const overflowTitle = 'T'.repeat(FIT_BUDGETS.title.titleChars + 8)
    const slides: RecipeSlide[] = [
      { layout: 'title', title: overflowTitle, body: 'Hi', bullets: [], table: null },
      { layout: 'title', title: '', body: 'x', bullets: [], table: null },
      { layout: 'title', title: 'Same', body: '', bullets: [], table: null },
      { layout: 'title', title: 'Same', body: '', bullets: [], table: null },
    ]
    const qa = runQa(slides)
    expect(qa.ran).toEqual(['overflow', 'empty-title', 'duplicate-title'])
    expect(qa.ran.join(' ')).not.toMatch(/grammar/i)
    expect(qa.findings.some((row) => row.check === 'overflow' && row.slideIndex === 0)).toBe(true)
    expect(qa.findings.some((row) => row.check === 'empty-title')).toBe(true)
    expect(qa.findings.some((row) => row.check === 'duplicate-title')).toBe(true)
    const summary = qaSummaryText(qa.findings, qa.ran, false)
    expect(summary).toMatch(/overflow/)
    expect(summary).not.toMatch(/grammar/i)
    const fix = proposeQaFix(slides, qa.findings.find((row) => row.check === 'overflow')!)
    expect(fix?.action).toBe('FIX_OVERFLOW')
    expect((fix?.afterSlides[0].title || '').length).toBeLessThanOrEqual(FIT_BUDGETS.title.titleChars)
  })

  it('VERIFY_FACT on a number with no source does not write a new number', () => {
    const change = proposeVerifyFact(deck, 2, { kind: 'cell', row: 0, col: 1 })
    expect(change.action).toBe('VERIFY_FACT')
    expect(change.applyBlocked).toBe('unverified')
    expect(change.after).toBe(change.before)
    expect(change.after).toBe('10')
    expect(applyChangeSet(change, false).ok).toBe(false)
    expect(change.afterSlides[2].table?.rows[0][1]).toBe('10')
  })

  it('image/chart/freeform stay unapplyable', () => {
    const change = proposeUnavailable(deck, 0, 'IMAGE')
    expect(change.applyBlocked).toBe('unavailable')
    expect(applyChangeSet(change, true).ok).toBe(false)
  })
})
