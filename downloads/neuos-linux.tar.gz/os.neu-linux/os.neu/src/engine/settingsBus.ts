import type { OfficeApp } from './office'

export type SettingsSection = 'power' | 'ai' | 'privacy' | 'help'

const OPEN_SETTINGS = 'osneu:open-settings'
const SETTINGS_VISIBILITY = 'osneu:settings-visibility'
const PICK_MODEL = 'osneu:pick-model'

export function openSettings(section: SettingsSection = 'ai') {
  window.dispatchEvent(new CustomEvent<SettingsSection>(OPEN_SETTINGS, { detail: section }))
}

export function onOpenSettings(handler: (section: SettingsSection) => void) {
  const listener = (event: Event) => handler((event as CustomEvent<SettingsSection>).detail || 'ai')
  window.addEventListener(OPEN_SETTINGS, listener)
  return () => window.removeEventListener(OPEN_SETTINGS, listener)
}

export function publishSettingsVisibility(open: boolean) {
  publishShellOverlay('settings', open)
  window.dispatchEvent(new CustomEvent<boolean>(SETTINGS_VISIBILITY, { detail: open }))
}

export function onSettingsVisibility(handler: (open: boolean) => void) {
  const listener = (event: Event) => handler(Boolean((event as CustomEvent<boolean>).detail))
  window.addEventListener(SETTINGS_VISIBILITY, listener)
  return () => window.removeEventListener(SETTINGS_VISIBILITY, listener)
}

/** HTML overlays that must hide Electron's daf.neu BrowserView (it paints above the page). */
export type ShellOverlayId = 'settings' | 'crm' | 'model-pick' | 'my-work' | 'ai-connect'

const SHELL_OVERLAY = 'osneu:shell-overlay'
const shellOverlays = new Set<ShellOverlayId>()

function emitShellOverlay() {
  window.dispatchEvent(new CustomEvent<boolean>(SHELL_OVERLAY, { detail: shellOverlays.size > 0 }))
}

export function publishShellOverlay(id: ShellOverlayId, open: boolean) {
  if (open) shellOverlays.add(id)
  else shellOverlays.delete(id)
  emitShellOverlay()
}

export function onShellOverlay(handler: (open: boolean) => void) {
  const listener = (event: Event) => handler(Boolean((event as CustomEvent<boolean>).detail))
  window.addEventListener(SHELL_OVERLAY, listener)
  return () => window.removeEventListener(SHELL_OVERLAY, listener)
}

const PROMPT_DRAFT = 'osneu:prompt-draft'

/** Put text back into the home prompt box (for example after Edit on the purpose card). */
export function setPromptDraft(text: string) {
  window.dispatchEvent(new CustomEvent<string>(PROMPT_DRAFT, { detail: text }))
}

export function onPromptDraft(handler: (text: string) => void) {
  const listener = (event: Event) => handler((event as CustomEvent<string>).detail || '')
  window.addEventListener(PROMPT_DRAFT, listener)
  return () => window.removeEventListener(PROMPT_DRAFT, listener)
}

const OPEN_MY_WORK = 'osneu:open-my-work'

export function openMyWork() {
  window.dispatchEvent(new CustomEvent(OPEN_MY_WORK))
}

export function onOpenMyWork(handler: () => void) {
  window.addEventListener(OPEN_MY_WORK, handler)
  return () => window.removeEventListener(OPEN_MY_WORK, handler)
}

/** Docs / Sheets / Slides buttons ask which model to use before opening the app. */
export function requestModelPick(app: OfficeApp) {
  window.dispatchEvent(new CustomEvent<OfficeApp>(PICK_MODEL, { detail: app }))
}

export function onModelPick(handler: (app: OfficeApp) => void) {
  const listener = (event: Event) => handler((event as CustomEvent<OfficeApp>).detail || 'doc')
  window.addEventListener(PICK_MODEL, listener)
  return () => window.removeEventListener(PICK_MODEL, listener)
}
