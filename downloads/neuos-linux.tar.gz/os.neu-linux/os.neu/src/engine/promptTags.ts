import type { PromptOffice } from './promptParse'

export type PromptInclude = PromptOffice | 'daf'

export type PromptTagState = {
  office: PromptOffice | null
  include: PromptInclude | null
  slidesTemplateId: string | null
  slidesTemplateName: string | null
}

const EMPTY: PromptTagState = {
  office: null,
  include: null,
  slidesTemplateId: null,
  slidesTemplateName: null,
}

let state: PromptTagState = { ...EMPTY }
const listeners = new Set<(next: PromptTagState) => void>()

function publish() {
  const snap = { ...state }
  listeners.forEach((listen) => listen(snap))
}

export function readPromptTags(): PromptTagState {
  return { ...state }
}

export function onPromptTags(listen: (next: PromptTagState) => void) {
  listeners.add(listen)
  listen({ ...state })
  return () => {
    listeners.delete(listen)
  }
}

export function setPromptOfficeTag(office: PromptOffice | null) {
  state = {
    office,
    include: office,
    slidesTemplateId: office === 'slides' ? state.slidesTemplateId : null,
    slidesTemplateName: office === 'slides' ? state.slidesTemplateName : null,
  }
  publish()
}

export function setPromptDafInclude() {
  state = { ...EMPTY, include: 'daf' }
  publish()
}

export function setPromptSlidesTemplate(id: string | null, name?: string | null) {
  state = {
    office: id ? 'slides' : state.office,
    include: id ? 'slides' : state.include,
    slidesTemplateId: id,
    slidesTemplateName: name || id,
  }
  publish()
}

export function clearPromptTags() {
  state = { ...EMPTY }
  publish()
}

export function tagLabel(office: PromptOffice, ko: boolean) {
  if (office === 'doc') return ko ? '문서' : 'Docs'
  if (office === 'sheet') return ko ? '시트' : 'Sheets'
  return ko ? '슬라이드' : 'Slides'
}

/** Chip inside the prompt box. English on purpose so the app name is recognized. */
export function includeChip(include: PromptInclude | null): string {
  if (include === 'doc') return 'Docs included'
  if (include === 'sheet') return 'Sheets included'
  if (include === 'slides') return 'Slides included'
  if (include === 'daf') return 'daf.neu included'
  return ''
}
