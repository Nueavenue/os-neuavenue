export const HOME_HOST = 'os.neu.local'
export const WEB_HOME = 'https://www.neuavenue.com'
export const GOOGLE_SIGNIN = 'https://accounts.google.com/ServiceLogin'

const HOME_ALIASES = ['os.neu.local', 'neuos.local']

export type Address =
  | { kind: 'home' }
  | { kind: 'url'; href: string }
  | { kind: 'invalid'; reason: string }

const BLOCKED = /^(javascript|data|file|vbscript|blob):/i
const DOMAIN = /^(localhost(:\d+)?|(\d{1,3}\.){3}\d{1,3}(:\d+)?|[a-z0-9-]+(\.[a-z0-9-]+)+)(:\d+)?([/:?#].*)?$/i
const LOCAL = /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])/i

export function normalizeAddress(raw: string): Address {
  const trimmed = raw.trim()
  if (!trimmed) return { kind: 'home' }
  if (HOME_ALIASES.some((host) => trimmed.toLowerCase().includes(host))) return { kind: 'home' }
  if (BLOCKED.test(trimmed)) {
    return { kind: 'invalid', reason: 'This kind of address cannot be opened.' }
  }

  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const url = new URL(trimmed)
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        return { kind: 'invalid', reason: 'Only http or https can be opened.' }
      }
      return { kind: 'url', href: url.toString() }
    } catch {
      return { kind: 'invalid', reason: 'Could not read that address.' }
    }
  }

  if (DOMAIN.test(trimmed)) {
    const protocol = LOCAL.test(trimmed) ? 'http' : 'https'
    return { kind: 'url', href: new URL(`${protocol}://${trimmed}`).toString() }
  }

  return {
    kind: 'url',
    href: `https://html.duckduckgo.com/html/?q=${encodeURIComponent(trimmed)}`,
  }
}

export function proxySrc(href: string): string {
  return `/api/browse?url=${encodeURIComponent(href)}`
}

export function isAuthHost(href: string): boolean {
  try {
    const url = new URL(href)
    const host = url.hostname
    if (host === 'accounts.google.com' || host === 'accounts.youtube.com') return true
    if (host === 'login.microsoftonline.com' || host === 'login.live.com') return true
    if (host === 'appleid.apple.com') return true
    if (host === 'github.com' && url.pathname.startsWith('/login')) return true
    return false
  } catch {
    return false
  }
}

export function googleLoginInIframe(href: string): boolean {
  return isAuthHost(href)
}
