export const HOME_HOST = 'os.neu.local'
export const WEB_HOME = 'https://www.neuavenue.com'
export const VITALITY_URL = 'https://www.neuavenue.com/vitality'
/**
 * Door A shareholder/Command View screen (WO-UI-NEU-COMMAND-VIEW-ICON-121 /
 * UI-B27). Screen of record lives on Door A only — this opens it via the
 * UI-B17 front-window path. Command View still opens in the system browser.
 * Site Google SSO inside daf.neu is allowed (Leader GRANT 2026-11-22); seat
 * os.neu Login remains system-browser / openExternal.
 */
export const COMMAND_VIEW_URL = 'https://neuavenue.com/?view=shareholder'
export const COMMAND_VIEW_LEADER_EMAIL = 'neuavenue@gmail.com'
export const GOOGLE_SIGNIN = 'https://accounts.google.com/ServiceLogin'

export function isCommandViewLeaderEmail(email?: string | null) {
  return (email ?? '').trim().toLowerCase() === COMMAND_VIEW_LEADER_EMAIL
}

export const COMMAND_VIEW_APP_URL = 'https://app.neuavenue.com/?view=shareholder'

/** Door A Command View after daf.neu CEO login. Carry the seat JWT so Google is not required. */
export function commandViewHref(accessToken?: string | null, refreshToken?: string | null) {
  const token = String(accessToken || '').trim()
  if (!token || token.split('.').length !== 3) return COMMAND_VIEW_APP_URL
  const parts = [`access_token=${encodeURIComponent(token)}`, 'token_type=bearer']
  const refresh = String(refreshToken || '').trim()
  if (refresh) parts.push(`refresh_token=${encodeURIComponent(refresh)}`)
  return `${COMMAND_VIEW_APP_URL}#${parts.join('&')}`
}

/** Opens Command View in Chrome. Caller must be the CEO mailbox on daf.neu. */
export function openCommandView() {
  if (typeof window === 'undefined') return
  let href = COMMAND_VIEW_APP_URL
  try {
    const access = localStorage.getItem('os.neu.token') || ''
    const refresh = localStorage.getItem('os.neu.refresh') || ''
    href = commandViewHref(access, refresh)
  } catch {
    /* ignore */
  }
  if (window.neuos?.browse?.openExternal) {
    void window.neuos.browse.openExternal(href)
    return
  }
  window.open(href, '_blank', 'noopener,noreferrer')
}

import { searchUrl, type SearchEngineId } from './searchEngines'

export { searchUrl, type SearchEngineId }

const HOME_ALIASES = ['os.neu.local', 'neuos.local']

export type Address =
  | { kind: 'home' }
  | { kind: 'url'; href: string }
  | { kind: 'invalid'; reason: string }

const BLOCKED = /^(javascript|data|file|vbscript|blob):/i
const DOMAIN = /^(localhost(:\d+)?|(\d{1,3}\.){3}\d{1,3}(:\d+)?|[a-z0-9-]+(\.[a-z0-9-]+)+)(:\d+)?([/:?#].*)?$/i
const LOCAL = /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])/i

export function normalizeAddress(raw: string, engineId?: SearchEngineId): Address {
  const trimmed = raw.trim()
  if (!trimmed) return { kind: 'home' }
  if (HOME_ALIASES.some((host) => trimmed.toLowerCase().includes(host))) return { kind: 'home' }
  if (BLOCKED.test(trimmed)) {
    return { kind: 'invalid', reason: 'This kind of address cannot be opened.' }
  }

  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const url = new URL(trimmed)
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        return { kind: 'invalid', reason: 'Only http or https can be opened.' }
      }
      return { kind: 'url', href: url.toString() }
    } catch {
      return { kind: 'invalid', reason: 'Could not read that address.' }
    }
  }

  if (DOMAIN.test(trimmed)) {
    const protocol = LOCAL.test(trimmed) ? 'http' : 'https'
    return { kind: 'url', href: new URL(`${protocol}://${trimmed}`).toString() }
  }

  return {
    kind: 'url',
    href: searchUrl(trimmed, engineId),
  }
}

export function proxySrc(href: string): string {
  return `/api/browse?url=${encodeURIComponent(href)}`
}

export function isAuthHost(href: string): boolean {
  try {
    const url = new URL(href)
    const host = url.hostname
    if (host === 'accounts.google.com' || host === 'accounts.youtube.com') return true
    if (host === 'login.microsoftonline.com' || host === 'login.live.com') return true
    if (host === 'appleid.apple.com') return true
    if (host === 'github.com' && url.pathname.startsWith('/login')) return true
    return false
  } catch {
    return false
  }
}

export function googleLoginInIframe(href: string): boolean {
  return isAuthHost(href)
}

export function isLoopbackHost(href: string): boolean {
  try {
    const host = new URL(href).hostname
    return host === 'localhost' || host === '127.0.0.1' || host === '::1'
  } catch {
    return false
  }
}

/** Ollama listen port — local API, not a surfing website. */
export function isOllamaApiUrl(href: string): boolean {
  try {
    const url = new URL(href)
    return isLoopbackHost(href) && url.port === '11434'
  } catch {
    return false
  }
}
