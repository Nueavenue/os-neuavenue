import { fetchHostProfile, type HostProfile } from './bridge'
import { inspectHardware } from './hardware'

export type UpdateFlag = 'current' | 'available' | 'unknown'

export type HardwareItem = {
  id: string
  name: string
  version: string
  features: string[]
  checkedAt: number
  update: UpdateFlag
  detail: string
}

export type HardwareGroup = {
  id: string
  label: string
  labelEn: string
  items: HardwareItem[]
}

export type HardwareInventory = {
  checkedAt: number
  groups: HardwareGroup[]
}

function gpuName() {
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl')
    if (!gl) return ''
    const info = gl.getExtension('WEBGL_debug_renderer_info')
    if (!info) return String(gl.getParameter(gl.RENDERER) || '')
    return String(gl.getParameter(info.UNMASKED_RENDERER_WEBGL) || '')
  } catch {
    return ''
  }
}

function cpuModel(cpuBrief: string | undefined, cores: number) {
  if (cpuBrief) {
    try {
      const parsed = JSON.parse(cpuBrief) as { lscpu?: Array<{ field?: string; data?: string }> }
      const model = parsed.lscpu?.find((row) => /model name/i.test(row.field || ''))?.data
      if (model) return model
    } catch {
      const line = cpuBrief.split('\n')[0]?.trim()
      if (line && line.length < 96) return line
    }
  }
  return cores > 0 ? `${cores} cores` : 'Unknown'
}

function item(
  id: string,
  name: string,
  version: string,
  features: string[],
  checkedAt: number,
  update: UpdateFlag,
  detail: string,
): HardwareItem {
  return { id, name, version, features, checkedAt, update, detail }
}

export async function loadHardwareInventory(): Promise<HardwareInventory> {
  const checkedAt = Date.now()
  const [report, host] = await Promise.all([
    inspectHardware(),
    fetchHostProfile().catch(() => null as HostProfile | null),
  ])
  const byId = Object.fromEntries(report.checks.map((row) => [row.id, row]))
  const cores = host?.cores || navigator.hardwareConcurrency || 0
  const mem = host?.memGb || (navigator as Navigator & { deviceMemory?: number }).deviceMemory
  const cpu = cpuModel(host?.cpuBrief, cores)
  const gpu = gpuName()
  const screenLabel = `${window.screen.width}×${window.screen.height}`

  const groups: HardwareGroup[] = [
    {
      id: 'system',
      label: '시스템',
      labelEn: 'System',
      items: [
        item(
          'osneu',
          'OS.neu',
          'v1.0',
          ['Talk screen', 'Console', 'No desktop'],
          checkedAt,
          'current',
          host?.pretty ? `Sitting on ${host.pretty} (${host.hostname}).` : 'This machine is the os.neu screen.',
        ),
        item(
          'host',
          host?.pretty || host?.hostname || 'This PC',
          host?.version || '—',
          [host?.arch, host?.pkg, host?.platform].filter(Boolean) as string[],
          checkedAt,
          'unknown',
          host ? `${host.hostname} · ${host.family}` : 'Host name was not reported.',
        ),
      ],
    },
    {
      id: 'display',
      label: '디스플레이',
      labelEn: 'Display',
      items: [
        item(
          'screen',
          'Screen',
          screenLabel,
          [`${window.devicePixelRatio || 1}x pixel density`, `${window.screen.colorDepth || 24}-bit color`],
          checkedAt,
          byId.display?.status === 'ok' ? 'current' : 'available',
          byId.display?.detail || screenLabel,
        ),
      ],
    },
    {
      id: 'processor',
      label: '프로세서',
      labelEn: 'Processor',
      items: [
        item(
          'cpu',
          cpu,
          cores ? `${cores} threads` : '—',
          cores ? [`${cores} cores ready`] : [],
          checkedAt,
          cores > 0 ? 'current' : 'available',
          byId.think?.detail || cpu,
        ),
      ],
    },
    {
      id: 'memory',
      label: '메모리',
      labelEn: 'Memory',
      items: [
        item(
          'ram',
          'Working memory',
          typeof mem === 'number' ? `~${mem} GB` : '—',
          typeof mem === 'number' ? [`About ${mem}GB reported`] : ['Size not reported'],
          checkedAt,
          'current',
          byId.memory?.detail || 'Memory is in use for this screen.',
        ),
      ],
    },
    {
      id: 'storage',
      label: '저장소',
      labelEn: 'Storage',
      items: [
        item(
          'disk',
          'Documents store',
          'local',
          [byId.storage?.detail || 'Reachable'],
          checkedAt,
          byId.storage?.status === 'warn' || byId.storage?.status === 'fail' ? 'available' : 'current',
          byId.storage?.detail || '',
        ),
      ],
    },
    {
      id: 'graphics',
      label: '그래픽',
      labelEn: 'Graphics',
      items: [
        item(
          'gpu',
          gpu || 'Display adapter',
          gpu ? 'WebGL' : '—',
          gpu ? ['WebGL renderer'] : ['Name hidden by the browser'],
          checkedAt,
          gpu ? 'current' : 'unknown',
          gpu || 'This browser did not name the graphics chip.',
        ),
      ],
    },
    {
      id: 'sound',
      label: '소리',
      labelEn: 'Sound',
      items: [
        item(
          'audio',
          'Mic and speakers',
          'media',
          [byId.audio?.detail || ''],
          checkedAt,
          byId.audio?.status === 'ok' ? 'current' : byId.audio?.status === 'fail' ? 'available' : 'unknown',
          byId.audio?.detail || '',
        ),
      ],
    },
    {
      id: 'power',
      label: '전원',
      labelEn: 'Power',
      items: [
        item(
          'battery',
          'Power',
          'battery / mains',
          [byId.power?.detail || ''],
          checkedAt,
          byId.power?.status === 'fail' || byId.power?.status === 'warn' ? 'available' : 'current',
          byId.power?.detail || '',
        ),
      ],
    },
    {
      id: 'network',
      label: '네트워크',
      labelEn: 'Network',
      items: [
        item(
          'net',
          navigator.onLine ? 'Outside link' : 'Local only',
          (navigator as Navigator & { connection?: { effectiveType?: string } }).connection?.effectiveType || '—',
          [navigator.language],
          checkedAt,
          navigator.onLine ? 'current' : 'unknown',
          navigator.onLine ? 'A path to the outside is open.' : 'This screen still works offline.',
        ),
      ],
    },
  ]

  return { checkedAt, groups }
}
