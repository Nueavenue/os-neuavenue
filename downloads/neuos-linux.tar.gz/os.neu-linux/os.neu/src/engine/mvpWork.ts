/** First MVP work session — this device only (localStorage). */

export type MvpSource = {
  id: string
  title: string
  url: string
  status: 'added' | 'read' | 'failed' | 'login'
  note?: string
  addedAt: number
}

export type MvpAudience = 'team' | 'customer' | 'other' | ''

export type MvpWork = {
  id: string
  title: string
  prompt: string
  audience: MvpAudience
  audienceNote: string
  docId: string | null
  sources: MvpSource[]
  createdAt: number
  updatedAt: number
  savedAt: number | null
  /** Set when moved to the trash; the row stays so it can be restored. */
  deletedAt: number | null
}

export type MvpPending = {
  prompt: string
  audience: MvpAudience
  audienceNote: string
}

const WORKS_KEY = 'os.neu.mvp.works'
const ACTIVE_KEY = 'os.neu.mvp.active'
const MAX = 40

function newId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

function blankWork(partial: Partial<MvpWork> & { prompt: string }): MvpWork {
  const now = Date.now()
  const title = (partial.title || titleFromPrompt(partial.prompt)).slice(0, 80)
  return {
    id: partial.id || newId('w'),
    title,
    prompt: partial.prompt.trim().slice(0, 800),
    audience: partial.audience || '',
    audienceNote: partial.audienceNote || '',
    docId: partial.docId ?? null,
    sources: Array.isArray(partial.sources) ? partial.sources : [],
    createdAt: partial.createdAt || now,
    updatedAt: partial.updatedAt || now,
    savedAt: partial.savedAt ?? null,
    deletedAt: partial.deletedAt ?? null,
  }
}

export function titleFromPrompt(prompt: string) {
  const line = prompt.trim().replace(/\s+/g, ' ')
  if (!line) return '새 작업'
  const cut = line.split(/[.。!?！？\n]/)[0] || line
  return cut.slice(0, 48) || '새 작업'
}

/** Trimmed prompt, or null when there is nothing to send. */
export function cleanPrompt(text: string | null | undefined) {
  const line = String(text ?? '').trim()
  return line ? line : null
}

/** Report / compare style request that should enter the MVP work path. */
export function isMvpReportPrompt(text: string) {
  const line = text.trim()
  if (!line) return false
  if (/비교|보고서|리포트|선택\s*기준|추천\s*이유|\breport\b|\bcompar(e|ison)\b|\brecommend/i.test(line)) {
    return true
  }
  if (/만들어\s*줘|작성해|써\s*줘|draft|write/i.test(line) && /서비스|제품|방안|안건|제안/i.test(line)) {
    return true
  }
  return false
}

/** Docs include, or a report-style line, starts the work path (purpose card → work view). */
export function startsMvpWork(text: string, office?: string | null) {
  if (office === 'doc') return true
  return isMvpReportPrompt(text)
}

/**
 * Ask purpose only when audience / use is missing (Leader default).
 * Known audience markers skip the card.
 */
export function needsPurposeConfirm(text: string, office?: string | null) {
  if (!startsMvpWork(text, office)) return false
  if (
    /우리\s*팀|내부\s*검토|고객\s*제출|제출용|검토용|for (our )?team|internal|customer[- ]facing|client/i.test(
      text,
    )
  ) {
    return false
  }
  return true
}

export function normalizeWorks(rows: unknown): MvpWork[] {
  if (!Array.isArray(rows)) return []
  return rows.slice(0, MAX).map((raw, i) => {
    const row = (raw && typeof raw === 'object' ? raw : {}) as Partial<MvpWork>
    return blankWork({
      id: String(row.id || `w-${i}`),
      title: String(row.title || ''),
      prompt: String(row.prompt || ''),
      audience: (row.audience as MvpAudience) || '',
      audienceNote: String(row.audienceNote || ''),
      docId: typeof row.docId === 'string' ? row.docId : null,
      sources: Array.isArray(row.sources) ? (row.sources as MvpSource[]) : [],
      createdAt: Number(row.createdAt) || Date.now(),
      updatedAt: Number(row.updatedAt) || Date.now(),
      savedAt: row.savedAt == null ? null : Number(row.savedAt),
      deletedAt: row.deletedAt == null ? null : Number(row.deletedAt),
    })
  })
}

export function loadWorks(): MvpWork[] {
  try {
    const raw = localStorage.getItem(WORKS_KEY)
    return normalizeWorks(raw ? JSON.parse(raw) : [])
  } catch {
    return []
  }
}

export function saveWorks(rows: MvpWork[]) {
  try {
    if (typeof localStorage === 'undefined') return
    localStorage.setItem(WORKS_KEY, JSON.stringify(normalizeWorks(rows).slice(0, MAX)))
  } catch {
    /* private mode */
  }
}

export function upsertWork(rows: MvpWork[], next: MvpWork) {
  const node = blankWork(next)
  node.updatedAt = Date.now()
  const list = rows.some((row) => row.id === node.id)
    ? rows.map((row) => (row.id === node.id ? node : row))
    : [node, ...rows]
  const final = normalizeWorks(list)
  saveWorks(final)
  return final
}

/** Re-reads storage: true only if the work row really carries this savedAt. */
export function confirmWorkSaved(id: string, savedAt: number) {
  return loadWorks().some((row) => row.id === id && row.savedAt === savedAt)
}

export type ExportResult = { ok: boolean; path?: string; reason?: string; via?: 'download' }

/**
 * `saved` only when the desktop shell wrote the file and returned its path.
 * A browser download cannot be confirmed from the page.
 */
export function exportOutcome(result: ExportResult | null | undefined) {
  if (!result) return 'failed' as const
  if (result.ok && result.path) return 'saved' as const
  if (result.ok && result.via === 'download') return 'download' as const
  if (result.ok) return 'unverified' as const
  if (result.reason === 'cancelled') return 'cancelled' as const
  return 'failed' as const
}

export function loadActiveWorkId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_KEY)
  } catch {
    return null
  }
}

export function setActiveWorkId(id: string | null) {
  try {
    if (id) localStorage.setItem(ACTIVE_KEY, id)
    else localStorage.removeItem(ACTIVE_KEY)
  } catch {
    /* private mode */
  }
}

export function createWork(opts: {
  prompt: string
  audience?: MvpAudience
  audienceNote?: string
  docId?: string | null
}): MvpWork {
  return blankWork({
    prompt: opts.prompt,
    audience: opts.audience || '',
    audienceNote: opts.audienceNote || '',
    docId: opts.docId ?? null,
  })
}

export function enrichPrompt(work: Pick<MvpWork, 'prompt' | 'audience' | 'audienceNote'>) {
  const who =
    work.audience === 'team'
      ? 'Audience: internal team review.'
      : work.audience === 'customer'
        ? 'Audience: customer-facing deliverable.'
        : work.audienceNote
          ? `Audience: ${work.audienceNote}`
          : ''
  const steps =
    'Write an editable report with: 1) purpose, 2) comparison table, 3) selection criteria, 4) recommendation and caveats. Mark unverified facts as 미확인. Separate confirmed facts from opinions.'
  return [work.prompt.trim(), who, steps].filter(Boolean).join('\n\n')
}

export function addSource(work: MvpWork, source: Omit<MvpSource, 'id' | 'addedAt'> & { id?: string }) {
  const next: MvpSource = {
    id: source.id || newId('s'),
    title: source.title.slice(0, 120) || source.url,
    url: source.url,
    status: source.status,
    note: source.note,
    addedAt: Date.now(),
  }
  const sources = [next, ...work.sources.filter((row) => row.url !== next.url)].slice(0, 30)
  return { ...work, sources, updatedAt: Date.now() }
}

function hhmm(ts: number) {
  const d = new Date(ts)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export function formatSavedAt(ts: number | null, ko: boolean) {
  if (!ts) return ko ? '저장 안 됨' : 'Not saved'
  return ko ? `저장됨 ${hhmm(ts)}` : `Saved ${hhmm(ts)}`
}

/** List label: "Saved" only after the user pressed Save; otherwise the last change time. */
export function formatWorkTime(work: Pick<MvpWork, 'savedAt' | 'updatedAt'>, ko: boolean) {
  if (work.savedAt) return formatSavedAt(work.savedAt, ko)
  return ko ? `변경 ${hhmm(work.updatedAt)}` : `Changed ${hhmm(work.updatedAt)}`
}
