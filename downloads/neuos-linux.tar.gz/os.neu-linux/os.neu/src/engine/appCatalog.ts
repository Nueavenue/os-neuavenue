import type { Phase } from '../types'

export const APP_CATALOG_STORAGE = 'osneu.appCatalog.open'

export type CatalogAccess = 'free' | 'paid' | 'intent'
export type CatalogLaunch =
  | 'office-doc'
  | 'office-sheet'
  | 'office-slides'
  | 'neu-word'
  | 'neu-excel'
  | 'neu-prez'
  | 'speak'
  | 'crm'
  | 'daf'
  | 'cloud'
  | 'locked'

export type CatalogItem = {
  id: string
  launch: CatalogLaunch
  labelKo: string
  labelEn: string
  glyph: string
  present: boolean
}

export type CatalogCategory = {
  id: string
  access: CatalogAccess
  labelKo: string
  labelEn: string
  items: CatalogItem[]
}

/** Parent → child. No live SKU / no list price. */
export const APP_CATALOG: CatalogCategory[] = [
  {
    id: 'office-free',
    access: 'free',
    labelKo: '무료 오피스',
    labelEn: 'Free office',
    items: [
      { id: 'doc', launch: 'office-doc', labelKo: '문서', labelEn: 'Docs', glyph: 'W', present: true },
      { id: 'sheet', launch: 'office-sheet', labelKo: '시트', labelEn: 'Sheets', glyph: 'X', present: true },
      { id: 'slides', launch: 'office-slides', labelKo: '슬라이드', labelEn: 'Slides', glyph: 'P', present: true },
    ],
  },
  {
    id: 'office-neu',
    access: 'paid',
    labelKo: 'Neu 오피스',
    labelEn: 'Neu office',
    items: [
      { id: 'neu-docs', launch: 'neu-word', labelKo: 'Neu Docs (word)', labelEn: 'Neu Docs (word)', glyph: 'N', present: true },
      { id: 'neu-sheets', launch: 'neu-excel', labelKo: 'Neu Sheets (excel)', labelEn: 'Neu Sheets (excel)', glyph: 'N', present: true },
      { id: 'neu-slides', launch: 'neu-prez', labelKo: 'Neu Slides (pptx)', labelEn: 'Neu Slides (pptx)', glyph: 'N', present: true },
    ],
  },
  {
    id: 'speak',
    access: 'paid',
    labelKo: '말하기',
    labelEn: 'Speak',
    items: [
      { id: 'english', launch: 'speak', labelKo: '영어회화', labelEn: 'English conversation', glyph: 'S', present: true },
    ],
  },
  {
    id: 'work',
    access: 'paid',
    labelKo: '업무',
    labelEn: 'Work',
    items: [
      { id: 'crm', launch: 'crm', labelKo: 'CRM', labelEn: 'CRM', glyph: 'C', present: true },
      { id: 'finance', launch: 'locked', labelKo: '재정관리', labelEn: 'Finance', glyph: 'F', present: false },
    ],
  },
  {
    id: 'learn',
    access: 'paid',
    labelKo: '교육',
    labelEn: 'Learn',
    items: [
      { id: 'edu', launch: 'locked', labelKo: '교육 앱', labelEn: 'Education', glyph: 'E', present: false },
      { id: 'bible', launch: 'locked', labelKo: '바이블 앱', labelEn: 'Bible', glyph: 'B', present: false },
    ],
  },
  {
    id: 'open',
    access: 'intent',
    labelKo: '열기',
    labelEn: 'Open',
    items: [
      { id: 'daf', launch: 'daf', labelKo: 'daf.neu', labelEn: 'daf.neu', glyph: '◉', present: true },
      { id: 'cloud', launch: 'cloud', labelKo: 'cloud.neu', labelEn: 'cloud.neu', glyph: '☁', present: false },
    ],
  },
]

export function appCatalogHiddenPhase(phase: Phase | string) {
  const value = String(phase || '')
  return value === 'splash' || value === 'home' || value.startsWith('preview')
}

export function catalogItemLabel(item: CatalogItem, ko: boolean) {
  return ko ? item.labelKo : item.labelEn
}

export function catalogCategoryLabel(row: CatalogCategory, ko: boolean) {
  return ko ? row.labelKo : row.labelEn
}

export function catalogAccessLabel(access: CatalogAccess, ko: boolean) {
  if (access === 'free') return ko ? '무료' : 'Free'
  if (access === 'paid') return ko ? '유료' : 'Paid'
  return ko ? '의도' : 'Intent'
}

export type NeuOpen = { ready: boolean; href: string | null }

export function catalogItemState(
  item: CatalogItem,
  neu: Record<'neu-word' | 'neu-excel' | 'neu-prez', NeuOpen | undefined>,
) {
  if (item.launch === 'locked') {
    return { enabled: false, reason: 'missing' as const }
  }
  if (item.launch === 'cloud') {
    return { enabled: true, reason: 'open' as const }
  }
  if (item.launch === 'neu-word' || item.launch === 'neu-excel' || item.launch === 'neu-prez') {
    const tile = neu[item.launch]
    if (!tile?.ready) return { enabled: false, reason: 'missing' as const }
    if (!tile.href) return { enabled: true, reason: 'cli' as const }
    return { enabled: true, reason: 'web' as const }
  }
  return { enabled: true, reason: 'open' as const }
}

export function readCatalogOpen(storage: Pick<Storage, 'getItem'> | null) {
  try {
    return storage?.getItem(APP_CATALOG_STORAGE) === '1'
  } catch {
    return false
  }
}

export function writeCatalogOpen(storage: Pick<Storage, 'setItem'> | null, open: boolean) {
  try {
    storage?.setItem(APP_CATALOG_STORAGE, open ? '1' : '0')
  } catch {
    /* ignore quota */
  }
}
