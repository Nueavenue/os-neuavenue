import { describe, expect, it } from 'vitest'
import {
  APP_CATALOG,
  appCatalogHiddenPhase,
  catalogAccessLabel,
  catalogItemState,
} from './appCatalog'

describe('app catalog', () => {
  it('groups parent categories with child apps', () => {
    expect(APP_CATALOG.map((row) => row.id)).toEqual([
      'office-free',
      'office-neu',
      'speak',
      'work',
      'learn',
      'open',
    ])
    const free = APP_CATALOG.find((row) => row.id === 'office-free')
    expect(free?.access).toBe('free')
    expect(free?.items.map((item) => item.id)).toEqual(['doc', 'sheet', 'slides'])
    const paidOffice = APP_CATALOG.find((row) => row.id === 'office-neu')
    expect(paidOffice?.items.map((item) => item.labelKo)).toEqual([
      'Neu Docs (word)',
      'Neu Sheets (excel)',
      'Neu Slides (pptx)',
    ])
    expect(APP_CATALOG.some((row) => row.items.some((item) => item.id === 'english'))).toBe(true)
    expect(APP_CATALOG.some((row) => row.items.some((item) => item.id === 'daf'))).toBe(true)
    expect(APP_CATALOG.some((row) => row.items.some((item) => item.id === 'cloud'))).toBe(true)
  })

  it('keeps the first landing (home) and splash without the rail', () => {
    expect(appCatalogHiddenPhase('home')).toBe(true)
    expect(appCatalogHiddenPhase('splash')).toBe(true)
    expect(appCatalogHiddenPhase('preview-hub')).toBe(true)
    expect(appCatalogHiddenPhase('lui')).toBe(false)
    expect(appCatalogHiddenPhase('landing')).toBe(false)
    expect(appCatalogHiddenPhase('workspace')).toBe(false)
    expect(appCatalogHiddenPhase('console')).toBe(false)
  })

  it('does not invent a live buy path for locked paid apps', () => {
    const bible = APP_CATALOG.flatMap((row) => row.items).find((item) => item.id === 'bible')
    expect(bible?.present).toBe(false)
    expect(catalogItemState(bible!, { 'neu-word': undefined, 'neu-excel': undefined, 'neu-prez': undefined })).toEqual({
      enabled: false,
      reason: 'missing',
    })
    expect(catalogAccessLabel('paid', true)).toBe('유료')
  })

  it('Neu office click needs craft-web href; CLI-only is not a GUI', () => {
    const word = APP_CATALOG.flatMap((row) => row.items).find((item) => item.id === 'neu-docs')!
    expect(catalogItemState(word, { 'neu-word': { ready: false, href: null }, 'neu-excel': undefined, 'neu-prez': undefined }).enabled).toBe(
      false,
    )
    expect(
      catalogItemState(word, { 'neu-word': { ready: true, href: null }, 'neu-excel': undefined, 'neu-prez': undefined }).reason,
    ).toBe('cli')
    expect(
      catalogItemState(word, {
        'neu-word': { ready: true, href: 'http://127.0.0.1:4178/craft-web/' },
        'neu-excel': undefined,
        'neu-prez': undefined,
      }).reason,
    ).toBe('web')
  })
})
