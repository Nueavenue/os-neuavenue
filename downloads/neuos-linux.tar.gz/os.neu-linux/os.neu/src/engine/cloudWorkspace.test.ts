import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  activityRow,
  cloudConfig,
  cloudPendingCount,
  cloudSyncLine,
  enqueueCloud,
  flushCloudOutbox,
  loadOutbox,
  saveAiKeyToCloud,
  workRow,
} from './cloudWorkspace'
import type { WsActivity, WsWork } from './workspaceDb'

const cfg = { url: 'http://127.0.0.1:54321', anon: 'anon-test' }
const jwt = 'aaa.bbb.ccc'

function memoryStorage() {
  const map = new Map<string, string>()
  return {
    getItem: (k: string) => (map.has(k) ? map.get(k)! : null),
    setItem: (k: string, v: string) => void map.set(k, String(v)),
    removeItem: (k: string) => void map.delete(k),
    clear: () => map.clear(),
    key: () => null,
    length: 0,
  }
}

const work: WsWork = {
  id: 'w-1',
  title: 'Report',
  prompt: 'Compare three CRM services',
  audience: 'team',
  audienceNote: '',
  status: 'open',
  projectId: null,
  docId: null,
  createdAt: Date.UTC(2026, 10, 5, 1, 0),
  updatedAt: Date.UTC(2026, 10, 5, 1, 5),
  savedAt: null,
  deletedAt: null,
}

beforeEach(() => {
  vi.stubGlobal('localStorage', memoryStorage())
  localStorage.setItem('os.neu.token', jwt)
})

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('cloud workspace', () => {
  it('is off without a URL and anon key', () => {
    expect(cloudConfig({})).toBeNull()
    expect(cloudConfig({ VITE_NEUWS_URL: 'http://127.0.0.1:54321/', VITE_NEUWS_ANON_KEY: 'k' })).toEqual({ url: 'http://127.0.0.1:54321', anon: 'k' })
  })

  it('maps rows with ISO times and never sends AI request text', () => {
    expect(workRow(work)).toMatchObject({ id: 'w-1', updated_at: '2026-11-05T01:05:00.000Z', saved_at: null })
    const ai: WsActivity = { id: 'a-1', workId: 'w-1', kind: 'ai.call', app: 'doc', title: 'Compare three CRM', model: 'gpt-4.1', chars: 900, t: work.updatedAt }
    expect(activityRow(ai)).toMatchObject({ title: null, model: 'gpt-4.1', chars: 900 })
  })

  it('keeps one outbox row per table and id', () => {
    enqueueCloud({ table: 'works', id: 'w-1', row: { title: 'a' } })
    enqueueCloud({ table: 'works', id: 'w-1', row: { title: 'b' } })
    enqueueCloud({ table: 'activity', id: 'a-1', row: {} })
    expect(cloudPendingCount()).toBe(2)
    expect(loadOutbox().find((r) => r.table === 'works')?.row).toEqual({ title: 'b' })
  })

  it('waits when signed out and uploads into the personal space when signed in', async () => {
    enqueueCloud({ table: 'works', id: 'w-1', row: workRow(work) })
    localStorage.setItem('os.neu.token', 'local-device-token')
    expect(await flushCloudOutbox(vi.fn() as unknown as typeof fetch, cfg)).toMatchObject({ sent: 0, left: 1, reason: 'signed-out' })

    localStorage.setItem('os.neu.token', jwt)
    const calls: Array<{ url: string; body: string; headers: Record<string, string> }> = []
    const fetcher = vi.fn(async (url: string, init: RequestInit) => {
      calls.push({ url, body: String(init.body), headers: init.headers as Record<string, string> })
      if (url.endsWith('/rpc/ensure_personal_space')) return new Response('"org-1"', { status: 200 })
      return new Response('', { status: 201 })
    })
    expect(await flushCloudOutbox(fetcher as unknown as typeof fetch, cfg)).toEqual({ sent: 1, left: 0, reason: undefined })
    const upload = calls.find((c) => c.url.includes('/rest/v1/works'))!
    expect(upload.url).toContain('on_conflict=org_id,id')
    expect(JSON.parse(upload.body)[0]).toMatchObject({ id: 'w-1', org_id: 'org-1' })
    expect(upload.headers['content-profile']).toBe('neuws')
    expect(upload.headers.authorization).toBe(`Bearer ${jwt}`)
  })

  it('keeps rows when the upload fails', async () => {
    enqueueCloud({ table: 'works', id: 'w-1', row: workRow(work) })
    localStorage.setItem('os.neu.cloud.space', 'org-1')
    const fetcher = vi.fn(async () => new Response('{}', { status: 500 }))
    expect(await flushCloudOutbox(fetcher as unknown as typeof fetch, cfg)).toMatchObject({ sent: 0, left: 1, reason: 'failed' })
  })

  it('saves a key to the vault through the RPC only', async () => {
    const fetcher = vi.fn(async () => new Response('"2026-11-05T01:00:00Z"', { status: 200 }))
    expect(await saveAiKeyToCloud('openai', ' sk-test-123456 ', fetcher as unknown as typeof fetch, cfg)).toBe(true)
    const [url, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit]
    expect(url).toBe('http://127.0.0.1:54321/rest/v1/rpc/set_ai_key')
    expect(JSON.parse(String(init.body))).toEqual({ p_vendor: 'openai', p_key: 'sk-test-123456' })
  })

  it('says where the work is kept', () => {
    expect(cloudSyncLine(false, { on: false, signedIn: false, pending: 0, syncedAt: null })).toBe('Saved on this device only')
    expect(cloudSyncLine(false, { on: true, signedIn: true, pending: 3, syncedAt: null })).toBe('Not synced (3)')
    expect(cloudSyncLine(true, { on: true, signedIn: false, pending: 0, syncedAt: null })).toBe('로그인하면 클라우드에 동기화')
  })
})
