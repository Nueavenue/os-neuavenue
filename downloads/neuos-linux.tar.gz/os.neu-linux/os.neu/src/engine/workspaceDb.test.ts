import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import {
  appendActivity,
  filterActivity,
  getArtifact,
  groupByDay,
  listActivity,
  listWorks,
  memoryBackend,
  putArtifact,
  putWork,
  resolveWorkIds,
  setWorkspaceBackend,
  summarizeWork,
  visibleActivity,
  type WsActivity,
  type WsWork,
} from './workspaceDb'
import { linkActivity, logActivity, saveArtifact } from './workspaceLog'

const work = (id: string, updatedAt: number): WsWork => ({
  id,
  title: id,
  prompt: '',
  audience: '',
  audienceNote: '',
  status: 'open',
  projectId: null,
  docId: null,
  createdAt: 1,
  updatedAt,
  savedAt: null,
  deletedAt: null,
})

const act = (id: string, kind: WsActivity['kind'], workId: string | null, t: number, extra: Partial<WsActivity> = {}): WsActivity => ({
  id,
  kind,
  workId,
  app: null,
  title: id,
  t,
  ...extra,
})

function stubActiveWork(id: string | null) {
  const map = new Map<string, string>()
  if (id) map.set('os.neu.mvp.active', id)
  ;(globalThis as { localStorage?: unknown }).localStorage = {
    getItem: (k: string) => map.get(k) ?? null,
    setItem: (k: string, v: string) => void map.set(k, v),
    removeItem: (k: string) => void map.delete(k),
    key: () => null,
    length: 0,
  }
}

const settle = () => new Promise((r) => setTimeout(r, 0))

describe('neu-workspace', () => {
  beforeEach(() => setWorkspaceBackend(memoryBackend()))
  afterEach(() => {
    setWorkspaceBackend(null)
    delete (globalThis as { localStorage?: unknown }).localStorage
  })

  it('lists works newest first', async () => {
    await putWork(work('a', 1))
    await putWork(work('b', 5))
    expect((await listWorks()).map((w) => w.id)).toEqual(['b', 'a'])
  })

  it('activity is append-only', async () => {
    await appendActivity({ id: 'x', kind: 'web.visit', workId: null, app: 'web', title: 'x' })
    await expect(appendActivity({ id: 'x', kind: 'web.visit', workId: 'w', app: 'web', title: 'changed' })).rejects.toThrow()
    expect((await listActivity())[0].workId).toBeNull()
  })

  it('artifacts bump version and keep a payload hash', async () => {
    const first = await putArtifact({ workId: 'w1', app: 'sheet', title: 'T', payload: { grid: [['a']] } })
    const second = await putArtifact({ id: first.id, workId: null, app: 'sheet', title: 'T', payload: { grid: [['b']] } })
    expect(second.version).toBe(2)
    expect(second.workId).toBe('w1')
    expect(second.hash).not.toBe(first.hash)
    expect(second.hash).toMatch(/^[0-9a-f]{64}$/)
    expect((await getArtifact(first.id))?.payload).toEqual({ grid: [['b']] })
  })

  it('a later link row re-points an activity without editing it', () => {
    const rows = [act('v1', 'web.visit', null, 1), act('l1', 'work.link', 'w1', 2, { refId: 'v1' })]
    expect(resolveWorkIds(rows).get('v1')).toBe('w1')
    const shown = visibleActivity(rows)
    expect(shown.map((r) => r.id)).toEqual(['v1'])
    expect(shown[0].workId).toBe('w1')
    expect(rows[0].workId).toBeNull()
  })

  it('summarizes a work across apps', () => {
    const counts = summarizeWork(
      { id: 'w1', docId: 'p1' },
      [act('a', 'ai.call', 'w1', 1), act('b', 'web.visit', 'w1', 2), act('c', 'ai.call', 'w2', 3)],
      [
        { id: 's', workId: 'w1', app: 'sheet', title: '', payload: null, version: 1, hash: '', createdAt: 1, updatedAt: 1 },
        { id: 'd', workId: 'w2', app: 'slides', title: '', payload: null, version: 1, hash: '', createdAt: 1, updatedAt: 1 },
      ],
      [{ id: 'e', workId: 'w1', url: 'https://a', title: 'a', status: 'added', addedAt: 1 }],
    )
    expect(counts).toEqual({ doc: 1, sheet: 1, slides: 0, sources: 1, ai: 1, web: 1 })
  })

  it('filters and groups the feed by day', () => {
    const day = 86_400_000
    const base = new Date(2026, 10, 3, 12).getTime()
    const rows = [
      act('a', 'ai.call', null, base, { app: 'doc' }),
      act('b', 'doc.save', null, base - 1000, { app: 'doc' }),
      act('c', 'web.visit', null, base - day, { app: 'web' }),
    ]
    expect(filterActivity(rows, 'doc').map((r) => r.id)).toEqual(['b'])
    expect(filterActivity(rows, 'ai').map((r) => r.id)).toEqual(['a'])
    expect(groupByDay(rows).map((g) => g.items.length)).toEqual([2, 1])
  })

  it('logActivity picks up the active work id (rule 1)', async () => {
    stubActiveWork('w-active')
    logActivity('web.visit', { app: 'web', url: 'https://example.com', title: 'example' })
    logActivity('ai.call', { app: 'doc', model: 'm', title: 'outside', workId: null })
    await settle()
    const rows = await listActivity()
    expect(rows.find((r) => r.kind === 'web.visit')?.workId).toBe('w-active')
    expect(rows.find((r) => r.kind === 'ai.call')?.workId).toBeNull()
  })

  it('saveArtifact stores the sheet and logs sheet.save; link attaches loose rows', async () => {
    stubActiveWork('w9')
    const row = await saveArtifact('sheet', 'Prices', { grid: [['1']] })
    linkActivity('loose', 'w9')
    await settle()
    const rows = await listActivity()
    expect(row.workId).toBe('w9')
    expect(rows.find((r) => r.kind === 'sheet.save')?.refId).toBe(row.id)
    expect(rows.find((r) => r.kind === 'work.link')).toMatchObject({ refId: 'loose', workId: 'w9' })
  })
})
