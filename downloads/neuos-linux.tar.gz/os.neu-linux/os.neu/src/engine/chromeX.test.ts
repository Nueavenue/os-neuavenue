import { describe, expect, it } from 'vitest'
import { decideChromeX, isHomePhase } from './chromeX'

describe('decideChromeX', () => {
  it('quits the landing and talk homes so Ubuntu comes back', () => {
    for (const phase of ['splash', 'install', 'landing', 'lui', 'jeos'] as const) {
      expect(isHomePhase(phase)).toBe(true)
      expect(
        decideChromeX({
          phase,
          previousPhase: null,
          windowFullscreen: true,
          domFullscreen: true,
        }),
      ).toBe('quit')
    }
  })

  it('leaves fullscreen on inner screens before going back', () => {
    expect(
      decideChromeX({
        phase: 'workspace',
        previousPhase: 'lui',
        windowFullscreen: true,
        domFullscreen: false,
      }),
    ).toBe('leave-fullscreen')
  })

  it('goes back from an inner screen when not fullscreen', () => {
    expect(
      decideChromeX({
        phase: 'studio',
        previousPhase: 'lui',
        windowFullscreen: false,
        domFullscreen: false,
      }),
    ).toBe('back')
  })
})
