import type { HardwareCheck, HardwareReport } from '../types'

function statusOk(): HardwareCheck['status'] {
  return 'ok'
}

async function storageDetail(): Promise<{ detail: string; status: HardwareCheck['status'] }> {
  try {
    if (!navigator.storage?.estimate) {
      return { detail: 'Storage is reachable. Documents can be saved.', status: 'ok' }
    }
    const estimate = await navigator.storage.estimate()
    const quota = estimate.quota ?? 0
    const usage = estimate.usage ?? 0
    if (quota === 0) {
      return { detail: 'Could not read storage size. Saving can still be tried.', status: 'warn' }
    }
    const freeGb = Math.max(0, (quota - usage) / 1024 ** 3)
    if (freeGb < 0.1) {
      return { detail: 'Storage is almost full. Clearing old files will help.', status: 'warn' }
    }
    return {
      detail: `About ${freeGb.toFixed(1)}GB is free.`,
      status: 'ok',
    }
  } catch {
    return { detail: 'Storage check stalled briefly. A restart usually clears it.', status: 'warn' }
  }
}

async function batteryDetail(): Promise<{ detail: string; status: HardwareCheck['status'] }> {
  try {
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<{ level: number; charging: boolean }>
    }
    if (!nav.getBattery) {
      return { detail: 'Plugged in, or this device has no battery.', status: 'ok' }
    }
    const battery = await nav.getBattery()
    const pct = Math.round(battery.level * 100)
    if (!battery.charging && pct <= 8) {
      return { detail: `Battery is ${pct}%. Please plug in a charger.`, status: 'fail' }
    }
    if (!battery.charging && pct <= 20) {
      return { detail: `Battery is ${pct}%. Charge soon.`, status: 'warn' }
    }
    return {
      detail: battery.charging ? `Charging, now ${pct}%.` : `Battery ${pct}% is usable.`,
      status: 'ok',
    }
  } catch {
    return { detail: 'Could not read power, but the screen is on so we continue.', status: 'ok' }
  }
}

async function audioDetail(): Promise<{ detail: string; status: HardwareCheck['status'] }> {
  try {
    if (!navigator.mediaDevices?.enumerateDevices) {
      return { detail: 'Could not list sound devices. Speech can be allowed later.', status: 'warn' }
    }
    const devices = await navigator.mediaDevices.enumerateDevices()
    const mics = devices.filter((d) => d.kind === 'audioinput')
    const outs = devices.filter((d) => d.kind === 'audiooutput')
    if (mics.length === 0 && outs.length === 0) {
      return { detail: 'No mic or speakers found. Please plug a cable in.', status: 'fail' }
    }
    if (mics.length === 0) {
      return { detail: 'Speakers are present. Without a mic you can still type.', status: 'warn' }
    }
    return {
      detail: `${mics.length} speech mic(s) and audio output are ready.`,
      status: 'ok',
    }
  } catch {
    return { detail: 'Could not check sound devices. Typing still works.', status: 'warn' }
  }
}

export async function inspectHardware(): Promise<HardwareReport> {
  const cores = navigator.hardwareConcurrency || 0
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory
  const width = window.screen.width
  const height = window.screen.height

  const [storage, battery, audio] = await Promise.all([
    storageDetail(),
    batteryDetail(),
    audioDetail(),
  ])

  const checks: HardwareCheck[] = [
    {
      id: 'display',
      title: 'Screen',
      meaning: 'The display you are looking at',
      detail:
        width > 0 && height > 0
          ? `${width}×${height} screen is on.`
          : 'Could not read the screen size.',
      status: width > 0 && height > 0 ? statusOk() : 'fail',
    },
    {
      id: 'think',
      title: 'Thinking unit',
      meaning: 'The part that computes commands',
      detail:
        cores > 0
          ? `Awake on ${cores} cores. Ready for work.`
          : 'Could not find the thinking unit.',
      status: cores > 0 ? 'ok' : 'fail',
    },
    {
      id: 'memory',
      title: 'Working memory',
      meaning: 'Memory held open for the current job',
      detail:
        typeof memory === 'number'
          ? `About ${memory}GB is available now.`
          : 'The device did not report memory size, but the screen is moving.',
      status: 'ok',
    },
    {
      id: 'storage',
      title: 'Storage',
      meaning: 'Where documents and sheets stay',
      detail: storage.detail,
      status: storage.status,
    },
    {
      id: 'audio',
      title: 'Sound',
      meaning: 'Speaking and listening',
      detail: audio.detail,
      status: audio.status,
    },
    {
      id: 'power',
      title: 'Power',
      meaning: 'Battery level if present, otherwise plugged-in state',
      detail: battery.detail,
      status: battery.status,
    },
  ]

  return {
    checks,
    healthy: checks.every((c) => c.status !== 'fail'),
    capturedAt: Date.now(),
  }
}
