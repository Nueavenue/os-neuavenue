/**
 * Rename HTML-deck slide labels (thumb + meta). Persisted by runtime localStorage.
 */

export type SlideRef = { id: string; label: string; file?: string }

export type RenameIntent = {
  type: 'rename'
  /** 0-based slide index */
  index: number
  title: string
  reason: string
}

/** Strip leading "05 " numbering from a label. */
export function baseSlideTitle(label: string): string {
  return String(label || '')
    .replace(/^\d+\s+/, '')
    .trim()
}

export function numberedLabel(index0: number, title: string): string {
  const base = baseSlideTitle(title) || '슬라이드'
  return String(index0 + 1).padStart(2, '0') + ' ' + base.slice(0, 80)
}

/**
 * Examples:
 * - "현재 장 제목을 제품구조로"
 * - "05장 이름을 제품구조로 변경"
 * - "장 이름: 제품구조"
 * - "rename slide to 제품구조"
 */
export function parseRenameIntent(
  instruction: string,
  slides: SlideRef[],
  currentIndex = 0,
): RenameIntent | null {
  const text = String(instruction || '').trim()
  if (!text || !slides.length) return null

  const looksRename =
    /(?:장\s*)?(?:이름|제목|label)\s*[:：]|이름\s*(?:을|를)?\s*(?:변경|바꿔|개명)|제목\s*(?:을|를)?\s*(?:변경|바꿔)|rename\s+(?:slide|title)|슬라이드\s*이름|장\s*이름/i.test(
      text,
    ) || /(?:이름|제목)\s*(?:을|를)\s*.{1,40}(?:으로|로)\s*(?:변경|바꿔|해|줘)?/i.test(text)

  if (!looksRename) return null
  // Don't steal insert "제목: X" when also inserting
  if (/(추가|insert|add\s+slide|다음\s*장)/i.test(text) && !/(이름|개명|변경|rename|바꿔)/i.test(text)) {
    return null
  }

  let title = ''
  const colon = text.match(/(?:장\s*)?(?:이름|제목|label|title)\s*[:：]\s*[「"']?([^」"'\n]+)[」"']?/i)
  if (colon) title = colon[1].trim()

  const toName =
    text.match(
      /(?:이름|제목)\s*(?:을|를)?\s*[「"']?([^」"'\n]{1,60}?)[」"']?\s*(?:으로|로)\s*(?:변경|바꿔|개명|해|줘)?/i,
    ) ||
    text.match(/rename\s+(?:slide|title)\s+to\s+[「"']?([^」"'\n]+)[」"']?/i) ||
    text.match(/(?:변경|바꿔)\s*[「"']?([^」"'\n]{1,60}?)[」"']?\s*$/i)
  if (!title && toName) title = toName[1].trim()

  title = title
    .replace(/^(?:을|를|이|가)\s*/, '')
    .replace(/\s*(?:으로|로|변경|바꿔|개명|해|줘|주세요)\s*$/i, '')
    .replace(/[<>]/g, '')
    .slice(0, 80)
  if (!title) return null

  let index = Math.max(0, Math.min(slides.length - 1, currentIndex))
  if (/현재\s*(장|슬라이드)|이\s*(장|슬라이드)|선택\s*(장|슬라이드)|this\s*slide/i.test(text)) {
    index = Math.max(0, Math.min(slides.length - 1, currentIndex))
  } else {
    const num = text.match(/(?:^|\s)0*(\d+)\s*(?:번|장)/)
    if (num) {
      const n = Number(num[1])
      const byPos = n - 1
      if (byPos >= 0 && byPos < slides.length) index = byPos
      else {
        // Label prefix "05 …" may not equal array index when slides were inserted
        const pad = String(n).padStart(2, '0')
        const byLabel = slides.findIndex(
          (s) => String(s.label || '').startsWith(pad + ' ') || String(s.label || '').startsWith(String(n) + ' '),
        )
        if (byLabel >= 0) index = byLabel
      }
    }
  }

  return {
    type: 'rename',
    index,
    title,
    reason: `rename #${index + 1} → ${title}`,
  }
}

/** Patch first h1 / <title> in slide HTML when renaming a placeholder. */
export function patchSlideTitleInHtml(html: string, title: string): string {
  const safe = String(title || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
  let out = String(html || '')
  if (!out) return out
  if (/<title\b/i.test(out)) {
    out = out.replace(/<title\b[^>]*>[\s\S]*?<\/title>/i, `<title>${safe}</title>`)
  }
  if (/<h1\b/i.test(out)) {
    out = out.replace(/<h1\b([^>]*)>[\s\S]*?<\/h1>/i, `<h1$1>${safe}</h1>`)
  }
  return out
}
