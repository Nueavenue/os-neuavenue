/** Carry the os.neu prompt into the PPT template window (verbatim). */

const SLIDES_PROMPT_KEY = 'os.neu.slides.prompt'
let memoryPrompt = ''

function readStore(): string {
  try {
    if (typeof sessionStorage !== 'undefined') {
      return String(sessionStorage.getItem(SLIDES_PROMPT_KEY) || '')
    }
  } catch {
    /* private mode */
  }
  return memoryPrompt
}

function writeStore(text: string) {
  memoryPrompt = text
  try {
    if (typeof sessionStorage === 'undefined') return
    if (text) sessionStorage.setItem(SLIDES_PROMPT_KEY, text)
    else sessionStorage.removeItem(SLIDES_PROMPT_KEY)
  } catch {
    /* private mode */
  }
}

export function stagePromptSlides(raw: string): string {
  const text = raw.trim()
  writeStore(text)
  return text
}

export function peekPromptSlides(): string {
  return readStore().trim()
}

export function takePromptSlides(): string {
  const text = peekPromptSlides()
  writeStore('')
  return text
}
