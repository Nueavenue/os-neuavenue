import { describe, expect, it } from 'vitest'
import { generationChangeSet, judgeGeneration } from './generationPath'
import { applyChangeSet, withDeckConfirm } from './slideChangeSet'
import type { RecipeSlide } from './slidesRecipe'

const current: RecipeSlide[] = [
  { layout: 'title', title: 'Kept title', body: 'Kept body', bullets: [], table: null },
]

function deck(n: number, layout: string = 'title'): unknown[] {
  return Array.from({ length: n }, (_, i) => ({
    layout,
    title: `S${i + 1}`,
    body: 'line',
  }))
}

describe('generation path', () => {
  it('keeps the deck until Apply of a valid ChangeSet', () => {
    const live = current.map((slide) => ({ ...slide }))
    const reply = JSON.stringify({ version: 1, slides: deck(2) })
    const change = generationChangeSet(live, reply, 2)
    expect(change).not.toBeNull()
    expect(live.map((slide) => slide.title)).toEqual(['Kept title'])
    expect(applyChangeSet(change!, false).ok).toBe(false)
    expect(live[0].title).toBe('Kept title')
    const applied = applyChangeSet(withDeckConfirm(change!, true), true)
    expect(applied.ok).toBe(true)
    if (!applied.ok) return
    expect(applied.slides.map((slide) => slide.title)).toEqual(['S1', 'S2'])
    expect(live[0].title).toBe('Kept title')
  })

  it('does not build a ChangeSet when the model fails', () => {
    expect(judgeGeneration('http-502', 8)).toEqual({ ok: false, reason: 'failed' })
    expect(generationChangeSet(current, 'http-502', 8)).toBeNull()
    expect(generationChangeSet(current, 'Could not reach the bridge (port 4178).', 8)).toBeNull()
    expect(current[0].title).toBe('Kept title')
  })

  it('rejects the whole reply when the slide count differs', () => {
    const reply = JSON.stringify({ version: 1, slides: deck(10) })
    expect(judgeGeneration(reply, 8)).toEqual({ ok: false, reason: 'count' })
    expect(generationChangeSet(current, reply, 8)).toBeNull()
    expect(current[0].title).toBe('Kept title')
  })

  it('rejects the whole reply when any layout or component is unsupported', () => {
    const slides = deck(2)
    slides[1] = { layout: 'chart', title: 'Trend', body: '' }
    const chart = JSON.stringify({ version: 1, slides })
    expect(judgeGeneration(chart, 2)).toEqual({ ok: false, reason: 'unsupported' })
    expect(generationChangeSet(current, chart, 2)).toBeNull()
    const withImage = deck(2)
    withImage[0] = { layout: 'title', title: 'Cover', body: '', components: [{ type: 'image' }] }
    const image = JSON.stringify({ version: 1, slides: withImage })
    expect(judgeGeneration(image, 2)).toEqual({ ok: false, reason: 'unsupported' })
    expect(generationChangeSet(current, image, 2)).toBeNull()
    expect(current[0].title).toBe('Kept title')
  })
})
