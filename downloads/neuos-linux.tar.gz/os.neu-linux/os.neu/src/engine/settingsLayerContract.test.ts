import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const root = resolve(__dirname, '../..')

function read(rel: string) {
  return readFileSync(resolve(root, rel), 'utf8')
}

describe('settings layer above daf.neu', () => {
  it('publishes settings visibility when Settings · Help opens', () => {
    const panel = read('src/components/SettingsPanel.tsx')
    const bus = read('src/engine/settingsBus.ts')
    expect(bus).toContain("osneu:settings-visibility")
    expect(bus).toContain('export function publishSettingsVisibility')
    expect(panel).toContain('publishSettingsVisibility(settingsOpen)')
    expect(panel).toContain('className="mvp-modal-scrim settings-scrim"')
  })

  it('hides the Electron BrowserView while Settings · Help is open', () => {
    const landing = read('src/screens/LandingBrowser.tsx')
    expect(landing).toContain('onSettingsVisibility(setSettingsLayerOpen)')
    expect(landing).toContain('settingsLayerOpen ||')
    expect(landing).toContain('onShellOverlay(setShellOverlayOpen)')
    expect(landing).toContain('void window.neuos.browse.hide()')
  })

  it('keeps the settings scrim above daf.neu HTML chrome', () => {
    const css = read('src/index.css')
    expect(css).toMatch(/\.mvp-modal-scrim\.settings-scrim[\s\S]*?z-index:\s*240/)
    expect(css).toMatch(/\.browser-flyout[\s\S]*?z-index:\s*90/)
  })
})
