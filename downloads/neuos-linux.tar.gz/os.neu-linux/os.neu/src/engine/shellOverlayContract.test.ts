import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const root = resolve(__dirname, '../..')

function read(rel: string) {
  return readFileSync(resolve(root, rel), 'utf8')
}

describe('shell overlays above daf.neu BrowserView', () => {
  it('publishes a shared shell-overlay bus', () => {
    const bus = read('src/engine/settingsBus.ts')
    expect(bus).toContain("osneu:shell-overlay")
    expect(bus).toContain('export function publishShellOverlay')
    expect(bus).toContain('export function onShellOverlay')
  })

  it('hides BrowserView for CRM, model pick, my work, and AI connect', () => {
    const landing = read('src/screens/LandingBrowser.tsx')
    expect(landing).toContain('onShellOverlay(setShellOverlayOpen)')
    expect(landing).toContain('shellOverlayOpen ||')
    expect(landing).toContain('crmOpen ||')

    expect(read('src/components/CrmDialog.tsx')).toContain("publishShellOverlay('crm'")
    expect(read('src/components/ModelPickDialog.tsx')).toContain("publishShellOverlay('model-pick'")
    expect(read('src/components/MyWorkPanel.tsx')).toContain("publishShellOverlay('my-work'")
    expect(read('src/components/AiConnectDialog.tsx')).toContain("publishShellOverlay('ai-connect'")
  })

  it('keeps the local Reliable-tier banner as a warning, not a hard block', () => {
    const health = read('src/engine/llmConnect.ts')
    expect(health).toContain('Ask AI still works')
    expect(health).toContain('Ask AI는 사용할 수 있습니다')
    const doc = read('src/components/apps/DocApp.tsx')
    expect(doc).toContain("health?.state === 'red'")
    expect(doc).not.toContain("health?.state === 'yellow'")
  })
})
