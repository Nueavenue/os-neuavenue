export const CRAFT_CLI = {
  wordcraft: 'wordcraft-cli',
  gridcraft: 'gridcraft-cli',
  deckcraft: 'deckcraft-cli',
} as const

export function defaultCraftBinDir(home: string) {
  return `${String(home || '').replace(/\/+$/, '')}/.local/share/os.neu/craft/bin`
}

/** Sidecar bin. Absolute OSNEU_CRAFT_BIN_DIR wins. No `..`. */
export function craftBinDirFromEnv(env: Record<string, string | undefined> = {}, home = '') {
  const custom = String(env.OSNEU_CRAFT_BIN_DIR || '').trim()
  if (custom.startsWith('/') && !custom.includes('\0') && !custom.includes('..')) {
    return custom.replace(/\/+$/, '')
  }
  return defaultCraftBinDir(home)
}

export function sidecarCliPath(binDir: string, name: string, existsExec: (path: string) => boolean) {
  const dir = String(binDir || '').replace(/\/+$/, '')
  if (!dir.startsWith('/') || !name) return null
  const path = `${dir}/${name}`
  return existsExec(path) ? path : null
}

export type CraftBins = {
  wordcraft: string | null
  gridcraft: string | null
  deckcraft: string | null
}

/** Pure detect. Keys are CLI names; values are paths (or empty/missing → null). */
export function detectCraftBins(map: Record<string, string | null | undefined> = {}): CraftBins {
  const pick = (name: string) => {
    const value = map[name]
    if (typeof value !== 'string') return null
    const path = value.trim()
    return path || null
  }
  return {
    wordcraft: pick(CRAFT_CLI.wordcraft),
    gridcraft: pick(CRAFT_CLI.gridcraft),
    deckcraft: pick(CRAFT_CLI.deckcraft),
  }
}
