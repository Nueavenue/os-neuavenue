import { describe, expect, it } from 'vitest'
import { gateAiRequest, gateOfficeRequest, loadAiPrefs, loadUsage, patchAiPrefs, recordUsage, shownModelOptions } from './aiPrefs'

function memory(): Storage {
  const rows = new Map<string, string>()
  return {
    get length() {
      return rows.size
    },
    clear: () => rows.clear(),
    getItem: (key) => rows.get(key) ?? null,
    key: (i) => [...rows.keys()][i] ?? null,
    removeItem: (key) => void rows.delete(key),
    setItem: (key, value) => void rows.set(key, String(value)),
  }
}

describe('aiPrefs', () => {
  it('shows only chosen models, plus the current one', () => {
    const prefs = { ...loadAiPrefs(memory()), shown: ['gemini-4-argon', 'perplexity-sonar-pro'] }
    expect(shownModelOptions(prefs).map((row) => row.id)).toEqual(['gemini-4-argon', 'perplexity-sonar-pro'])
    expect(shownModelOptions(prefs, 'gpt-6-astra').map((row) => row.id)).toContain('gpt-6-astra')
  })

  it('blocks past the daily limit', () => {
    const storage = memory()
    const now = new Date(2026, 10, 3, 9)
    patchAiPrefs({ dailyLimit: 2 }, storage)
    recordUsage(10, true, storage, now)
    recordUsage(10, true, storage, now)
    const gate = gateOfficeRequest('os.neu-local', () => true, storage, now)
    expect(gate.ok).toBe(false)
    expect(loadUsage(storage, new Date(2026, 10, 4, 9)).dayCount).toBe(0)
  })

  it('asks once per cloud vendor and never for local', () => {
    const storage = memory()
    let asked = 0
    const ask = () => {
      asked += 1
      return true
    }
    expect(gateOfficeRequest('os.neu-local', ask, storage).ok).toBe(true)
    expect(asked).toBe(0)
    expect(gateOfficeRequest('perplexity-sonar-pro', ask, storage).ok).toBe(true)
    expect(gateOfficeRequest('perplexity-sonar-pro', ask, storage).ok).toBe(true)
    expect(asked).toBe(1)
    expect(gateOfficeRequest('gemini-4-argon', () => false, storage).ok).toBe(false)
  })

  it('gates fixed-vendor services (coach, speech-to-text) by vendor', () => {
    const storage = memory()
    let asked = 0
    const ask = () => {
      asked += 1
      return true
    }
    const openai = { vendorId: 'openai', vendor: 'OpenAI' }
    expect(gateAiRequest(openai, ask, storage).ok).toBe(true)
    expect(gateOfficeRequest('gpt-6-astra', ask, storage).ok).toBe(true)
    expect(asked).toBe(1)
    patchAiPrefs({ dailyLimit: 1 }, storage)
    recordUsage(0, true, storage)
    expect(gateAiRequest(openai, ask, storage).ok).toBe(false)
  })
})
