/** Customer-visible os.neu build version (Linux plant + Windows Setup). */

declare const __OSNEU_VERSION__: string | undefined

const FALLBACK = '1.0.13'

function fromBuild(): string {
  try {
    if (typeof __OSNEU_VERSION__ === 'string' && __OSNEU_VERSION__.trim()) {
      return __OSNEU_VERSION__.trim()
    }
  } catch {
    /* define missing in some test runners */
  }
  return FALLBACK
}

/** Semver without leading v, e.g. 1.0.12 */
export function appVersionRaw(): string {
  return fromBuild().replace(/^v/i, '')
}

/** Label shown in chrome, e.g. v1.0.12 */
export function appVersionLabel(): string {
  return `v${appVersionRaw()}`
}

/** Prefer Electron packaged version when the shell exposes it. */
export async function resolveAppVersionLabel(): Promise<string> {
  try {
    const row = await window.neuos?.appVersion?.()
    const text = String(row?.version || '').trim().replace(/^v/i, '')
    if (row?.ok && text) return `v${text}`
  } catch {
    /* browser / tests */
  }
  return appVersionLabel()
}
