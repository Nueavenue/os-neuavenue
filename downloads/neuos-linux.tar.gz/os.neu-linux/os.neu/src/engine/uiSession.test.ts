import { describe, expect, it } from 'vitest'
import { peekUiToken, rememberUiToken, UI_TOKEN_HEADER, uiSessionHeaders } from './uiSession'

describe('uiSession helper', () => {
  it('reads the meta tag and adds the UI header', () => {
    rememberUiToken('')
    const doc = {
      querySelector: (sel: string) =>
        sel.includes('osneu-ui-token') ? { getAttribute: () => 'unit-test-token' } : null,
    }
    expect(peekUiToken(doc)).toBe('unit-test-token')
    expect(uiSessionHeaders({ 'x-osneu-token': 'user' })[UI_TOKEN_HEADER]).toBe('unit-test-token')
    rememberUiToken('')
  })
})
