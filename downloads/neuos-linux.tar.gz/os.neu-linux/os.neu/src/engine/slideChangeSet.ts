/**
 * PPT Studio steps 4–6 — ChangeSets, structural slide ops, session undo/restore.
 * Recipe version stays 1. Element edits never call fillDeck / applyAssistResult.
 */
import {
  FIT_BUDGETS,
  fitDeck,
  fitSlide,
  primitiveOf,
  type OverflowMessageKey,
} from './contentFitter'
import {
  applySelectedText,
  cloneSlide,
  patchDeckSlide,
  selectedText,
  type SlideElementSel,
} from './slideAgentEdit'
import {
  MAX_BULLETS,
  MAX_SLIDES,
  defaultSlide,
  serializeRecipe,
  wantsFullDeckReplace,
  type RecipeSlide,
} from './slidesRecipe'

export type ChangeScope = 'element' | 'slide' | 'slides' | 'deck'

export type TypedAction =
  | 'REWRITE_CONTENT'
  | 'TRANSLATE'
  | 'EDIT_TEXT'
  | 'REPLACE_TEXT'
  | 'CREATE_SLIDE'
  | 'DELETE_SLIDE'
  | 'DUPLICATE_SLIDE'
  | 'MOVE_SLIDE'
  | 'MERGE_SLIDES'
  | 'SPLIT_SLIDE'
  | 'FIX_OVERFLOW'
  | 'RUN_QA'
  | 'VERIFY_FACT'

export const UNAVAILABLE_ON_RECIPE = ['IMAGE', 'CHART', 'FREEFORM'] as const
export type UnavailableAction = (typeof UNAVAILABLE_ON_RECIPE)[number]

export type ChangeStatus = 'proposed' | 'approved' | 'rejected' | 'applied' | 'reverted'
export type ApplyBlock = 'unverified' | 'needs-confirm' | 'unavailable' | 'cap'

export type ChangeSet = {
  id: string
  scope: ChangeScope
  targetIds: string[]
  action: TypedAction | UnavailableAction
  before: string
  after: string
  reason: string
  status: ChangeStatus
  beforeSlides: RecipeSlide[]
  afterSlides: RecipeSlide[]
  indexAfter: number
  applyBlocked?: ApplyBlock
  capMessage?: string
}

export type SessionVersion = {
  id: string
  at: string
  label: string
  slides: RecipeSlide[]
  index: number
}

export type QaCheckId = 'overflow' | 'empty-title' | 'duplicate-title'

export type QaFinding = {
  check: QaCheckId
  slideIndex: number
  messageEn: string
  messageKo: string
  overflowKey?: OverflowMessageKey
}

export type SlideRailStatus = 'draft' | 'generating' | 'ready' | 'modified' | 'needs-review' | 'qa-warning'

export function cloneDeck(slides: RecipeSlide[]): RecipeSlide[] {
  return serializeRecipe(undefined, slides).slides.map(cloneSlide)
}

export function newChangeId(): string {
  return `cs-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

function baseChange(partial: Omit<ChangeSet, 'id' | 'status'> & { id?: string; status?: ChangeStatus }): ChangeSet {
  return { id: partial.id || newChangeId(), status: partial.status || 'proposed', ...partial }
}

export function summarizeSlide(slide: RecipeSlide | undefined): string {
  if (!slide) return ''
  const body = (slide.body || slide.bullets.join('\n')).trim()
  return [slide.title, body].filter(Boolean).join('\n')
}

export function elementEditIgnoresFullReplace(instruction: string): boolean {
  return wantsFullDeckReplace(instruction)
}

/** Patch one field. Extra text such as "10 slides" does not replace the deck. */
export function proposeElementEdit(
  slides: RecipeSlide[],
  index: number,
  sel: SlideElementSel,
  afterText: string,
  opts?: { action?: TypedAction; reason?: string; extra?: string },
): ChangeSet {
  const slide = slides[index]
  const before = selectedText(slide, sel)
  const nextSlide = applySelectedText(slide, sel, afterText)
  const afterSlides = patchDeckSlide(slides, index, nextSlide)
  return baseChange({
    scope: 'element',
    targetIds: [`slide:${index}`, `el:${sel.kind}`],
    action: opts?.action || 'REWRITE_CONTENT',
    before,
    after: selectedText(nextSlide, sel),
    reason: opts?.reason || opts?.extra || 'element edit',
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: index,
  })
}

export function proposeSlideReplace(slides: RecipeSlide[], index: number, next: RecipeSlide, reason: string): ChangeSet {
  const afterSlides = patchDeckSlide(slides, index, next)
  return baseChange({
    scope: 'slide',
    targetIds: [`slide:${index}`],
    action: 'REWRITE_CONTENT',
    before: summarizeSlide(slides[index]),
    after: summarizeSlide(next),
    reason,
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: index,
  })
}

export function proposeCreateSlide(slides: RecipeSlide[], afterIndex: number): ChangeSet {
  if (slides.length >= MAX_SLIDES) {
    return baseChange({
      scope: 'slide',
      targetIds: [`slide:${afterIndex}`],
      action: 'CREATE_SLIDE',
      before: summarizeSlide(slides[afterIndex]),
      after: summarizeSlide(slides[afterIndex]),
      reason: 'cap',
      beforeSlides: cloneDeck(slides),
      afterSlides: cloneDeck(slides),
      indexAfter: afterIndex,
      applyBlocked: 'cap',
      capMessage: `This deck is at the ${MAX_SLIDES} slide cap.`,
    })
  }
  const insertAt = Math.min(afterIndex + 1, slides.length)
  const created = defaultSlide(insertAt)
  const afterSlides = cloneDeck(slides)
  afterSlides.splice(insertAt, 0, created)
  return baseChange({
    scope: 'slide',
    targetIds: [`slide:${insertAt}`],
    action: 'CREATE_SLIDE',
    before: '',
    after: summarizeSlide(created),
    reason: 'create slide',
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: insertAt,
  })
}

export function proposeDeleteSlides(slides: RecipeSlide[], indices: number[]): ChangeSet {
  const unique = [...new Set(indices.filter((i) => i >= 0 && i < slides.length))].sort((a, b) => b - a)
  const before = unique.map((i) => summarizeSlide(slides[i])).join('\n---\n')
  if (slides.length - unique.length < 1) {
    return baseChange({
      scope: unique.length > 1 ? 'slides' : 'slide',
      targetIds: unique.map((i) => `slide:${i}`),
      action: 'DELETE_SLIDE',
      before,
      after: before,
      reason: 'cap',
      beforeSlides: cloneDeck(slides),
      afterSlides: cloneDeck(slides),
      indexAfter: unique[0] ?? 0,
      applyBlocked: 'cap',
      capMessage: 'Keep at least one slide.',
    })
  }
  const afterSlides = cloneDeck(slides)
  for (const i of unique) afterSlides.splice(i, 1)
  const indexAfter = Math.min(Math.min(...unique), afterSlides.length - 1)
  return baseChange({
    scope: unique.length > 1 ? 'slides' : 'slide',
    targetIds: unique.map((i) => `slide:${i}`),
    action: 'DELETE_SLIDE',
    before,
    after: '',
    reason: 'delete slide',
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: Math.max(0, indexAfter),
  })
}

export function proposeDuplicateSlide(slides: RecipeSlide[], index: number): ChangeSet {
  if (slides.length >= MAX_SLIDES) {
    return baseChange({
      scope: 'slide',
      targetIds: [`slide:${index}`],
      action: 'DUPLICATE_SLIDE',
      before: summarizeSlide(slides[index]),
      after: summarizeSlide(slides[index]),
      reason: 'cap',
      beforeSlides: cloneDeck(slides),
      afterSlides: cloneDeck(slides),
      indexAfter: index,
      applyBlocked: 'cap',
      capMessage: `This deck is at the ${MAX_SLIDES} slide cap.`,
    })
  }
  const copy = cloneSlide(slides[index])
  const afterSlides = cloneDeck(slides)
  afterSlides.splice(index + 1, 0, copy)
  return baseChange({
    scope: 'slide',
    targetIds: [`slide:${index}`, `slide:${index + 1}`],
    action: 'DUPLICATE_SLIDE',
    before: summarizeSlide(slides[index]),
    after: summarizeSlide(copy),
    reason: 'duplicate slide',
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: index + 1,
  })
}

export function proposeMoveSlide(slides: RecipeSlide[], index: number, to: number): ChangeSet {
  const dest = Math.min(Math.max(to, 0), slides.length - 1)
  if (dest === index) {
    return baseChange({
      scope: 'slide',
      targetIds: [`slide:${index}`],
      action: 'MOVE_SLIDE',
      before: summarizeSlide(slides[index]),
      after: summarizeSlide(slides[index]),
      reason: 'no move',
      beforeSlides: cloneDeck(slides),
      afterSlides: cloneDeck(slides),
      indexAfter: index,
    })
  }
  const afterSlides = cloneDeck(slides)
  const [row] = afterSlides.splice(index, 1)
  afterSlides.splice(dest, 0, row)
  return baseChange({
    scope: 'slide',
    targetIds: [`slide:${index}`, `slide:${dest}`],
    action: 'MOVE_SLIDE',
    before: summarizeSlide(slides[index]),
    after: summarizeSlide(row),
    reason: `move ${index + 1} → ${dest + 1}`,
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: dest,
  })
}

export function proposeMergeSlides(slides: RecipeSlide[], a: number, b: number): ChangeSet {
  if (a === b || a < 0 || b < 0 || a >= slides.length || b >= slides.length) {
    return baseChange({
      scope: 'slides',
      targetIds: [`slide:${a}`, `slide:${b}`],
      action: 'MERGE_SLIDES',
      before: summarizeSlide(slides[a]),
      after: summarizeSlide(slides[a]),
      reason: 'need two slides',
      beforeSlides: cloneDeck(slides),
      afterSlides: cloneDeck(slides),
      indexAfter: Math.max(0, a),
      applyBlocked: 'cap',
      capMessage: 'Pick two slides to merge.',
    })
  }
  const first = Math.min(a, b)
  const second = Math.max(a, b)
  const left = cloneSlide(slides[first])
  const right = slides[second]
  const lines = [...bulletLines(left), ...bulletLines(right)]
  const overflow = lines.length > MAX_BULLETS
  const kept = lines.slice(0, MAX_BULLETS)
  left.body = kept.join('\n')
  left.bullets = kept.filter(Boolean)
  if (!left.title.trim()) left.title = right.title
  const afterSlides = cloneDeck(slides)
  afterSlides[first] = left
  afterSlides.splice(second, 1)
  return baseChange({
    scope: 'slides',
    targetIds: [`slide:${first}`, `slide:${second}`],
    action: 'MERGE_SLIDES',
    before: `${summarizeSlide(slides[first])}\n---\n${summarizeSlide(slides[second])}`,
    after: summarizeSlide(left),
    reason: overflow ? `Merged. Extra bullets past ${MAX_BULLETS} were not kept.` : 'merge slides',
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: first,
    capMessage: overflow ? `Kept ${MAX_BULLETS} bullets (cap).` : undefined,
  })
}

function bulletLines(slide: RecipeSlide): string[] {
  if (slide.body) return slide.body.split(/\r?\n/)
  return [...(slide.bullets || [])]
}

export function proposeUnavailable(slides: RecipeSlide[], index: number, action: UnavailableAction): ChangeSet {
  return baseChange({
    scope: 'slide',
    targetIds: [`slide:${index}`],
    action,
    before: summarizeSlide(slides[index]),
    after: summarizeSlide(slides[index]),
    reason: 'unavailable on this recipe',
    beforeSlides: cloneDeck(slides),
    afterSlides: cloneDeck(slides),
    indexAfter: index,
    applyBlocked: 'unavailable',
  })
}

export function proposeDeckRewrite(
  slides: RecipeSlide[],
  next: RecipeSlide[],
  confirmed: boolean,
  reason: string,
): ChangeSet {
  const afterSlides = cloneDeck(next).slice(0, MAX_SLIDES)
  const cap = next.length > MAX_SLIDES
  return baseChange({
    scope: 'deck',
    targetIds: slides.map((_, i) => `slide:${i}`),
    action: 'REWRITE_CONTENT',
    before: slides.map(summarizeSlide).join('\n---\n'),
    after: afterSlides.map(summarizeSlide).join('\n---\n'),
    reason,
    beforeSlides: cloneDeck(slides),
    afterSlides,
    indexAfter: 0,
    applyBlocked: confirmed ? (cap ? 'cap' : undefined) : 'needs-confirm',
    capMessage: cap ? `Outline is ${next.length} slides. Cap is ${MAX_SLIDES}.` : undefined,
  })
}

export function withDeckConfirm(change: ChangeSet, confirmed: boolean): ChangeSet {
  if (change.scope !== 'deck') return change
  if (change.applyBlocked === 'unverified' || change.applyBlocked === 'unavailable' || change.applyBlocked === 'cap') {
    return change
  }
  return { ...change, applyBlocked: confirmed ? undefined : 'needs-confirm' }
}

export function canApply(change: ChangeSet, confirmedDeck: boolean): boolean {
  if (change.status !== 'proposed') return false
  if (change.applyBlocked === 'unverified' || change.applyBlocked === 'unavailable' || change.applyBlocked === 'cap') {
    return false
  }
  if (change.scope === 'deck' && (!confirmedDeck || change.applyBlocked === 'needs-confirm')) return false
  return true
}

export function applyChangeSet(
  change: ChangeSet,
  confirmedDeck: boolean,
): { ok: true; change: ChangeSet; slides: RecipeSlide[]; index: number } | { ok: false; reason: ApplyBlock | 'not-proposed' } {
  if (!canApply(change, confirmedDeck)) {
    return { ok: false, reason: change.applyBlocked || 'needs-confirm' }
  }
  const applied: ChangeSet = { ...change, status: 'applied', applyBlocked: undefined }
  return { ok: true, change: applied, slides: cloneDeck(change.afterSlides), index: change.indexAfter }
}

export function rejectChangeSet(change: ChangeSet): ChangeSet {
  return { ...change, status: 'rejected' }
}

export function snapshotVersion(slides: RecipeSlide[], index: number, label: string): SessionVersion {
  return {
    id: `v-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    at: new Date().toISOString(),
    label,
    slides: cloneDeck(slides),
    index,
  }
}

export function undoVersion(
  versions: SessionVersion[],
  cursor: number,
): { cursor: number; snap: SessionVersion } | null {
  if (cursor <= 0 || !versions[cursor - 1]) return null
  return { cursor: cursor - 1, snap: versions[cursor - 1] }
}

export function redoVersion(
  versions: SessionVersion[],
  cursor: number,
): { cursor: number; snap: SessionVersion } | null {
  if (cursor >= versions.length - 1 || !versions[cursor + 1]) return null
  return { cursor: cursor + 1, snap: versions[cursor + 1] }
}

export function restoreVersion(versions: SessionVersion[], id: string): { cursor: number; snap: SessionVersion } | null {
  const cursor = versions.findIndex((row) => row.id === id)
  if (cursor < 0) return null
  return { cursor, snap: versions[cursor] }
}

export function runQa(slides: RecipeSlide[]): { ran: QaCheckId[]; findings: QaFinding[] } {
  const ran: QaCheckId[] = ['overflow', 'empty-title', 'duplicate-title']
  const findings: QaFinding[] = []
  const fit = fitDeck(slides)
  fit.results.forEach((result, slideIndex) => {
    if (!result.overflow || !result.messageKey) return
    findings.push({
      check: 'overflow',
      slideIndex,
      overflowKey: result.messageKey,
      messageEn: `Slide ${slideIndex + 1} overflow (${result.messageKey}, ${result.used}/${result.budget}).`,
      messageKo: `${slideIndex + 1}장 넘침 (${result.messageKey}, ${result.used}/${result.budget}).`,
    })
  })
  slides.forEach((slide, slideIndex) => {
    if (slide.title.trim()) return
    findings.push({
      check: 'empty-title',
      slideIndex,
      messageEn: `Slide ${slideIndex + 1} has an empty title.`,
      messageKo: `${slideIndex + 1}장 제목이 비어 있습니다.`,
    })
  })
  const seen = new Map<string, number>()
  slides.forEach((slide, slideIndex) => {
    const key = slide.title.trim().toLowerCase()
    if (!key) return
    const first = seen.get(key)
    if (first == null) {
      seen.set(key, slideIndex)
      return
    }
    findings.push({
      check: 'duplicate-title',
      slideIndex,
      messageEn: `Slide ${slideIndex + 1} title duplicates slide ${first + 1}.`,
      messageKo: `${slideIndex + 1}장 제목이 ${first + 1}장과 같습니다.`,
    })
  })
  return { ran, findings }
}

export function qaSummaryText(findings: QaFinding[], ran: QaCheckId[], ko: boolean): string {
  const ranLine = ko ? `검사함: ${ran.join(', ')}` : `Ran: ${ran.join(', ')}`
  if (!findings.length) return ko ? `${ranLine}. 문제 없음.` : `${ranLine}. No issues.`
  const lines = findings.map((row) => (ko ? row.messageKo : row.messageEn))
  return `${ranLine}\n${lines.join('\n')}`
}

function titleBudget(slide: RecipeSlide): number {
  const primitive = primitiveOf(slide)
  if (primitive === 'section-divider') return FIT_BUDGETS['section-divider'].titleChars
  if (primitive === 'metric') return FIT_BUDGETS.metric.titleChars
  if (primitive === 'table') return FIT_BUDGETS.table.titleChars
  if (primitive === 'title') return FIT_BUDGETS.title.titleChars
  return FIT_BUDGETS.bullets.titleChars
}

export function proposeQaFix(slides: RecipeSlide[], finding: QaFinding): ChangeSet | null {
  const slide = cloneSlide(slides[finding.slideIndex])
  if (finding.check === 'empty-title') {
    slide.title = `Slide ${finding.slideIndex + 1}`
    return proposeSlideReplace(slides, finding.slideIndex, slide, 'empty title')
  }
  if (finding.check === 'duplicate-title') {
    slide.title = `${slide.title} (${finding.slideIndex + 1})`
    return proposeSlideReplace(slides, finding.slideIndex, slide, 'duplicate title')
  }
  const fit = fitSlide(slide)
  if (!fit.overflow || !fit.messageKey) return null
  if (fit.messageKey === 'title-long' || fit.messageKey === 'divider-long') {
    slide.title = slide.title.slice(0, titleBudget(slide))
  } else if (fit.messageKey === 'body-long') {
    slide.body = slide.body.slice(0, FIT_BUDGETS.title.bodyChars)
  } else if (fit.messageKey === 'bullet-long' || fit.messageKey === 'too-many-bullets') {
    const budget = primitiveOf(slide) === 'two-column' ? FIT_BUDGETS['two-column'] : FIT_BUDGETS.bullets
    const lines = bulletLines(slide)
      .slice(0, budget.maxBullets)
      .map((line) => line.slice(0, budget.bulletChars))
    slide.body = lines.join('\n')
    slide.bullets = lines.filter(Boolean)
  } else if (fit.messageKey === 'table-wide' && slide.table) {
    const cell = FIT_BUDGETS.table.cellChars
    slide.table = {
      headers: slide.table.headers.map((h) => h.slice(0, cell)),
      rows: slide.table.rows.map((row) => row.map((c) => c.slice(0, cell))),
    }
  } else if (fit.messageKey === 'metric-long') {
    if (slide.table?.rows[0]) {
      slide.table.rows[0][1] = (slide.table.rows[0][1] || '').slice(0, FIT_BUDGETS.metric.valueChars)
    } else {
      slide.body = slide.body.slice(0, FIT_BUDGETS.metric.valueChars)
    }
  }
  return {
    ...proposeSlideReplace(slides, finding.slideIndex, slide, 'overflow'),
    action: 'FIX_OVERFLOW',
  }
}

/** Recipe has no source field. A number with no stored source stays unverified. Apply stays off. */
export function proposeVerifyFact(slides: RecipeSlide[], index: number, sel: SlideElementSel | null): ChangeSet {
  const text = sel ? selectedText(slides[index], sel) : summarizeSlide(slides[index])
  const hasNumber = /\d/.test(text)
  return baseChange({
    scope: sel ? 'element' : 'slide',
    targetIds: sel ? [`slide:${index}`, `el:${sel.kind}`] : [`slide:${index}`],
    action: 'VERIFY_FACT',
    before: text,
    after: text,
    reason: hasNumber ? 'unverified: no stored source' : 'unverified: no metric number in this selection',
    beforeSlides: cloneDeck(slides),
    afterSlides: cloneDeck(slides),
    indexAfter: index,
    applyBlocked: 'unverified',
  })
}

export function railStatus(opts: {
  slide: RecipeSlide
  index: number
  current: number
  busy: boolean
  proposedTargets: string[]
  modified: Set<number>
  findings: QaFinding[]
}): SlideRailStatus {
  if (opts.busy && opts.index === opts.current) return 'generating'
  if (opts.proposedTargets.includes(`slide:${opts.index}`)) return 'needs-review'
  if (opts.findings.some((row) => row.slideIndex === opts.index)) return 'qa-warning'
  if (opts.modified.has(opts.index)) return 'modified'
  if (!opts.slide.title.trim() && !opts.slide.body.trim()) return 'draft'
  return 'ready'
}

export function historyLabel(change: ChangeSet): string {
  const verb =
    change.action === 'DELETE_SLIDE'
      ? 'deleted slide'
      : change.action === 'CREATE_SLIDE'
        ? 'created slide'
        : change.action === 'DUPLICATE_SLIDE'
          ? 'duplicated slide'
          : change.action === 'MOVE_SLIDE'
            ? 'moved slide'
            : change.action === 'MERGE_SLIDES'
              ? 'merged slides'
              : change.action === 'FIX_OVERFLOW'
                ? 'fixed overflow'
                : change.action === 'VERIFY_FACT'
                  ? 'fact check'
                  : change.action === 'TRANSLATE'
                    ? 'translated'
                    : 'rewrote'
  return `AI: ${verb}`
}
