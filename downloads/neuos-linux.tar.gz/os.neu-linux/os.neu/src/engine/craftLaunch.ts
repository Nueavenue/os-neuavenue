import { CRAFT_CLI, detectCraftBins, type CraftBins } from './craftDetect'

export const CRAFT_LAUNCH_MISSING = '아직 없음'

export const CRAFT_LAUNCH = [
  { id: 'neu-word', label: 'NeuWord doc' },
  { id: 'neu-excel', label: 'Neu Excel' },
  { id: 'neu-prez', label: 'Neu Prez' },
] as const

export type CraftLaunchId = (typeof CRAFT_LAUNCH)[number]['id']
export type CraftLaunchLabel = (typeof CRAFT_LAUNCH)[number]['label']

export type CraftLaunchTile = {
  id: CraftLaunchId
  label: CraftLaunchLabel
  ready: boolean
  /** PhoneHome only. N-series — never W / X / P. */
  glyph: 'N'
  /** 006: local craft-web href. Click opens only this. */
  href: string | null
}

export type CraftWebLinks = {
  present?: boolean
  href?: string | null
  word?: string | null
  excel?: string | null
  prez?: string | null
}

export function launchCraftHref(id: CraftLaunchId, web: CraftWebLinks | null): string | null {
  if (!web) return null
  if (id === 'neu-word') return web.word || (web.present ? web.href || null : null)
  if (id === 'neu-excel') return web.excel || null
  if (id === 'neu-prez') return web.prez || null
  return null
}

export function planCraftLaunch(
  bins: CraftBins = detectCraftBins({}),
  webPresent = false,
  web: CraftWebLinks | null = null,
): CraftLaunchTile[] {
  const links = web || (webPresent ? { present: true } : null)
  return [
    {
      id: 'neu-word',
      label: 'NeuWord doc',
      ready: Boolean(bins.wordcraft) || Boolean(webPresent) || Boolean(web?.word || web?.href),
      glyph: 'N',
      href: launchCraftHref('neu-word', links),
    },
    {
      id: 'neu-excel',
      label: 'Neu Excel',
      ready: Boolean(bins.gridcraft) || Boolean(web?.excel),
      glyph: 'N',
      href: launchCraftHref('neu-excel', links),
    },
    {
      id: 'neu-prez',
      label: 'Neu Prez',
      ready: Boolean(bins.deckcraft) || Boolean(web?.prez),
      glyph: 'N',
      href: launchCraftHref('neu-prez', links),
    },
  ]
}

export function craftLaunchFromBridge(
  detect: { wordcraft?: string | null; gridcraft?: string | null; deckcraft?: string | null } | null,
  web: CraftWebLinks | null,
) {
  if (!detect && !web) return planCraftLaunch(detectCraftBins({}), false, null)
  const bins = detectCraftBins({
    [CRAFT_CLI.wordcraft]: detect?.wordcraft,
    [CRAFT_CLI.gridcraft]: detect?.gridcraft,
    [CRAFT_CLI.deckcraft]: detect?.deckcraft,
  })
  return planCraftLaunch(bins, Boolean(web?.present), web)
}
