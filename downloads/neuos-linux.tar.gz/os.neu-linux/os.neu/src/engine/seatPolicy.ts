/** Product permission for one sentence. Not the developer GRANT tape. */

export type SeatTool = 'browser.open-url' | 'doc.write'

export type SeatPolicy = Record<SeatTool, boolean>

export function seatPolicy(opts: { browserOpenUrl?: boolean; docWrite?: boolean } = {}): SeatPolicy {
  return {
    'browser.open-url': Boolean(opts.browserOpenUrl),
    'doc.write': Boolean(opts.docWrite),
  }
}

export function wantsPageResearch(text: string) {
  return /(조사|분석|현황|검색해|찾아줘|날씨|search|analyze|look\s?up)/i.test(text)
}

export function wantsExternalSend(text: string) {
  return /(이메일|메일로|보내줘|결제|게시|업로드|\bemail\b|\bpublish\b|\bpay\b)/i.test(text)
}
