import { describe, expect, it } from 'vitest'
import { acceptDeckReply, bulletsToComparisonTable, fitSlot, frameSlots, isAssistFailure, metricText, stampLayout } from './slidesLayoutEngine'
import type { RecipeSlide } from './slidesRecipe'

const bulletSlide = (bullets: string[]): RecipeSlide => ({
  layout: 'bullets',
  title: 'Models',
  body: bullets.join('\n'),
  bullets,
  table: null,
})

describe('slides layout engine', () => {
  it('shrinks a long title and does not drop the words from the overflow flag', () => {
    const slot = { ...frameSlots('title').title!, maxLines: 1, w: 18 }
    const long = 'AI Agents Are Transforming Enterprise Software Through Autonomous Workflow Execution Today'
    const fit = fitSlot(long, slot)
    expect(fit.fontPx).toBeLessThan(slot.basePx)
    expect(fit.needsRewrite).toBe(true)
    expect(fit.lines).toHaveLength(1)
  })

  it('leaves a short title at the slot size', () => {
    const slot = frameSlots('title').title!
    const fit = fitSlot('AI Agents in 2026', slot)
    expect(fit.overflow).toBe(false)
    expect(fit.fontPx).toBe(slot.basePx)
    expect(fit.lines).toEqual(['AI Agents in 2026'])
  })

  it('makes a table from the lines the slide already has', () => {
    const next = bulletsToComparisonTable(bulletSlide(['Seat | License', 'Usage | Metered']))
    expect(next?.layout).toBe('table')
    expect(next?.primitive).toBe('table')
    expect(next?.table?.rows[0]).toEqual(['Seat', 'License'])
    expect(next?.table?.rows[1]).toEqual(['Usage', 'Metered'])
    expect(JSON.stringify(next)).not.toMatch(/72%|\$/)
  })

  it('does not invent a note when a line has no divider', () => {
    const next = bulletsToComparisonTable(bulletSlide(['Seat-based SaaS']))
    expect(next?.table?.headers).toEqual(['Item', 'Note'])
    expect(next?.table?.rows).toEqual([['Seat-based SaaS', '']])
  })

  it('reports a metric only when the slide stored one', () => {
    expect(metricText(bulletSlide(['Adoption'])).sourced).toBe(false)
    expect(metricText(bulletSlide(['Adoption'])).value).toBe('')
    const withNumber: RecipeSlide = {
      layout: 'table',
      primitive: 'metric',
      title: 'Adoption',
      body: '',
      bullets: [],
      table: { headers: ['Label', 'Value'], rows: [['Given by the user', '12']] },
    }
    expect(metricText(withNumber)).toEqual({ value: '12', label: 'Given by the user', sourced: true })
  })

  it('does not treat a bridge failure as slide text', () => {
    expect(isAssistFailure('Could not reach the bridge (port 4178).')).toBe(true)
    expect(isAssistFailure('http-502')).toBe(true)
    expect(acceptDeckReply('http-502', 8)).toBe(false)
    expect(isAssistFailure('AI Agents in 2026')).toBe(false)
  })

  it('stamps a primitive without replacing one that is already set', () => {
    expect(stampLayout(bulletSlide(['a'])).primitive).toBe('bullets')
    const titled = stampLayout({ layout: 'title', title: 'Cover', body: '', bullets: [], table: null })
    expect(titled.primitive).toBe('title')
    const kept = stampLayout({ ...bulletSlide(['a']), primitive: 'two-column' })
    expect(kept.primitive).toBe('two-column')
  })
})
