/** Read-only seat identity. Does not decode tokens or import auth. */

export type SeatAccount = { name: string; email: string; admin: boolean }

export type SeatIdentity =
  | { kind: 'supabase'; authUserId: string; email: string }
  | { kind: 'local-or-unknown'; email: string | null; reason: string }

export function seatIdentity(input: {
  account: SeatAccount | null
  authUserId?: string | null
}): SeatIdentity {
  const email = input.account?.email?.trim() || null
  const id = String(input.authUserId || '').trim()
  if (id) {
    return { kind: 'supabase', authUserId: id, email: email || '' }
  }
  if (!email) {
    return {
      kind: 'local-or-unknown',
      email: null,
      reason: '로그인 없음. auth.users.id도 없습니다.',
    }
  }
  return {
    kind: 'local-or-unknown',
    email,
    reason: '이메일은 있습니다. auth.users.id는 로그인 응답에 없어 신원 키로 쓰지 않습니다.',
  }
}
