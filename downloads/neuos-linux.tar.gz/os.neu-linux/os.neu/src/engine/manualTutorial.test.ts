import { existsSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'
import { MANUAL_CHAPTERS, findManualPage, flatManualPages, manualKey } from './manualTutorial'

describe('manual tutorial', () => {
  it('starts with Getting started and the four intro chapters in order', () => {
    expect(MANUAL_CHAPTERS.map((c) => c.title).slice(0, 4)).toEqual([
      'Getting started with OS.neu',
      'Intro to OS.neu',
      'Intro to App.neu',
      'Intro to Daf.neu',
    ])
  })

  it('has unique page keys and every page has steps or a preparing list', () => {
    const all = flatManualPages()
    const keys = all.map(manualKey)
    expect(new Set(keys).size).toBe(keys.length)
    for (const ref of all) {
      const covers = ref.page.preparing?.covers.length ?? 0
      expect(ref.page.steps.length + covers, manualKey(ref)).toBeGreaterThan(0)
    }
  })

  it('shows how to enter os.neu with real screens for boot and Linux', () => {
    for (const key of ['start/enter-boot', 'start/install-linux']) {
      const { current } = findManualPage(key)
      expect(manualKey(current)).toBe(key)
      expect(current.page.preparing).toBeUndefined()
      expect(current.page.steps.filter((s) => s.img).length, key).toBeGreaterThan(0)
    }
    expect(findManualPage('start/enter-boot').current.page.steps[0].img).toBe('40-boot-grub.webp')
  })

  it('lists the pages whose screenshots are still being captured', () => {
    const preparing = flatManualPages()
      .filter((ref) => ref.page.preparing)
      .map(manualKey)
    expect(preparing).toEqual([
      'start/install-windows',
      'start/usb',
      'osneu/voice',
      'osneu/desktop-window',
      'dafneu/popups',
    ])
  })

  it('only points at videos that exist', () => {
    const dir = resolve(__dirname, '../../public/docs/manual/video')
    for (const ref of flatManualPages()) {
      const video = ref.page.preparing?.video
      if (video) expect(existsSync(resolve(dir, video)), video).toBe(true)
    }
  })

  it('only points at screenshots that exist', () => {
    const dir = resolve(__dirname, '../../public/docs/manual/img')
    for (const ref of flatManualPages()) {
      for (const step of ref.page.steps) {
        if (step.img) expect(existsSync(resolve(dir, step.img)), step.img).toBe(true)
      }
    }
  })

  it('documents the Windows local model setup and both failure states', () => {
    const page = findManualPage('help/windows-local-ai').current.page
    const text = page.steps.map((step) => `${step.text}\n${step.code ?? ''}`).join('\n')
    expect(text).toContain('winget install --id Ollama.Ollama -e')
    expect(text).toContain('ollama pull llama3.2:1b')
    expect(text).toContain('127.0.0.1:11434/api/tags')
    expect(text).toContain('local-unavailable')
    expect(text).toContain('Not on this device')
  })

  it('uses all 17 recording frames without presenting the recording as a USB burn', () => {
    const page = findManualPage('start/recorded-seat-tour').current.page
    const frames = page.steps.map((step) => step.img).filter(Boolean)
    expect(frames).toHaveLength(17)
    expect(frames[0]).toBe('70-recording-boot-menu.webp')
    expect(frames.at(-1)).toBe('86-recording-manual.webp')
    expect(`${page.lead}\n${page.tip}`).toContain('not a recording of burning a USB stick')
  })

  it('finds prev / next and falls back to the first page', () => {
    const first = findManualPage('start/what-is')
    expect(first.prev).toBeNull()
    expect(first.next && manualKey(first.next)).toBe('start/home-tour')
    expect(manualKey(findManualPage('nope/nope').current)).toBe('start/what-is')
    const last = flatManualPages().at(-1)!
    expect(findManualPage(manualKey(last)).next).toBeNull()
  })
})
