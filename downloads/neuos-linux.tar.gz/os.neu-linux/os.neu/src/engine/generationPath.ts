/**
 * Generation path contract: a model reply becomes a ChangeSet or nothing.
 * This module does not write a deck.
 */
import { recipeLayoutFor, LAYOUT_PRIMITIVES, type LayoutPrimitiveId } from './layoutContract'
import { proposeDeckRewrite, type ChangeSet } from './slideChangeSet'
import { parseAssistText, parseRecipeJson, type RecipeSlide, type SlideLayout } from './slidesRecipe'
import { acceptDeckReply, isAssistFailure, stampLayout } from './slidesLayoutEngine'

const RECIPE_LAYOUT = new Set<SlideLayout>(['title', 'bullets', 'table'])
const PRIMITIVE = new Set<string>(LAYOUT_PRIMITIVES)
const TEXT_COMPONENT = new Set(['text', 'heading', 'subtitle', 'bullet-list', 'quote'])

export type GenerationReject = 'failed' | 'count' | 'unsupported'

export type GenerationJudgement =
  | { ok: true; slides: RecipeSlide[] }
  | { ok: false; reason: GenerationReject }

function asRecord(raw: unknown): Record<string, unknown> | null {
  return raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : null
}

function jsonCandidate(raw: string): string {
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/i)
  return (fence ? fence[1] : raw).trim()
}

function componentUnsupported(raw: Record<string, unknown>): boolean {
  if (!Array.isArray(raw.components)) return false
  return raw.components.some((item) => {
    const row = asRecord(item)
    const type = typeof row?.type === 'string' ? row.type : ''
    return !TEXT_COMPONENT.has(type)
  })
}

function slideFromRaw(raw: unknown): RecipeSlide | 'unsupported' {
  const obj = asRecord(raw)
  if (!obj) return 'unsupported'
  if (componentUnsupported(obj)) return 'unsupported'
  const layoutRaw = typeof obj.layout === 'string' ? obj.layout : ''
  const primitiveRaw = typeof obj.primitive === 'string' ? obj.primitive : ''
  if (primitiveRaw && !PRIMITIVE.has(primitiveRaw)) return 'unsupported'
  if (layoutRaw && !RECIPE_LAYOUT.has(layoutRaw as SlideLayout) && !PRIMITIVE.has(layoutRaw)) return 'unsupported'
  const primitive = (primitiveRaw || (PRIMITIVE.has(layoutRaw) ? layoutRaw : '')) as LayoutPrimitiveId | ''
  const layout: SlideLayout = RECIPE_LAYOUT.has(layoutRaw as SlideLayout)
    ? (layoutRaw as SlideLayout)
    : primitive
      ? recipeLayoutFor(primitive)
      : 'bullets'
  return {
    layout,
    title: typeof obj.title === 'string' ? obj.title : '',
    body: typeof obj.body === 'string' ? obj.body : '',
    bullets: Array.isArray(obj.bullets) ? obj.bullets.filter((line) => typeof line === 'string') : [],
    table: (layout === 'table' ? obj.table ?? null : null) as RecipeSlide['table'],
    primitive: primitive || undefined,
  }
}

function fromJson(text: string, expectedCount: number): GenerationJudgement | null {
  const candidate = jsonCandidate(text)
  if (!candidate.startsWith('{')) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(candidate)
  } catch {
    return { ok: false, reason: 'failed' }
  }
  const obj = asRecord(parsed)
  if (!obj || !Array.isArray(obj.slides)) return { ok: false, reason: 'failed' }
  if (obj.version !== 1) return { ok: false, reason: 'failed' }
  if (obj.slides.length !== expectedCount) return { ok: false, reason: 'count' }
  const safe: RecipeSlide[] = []
  for (const raw of obj.slides) {
    const slide = slideFromRaw(raw)
    if (slide === 'unsupported') return { ok: false, reason: 'unsupported' }
    safe.push(slide)
  }
  const clamped = parseRecipeJson(JSON.stringify({ version: 1, slides: safe }))
  if (!clamped || clamped.slides.length !== expectedCount) return { ok: false, reason: 'failed' }
  return { ok: true, slides: clamped.slides }
}

/** Does not mutate `text`. A reject means the caller must not build a ChangeSet. */
export function judgeGeneration(text: string, expectedCount: number): GenerationJudgement {
  const raw = (text || '').trim()
  if (!raw || isAssistFailure(raw) || expectedCount < 1) return { ok: false, reason: 'failed' }
  const json = fromJson(raw, expectedCount)
  if (json) return json
  if (!acceptDeckReply(raw, expectedCount)) return { ok: false, reason: 'failed' }
  const markdown = parseAssistText(raw)
  if (markdown.slides.length !== expectedCount) return { ok: false, reason: 'count' }
  return { ok: true, slides: markdown.slides }
}

/** A reject returns null. The deck argument is not written. */
export function generationChangeSet(current: RecipeSlide[], text: string, expectedCount: number): ChangeSet | null {
  const judged = judgeGeneration(text, expectedCount)
  if (!judged.ok) return null
  return proposeDeckRewrite(current, judged.slides.map(stampLayout), false, 'presentation_generation')
}
