import { describe, expect, it } from 'vitest'
import { autoNarrativeOrder, moveIdOrder, parseReorderIntent } from './htmlDeckReorder'

describe('htmlDeckReorder', () => {
  it('autoNarrativeOrder puts cover before ask', () => {
    const ids = ['ask', 'team', 'cover', 'problem']
    expect(autoNarrativeOrder(ids)[0]).toBe('cover')
    expect(autoNarrativeOrder(ids).indexOf('ask')).toBeGreaterThan(autoNarrativeOrder(ids).indexOf('problem'))
  })

  it('moveIdOrder moves 3→1', () => {
    expect(moveIdOrder(['a', 'b', 'c'], 2, 0)).toEqual(['c', 'a', 'b'])
  })

  it('parseReorderIntent reads Korean move', () => {
    const hit = parseReorderIntent('3번을 1번으로 이동', ['a', 'b', 'c'])
    expect(hit?.order).toEqual(['c', 'a', 'b'])
  })

  it('parseReorderIntent auto', () => {
    const hit = parseReorderIntent('자동 순서 정렬', ['ask', 'cover'])
    expect(hit?.type).toBe('auto')
    expect(hit?.order[0]).toBe('cover')
  })
})
