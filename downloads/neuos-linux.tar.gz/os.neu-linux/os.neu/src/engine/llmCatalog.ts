/** User-visible limits for local models. These are not live web models. */

export type LocalLlmCard = {
  id: string
  label: string
  approxGb: number
  limitsKo: string
  limitsEn: string
}

export const LOCAL_LLM_CATALOG: LocalLlmCard[] = [
  {
    id: 'llama3.2:1b',
    label: 'Llama 3.2 1B · short · weak Korean',
    approxGb: 1.3,
    limitsKo:
      'Meta Llama 3.2 1B. 학습 지식은 2023년 12월경에서 멈춥니다. 그 이후 뉴스·가격·날씨는 모릅니다. 웹을 열지 않습니다. 답은 약 120토큰(짧은 문장 몇 개)에서 끊깁니다. 틀린 문장을 사실처럼 쓸 수 있습니다. 의료·법률·투자 결정에 쓰지 마세요. 이 PC 안에서만 계산합니다.',
    limitsEn:
      'Meta Llama 3.2 1B. Knowledge stops around December 2023. It does not browse. Replies stop near 120 tokens. It can state falsehoods. Not for medical, legal, or investment decisions. Compute stays on this PC.',
  },
  {
    id: 'llama3.1:8b',
    label: 'Llama 3.1 8B · longer · slow on CPU',
    approxGb: 4.9,
    limitsKo:
      'Meta Llama 3.1 8B. 학습 지식은 2023년 12월에서 멈춥니다. 오늘 사실을 모릅니다. 웹을 열지 않습니다. 100줄을 보장하지 않고, 최대 약 80줄·1024토큰에서 멈춥니다. CPU만이면 한 문단도 1B보다 오래 걸리고, 수 분 뒤 시간 제한으로 끊길 수 있습니다. 틀린 단정이 있습니다. 의료·법률·투자 금지. 라이선스는 Meta Llama 커뮤니티 라이선스입니다. 받기에는 약 5GB와 여유 1GB가 필요합니다.',
    limitsEn:
      'Meta Llama 3.1 8B. Knowledge cutoff December 2023. No browsing. Not 100 lines; about 80 lines or 1024 tokens. On CPU one paragraph is slower than 1B and may hit the time limit. Can be wrong. Not for medical, legal, or investment use. Llama community license. Download needs about 5GB plus 1GB free.',
  },
  {
    id: 'qwen2.5:7b',
    label: 'Qwen2.5 7B · default · Korean · slow on CPU',
    approxGb: 4.7,
    limitsKo:
      'Alibaba Qwen2.5 7B. 2024년 9월 공개본입니다. 그 이후 사건은 모릅니다. Llama처럼 “2023-12” 한 줄로 고정된 컷오프 문구는 모델 카드에 없습니다. 웹을 열지 않습니다. 한국어는 1B보다 나은 편이지만 틀릴 수 있습니다. 길이·속도·금지 용도는 Llama 3.1 8B와 같습니다. 약 4.7GB.',
    limitsEn:
      'Alibaba Qwen2.5 7B, released September 2024. It does not know later events. No single cutoff line like Llama’s December 2023. No browsing. Korean is often better than 1B and still wrong. Same length, speed, and banned uses as Llama 3.1 8B. About 4.7GB.',
  },
  {
    id: 'gemma2:9b',
    label: 'Gemma 2 9B · English-first · slow on CPU',
    approxGb: 5.5,
    limitsKo:
      'Google Gemma 2 9B. 2024년 6월 공개본입니다. 그 이후 사건은 모릅니다. 웹을 열지 않습니다. 영어가 중심이라 한국어 장문은 더 잘 틀립니다. 길이·속도·금지 용도는 Llama 3.1 8B와 같습니다. 약 5.5GB. Google Gemma 이용 약관이 있습니다.',
    limitsEn:
      'Google Gemma 2 9B, released June 2024. It does not know later events. No browsing. English-first, so long Korean is weaker. Same length, speed, and banned uses as Llama 3.1 8B. About 5.5GB. Gemma terms apply.',
  },
]

/** Korean drafts: Qwen first. 1B mixes scripts and is not the seat default. */
export const DEFAULT_LOCAL_WRITER = 'qwen2.5:7b'
export const LOCAL_WRITER_PREF = ['qwen2.5:7b', 'llama3.1:8b', 'llama3.2:1b'] as const

export function pickDefaultWriter(installed: string[] = []) {
  const have = new Set(installed)
  if (!have.size) return DEFAULT_LOCAL_WRITER
  return LOCAL_WRITER_PREF.find((id) => have.has(id)) || DEFAULT_LOCAL_WRITER
}

export function localCard(id: string): LocalLlmCard | undefined {
  if (id === 'os.neu-local') return LOCAL_LLM_CATALOG[0]
  return LOCAL_LLM_CATALOG.find((row) => row.id === id)
}

export function canPullLocal(freeBytes: number, approxGb: number) {
  const need = Math.round(approxGb * 1_000_000_000) + 1_000_000_000
  return { ok: freeBytes >= need, need }
}
