export function linuxPackHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/api/download/linux'
  return '/downloads/neuos-linux.tar.gz'
}

export function usbKitHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/api/download/pack'
  return '/downloads/neuos-boot-kit.tar.gz'
}
