/**
 * PPT Studio Phase 1 — element / one-slide agent edits.
 * Does not rewrite the deck. Does not invent text when the model is silent.
 */
import {
  MAX_BULLETS,
  bodyFromBullets,
  bulletsFromBody,
  parseRecipeJson,
  serializeRecipe,
  wantsFullDeckReplace,
  type RecipeSlide,
} from './slidesRecipe'

export type AgentAction = 'rewrite' | 'shorten' | 'improve' | 'translate' | 'delete' | 'add'
export type AgentScope = 'element' | 'slide' | 'slides' | 'deck'
export type ElementKind = 'title' | 'body' | 'bullet' | 'cell'

export type SlideElementSel = {
  kind: ElementKind
  bulletIndex?: number
  row?: number
  col?: number
}

export type AgentHistoryLine = {
  at: string
  text: string
  source: 'ai' | 'user'
}

export type AgentPreview = {
  before: string
  after: string
  nextSlides: RecipeSlide[]
  action: AgentAction
  scope: AgentScope
}

export const ENTIRE_DECK_SCOPE_ENABLED = true

export function cloneSlide(slide: RecipeSlide): RecipeSlide {
  return {
    ...slide,
    bullets: [...(slide.bullets || [])],
    table: slide.table
      ? { headers: [...slide.table.headers], rows: slide.table.rows.map((row) => [...row]) }
      : null,
  }
}

export function patchDeckSlide(slides: RecipeSlide[], index: number, next: RecipeSlide): RecipeSlide[] {
  if (index < 0 || index >= slides.length) return slides
  const clamped = serializeRecipe(undefined, [next]).slides[0] || next
  return slides.map((slide, i) => (i === index ? clamped : slide))
}

export function selectedText(slide: RecipeSlide, sel: SlideElementSel | null): string {
  if (!sel) return ''
  if (sel.kind === 'title') return slide.title || ''
  if (sel.kind === 'body') return slide.body || ''
  if (sel.kind === 'bullet') {
    const lines = bulletLines(slide)
    return lines[sel.bulletIndex ?? 0] || ''
  }
  const table = slide.table
  if (!table) return ''
  const row = sel.row ?? -1
  const col = sel.col ?? -1
  if (row < 0) return table.headers[col] || ''
  return table.rows[row]?.[col] || ''
}

export function applySelectedText(slide: RecipeSlide, sel: SlideElementSel, text: string): RecipeSlide {
  const next = cloneSlide(slide)
  if (sel.kind === 'title') {
    next.title = text
    return next
  }
  if (sel.kind === 'body') {
    next.body = text
    next.bullets = next.layout === 'bullets' ? bulletsFromBody(text) : []
    return next
  }
  if (sel.kind === 'bullet') {
    const lines = bulletLines(next)
    const i = Math.min(Math.max(sel.bulletIndex ?? 0, 0), Math.max(lines.length - 1, 0))
    if (!lines.length) lines.push(text)
    else lines[i] = text
    next.body = bodyFromBullets(lines)
    next.bullets = bulletsFromBody(next.body)
    return next
  }
  if (!next.table) return next
  const col = sel.col ?? 0
  const row = sel.row ?? -1
  if (row < 0) {
    const headers = [...next.table.headers]
    if (col >= 0 && col < headers.length) headers[col] = text
    next.table = { ...next.table, headers }
    return next
  }
  const rows = next.table.rows.map((r) => [...r])
  if (rows[row] && col >= 0) rows[row][col] = text
  next.table = { ...next.table, rows }
  return next
}

export function deleteSelected(slide: RecipeSlide, sel: SlideElementSel): RecipeSlide {
  if (sel.kind === 'bullet') {
    const lines = bulletLines(slide)
    const i = sel.bulletIndex ?? 0
    if (i < 0 || i >= lines.length) return cloneSlide(slide)
    lines.splice(i, 1)
    const next = cloneSlide(slide)
    next.body = bodyFromBullets(lines)
    next.bullets = bulletsFromBody(next.body)
    return next
  }
  return applySelectedText(slide, sel, '')
}

export function addOnSelected(slide: RecipeSlide, sel: SlideElementSel): RecipeSlide | null {
  if (sel.kind === 'bullet') {
    const lines = bulletLines(slide)
    if (lines.length >= MAX_BULLETS) return null
    const i = Math.min((sel.bulletIndex ?? lines.length - 1) + 1, lines.length)
    lines.splice(i, 0, '')
    const next = cloneSlide(slide)
    next.body = lines.join('\n')
    next.bullets = bulletsFromBody(next.body)
    return next
  }
  if (sel.kind === 'body') {
    const next = cloneSlide(slide)
    next.body = next.body ? `${next.body}\n` : ''
    if (next.layout === 'bullets') next.bullets = bulletsFromBody(next.body)
    return next
  }
  return null
}

export function bulletLines(slide: RecipeSlide): string[] {
  if (slide.body) return slide.body.split(/\r?\n/)
  return [...(slide.bullets || [])]
}

export function parseElementReply(raw: string, sel: SlideElementSel): string | null {
  const text = unwrapFence(raw).trim()
  if (!text) return null
  const json = parseRecipeJson(text)
  if (json?.slides[0]) {
    const fromJson = selectedText(json.slides[0], sel).trim()
    return fromJson || null
  }
  if (text.startsWith('{') && text.includes('"slides"')) return null
  return stripQuotes(text)
}

export function parseSlideReply(raw: string): RecipeSlide | null {
  const json = parseRecipeJson(unwrapFence(raw))
  return json?.slides[0] || null
}

export function agentInstruction(opts: {
  action: Exclude<AgentAction, 'delete' | 'add'>
  scope: Exclude<AgentScope, 'deck'>
  sel: SlideElementSel | null
  extra: string
}): string {
  const extra = opts.extra.trim()
  const field = fieldLabel(opts.sel)
  const verb =
    opts.action === 'shorten'
      ? 'Shorten'
      : opts.action === 'improve'
        ? 'Improve'
        : opts.action === 'translate'
          ? 'Translate'
          : 'Rewrite'
  if (opts.scope === 'slide') {
    return [
      `${verb} this one slide only.`,
      'Return JSON for this one slide (title, body, bullets, table).',
      'Do not change any other slide.',
      extra ? `Note: ${extra}` : '',
    ]
      .filter(Boolean)
      .join(' ')
  }
  return [
    `${verb} only the selected ${field}.`,
    'Return the replacement text only.',
    'Do not return a deck. Do not change other fields or slides.',
    extra ? `Note: ${extra}` : '',
  ]
    .filter(Boolean)
    .join(' ')
}

export function instructionTouchesWholeDeck(instruction: string): boolean {
  return wantsFullDeckReplace(instruction)
}

export function elementLabel(sel: SlideElementSel | null, ko: boolean): string {
  if (!sel) return ko ? '없음' : 'None'
  if (sel.kind === 'title') return ko ? '제목' : 'Title'
  if (sel.kind === 'body') return ko ? '본문' : 'Body'
  if (sel.kind === 'bullet') return ko ? `항목 ${(sel.bulletIndex ?? 0) + 1}` : `Bullet ${(sel.bulletIndex ?? 0) + 1}`
  const row = sel.row ?? -1
  const col = (sel.col ?? 0) + 1
  if (row < 0) return ko ? `표 머리 ${col}` : `Header ${col}`
  return ko ? `표 ${row + 1}행 ${col}열` : `Cell r${row + 1} c${col}`
}

export function historyLine(opts: {
  source: 'ai' | 'user'
  action?: AgentAction
  scope?: AgentScope
  sel: SlideElementSel | null
  ko: boolean
}): string {
  const field = elementLabel(opts.sel, false).toLowerCase()
  if (opts.source === 'user') return `User: edited the ${field}`
  if (opts.scope === 'slide') {
    const verb =
      opts.action === 'shorten'
        ? 'shortened'
        : opts.action === 'improve'
          ? 'improved'
          : opts.action === 'translate'
            ? 'translated'
            : 'rewrote'
    return `AI: ${verb} this slide`
  }
  const verb =
    opts.action === 'shorten'
      ? 'shortened'
      : opts.action === 'improve'
        ? 'improved'
        : opts.action === 'translate'
          ? 'translated'
          : opts.action === 'delete'
            ? 'deleted'
            : opts.action === 'add'
              ? 'added'
              : 'rewrote'
  return `AI: ${verb} the ${field}`
}

export function agentFailMessage(reason: string | undefined, ko: boolean): string {
  const code = reason || 'no-llm'
  if (code === 'network') return ko ? '브리지에 연결하지 못했습니다. 슬라이드는 그대로입니다.' : 'Could not reach the bridge. The slide is unchanged.'
  if (code === 'no-llm') return ko ? '쓸 수 있는 모델이 없습니다. 슬라이드는 그대로입니다.' : 'No model is ready. The slide is unchanged.'
  if (code === 'local-unavailable') return ko ? '로컬 모델이 응답하지 않습니다. 슬라이드는 그대로입니다.' : 'The local model is not answering. The slide is unchanged.'
  if (code === 'empty') return ko ? '모델이 빈 답을 보냈습니다. 슬라이드는 그대로입니다.' : 'The model returned no text. The slide is unchanged.'
  if (code === 'timeout') return ko ? '모델이 시간 안에 끝내지 못했습니다. 슬라이드는 그대로입니다.' : 'The model did not finish in time. The slide is unchanged.'
  return ko ? '에이전트가 이 필드를 바꾸지 못했습니다. 슬라이드는 그대로입니다.' : 'The agent could not change this field. The slide is unchanged.'
}

function fieldLabel(sel: SlideElementSel | null): string {
  if (!sel) return 'field'
  if (sel.kind === 'bullet') return 'bullet'
  if (sel.kind === 'cell') return 'table cell'
  return sel.kind
}

function unwrapFence(raw: string): string {
  const text = String(raw || '').trim()
  const fence = text.match(/^```(?:json|text)?\s*([\s\S]*?)```$/i)
  return fence ? fence[1].trim() : text
}

function stripQuotes(text: string): string {
  if ((text.startsWith('"') && text.endsWith('"')) || (text.startsWith("'") && text.endsWith("'"))) {
    return text.slice(1, -1)
  }
  return text
}
