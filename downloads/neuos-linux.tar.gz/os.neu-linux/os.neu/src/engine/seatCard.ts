import type { SeatStep } from './seatRun'

export function activeSeatStep(steps: SeatStep[]): SeatStep | null {
  const waiting = steps.find((row) => row.status === 'wait' || row.status === 'running')
  if (waiting) return waiting
  const result = steps.find((row) => row.n === 9 && row.status !== 'pending')
  if (result) return result
  const last = [...steps].reverse().find((row) => row.status !== 'pending')
  return last ?? steps[0] ?? null
}

export function oneLine(text: string, max = 96): string {
  const line = text.replace(/[#*_`]/g, ' ').replace(/\s+/g, ' ').trim()
  if (line.length <= max) return line
  return `${line.slice(0, max - 1).trimEnd()}…`
}

export function seatCardLines(
  steps: SeatStep[],
  output: string,
  ko: boolean,
): { stepLine: string; resultLine: string } {
  const row = activeSeatStep(steps)
  const stepLine = row ? `${row.n}. ${row.name}  ${oneLine(row.detail, 72)}`.trim() : ''
  const written = oneLine(output, 88)
  const resultLine =
    written ||
    (row?.status === 'running' || row?.status === 'wait'
      ? ko
        ? '작성 중…'
        : 'Writing…'
      : '')
  return { stepLine, resultLine }
}
