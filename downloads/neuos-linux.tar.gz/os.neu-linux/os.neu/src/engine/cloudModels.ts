/** October 2026 vendor list for Connect Model. Keys stay with the user (BYOK). */

export type CloudApiKind = 'openai' | 'openai-compat' | 'anthropic' | 'google'

export type CloudVendorCard = {
  rank: number
  vendorId: string
  vendor: string
  vendorKo: string
  id: string
  label: string
  apiModel: string
  api: CloudApiKind
  baseUrl?: string
  asOf: '2026-10' | '2026-11'
  noteKo: string
  noteEn: string
}

export const CLOUD_VENDORS_2026: CloudVendorCard[] = [
  {
    rank: 1,
    vendorId: 'anthropic',
    vendor: 'Anthropic',
    vendorKo: '앤트로픽',
    id: 'claude-opus-5.5',
    label: 'Anthropic Claude Opus 5.5',
    apiModel: 'claude-opus-5-5',
    api: 'anthropic',
    asOf: '2026-10',
    noteKo: '2026-10 리더보드 1위권. Anthropic 키가 필요합니다.',
    noteEn: 'October 2026 leaderboard #1 band. Needs an Anthropic key.',
  },
  {
    rank: 2,
    vendorId: 'openai',
    vendor: 'OpenAI',
    vendorKo: '오픈AI',
    id: 'gpt-6-astra',
    label: 'OpenAI GPT-6 Astra',
    apiModel: 'gpt-6',
    api: 'openai',
    asOf: '2026-10',
    noteKo: 'OpenAI 최신 플래그십. 기존 sk- 키를 씁니다.',
    noteEn: 'Current OpenAI flagship. Uses the existing sk- key.',
  },
  {
    rank: 3,
    vendorId: 'google',
    vendor: 'Google',
    vendorKo: '구글',
    id: 'gemini-4-argon',
    label: 'Google Gemini 4 Argon',
    apiModel: 'gemini-4-argon',
    api: 'google',
    asOf: '2026-11',
    noteKo: 'API 모델: gemini-4-argon. 키는 Google 칸에만 넣습니다(AIza…). 429는 키 오류가 아니라 사용량·요금 한도입니다.',
    noteEn: 'API model: gemini-4-argon. Paste the key only in the Google field (AIza…). 429 means quota/rate limit — not a bad key.',
  },
  {
    rank: 4,
    vendorId: 'moonshot',
    vendor: 'Moonshot',
    vendorKo: '문샷',
    id: 'kimi-k3.1-pro',
    label: 'Moonshot Kimi K3.1 Pro',
    apiModel: 'kimi-k3.1',
    api: 'openai-compat',
    baseUrl: 'https://api.moonshot.ai/v1',
    asOf: '2026-10',
    noteKo: 'Moonshot OpenAI 호환 엔드포인트 + 키.',
    noteEn: 'Moonshot OpenAI-compatible endpoint + key.',
  },
  {
    rank: 5,
    vendorId: 'xai',
    vendor: 'xAI',
    vendorKo: 'xAI',
    id: 'grok-4.7',
    label: 'xAI Grok 4.7',
    apiModel: 'grok-4-latest',
    api: 'openai-compat',
    baseUrl: 'https://api.x.ai/v1',
    asOf: '2026-10',
    noteKo: 'xAI 키. OpenAI 호환 /v1/chat/completions.',
    noteEn: 'xAI key. OpenAI-compatible /v1/chat/completions.',
  },
  {
    rank: 6,
    vendorId: 'qwen',
    vendor: 'Alibaba',
    vendorKo: '알리바바',
    id: 'qwen-3.8-max',
    label: 'Alibaba Qwen 3.8 Max',
    apiModel: 'qwen-max',
    api: 'openai-compat',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    asOf: '2026-10',
    noteKo: 'DashScope 호환 모드 키.',
    noteEn: 'DashScope compatible-mode key.',
  },
  {
    rank: 7,
    vendorId: 'deepseek',
    vendor: 'DeepSeek',
    vendorKo: '딥시크',
    id: 'deepseek-v4.1',
    label: 'DeepSeek V4.1',
    apiModel: 'deepseek-chat',
    api: 'openai-compat',
    baseUrl: 'https://api.deepseek.com/v1',
    asOf: '2026-10',
    noteKo: 'DeepSeek 키.',
    noteEn: 'DeepSeek key.',
  },
  {
    rank: 8,
    vendorId: 'meta',
    vendor: 'Meta',
    vendorKo: '메타',
    id: 'muse-spark-1.3',
    label: 'Meta Muse Spark 1.3',
    apiModel: 'llama-4-maverick',
    api: 'openai-compat',
    baseUrl: 'https://api.groq.com/openai/v1',
    asOf: '2026-10',
    noteKo: '호스트(Groq 등) OpenAI 호환 키. Meta 직접 키가 아니면 호스트 키를 넣습니다.',
    noteEn: 'Hosted OpenAI-compatible key (Groq and similar). Not a Meta first-party key.',
  },
  {
    rank: 9,
    vendorId: 'zai',
    vendor: 'Z.ai',
    vendorKo: '지.ai',
    id: 'glm-5.3',
    label: 'Z.ai GLM 5.3',
    apiModel: 'glm-5',
    api: 'openai-compat',
    baseUrl: 'https://api.z.ai/api/paas/v4',
    asOf: '2026-10',
    noteKo: 'Z.ai / Zhipu 키.',
    noteEn: 'Z.ai / Zhipu key.',
  },
  {
    rank: 10,
    vendorId: 'mistral',
    vendor: 'Mistral',
    vendorKo: '미스트랄',
    id: 'mistral-large',
    label: 'Mistral Large',
    apiModel: 'mistral-large-latest',
    api: 'openai-compat',
    baseUrl: 'https://api.mistral.ai/v1',
    asOf: '2026-10',
    noteKo: 'Mistral 키.',
    noteEn: 'Mistral key.',
  },
]

/** Answer engines that search the web while replying. Kept apart from the top-10 leaderboard list. */
export const SEARCH_AI_VENDORS: CloudVendorCard[] = [
  {
    rank: 11,
    vendorId: 'perplexity',
    vendor: 'Perplexity',
    vendorKo: '퍼플렉시티',
    id: 'perplexity-sonar-pro',
    label: 'Perplexity Sonar Pro',
    apiModel: 'sonar-pro',
    api: 'openai-compat',
    baseUrl: 'https://api.perplexity.ai',
    asOf: '2026-10',
    noteKo: 'Perplexity API 키(pplx-)가 필요합니다. 답할 때 웹을 검색합니다.',
    noteEn: 'Needs a Perplexity API key (pplx-). Searches the web while answering.',
  },
]

export const ALL_CLOUD_VENDORS: CloudVendorCard[] = [...CLOUD_VENDORS_2026, ...SEARCH_AI_VENDORS]

export const LEGACY_OPENAI_MODELS = [
  { id: 'gpt-4.1', label: 'OpenAI GPT-4.1' },
  { id: 'gpt-4.1-mini', label: 'OpenAI GPT-4.1 mini' },
  { id: 'gpt-4o', label: 'OpenAI GPT-4o' },
  { id: 'gpt-4o-mini', label: 'OpenAI GPT-4o mini' },
] as const

export function cloudCard(id: string): CloudVendorCard | undefined {
  return ALL_CLOUD_VENDORS.find((row) => row.id === id || row.apiModel === id)
}

export function isCloudModel(id: string): boolean {
  const name = String(id || '')
  if (name.startsWith('gpt-')) return true
  return Boolean(cloudCard(name))
}

export function officeModelList(): { id: string; label: string }[] {
  return [
    { id: 'os.neu-local', label: 'os.neu-local (Llama 3.2 1B · weak Korean)' },
    ...ALL_CLOUD_VENDORS.map((row) => ({ id: row.id, label: row.label })),
    ...LEGACY_OPENAI_MODELS.map((row) => ({ id: row.id, label: row.label })),
  ]
}
