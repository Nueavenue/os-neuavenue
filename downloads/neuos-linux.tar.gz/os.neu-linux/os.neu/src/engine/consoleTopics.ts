import type { ChatBubble } from '../components/ChatThread'

export type TopicKind = 'topic' | 'project'

export type ConsoleTopic = {
  id: string
  kind: TopicKind
  title: string
  titleEn: string
  hint: string
  hintEn: string
  seed: string
  seedEn: string
}

export type TalkGroup = {
  id: string
  title: string
  titleEn: string
  builtin?: boolean
  topics: ConsoleTopic[]
}

export type TalkPack = {
  customized: boolean
  activeGroupId: string
  activeTopicId: string
  groups: TalkGroup[]
  threads: Record<string, ChatBubble[]>
}

type Store = {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export const BUILTIN_TOPICS: ConsoleTopic[] = [
  {
    id: 'general',
    kind: 'topic',
    title: '일반',
    titleEn: 'General',
    hint: '콘솔에서 한 줄로 묻기',
    hintEn: 'Ask one line on the console',
    seed: '지금 이 기기에서 무엇을 먼저 할까요?',
    seedEn: 'What should we do first on this machine?',
  },
  {
    id: 'hardware',
    kind: 'topic',
    title: '하드웨어',
    titleEn: 'Hardware',
    hint: '장치 · 버전 · 업데이트',
    hintEn: 'Devices, versions, updates',
    seed: '이 PC 하드웨어를 짧게 읽어 주세요.',
    seedEn: 'Please read this PC hardware briefly.',
  },
  {
    id: 'network',
    kind: 'topic',
    title: '네트워크',
    titleEn: 'Network',
    hint: '연결 · 온라인 여부',
    hintEn: 'Link and online state',
    seed: '네트워크 상태를 확인해 주세요.',
    seedEn: 'Please check the network state.',
  },
  {
    id: 'memory',
    kind: 'topic',
    title: '메모리',
    titleEn: 'Memory',
    hint: 'RAM · 사용량',
    hintEn: 'RAM and usage',
    seed: '메모리 사용을 알려 주세요.',
    seedEn: 'Please tell me about memory use.',
  },
  {
    id: 'install',
    kind: 'topic',
    title: '설치',
    titleEn: 'Install',
    hint: '심기 · USB · 공개 AI',
    hintEn: 'Plant, USB, public AI',
    seed: '이 기기에 os.neu를 어떻게 심나요?',
    seedEn: 'How do I plant os.neu on this machine?',
  },
  {
    id: 'talk',
    kind: 'topic',
    title: '말하기',
    titleEn: 'Talk',
    hint: '마이크 · 한 줄 대화',
    hintEn: 'Mic and one-line talk',
    seed: '말하기 화면으로 가려면 어떻게 하나요?',
    seedEn: 'How do I open the talk screen?',
  },
]

const LEGACY_PROJECT_KEY = 'os.neu.console-projects'
const LEGACY_THREAD_KEY = 'os.neu.console-threads'
const LEGACY_ACTIVE_KEY = 'os.neu.console-active'

function sid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

function browserStore(): Store | null {
  try {
    if (typeof localStorage === 'undefined') return null
    return localStorage
  } catch {
    return null
  }
}

export function talkStorageKey(email?: string | null) {
  const neat = String(email || 'guest').trim().toLowerCase() || 'guest'
  return `os.neu.talk.${neat}`
}

export function defaultTalkPack(): TalkPack {
  return {
    customized: false,
    activeGroupId: 'topics',
    activeTopicId: 'general',
    groups: [
      {
        id: 'topics',
        title: '주제별 대화',
        titleEn: 'By topic',
        builtin: true,
        topics: BUILTIN_TOPICS.map((row) => ({ ...row })),
      },
    ],
    threads: {},
  }
}

export function makeGroup(name: string): TalkGroup {
  const title = name.trim()
  return {
    id: sid('grp'),
    title,
    titleEn: title,
    topics: [],
  }
}

export function makeTopic(name: string): ConsoleTopic {
  const title = name.trim()
  return {
    id: sid('talk'),
    kind: 'project',
    title,
    titleEn: title,
    hint: '내가 만든 대화',
    hintEn: 'A talk I added',
    seed: `${title}부터 이어서 이야기할까요?`,
    seedEn: `Shall we continue with ${title}?`,
  }
}

export function allTopics(pack: TalkPack): ConsoleTopic[] {
  return pack.groups.flatMap((group) => group.topics)
}

export function findTopic(pack: TalkPack, id: string): ConsoleTopic {
  return allTopics(pack).find((row) => row.id === id) || pack.groups[0]?.topics[0] || BUILTIN_TOPICS[0]
}

export function findGroup(pack: TalkPack, id: string): TalkGroup {
  return pack.groups.find((row) => row.id === id) || pack.groups[0]
}

function parsePack(raw: string | null): TalkPack | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as TalkPack
    if (!parsed || !Array.isArray(parsed.groups)) return null
    const groups = parsed.groups
      .filter((row) => row?.id && row.title && Array.isArray(row.topics))
      .map((row) => ({
        id: String(row.id),
        title: String(row.title),
        titleEn: String(row.titleEn || row.title),
        builtin: Boolean(row.builtin),
        topics: row.topics.filter((topic) => topic?.id && topic.title),
      }))
    if (!groups.length) return null
    return {
      customized: Boolean(parsed.customized),
      activeGroupId: String(parsed.activeGroupId || groups[0].id),
      activeTopicId: String(parsed.activeTopicId || groups[0].topics[0]?.id || 'general'),
      groups,
      threads: parsed.threads && typeof parsed.threads === 'object' ? parsed.threads : {},
    }
  } catch {
    return null
  }
}

function migrateLegacy(store: Store): TalkPack | null {
  try {
    const projectsRaw = store.getItem(LEGACY_PROJECT_KEY)
    const threadsRaw = store.getItem(LEGACY_THREAD_KEY)
    const projects = projectsRaw ? (JSON.parse(projectsRaw) as ConsoleTopic[]) : []
    const threads = threadsRaw ? (JSON.parse(threadsRaw) as TalkPack['threads']) : {}
    const list = Array.isArray(projects) ? projects.filter((row) => row?.kind === 'project' && row.id && row.title) : []
    if (!list.length && (!threads || !Object.keys(threads).length)) return null
    const pack = defaultTalkPack()
    if (list.length) {
      pack.groups.push({
        id: 'projects',
        title: '프로젝트',
        titleEn: 'Projects',
        topics: list,
      })
      pack.customized = true
    }
    pack.threads = threads && typeof threads === 'object' ? threads : {}
    pack.activeTopicId = store.getItem(LEGACY_ACTIVE_KEY) || pack.activeTopicId
    return pack
  } catch {
    return null
  }
}

export function loadTalkPack(email?: string | null, store: Store | null = browserStore()): TalkPack {
  const fallback = defaultTalkPack()
  if (!store) return fallback
  const saved = parsePack(store.getItem(talkStorageKey(email)))
  if (saved) return saved
  if (!email) {
    const legacy = migrateLegacy(store)
    if (legacy) {
      store.setItem(talkStorageKey('guest'), JSON.stringify(legacy))
      return legacy
    }
  }
  return fallback
}

export function saveTalkPack(email: string | null | undefined, pack: TalkPack, store: Store | null = browserStore()) {
  if (!store) return pack
  store.setItem(talkStorageKey(email), JSON.stringify(pack))
  return pack
}

export function addGroup(pack: TalkPack, name: string): TalkPack {
  const group = makeGroup(name)
  if (!group.title) return pack
  return {
    ...pack,
    customized: true,
    activeGroupId: group.id,
    groups: [...pack.groups, group],
  }
}

export function addTopicToGroup(pack: TalkPack, groupId: string, name: string): TalkPack {
  const topic = makeTopic(name)
  if (!topic.title) return pack
  return {
    ...pack,
    customized: true,
    activeGroupId: groupId,
    activeTopicId: topic.id,
    groups: pack.groups.map((group) =>
      group.id === groupId ? { ...group, topics: [...group.topics, topic] } : group,
    ),
  }
}

export function greetingFor(topic: ConsoleTopic, ko: boolean): ChatBubble {
  const title = ko ? topic.title : topic.titleEn
  const hint = ko ? topic.hint : topic.hintEn
  return {
    id: `boot-${topic.id}`,
    role: 'neu',
    text: ko
      ? `「${title}」 대화입니다. ${hint}. 한 줄을 말하거나 적어도 됩니다.`
      : `This is the ${title} thread. ${hint}. Speak or type one line.`,
  }
}
