import { describe, expect, it } from 'vitest'
import {
  addGroup,
  addTopicToGroup,
  defaultTalkPack,
  findTopic,
  loadTalkPack,
  saveTalkPack,
  talkStorageKey,
} from './consoleTopics'

function memory() {
  const map = new Map<string, string>()
  return {
    getItem: (key: string) => map.get(key) ?? null,
    setItem: (key: string, value: string) => {
      map.set(key, value)
    },
  }
}

describe('console talk packs', () => {
  it('keys lists by login email', () => {
    expect(talkStorageKey(null)).toBe('os.neu.talk.guest')
    expect(talkStorageKey('Ada@Neu.os')).toBe('os.neu.talk.ada@neu.os')
  })

  it('gives first-time users the default topic screen', () => {
    const pack = loadTalkPack('new@os.neu', memory())
    expect(pack.customized).toBe(false)
    expect(pack.groups[0].title).toBe('주제별 대화')
    expect(pack.groups[0].topics.map((row) => row.id)).toContain('hardware')
  })

  it('keeps a signed-in list apart from the guest default', () => {
    const store = memory()
    const guest = defaultTalkPack()
    const mine = addGroup(defaultTalkPack(), '캠페인')
    saveTalkPack(null, guest, store)
    saveTalkPack('lee@os.neu', mine, store)
    expect(loadTalkPack(null, store).groups).toHaveLength(1)
    expect(loadTalkPack('lee@os.neu', store).groups.map((row) => row.title)).toContain('캠페인')
    expect(loadTalkPack('lee@os.neu', store).customized).toBe(true)
  })

  it('adds a talk under a top-level group', () => {
    const started = addGroup(defaultTalkPack(), '업무')
    const next = addTopicToGroup(started, started.activeGroupId, '주간 보고')
    expect(findTopic(next, next.activeTopicId).title).toBe('주간 보고')
    expect(next.customized).toBe(true)
  })
})
