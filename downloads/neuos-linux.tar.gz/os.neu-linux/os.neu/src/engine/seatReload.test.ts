import { describe, expect, it } from 'vitest'
import { isSeatStale, shouldReloadSeat } from './seatReload'

describe('shouldReloadSeat', () => {
  it('reloads the known provider-missing crash', () => {
    expect(shouldReloadSeat(new Error('NeuProvider missing'))).toBe(true)
    expect(shouldReloadSeat(new Error('AppCatalogProvider missing'))).toBe(true)
  })

  it('leaves other errors alone', () => {
    expect(shouldReloadSeat(new Error('network failed'))).toBe(false)
    expect(shouldReloadSeat('')).toBe(false)
  })
})

describe('isSeatStale', () => {
  it('stays quiet until the first pulse', () => {
    expect(isSeatStale(0, 10_000)).toBe(false)
  })

  it('hides the guest when the chrome pulse stops', () => {
    expect(isSeatStale(1000, 5000, 4000)).toBe(true)
    expect(isSeatStale(1000, 4999, 4000)).toBe(false)
  })
})
