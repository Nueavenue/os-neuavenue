/**
 * Writes into neu-workspace from the apps. Every row picks up the active
 * work id unless the caller passes one (rule 1). Old localStorage records
 * stay where they are and are copied in once.
 */
import { migrateHistory, type DownloadRecord } from './browseLedger'
import { queueActivity, queueWork } from './cloudWorkspace'
import { loadDocProjects } from './docProjects'
import { loadActiveWorkId, loadWorks, type MvpWork } from './mvpWork'
import {
  appendActivity,
  getArtifact,
  getMeta,
  putArtifact,
  putEvidence,
  putWork,
  setMeta,
  type ActivityKind,
  type ArtifactApp,
  type WsActivity,
  type WsApp,
  type WsArtifact,
  type WsWork,
} from './workspaceDb'

const LEGACY_FLAG = 'legacyImported.v1'
const OPEN_ARTIFACT = 'neu-open-artifact'

export function toWsWork(work: MvpWork): WsWork {
  return {
    id: work.id,
    title: work.title,
    prompt: work.prompt,
    audience: work.audience,
    audienceNote: work.audienceNote,
    status: work.savedAt ? 'saved' : 'open',
    projectId: null,
    docId: work.docId,
    createdAt: work.createdAt,
    updatedAt: work.updatedAt,
    savedAt: work.savedAt,
    deletedAt: work.deletedAt,
  }
}

export function docArtifactId(docId: string) {
  return `doc:${docId}`
}

function quiet(task: Promise<unknown>) {
  task.catch(() => {
    /* never block the app on the log */
  })
}

const OFFICE_TAIL = 'Write the draft from this request only.'

/** The user's own request for an AI row, never the instruction composed for the model. */
export function aiRequestTitle(text: string, max = 60): string {
  const raw = String(text || '')
  const ask = raw.match(/(?:^|\s)Ask:\s*(.+?)(?=\s+Search (?:engine|URL|notes)\b|$)/m)
  const words = /^User language:/.test(raw) ? raw.match(/Words:\s*(.+?)(?=\s+Ask:|$)/m) : null
  const body = ask ? ask[1] : words ? words[1].replace(/\s·\s/g, ' ') : raw.split(OFFICE_TAIL)[0]
  const line = body.split('\n').map((row) => row.trim()).find(Boolean) || ''
  const clean = line.replace(/\s+/g, ' ')
  return clean.length > max ? `${clean.slice(0, max - 1).trimEnd()}…` : clean
}

export function logActivity(
  kind: ActivityKind,
  fields: { app?: WsApp | null; title?: string; url?: string; model?: string; chars?: number; refId?: string; workId?: string | null } = {},
) {
  const workId = fields.workId === undefined ? loadActiveWorkId() : fields.workId
  const row: Omit<WsActivity, 'id' | 't'> = {
    workId: workId || null,
    kind,
    app: fields.app ?? null,
    title: (fields.title || '').replace(/\s+/g, ' ').trim().slice(0, 120),
  }
  if (fields.url) row.url = fields.url
  if (fields.model) row.model = fields.model
  if (typeof fields.chars === 'number') row.chars = fields.chars
  if (fields.refId) row.refId = fields.refId
  quiet(appendActivity(row).then(queueActivity))
}

export function mirrorWork(work: MvpWork | null | undefined) {
  if (!work) return
  const row = toWsWork(work)
  quiet(putWork(row).then(() => queueWork(row)))
}

export function recordSource(work: MvpWork, source: { id: string; url: string; title: string; status: string; addedAt: number }) {
  quiet(
    putEvidence({
      id: source.id,
      workId: work.id,
      url: source.url,
      title: source.title,
      status: source.status,
      addedAt: source.addedAt,
    }),
  )
  logActivity('source.add', { app: 'web', title: source.title, url: source.url, workId: work.id })
}

/** Copy the work's document body into artifacts when the work is saved. */
export function snapshotWorkDoc(work: MvpWork) {
  if (!work.docId) return
  const doc = loadDocProjects().find((row) => row.id === work.docId)
  if (!doc) return
  quiet(
    putArtifact({
      id: docArtifactId(doc.id),
      workId: work.id,
      app: 'doc',
      title: doc.title || work.title,
      payload: { docId: doc.id, body: doc.body },
    }),
  )
}

/** Sheets / Slides save button (rule 2). Returns the stored artifact. */
export async function saveArtifact(app: ArtifactApp, title: string, payload: unknown, id?: string | null) {
  const row = await putArtifact({ id: id || undefined, workId: loadActiveWorkId(), app, title, payload })
  logActivity(`${app}.save` as ActivityKind, { app, title: row.title, refId: row.id, workId: row.workId })
  return row
}

export function linkActivity(activityId: string, workId: string) {
  logActivity('work.link', { refId: activityId, workId })
}

// ---- reopen a saved sheet / slides ----

let pendingOpen: { id: string; app: ArtifactApp } | null = null

export function requestOpenArtifact(id: string, app: ArtifactApp) {
  pendingOpen = { id, app }
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(OPEN_ARTIFACT, { detail: pendingOpen }))
}

/** Calls back with the artifact the user asked to open in this app (also one queued before mount). */
export function onOpenArtifact(app: ArtifactApp, handler: (row: WsArtifact) => void) {
  const take = (req: { id: string; app: ArtifactApp } | null) => {
    if (!req || req.app !== app) return
    pendingOpen = null
    void getArtifact(req.id).then((row) => {
      if (row) handler(row)
    })
  }
  take(pendingOpen)
  if (typeof window === 'undefined') return () => {}
  const listener = (ev: Event) => take((ev as CustomEvent<{ id: string; app: ArtifactApp }>).detail)
  window.addEventListener(OPEN_ARTIFACT, listener)
  return () => window.removeEventListener(OPEN_ARTIFACT, listener)
}

// ---- one-time copy of old records ----

function legacyBrowseKeys(): string[] {
  const keys: string[] = []
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i)
    if (key && key.startsWith('os.neu.browse.')) keys.push(key)
  }
  return keys
}

async function addOnce(row: Omit<WsActivity, 'id' | 't'> & { id: string; t: number }) {
  try {
    await appendActivity(row)
  } catch {
    /* already imported */
  }
}

export async function importLegacy(): Promise<boolean> {
  if (typeof localStorage === 'undefined') return false
  if (await getMeta<boolean>(LEGACY_FLAG)) return false
  const works = loadWorks()
  for (const work of works) {
    await putWork(toWsWork(work))
    for (const src of work.sources) {
      await putEvidence({ id: src.id, workId: work.id, url: src.url, title: src.title, status: src.status, addedAt: src.addedAt })
    }
    await addOnce({ id: `legacy-start-${work.id}`, workId: work.id, kind: 'work.start', app: null, title: work.prompt.slice(0, 120), t: work.createdAt })
    if (work.savedAt) {
      await addOnce({ id: `legacy-save-${work.id}`, workId: work.id, kind: 'work.save', app: 'doc', title: work.title, t: work.savedAt })
    }
  }
  const docOwner = new Map(works.filter((w) => w.docId).map((w) => [w.docId as string, w.id]))
  for (const doc of loadDocProjects()) {
    if (doc.kind !== 'doc' || !doc.body.trim()) continue
    await putArtifact({
      id: docArtifactId(doc.id),
      workId: docOwner.get(doc.id) || null,
      app: 'doc',
      title: doc.title,
      payload: { docId: doc.id, body: doc.body },
    })
  }
  for (const key of legacyBrowseKeys()) {
    try {
      const parsed = JSON.parse(localStorage.getItem(key) || '{}') as { visits?: unknown; downloads?: DownloadRecord[] }
      for (const visit of migrateHistory(parsed.visits)) {
        await addOnce({ id: `legacy-visit-${visit.id}`, workId: null, kind: 'web.visit', app: 'web', title: visit.title, url: visit.url, t: visit.t })
      }
      for (const dl of Array.isArray(parsed.downloads) ? parsed.downloads : []) {
        if (dl.state !== 'done') continue
        await addOnce({ id: `legacy-dl-${dl.id}`, workId: null, kind: 'web.download', app: 'web', title: dl.filename, url: dl.url, t: dl.t })
      }
    } catch {
      /* skip unreadable ledger */
    }
  }
  await setMeta(LEGACY_FLAG, true)
  return true
}
