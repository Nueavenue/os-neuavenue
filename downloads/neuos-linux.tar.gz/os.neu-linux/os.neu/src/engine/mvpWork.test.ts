import { beforeEach, describe, expect, it, vi } from 'vitest'
import { firstDoc, isDocStored, loadDocProjects, upsertDocProject } from './docProjects'
import {
  cleanPrompt,
  confirmWorkSaved,
  createWork,
  enrichPrompt,
  exportOutcome,
  formatSavedAt,
  formatWorkTime,
  isMvpReportPrompt,
  loadActiveWorkId,
  loadWorks,
  needsPurposeConfirm,
  setActiveWorkId,
  titleFromPrompt,
  upsertWork,
} from './mvpWork'
import { readSavedLocale, saveLocale } from '../i18n/detect'

// vitest runs in 'node' here — minimal in-memory storage, same as bookmarks.test.ts.
if (typeof globalThis.localStorage === 'undefined') {
  const backing = new Map<string, string>()
  globalThis.localStorage = {
    getItem: (key: string) => (backing.has(key) ? backing.get(key)! : null),
    setItem: (key: string, value: string) => void backing.set(key, String(value)),
    removeItem: (key: string) => void backing.delete(key),
    clear: () => void backing.clear(),
    key: (index: number) => Array.from(backing.keys())[index] ?? null,
    get length() {
      return backing.size
    },
  } as Storage
}

beforeEach(() => {
  localStorage.clear()
  vi.restoreAllMocks()
})

describe('mvpWork', () => {
  it('detects the first MVP report prompt', () => {
    expect(isMvpReportPrompt('A·B·C 서비스를 비교해서 선택 기준과 추천 이유를 담은 보고서를 만들어 줘.')).toBe(true)
    expect(isMvpReportPrompt('인터넷 열어줘')).toBe(false)
  })

  it('asks purpose only when audience is missing', () => {
    expect(needsPurposeConfirm('고객관리 서비스 세 곳을 비교해서 보고서를 만들어 줘')).toBe(true)
    expect(needsPurposeConfirm('우리 팀 내부 검토용으로 CRM 세 곳을 비교해 줘')).toBe(false)
    expect(needsPurposeConfirm('짧은 한 줄', 'doc')).toBe(true)
    expect(needsPurposeConfirm('우리 팀 내부 검토용 짧은 한 줄', 'doc')).toBe(false)
    expect(needsPurposeConfirm('인터넷 열어줘')).toBe(false)
  })

  it('builds a title and enriched instruction', () => {
    expect(titleFromPrompt('고객관리 서비스 비교 보고서 만들어 줘')).toMatch(/고객관리/)
    const work = createWork({ prompt: '비교 보고서', audience: 'team' })
    expect(enrichPrompt(work)).toMatch(/Audience: internal team review/)
    expect(enrichPrompt(work)).toMatch(/comparison table/)
  })
})

describe('trash', () => {
  it('keeps a trashed work in storage and can clear the marker', () => {
    const work = createWork({ prompt: '비교 보고서', docId: 'd1' })
    expect(work.deletedAt).toBeNull()
    upsertWork(loadWorks(), { ...work, deletedAt: 1234 })
    const stored = loadWorks().find((row) => row.id === work.id)
    expect(stored?.deletedAt).toBe(1234)
    expect(stored?.prompt).toBe('비교 보고서')
    upsertWork(loadWorks(), { ...stored!, deletedAt: null })
    expect(loadWorks().find((row) => row.id === work.id)?.deletedAt).toBeNull()
  })
})

describe('empty prompt', () => {
  it('blocks empty and whitespace-only prompts', () => {
    for (const text of ['', '   ', '\n\t  \n', null, undefined]) {
      expect(cleanPrompt(text)).toBeNull()
    }
    expect(cleanPrompt('  보고서 만들어 줘 \n')).toBe('보고서 만들어 줘')
  })

  it('never routes an empty prompt into the work path', () => {
    expect(isMvpReportPrompt('   ')).toBe(false)
    expect(needsPurposeConfirm('')).toBe(false)
    expect(titleFromPrompt('  ')).toBe('새 작업')
  })
})

describe('verified save', () => {
  it('confirms only the exact savedAt that reached storage', () => {
    const work = createWork({ prompt: '비교 보고서' })
    upsertWork(loadWorks(), { ...work, savedAt: 1234 })
    expect(confirmWorkSaved(work.id, 1234)).toBe(true)
    expect(confirmWorkSaved(work.id, 9999)).toBe(false)
    expect(confirmWorkSaved('w-missing', 1234)).toBe(false)
  })

  it('does not confirm when storage refuses the write', () => {
    const work = createWork({ prompt: '비교 보고서' })
    upsertWork(loadWorks(), work)
    vi.spyOn(localStorage, 'setItem').mockImplementation(() => {
      throw new Error('QuotaExceededError')
    })
    upsertWork(loadWorks(), { ...work, savedAt: 5555 })
    expect(confirmWorkSaved(work.id, 5555)).toBe(false)
  })

  it('confirms the document version that was written', () => {
    const doc = firstDoc(loadDocProjects())
    upsertDocProject(loadDocProjects(), { ...doc, updated: 4242 })
    expect(isDocStored(doc.id, 4242)).toBe(true)
    expect(isDocStored(doc.id, 4243)).toBe(false)
  })

  it('maps export results without claiming unconfirmed saves', () => {
    expect(exportOutcome({ ok: true, path: '/home/u/r.docx' })).toBe('saved')
    expect(exportOutcome({ ok: true, via: 'download' })).toBe('download')
    expect(exportOutcome({ ok: true })).toBe('unverified')
    expect(exportOutcome({ ok: false, reason: 'cancelled' })).toBe('cancelled')
    expect(exportOutcome({ ok: false, reason: 'EACCES' })).toBe('failed')
    expect(exportOutcome(undefined)).toBe('failed')
  })
})

describe('language switch', () => {
  it('keeps the active task and its record unchanged', () => {
    const work = createWork({ prompt: 'CRM 세 곳 비교 보고서', audience: 'team', docId: 'd-1' })
    upsertWork(loadWorks(), { ...work, savedAt: 7777 })
    setActiveWorkId(work.id)
    saveLocale('ko')
    const before = JSON.stringify(loadWorks())

    for (const locale of ['en', 'ja', 'ar', 'ko'] as const) {
      saveLocale(locale)
      expect(readSavedLocale()).toBe(locale)
      expect(JSON.stringify(loadWorks())).toBe(before)
      expect(loadActiveWorkId()).toBe(work.id)
    }
  })

  it('shows the same saved state in either language', () => {
    expect(formatSavedAt(null, true)).toBe('저장 안 됨')
    expect(formatSavedAt(null, false)).toBe('Not saved')
    const at = new Date(2026, 10, 3, 9, 5).getTime()
    expect(formatSavedAt(at, true)).toBe('저장됨 09:05')
    expect(formatSavedAt(at, false)).toBe('Saved 09:05')
  })

  it('does not say Saved for a work the user never saved', () => {
    const changed = new Date(2026, 10, 3, 10, 12).getTime()
    const saved = new Date(2026, 10, 3, 9, 5).getTime()
    expect(formatWorkTime({ savedAt: null, updatedAt: changed }, false)).toBe('Changed 10:12')
    expect(formatWorkTime({ savedAt: null, updatedAt: changed }, true)).toBe('변경 10:12')
    expect(formatWorkTime({ savedAt: saved, updatedAt: changed }, false)).toBe('Saved 09:05')
  })
})
