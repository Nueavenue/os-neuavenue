import type { Intent, Pipeline, PipelineStep } from '../types'

function sid(prefix: string, index: number) {
  return `${prefix}-${index}`
}

function queued(
  id: string,
  title: string,
  detail: string,
  layer: PipelineStep['layer'],
): PipelineStep {
  return { id, title, detail, layer, status: 'queued' }
}

export function planIntent(intent: Intent): Pipeline {
  const now = Date.now()
  if (intent.kind === 'sheet-report') {
    return {
      id: `pipe-${now}`,
      goal: intent.raw,
      createdAt: now,
      steps: [
        queued(sid('s', 1), 'Isolate the sheet app', 'Keep the host OS hidden. Open the sandbox only.', 'driver'),
        queued(sid('s', 2), 'Read the title field', 'Find the input from screen pixels.', 'vlm'),
        queued(sid('s', 3), 'Type the report title', 'Put characters through the virtual keyboard.', 'driver'),
        queued(sid('s', 4), 'Find the body cell', 'Lock the first input cell in the grid.', 'vlm'),
        queued(sid('s', 5), 'Fill numbers and items', 'Type planned values in order.', 'driver'),
        queued(sid('s', 6), 'Find the save button', 'Pull X, Y for the save control.', 'vlm'),
        queued(sid('s', 7), 'Click save', 'Leave the file with a coordinate click.', 'driver'),
      ],
    }
  }

  if (intent.kind === 'doc') {
    return {
      id: `pipe-${now}`,
      goal: intent.raw,
      createdAt: now,
      steps: [
        queued(sid('d', 1), 'Isolate the document app', 'Open the document with no desktop around it.', 'driver'),
        queued(sid('d', 2), 'Find the body field', 'Confirm the cursor from pixels.', 'vlm'),
        queued(sid('d', 3), 'Type the sentences', 'The virtual keyboard writes the text.', 'driver'),
        queued(sid('d', 4), 'Confirm save location', 'Read save-button coordinates.', 'vlm'),
        queued(sid('d', 5), 'Save to storage', 'Click to keep the file.', 'driver'),
      ],
    }
  }

  return {
    id: `pipe-${now}`,
    goal: intent.raw,
    createdAt: now,
    steps: [
      queued(sid('w', 1), 'Open browser home', 'Start from a phone-like home page.', 'driver'),
      queued(sid('w', 2), 'Find the address bar', 'Read the input from the screen.', 'vlm'),
      queued(sid('w', 3), 'Attach the landing page', 'If there is no connection, keep the local home.', 'driver'),
    ],
  }
}

export function withStep(
  pipeline: Pipeline,
  id: string,
  patch: Partial<PipelineStep>,
): Pipeline {
  return {
    ...pipeline,
    steps: pipeline.steps.map((step) => (step.id === id ? { ...step, ...patch } : step)),
  }
}
