import { describe, expect, it } from 'vitest'
import {
  applyRegionPatchToHtml,
  ensureRegionIdsInHtml,
  listRegionsFromHtml,
  REGION_EDIT_GUIDE_KO,
} from './htmlDeckRegionEdit'

const FIXTURE = `<!DOCTYPE html><html><body>
<div class="slide-container" style="width:1920px;height:1080px;">
  <div id="title-box" data-object="true" data-object-type="textbox" style="position:absolute;left:96px;top:100px;width:800px;">
    <p style="font-size:48px;color:#14181D;font-weight:800;">Hello Title</p>
  </div>
  <div data-object="true" data-object-type="shape" style="position:absolute;left:0;top:0;width:12px;height:1080px;background:#BC4F2B;"></div>
  <div id="body-box" data-object="true" data-object-type="textbox" style="position:absolute;left:96px;top:200px;width:800px;">
    <p style="font-size:24px;color:#4A4D52;">Body line</p>
  </div>
</div>
</body></html>`

describe('htmlDeckRegionEdit', () => {
  it('assigns data-edit-id and lists textbox regions', () => {
    const tagged = ensureRegionIdsInHtml(FIXTURE)
    expect(tagged).toMatch(/data-edit-id="r1"/)
    const regions = listRegionsFromHtml(FIXTURE)
    expect(regions.length).toBeGreaterThanOrEqual(2)
    expect(regions.some((r) => r.kind === 'textbox' && r.text.includes('Hello'))).toBe(true)
  })

  it('patches only one region text', () => {
    const regions = listRegionsFromHtml(FIXTURE)
    const title = regions.find((r) => r.text.includes('Hello'))
    expect(title).toBeTruthy()
    const next = applyRegionPatchToHtml(FIXTURE, {
      id: title!.id,
      text: 'New Title',
      fontSize: '52px',
      color: '#BC4F2B',
    })
    expect(next).toContain('New Title')
    expect(next).toContain('Body line')
    expect(next).not.toContain('Hello Title')
  })

  it('exposes Korean guide', () => {
    expect(REGION_EDIT_GUIDE_KO).toMatch(/Edit 모드/)
  })
})
