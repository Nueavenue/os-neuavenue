/**
 * neu workspace cloud sync (Supabase schema `neuws`). Local IndexedDB stays the working copy;
 * changes wait in an outbox and upload when signed in and online. Off unless VITE_NEUWS_URL and
 * VITE_NEUWS_ANON_KEY are set (publishable/anon key only — never a service key).
 * Design: docs/architecture/NEU-WORKSPACE-UNIFIED-SUPABASE-DESIGN-V1-2026-11-04.md
 */
import { readToken } from './auth'
import type { WsActivity, WsWork } from './workspaceDb'

const OUTBOX_KEY = 'os.neu.cloud.outbox'
const SPACE_KEY = 'os.neu.cloud.space'
const SYNCED_KEY = 'os.neu.cloud.syncedAt'
const FLUSH_DELAY_MS = 3000

export type CloudConfig = { url: string; anon: string }
export type CloudTable = 'works' | 'activity'
export type OutboxItem = { table: CloudTable; id: string; row: Record<string, unknown> }
export type FlushResult = { sent: number; left: number; reason?: 'off' | 'signed-out' | 'offline' | 'failed' }
export type CloudKeyStatus = { vendor: string; scope: 'user' | 'org'; orgId: string | null; setAt: string }

type Fetcher = typeof fetch
type Env = Record<string, string | boolean | undefined>

export function cloudConfig(env: Env = import.meta.env as Env): CloudConfig | null {
  const url = String(env.VITE_NEUWS_URL || '')
    .trim()
    .replace(/\/$/, '')
  const anon = String(env.VITE_NEUWS_ANON_KEY || '').trim()
  if (!/^https?:\/\//.test(url) || !anon) return null
  return { url, anon }
}

function iso(ms: number | null | undefined) {
  return typeof ms === 'number' && Number.isFinite(ms) ? new Date(ms).toISOString() : null
}

export function workRow(work: WsWork): Record<string, unknown> {
  return {
    id: work.id,
    project_id: work.projectId,
    title: work.title,
    prompt: work.prompt,
    audience: work.audience,
    audience_note: work.audienceNote,
    status: work.status === 'saved' ? 'saved' : 'open',
    doc_id: work.docId,
    created_at: iso(work.createdAt),
    updated_at: iso(work.updatedAt),
    saved_at: iso(work.savedAt),
    deleted_at: iso(work.deletedAt),
  }
}

/** ai.call rows go up with model and character count only — no title, so no request text. */
export function activityRow(row: WsActivity): Record<string, unknown> {
  return {
    id: row.id,
    work_id: row.workId,
    kind: row.kind,
    app: row.app,
    title: row.kind === 'ai.call' ? null : row.title.slice(0, 200),
    url: row.url ?? null,
    model: row.model ?? null,
    chars: typeof row.chars === 'number' ? row.chars : null,
    ref_id: row.refId ?? null,
    t: iso(row.t),
  }
}

function storage(): Storage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage
  } catch {
    return null
  }
}

export function loadOutbox(): OutboxItem[] {
  const raw = storage()?.getItem(OUTBOX_KEY)
  if (!raw) return []
  try {
    const rows = JSON.parse(raw) as unknown
    return Array.isArray(rows) ? (rows.filter((r) => r && typeof r === 'object' && 'table' in r && 'id' in r) as OutboxItem[]) : []
  } catch {
    return []
  }
}

function saveOutbox(rows: OutboxItem[]) {
  storage()?.setItem(OUTBOX_KEY, JSON.stringify(rows))
}

/** Same table + id keeps only the newest row. */
export function enqueueCloud(item: OutboxItem) {
  const rows = loadOutbox().filter((r) => !(r.table === item.table && r.id === item.id))
  rows.push(item)
  saveOutbox(rows)
}

export function cloudPendingCount() {
  return loadOutbox().length
}

export function cloudSyncedAt(): number | null {
  const n = Number(storage()?.getItem(SYNCED_KEY) || '')
  return Number.isFinite(n) && n > 0 ? n : null
}

function userToken() {
  const token = readToken()
  return token.split('.').length === 3 ? token : ''
}

function headers(cfg: CloudConfig, token: string, extra: Record<string, string> = {}) {
  return {
    apikey: cfg.anon,
    authorization: `Bearer ${token}`,
    'content-type': 'application/json',
    'accept-profile': 'neuws',
    'content-profile': 'neuws',
    ...extra,
  }
}

async function rpc<T>(cfg: CloudConfig, token: string, name: string, body: Record<string, unknown>, fetcher: Fetcher): Promise<T | null> {
  const res = await fetcher(`${cfg.url}/rest/v1/rpc/${name}`, { method: 'POST', headers: headers(cfg, token), body: JSON.stringify(body) })
  if (!res.ok) return null
  const text = await res.text()
  return text ? (JSON.parse(text) as T) : null
}

async function personalSpace(cfg: CloudConfig, token: string, fetcher: Fetcher): Promise<string | null> {
  const cached = storage()?.getItem(SPACE_KEY)
  if (cached) return cached
  const id = await rpc<string>(cfg, token, 'ensure_personal_space', {}, fetcher)
  if (typeof id === 'string' && id) storage()?.setItem(SPACE_KEY, id)
  return typeof id === 'string' && id ? id : null
}

export async function flushCloudOutbox(fetcher: Fetcher = fetch, cfg = cloudConfig()): Promise<FlushResult> {
  const pending = loadOutbox()
  if (!cfg) return { sent: 0, left: pending.length, reason: 'off' }
  const token = userToken()
  if (!token) return { sent: 0, left: pending.length, reason: 'signed-out' }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { sent: 0, left: pending.length, reason: 'offline' }
  if (!pending.length) return { sent: 0, left: 0 }
  try {
    const orgId = await personalSpace(cfg, token, fetcher)
    if (!orgId) return { sent: 0, left: pending.length, reason: 'failed' }
    const sent = new Map<string, string>()
    for (const table of ['works', 'activity'] as CloudTable[]) {
      const batch = pending.filter((r) => r.table === table)
      if (!batch.length) continue
      const res = await fetcher(`${cfg.url}/rest/v1/${table}?on_conflict=org_id,id`, {
        method: 'POST',
        headers: headers(cfg, token, {
          prefer: `resolution=${table === 'activity' ? 'ignore' : 'merge'}-duplicates,return=minimal`,
        }),
        body: JSON.stringify(batch.map((r) => ({ ...r.row, org_id: orgId }))),
      })
      if (res.ok) batch.forEach((r) => sent.set(`${r.table}:${r.id}`, JSON.stringify(r.row)))
    }
    // A row changed again while uploading stays in the outbox.
    const left = loadOutbox().filter((r) => sent.get(`${r.table}:${r.id}`) !== JSON.stringify(r.row))
    saveOutbox(left)
    if (sent.size) storage()?.setItem(SYNCED_KEY, String(Date.now()))
    return { sent: sent.size, left: left.length, reason: sent.size < pending.length ? 'failed' : undefined }
  } catch {
    return { sent: 0, left: loadOutbox().length, reason: 'failed' }
  }
}

let flushTimer: ReturnType<typeof setTimeout> | null = null

export function scheduleCloudFlush() {
  if (!cloudConfig() || flushTimer) return
  flushTimer = setTimeout(() => {
    flushTimer = null
    void flushCloudOutbox()
  }, FLUSH_DELAY_MS)
}

export function queueWork(work: WsWork) {
  if (!cloudConfig()) return
  enqueueCloud({ table: 'works', id: work.id, row: workRow(work) })
  scheduleCloudFlush()
}

export function queueActivity(row: WsActivity) {
  if (!cloudConfig()) return
  enqueueCloud({ table: 'activity', id: row.id, row: activityRow(row) })
  scheduleCloudFlush()
}

export async function cloudAiKeyStatus(fetcher: Fetcher = fetch, cfg = cloudConfig()): Promise<CloudKeyStatus[] | null> {
  const token = userToken()
  if (!cfg || !token) return null
  try {
    const rows = await rpc<Array<{ vendor: string; scope: 'user' | 'org'; org_id: string | null; set_at: string }>>(cfg, token, 'ai_key_status', {}, fetcher)
    return Array.isArray(rows) ? rows.map((r) => ({ vendor: r.vendor, scope: r.scope, orgId: r.org_id, setAt: r.set_at })) : null
  } catch {
    return null
  }
}

/** Sends the key to the user's cloud vault. The key is not kept on this device by this call. */
export async function saveAiKeyToCloud(vendor: string, key: string, fetcher: Fetcher = fetch, cfg = cloudConfig()): Promise<boolean> {
  const token = userToken()
  if (!cfg || !token || !key.trim()) return false
  try {
    const at = await rpc<string>(cfg, token, 'set_ai_key', { p_vendor: vendor, p_key: key.trim() }, fetcher)
    return typeof at === 'string' && at.length > 0
  } catch {
    return false
  }
}

function hhmm(ms: number) {
  const d = new Date(ms)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export function cloudSyncLine(ko: boolean, state = { on: Boolean(cloudConfig()), signedIn: Boolean(userToken()), pending: cloudPendingCount(), syncedAt: cloudSyncedAt() }) {
  if (!state.on) return ko ? '이 기기에만 저장' : 'Saved on this device only'
  if (!state.signedIn) return ko ? '로그인하면 클라우드에 동기화' : 'Sign in to sync to the cloud'
  if (state.pending > 0) return ko ? `동기화 안 됨 (${state.pending})` : `Not synced (${state.pending})`
  if (state.syncedAt) return ko ? `동기화됨 ${hhmm(state.syncedAt)}` : `Synced ${hhmm(state.syncedAt)}`
  return ko ? '클라우드 동기화 켜짐' : 'Cloud sync on'
}
