import { afterEach, describe, expect, it } from 'vitest'
import { peekPromptSlides, stagePromptSlides, takePromptSlides } from './slidesPrompt'

describe('slidesPrompt carry', () => {
  afterEach(() => {
    stagePromptSlides('')
  })

  it('stores the prompt verbatim and take() clears it', () => {
    const line = '슬라이드 만들어줘. AI-driven analytics platform'
    expect(stagePromptSlides(line)).toBe(line)
    expect(peekPromptSlides()).toBe(line)
    expect(takePromptSlides()).toBe(line)
    expect(peekPromptSlides()).toBe('')
  })
})
