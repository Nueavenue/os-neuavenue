import { describe, expect, it } from 'vitest'
import { craftWebFileRel, craftWebHref, craftWebRoot, joinCraftWebFile, planCraftWeb } from './craftWeb'

describe('craftWeb optional static root', () => {
  it('missing dir → not present', () => {
    expect(craftWebRoot({})).toBeNull()
    expect(planCraftWeb({}, 4178, false)).toEqual({ present: false, root: null })
    expect(planCraftWeb({ OSNEU_CRAFT_WEB_DIR: '/opt/craft-web' }, 4178, false).present).toBe(false)
  })

  it('present only with index and 127.0.0.1 href', () => {
    const planned = planCraftWeb({ OSNEU_CRAFT_WEB_DIR: '/opt/craft-web' }, 4178, true)
    expect(planned.present).toBe(true)
    expect(planned.href).toBe('http://127.0.0.1:4178/craft-web/')
    expect(craftWebHref(4178)).toBe('http://127.0.0.1:4178/craft-web/')
    expect(String(craftWebHref(4178))).not.toContain('localhost')
    expect(String(craftWebHref(4178))).not.toMatch(/https?:\/\/(?!127\.0\.0\.1)/)
  })

  it('rejects path escape under /craft-web/', () => {
    expect(craftWebFileRel('/craft-web/../etc/passwd')).toBeNull()
    expect(craftWebFileRel('/craft-web/%2e%2e/etc/passwd')).toBeNull()
    expect(craftWebFileRel('/craft-web/foo/../../etc/passwd')).toBeNull()
    expect(craftWebFileRel('/craft-web')).toBe('index.html')
    expect(craftWebFileRel('/craft-web/app.wasm')).toBe('app.wasm')
    expect(joinCraftWebFile('/opt/craft-web', '../etc/passwd')).toBeNull()
    expect(joinCraftWebFile('/opt/craft-web', 'index.html')).toBe('/opt/craft-web/index.html')
  })

  it('rejects a relative or dotted OSNEU_CRAFT_WEB_DIR', () => {
    expect(craftWebRoot({ OSNEU_CRAFT_WEB_DIR: 'craft-web' })).toBeNull()
    expect(craftWebRoot({ OSNEU_CRAFT_WEB_DIR: '/opt/craft-web/../evil' })).toBeNull()
  })
})
