import { askFirstSend, gateAiRequest, limitedReasonFromBridge, recordUsage } from './aiPrefs'
import { readyUiSessionHeaders } from './uiSession'
import { isCloudModel } from './cloudModels'
import { aiRequestTitle, logActivity } from './workspaceLog'

/**
 * How long a run may wait for its first text before it stops.
 * The bridge sends a cloud answer in one piece when it is complete, and a local model
 * must load on the CPU first, so neither can promise text within 20 seconds.
 */
export function firstTextWaitMs(model: string): number {
  if (isCloudModel(model)) return 120_000
  const name = String(model || '')
  if (name === 'os.neu-local' || name.includes('1b')) return 90_000
  return 180_000
}

export function firstTextWaitSec(model: string): number {
  return Math.round(firstTextWaitMs(model) / 1000)
}

export async function streamSeatWrite(
  model: string,
  instruction: string,
  onFull: (full: string) => void,
  signal: AbortSignal,
  opts?: { app?: 'doc' | 'sheet' | 'slides' | null; title?: string },
): Promise<{ ok: boolean; text: string; reason?: string }> {
  const gate = gateAiRequest({ model }, (vendor) => askFirstSend(vendor, '요청 문장', 'your request'))
  if (!gate.ok) return { ok: false, text: '', reason: gate.reason }
  const result = await postSeatWrite(model, instruction, onFull, signal, opts)
  recordUsage(instruction.length + result.text.length, true)
  logActivity('ai.call', {
    app: opts?.app || 'doc',
    model,
    title: aiRequestTitle(opts?.title || instruction),
    chars: instruction.length + result.text.length,
  })
  return result
}

async function postSeatWrite(
  model: string,
  instruction: string,
  onFull: (full: string) => void,
  signal: AbortSignal,
  opts?: { app?: 'doc' | 'sheet' | 'slides' | null },
): Promise<{ ok: boolean; text: string; reason?: string }> {
  let res: Response
  try {
    res = await fetch('/api/seat/write', {
      method: 'POST',
      headers: await readyUiSessionHeaders(),
      body: JSON.stringify({ model, instruction, app: opts?.app || undefined }),
      signal,
    })
  } catch (err) {
    const reason = err instanceof Error && err.name === 'AbortError' ? 'aborted' : err instanceof Error && err.name === 'TimeoutError' ? 'timeout' : 'network'
    return { ok: false, text: '', reason }
  }
  if (!res.ok) {
    const fail = (await res.json().catch(() => ({}))) as { reason?: string; limit?: number }
    return { ok: false, text: '', reason: limitedReasonFromBridge(fail) || fail.reason || `http-${res.status}` }
  }
  if (!res.body) return { ok: false, text: '', reason: 'no-body' }
  const reader = res.body.getReader()
  const onAbort = () => {
    void reader.cancel().catch(() => undefined)
  }
  if (signal.aborted) onAbort()
  signal.addEventListener('abort', onAbort)
  const decoder = new TextDecoder()
  let buf = ''
  let full = ''
  let reason = ''
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      buf += decoder.decode(value, { stream: true })
      const lines = buf.split('\n')
      buf = lines.pop() || ''
      for (const line of lines) {
        const raw = line.trim()
        if (!raw) continue
        try {
          const row = JSON.parse(raw) as { ok?: boolean; full?: string; reason?: string; done?: boolean }
          if (row.full) {
            full = row.full
            onFull(full)
          }
          if (row.ok === false) reason = row.reason || 'seat-write-error'
        } catch {
          /* skip a partial line */
        }
      }
    }
  } catch (err) {
    const aborted = err instanceof Error && (err.name === 'AbortError' || signal.aborted)
    if (aborted) return { ok: false, text: full, reason: 'aborted' }
    return { ok: false, text: full, reason: 'network' }
  } finally {
    signal.removeEventListener('abort', onAbort)
  }
  if (reason && !full.trim()) return { ok: false, text: full, reason }
  return { ok: Boolean(full.trim()), text: full, reason: reason || undefined }
}

export function seatErrorKo(reason: string, ko = true, waitSec = 20) {
  if (!ko) return seatErrorEn(reason, waitSec)
  if (reason.startsWith('model-not-installed')) return '고른 모델이 이 PC에 없습니다. 다른 모델로 바꾸지 않았습니다.'
  if (reason === 'local-unavailable') return '로컬 모델 서버가 응답하지 않습니다.'
  if (reason === 'no-llm') return '쓸 수 있는 모델이 없습니다. 로컬 모델 또는 본인 키가 필요합니다.'
  if (reason === 'timeout') return '모델이 시간 안에 끝내지 못했습니다.'
  if (reason === 'first-token-timeout')
    return `첫 글자가 ${waitSec}초 안에 오지 않아 멈췄습니다. AI 연결에서 키와 모델이 켜져 있는지 확인하고 다시 시도하세요.`
  if (reason === 'openai-timeout' || reason === 'anthropic-timeout' || reason === 'google-timeout')
    return '클라우드 AI가 시간 안에 답하지 않았습니다. 인터넷·방화벽·API 키를 Connect AI에서 확인하세요.'
  if (reason === 'openai-401' || reason === 'openai-403')
    return 'OpenAI 키가 거절되었습니다. Connect AI에서 키를 다시 저장하세요.'
  if (reason === 'openai-429')
    return 'OpenAI 사용량·요금 한도(429)에 걸렸습니다. 잠시 기다리거나 Connect AI에서 os.neu-local로 바꾼 뒤 다시 시도하세요.'
  if (reason === 'network') return '브리지(4178)에 연결하지 못했습니다.'
  if (reason === 'aborted') return '이전 문장 실행을 멈췄습니다.'
  return reason || '모델 실행에 실패했습니다.'
}

function seatErrorEn(reason: string, waitSec: number) {
  if (reason.startsWith('model-not-installed')) return 'The chosen model is not on this PC. Nothing was switched for you.'
  if (reason === 'local-unavailable') return 'The local model server is not answering.'
  if (reason === 'no-llm') return 'No model is ready. Turn on a local model or add your own key in Connect AI.'
  if (reason === 'timeout') return 'The model did not finish in time.'
  if (reason === 'first-token-timeout')
    return `No text arrived within ${waitSec} seconds, so this run stopped. Check in Connect AI that your key and model are on, then try again.`
  if (reason === 'openai-timeout' || reason === 'anthropic-timeout' || reason === 'google-timeout')
    return 'The cloud AI did not answer in time. Check internet, firewall, and your API key in Connect AI.'
  if (reason === 'openai-401' || reason === 'openai-403')
    return 'OpenAI rejected the key. Save the key again in Connect AI.'
  if (reason === 'openai-429')
    return 'OpenAI rate limit (429). Wait a bit, or switch to os.neu-local in Connect AI and try again.'
  if (reason === 'network') return 'Could not reach the bridge (port 4178).'
  if (reason === 'aborted') return 'The previous run was stopped.'
  return reason || 'The model run failed.'
}
