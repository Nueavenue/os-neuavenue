import { describe, expect, it } from 'vitest'
import { classifyIntent } from './intents'

describe('intents', () => {
  it('routes app install away from web', () => {
    expect(classifyIntent('크롬 설치해줘').kind).toBe('app-install')
    expect(classifyIntent('인터넷 열어줘').kind).toBe('web')
  })

  it('opens slides for powerpoint wording', () => {
    expect(classifyIntent('파워포인트 만들어줘').kind).toBe('slides')
  })

  it('does not steal a mixed internet+install request', () => {
    expect(classifyIntent('인터넷이 되는지 확인하고 브라우저를 띄워 node.js 설치를 부탁해').kind).toBe('web')
  })
})
