import { describe, expect, it } from 'vitest'
import { classifyIntent, extractSearchQuery } from './intents'

describe('intents', () => {
  it('routes app install away from web', () => {
    expect(classifyIntent('크롬 설치해줘').kind).toBe('app-install')
    expect(classifyIntent('인터넷 열어줘').kind).toBe('web')
  })

  it('opens slides for powerpoint wording', () => {
    expect(classifyIntent('파워포인트 만들어줘').kind).toBe('slides')
  })

  it('honors Docs/Sheets/Slides tags on any language', () => {
    expect(classifyIntent('[Docs] 국내에서 사과 종류가 몇 개나 있어요?').kind).toBe('doc')
    expect(classifyIntent('[Sheets] apple types in Korea').kind).toBe('sheet-report')
    expect(classifyIntent('[Slides:NEU Investor Deck] apple types').kind).toBe('slides')
  })

  it('does not steal a mixed internet+install request', () => {
    expect(classifyIntent('인터넷이 되는지 확인하고 브라우저를 띄워 node.js 설치를 부탁해').kind).toBe('web')
  })

  it('turns an investigate request into a web search with a query', () => {
    const en = classifyIntent('search tesla stock price')
    expect(en.kind).toBe('web')
    expect(en.query).toContain('tesla')
  })

  it('treats write lines as documents, excel as a sheet, research as talk', () => {
    expect(classifyIntent('구글 작년 사업 계획서 작성해줘').kind).toBe('doc')
    expect(classifyIntent('조사해줘').kind).toBe('talk')
    expect(classifyIntent('강릉 날씨 조사해줘').kind).toBe('talk')
    expect(
      classifyIntent('os.neu가 AI-power os 제작물로 사업성과 수익성은 어덯게 대체하면 좋을까요?').kind,
    ).toBe('talk')
    expect(classifyIntent('구글 작년 사업 계획서 엑셀 표 제작해줘').kind).toBe('sheet-report')
    expect(classifyIntent('마크다운 문서로 정리해줘').kind).toBe('doc')
    expect(classifyIntent('슬라이드 만들어줘').kind).toBe('slides')
  })

  it('keeps office intents ahead of look-up verbs', () => {
    expect(classifyIntent('엑셀 보고서 조사해줘').kind).toBe('sheet-report')
    expect(classifyIntent('슬라이드 자료 찾아줘').kind).toBe('slides')
  })

  it('opens daf.neu for site and web/app wording', () => {
    const naver = classifyIntent('네이버 열어줘')
    expect(naver.kind).toBe('web')
    expect(naver.query).toBe('네이버')
    expect(classifyIntent('강릉 날씨 검색해줘').kind).toBe('web')
    expect(classifyIntent('웹에서 조사해줘').kind).toBe('web')
    expect(classifyIntent('앱 사이트 열어줘').kind).toBe('web')
    expect(classifyIntent('웹에서 삼성전자 조사해줘').query).toContain('삼성전자')
  })

  it('keeps a factual apple question on the left ask path', () => {
    expect(classifyIntent('국내에서 사과 종류가 몇 개나 있어요?').kind).toBe('talk')
  })

  it('extractSearchQuery returns null for plain chat', () => {
    expect(extractSearchQuery('안녕하세요')).toBeNull()
    expect(extractSearchQuery('고마워')).toBeNull()
    expect(extractSearchQuery('강릉 날씨 조사해줘')).toBeNull()
    expect(extractSearchQuery('네이버 열어줘')).toBe('네이버')
  })

  it('opens the English app only on explicit study wording', () => {
    expect(classifyIntent('영어 연습 하고 싶어').kind).toBe('english')
    expect(classifyIntent('practice English with me').kind).toBe('english')
    // plain greeting is NOT english study
    expect(classifyIntent('안녕').kind).toBe('talk')
  })

  it('exits the English app', () => {
    expect(classifyIntent('영어 그만').kind).toBe('english-exit')
    expect(classifyIntent('stop english').kind).toBe('english-exit')
  })
})
