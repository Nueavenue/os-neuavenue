import { describe, expect, it } from 'vitest'
import { markdownToHtml } from './manualMd'

describe('markdownToHtml', () => {
  it('renders headings, lists, and safe links', () => {
    const html = markdownToHtml('# Title\n\n- **Bold** item\n- See [docs](https://docs.neuavenue.com)\n\nType `install os.neu`.\n')
    expect(html).toContain('<h1>Title</h1>')
    expect(html).toContain('<strong>Bold</strong>')
    expect(html).toContain('href="https://docs.neuavenue.com"')
    expect(html).toContain('<code>install os.neu</code>')
    expect(html).not.toContain('<script')
  })

  it('escapes raw html', () => {
    const html = markdownToHtml('<img src=x onerror=alert(1)>')
    expect(html).toContain('&lt;img')
    expect(html).not.toContain('<img')
  })

  it('renders fenced commands and numbered steps', () => {
    const html = markdownToHtml('1. List disks\n\n```\nnpm run usb:list\n```\n')
    expect(html).toContain('<ol>')
    expect(html).toContain('<li>List disks</li>')
    expect(html).toContain('<pre><code>')
    expect(html).toContain('npm run usb:list')
  })
})
