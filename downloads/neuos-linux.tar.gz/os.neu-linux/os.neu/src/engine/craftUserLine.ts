import type { CraftJob } from './craftPlan'

/** What a user needs to know about the Office file step; empty when there is nothing to act on. */
export function craftUserLine(job: CraftJob, ko: boolean): string {
  if (job.web === 'ready' && job.webHref) return ko ? '웹 편집기에서 열기' : 'Open in the web editor'
  if (job.status === 'converted' || job.reason === 'converted') {
    const path = job.outPath || job.outExt || ''
    return ko ? `Office 파일을 만들었습니다: ${path}` : `Office file made: ${path}`
  }
  if (job.status === 'convert-failed' || job.reason === 'convert-failed') {
    return ko
      ? 'Office 파일로 바꾸지 못했습니다. 초안은 그대로 있습니다.'
      : 'Could not turn the draft into an Office file. The draft is still here.'
  }
  return ''
}
