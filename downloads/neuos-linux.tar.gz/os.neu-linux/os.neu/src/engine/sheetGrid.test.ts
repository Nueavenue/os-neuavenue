import { describe, expect, it } from 'vitest'
import { applySheetSeatBody, parseSheetGrid } from './sheetGrid'

describe('parseSheetGrid', () => {
  it('reads a markdown table including a separator row', () => {
    const grid = parseSheetGrid('|항목|내용|\n|---|---|\n|사업 분야|광고|')
    expect(grid[0][0]).toBe('항목')
    expect(grid[0][1]).toBe('내용')
    expect(grid[1][0]).toBe('사업 분야')
    expect(grid[1][1]).toBe('광고')
  })

  it('keeps a partial table while the writer is still going', () => {
    const grid = parseSheetGrid('|A|B|\n|1|')
    expect(grid[0][0]).toBe('A')
    expect(grid[1][0]).toBe('1')
  })

  it('shows display values from an A1 formula dump instead of source', () => {
    const grid = parseSheetGrid(
      [
        '| = A1 | = 월 |',
        '| = B1 | = 매출(만원) |',
        '| = A2 | = 1월 | =B2 | = 50 |',
        '| = A3 | = 2월 | =B3 | = 60 |',
      ].join('\n'),
    )
    expect(grid[0][0]).toBe('월')
    expect(grid[0][1]).toBe('매출(만원)')
    expect(grid[1][0]).toBe('1월')
    expect(grid[1][1]).toBe('50')
    expect(grid[2][0]).toBe('2월')
    expect(grid[2][1]).toBe('60')
    expect(grid[0][2]).toBe('')
    expect(grid[3][0]).toBe('')
  })

  it('skips commentary and the user prompt around a real table', () => {
    const grid = parseSheetGrid(
      '구글 작년 매출 엑셀 표 제작해줘\n아래는 표입니다.\n|월|매출(만원)|\n|---|---|\n|1월|확인 필요|\n```\nsource\n```\n',
    )
    expect(grid[0][0]).toBe('월')
    expect(grid[0][1]).toBe('매출(만원)')
    expect(grid[1][0]).toBe('1월')
    expect(grid[1][1]).toBe('확인 필요')
    expect(grid[2][0]).toBe('')
  })

  it('places A1 = value listings into the addressed cells', () => {
    const grid = parseSheetGrid('A1 = 월\nB1 = 매출\nA2 = 1월\nB2 = 확인 필요')
    expect(grid[0][0]).toBe('월')
    expect(grid[0][1]).toBe('매출')
    expect(grid[1][0]).toBe('1월')
    expect(grid[1][1]).toBe('확인 필요')
  })
})

describe('applySheetSeatBody', () => {
  it('keeps a markdown table', () => {
    const grid = applySheetSeatBody('|월|매출|\n|---|---|\n|1월|확인 필요|')
    expect(grid[0][0]).toBe('월')
    expect(grid[1][0]).toBe('1월')
  })

  it('puts a fail sentence in A1 so the sheet is not blank', () => {
    const grid = applySheetSeatBody('로컬 모델 서버가 응답하지 않습니다.')
    expect(grid[0][0]).toBe('로컬 모델 서버가 응답하지 않습니다.')
    expect(grid[0][1]).toBe('')
  })
})
