import { describe, expect, it } from 'vitest'
import { activeSeatStep, oneLine, seatCardLines } from './seatCard'
import type { SeatStep } from './seatRun'

function step(n: number, status: SeatStep['status'], detail: string): SeatStep {
  return { n, name: 'Execute', status, detail }
}

describe('seat card', () => {
  it('prefers the running or waiting step', () => {
    const rows = [step(5, 'ok', '계획'), step(6, 'running', 'Writer가 글을 쓰는 중입니다.'), step(7, 'pending', '')]
    expect(activeSeatStep(rows)?.n).toBe(6)
  })

  it('shows one step sentence and one result line', () => {
    const rows = [step(9, 'ok', '화면 텍스트와 문서 파일에 같은 글을 넣습니다.')]
    const lines = seatCardLines(rows, '구독 모델\n광고 이동\nAPI 판매', true)
    expect(lines.stepLine).toContain('9.')
    expect(lines.resultLine).toContain('구독 모델')
    expect(lines.resultLine.includes('\n')).toBe(false)
  })

  it('collapses whitespace in oneLine', () => {
    expect(oneLine('  a\n\nb  ')).toBe('a b')
  })
})
