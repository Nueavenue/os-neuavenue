import { describe, expect, it } from 'vitest'
import { CRAFT_CLI, craftBinDirFromEnv, defaultCraftBinDir, detectCraftBins, sidecarCliPath } from './craftDetect'

describe('craftDetect from an injected bin map', () => {
  it('reads PATH-like map entries and ignores empty keys', () => {
    const bins = detectCraftBins({
      [CRAFT_CLI.wordcraft]: '/opt/craft/wordcraft-cli',
      [CRAFT_CLI.gridcraft]: '  /usr/local/bin/gridcraft-cli  ',
      [CRAFT_CLI.deckcraft]: '',
      which: '/usr/bin/which',
    })
    expect(bins.wordcraft).toBe('/opt/craft/wordcraft-cli')
    expect(bins.gridcraft).toBe('/usr/local/bin/gridcraft-cli')
    expect(bins.deckcraft).toBeNull()
  })

  it('treats a missing map as all absent (no throw)', () => {
    expect(detectCraftBins()).toEqual({ wordcraft: null, gridcraft: null, deckcraft: null })
    expect(detectCraftBins({})).toEqual({ wordcraft: null, gridcraft: null, deckcraft: null })
  })

  it('007 sidecar bin dir is absolute and rejects ..', () => {
    expect(defaultCraftBinDir('/home/u')).toBe('/home/u/.local/share/os.neu/craft/bin')
    expect(craftBinDirFromEnv({ OSNEU_CRAFT_BIN_DIR: '/data/craft/bin' }, '/home/u')).toBe('/data/craft/bin')
    expect(craftBinDirFromEnv({ OSNEU_CRAFT_BIN_DIR: '/data/craft/../evil' }, '/home/u')).toBe(
      '/home/u/.local/share/os.neu/craft/bin',
    )
    expect(sidecarCliPath('/data/bin', 'wordcraft-cli', () => true)).toBe('/data/bin/wordcraft-cli')
    expect(sidecarCliPath('/data/bin', 'wordcraft-cli', () => false)).toBeNull()
  })
})
