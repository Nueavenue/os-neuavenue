import { describe, expect, it } from 'vitest'
import { applyOfficeTag, parsePrompt, tokenizePrompt } from './promptParse'

describe('promptParse', () => {
  it('splits a Korean factual ask into words and a search query', () => {
    const parsed = parsePrompt('국내에서 사과 종류가 몇 개나 있어요?')
    expect(parsed.language).toBe('ko')
    expect(parsed.tokens).toContain('사과')
    expect(parsed.tokens).toContain('종류가')
    expect(parsed.factual).toBe(true)
    expect(parsed.searchQuery).toContain('사과')
    expect(parsed.office).toBeNull()
  })

  it('keeps Docs / Sheets / Slides tags and English words', () => {
    const parsed = parsePrompt('[Docs] Write a memo about apple types in Korea')
    expect(parsed.office).toBe('doc')
    expect(parsed.language).toBe('en')
    expect(parsed.tokens).toContain('apple')
    expect(parsed.factual).toBe(false)
    expect(applyOfficeTag('hello', 'slides', 'NEU Investor Deck')).toBe('[Slides:NEU Investor Deck] hello')
  })

  it('tokenizes mixed language without emptying Hangul', () => {
    expect(tokenizePrompt('Fuji 사과 and 홍로')).toEqual(['Fuji', '사과', 'and', '홍로'])
  })
})
