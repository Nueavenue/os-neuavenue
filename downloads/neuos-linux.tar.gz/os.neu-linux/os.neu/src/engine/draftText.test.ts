import { describe, expect, it } from 'vitest'
import { collapseRepeatedDraft, isRepeatingDraft, tidyDraft } from './draftText'

const block = `* 포항 출장 준비
  + 일자: [Insert Date]
  + 출장지: 포항시
  + 출장비: [Insert Amount]`

describe('draft text', () => {
  it('keeps one copy of a repeated memo block', () => {
    const raw = `${block}\n\n${block}\n\n${block}`
    expect(collapseRepeatedDraft(raw)).toBe(block)
    expect(isRepeatingDraft(raw)).toBe(true)
  })

  it('replaces blank form fields after collapsing', () => {
    const tidy = tidyDraft(`${block}\n${block}`)
    expect(tidy).not.toMatch(/Insert Date/i)
    expect(tidy).toContain('확인 필요')
    expect(tidy.split('포항 출장 준비').length - 1).toBe(1)
  })
})
