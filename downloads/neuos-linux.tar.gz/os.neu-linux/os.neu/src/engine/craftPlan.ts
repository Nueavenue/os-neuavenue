import { CRAFT_CLI, type CraftBins } from './craftDetect'

export type CraftJob = {
  kind: 'word' | 'grid' | 'deck' | 'skip'
  surface: 'doc' | 'sheet' | 'slides' | null
  cliName: 'wordcraft-cli' | 'gridcraft-cli' | 'deckcraft-cli' | null
  cliPath: string | null
  outExt: '.docx' | '.xlsx' | '.pptx' | null
  outPath: string | null
  status: 'planned-not-run' | 'unavailable' | 'converted' | 'convert-failed'
  reason: 'no-office-intent' | 'cli-missing' | 'cli-ready' | 'converted' | 'convert-failed'
  mcp: 'ping-ok' | 'skip' | null
  web: 'ready' | 'missing' | null
  webHref: string | null
}

export function planCraftJob(surface: 'doc' | 'sheet' | 'slides' | null, bins: CraftBins): CraftJob {
  if (surface === 'doc') {
    return job('word', 'doc', CRAFT_CLI.wordcraft, '.docx', bins.wordcraft)
  }
  if (surface === 'sheet') {
    return job('grid', 'sheet', CRAFT_CLI.gridcraft, '.xlsx', bins.gridcraft)
  }
  if (surface === 'slides') {
    return job('deck', 'slides', CRAFT_CLI.deckcraft, '.pptx', bins.deckcraft)
  }
  return {
    kind: 'skip',
    surface: null,
    cliName: null,
    cliPath: null,
    outExt: null,
    outPath: null,
    status: 'unavailable',
    reason: 'no-office-intent',
    mcp: null,
    web: null,
    webHref: null,
  }
}

function job(
  kind: 'word' | 'grid' | 'deck',
  surface: 'doc' | 'sheet' | 'slides',
  cliName: CraftJob['cliName'],
  outExt: '.docx' | '.xlsx' | '.pptx',
  cliPath: string | null,
): CraftJob {
  if (cliPath) {
    return { kind, surface, cliName, cliPath, outExt, outPath: null, status: 'planned-not-run', reason: 'cli-ready', mcp: null, web: null, webHref: null }
  }
  return { kind, surface, cliName, cliPath: null, outExt, outPath: null, status: 'unavailable', reason: 'cli-missing', mcp: null, web: null, webHref: null }
}

function sideHints(job: CraftJob) {
  const bits: string[] = []
  if (job.mcp) bits.push(`mcp: ${job.mcp === 'ping-ok' ? 'ping-ok' : 'skip'}`)
  if (job.web) bits.push(`web: ${job.web}`)
  return bits.length ? ` · ${bits.join(' · ')}` : ''
}

export function craftHintLine(job: CraftJob, ko: boolean) {
  if (job.kind === 'skip' || !job.outExt) {
    const base = ko ? '자동 파일: 없음 · 사무 의도 아님' : 'Office file: skip · no office intent'
    return `${base}${sideHints(job)}`
  }
  if (job.status === 'converted' || job.reason === 'converted') {
    const path = job.outPath || job.outExt
    const base = ko
      ? `status=converted · 자동 파일: ${path}`
      : `status=converted · ${path}`
    return `${base}${sideHints(job)}`
  }
  if (job.status === 'convert-failed' || job.reason === 'convert-failed') {
    const base = ko
      ? `status=convert-failed · 자동 파일: ${job.outExt} 예정 · 변환 실패`
      : `status=convert-failed · ${job.outExt} planned · convert failed`
    return `${base}${sideHints(job)}`
  }
  const status = job.reason === 'cli-ready' ? 'planned-not-run' : 'unavailable'
  const line = ko ? `자동 파일: ${job.outExt} 예정` : `Office file: ${job.outExt} planned`
  return `status=${status} · ${line}${sideHints(job)}`
}
