export type PromptOffice = 'doc' | 'sheet' | 'slides'
export type PromptLanguage = 'ko' | 'en' | 'mixed' | 'other'

export type PromptParse = {
  raw: string
  clean: string
  language: PromptLanguage
  tokens: string[]
  office: PromptOffice | null
  slidesTemplate: string | null
  factual: boolean
  searchQuery: string | null
}

const TAG_RE = /\[(docs?|sheets?|slides?|문서|시트|슬라이드)(?::\s*([^\]]+))?\]/gi
const HASH_RE = /#(docs?|sheets?|slides?|문서|시트|슬라이드)\b/gi
const FACTUAL_RE =
  /몇\s*개|종류|무엇|뭐야|뭐예요|뭔가요|어디|언제|누가|왜|시세|가격|how many|what is|which|types? of|how much|where is|when is/i

function officeFromToken(raw: string): PromptOffice | null {
  const key = raw.toLowerCase()
  if (key.startsWith('doc') || key === '문서') return 'doc'
  if (key.startsWith('sheet') || key === '시트') return 'sheet'
  if (key.startsWith('slide') || key === '슬라이드') return 'slides'
  return null
}

function stripTags(text: string): { clean: string; office: PromptOffice | null; slidesTemplate: string | null } {
  let office: PromptOffice | null = null
  let slidesTemplate: string | null = null
  const without = text
    .replace(TAG_RE, (_, kind: string, extra?: string) => {
      office = officeFromToken(kind) || office
      if (extra?.trim()) slidesTemplate = extra.trim()
      return ' '
    })
    .replace(HASH_RE, (hit) => {
      office = officeFromToken(hit.slice(1)) || office
      return ' '
    })
    .replace(/\s+/g, ' ')
    .trim()
  return { clean: without, office, slidesTemplate }
}

export function detectPromptLanguage(text: string): PromptLanguage {
  const hangul = (text.match(/[\uac00-\ud7a3]/g) || []).length
  const latin = (text.match(/[A-Za-z]/g) || []).length
  if (hangul && latin) return 'mixed'
  if (hangul) return 'ko'
  if (latin) return 'en'
  return 'other'
}

export function tokenizePrompt(raw: string): string[] {
  const text = raw.replace(TAG_RE, ' ').replace(HASH_RE, ' ')
  const tokens: string[] = []
  const re = /[A-Za-z0-9]+(?:'[A-Za-z]+)?|[\uac00-\ud7a3]+|[0-9]+(?:[.,][0-9]+)?/g
  let hit: RegExpExecArray | null
  while ((hit = re.exec(text))) {
    if (hit[0]) tokens.push(hit[0])
  }
  return tokens
}

export function isFactualPrompt(text: string): boolean {
  return FACTUAL_RE.test(text)
}

export function parsePrompt(raw: string): PromptParse {
  const text = raw.trim()
  const tagged = stripTags(text)
  const tokens = tokenizePrompt(tagged.clean || text)
  const language = detectPromptLanguage(tagged.clean || text)
  const office = tagged.office
  const factual = !office && isFactualPrompt(tagged.clean)
  const searchQuery = factual ? tokens.slice(0, 10).join(' ') : null
  return {
    raw: text,
    clean: tagged.clean || text,
    language,
    tokens,
    office,
    slidesTemplate: tagged.slidesTemplate,
    factual,
    searchQuery: searchQuery && searchQuery.length >= 2 ? searchQuery : null,
  }
}

export function applyOfficeTag(text: string, office: PromptOffice, template?: string | null): string {
  const stripped = stripTags(text).clean
  const label = office === 'doc' ? 'Docs' : office === 'sheet' ? 'Sheets' : 'Slides'
  const extra = office === 'slides' && template ? `:${template}` : ''
  return `[${label}${extra}] ${stripped}`.trim()
}
