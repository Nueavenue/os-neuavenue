/** Flat multi-file lists for Sheets and Slides (DocApp-style left rail). */

export type OfficeListApp = 'sheet' | 'slides'

export type OfficeListItem<T> = {
  id: string
  name: string
  title: string
  updated: number
  payload: T
}

const MAX = 60

function storageKey(app: OfficeListApp) {
  return `os.neu.${app}.files`
}

function newId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export function normalizeOfficeList<T>(
  rows: unknown,
  fallbackPayload: () => T,
  defaults: { name: string; title: string },
): OfficeListItem<T>[] {
  if (!Array.isArray(rows) || !rows.length) {
    return [
      {
        id: newId('f'),
        name: defaults.name,
        title: defaults.title,
        updated: Date.now(),
        payload: fallbackPayload(),
      },
    ]
  }
  return rows.slice(0, MAX).map((raw, i) => {
    const row = (raw && typeof raw === 'object' ? raw : {}) as Partial<OfficeListItem<T>>
    return {
      id: String(row.id || `f-${Date.now()}-${i}`),
      name: String(row.name || row.title || defaults.name),
      title: String(row.title || row.name || defaults.title),
      updated: Number(row.updated) || Date.now(),
      payload: (row.payload as T) ?? fallbackPayload(),
    }
  })
}

export function loadOfficeList<T>(
  app: OfficeListApp,
  fallbackPayload: () => T,
  defaults: { name: string; title: string },
): OfficeListItem<T>[] {
  try {
    const raw = localStorage.getItem(storageKey(app))
    const rows = raw ? (JSON.parse(raw) as unknown) : []
    const next = normalizeOfficeList(rows, fallbackPayload, defaults)
    saveOfficeList(app, next)
    return next
  } catch {
    /* fall through */
  }
  const seed: OfficeListItem<T> = {
    id: newId('f'),
    name: defaults.name,
    title: defaults.title,
    updated: Date.now(),
    payload: fallbackPayload(),
  }
  saveOfficeList(app, [seed])
  return [seed]
}

export function saveOfficeList<T>(app: OfficeListApp, rows: OfficeListItem<T>[]) {
  try {
    if (typeof localStorage === 'undefined') return
    localStorage.setItem(storageKey(app), JSON.stringify(rows.slice(0, MAX)))
  } catch {
    /* private mode / tests */
  }
}

export function upsertOfficeItem<T>(app: OfficeListApp, rows: OfficeListItem<T>[], next: OfficeListItem<T>) {
  const list = rows.some((row) => row.id === next.id)
    ? rows.map((row) => (row.id === next.id ? next : row))
    : [...rows, next]
  const final = list.slice(0, MAX)
  saveOfficeList(app, final)
  return final
}

export function addOfficeItem<T>(
  app: OfficeListApp,
  rows: OfficeListItem<T>[],
  opts: { name: string; title: string; payload: T },
) {
  const node: OfficeListItem<T> = {
    id: newId(app === 'sheet' ? 'sh' : 'dk'),
    name: opts.name,
    title: opts.title,
    updated: Date.now(),
    payload: opts.payload,
  }
  return { rows: upsertOfficeItem(app, rows, node), node }
}

export function removeOfficeItem<T>(
  app: OfficeListApp,
  rows: OfficeListItem<T>[],
  id: string,
  fallbackPayload: () => T,
  defaults: { name: string; title: string },
) {
  const list = rows.filter((row) => row.id !== id)
  const next =
    list.length > 0
      ? list
      : [
          {
            id: newId('f'),
            name: defaults.name,
            title: defaults.title,
            updated: Date.now(),
            payload: fallbackPayload(),
          } satisfies OfficeListItem<T>,
        ]
  saveOfficeList(app, next)
  return next
}
