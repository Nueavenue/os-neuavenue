export type GuestOs = 'linux' | 'windows' | 'macos' | 'chromeos' | 'unknown'

export function detectGuestOs(ua = '', platformHint = '') {
  const p = String(platformHint || '').toLowerCase()
  const u = String(ua || '').toLowerCase()
  if (p.includes('cros') || u.includes('cros')) return 'chromeos'
  if (p === 'macos' || p.includes('mac') || u.includes('mac os') || u.includes('macintosh')) return 'macos'
  if (p === 'windows' || p === 'win32' || u.includes('windows')) return 'windows'
  if (p === 'linux' || u.includes('linux')) return 'linux'
  return 'unknown'
}

export function detectGuestOsNow() {
  if (typeof navigator === 'undefined') return 'unknown'
  const nav = navigator as Navigator & { userAgentData?: { platform?: string } }
  const hint = nav.userAgentData?.platform || nav.platform || ''
  return detectGuestOs(nav.userAgent, hint)
}

export function packForGuestOs(os: GuestOs, hostname = '') {
  if (os === 'linux') {
    return {
      available: true,
      os,
      file: 'neuos-linux.tar.gz',
      href: hostname === 'localhost' || hostname === '127.0.0.1' ? '/api/download/linux' : '/downloads/neuos-linux.tar.gz',
    }
  }
  const names: Record<GuestOs, string> = {
    windows: 'neuos-windows.zip',
    macos: 'neuos-macos.dmg',
    chromeos: 'neuos-chromeos.tar.gz',
    linux: 'neuos-linux.tar.gz',
    unknown: '',
  }
  return {
    available: false,
    os,
    file: names[os] || '',
    href: '',
  }
}
