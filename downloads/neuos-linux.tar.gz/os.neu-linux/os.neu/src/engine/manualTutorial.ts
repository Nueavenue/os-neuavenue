/** os.neu manual as a tutorial: chapters (left bar) → pages → numbered steps with a screenshot and a comment. */

export type ManualStep = {
  title: string
  text: string
  /** File name under MANUAL_IMG_BASE. */
  img?: string
  /** What to look at in the screenshot. */
  comment?: string
  code?: string
}

/** A page whose guide is still being made. It is shown in the menu with a video slot instead of steps. */
export type ManualPreparing = {
  /** What the video will show, in order. */
  covers: string[]
  /** File name under MANUAL_VIDEO_BASE once the video exists. */
  video?: string
  poster?: string
}

export type ManualPage = {
  id: string
  title: string
  lead: string
  steps: ManualStep[]
  tip?: string
  preparing?: ManualPreparing
}

export type ManualChapter = {
  id: string
  title: string
  pages: ManualPage[]
}

export const MANUAL_IMG_BASE = '/docs/manual/img/'

export function manualImg(name: string) {
  return `${MANUAL_IMG_BASE}${name}`
}

export const MANUAL_VIDEO_BASE = '/docs/manual/video/'

export function manualVideo(name: string) {
  return `${MANUAL_VIDEO_BASE}${name}`
}

export const MANUAL_CHAPTERS: ManualChapter[] = [
  {
    id: 'start',
    title: 'Getting started with OS.neu',
    pages: [
      {
        id: 'what-is',
        title: 'What is OS.neu?',
        lead: 'OS.neu is an AI work screen that sits on the PC you already have. You tell it what you want; it opens the right app, finds sources, and writes the first draft. Your disk is not wiped.',
        steps: [
          {
            title: 'One screen, one prompt',
            text: 'Power-on shows a talk screen instead of folders or a Start menu. The centre box is where you type or speak what you want to do.',
            img: '01-home.webp',
            comment: 'The headline explains the product. The box "Tell me what you want to do" is the prompt. The green button on the right is the microphone.',
          },
          {
            title: 'Three parts work together',
            text: 'OS.neu is the screen and the AI. app.neu holds the apps (Docs, Sheets, Slides and more). daf.neu is the built-in browser that finds and keeps web sources.',
            img: '10-appneu-bar.webp',
            comment: 'Left: the app.neu bar. "Free office" are the three apps you can use today. "daf.neu" at the bottom opens the browser.',
          },
          {
            title: 'Your work stays together',
            text: 'Everything you do for one request — the document, the sources, the AI answers — is kept as one "work". You find it again in My work.',
            img: '11-mywork.webp',
            comment: 'One card = one work. The counts line shows how many docs, sheets, slides, sources, web visits and AI calls belong to it.',
          },
        ],
      },
      {
        id: 'home-tour',
        title: 'Tour of the home screen',
        lead: 'Learn the buttons on the first screen before you start.',
        steps: [
          {
            title: 'Top bar',
            text: 'Left: Sign in, Feedback, the OS.neu logo. Right: the ☰ Menu and × (quit to the host desktop).',
            img: '01-home.webp',
            comment: 'The × on the home screen closes OS.neu. Inner screens use Back instead.',
          },
          {
            title: 'Open the menu',
            text: 'Click ☰. You see the network state, six icons (Plant, USB, Try now, NEU VITALITY, Download, Manual), the language and the clock.',
            img: '02-menu.webp',
            comment: '"Online · 4g" means the network is up. The last icon (page symbol) opens this manual.',
          },
          {
            title: 'Docs, Sheets, Slides',
            text: 'Under the prompt are three buttons. Click one to tell OS.neu which app the answer should land in.',
            img: '06-docs-chip.webp',
            comment: 'After clicking Docs, the chip "Docs included" and an AI model list appear inside the prompt. × removes the chip.',
          },
        ],
      },
      {
        id: 'body-check',
        title: 'Plant, USB, and body check',
        lead: 'Check that the PC is healthy and choose how to keep OS.neu.',
        steps: [
          {
            title: 'Open the panel',
            text: 'On the home screen click "Plant, USB, and body check".',
            img: '05-plant-usb-body.webp',
            comment: 'Three cards: Plant on this device, Burn to USB, Try now. None of them wipes your disk.',
          },
          {
            title: 'Read the body check',
            text: '"Right after power-on" shows screen, thinking unit (CPU), working memory, storage, sound and power in plain words. If something is wrong, it says so here.',
            img: '05-plant-usb-body.webp',
            comment: 'Example values: 2880×1620 screen, 4 cores, about 32 GB memory, about 81 GB free, 3 mics, charging 100%.',
          },
          {
            title: 'Pick a path',
            text: 'Plant on this device = install on this Linux or Windows PC. Burn to USB = make a boot stick (Linux only). Try now = look without installing.',
            comment: 'Next: "Enter os.neu by booting this PC" and "Plant on Linux" show real screens. "Windows 11 download and install" is the photographed Setup.exe path. USB screens are still being captured.',
          },
        ],
      },
      {
        id: 'enter-boot',
        title: 'Enter os.neu by booting this PC (Ubuntu 26.04 LTS)',
        lead: 'On a PC where os.neu is planted next to Ubuntu 26.04 LTS, power on and os.neu opens full screen. These are photos of a real boot.',
        steps: [
          {
            title: 'Pick os.neu in the boot menu',
            text: 'Power on. The boot menu lists "os.neu" first. Press Enter or wait 2 seconds and it starts by itself.',
            img: '40-boot-grub.webp',
            comment: '"Advanced (console network check)" opens a text console that only checks the network. Use it when the screen stays black.',
          },
          {
            title: 'The Neuavenue logo',
            text: 'A white screen with the Neuavenue logo appears while the PC starts.',
            img: '41-boot-splash.webp',
            comment: 'Wait. Do not press keys here.',
          },
          {
            title: 'Text lines may scroll by',
            text: 'On some PCs a few lines of start-up text appear before os.neu. This is Ubuntu starting its own services.',
            img: '42-boot-messages.webp',
            comment: 'Red [FAILED] lines here belong to Ubuntu services on this PC (for example a VirtualBox helper or a bank-security app). They do not stop os.neu.',
          },
          {
            title: 'os.neu gets ready',
            text: 'The os.neu logo shows "Initializing AI runtime…" and ticks four checks: runtime, daf.neu network, app.neu, AI workspace.',
            img: '43-boot-runtime.webp',
            comment: 'The bottom line shows the network and "app.neu ok · daf.neu ok · AI ok". If a check stays grey, reboot and choose Advanced.',
          },
          {
            title: 'You are in os.neu',
            text: 'The home screen opens: the app.neu bar on the left, one prompt box in the middle, Docs / Sheets / Slides under it.',
            img: '44-boot-home.webp',
            comment: 'Answers land in the console under the prompt. "Online · 4g" at the top right means the network is up.',
          },
          {
            title: 'Pick the AI that writes',
            text: 'Choose Docs, Sheets or Slides and send a request. os.neu asks which AI should write it; models with a saved key say "Connected".',
            img: '45-pick-model.webp',
            comment: 'Pick a model and press "Open with current model". "Turn on more models" opens Connect AI.',
          },
          {
            title: 'Open the web inside os.neu',
            text: 'daf.neu at the bottom of the app.neu bar opens web pages inside os.neu, next to your work.',
            img: '46-lifeforce-web.webp',
            comment: 'Here the NeuAvenue Life-Force page is open in daf.neu while the app.neu bar stays on the left.',
          },
          {
            title: 'Make slides from a template',
            text: 'Slides opens the slide studio. Type what the deck is for, or pick a template.',
            img: '47-slides-studio.webp',
            comment: 'Template groups (Investor, Business, Product, …) are along the top. Connect AI on the left shows which AI vendors are on.',
          },
        ],
        tip: 'To go back to Ubuntu: restart and pick Ubuntu in the boot menu, if it is listed. Your Ubuntu files are not changed.',
      },
      {
        id: 'install-linux',
        title: 'Plant on Linux',
        lead: 'Plant OS.neu on a Linux PC without formatting, then open it as a window on your desktop. The first three screens are the Linux screen pack, run on 21 November 2026.',
        steps: [
          {
            title: 'Get the Linux screen pack',
            text: 'On os.neuavenue.com/welcome, choose Linux screen pack. The file is neuos-linux.tar.gz. The large Linux button on that page is the boot kit, a different download.',
            img: '60-linux-pack.webp',
            comment: 'This capture shows the 754K file in a separate home, /tmp/ext-user. Ubuntu stays on. The disk is not wiped.',
          },
          {
            title: 'Unpack the pack',
            text: 'Run tar -xzf neuos-linux.tar.gz. You get os.neu-linux/install.sh and the os.neu folder.',
            img: '61-linux-unpack.webp',
            comment: 'The README says the next command is bash os.neu-linux/install.sh. Node.js 20 and npm must already be on this PC.',
          },
          {
            title: 'Run install.sh',
            text: 'bash os.neu-linux/install.sh copies the pack to ~/os.neu and runs npm install when Electron is missing. It then writes the os.neu launcher. Two questions appear. Both default to N: register a GDM session, and download cage. Answer n unless you want those.',
            img: '62-linux-install-done.webp',
            comment: 'The last lines say os.neu is on this Linux PC. Show Apps received a launcher. This home had no Desktop folder, so no desktop icon was written. The script writes ~/Desktop/neuos.desktop only when that folder already exists. The launcher runs the local copy through open-neuos.sh. It does not open the files published on os.neuavenue.com. This capture did not click the icon, because this PC already had the screen on port 5173.',
          },
          {
            title: 'Plant on this device',
            text: 'On the home screen open "Plant, USB, and body check", press "Plant on this device" and wait for 100%.',
            img: '05-plant-usb-body.webp',
            comment: 'Nothing is formatted. Your Linux files stay as they are.',
          },
          {
            title: 'Open os.neu on your desktop',
            text: 'Open OS.neu from the os.neu icon in Applications or on the Desktop. It opens in its own window on top of your Linux desktop.',
            img: '48-linux-window.webp',
            comment: 'The window has its own title bar (☰ and × at the top right). Your Linux desktop is still behind it.',
          },
        ],
        tip: 'Want os.neu full screen at power-on instead? See "Enter os.neu by booting this PC".',
      },
      {
        id: 'install-windows',
        title: 'Plant on Windows',
        lead: 'Windows 11 x64 (os.neu-Setup.exe or the source pack). The video is the Windows plant from the product film, 23s to 54s. The photographed Setup.exe path is the next page.',
        steps: [],
        preparing: {
          video: 'plant-windows.mp4',
          covers: [
            'Customer path: run os.neu-Setup.exe (SmartScreen: More info → Run anyway).',
            'Developer path: Node.js 20 LTS, about 3 GB free, ports 4178 and 5173 free, then install-windows.ps1.',
            'Open from Start Menu → os.neu (not os.neu.exe) and check that the brand shows OS.neu with a version like v1.0.12 and the app.neu bar appear.',
          ],
        },
      },
      {
        id: 'install-windows-captured',
        title: 'Windows 11 download and install',
        lead: 'Photographed on 20 November 2026 on an English Windows 11 PC. This plants os.neu as a program. Windows stays on. It does not add an os.neu boot entry.',
        steps: [
          {
            title: 'Start from the Windows desktop',
            text: 'Sign in to Windows 11. The desktop is still Windows. os.neu is not installed yet, so there is no os.neu icon.',
            img: '49-win11-desktop.webp',
            comment: 'English Windows 11 desktop before the install. The taskbar, Edge, and the weather widget are Windows itself.',
          },
          {
            title: 'Open the product home',
            text: 'In the browser address bar, open https://os.neuavenue.com/. That is the public home, not the USB kit.',
            img: '50-win11-open-home.webp',
            comment: 'The Run box is only how this capture opened Edge. On your PC, type the same address in Edge or Chrome.',
          },
          {
            title: 'The home page is the seat, in the browser',
            text: 'The home page loads os.neu v1.0 inside the browser: one prompt, Docs, Sheets, Slides, and daf.neu. You can look around here before you install.',
            img: '51-win11-homepage.webp',
            comment: 'The address is os.neuavenue.com. "Online · 4g" means the browser session can reach the network. Windows is still the operating system underneath.',
          },
          {
            title: 'Open the Windows download page',
            text: 'Go to https://os.neuavenue.com/welcome and choose Download os.neu for Windows. That file is os.neu-Setup.exe. The USB / boot-kit button on the same page is a Linux image and does not install the Windows program.',
            img: '52-win11-welcome.webp',
            comment: 'The welcome page says the Linux plant and the Windows zip install on this PC, and that the USB ISO is Linux JeOS, not a Windows Start Menu plant.',
          },
          {
            title: 'Read the Edge warning',
            text: 'The installer is not code-signed yet. Edge says the file is not commonly downloaded. That warning is about trust, not about wiping the disk. Keep the file only if you meant to download it from os.neuavenue.com.',
            img: '53-win11-warning.webp',
            comment: 'The exact line in this capture: "os.neu-Setup (2).exe isn\'t commonly downloaded." The "(2)" is because this PC already had older copies. Your first download may be named os.neu-Setup.exe.',
          },
          {
            title: 'Press Keep',
            text: 'Open edge://downloads. On the file you just downloaded, press Keep. Do not press Delete.',
            img: '54-win11-keep.webp',
            comment: 'Keep is the blue button. This PC also listed older setup files from 9 November and 21 October. Use the file from today.',
          },
          {
            title: 'Confirm the file was kept',
            text: 'After Keep, the download stays in your Downloads folder. Edge may offer Open containing folder rather than Open file.',
            img: '55-win11-kept.webp',
            comment: 'The kept row is os.neu-Setup (2).exe, 20 November. Open that file. Leave the older rows alone.',
          },
          {
            title: 'Choose the install folder',
            text: 'os.neu Setup opens. This capture installed os.neu 1.0.0 into C:\\Users\\billylee\\os.neu (about 90 MB). It is a folder under your user account. It does not replace Windows and it does not create a boot menu.',
            img: '56-win11-location.webp',
            comment: 'The installer window is "Choose Install Location". A command window is also visible behind it in this capture; the step you follow is the os.neu Setup window in front. Press Install.',
          },
          {
            title: 'Wait for the copy',
            text: 'The green bar moves while the files are copied. Leave the window open until it finishes.',
            img: '57-win11-installing.webp',
            comment: 'The title stays "os.neu Setup". Cancel would stop the copy. This capture let it finish.',
          },
          {
            title: 'Finish and launch',
            text: 'The last setup screen says os.neu has been installed. Leave "Run os.neu" checked and press Finish. That opens the program. You can also open it later from the Start Menu or the desktop shortcut named os.neu.',
            img: '58-win11-finish.webp',
            comment: '"Completing os.neu Setup" with Run os.neu checked. Finish is the button that opens the seat.',
          },
          {
            title: 'os.neu is open on Windows',
            text: 'The window title is os.neu v1.0. The status line says Online · 4g and win32 live. win32 live means this window is running on Windows. Docs, Sheets, Slides, daf.neu, and Open the Internet are on this screen.',
            img: '59-win11-running.webp',
            comment: 'Windows never rebooted. The sentence on the screen that says "independent meta environment" is the product text. The status line next to it, win32 live, is what this capture showed.',
          },
        ],
        tip: 'This capture browsed os.neuavenue.com in Edge before install. After install, Open the Internet and daf.neu are visible, but a page opened from that button was not captured.',
      },
      {
        id: 'usb',
        title: 'Burn and boot from USB',
        lead: 'Burning the stick is Linux only; the USB first screen is a dark text console. The video is the first 2 minutes of the 6 November recording, but it begins at a PC boot menu. It does not show the stick being burned or prove that the selected entry came from USB.',
        steps: [],
        preparing: {
          video: 'burn-usb.mp4',
          covers: [
            'Find the stick with "npm run usb:list" — never the disk that holds "/".',
            'Refresh the stick without wiping it (make-usb.sh --update), after you confirm.',
            'Reboot, press F8 at the ASUS logo, choose "UEFI: … USB …", and see "[os.neu] >".',
            'Commands: hardware, memory, network, help, exit, "install os.neu", "open os.neu".',
          ],
        },
        tip: 'To go back to Ubuntu: power off, unplug the USB, power on. The internal disk is not wiped.',
      },
      {
        id: 'recorded-seat-tour',
        title: 'From the boot menu to this manual (6 November recording)',
        lead: 'A frame-by-frame guide to the 20 minute 28 second phone recording made on 6 November 2026. It starts at a PC boot menu, then shows the os.neu seat, web research, work history, Docs, Slides, neuCRM and this manual. It is not a recording of burning a USB stick.',
        steps: [
          {
            title: '0:01 — Read the boot menu',
            text: 'The GNU GRUB menu lists Ubuntu, advanced options, memory tests, firmware settings and os.neu. The glare does not let us prove which row was selected.',
            img: '70-recording-boot-menu.webp',
            comment: 'No USB device list, usb:list command or burn step appears in this recording.',
          },
          {
            title: '0:36 — The os.neu seat',
            text: 'The seat opens with one prompt, Docs, Sheets, Slides, daf.neu, the app.neu bar and a recent work card.',
            img: '71-recording-seat.webp',
            comment: 'This is the screen after power-on in the recording. It does not replace the Ubuntu or Windows kernel.',
          },
          {
            title: '1:36 — Address bar and site pop-up',
            text: 'daf.neu opens neuavenue.com. The site pop-up offers Default, Allow this site and Block this site.',
            img: '72-recording-address-popup.webp',
            comment: 'Use the address bar for a site or search words. Pop-up permission is controlled per site.',
          },
          {
            title: '1:55 — Open ChatGPT',
            text: 'The recording opens chatgpt.com inside the seat browser and shows the public page and cookie choices.',
            img: '73-recording-chatgpt.webp',
            comment: 'A third-party page can change after the recording date.',
          },
          {
            title: '2:20 — A sign-in page',
            text: 'Google sign-in opens for OpenAI. The recording does not show a password or account value, and the attempt later appears in My work as "Couldn\'t sign you in".',
            img: '74-recording-openai-signin.webp',
            comment: 'A failed third-party sign-in does not stop the os.neu seat.',
          },
          {
            title: '2:48 — Return to the online home',
            text: 'The browser home says the network is online and offers Docs, Sheets, Slides, daf.neu, Health and Layers.',
            img: '75-recording-online-home.webp',
            comment: 'The address field is ready for another place or search.',
          },
          {
            title: '3:12 — Research in Perplexity',
            text: 'A Perplexity result about an agent market is opened. Links and follow-up questions belong to that third-party site.',
            img: '76-recording-perplexity.webp',
          },
          {
            title: '3:36 — Read an Agent Market guide',
            text: 'The recording opens WORLD3 documentation titled "How to Use Agent Market" and later returns to Perplexity.',
            img: '77-recording-agent-market-guide.webp',
            comment: 'os.neu keeps the visited web pages with the activity record.',
          },
          {
            title: '5:24 — Check My work',
            text: 'My work lists the recent neuavenue.com, ChatGPT, OpenAI sign-in, Perplexity and WORLD3 visits under the work history.',
            img: '78-recording-my-work.webp',
            comment: 'Continue reopens the work. All activity shows the individual events.',
          },
          {
            title: '6:00 — Ask for a document',
            text: 'Back at the prompt, Docs included and OpenAI GPT-4.1 are selected while an AI Agent market request is entered.',
            img: '79-recording-prompt.webp',
            comment: 'The selected model in this 2026 recording is a cloud model, not proof that a local model is installed.',
          },
          {
            title: '7:00 — The document editor',
            text: 'The generated Docs file opens with formatting controls, a model selector, Preview, Connect AI and Saved.',
            img: '80-recording-doc-editor.webp',
            comment: 'Some body text is unreadable because the monitor was filmed through glare; this guide does not reconstruct it.',
          },
          {
            title: '8:00 — Inspect the model menu',
            text: 'OpenAI GPT-4.1 mini is selected. Other vendor rows visible in the recording say no key.',
            img: '81-recording-model-menu.webp',
            comment: 'No API key value is copied into this guide.',
          },
          {
            title: '11:00 — Open Slides',
            text: 'The Research Report template opens with a title, sections and controls for AI, Export, Export PPTX and Save.',
            img: '82-recording-slides.webp',
          },
          {
            title: '17:00 — Open neuCRM',
            text: 'neuCRM is shown at the Email step with To, Subject, Body and Queue send. This frame does not show that an email was sent.',
            img: '83-recording-neucrm.webp',
            comment: 'Treat Queue send as a pending action until a separate completion message is shown.',
          },
          {
            title: '18:00 — Review an English document',
            text: 'A document titled "AI Agent Market Outlook 2026" is visible with Prepare, Buy and Check sections.',
            img: '84-recording-doc-written.webp',
          },
          {
            title: '19:00 — Choose a presentation template',
            text: 'Presentations with AI shows categories and templates such as Investor Deck, Business Plan, Research Report and Tech Architecture.',
            img: '85-recording-presentations.webp',
            comment: 'Connect AI on the left shows the cloud vendors available to connect.',
          },
          {
            title: '20:24 — Open the os.neu manual',
            text: 'The recording ends inside this manual. Open it again from ☰ Menu → Manual or Settings · Help → Help → Open manual.',
            img: '86-recording-manual.webp',
            comment: 'The full path in the recording is boot menu → seat → web → My work → Docs/Slides/neuCRM → manual.',
          },
        ],
        tip: 'Use this page as a recorded product tour. For USB creation, follow "Burn and boot from USB"; this recording does not contain the burn procedure.',
      },
    ],
  },
  {
    id: 'osneu',
    title: 'Intro to OS.neu',
    pages: [
      {
        id: 'prompt',
        title: 'Ask with the prompt',
        lead: 'Type or speak one line. OS.neu answers in the console under the prompt or continues into a work.',
        steps: [
          {
            title: 'Type',
            text: 'Click the box, type one line, press Enter.',
            img: '01-home.webp',
            comment: 'Example: "Compare three CRM services and write a report for our team."',
          },
          {
            title: 'Speak',
            text: 'The green mic (right) and the speaker (left) sit in the prompt. Their guide is in preparation — see "Mic and speaker".',
            img: '01-home.webp',
            comment: 'Right = mic, left = speaker.',
          },
          {
            title: 'Use an example',
            text: 'Below the prompt, "Service comparison report" and "Make a document from sources" fill in a ready request.',
            img: '21-purpose-card.webp',
            comment: 'The two example buttons are at the very bottom.',
          },
        ],
      },
      {
        id: 'voice',
        title: 'Mic and speaker',
        lead: 'Talk to OS.neu and hear the answer. Screenshots for this guide are being captured.',
        steps: [],
        preparing: {
          covers: [
            'Allow the microphone the first time OS.neu asks.',
            'Tap the green mic, say one line, tap again to send.',
            'The speaker button reads the answer aloud; tap it again to replay.',
            'What to check when nothing is heard or nothing is typed.',
          ],
        },
      },
      {
        id: 'new-work',
        title: 'Start a new work',
        lead: 'A request that makes a document becomes a work. OS.neu asks who it is for when your request does not say.',
        steps: [
          {
            title: 'Send a request',
            text: 'Type what you want and press Enter (or click an example).',
            img: '01-home.webp',
          },
          {
            title: 'Answer "Who is this for?"',
            text: 'The card repeats Your request, then asks for the audience: Internal team review, Customer-facing or Other. The plan shows what OS.neu will do.',
            img: '21-purpose-card.webp',
            comment: '"Your request" is your text. Pick an audience, then press Start. Edit puts your text back in the prompt.',
          },
          {
            title: 'Work view opens',
            text: 'You get the document on the left, sources on the right, and the prompt at the bottom for follow-ups.',
            img: '07-work-view.webp',
            comment: 'Top: work title and "Not saved". Right: Doc / Web tabs. Left rail: This work + All documents.',
          },
          {
            title: 'Save',
            text: 'Press Save when the draft is good. The header changes to "Saved hh:mm".',
          },
        ],
        tip: 'If your request already says the audience ("…for our team"), the card is skipped.',
      },
      {
        id: 'my-work',
        title: 'My work: find, continue, delete, restore',
        lead: 'Every work, with its documents, sources and AI calls, in one list.',
        steps: [
          {
            title: 'Open My work',
            text: 'In the app.neu bar click My work.',
            img: '10-appneu-bar.webp',
            comment: 'My work is under WORK at the top of the bar.',
          },
          {
            title: 'Open a card',
            text: 'Click a work. You see Continue, Delete, its outputs and a timeline.',
            img: '11-mywork.webp',
            comment: 'Timeline rows: "Work started", "AI", and later saves, sources and web visits.',
          },
          {
            title: 'Delete (trash)',
            text: 'Delete hides the work. Nothing is erased. It moves to "Deleted works (n)" at the bottom.',
            img: '12-mywork-trash.webp',
            comment: 'Press Restore to bring it back.',
          },
          {
            title: 'All activity',
            text: 'The All activity tab lists everything by day. Use the filters All, Web, Docs, Sheets, Slides, AI.',
            img: '13-mywork-activity.webp',
            comment: 'The right column shows which work each row belongs to.',
          },
        ],
      },
      {
        id: 'settings',
        title: 'Settings & Help',
        lead: 'Choose AI models, check privacy, and open help.',
        steps: [
          {
            title: 'AI & Usage',
            text: 'Test the connection, connect a key, choose the Default model and which models appear on screen.',
            img: '14-settings-ai.webp',
            comment: 'If Default model says "Turn on a model below first", tick a model that has a key. Otherwise writing cannot start.',
          },
          {
            title: 'Privacy & Permissions',
            text: 'What the AI reads, what is sent to an outside AI, what happens without asking, and your records.',
            img: '15-settings-privacy.webp',
            comment: 'Keep "Ask before the first send to each company" ticked if you want a confirm.',
          },
          {
            title: 'Help',
            text: 'Open manual (this page) or Report a problem.',
            img: '16-settings-help.webp',
          },
        ],
      },
      {
        id: 'connect-ai',
        title: 'Connect an AI model',
        lead: 'Bring your own key (BYOK). A model without a key stays off.',
        steps: [
          {
            title: 'Open the dialog',
            text: 'Settings · Help → AI & Usage → Connect or change key. (Docs, Sheets and Slides also have a Connect AI button.)',
            img: '14-settings-ai.webp',
          },
          {
            title: 'Pick a vendor and paste the key',
            text: 'Choose the vendor in the list, paste the key, save. The pill shows which keys are saved. Scroll down for "Model to use".',
            img: '17-connect-ai.webp',
            comment: 'The dialog scrolls inside. Saved keys are never shown in full.',
          },
          {
            title: 'Turn the model on',
            text: 'Back in AI & Usage, tick the model and choose it as Default model.',
            img: '14-settings-ai.webp',
          },
        ],
      },
      {
        id: 'language-leave',
        title: 'Language and leaving',
        lead: 'Switch language any time; leave with ×.',
        steps: [
          {
            title: 'Change language',
            text: 'Open ☰ Menu and choose a language. The whole screen switches.',
            img: '02-menu.webp',
          },
          {
            title: 'Leave',
            text: 'On the home screen, the top-right × quits to the host desktop. Inner screens use Back.',
            img: '01-home.webp',
          },
        ],
      },
      {
        id: 'desktop-window',
        title: 'The OS.neu desktop window',
        lead: 'How OS.neu behaves as its own app window on Linux and Windows. Screenshots for this guide are being captured.',
        steps: [],
        preparing: {
          covers: [
            'Open OS.neu from the os.neu icon; it starts in its own window.',
            'daf.neu opens new browser windows next to it.',
            'Pop-up controls (Default / Allow / Block) in the address bar.',
            'Leaving with × and opening OS.neu again.',
          ],
        },
      },
    ],
  },
  {
    id: 'appneu',
    title: 'Intro to App.neu',
    pages: [
      {
        id: 'bar',
        title: 'The app.neu bar',
        lead: 'All apps in one bar on the left.',
        steps: [
          {
            title: 'Open the bar',
            text: 'Click the ▦ tab on the left edge. Click ‹ to fold it.',
            img: '10-appneu-bar.webp',
            comment: 'WORK (your works), FREE OFFICE (Docs, Sheets, Slides), paid groups, and OPEN (daf.neu, cloud.neu).',
          },
          {
            title: 'What is available',
            text: 'Grey items say "not yet". Today: Docs, Sheets, Slides, English conversation, CRM and daf.neu.',
          },
          {
            title: 'On the home screen vs. inside an app',
            text: 'On the home screen, Docs / Sheets / Slides add a chip to the prompt. Inside the workspace, they open that app.',
          },
        ],
      },
      {
        id: 'docs',
        title: 'Docs',
        lead: 'Write and edit documents. The AI writes the first draft into the page.',
        steps: [
          {
            title: 'Start from the prompt',
            text: 'Click Docs under the prompt, type your request, press Enter.',
            img: '06-docs-chip.webp',
          },
          {
            title: 'The editor',
            text: 'Format bar (B, I, U, H1, lists, quote, code, table), views Markdown / Word / Preview / Docs, the model list, Connect AI and Save.',
            img: '07-work-view.webp',
            comment: 'Ask AI at the bottom of the page takes follow-up requests for this document.',
          },
          {
            title: 'Wait for the draft',
            text: 'The orange line "Writing…" means the AI is working. Text appears in the page.',
            img: '08-ai-writing-stuck.webp',
            comment: 'If it keeps saying "Writing…", see Troubleshooting → The draft never arrives.',
          },
        ],
      },
      {
        id: 'sheets',
        title: 'Sheets',
        lead: 'A grid for tables. Ask AI fills it.',
        steps: [
          {
            title: 'Open Sheets',
            text: 'app.neu bar → Sheets (or click Sheets under the prompt and send a request).',
            img: '18-sheets.webp',
            comment: 'Title box, columns A–F, rows 1–12, model list, Connect AI and Ask AI at the top.',
          },
          {
            title: 'Fill with AI',
            text: 'Type in Ask AI, for example "Make a monthly budget table". The grid fills in.',
          },
        ],
      },
      {
        id: 'slides',
        title: 'Slides',
        lead: 'os.neu PPT Studio: pick a template, describe your idea.',
        steps: [
          {
            title: 'Open Slides',
            text: 'app.neu bar → Slides.',
            img: '19-slides.webp',
            comment: 'Categories (Investor, Business, Product …), Featured and Popular templates.',
          },
          {
            title: 'Describe and build',
            text: 'Choose a template, type your idea in the box (e.g. "Investor deck, 10 slides"), and let it build. Export to PPTX from the editor.',
          },
        ],
      },
      {
        id: 'this-work',
        title: 'This work vs. All documents',
        lead: 'Inside a work you only see that work’s documents, with the cursor in it.',
        steps: [
          {
            title: 'This work',
            text: 'The left rail is titled "This work" and lists only this work’s document. Other outputs (sheets, slides) appear under it.',
            img: '07-work-view.webp',
            comment: 'Upper left: "THIS WORK" and the All documents button.',
          },
          {
            title: 'All documents',
            text: 'Press All documents to leave the work and see every project.',
          },
        ],
      },
    ],
  },
  {
    id: 'dafneu',
    title: 'Intro to Daf.neu',
    pages: [
      {
        id: 'open',
        title: 'Open the daf.neu browser',
        lead: 'A real browser inside OS.neu.',
        steps: [
          {
            title: 'Open',
            text: 'app.neu bar → daf.neu. It opens in its own window.',
            img: '20-dafneu.webp',
            comment: 'Tabs on top; back, forward, reload, home; the address bar; the search engine list (SearXNG); Go; zoom; downloads (↓).',
          },
          {
            title: 'Search or go',
            text: 'Type an address or words in the address bar and press Go.',
          },
        ],
      },
      {
        id: 'source',
        title: 'Add a web page as a source',
        lead: 'Keep pages you trust with the work.',
        steps: [
          {
            title: 'Web tab',
            text: 'In a work, open the Web tab, type the https:// address and press Add as source.',
            img: '09-work-web.webp',
            comment: 'Open shows the page in daf.neu. "Back to document draft" returns to the Doc tab.',
          },
          {
            title: 'See it in Sources',
            text: 'The page appears in the right panel "Sources for this work" and in My work.',
          },
        ],
      },
      {
        id: 'popups',
        title: 'Pop-ups: Default / Allow / Block',
        lead: 'Control pop-ups per site. This panel shows in the OS.neu desktop window; screenshots for this guide are being captured.',
        steps: [],
        preparing: {
          covers: [
            'Default: sign-up and identity pop-ups open without asking.',
            'Click the address bar: Default / Allow this site / Block this site. There is no global "allow all".',
            'Google, Microsoft, Apple and GitHub logins open in the system browser.',
          ],
        },
      },
    ],
  },
  {
    id: 'help',
    title: 'Troubleshooting',
    pages: [
      {
        id: 'windows-local-ai',
        title: 'Windows: install and use a local AI model',
        lead: 'The Windows Setup installs os.neu, but it does not silently bundle the separate Ollama service or the llama3.2:1b model. Complete this one-time setup while online; after the model is downloaded, local requests can run without an API key or internet connection.',
        steps: [
          {
            title: 'Before you start',
            text: 'Use Windows 11 x64, connect to the internet for the first download, and keep at least 2.5 GB free. Close any old os.neu window before installing the local service.',
          },
          {
            title: 'Install Ollama',
            text: 'Open PowerShell or Windows Terminal and run:',
            code: 'winget install --id Ollama.Ollama -e',
          },
          {
            title: 'Start the local service if needed',
            text: 'Ollama normally starts after installation. If os.neu still says local-unavailable, start it from PowerShell and leave that window open:',
            code: 'Start-Process ollama -ArgumentList "serve"',
          },
          {
            title: 'Download the public 1B model',
            text: 'The first pull is about 1.3–1.5 GB and may take several minutes. Run:',
            code: 'ollama pull llama3.2:1b\nollama list',
          },
          {
            title: 'Check the local API',
            text: 'This command should return a model list containing llama3.2:1b:',
            code: 'Invoke-RestMethod http://127.0.0.1:11434/api/tags',
          },
          {
            title: 'Turn it on in os.neu',
            text: 'Restart os.neu. Open Settings · Help → Power & offline and tick "Use a local model". Then open AI & Usage, turn on llama3.2:1b, choose it as Default model and press Test connection.',
            img: '14-settings-ai.webp',
            comment: 'Expected result: Connected · local · llama3.2:1b. The first reply can take up to 3 minutes while the model loads.',
          },
          {
            title: 'Read the two common errors',
            text: '"Not connected · local-unavailable" means os.neu cannot reach Ollama at 127.0.0.1:11434. "Not on this device" means Ollama answered, but llama3.2:1b is not in ollama list. Start the service for the first error; run the pull command again for the second.',
          },
        ],
        tip: 'llama3.2:1b is small enough for a laptop, but its Korean and long-document quality are limited. Use a connected cloud model when you need stronger writing. The older os.neu-win zip did not contain Ollama or this model either.',
      },
      {
        id: 'writing',
        title: 'The draft never arrives',
        lead: 'The page says "Writing…" and no text appears. Cloud models paste the whole draft at once when done. If no text arrives within 2 minutes (local models: up to 3 minutes while they load), the run stops and tells you why.',
        steps: [
          {
            title: 'Look at the model',
            text: 'Check the model name in the editor. If it is a local model that is not on this PC, nothing will be written.',
            img: '08-ai-writing-stuck.webp',
            comment: 'The orange "Writing…" line under Ask AI stays and the page does not change.',
          },
          {
            title: 'Add your key',
            text: 'Settings · Help → AI & Usage → Connect or change key. Pick the vendor (for example OpenAI), paste your key, save. Only the last characters of a saved key are ever shown.',
            img: '17-connect-ai.webp',
            comment: 'The pill at the top lists the keys that are saved on this PC.',
          },
          {
            title: 'Turn a model on',
            text: 'Back in AI & Usage, tick the model of that vendor under "Models shown on screen", then choose it as Default model. Press Test connection.',
            img: '14-settings-ai.webp',
            comment: '"Turn on a model below first" means no model is on yet.',
          },
          {
            title: 'Try again',
            text: 'Start the work again or use Ask AI in the document.',
          },
        ],
      },
      {
        id: 'usb-other',
        title: 'USB: if you see something else',
        lead: 'What to do when the USB boot does not show [os.neu] >.',
        steps: [
          {
            title: 'Usual Ubuntu or Windows opens',
            text: 'The USB was not selected. Reboot and pick the USB in F8 again.',
          },
          {
            title: 'grub> appears',
            text: 'Type these two lines:',
            code: 'search --label NEUOS-ROOT --set=root\nconfigfile /boot/grub/grub.cfg',
          },
          {
            title: 'BusyBox # or "payload not found"',
            text: 'Power off, boot Ubuntu, run the --update step again.',
          },
        ],
        tip: 'Give up safely: hold power, unplug USB, power on. The internal disk is not wiped.',
      },
      {
        id: 'manual-again',
        title: 'Open this manual again',
        lead: 'Two ways back to this manual.',
        steps: [
          {
            title: 'From the menu',
            text: '☰ Menu → Manual icon. The card shows Linux, Windows, USB and Try now.',
            img: '03-manual-card.webp',
            comment: 'Click docs.neuavenue.com at the bottom of the card to open this manual.',
          },
          {
            title: 'From Settings',
            text: 'Settings · Help → Help → Open manual.',
            img: '16-settings-help.webp',
          },
        ],
      },
    ],
  },
]

export type ManualPageRef = { chapter: ManualChapter; page: ManualPage; chapterNo: number; pageNo: number }

export function flatManualPages(chapters: ManualChapter[] = MANUAL_CHAPTERS): ManualPageRef[] {
  return chapters.flatMap((chapter, ci) =>
    chapter.pages.map((page, pi) => ({ chapter, page, chapterNo: ci + 1, pageNo: pi + 1 })),
  )
}

export function manualKey(ref: { chapter: ManualChapter; page: ManualPage }) {
  return `${ref.chapter.id}/${ref.page.id}`
}

export function findManualPage(key: string, chapters: ManualChapter[] = MANUAL_CHAPTERS) {
  const all = flatManualPages(chapters)
  const index = all.findIndex((ref) => manualKey(ref) === key)
  const at = index < 0 ? 0 : index
  return { current: all[at], prev: all[at - 1] ?? null, next: all[at + 1] ?? null }
}
