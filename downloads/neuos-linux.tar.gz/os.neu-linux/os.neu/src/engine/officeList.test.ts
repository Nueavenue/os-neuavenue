import { describe, expect, it } from 'vitest'
import {
  addOfficeItem,
  bootOfficeList,
  normalizeOfficeList,
  rememberOfficeActive,
  removeOfficeItem,
  upsertOfficeItem,
} from './officeList'

describe('officeList', () => {
  it('seeds one file when empty', () => {
    const rows = normalizeOfficeList<{ n: number }>([], () => ({ n: 1 }), { name: 'A', title: 'A title' })
    expect(rows).toHaveLength(1)
    expect(rows[0].payload.n).toBe(1)
    expect(rows[0].title).toBe('A title')
  })

  it('keeps sibling payloads when updating one', () => {
    const a = {
      id: 'a',
      name: 'A',
      title: 'A',
      updated: 1,
      payload: { n: 1 },
    }
    const b = {
      id: 'b',
      name: 'B',
      title: 'B',
      updated: 1,
      payload: { n: 2 },
    }
    const next = upsertOfficeItem('sheet', [a, b], { ...a, payload: { n: 9 }, updated: 2 })
    expect(next.find((row) => row.id === 'a')?.payload.n).toBe(9)
    expect(next.find((row) => row.id === 'b')?.payload.n).toBe(2)
  })

  it('adds and removes without dropping the last file', () => {
    let rows = normalizeOfficeList<{ n: number }>([], () => ({ n: 0 }), { name: 'Seed', title: 'Seed' })
    const added = addOfficeItem('slides', rows, { name: 'Deck', title: 'Deck', payload: { n: 3 } })
    rows = added.rows
    expect(rows).toHaveLength(2)
    rows = removeOfficeItem('slides', rows, added.node.id, () => ({ n: 0 }), { name: 'Seed', title: 'Seed' })
    expect(rows).toHaveLength(1)
    rows = removeOfficeItem('slides', rows, rows[0].id, () => ({ n: 7 }), { name: 'Seed', title: 'Seed' })
    expect(rows).toHaveLength(1)
    expect(rows[0].payload.n).toBe(7)
  })

  it('boots the remembered active sheet', () => {
    const mem = new Map<string, string>()
    const ls = {
      getItem: (k: string) => mem.get(k) ?? null,
      setItem: (k: string, v: string) => {
        mem.set(k, String(v))
      },
      removeItem: (k: string) => {
        mem.delete(k)
      },
      clear: () => mem.clear(),
      key: () => null,
      get length() {
        return mem.size
      },
    }
    Object.defineProperty(globalThis, 'localStorage', { value: ls, configurable: true })
    const a = { id: 'a', name: 'A', title: 'A', updated: 1, payload: { n: 1 } }
    const b = { id: 'b', name: 'B', title: 'B', updated: 2, payload: { n: 2 } }
    upsertOfficeItem('sheet', [a, b], b)
    rememberOfficeActive('sheet', 'b')
    const boot = bootOfficeList<{ n: number }>('sheet', () => ({ n: 0 }), { name: 'Seed', title: 'Seed' })
    expect(boot.activeId).toBe('b')
    expect(boot.rows.find((row) => row.id === 'b')?.payload.n).toBe(2)
  })
})
