import { describe, expect, it } from 'vitest'
import type { CraftJob } from './craftPlan'
import { craftUserLine } from './craftUserLine'

const base: CraftJob = {
  kind: 'grid',
  surface: 'sheet',
  cliName: 'gridcraft-cli',
  cliPath: null,
  outExt: '.xlsx',
  outPath: null,
  status: 'unavailable',
  reason: 'cli-missing',
  mcp: 'skip',
  web: 'missing',
  webHref: null,
}

describe('craftUserLine', () => {
  it('hides the developer status when nothing can be done', () => {
    expect(craftUserLine(base, false)).toBe('')
    expect(craftUserLine({ ...base, status: 'planned-not-run', reason: 'cli-ready' }, false)).toBe('')
    expect(craftUserLine({ ...base, kind: 'skip', outExt: null, reason: 'no-office-intent' }, true)).toBe('')
  })

  it('never shows raw keys like status= or mcp:', () => {
    const lines = [
      craftUserLine({ ...base, status: 'converted', reason: 'converted', outPath: '/tmp/a.xlsx' }, false),
      craftUserLine({ ...base, status: 'convert-failed', reason: 'convert-failed' }, false),
      craftUserLine({ ...base, web: 'ready', webHref: 'http://x' }, false),
    ]
    for (const line of lines) {
      expect(line).not.toMatch(/status=|mcp:|web:/)
      expect(line.length).toBeGreaterThan(0)
    }
  })

  it('names the made file', () => {
    expect(craftUserLine({ ...base, status: 'converted', reason: 'converted', outPath: '/tmp/a.xlsx' }, false)).toBe(
      'Office file made: /tmp/a.xlsx',
    )
  })
})
