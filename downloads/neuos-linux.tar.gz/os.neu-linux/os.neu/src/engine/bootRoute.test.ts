import { describe, expect, it } from 'vitest'
import { bootAfterSplash, phaseFromQuery, shouldRunBootTimer } from './bootRoute'

describe('boot route', () => {
  it('sends an unplanted splash to the install cards', () => {
    expect(bootAfterSplash(false)).toBe('install')
  })

  it('sends a planted splash to the body check', () => {
    expect(bootAfterSplash(true)).toBe('post')
  })

  it('does not re-run the splash timer after the user leaves splash', () => {
    expect(shouldRunBootTimer('splash')).toBe(true)
    expect(shouldRunBootTimer('post')).toBe(false)
    expect(shouldRunBootTimer('announce')).toBe(false)
    expect(shouldRunBootTimer('install')).toBe(false)
  })

  it('honors ?go= only for known screens', () => {
    expect(phaseFromQuery('post')).toBe('post')
    expect(phaseFromQuery('announce')).toBe('announce')
    expect(phaseFromQuery('nope')).toBeNull()
  })
})
