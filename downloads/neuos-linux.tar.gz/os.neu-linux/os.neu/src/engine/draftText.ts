/** Turn a looping local draft into one copy, and drop blank form fields. */

function normBlock(lines: string[]) {
  return lines.map((line) => line.trim()).join('\n')
}

export function collapseRepeatedDraft(text: string): string {
  let lines = text.replace(/\r\n/g, '\n').split('\n')
  let changed = true
  while (changed) {
    changed = false
    const filled = lines.map((line, index) => ({ index, text: line.trim() })).filter((row) => row.text)
    for (let size = 6; size >= 2 && !changed; size--) {
      for (let start = 0; start + size * 2 <= filled.length; start++) {
        const a = normBlock(filled.slice(start, start + size).map((row) => row.text))
        const b = normBlock(filled.slice(start + size, start + size * 2).map((row) => row.text))
        if (!a.trim() || a !== b) continue
        const from = filled[start + size].index
        const to = filled[start + size * 2 - 1].index
        lines.splice(from, to - from + 1)
        changed = true
        break
      }
    }
  }
  const noDup: string[] = []
  for (const line of lines) {
    const prev = noDup[noDup.length - 1]
    if (prev !== undefined && prev.trim() && prev.trim() === line.trim()) continue
    noDup.push(line)
  }
  return noDup.join('\n').replace(/\n{3,}/g, '\n\n').trim()
}

/** True when the tail of the draft is the same block twice — the model is looping. */
export function isRepeatingDraft(text: string): boolean {
  const lines = text
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
  if (lines.length < 6) return false
  for (let size = 4; size >= 2; size--) {
    if (lines.length < size * 2) continue
    const a = lines.slice(-size).join('\n')
    const b = lines.slice(-size * 2, -size).join('\n')
    if (a.length > 20 && a === b) return true
  }
  return false
}

export function tidyDraft(text: string): string {
  return collapseRepeatedDraft(text)
    .replace(/\[insert date\]/gi, '확인 필요')
    .replace(/\[insert amount\]/gi, '확인 필요')
    .replace(/\[insert[^\]]*\]/gi, '확인 필요')
}
