/**
 * WO-UI-NEU-SLIDES-PPT-STUDIO-STEP1-VISUAL-121 — Leader spec §15 template contract.
 * Templates carry visual/style/structure metadata; runtime deck still loads generic
 * pitch | report | product packs (6 slides, title | bullets | table).
 */
import type { OutlinePackId } from './slideOutlines'
import { getLicensedPilot } from './licenseImport'

export type TemplateGroup = 'featured' | 'popular'

export type TemplateCategory =
  | 'Investor'
  | 'Business'
  | 'Product'
  | 'Tech'
  | 'Marketing'
  | 'Education'
  | 'Report'
  | 'Custom'

export type TemplatePreviewTheme = 'neu-investor' | 'modern-business' | 'tech-arch' | 'minimal-corp' | 'dark-tech' | 'pitch' | 'paper' | 'report' | 'marketing' | 'training'

export type PresentationTemplateStyle = {
  theme: string
  typography: string
  density: 'light' | 'medium' | 'dense'
  visualTone: string
  accent: string
}

export type TemplatePackPolicy = {
  defaultSlides: number
  minSlides: number
  maxSlides: number
}

/** 122E — license metadata on imported / pilot templates. Native five omit this. */
export type TemplateLicenseMeta = {
  source: string
  license: string
  licenseUrl: string
  attributionRequired: boolean
  attributionText: string
}

export type PresentationTemplate = {
  id: string
  name: string
  nameKo: string
  category: TemplateCategory
  /** Category pill filter id (lowercase) */
  categoryFilter: string
  description: string
  descriptionKo: string
  /** Short line under title on card */
  cardSubtitle: string
  cardSubtitleKo: string
  aspectRatio: '16:9'
  /** Leader §15; `ppt-preview://` maps to CSS 16:9 until `.webp` assets ship */
  previewImage?: string
  previewTheme: TemplatePreviewTheme
  style: PresentationTemplateStyle
  structure: string[]
  /** Slide count policy (Leader runtime §4). */
  packPolicy: TemplatePackPolicy
  group: TemplateGroup
  pack: OutlinePackId
  license?: TemplateLicenseMeta
  /**
   * HTML cream-paper deck (PSST/IR pack). When set, PPT Studio opens this
   * viewer instead of the recipe title/bullets/table editor.
   */
  htmlDeckUrl?: string
  /**
   * Gallery / Decks visibility. `ceo-only` = Leader email or Command View grant only
   * (NeuAvenue business-plan presentation). Default public.
   */
  audience?: 'public' | 'ceo-only'
}

export const CATEGORY_FILTERS: { id: string; en: string; ko: string }[] = [
  { id: 'all', en: 'All', ko: '전체' },
  { id: 'investor', en: 'Investor', ko: '투자' },
  { id: 'business', en: 'Business', ko: '비즈니스' },
  { id: 'product', en: 'Product', ko: '제품' },
  { id: 'tech', en: 'Tech', ko: '기술' },
  { id: 'marketing', en: 'Marketing', ko: '마케팅' },
  { id: 'education', en: 'Education', ko: '교육' },
  { id: 'report', en: 'Report', ko: '보고' },
  { id: 'custom', en: 'Custom', ko: '사용자' },
]

export const PRESENTATION_TEMPLATES: PresentationTemplate[] = [
  {
    id: 'ir-psst',
    name: 'IR PSST',
    nameKo: 'IR PSST',
    category: 'Investor',
    categoryFilter: 'investor',
    description:
      'Sample cream-paper layouts (YC / EIC / Slidev-style patterns). Not a copy of the full PSST pack. Surgical Agent edits.',
    descriptionKo:
      '예제 크림지 레이아웃(YC·EIC·Slidev 패턴). 풀 사업계획서 복제 아님. Agent는 부분 수정(ops) 기본.',
    cardSubtitle: 'Sample layouts · not full BP',
    cardSubtitleKo: '예제 레이아웃 · 풀 팩 아님',
    aspectRatio: '16:9',
    previewTheme: 'paper',
    style: {
      theme: 'paper-cream',
      typography: 'inter-noto',
      density: 'medium',
      visualTone: 'institutional',
      accent: 'ember',
    },
    structure: ['cover', 'problem', 'solution', 'grid', 'table', 'closing'],
    packPolicy: { defaultSlides: 6, minSlides: 4, maxSlides: 12 },
    group: 'featured',
    pack: 'pitch',
    htmlDeckUrl: '/psst-ir-pack/sample-deck/index.html',
  },
  {
    id: 'ir-psst-full',
    name: 'PSST Full Pack',
    nameKo: 'PSST 풀 팩',
    category: 'Investor',
    categoryFilter: 'investor',
    description:
      'NeuAvenue business-plan presentation (CEO / Leader only). Not shown in the public gallery.',
    descriptionKo:
      'NeuAvenue 사업계획서 발표본 · 대표(CEO) 전용. 공개 갤러리에는 표시되지 않습니다.',
    cardSubtitle: 'CEO only · business-plan',
    cardSubtitleKo: '대표 전용 · 사업계획서',
    aspectRatio: '16:9',
    previewTheme: 'paper',
    style: {
      theme: 'paper-cream',
      typography: 'inter-noto',
      density: 'dense',
      visualTone: 'institutional',
      accent: 'ember',
    },
    structure: ['cover', 'problem', 'solution', 'market', 'product', 'finance', 'team', 'early-voice'],
    packPolicy: { defaultSlides: 12, minSlides: 6, maxSlides: 32 },
    group: 'popular',
    pack: 'pitch',
    htmlDeckUrl: '/psst-ir-pack/index.html',
    audience: 'ceo-only',
  },
  {
    id: 'northline-ir-demo',
    name: 'Sample Co. DEMO IR',
    nameKo: 'Sample Co. DEMO IR',
    category: 'Investor',
    categoryFilter: 'investor',
    description:
      'Public cream HTML pack — PSST shell layout/colors, sanitized fictional copy (no founder name, posters omitted). Demo only.',
    descriptionKo:
      '공개용 크림 HTML 팩. PSST 레이아웃·색 유지 · 가상 회사 카피(대표 이름 없음 · 포스터 23–29 제외). 데모 전용.',
    cardSubtitle: 'Public twin · sanitized demo',
    cardSubtitleKo: '공개 쌍둥이 · 정제 데모',
    aspectRatio: '16:9',
    previewTheme: 'paper',
    style: {
      theme: 'paper-cream',
      typography: 'inter-noto',
      density: 'dense',
      visualTone: 'institutional',
      accent: 'ember',
    },
    structure: ['cover', 'problem', 'solution', 'market', 'product', 'finance', 'team', 'early-voice'],
    packPolicy: { defaultSlides: 12, minSlides: 6, maxSlides: 32 },
    group: 'featured',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/northline-ir-demo/index.html',
    audience: 'public',
  },
  {
    id: 'neu-investor-dark',
    name: 'NEU Investor Deck',
    nameKo: 'NEU 투자 덱',
    category: 'Investor',
    categoryFilter: 'investor',
    description: 'Professional investor deck for funding, partnerships and strategic discussions.',
    descriptionKo: '펀딩·파트너십·전략 논의용 투자 프레젠테이션.',
    cardSubtitle: 'For funding and partnerships',
    cardSubtitleKo: '펀딩 및 파트너십',
    aspectRatio: '16:9',
    previewTheme: 'neu-investor',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'premium',
      accent: 'blue-purple',
    },
    structure: [
      'cover',
      'problem',
      'solution',
      'market',
      'product',
      'technology',
      'business-model',
      'traction',
      'roadmap',
      'team',
      'funding',
      'closing',
    ],
    packPolicy: { defaultSlides: 12, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/neu-investor-dark/index.html',
  },
  {
    id: 'modern-business',
    name: 'Modern Business',
    nameKo: '모던 비즈니스',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Clean and professional business narrative.',
    descriptionKo: '깔끔하고 전문적인 비즈니스 내러티브.',
    cardSubtitle: 'Clean & professional',
    cardSubtitleKo: '단정 · 프로페셔널',
    aspectRatio: '16:9',
    previewTheme: 'modern-business',
    style: {
      theme: 'light-minimal',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'calm',
      accent: 'slate',
    },
    structure: ['cover', 'agenda', 'overview', 'highlights', 'next-steps', 'team', 'risks', 'closing'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/modern-business/index.html',
  },
  {
    id: 'tech-architecture',
    name: 'Tech Architecture',
    nameKo: '기술 아키텍처',
    category: 'Tech',
    categoryFilter: 'tech',
    description: 'Technical diagrams and system overview.',
    descriptionKo: '기술 다이어그램과 시스템 개요.',
    cardSubtitle: 'Technical diagrams',
    cardSubtitleKo: '기술 다이어그램',
    aspectRatio: '16:9',
    previewTheme: 'tech-arch',
    style: {
      theme: 'dark-grid',
      typography: 'space-grotesk',
      density: 'medium',
      visualTone: 'technical',
      accent: 'electric-blue',
    },
    structure: [
      'cover',
      'context',
      'architecture',
      'components',
      'data-flow',
      'security',
      'scalability',
      'integration',
      'roadmap',
      'closing',
    ],
    packPolicy: { defaultSlides: 10, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
    htmlDeckUrl: '/html-templates/tech-architecture/index.html',
  },
  {
    id: 'minimal-corporate',
    name: 'Minimal Corporate',
    nameKo: '미니멀 코퍼레이트',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Simple and elegant corporate reporting.',
    descriptionKo: '단순하고 우아한 기업 보고.',
    cardSubtitle: 'Simple & elegant',
    cardSubtitleKo: '심플 · 우아함',
    aspectRatio: '16:9',
    previewTheme: 'minimal-corp',
    style: {
      theme: 'light-typography',
      typography: 'ibm-plex',
      density: 'light',
      visualTone: 'corporate',
      accent: 'neutral',
    },
    structure: ['cover', 'summary', 'vision', 'progress', 'metrics', 'risks', 'team', 'next'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'report',
    htmlDeckUrl: '/html-templates/minimal-corporate/index.html',
  },
  {
    id: 'dark-tech',
    name: 'Dark Tech',
    nameKo: '다크 테크',
    category: 'Tech',
    categoryFilter: 'tech',
    description: 'Bold modern product story on dark canvas.',
    descriptionKo: '다크 캔버스의 대담한 제품 스토리.',
    cardSubtitle: 'Bold & modern',
    cardSubtitleKo: '볼드 · 모던',
    aspectRatio: '16:9',
    previewTheme: 'dark-tech',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'premium',
      accent: 'purple-blue',
    },
    structure: ['cover', 'problem', 'product', 'features', 'comparison', 'next'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
    htmlDeckUrl: '/html-templates/dark-tech/index.html',
  },
  {
    id: 'product-launch',
    name: 'Product Launch',
    nameKo: '제품 런치',
    category: 'Product',
    categoryFilter: 'product',
    description: 'Launch narrative: problem, steps, comparison, and next.',
    descriptionKo: '런치 내러티브: 문제, 단계, 비교, 다음.',
    cardSubtitle: 'Ship the story',
    cardSubtitleKo: '출시 이야기',
    aspectRatio: '16:9',
    previewTheme: 'dark-tech',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'launch',
      accent: 'purple-blue',
    },
    structure: ['cover', 'problem', 'audience', 'steps', 'feature-comparison', 'benefits', 'timeline', 'next'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
    htmlDeckUrl: '/html-templates/product-launch/index.html',
  },
  {
    id: 'popular-pitch-deck',
    name: 'Pitch Deck',
    nameKo: '피치 덱',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Classic pitch flow in six slides.',
    descriptionKo: '6장 클래식 피치 흐름.',
    cardSubtitle: 'Problem → Ask',
    cardSubtitleKo: '문제 → 요청',
    aspectRatio: '16:9',
    previewTheme: 'pitch',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'startup',
      accent: 'blue-purple',
    },
    structure: ['cover', 'problem', 'solution', 'market', 'team', 'ask'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/popular-pitch-deck/index.html',
  },
  {
    id: 'business-plan',
    name: 'Business Plan',
    nameKo: '사업 계획',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Plan outline from cover through next steps.',
    descriptionKo: '표지부터 다음 단계까지 사업 계획 개요.',
    cardSubtitle: 'Strategy outline',
    cardSubtitleKo: '전략 개요',
    aspectRatio: '16:9',
    previewTheme: 'paper',
    style: {
      theme: 'light-minimal',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'professional',
      accent: 'slate',
    },
    structure: ['cover', 'vision', 'market', 'model', 'plan', 'milestones'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/business-plan/index.html',
  },
  {
    id: 'research-report',
    name: 'Research Report',
    nameKo: '리서치 보고',
    category: 'Report',
    categoryFilter: 'report',
    description: 'Findings, metrics table, and recommendations.',
    descriptionKo: '발견, 지표 표, 권고.',
    cardSubtitle: 'Findings & metrics',
    cardSubtitleKo: '발견 · 지표',
    aspectRatio: '16:9',
    previewTheme: 'report',
    style: {
      theme: 'mist',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'analytical',
      accent: 'teal',
    },
    structure: ['cover', 'summary', 'method', 'findings', 'metrics', 'recommendations'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'report',
    htmlDeckUrl: '/html-templates/research-report/index.html',
  },
  {
    id: 'marketing-plan',
    name: 'Marketing Plan',
    nameKo: '마케팅 계획',
    category: 'Marketing',
    categoryFilter: 'marketing',
    description: 'Campaign narrative and roadmap table.',
    descriptionKo: '캠페인 내러티브와 로드맵 표.',
    cardSubtitle: 'Campaign focus',
    cardSubtitleKo: '캠페인 중심',
    aspectRatio: '16:9',
    previewTheme: 'marketing',
    style: {
      theme: 'light-vivid',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'energetic',
      accent: 'coral',
    },
    structure: ['cover', 'audience', 'message', 'channels', 'timeline', 'kpis'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
    htmlDeckUrl: '/html-templates/marketing-plan/index.html',
  },
  {
    id: 'training-education',
    name: 'Training & Education',
    nameKo: '교육 · 트레이닝',
    category: 'Education',
    categoryFilter: 'education',
    description: 'Step-by-step learning deck with feature table.',
    descriptionKo: '단계별 학습 덱과 기능 표.',
    cardSubtitle: 'Steps & exercises',
    cardSubtitleKo: '단계 · 실습',
    aspectRatio: '16:9',
    previewTheme: 'training',
    style: {
      theme: 'grid',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'friendly',
      accent: 'green',
    },
    structure: ['cover', 'objectives', 'steps', 'demo', 'quiz', 'resources'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'product',
    htmlDeckUrl: '/html-templates/training-education/index.html',
  },
]

export function packPolicyFor(template: PresentationTemplate): TemplatePackPolicy {
  return template.packPolicy
}

export function resolvePreviewImage(t: PresentationTemplate): string {
  return t.previewImage ?? `ppt-preview://${t.id}`
}

export function titleColorForTemplate(t: PresentationTemplate | null | undefined): string | undefined {
  if (!t) return undefined
  const accent = t.style.accent
  if (accent.includes('purple') || accent.includes('blue')) return '4F46E5'
  if (accent.includes('teal')) return '0D9488'
  if (accent.includes('coral')) return 'EA580C'
  if (accent.includes('green')) return '059669'
  return '1E293B'
}

export function getTemplateById(id: string): PresentationTemplate | undefined {
  const native = PRESENTATION_TEMPLATES.find((t) => t.id === id)
  if (native) return native
  return getLicensedPilot(id)
}

export function isCeoOnlyTemplate(t: PresentationTemplate | null | undefined): boolean {
  return Boolean(t && t.audience === 'ceo-only')
}

/** Gallery / recommend pool — hide CEO-only packs unless viewerIsCeo. */
export function templatesVisibleTo(
  templates: PresentationTemplate[],
  viewerIsCeo: boolean,
): PresentationTemplate[] {
  return templates.filter((t) => (t.audience === 'ceo-only' ? viewerIsCeo : true))
}

export function filterTemplates(
  templates: PresentationTemplate[],
  categoryId: string,
  query: string,
  opts?: { viewerIsCeo?: boolean },
): PresentationTemplate[] {
  const q = query.trim().toLowerCase()
  const viewerIsCeo = Boolean(opts?.viewerIsCeo)
  return templates.filter((t) => {
    if (t.audience === 'ceo-only' && !viewerIsCeo) return false
    if (categoryId !== 'all') {
      if (categoryId === 'custom') {
        if (t.category !== 'Custom') return false
      } else if (categoryId === 'product') {
        if (t.pack !== 'product' && t.categoryFilter !== 'product') return false
      } else if (t.categoryFilter !== categoryId) return false
    }
    if (!q) return true
    const blob = `${t.name} ${t.nameKo} ${t.description} ${t.category} ${t.cardSubtitle}`.toLowerCase()
    return blob.includes(q)
  })
}
