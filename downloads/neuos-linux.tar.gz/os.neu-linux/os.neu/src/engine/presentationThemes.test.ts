import { describe, expect, it } from 'vitest'
import { getTemplateById, PRESENTATION_TEMPLATES } from './presentationTemplates'
import { ensureThemeContrast, themeForEditor, themeForTemplate } from './presentationThemes'

function lum(hex: string) {
  const n = Number.parseInt(hex.replace('#', '').slice(0, 6), 16)
  const r = (n >> 16) & 255
  const g = (n >> 8) & 255
  const b = n & 255
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

describe('presentation theme contrast', () => {
  it('untitled editor is light board + dark ink (not white-on-white)', () => {
    const theme = themeForEditor(null)
    expect(lum(theme.background)).toBeGreaterThan(160)
    expect(lum(theme.foreground)).toBeLessThan(80)
    expect(Math.abs(lum(theme.background) - lum(theme.foreground))).toBeGreaterThanOrEqual(90)
  })

  it('light template keeps dark ink; dark template keeps light ink', () => {
    const light = themeForEditor(getTemplateById('minimal-corporate'))
    expect(lum(light.foreground)).toBeLessThan(lum(light.background))
    const dark = themeForEditor(getTemplateById('neu-investor-dark'))
    expect(lum(dark.foreground)).toBeGreaterThan(lum(dark.background))
  })

  it('every catalog template has readable editor contrast', () => {
    for (const template of PRESENTATION_TEMPLATES) {
      const theme = themeForEditor(template)
      expect(Math.abs(lum(theme.background) - lum(theme.foreground))).toBeGreaterThanOrEqual(90)
    }
  })

  it('ensureThemeContrast repairs matching white-on-white', () => {
    const fixed = ensureThemeContrast({
      ...themeForTemplate(getTemplateById('minimal-corporate')!),
      background: '#FFFFFF',
      foreground: '#FFFFFF',
    })
    expect(Math.abs(lum(fixed.background) - lum(fixed.foreground))).toBeGreaterThanOrEqual(90)
  })
})
