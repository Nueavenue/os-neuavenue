import { describe, expect, it } from 'vitest'
import { isAffirmative, isNegative, parseGuide } from './guide'

describe('parseGuide', () => {
  it('captures check-internet + browser + node install', () => {
    const plan = parseGuide('인터넷이 되는지 확인하고 브라우저를 띄워 node.js 설치를 부탁해')
    expect(plan).not.toBeNull()
    expect(plan?.wantsNet).toBe(true)
    expect(plan?.wantsBrowser).toBe(true)
    expect(plan?.browseUrl).toContain('nodejs.org')
    expect(plan?.installQuery).toMatch(/node/i)
    expect(plan?.confirm).toMatch(/yes or no/i)
  })

  it('ignores a single web request', () => {
    expect(parseGuide('인터넷 열어줘')).toBeNull()
  })
})

describe('confirm words', () => {
  it('hears yes and no', () => {
    expect(isAffirmative('네')).toBe(true)
    expect(isAffirmative('yes')).toBe(true)
    expect(isNegative('아니')).toBe(true)
    expect(isAffirmative('인터넷이 되는지 확인하고 브라우저를 띄워')).toBe(false)
  })
})
