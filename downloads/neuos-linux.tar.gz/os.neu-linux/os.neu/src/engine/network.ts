import type { NetworkState } from '../types'

const PROBE_URLS = [
  'https://www.gstatic.com/generate_204',
  'https://cloudflare.com/cdn-cgi/trace',
]

async function ping(url: string, ms: number): Promise<boolean> {
  const ctrl = new AbortController()
  const timer = window.setTimeout(() => ctrl.abort(), ms)
  try {
    await fetch(url, {
      method: 'GET',
      mode: 'no-cors',
      cache: 'no-store',
      signal: ctrl.signal,
    })
    return true
  } catch {
    return false
  } finally {
    window.clearTimeout(timer)
  }
}

export async function probeNetwork(): Promise<NetworkState> {
  const forced = new URLSearchParams(window.location.search).get('net')
  if (forced === 'off') {
    return { online: false, probed: true, label: 'Offline · local home' }
  }
  if (forced === 'on') {
    return { online: true, probed: true, label: 'Online' }
  }

  if (!navigator.onLine) {
    return { online: false, probed: true, label: 'Offline · local home' }
  }

  const hits = await Promise.all(PROBE_URLS.map((url) => ping(url, 2500)))
  const online = hits.some(Boolean)

  const conn = (navigator as Navigator & {
    connection?: { effectiveType?: string }
  }).connection

  if (!online) {
    return { online: false, probed: true, label: 'Offline · local home' }
  }

  const type = conn?.effectiveType
  return {
    online: true,
    probed: true,
    label: type ? `Online · ${type}` : 'Online',
  }
}
