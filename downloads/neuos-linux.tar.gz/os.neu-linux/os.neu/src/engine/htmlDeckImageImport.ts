/**
 * Image → HTML helpers (palette / regions / hybrid).
 * Production path: POST /api/office/image-to-html (Vision LLM or pack-original).
 * OCR not required — Vision rebuilds editable DOM; hybrid keeps screenshot underlay.
 * Browser runtime: public/html-deck/runtime.js
 */

export type ImageRegion = {
  left: number
  top: number
  width: number
  height: number
  contrast: number
  avg: string
  likelyText: boolean
  fontSize: number
}

export type ImageLayoutAnalysis = {
  width: number
  height: number
  background: string
  ink: string
  accent: string
  soft: string
  palette: string[]
  regions: ImageRegion[]
  fontFamily: string
}

export function rgbToHex(r: number, g: number, b: number): string {
  return (
    '#' +
    [r, g, b]
      .map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0'))
      .join('')
  )
}

/** Analyze raw RGBA buffer (e.g. 64×36 downsample). */
export function analyzeRgbaBuffer(
  data: Uint8ClampedArray | Uint8Array,
  W: number,
  H: number,
  meta?: { width?: number; height?: number },
): ImageLayoutAnalysis {
  const buckets = new Map<number, number>()
  let sumR = 0
  let sumG = 0
  let sumB = 0
  let n = 0
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const o = (y * W + x) * 4
      const r = data[o]
      const g = data[o + 1]
      const b = data[o + 2]
      const a = data[o + 3]
      if (a < 200) continue
      sumR += r
      sumG += g
      sumB += b
      n++
      const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)
      buckets.set(key, (buckets.get(key) || 0) + 1)
    }
  }
  const palette = [...buckets.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([key]) => {
      const r = ((key >> 8) & 0xf) * 17
      const g = ((key >> 4) & 0xf) * 17
      const b = (key & 0xf) * 17
      return rgbToHex(r, g, b)
    })
  const background = n ? rgbToHex(sumR / n, sumG / n, sumB / n) : '#ECE3D2'
  const regions: ImageRegion[] = []
  const bx = 4
  const by = 3
  for (let gy = 0; gy < by; gy++) {
    for (let gx = 0; gx < bx; gx++) {
      let minL = 255
      let maxL = 0
      let count = 0
      let sr = 0
      let sg = 0
      let sb = 0
      const x0 = Math.floor((gx * W) / bx)
      const x1 = Math.floor(((gx + 1) * W) / bx)
      const y0 = Math.floor((gy * H) / by)
      const y1 = Math.floor(((gy + 1) * H) / by)
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const o = (y * W + x) * 4
          const r = data[o]
          const g = data[o + 1]
          const b = data[o + 2]
          const L = 0.2126 * r + 0.7152 * g + 0.0722 * b
          minL = Math.min(minL, L)
          maxL = Math.max(maxL, L)
          sr += r
          sg += g
          sb += b
          count++
        }
      }
      const contrast = maxL - minL
      const height = Math.round((1 / by) * 1080)
      regions.push({
        left: Math.round((gx / bx) * 1920),
        top: Math.round((gy / by) * 1080),
        width: Math.round((1 / bx) * 1920),
        height,
        contrast,
        avg: count ? rgbToHex(sr / count, sg / count, sb / count) : background,
        likelyText: contrast > 28,
        fontSize: Math.max(18, Math.min(72, Math.round(height * 0.18))),
      })
    }
  }
  const ink = palette.find((c) => c.toLowerCase() !== background.toLowerCase()) || '#14181D'
  return {
    width: meta?.width || 1920,
    height: meta?.height || 1080,
    background,
    ink,
    accent: palette[1] || palette[0] || '#BC4F2B',
    soft: palette[2] || '#4A4D52',
    palette,
    regions: regions.filter((r) => r.likelyText).slice(0, 6),
    fontFamily: "Inter, 'Noto Sans KR', sans-serif",
  }
}

export function htmlFromImageAnalysis(analysis: ImageLayoutAnalysis, title = 'Imported slide'): string {
  const blocks = (analysis.regions.length
    ? analysis.regions
    : [
        {
          left: 96,
          top: 220,
          width: 1600,
          height: 200,
          fontSize: 64,
          avg: analysis.ink,
          likelyText: true,
          contrast: 40,
        },
      ]
  )
    .map((r, idx) => {
      const sample = idx === 0 ? title : `Region ${idx + 1} · edit text`
      return `<p style="position:absolute;left:${r.left}px;top:${r.top}px;width:${r.width}px;margin:0;font-size:${r.fontSize}px;font-weight:${idx === 0 ? 800 : 600};line-height:1.2;color:${analysis.ink};font-family:${analysis.fontFamily};">${sample.replace(/[<>]/g, '')}</p>`
    })
    .join('\n')
  const swatches = (analysis.palette || [])
    .map(
      (c, n) =>
        `<div style="position:absolute;left:${96 + n * 48}px;top:1000px;width:36px;height:36px;border-radius:6px;background:${c};border:1px solid rgba(0,0,0,.2);"></div>`,
    )
    .join('')
  return `<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8"><title>Image import</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+KR:wght@400;700;800&display=swap" rel="stylesheet">
<style>body{margin:0;overflow:hidden;background:${analysis.background};color:${analysis.ink};font-family:${analysis.fontFamily};}</style>
</head><body>
<div class="slide-container" data-import="image" style="position:relative;width:1920px;height:1080px;background:${analysis.background};">
  <div style="position:absolute;left:0;top:0;width:12px;height:1080px;background:${analysis.accent};"></div>
  <p style="position:absolute;left:96px;top:64px;margin:0;font-size:14px;font-weight:700;letter-spacing:.14em;color:${analysis.accent};">IMAGE → HTML · palette / regions</p>
  ${blocks}
  ${swatches}
  <p style="position:absolute;left:420px;top:1008px;margin:0;font-size:13px;color:${analysis.soft};">src ${analysis.width}×${analysis.height} · OCR 없음 · 좌표·색·크기 추정</p>
</div>
</body></html>`
}

/** Soft-sanitize HTML slide import (strip scripts; wrap fragment if needed). */
export function normalizeImportedHtml(raw: string): string {
  let html = String(raw || '').trim()
  if (!html) return ''
  html = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
  if (!/<html[\s>]/i.test(html) && /slide-container/i.test(html)) {
    html =
      '<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>Imported</title></head><body>' +
      html +
      '</body></html>'
  }
  if (!/<!DOCTYPE/i.test(html) && /<html/i.test(html)) {
    html = '<!DOCTYPE html>\n' + html
  }
  return html
}

export type FaithfulImageOpts = {
  dataUrl: string
  fileName?: string
  naturalWidth?: number
  naturalHeight?: number
  /** contain = no stretch (default when not ~16:9). fill only when aspect ~16:9. */
  fit?: 'contain' | 'cover' | 'fill'
}

/** Pixel-faithful slide: keep the bitmap; do not Vision-rewrite text/layout. */
export function faithfulImageSlideHtml(
  dataUrlOrOpts: string | FaithfulImageOpts,
  fileName?: string,
): string {
  const opts: FaithfulImageOpts =
    typeof dataUrlOrOpts === 'string'
      ? { dataUrl: dataUrlOrOpts, fileName }
      : dataUrlOrOpts
  const safe = String(opts.dataUrl || '').replace(/"/g, '')
  const label = String(opts.fileName || 'import').replace(/[<>]/g, '')
  const nw = Number(opts.naturalWidth) || 0
  const nh = Number(opts.naturalHeight) || 0
  const slideAr = 1920 / 1080
  const imgAr = nw > 0 && nh > 0 ? nw / nh : slideAr
  const near169 = Math.abs(imgAr - slideAr) / slideAr < 0.03
  const fit = opts.fit || (near169 ? 'fill' : 'contain')
  const imgStyle =
    fit === 'contain'
      ? 'position:absolute;left:0;top:0;right:0;bottom:0;margin:auto;max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;z-index:1;'
      : fit === 'cover'
        ? 'position:absolute;left:0;top:0;width:1920px;height:1080px;object-fit:cover;z-index:1;'
        : 'position:absolute;left:0;top:0;width:1920px;height:1080px;object-fit:fill;z-index:1;'
  return `<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>${label}</title>
<style>body{margin:0;overflow:hidden;background:#ECE3D2;}</style></head><body>
<div class="slide-container" data-import="faithful-image" data-fit="${fit}" data-object="true" data-object-type="shape" data-edit-id="r1"
 style="position:relative;width:1920px;height:1080px;overflow:hidden;background:#ECE3D2;">
<img alt="" src="${safe}" style="${imgStyle}" />
</div></body></html>`
}

export const IMAGE_HTML_FIDELITY_NOTE_KO =
  '뭉개지지 않으려면 Vision 재작성 금지 → 「이미지 그대로」(비트맵 contain/fill). 글자 Edit이 필요하면 HTML Import 또는 팩 원문.'
