import { describe, expect, it } from 'vitest'
import { addTopic, appendTopicItem, emptyTopicStore, itemsFor, normalizeTopicStore, renameTopic } from './seatTopics'

describe('seat topics', () => {
  it('always keeps the default start topic', () => {
    const store = normalizeTopicStore({ topics: [], activeId: 'gone', items: [] })
    expect(store.topics[0]).toMatchObject({ id: 'start', title: '시작' })
    expect(store.activeId).toBe('start')
  })

  it('lets the user add a topic and hang a history line on it', () => {
    let store = emptyTopicStore()
    store = addTopic(store, '출장')
    store = appendTopicItem(store, { ask: '포항 출장 메모', body: '일정 확인 필요', topicId: store.activeId })
    expect(store.topics.some((row) => row.title === '출장')).toBe(true)
    expect(itemsFor(store, store.activeId)[0]?.ask).toContain('포항')
  })

  it('renames a topic without dropping the default row', () => {
    let store = emptyTopicStore()
    store = renameTopic(store, 'start', '기본')
    expect(store.topics.some((row) => row.id === 'start' && row.title === '기본')).toBe(true)
  })
})
