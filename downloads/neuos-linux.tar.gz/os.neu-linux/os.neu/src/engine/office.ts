import { hostedAssistHeaders } from './hostedLlm'
import { askFirstSend, gateOfficeRequest, limitedReasonFromBridge, recordUsage } from './aiPrefs'
import { readyUiSessionHeaders } from './uiSession'
import { isCloudModel, officeModelList } from './cloudModels'
import { firstTextWaitMs } from './seatClient'
import { aiRequestTitle, logActivity } from './workspaceLog'

/** How long the Docs/Sheets stream may wait before the client aborts. Cloud is shorter. */
export function assistTimeoutMs(model: string): number {
  const wait = firstTextWaitMs(model)
  if (isCloudModel(model)) return Math.min(wait + 15_000, 135_000)
  return Math.min(wait + 30_000, 300_000)
}

async function officeHeaders(): Promise<HeadersInit> {
  const hosted =
    typeof location === 'undefined'
      ? { 'content-type': 'application/json' }
      : hostedAssistHeaders(location.hostname, typeof sessionStorage === 'undefined' ? null : sessionStorage)
  return readyUiSessionHeaders(hosted)
}

export type OfficeApp = 'sheet' | 'doc' | 'slides'

export const OFFICE_MODELS = officeModelList()

type AssistBody = {
  model: string
  app: OfficeApp
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
  /** The user's words for the activity log; not sent to the model. */
  title?: string
}

function askFirstSendDoc(vendor: string): boolean {
  return askFirstSend(vendor, '요청 문장과 문서 내용', 'your request and document text')
}

function requestChars(body: AssistBody) {
  const history = (body.history || []).reduce((n, row) => n + row.content.length, 0)
  return body.instruction.length + (body.content || '').length + (body.selection || '').length + history
}

function logAssist(body: AssistBody, outChars: number) {
  logActivity('ai.call', {
    app: body.app,
    model: body.model,
    title: aiRequestTitle(body.title || body.instruction),
    chars: requestChars(body) + outChars,
  })
}

export async function assistOffice(body: AssistBody) {
  const gate = gateOfficeRequest(body.model, askFirstSendDoc)
  if (!gate.ok) return { ok: false, reason: gate.reason } as { ok: boolean; text?: string; reason?: string; model?: string }
  const result = await postAssist(body)
  recordUsage(requestChars(body) + (result.text || '').length, true)
  logAssist(body, (result.text || '').length)
  return result
}

function wireBody(body: AssistBody): Omit<AssistBody, 'title'> {
  const { title: _title, ...rest } = body
  return rest
}

async function postAssist(body: AssistBody) {
  try {
    const res = await fetch('/api/office/assist', {
      method: 'POST',
      headers: await officeHeaders(),
      body: JSON.stringify(wireBody(body)),
      signal: AbortSignal.timeout(130_000),
    })
    const row = (await res.json()) as { ok: boolean; text?: string; reason?: string; model?: string; limit?: number }
    const limited = limitedReasonFromBridge(row)
    if (limited) return { ok: false, reason: limited }
    return row
  } catch (err) {
    const reason = err instanceof Error && err.name === 'TimeoutError' ? 'timeout' : 'network'
    return { ok: false, reason }
  }
}

export type AssistStreamChunk = {
  ok: boolean
  piece?: string
  full?: string
  done?: boolean
  reason?: string
  model?: string
  provider?: string
}

type AssistStreamResult = { ok: boolean; text: string; reason?: string }

async function fakeTypeStream(text: string, onChunk: (chunk: AssistStreamChunk) => void): Promise<AssistStreamResult> {
  const step = Math.max(1, Math.floor(text.length / 56))
  let full = ''
  for (let i = 0; i < text.length; i += step) {
    const piece = text.slice(i, i + step)
    full += piece
    onChunk({ ok: true, piece, full, done: i + step >= text.length })
    await new Promise((r) => window.setTimeout(r, 12))
  }
  return { ok: Boolean(full.trim()), text: full }
}

/** Prefer NDJSON stream; if bridge is old (404/not-found), fall back to one-shot + typing UX. */
export async function assistOfficeStream(
  body: AssistBody,
  onChunk: (chunk: AssistStreamChunk) => void,
  signal?: AbortSignal,
): Promise<AssistStreamResult> {
  const gate = gateOfficeRequest(body.model, askFirstSendDoc)
  if (!gate.ok) {
    onChunk({ ok: false, reason: gate.reason, done: true })
    return { ok: false, text: '', reason: gate.reason }
  }
  const result = await streamAssist(body, onChunk, signal)
  recordUsage(requestChars(body) + result.text.length, true)
  logAssist(body, result.text.length)
  return result
}

function assistSignal(model: string, signal?: AbortSignal) {
  const timeout = AbortSignal.timeout(assistTimeoutMs(model))
  if (!signal) return timeout
  const any = (AbortSignal as unknown as { any?: (list: AbortSignal[]) => AbortSignal }).any
  return typeof any === 'function' ? any([timeout, signal]) : signal
}

async function streamAssist(
  body: AssistBody,
  onChunk: (chunk: AssistStreamChunk) => void,
  signal?: AbortSignal,
): Promise<AssistStreamResult> {
  const combined = assistSignal(body.model, signal)
  let res: Response
  try {
    res = await fetch('/api/office/assist/stream', {
      method: 'POST',
      headers: await officeHeaders(),
      body: JSON.stringify(wireBody(body)),
      signal: combined,
    })
  } catch (err) {
    const aborted = err instanceof Error && err.name === 'AbortError'
    const reason = aborted ? 'aborted' : err instanceof Error && err.name === 'TimeoutError' ? 'timeout' : 'network'
    onChunk({ ok: false, reason, done: true })
    return { ok: false, text: '', reason }
  }

  const contentType = res.headers.get('content-type') || ''
  if (!res.ok || contentType.includes('application/json')) {
    const fail = (await res.json().catch(() => ({}))) as { reason?: string; ok?: boolean; text?: string; limit?: number }
    const limited = limitedReasonFromBridge(fail)
    const reason = limited || fail.reason || `http-${res.status}`
    if (reason === 'not-found' || res.status === 404) {
      const oneshot = await postAssist(body)
      if (!oneshot.ok || !oneshot.text) {
        onChunk({ ok: false, reason: oneshot.reason || reason, done: true })
        return { ok: false, text: '', reason: oneshot.reason || reason }
      }
      return fakeTypeStream(oneshot.text, onChunk)
    }
    onChunk({ ok: false, reason, done: true })
    return { ok: false, text: '', reason }
  }

  if (!res.body) {
    onChunk({ ok: false, reason: 'no-body', done: true })
    return { ok: false, text: '', reason: 'no-body' }
  }

  const reader = res.body.getReader()
  const onAbort = () => {
    void reader.cancel().catch(() => undefined)
  }
  if (combined.aborted || signal?.aborted) onAbort()
  combined.addEventListener('abort', onAbort)
  signal?.addEventListener('abort', onAbort)
  const decoder = new TextDecoder()
  let buf = ''
  let full = ''
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      buf += decoder.decode(value, { stream: true })
      const lines = buf.split('\n')
      buf = lines.pop() || ''
      for (const line of lines) {
        const raw = line.trim()
        if (!raw) continue
        try {
          const row = JSON.parse(raw) as AssistStreamChunk
          if (row.full) full = row.full
          else if (row.piece) full += row.piece
          onChunk({ ...row, full })
          if (row.ok === false && row.done) {
            return { ok: false, text: full, reason: row.reason || 'assist-error' }
          }
        } catch {
          /* skip */
        }
      }
    }
  } catch (err) {
    const aborted = err instanceof Error && (err.name === 'AbortError' || combined.aborted || signal?.aborted)
    if (aborted) {
      onChunk({ ok: false, reason: 'aborted', done: true })
      return { ok: false, text: full, reason: 'aborted' }
    }
    onChunk({ ok: false, reason: 'network', done: true })
    return { ok: false, text: full, reason: 'network' }
  } finally {
    combined.removeEventListener('abort', onAbort)
    signal?.removeEventListener('abort', onAbort)
  }
  return { ok: Boolean(full.trim()), text: full }
}
