export const OFFICE_MODELS = [
  { id: 'os.neu-local', label: 'os.neu 공개 AI' },
  { id: 'gpt-4o-mini', label: 'GPT-4o mini' },
  { id: 'gpt-4o', label: 'GPT-4o' },
  { id: 'gpt-4.1-mini', label: 'GPT-4.1 mini' },
  { id: 'gpt-4.1', label: 'GPT-4.1' },
] as const

export type OfficeApp = 'sheet' | 'doc' | 'slides'

export async function assistOffice(body: {
  model: string
  app: OfficeApp
  instruction: string
  content?: string
}) {
  const res = await fetch('/api/office/assist', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  return (await res.json()) as { ok: boolean; text?: string; reason?: string; model?: string }
}
