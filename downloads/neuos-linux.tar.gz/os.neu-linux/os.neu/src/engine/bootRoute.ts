import type { Phase } from '../types'

const QUERY_PHASES: Phase[] = [
  'lui',
  'landing',
  'studio',
  'post',
  'workspace',
  'network',
  'install',
  'jeos',
  'announce',
  'plant',
  'admin',
]

export function phaseFromQuery(go: string | null): Phase | null {
  if (!go) return null
  return QUERY_PHASES.includes(go as Phase) ? (go as Phase) : null
}

/** Splash-only auto-advance. Later screens must not be yanked back. */
export function bootAfterSplash(planted: boolean): Phase {
  return planted ? 'post' : 'install'
}

export function shouldRunBootTimer(phase: Phase): boolean {
  return phase === 'splash'
}
