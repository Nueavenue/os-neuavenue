import { describe, expect, it } from 'vitest'
import { composeSeatInstruction } from './promptSearch'
import { firstTextWaitMs, seatErrorKo } from './seatClient'
import { aiRequestTitle } from './workspaceLog'

describe('aiRequestTitle', () => {
  it('shows the user request, not the composed prompt', () => {
    const composed = composeSeatInstruction('Compare three note apps for my team', null)
    expect(composed).toMatch(/^User language:/)
    expect(aiRequestTitle(composed)).toBe('Compare three note apps for my team')
  })

  it('reads rows that were stored on one line', () => {
    const flat = 'User language: en Words: compare · note · apps Ask: Compare three note apps Search engine: wiki Search URL: x'
    expect(aiRequestTitle(flat)).toBe('Compare three note apps')
  })

  it('falls back to the words when the stored row was cut before Ask', () => {
    expect(aiRequestTitle('User language: mixed Words: 보고서 · 작성')).toBe('보고서 작성')
  })

  it('drops the office tail and keeps plain requests as they are', () => {
    const office = 'Write a memo\n\nWrite the draft from this request only. Do not claim you opened a browser.'
    expect(aiRequestTitle(office)).toBe('Write a memo')
    expect(aiRequestTitle('Make a budget table')).toBe('Make a budget table')
  })

  it('keeps titles short', () => {
    const title = aiRequestTitle('a'.repeat(200))
    expect(title.length).toBe(60)
    expect(title.endsWith('…')).toBe(true)
  })
})

describe('firstTextWaitMs', () => {
  it('gives cloud and local models more than 20 seconds', () => {
    expect(firstTextWaitMs('gpt-4o-mini')).toBe(120_000)
    expect(firstTextWaitMs('os.neu-local')).toBe(90_000)
    expect(firstTextWaitMs('llama3.2:1b')).toBe(90_000)
    expect(firstTextWaitMs('qwen2.5:7b')).toBe(180_000)
  })

  it('names the real wait in the stop message', () => {
    expect(seatErrorKo('first-token-timeout', false, 120)).toContain('120 seconds')
    expect(seatErrorKo('first-token-timeout', true, 90)).toContain('90초')
    expect(seatErrorKo('openai-timeout', true)).toContain('클라우드')
    expect(seatErrorKo('openai-401', false)).toContain('OpenAI')
    expect(seatErrorKo('openai-429', true)).toContain('429')
    expect(seatErrorKo('openai-429', true)).toContain('os.neu-local')
    expect(seatErrorKo('google-404', true)).toContain('404')
    expect(seatErrorKo('google-404', false)).toContain('gemini-4-argon')
    expect(seatErrorKo('google-429', true)).toContain('429')
    expect(seatErrorKo('google-429', false)).toContain('quota')
    expect(seatErrorKo('google-429', true)).toContain('os.neu-local')
  })
})
