import { describe, expect, it } from 'vitest'
import { seatIdentity } from './seatIdentity'
import { seatPolicy } from './seatPolicy'
import { composeSeatFile, finishSeat, judgeSeatText, prepareSeat, releaseGate } from './seatRun'

const memo = '포항 출장 준비해주고 여행지 구매 출장 메모해줘'
const report = '이번 달 사업 현황을 분석해서 투자자 보고서를 준비해줘'

describe('seat identity and policy', () => {
  it('does not pretend a mailbox is a supabase id', () => {
    const id = seatIdentity({ account: { name: 'A', email: 'a@b.c', admin: false }, authUserId: null })
    expect(id.kind).toBe('local-or-unknown')
    if (id.kind === 'local-or-unknown') expect(id.reason).toContain('auth.users.id')
  })

  it('keeps a caller-supplied auth user id', () => {
    const id = seatIdentity({ account: { name: 'A', email: 'a@b.c', admin: false }, authUserId: 'user-1' })
    expect(id).toMatchObject({ kind: 'supabase', authUserId: 'user-1' })
  })

  it('allows a file and refuses the web unless asked', () => {
    expect(seatPolicy({ docWrite: true })['doc.write']).toBe(true)
    expect(seatPolicy({ docWrite: true })['browser.open-url']).toBe(false)
    expect(seatPolicy()['doc.write']).toBe(false)
  })
})

describe('seat ten steps', () => {
  it('stops a research sentence before any model call', () => {
    const prepared = prepareSeat({
      text: report,
      model: 'gemma2:9b',
      account: null,
      phase: 'lui',
      online: true,
    })
    expect(prepared.gate).toBe('web')
    expect(prepared.steps.find((row) => row.n === 3)?.status).toBe('wait')
    expect(prepared.steps.find((row) => row.n === 6)?.status).toBe('pending')
    expect(prepared.steps.find((row) => row.n === 2)?.detail).toContain('없습니다')
  })

  it('parses a factual Korean ask into words and keeps search unblocked', () => {
    const prepared = prepareSeat({
      text: '국내에서 사과 종류가 몇 개나 있어요?',
      model: 'gpt-4.1',
      account: null,
      phase: 'lui',
      online: true,
      webHref: 'https://searx.be/search?q=%EC%82%AC%EA%B3%BC',
    })
    expect(prepared.gate).toBeNull()
    expect(prepared.steps.find((row) => row.n === 1)?.detail).toContain('사과')
    expect(prepared.steps.find((row) => row.n === 3)?.detail).toContain('검색')
  })

  it('lets a memo pass permission without opening the web', () => {
    const prepared = prepareSeat({
      text: memo,
      model: 'gemma2:9b',
      account: { name: 'B', email: 'b@c.d', admin: false },
      phase: 'lui',
      online: true,
    })
    expect(prepared.gate).toBeNull()
    expect(prepared.policy['browser.open-url']).toBe(false)
    expect(prepared.steps.find((row) => row.n === 5)?.status).toBe('ok')
  })

  it('fails closed when the user stops at permission', () => {
    const prepared = prepareSeat({
      text: report,
      model: 'gemma2:9b',
      account: null,
      phase: 'lui',
      online: false,
    })
    const stopped = releaseGate(prepared, 'stop')
    const done = finishSeat(stopped, { body: '' })
    expect(done.find((row) => row.n === 6)?.status).toBe('fail')
    expect(done.find((row) => row.n === 9)?.detail).toContain('만들지 않습니다')
    expect(done.find((row) => row.n === 10)?.detail).toContain('웹을 보지 않음')
  })

  it('marks invented money and repeated blocks as verify failures', () => {
    const block = '* 포항 출장 준비\n+ 일자: [Insert Date]\n+ 출장지: 포항시\n+ 출장비: [Insert Amount]'
    expect(judgeSeatText(memo, `${block}\n${block}`).ok).toBe(false)
    expect(judgeSeatText(memo, '숙박 12만원').ok).toBe(false)
    expect(judgeSeatText(memo, '일정은 확인 필요').ok).toBe(true)
  })

  it('writes the full text into the file with the plan and the verdict', () => {
    const prepared = prepareSeat({
      text: memo,
      model: 'gemma2:9b',
      account: null,
      phase: 'lui',
      online: true,
    })
    const body = '첫 줄\n둘째 줄은 길어도 잘리지 않는다.'
    const steps = finishSeat(prepared, { body })
    const file = composeSeatFile({
      request: memo,
      body,
      plan: prepared.plan,
      verdict: steps.find((row) => row.n === 7)?.detail || '',
      evidence: steps.find((row) => row.n === 10)?.detail || '',
    })
    expect(file).toContain(body)
    expect(file).toContain('웹을 보지 않음')
    expect(file).toContain('계획')
    expect(steps.find((row) => row.n === 8)?.detail).toContain('메일')
  })
})
