const SESSION_KEY = 'os.neu.session'
const TOKEN_KEY = 'os.neu.token'

export type AuthUser = {
  name: string
  email: string
  admin: boolean
}

export function sessionId() {
  let id = localStorage.getItem(SESSION_KEY)
  if (!id) {
    id = `s-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    localStorage.setItem(SESSION_KEY, id)
  }
  return id
}

export function readToken() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

function headers() {
  const token = readToken()
  return {
    'content-type': 'application/json',
    ...(token ? { 'x-osneu-token': token } : {}),
  }
}

export async function trackEvent(kind: 'view' | 'click' | 'login' | 'logout' | 'open-app' | 'feedback', screen: string, label?: string) {
  try {
    await fetch('/api/track', {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ session: sessionId(), kind, screen, label }),
    })
  } catch {
    /* tracking is best-effort */
  }
}

export async function loginRequest(email: string, password: string) {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  const body = (await res.json()) as { ok: boolean; token?: string; user?: AuthUser; reason?: string }
  if (body.ok && body.token && body.user) localStorage.setItem(TOKEN_KEY, body.token)
  return body
}

export async function registerRequest(name: string, email: string, password: string) {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  })
  const body = (await res.json()) as {
    ok: boolean
    token?: string
    user?: AuthUser
    reason?: string
    needsConfirm?: boolean
  }
  if (body.ok && body.token && body.user) localStorage.setItem(TOKEN_KEY, body.token)
  return body
}

export async function logoutRequest() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', headers: headers() })
  } finally {
    localStorage.removeItem(TOKEN_KEY)
  }
}

export async function fetchMe() {
  const token = readToken()
  if (!token) return null
  const res = await fetch('/api/auth/me', { headers: headers() })
  const body = (await res.json()) as { ok: boolean; user?: AuthUser | null }
  return body.user ?? null
}

export async function sendFeedback(title: string, body: string) {
  const res = await fetch('/api/feedback', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ title, body }),
  })
  return (await res.json()) as { ok: boolean; reason?: string; cloud?: boolean }
}

export async function fetchAdminStats() {
  const res = await fetch('/api/admin/stats', { headers: headers() })
  return res.json() as Promise<Record<string, unknown>>
}
