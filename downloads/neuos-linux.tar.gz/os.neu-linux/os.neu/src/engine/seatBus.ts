import type { SeatAccount } from './seatIdentity'

export type SeatAsk = {
  text: string
  model: string
  account: SeatAccount | null
  phase: string
  online: boolean
  fileId: string | null
  webHref: string | null
}

type Listener = (ask: SeatAsk) => void
type AbortFn = () => void

let listener: Listener | null = null
let abortFn: AbortFn | null = null

export function bindSeatListener(fn: Listener) {
  listener = fn
  return () => {
    if (listener === fn) listener = null
  }
}

/** SeatRunPanel registers the live AbortController so Docs/Sheets Stop can cut the run. */
export function bindSeatAbort(fn: AbortFn) {
  abortFn = fn
  return () => {
    if (abortFn === fn) abortFn = null
  }
}

export function requestSeatRun(ask: SeatAsk) {
  listener?.(ask)
}

/** Stop a seat write that is filling Docs/Sheets/Slides (the in-app Stop button). */
export function abortSeatRun() {
  abortFn?.()
}
