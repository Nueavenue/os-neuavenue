/**
 * Region-based HTML slide editing — select one data-object / tagged box, patch only that node.
 */

export type RegionKind = 'textbox' | 'shape' | 'other'

export type SlideRegion = {
  id: string
  kind: RegionKind
  label: string
  text: string
  fontSize?: string
  color?: string
  fontWeight?: string
  fontFamily?: string
  left?: string
  top?: string
  width?: string
  height?: string
  background?: string
}

export type RegionPatch = {
  id: string
  text?: string
  fontSize?: string
  color?: string
  fontWeight?: string
  fontFamily?: string
  left?: string
  top?: string
  width?: string
  height?: string
  background?: string
}

function stripTags(html: string): string {
  return String(html || '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

function styleProp(style: string, name: string): string | undefined {
  const re = new RegExp('(?:^|;)\\s*' + name + '\\s*:\\s*([^;]+)', 'i')
  const m = String(style || '').match(re)
  return m ? m[1].trim() : undefined
}

function firstTextStyle(inner: string): { fontSize?: string; color?: string; fontWeight?: string; fontFamily?: string } {
  const m = inner.match(/style\s*=\s*"([^"]*)"/i) || inner.match(/style\s*=\s*'([^']*)'/i)
  if (!m) return {}
  const s = m[1]
  return {
    fontSize: styleProp(s, 'font-size'),
    color: styleProp(s, 'color'),
    fontWeight: styleProp(s, 'font-weight'),
    fontFamily: styleProp(s, 'font-family'),
  }
}

/** Ensure every editable box has a stable data-edit-id (idempotent). */
export function ensureRegionIdsInHtml(html: string): string {
  if (typeof document !== 'undefined') {
    // Browser path uses DOM; this string path is for Node tests / SSR-less apply
  }
  let i = 0
  return html.replace(/<div([^>]*data-object\s*=\s*["']true["'][^>]*)>/gi, (full, attrs) => {
    if (/data-edit-id\s*=/i.test(attrs)) return full
    i += 1
    const id = 'r' + i
    return `<div${attrs} data-edit-id="${id}">`
  })
}

/**
 * Lightweight HTML parse without DOMParser — extract region metadata from data-object divs.
 */
export function listRegionsFromHtml(html: string): SlideRegion[] {
  const tagged = ensureRegionIdsInHtml(html)
  const regions: SlideRegion[] = []
  const openRe = /<div([^>]*\bdata-object\s*=\s*["']true["'][^>]*)>/gi
  let m: RegExpExecArray | null
  const opens: { attrs: string; index: number; end: number }[] = []
  while ((m = openRe.exec(tagged))) {
    opens.push({ attrs: m[1], index: m.index, end: m.index + m[0].length })
  }
  for (let n = 0; n < opens.length; n++) {
    const start = opens[n].end
    const stop = n + 1 < opens.length ? opens[n + 1].index : tagged.length
    let chunk = tagged.slice(start, stop)
    // trim trailing outer closers roughly
    chunk = chunk.replace(/(<\/div>\s*)+$/i, '')
    const attrs = opens[n].attrs
    let id = (attrs.match(/data-edit-id\s*=\s*["']([^"']+)["']/i) || [])[1]
    if (!id) id = 'r' + (n + 1)
    const type = ((attrs.match(/data-object-type\s*=\s*["']([^"']+)["']/i) || [])[1] || 'other').toLowerCase()
    const kind: RegionKind = type === 'textbox' ? 'textbox' : type === 'shape' ? 'shape' : 'other'
    const style = (attrs.match(/style\s*=\s*"([^"]*)"/i) || attrs.match(/style\s*=\s*'([^']*)'/i) || [])[1] || ''
    const textStyle = firstTextStyle(chunk)
    const text = stripTags(chunk)
    const elId = (attrs.match(/\bid\s*=\s*["']([^"']+)["']/i) || [])[1]
    regions.push({
      id,
      kind,
      label: elId || (kind === 'textbox' ? `Text ${n + 1}` : kind === 'shape' ? `Shape ${n + 1}` : `Region ${n + 1}`),
      text,
      fontSize: textStyle.fontSize || styleProp(style, 'font-size'),
      color: textStyle.color || styleProp(style, 'color'),
      fontWeight: textStyle.fontWeight || styleProp(style, 'font-weight'),
      fontFamily: textStyle.fontFamily || styleProp(style, 'font-family'),
      left: styleProp(style, 'left'),
      top: styleProp(style, 'top'),
      width: styleProp(style, 'width'),
      height: styleProp(style, 'height'),
      background: styleProp(style, 'background') || styleProp(style, 'background-color'),
    })
  }
  return regions
}

function setStyleProp(style: string, name: string, value: string | undefined): string {
  const parts = String(style || '')
    .split(';')
    .map((p) => p.trim())
    .filter(Boolean)
    .filter((p) => !new RegExp('^' + name + '\\s*:', 'i').test(p))
  if (value != null && String(value).trim() !== '') parts.push(name + ': ' + String(value).trim())
  return parts.join('; ') + (parts.length ? ';' : '')
}

/**
 * Apply a region patch to HTML string. Only the matching data-edit-id (or nth data-object) changes.
 */
export function applyRegionPatchToHtml(html: string, patch: RegionPatch): string {
  const tagged = ensureRegionIdsInHtml(html)
  const openRe = /<div([^>]*\bdata-object\s*=\s*["']true["'][^>]*)>/gi
  const opens: { full: string; attrs: string; index: number; end: number }[] = []
  let m: RegExpExecArray | null
  while ((m = openRe.exec(tagged))) {
    opens.push({ full: m[0], attrs: m[1], index: m.index, end: m.index + m[0].length })
  }
  const idx = opens.findIndex((o) => {
    const id = (o.attrs.match(/data-edit-id\s*=\s*["']([^"']+)["']/i) || [])[1]
    return id === patch.id
  })
  if (idx < 0) return tagged

  const start = opens[idx].index
  const contentStart = opens[idx].end
  const contentEnd = idx + 1 < opens.length ? opens[idx + 1].index : tagged.lastIndexOf('</div>')
  // Find the closing div for this block: naive — take until next data-object or before </body>
  let end = contentEnd
  if (idx + 1 < opens.length) end = opens[idx + 1].index
  else {
    const bodyClose = tagged.lastIndexOf('</body>')
    end = bodyClose > contentStart ? bodyClose : tagged.length
  }

  let block = tagged.slice(start, end)
  // Update outer style
  block = block.replace(/^(<div)([^>]*)(>)/i, (_, a, attrs, c) => {
    let style = (attrs.match(/style\s*=\s*"([^"]*)"/i) || attrs.match(/style\s*=\s*'([^']*)'/i) || [])[1] || ''
    if (patch.left != null) style = setStyleProp(style, 'left', patch.left)
    if (patch.top != null) style = setStyleProp(style, 'top', patch.top)
    if (patch.width != null) style = setStyleProp(style, 'width', patch.width)
    if (patch.height != null) style = setStyleProp(style, 'height', patch.height)
    if (patch.background != null) style = setStyleProp(style, 'background', patch.background)
    let next = attrs
    if (/style\s*=/i.test(next)) {
      next = next.replace(/style\s*=\s*"[^"]*"/i, `style="${style}"`).replace(/style\s*=\s*'[^']*'/i, `style="${style}"`)
    } else {
      next += ` style="${style}"`
    }
    if (!/data-edit-id\s*=/i.test(next)) next += ` data-edit-id="${patch.id}"`
    return a + next + c
  })

  if (patch.text != null) {
    const type = ((opens[idx].attrs.match(/data-object-type\s*=\s*["']([^"']+)["']/i) || [])[1] || '').toLowerCase()
    if (type !== 'shape') {
      const safe = String(patch.text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>')
      const fs = patch.fontSize || '24px'
      const color = patch.color || 'var(--ink)'
      const fw = patch.fontWeight || '600'
      const ff = patch.fontFamily || "Inter, 'Noto Sans KR', sans-serif"
      // Replace inner content after first >
      block = block.replace(
        /^(<div[^>]*>)([\s\S]*)$/i,
        `$1<p style="margin:0;font-size:${fs};color:${color};font-weight:${fw};font-family:${ff};line-height:1.35;">${safe}</p>`,
      )
    }
  } else if (patch.fontSize || patch.color || patch.fontWeight || patch.fontFamily) {
    // Patch first inner style= on p/h1/span
    block = block.replace(/style\s*=\s*"([^"]*)"/i, (_all, s) => {
      let style = s
      if (patch.fontSize) style = setStyleProp(style, 'font-size', patch.fontSize)
      if (patch.color) style = setStyleProp(style, 'color', patch.color)
      if (patch.fontWeight) style = setStyleProp(style, 'font-weight', patch.fontWeight)
      if (patch.fontFamily) style = setStyleProp(style, 'font-family', patch.fontFamily)
      return `style="${style}"`
    })
  }

  return tagged.slice(0, start) + block + tagged.slice(end)
}

export const REGION_EDIT_GUIDE_KO = [
  'Edit 모드 ON → 슬라이드에서 영역 클릭',
  '오른쪽 패널에서 해당 영역 글씨·폰트·색만 수정',
  '영역 적용 → 그 박스만 저장 (전체 재작성 아님)',
].join(' · ')
