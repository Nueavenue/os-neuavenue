/** Lightweight exports — no extra npm packages. */

import { buildZip } from './zip'

export function toPlainText(title: string, body: string) {
  return `${title.trim()}\n\n${body.trim()}\n`
}

function xmlEsc(s: string) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/** Minimal OOXML .docx (title + body paragraphs). */
export function toDocx(title: string, body: string): Uint8Array {
  const paras = [`${title.trim()}`, '', ...body.replace(/\r\n/g, '\n').split('\n')]
    .slice(0, 200)
    .map((line, i) => {
      const text = xmlEsc(line || ' ')
      const bold = i === 0 && title.trim() ? '<w:rPr><w:b/></w:rPr>' : ''
      return `<w:p><w:r>${bold}<w:t xml:space="preserve">${text}</w:t></w:r></w:p>`
    })
    .join('')
  const documentXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
    `<w:body>${paras}<w:sectPr/></w:body></w:document>`
  const contentTypes =
    `<?xml version="1.0" encoding="UTF-8"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>` +
    `</Types>`
  const rels =
    `<?xml version="1.0" encoding="UTF-8"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>` +
    `</Relationships>`
  const enc = new TextEncoder()
  return buildZip([
    { name: '[Content_Types].xml', data: enc.encode(contentTypes) },
    { name: '_rels/.rels', data: enc.encode(rels) },
    { name: 'word/document.xml', data: enc.encode(documentXml) },
  ])
}

export function toMarkdown(title: string, body: string) {
  const heading = title.trim() ? `# ${title.trim()}\n\n` : ''
  return `${heading}${body.trim()}\n`
}

export function toRtf(title: string, body: string) {
  const esc = (s: string) =>
    s
      .replace(/\\/g, '\\\\')
      .replace(/\{/g, '\\{')
      .replace(/\}/g, '\\}')
      .replace(/\n/g, '\\par\n')
  return `{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Arial;}}\\f0\\fs24\\b ${esc(title)}\\b0\\par\\par ${esc(body)}}`
}

/** Minimal single-page PDF with Helvetica text lines. */
export function toPdf(title: string, body: string) {
  const lines = [`${title}`, '', ...body.split(/\n/).slice(0, 48)]
  const escaped = lines.map((line) =>
    line.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)').slice(0, 96),
  )
  const cmds = ['BT', '/F1 12 Tf', '50 780 Td', '14 TL']
  escaped.forEach((line, i) => {
    if (i === 0) cmds.push(`(${line}) Tj`, 'T*', '/F1 11 Tf')
    else cmds.push(`(${line || ' '}) Tj`, 'T*')
  })
  cmds.push('ET')
  const stream = cmds.join('\n')
  const objects = [
    '1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj\n',
    '2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj\n',
    '3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources<< /Font<< /F1 5 0 R >> >> >>endobj\n',
    `4 0 obj<< /Length ${stream.length} >>stream\n${stream}\nendstream\nendobj\n`,
    '5 0 obj<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>endobj\n',
  ]
  let pdf = '%PDF-1.4\n'
  const offsets = [0]
  const byteLen = (s: string) => new TextEncoder().encode(s).length
  for (const obj of objects) {
    offsets.push(byteLen(pdf))
    pdf += obj
  }
  const xref = offsets.length - 1
  const startxref = byteLen(pdf)
  pdf += `xref\n0 ${xref + 1}\n`
  pdf += '0000000000 65535 f \n'
  for (let i = 1; i <= xref; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`
  }
  pdf += `trailer<< /Size ${xref + 1} /Root 1 0 R >>\nstartxref\n${startxref}\n%%EOF`
  return pdf
}

export type DocSaveFormat = 'txt' | 'md' | 'rtf' | 'pdf' | 'docx'

export async function saveDocumentFile(opts: {
  title: string
  body: string
  format: DocSaveFormat
}) {
  const base = (opts.title || 'document').replace(/[^\w\- .]+/g, '_').slice(0, 60) || 'document'
  if (opts.format === 'docx') {
    const bytes = toDocx(opts.title, opts.body)
    const name = `${base}.docx`
    const mime = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    if (window.neuos?.files?.save) {
      return window.neuos.files.save({
        defaultPath: name,
        mime,
        bytes: Array.from(bytes),
        filters: [{ name: 'Word', extensions: ['docx'] }],
      })
    }
    const blob = new Blob([Uint8Array.from(bytes)], { type: mime })
    const href = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    a.download = name
    a.click()
    URL.revokeObjectURL(href)
    return { ok: true, via: 'download' as const }
  }

  const payload =
    opts.format === 'pdf'
      ? { name: `${base}.pdf`, mime: 'application/pdf', text: toPdf(opts.title, opts.body), binary: true }
      : opts.format === 'rtf'
        ? {
            name: `${base}.rtf`,
            mime: 'application/rtf',
            text: toRtf(opts.title, opts.body),
            binary: false,
          }
        : opts.format === 'md'
          ? {
              name: `${base}.md`,
              mime: 'text/markdown;charset=utf-8',
              text: toMarkdown(opts.title, opts.body),
              binary: false,
            }
          : {
              name: `${base}.txt`,
              mime: 'text/plain;charset=utf-8',
              text: toPlainText(opts.title, opts.body),
              binary: false,
            }

  if (window.neuos?.files?.save) {
    const bytes = payload.binary
      ? Array.from(new TextEncoder().encode(payload.text))
      : undefined
    return window.neuos.files.save({
      defaultPath: payload.name,
      mime: payload.mime,
      text: payload.binary ? undefined : payload.text,
      bytes,
      filters:
        opts.format === 'pdf'
          ? [{ name: 'PDF', extensions: ['pdf'] }]
          : opts.format === 'rtf'
            ? [{ name: 'Word-compatible RTF', extensions: ['rtf'] }]
            : opts.format === 'md'
              ? [{ name: 'Markdown', extensions: ['md'] }]
              : [{ name: 'Text', extensions: ['txt'] }],
    })
  }

  const blob = new Blob([payload.text], { type: payload.mime })
  const href = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = href
  a.download = payload.name
  a.click()
  URL.revokeObjectURL(href)
  return { ok: true, via: 'download' as const }
}
