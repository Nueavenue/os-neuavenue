/**
 * HTML deck — insert a new slide after a target (Agent prompt + Apply).
 */

export type InsertIntent = {
  type: 'insert-after'
  /** 0-based index to insert after (−1 = before first). */
  afterIndex: number
  title?: string
  reason: string
}

export type SlideRef = { id: string; label: string; file?: string }

/** Resolve "04", "4번", label keywords against current slides. */
export function resolveSlideIndex(token: string, slides: SlideRef[]): number {
  const raw = String(token || '').trim()
  if (!raw || !slides.length) return -1
  const num = raw.match(/^0*(\d+)/)
  if (num) {
    const n = Number(num[1]) - 1
    if (n >= 0 && n < slides.length) return n
  }
  const lower = raw.toLowerCase()
  const hit = slides.findIndex(
    (s) =>
      s.id === raw ||
      s.id.includes(raw) ||
      String(s.file || '').includes(raw) ||
      s.label.includes(raw) ||
      s.label.toLowerCase().includes(lower),
  )
  return hit
}

/**
 * Examples:
 * - "04 새로운 카테고리 슬라이드에 다음 장 추가"
 * - "4번 다음에 새 슬라이드 추가"
 * - "현재 장 다음에 추가"
 * - "insert slide after 4"
 */
export function parseInsertIntent(
  instruction: string,
  slides: SlideRef[],
  currentIndex = 0,
): InsertIntent | null {
  const text = String(instruction || '').trim()
  if (!text || !slides.length) return null
  if (!/(추가|insert|add\s+(a\s+)?slide|새\s*슬라이드|다음\s*장)/i.test(text)) return null
  // Exclude pure reorder moves
  if (/이동|reorder|순서\s*정렬|자동\s*순서/i.test(text) && !/추가|insert|add/i.test(text)) return null

  let title: string | undefined
  const titleM = text.match(/(?:제목|title)\s*[:：]\s*[「"']?([^」"'\n]+)[」"']?/i)
  if (titleM) title = titleM[1].trim().slice(0, 80)

  // "현재 / 이 장 / this slide 다음"
  if (/현재\s*(장|슬라이드)|이\s*(장|슬라이드)|this\s*slide|선택\s*슬라이드/i.test(text) && /다음|after|뒤에/i.test(text)) {
    return {
      type: 'insert-after',
      afterIndex: Math.max(0, Math.min(slides.length - 1, currentIndex)),
      title,
      reason: 'insert after current',
    }
  }

  // "04 … 다음 장 추가" / "4번 다음에 추가"
  const afterNum = text.match(
    /(?:^|\s)0*(\d+)\s*(?:번)?[\s\S]{0,48}?(?:에\s*)?(?:다음|뒤)(?:\s*장)?\s*(?:에\s*)?(?:새\s*)?(?:슬라이드\s*)?추가/,
  )
  if (afterNum) {
    const idx = Number(afterNum[1]) - 1
    if (idx >= 0 && idx < slides.length) {
      return { type: 'insert-after', afterIndex: idx, title, reason: `insert after #${idx + 1}` }
    }
  }

  const afterEn = text.match(/insert\s+(?:a\s+)?slide\s+after\s+(\d+)/i)
  if (afterEn) {
    const idx = Number(afterEn[1]) - 1
    if (idx >= 0 && idx < slides.length) {
      return { type: 'insert-after', afterIndex: idx, title, reason: `insert after #${idx + 1}` }
    }
  }

  // Label keyword before "다음 장 추가" — e.g. "새로운 카테고리 슬라이드에 다음 장 추가"
  const labelAfter = text.match(
    /[「"']?([^」"'\n]{2,40}?)[」"']?\s*(?:슬라이드|장)?\s*(?:에\s*)?(?:다음|뒤)(?:\s*장)?\s*(?:에\s*)?(?:새\s*)?(?:슬라이드\s*)?추가/,
  )
  if (labelAfter) {
    const tok = labelAfter[1].replace(/^0*\d+\s*/, '').trim()
    const idx = resolveSlideIndex(tok, slides)
    if (idx >= 0) {
      return { type: 'insert-after', afterIndex: idx, title, reason: `insert after ${slides[idx].id}` }
    }
    // leading number still in tok path
    const n = labelAfter[1].match(/^0*(\d+)/)
    if (n) {
      const i = Number(n[1]) - 1
      if (i >= 0 && i < slides.length) {
        return { type: 'insert-after', afterIndex: i, title, reason: `insert after #${i + 1}` }
      }
    }
  }

  // Bare "다음 장 추가" / "새 슬라이드 추가" → after current
  if (/^(?:새\s*)?(?:슬라이드|장)\s*추가$|다음\s*장\s*추가|add\s+slide\s+here/i.test(text)) {
    return {
      type: 'insert-after',
      afterIndex: Math.max(0, Math.min(slides.length - 1, currentIndex)),
      title,
      reason: 'insert after current (bare)',
    }
  }

  return null
}

export function blankPaperSlideHtml(opts: {
  title?: string
  packTitle?: string
  accent?: string
  paper?: string
  ink?: string
  soft?: string
}): string {
  const title = (opts.title || '새 슬라이드').replace(/[<>]/g, '')
  const pack = (opts.packTitle || 'HTML Deck').replace(/[<>]/g, '')
  const accent = opts.accent || '#BC4F2B'
  const paper = opts.paper || '#ECE3D2'
  const ink = opts.ink || '#14181D'
  const soft = opts.soft || '#4A4D52'
  return `<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8"><title>${title}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+KR:wght@400;700;800&display=swap" rel="stylesheet">
<style>
:root{--paper:${paper};--ink:${ink};--ink-soft:${soft};--ember:${accent};--line:rgba(20,24,29,.16);}
body{margin:0;overflow:hidden;font-family:Inter,'Noto Sans KR',sans-serif;background:var(--paper);color:var(--ink);}
p,h1{margin:0;}
</style></head>
<body>
<div class="slide-container" data-slide-key="inserted" style="position:relative;width:1920px;height:1080px;background:var(--paper);">
  <div style="position:absolute;left:0;top:0;width:12px;height:1080px;background:var(--ember);"></div>
  <p style="position:absolute;left:96px;top:72px;font-size:14px;font-weight:700;letter-spacing:.14em;color:var(--ember);">${pack.toUpperCase()} · NEW</p>
  <h1 style="position:absolute;left:96px;top:200px;width:1600px;font-size:56px;font-weight:800;line-height:1.15;letter-spacing:-.02em;">${title}</h1>
  <p style="position:absolute;left:96px;top:360px;width:1400px;font-size:26px;line-height:1.45;color:var(--ink-soft);">플레이스홀더 · Agent로 문구·폰트를 부분 수정하세요. 레이아웃·색은 유지됩니다.</p>
  <ul style="position:absolute;left:96px;top:480px;margin:0;padding:0;list-style:none;width:1600px;">
    <li style="margin:0 0 24px;padding-left:28px;border-left:4px solid var(--ember);font-size:26px;line-height:1.4;">요점 하나</li>
    <li style="margin:0 0 24px;padding-left:28px;border-left:4px solid var(--ember);font-size:26px;line-height:1.4;">요점 둘</li>
    <li style="margin:0 0 24px;padding-left:28px;border-left:4px solid var(--ember);font-size:26px;line-height:1.4;">요점 셋</li>
  </ul>
  <p style="position:absolute;left:96px;top:980px;font-size:15px;color:var(--ink-soft);">Inserted slide · editable HTML</p>
</div>
</body></html>`
}
