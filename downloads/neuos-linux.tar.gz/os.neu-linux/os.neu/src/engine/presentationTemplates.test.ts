import { describe, expect, it } from 'vitest'
import {
  PRESENTATION_TEMPLATES,
  filterTemplates,
  getTemplateById,
  templatesVisibleTo,
} from './presentationTemplates'

describe('presentationTemplates', () => {
  it('includes neu-investor-dark with structure contract', () => {
    const t = getTemplateById('neu-investor-dark')
    expect(t?.name).toBe('NEU Investor Deck')
    expect(t?.structure.length).toBeGreaterThan(6)
    expect(t?.aspectRatio).toBe('16:9')
  })

  it('filterTemplates matches investor category', () => {
    const investor = filterTemplates(PRESENTATION_TEMPLATES, 'investor', '')
    expect(investor.some((t) => t.id === 'neu-investor-dark')).toBe(true)
  })

  it('filterTemplates search narrows by name', () => {
    const hits = filterTemplates(PRESENTATION_TEMPLATES, 'all', 'architecture')
    expect(hits.some((t) => t.id === 'tech-architecture')).toBe(true)
  })

  it('every gallery template exposes htmlDeckUrl', () => {
    for (const t of PRESENTATION_TEMPLATES) {
      expect(t.htmlDeckUrl, t.id).toBeTruthy()
      expect(t.htmlDeckUrl!.endsWith('.html'), t.id).toBe(true)
    }
  })

  it('PSST full pack is CEO-only; Northline demo is public twin', () => {
    expect(getTemplateById('ir-psst-full')?.audience).toBe('ceo-only')
    expect(getTemplateById('northline-ir-demo')?.htmlDeckUrl).toContain('northline-ir-demo')
    const publicPool = templatesVisibleTo(PRESENTATION_TEMPLATES, false)
    expect(publicPool.some((t) => t.id === 'ir-psst-full')).toBe(false)
    expect(publicPool.some((t) => t.id === 'northline-ir-demo')).toBe(true)
    const ceoPool = templatesVisibleTo(PRESENTATION_TEMPLATES, true)
    expect(ceoPool.some((t) => t.id === 'ir-psst-full')).toBe(true)
  })
})
