type Recog = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((ev: { results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null
  onerror: ((ev: { error: string }) => void) | null
  onend: (() => void) | null
}

function getEngine(): (new () => Recog) | null {
  const w = window as Window & {
    SpeechRecognition?: new () => Recog
    webkitSpeechRecognition?: new () => Recog
  }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function speechAvailable(): boolean {
  return getEngine() !== null
}

export function listenOnce(lang = 'en-US'): Promise<string> {
  const Ctor = getEngine()
  if (!Ctor) {
    return Promise.reject(new Error('Voice typing is not available on this screen. Type one line instead.'))
  }

  return new Promise((resolve, reject) => {
    const rec = new Ctor()
    rec.lang = lang
    rec.continuous = false
    rec.interimResults = true
    let last = ''

    rec.onresult = (ev) => {
      const piece = ev.results[ev.results.length - 1]
      if (piece) last = piece[0].transcript
      if (piece?.isFinal && last.trim()) {
        rec.stop()
        resolve(last.trim())
      }
    }
    rec.onerror = (ev) => {
      reject(new Error(ev.error === 'not-allowed' ? 'Please allow the microphone.' : 'Could not hear that.'))
    }
    rec.onend = () => {
      if (last.trim()) resolve(last.trim())
      else reject(new Error('Stopped before the sentence finished. Tap again.'))
    }
    rec.start()
  })
}

export type LiveListen = {
  stop: () => string
}

export function startLiveListen(
  lang: string,
  onPartial?: (text: string, isFinal: boolean) => void,
): LiveListen | null {
  const Ctor = getEngine()
  if (!Ctor) return null
  const rec = new Ctor()
  rec.lang = lang
  rec.continuous = true
  rec.interimResults = true
  let last = ''
  rec.onresult = (ev) => {
    const piece = ev.results[ev.results.length - 1]
    if (piece) last = piece[0].transcript
    if (last.trim()) onPartial?.(last.trim(), Boolean(piece?.isFinal))
  }
  rec.onerror = () => {
    /* MediaRecorder path still runs */
  }
  try {
    rec.start()
  } catch {
    return null
  }
  return {
    stop: () => {
      try {
        rec.stop()
      } catch {
        rec.abort()
      }
      return last.trim()
    },
  }
}

export async function recordClip(ms = 6000): Promise<Blob> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
  const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
    ? 'audio/webm;codecs=opus'
    : 'audio/webm'
  const recorder = new MediaRecorder(stream, { mimeType: mime })
  const chunks: Blob[] = []
  return new Promise((resolve, reject) => {
    recorder.ondataavailable = (ev) => {
      if (ev.data.size) chunks.push(ev.data)
    }
    recorder.onerror = () => {
      stream.getTracks().forEach((track) => track.stop())
      reject(new Error('Could not record audio.'))
    }
    recorder.onstop = () => {
      stream.getTracks().forEach((track) => track.stop())
      resolve(new Blob(chunks, { type: mime }))
    }
    recorder.start(200)
    window.setTimeout(() => {
      if (recorder.state !== 'inactive') recorder.stop()
    }, ms)
  })
}
