export type Rect = {
  left: number
  top: number
  width: number
  height: number
}

export type DriverKind = 'click' | 'type' | 'hotkey' | 'mousemove' | 'isolate'

export type DriverRequest = {
  kind: DriverKind
  x?: number
  y?: number
  text?: string
  keys?: string
  sandbox: Rect
}

export type PlannedAction =
  | { ok: false; reason: string }
  | {
      ok: true
      kind: DriverKind
      x: number
      y: number
      text?: string
      keys?: string
    }

export function clampToSandbox(x: number, y: number, box: Rect): PlannedAction {
  if (!Number.isFinite(box.left) || !Number.isFinite(box.top) || box.width < 8 || box.height < 8) {
    return { ok: false, reason: 'No sandbox region.' }
  }
  const maxX = box.left + box.width
  const maxY = box.top + box.height
  if (x < box.left || y < box.top || x > maxX || y > maxY) {
    return { ok: false, reason: 'Click left the isolated space.' }
  }
  return { ok: true, kind: 'click', x: Math.round(x), y: Math.round(y) }
}

export function planDriver(req: DriverRequest): PlannedAction {
  if (req.kind === 'isolate') {
    return { ok: true, kind: 'isolate', x: 0, y: 0 }
  }
  if (req.kind === 'type') {
    const text = (req.text ?? '').slice(0, 400)
    if (!text) return { ok: false, reason: 'Nothing to type.' }
    return { ok: true, kind: 'type', x: 0, y: 0, text }
  }
  if (req.kind === 'hotkey') {
    const keys = (req.keys ?? '').trim()
    if (!/^[a-z0-9+^_-]+$/i.test(keys)) {
      return { ok: false, reason: 'That hotkey is not allowed.' }
    }
    return { ok: true, kind: 'hotkey', x: 0, y: 0, keys }
  }
  const x = Number(req.x)
  const y = Number(req.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    return { ok: false, reason: 'No coordinates.' }
  }
  const clamped = clampToSandbox(x, y, req.sandbox)
  if (!clamped.ok) return clamped
  return { ...clamped, kind: req.kind === 'mousemove' ? 'mousemove' : 'click' }
}

export function linuxCommand(action: Extract<PlannedAction, { ok: true }>, windowId?: string): string[] {
  const win = windowId ? ['--window', windowId] : []
  if (action.kind === 'click' || action.kind === 'mousemove') {
    const move = ['xdotool', 'mousemove', ...win, String(action.x), String(action.y)]
    if (action.kind === 'mousemove') return move
    return [...move, 'click', ...win, '1']
  }
  if (action.kind === 'type') {
    return ['xdotool', 'type', '--clearmodifiers', '--', action.text ?? '']
  }
  if (action.kind === 'hotkey') {
    const mapped = (action.keys ?? 'ctrl+s').replace(/control/i, 'ctrl').toLowerCase()
    return ['xdotool', 'key', '--clearmodifiers', mapped]
  }
  return ['xdotool', 'getwindowname']
}

export function windowsScript(action: Extract<PlannedAction, { ok: true }>): string {
  if (action.kind === 'click' || action.kind === 'mousemove') {
    const click =
      action.kind === 'click'
        ? '[NeuInput]::Click([int]$env:NEU_X,[int]$env:NEU_Y)'
        : '[NeuInput]::Move([int]$env:NEU_X,[int]$env:NEU_Y)'
    return `
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class NeuInput {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, UIntPtr e);
  public static void Move(int x, int y) { SetCursorPos(x, y); }
  public static void Click(int x, int y) {
    SetCursorPos(x, y);
    mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
    mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
  }
}
"@
${click}
`.trim()
  }
  if (action.kind === 'type') {
    return '$w = New-Object -ComObject WScript.Shell; $w.SendKeys($env:NEU_TEXT)'
  }
  return '$w = New-Object -ComObject WScript.Shell; $w.SendKeys("^s")'
}
