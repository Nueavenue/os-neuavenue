import { afterEach, describe, expect, it } from 'vitest'
import {
  DEFAULT_SEARCH_ENGINE,
  SEARCH_ENGINE_GROUP_LABEL,
  SEARCH_ENGINE_STORAGE,
  isSearchEngineId,
  readSearchEngine,
  searchEngineGroups,
  searchUrl,
  writeSearchEngine,
} from './searchEngines'

const memory = new Map<string, string>()

afterEach(() => {
  memory.clear()
  // @ts-expect-error test stub
  globalThis.localStorage = undefined
})

function stubStorage() {
  const store = {
    getItem: (key: string) => memory.get(key) ?? null,
    setItem: (key: string, value: string) => {
      memory.set(key, value)
    },
  }
  // @ts-expect-error test stub
  globalThis.localStorage = store
}

describe('searchUrl', () => {
  it('defaults to SearXNG on searx.be', () => {
    expect(DEFAULT_SEARCH_ENGINE).toBe('searxng')
    expect(searchUrl('neu avenue')).toBe('https://searx.be/search?q=neu%20avenue')
  })

  it('builds one URL per chosen engine', () => {
    expect(searchUrl('os.neu', 'ddg')).toContain('html.duckduckgo.com/html')
    expect(searchUrl('os.neu', 'brave')).toContain('search.brave.com/search')
    expect(searchUrl('os.neu', 'mojeek')).toContain('mojeek.com/search')
    expect(searchUrl('os.neu', 'startpage')).toContain('startpage.com')
    expect(searchUrl('os.neu', 'wikipedia')).toContain('wikipedia.org/w/index.php?search=')
    expect(searchUrl('os.neu', 'google')).toContain('google.com/search')
    expect(searchUrl('os.neu', 'bing')).toContain('bing.com/search')
    expect(searchUrl('os.neu', 'naver')).toContain('search.naver.com')
    expect(searchUrl('os.neu', 'daum')).toContain('search.daum.net')
    expect(searchUrl('os.neu', 'perplexity')).toContain('perplexity.ai/search')
    expect(searchUrl('os.neu', 'yahoo')).toContain('search.yahoo.com/search')
    expect(searchUrl('os.neu', 'yandex')).toContain('yandex.com/search')
    expect(searchUrl('os.neu', 'qwant')).toContain('qwant.com')
    expect(searchUrl('os.neu', 'ecosia')).toContain('ecosia.org/search')
    expect(searchUrl('os.neu', 'you')).toContain('you.com/search')
    expect(searchUrl('os.neu', 'searxng')).toContain('searx.be/search')
  })

  it('lists world and Korea engines beside the open seat', () => {
    const groups = searchEngineGroups()
    expect(groups.map((group) => group.id)).toEqual(['open', 'world', 'korea', 'answer'])
    expect(SEARCH_ENGINE_GROUP_LABEL.open.ko).toBe('오픈')
    expect(SEARCH_ENGINE_GROUP_LABEL.world.ko).toBe('세계')
    expect(SEARCH_ENGINE_GROUP_LABEL.korea.ko).toBe('한국')
    expect(SEARCH_ENGINE_GROUP_LABEL.answer.ko).toBe('답변')
    expect(groups.flatMap((group) => group.engines.map((engine) => engine.id))).toEqual([
      'searxng',
      'ddg',
      'brave',
      'mojeek',
      'startpage',
      'qwant',
      'ecosia',
      'google',
      'bing',
      'yahoo',
      'yandex',
      'naver',
      'daum',
      'perplexity',
      'you',
      'wikipedia',
    ])
  })

  it('persists the customer pick and uses it on the next query', () => {
    stubStorage()
    writeSearchEngine('brave')
    expect(readSearchEngine()).toBe('brave')
    expect(localStorage.getItem(SEARCH_ENGINE_STORAGE)).toBe('brave')
    expect(searchUrl('weather')).toContain('search.brave.com/search')
  })

  it('rejects unknown engine ids', () => {
    expect(isSearchEngineId('askjeeves')).toBe(false)
    expect(isSearchEngineId('bing')).toBe(true)
    expect(isSearchEngineId('searxng')).toBe(true)
  })
})
