import { describe, expect, it } from 'vitest'
import { detectGuestOs, packForGuestOs } from './detectOs'

describe('guest OS from the public site', () => {
  it('reads Windows, macOS, ChromeOS, and Linux from the user agent', () => {
    expect(detectGuestOs('Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'Windows')).toBe('windows')
    expect(detectGuestOs('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 'macOS')).toBe('macos')
    expect(detectGuestOs('Mozilla/5.0 (X11; CrOS x86_64 14541.0.0)', 'Linux')).toBe('chromeos')
    expect(detectGuestOs('Mozilla/5.0 (X11; Linux x86_64)', 'Linux')).toBe('linux')
  })

  it('only ships a Linux screen pack today', () => {
    expect(packForGuestOs('linux', 'os.neuavenue.com').available).toBe(true)
    expect(packForGuestOs('linux', 'os.neuavenue.com').href).toBe('/downloads/neuos-linux.tar.gz')
    expect(packForGuestOs('windows').available).toBe(false)
    expect(packForGuestOs('macos').available).toBe(false)
    expect(packForGuestOs('chromeos').available).toBe(false)
  })
})
