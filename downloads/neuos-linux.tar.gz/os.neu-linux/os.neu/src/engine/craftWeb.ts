import { isInsideSandbox, joinCraftPath } from './craftConvert'

export function craftWebRoot(env: Record<string, string | undefined> = {}) {
  const dir = String(env.OSNEU_CRAFT_WEB_DIR || '').trim()
  if (!dir || dir.includes('\0') || dir.includes('..')) return null
  if (!dir.startsWith('/')) return null
  return dir.replace(/\/+$/, '')
}

export function craftWebHref(port: number) {
  const n = Number(port)
  if (!Number.isFinite(n) || n <= 0) return null
  return `http://127.0.0.1:${n}/craft-web/`
}

/** Relative file under the web dir. `/craft-web` → index.html. Reject `..`. */
export function craftWebFileRel(pathname: string) {
  const raw = String(pathname || '')
  let decoded = raw
  try {
    decoded = decodeURIComponent(raw)
  } catch {
    return null
  }
  const path = decoded.replace(/\\/g, '/')
  if (path === '/craft-web' || path === '/craft-web/') return 'index.html'
  if (!path.startsWith('/craft-web/')) return null
  let rest = path.slice('/craft-web/'.length)
  if (!rest || rest.endsWith('/')) rest = `${rest}index.html`.replace(/^\/+/, '')
  if (!rest || rest.includes('\0') || rest.includes('..') || rest.startsWith('/')) return null
  return rest
}

export function joinCraftWebFile(root: string, rel: string) {
  const joined = joinCraftPath(root, rel)
  if (!joined || !isInsideSandbox(root, joined)) return null
  return joined
}

export function planCraftWeb(
  env: Record<string, string | undefined>,
  port: number,
  hasIndex: boolean,
) {
  const root = craftWebRoot(env)
  const href = craftWebHref(port)
  if (!root || !hasIndex || !href) return { present: false as const, root }
  return { present: true as const, href, root }
}
