/** Customer seat must never sit dark with a leftover guest page. */

const RELOAD_AT = 'os.neu.seat.reloadAt'
const RELOAD_GAP_MS = 4000

export const SEAT_PULSE_MS = 1500
export const SEAT_STALE_MS = 4000

export function shouldReloadSeat(error: unknown): boolean {
  const msg = error instanceof Error ? error.message : String(error ?? '')
  return /NeuProvider missing|AppCatalogProvider missing/.test(msg)
}

export function isSeatStale(lastPulseAt: number, now: number, staleMs = SEAT_STALE_MS): boolean {
  if (!lastPulseAt) return false
  return now - lastPulseAt >= staleMs
}

export function hideSeatGuest() {
  if (typeof window === 'undefined') return
  try {
    void window.neuos?.browse?.hide()
    void window.neuos?.browse?.devtools?.(null)
  } catch {
    /* no electron */
  }
}

export function reloadSeat() {
  if (typeof window === 'undefined') return
  try {
    const last = Number(sessionStorage.getItem(RELOAD_AT) || 0)
    if (last && Date.now() - last < RELOAD_GAP_MS) return
    sessionStorage.setItem(RELOAD_AT, String(Date.now()))
  } catch {
    /* private mode */
  }
  hideSeatGuest()
  window.location.reload()
}

function installErrorGuard() {
  window.addEventListener('error', (event) => {
    hideSeatGuest()
    if (shouldReloadSeat(event.error ?? event.message)) reloadSeat()
  })
  window.addEventListener('unhandledrejection', () => {
    hideSeatGuest()
  })
}

function installElectronFullReload() {
  if (!window.neuos) return
  const hot = import.meta.hot
  if (!hot) return
  hot.on('vite:beforeUpdate', () => {
    hideSeatGuest()
    window.location.reload()
  })
}

function installSeatPulse() {
  if (!window.neuos?.seatPulse) return
  const beat = () => {
    void window.neuos?.seatPulse?.()
  }
  beat()
  window.setInterval(beat, SEAT_PULSE_MS)
}

let installed = false

export function installSeatGuard() {
  if (installed || typeof window === 'undefined') return
  installed = true
  installErrorGuard()
  installElectronFullReload()
  installSeatPulse()
}

/** @deprecated use installSeatGuard */
export function installSeatReload() {
  installSeatGuard()
}
