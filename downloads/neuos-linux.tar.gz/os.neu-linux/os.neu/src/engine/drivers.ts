import type { DriverEvent, DriverState } from '../types'

export function idleDriver(): DriverState {
  return {
    cursor: { x: 48, y: 48, visible: false },
    sandbox: 'idle',
    events: [],
  }
}

let eventSeq = 0

export function pushEvent(state: DriverState, kind: DriverEvent['kind'], label: string): DriverState {
  eventSeq += 1
  const next: DriverEvent = {
    id: `ev-${eventSeq}`,
    kind,
    label,
    at: Date.now(),
  }
  return {
    ...state,
    events: [...state.events.slice(-24), next],
  }
}

export function moveCursor(state: DriverState, x: number, y: number): DriverState {
  return {
    ...state,
    cursor: { x, y, visible: true },
  }
}

export function isolate(state: DriverState): DriverState {
  return pushEvent({ ...state, sandbox: 'isolated' }, 'isolate', 'App isolated in its own space')
}
