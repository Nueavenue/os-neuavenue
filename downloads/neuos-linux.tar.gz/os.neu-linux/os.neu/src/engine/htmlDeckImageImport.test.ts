import { describe, expect, it } from 'vitest'
import {
  analyzeRgbaBuffer,
  faithfulImageSlideHtml,
  htmlFromImageAnalysis,
  normalizeImportedHtml,
  rgbToHex,
} from './htmlDeckImageImport'

describe('htmlDeckImageImport', () => {
  it('rgbToHex pads', () => {
    expect(rgbToHex(0, 15, 255)).toBe('#000fff')
  })

  it('analyzeRgbaBuffer returns palette and html scaffold', () => {
    const W = 8
    const H = 8
    const data = new Uint8ClampedArray(W * H * 4)
    for (let i = 0; i < W * H; i++) {
      const o = i * 4
      data[o] = i % 2 === 0 ? 236 : 20
      data[o + 1] = i % 2 === 0 ? 227 : 24
      data[o + 2] = i % 2 === 0 ? 210 : 29
      data[o + 3] = 255
    }
    const analysis = analyzeRgbaBuffer(data, W, H, { width: 1920, height: 1080 })
    expect(analysis.palette.length).toBeGreaterThan(0)
    expect(analysis.background.startsWith('#')).toBe(true)
    const html = htmlFromImageAnalysis(analysis, 'Test Title')
    expect(html.length).toBeGreaterThan(200)
    expect(html).toContain('1920px')
    expect(html).toContain('Test Title')
  })

  it('normalizeImportedHtml strips scripts and keeps markup', () => {
    const raw =
      '<!DOCTYPE html><html><body><div class="slide-container">Hi</div>' +
      '<script>alert(1)</script></body></html>'
    const out = normalizeImportedHtml(raw)
    expect(out).toContain('slide-container')
    expect(out).not.toMatch(/<script/i)
  })

  it('faithfulImageSlideHtml embeds data url without stretch when not 16:9', () => {
    const html = faithfulImageSlideHtml({
      dataUrl: 'data:image/png;base64,aaa',
      fileName: 'shot.png',
      naturalWidth: 1200,
      naturalHeight: 1800,
    })
    expect(html).toContain('data-import="faithful-image"')
    expect(html).toContain('object-fit:contain')
    expect(html).toContain('data:image/png;base64,aaa')
  })
})
