import { describe, expect, it } from 'vitest'
import { blankPaperSlideHtml, parseInsertIntent, resolveSlideIndex } from './htmlDeckInsert'

const slides = [
  { id: 'cover', label: '01 표지' },
  { id: 'problem', label: '02 문제' },
  { id: 'pain', label: '03 문제인식' },
  { id: 'intent-first-category', label: '04 새로운 카테고리' },
  { id: 'personas', label: '05 목표고객' },
]

describe('htmlDeckInsert', () => {
  it('resolves 04 and label', () => {
    expect(resolveSlideIndex('04', slides)).toBe(3)
    expect(resolveSlideIndex('새로운 카테고리', slides)).toBe(3)
  })

  it('parses user phrase after category slide', () => {
    const hit = parseInsertIntent('04 새로운 카테고리 슬라이드에 다음 장 추가', slides, 0)
    expect(hit?.type).toBe('insert-after')
    expect(hit?.afterIndex).toBe(3)
  })

  it('parses 4번 다음에 새 슬라이드 추가', () => {
    const hit = parseInsertIntent('4번 다음에 새 슬라이드 추가', slides, 0)
    expect(hit?.afterIndex).toBe(3)
  })

  it('parses current slide', () => {
    const hit = parseInsertIntent('현재 장 다음에 추가', slides, 2)
    expect(hit?.afterIndex).toBe(2)
  })

  it('blank html is non-empty paper slide', () => {
    const html = blankPaperSlideHtml({ title: '테스트' })
    expect(html.length).toBeGreaterThan(200)
    expect(html).toContain('1920px')
    expect(html).toContain('테스트')
    expect(html).toContain('#ECE3D2')
  })
})
