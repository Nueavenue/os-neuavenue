import { describe, expect, it } from 'vitest'
import {
  dayKey,
  deleteVisit,
  editVisit,
  emptyLedger,
  groupByDay,
  hostOf,
  migrateHistory,
  suggestTools,
  upsertDownload,
  upsertVisit,
} from './browseLedger'

describe('browse ledger', () => {
  it('turns old string history into visit rows', () => {
    const rows = migrateHistory(['https://example.com/a', 'https://github.com'])
    expect(rows).toHaveLength(2)
    expect(rows[0].url).toBe('https://example.com/a')
    expect(rows[0].title).toBe('example.com')
  })

  it('adds, edits, and deletes visits', () => {
    let ledger = upsertVisit(emptyLedger(), { url: 'https://a.test/x', title: 'A' })
    const id = ledger.visits[0].id
    ledger = editVisit(ledger, id, { title: 'Alpha', url: 'https://a.test/y' })
    expect(ledger.visits[0].title).toBe('Alpha')
    expect(ledger.visits[0].url).toBe('https://a.test/y')
    ledger = deleteVisit(ledger, id)
    expect(ledger.visits).toHaveLength(0)
  })

  it('groups downloads by day with the newest file first', () => {
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 18, 0, 0).getTime()
    const morning = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0, 0).getTime()
    const yesterday = today - 24 * 60 * 60 * 1000
    let ledger = emptyLedger()
    ledger = upsertDownload(ledger, {
      id: '1',
      filename: 'old.zip',
      url: 'https://a.test/old.zip',
      state: 'done',
      t: morning,
    })
    ledger = upsertDownload(ledger, {
      id: '2',
      filename: 'new.pdf',
      url: 'https://a.test/new.pdf',
      state: 'done',
      t: today,
    })
    ledger = upsertDownload(ledger, {
      id: '3',
      filename: 'y.pdf',
      url: 'https://a.test/y.pdf',
      state: 'done',
      t: yesterday,
    })
    const groups = groupByDay(ledger.downloads)
    expect(groups[0].key).toBe(dayKey(today))
    expect(groups[0].items[0].filename).toBe('new.pdf')
    expect(groups[0].items[1].filename).toBe('old.zip')
    expect(groups[1].key).toBe(dayKey(yesterday))
  })

  it('assigns tools from login history', () => {
    let ledger = upsertVisit(emptyLedger(), { url: 'https://github.com/neuavenue', title: 'GitHub' })
    ledger = upsertVisit(ledger, { url: 'https://github.com/neuOS', title: 'neuOS' })
    ledger = upsertDownload(ledger, {
      id: 'd1',
      filename: 'brief.pdf',
      url: 'https://a.test/brief.pdf',
      state: 'done',
      t: Date.now(),
    })
    const tools = suggestTools(ledger, true)
    expect(tools.some((row) => row.id === 'devtools')).toBe(true)
    expect(tools.some((row) => row.id === 'pdf')).toBe(true)
    expect(hostOf('https://www.github.com/x')).toBe('github.com')
  })
})
