import { describe, expect, it } from 'vitest'
import { clampToSandbox, linuxCommand, planDriver } from './driverPlan'

const box = { left: 100, top: 80, width: 400, height: 300 }

describe('planDriver', () => {
  it('rejects clicks outside the sandbox', () => {
    const result = planDriver({ kind: 'click', x: 10, y: 10, sandbox: box })
    expect(result.ok).toBe(false)
  })

  it('keeps clicks inside the sandbox', () => {
    const result = planDriver({ kind: 'click', x: 120, y: 90, sandbox: box })
    expect(result).toMatchObject({ ok: true, kind: 'click', x: 120, y: 90 })
  })

  it('builds an xdotool click chain', () => {
    const planned = planDriver({ kind: 'click', x: 120, y: 90, sandbox: box })
    expect(planned.ok).toBe(true)
    if (!planned.ok) return
    expect(linuxCommand(planned)).toEqual(['xdotool', 'mousemove', '120', '90', 'click', '1'])
  })

  it('maps ctrl+s to xdotool', () => {
    const planned = planDriver({ kind: 'hotkey', keys: 'ctrl+s', sandbox: box })
    expect(planned.ok).toBe(true)
    if (!planned.ok) return
    expect(linuxCommand(planned)).toEqual(['xdotool', 'key', '--clearmodifiers', 'ctrl+s'])
  })

  it('rejects an empty sandbox', () => {
    const result = clampToSandbox(1, 1, { left: 0, top: 0, width: 0, height: 0 })
    expect(result.ok).toBe(false)
  })
})
