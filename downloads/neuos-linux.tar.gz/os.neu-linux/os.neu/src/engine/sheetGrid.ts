const COLS = 6
const ROWS = 12

export function emptySheetGrid(rows = ROWS, cols = COLS) {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => ''))
}

function colIndex(letters: string) {
  let n = 0
  for (const ch of letters.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64)
  return n - 1
}

/** A1-style address, with or without a leading equals. */
export function parseCellRef(raw: string): { r: number; c: number } | null {
  const t = String(raw || '')
    .trim()
    .replace(/^=\s*/, '')
    .replace(/\s+/g, '')
  const match = t.match(/^([A-Za-z]{1,2})(\d+)$/)
  if (!match) return null
  const c = colIndex(match[1])
  const r = Number(match[2]) - 1
  if (c < 0 || r < 0) return null
  return { r, c }
}

function isFormulaDump(raw: string) {
  const t = String(raw || '').trim()
  if (!t.startsWith('=')) return false
  if (parseCellRef(t)) return true
  if (/^=\s*[A-Za-z]{2,}\s*\(/.test(t)) return true
  if (/^=\s*[A-Za-z]{1,2}\d+\s*([+\-*/:])/.test(t)) return true
  return false
}

/** Value a person reads in the grid — not Excel source. */
export function displaySheetCell(raw: string) {
  const t = String(raw || '').trim()
  if (!t) return ''
  if (isFormulaDump(t)) return ''
  return t.replace(/^=\s*/, '').trim()
}

function splitLine(line: string): string[] | null {
  if (/^```/.test(line) || /^#{1,6}\s/.test(line)) return null
  const assign =
    line.match(/^([A-Za-z]{1,2}\d+)\s*=\s*(.+)$/) || line.match(/^=\s*([A-Za-z]{1,2}\d+)\s*=\s*(.+)$/)
  if (assign) return [assign[1], assign[2]]
  if (line.includes('|')) {
    const cells = line.split('|').map((cell) => cell.trim())
    if (cells[0] === '') cells.shift()
    if (cells.length && cells[cells.length - 1] === '') cells.pop()
    if (cells.length && cells.every((cell) => /^:?-{2,}:?$/.test(cell))) return null
    return cells
  }
  if (line.includes('\t')) return line.split('\t').map((cell) => cell.trim())
  if (line.includes(',') && line.split(',').length >= 2) {
    return line.split(',').map((cell) => cell.trim())
  }
  return null
}

function looksLikeAssignmentRow(cells: string[]) {
  if (cells.length < 2) return false
  let pairs = 0
  for (let i = 0; i + 1 < cells.length; i += 2) {
    if (parseCellRef(cells[i]) && displaySheetCell(cells[i + 1])) pairs += 1
  }
  return pairs >= 1 && pairs * 2 >= cells.length - 1
}

function applyAssignments(grid: string[][], cells: string[], rows: number, cols: number) {
  for (let i = 0; i + 1 < cells.length; i += 2) {
    const at = parseCellRef(cells[i])
    const value = displaySheetCell(cells[i + 1])
    if (!at || !value) continue
    if (at.r >= rows || at.c >= cols) continue
    grid[at.r][at.c] = value
  }
}

/** Turn Writer text into display cells. Drops formulas, A1 dumps, and prose around the table. */
export function parseSheetGrid(text: string, rows = ROWS, cols = COLS) {
  const grid = emptySheetGrid(rows, cols)
  const parsed: string[][] = []
  for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
    const line = raw.trim()
    if (!line) continue
    const cells = splitLine(line)
    if (!cells?.length) continue
    parsed.push(cells)
  }
  const assignRows = parsed.filter(looksLikeAssignmentRow)
  if (assignRows.length >= 1 && assignRows.length >= parsed.length / 2) {
    for (const cells of assignRows) applyAssignments(grid, cells, rows, cols)
    return grid
  }
  let r = 0
  for (const cells of parsed) {
    if (r >= rows) break
    const shown = cells.slice(0, cols).map(displaySheetCell)
    if (shown.every((cell) => !cell)) continue
    shown.forEach((cell, c) => {
      grid[r][c] = cell
    })
    r += 1
  }
  return grid
}

function gridHasCells(grid: string[][]) {
  return grid.some((row) => row.some((cell) => String(cell || '').trim()))
}

/** Seat / fail text: keep a real table, or put the message in A1 so the page is not blank. */
export function applySheetSeatBody(text: string, rows = ROWS, cols = COLS) {
  const raw = String(text || '')
  const grid = parseSheetGrid(raw, rows, cols)
  if (gridHasCells(grid)) return grid
  const msg = raw.replace(/\s+/g, ' ').trim()
  if (!msg) return grid
  const next = emptySheetGrid(rows, cols)
  next[0][0] = msg
  return next
}
