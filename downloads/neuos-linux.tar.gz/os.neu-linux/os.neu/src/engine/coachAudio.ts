export type CoachClip = { data: string; format: string }

let lastClip: CoachClip | null = null
let lastReply = ''

export function rememberCoach(reply: string, audio?: CoachClip) {
  lastReply = reply
  lastClip = audio ?? null
}

export function coachHasVoice(): boolean {
  return Boolean(lastClip || lastReply)
}

export function speakBrowser(text: string) {
  if (typeof window === 'undefined' || !window.speechSynthesis || !text.trim()) return
  const utter = new SpeechSynthesisUtterance(text)
  utter.lang = 'en-US'
  window.speechSynthesis.cancel()
  window.speechSynthesis.speak(utter)
}

export async function playCoachAudio(): Promise<boolean> {
  if (lastClip) {
    const binary = atob(lastClip.data)
    const bytes = new Uint8Array(binary.length)
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i)
    const mime = lastClip.format === 'wav' ? 'audio/wav' : `audio/${lastClip.format}`
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }))
    const audio = new Audio(url)
    await audio.play()
    return true
  }
  if (lastReply) {
    speakBrowser(lastReply)
    return true
  }
  return false
}
