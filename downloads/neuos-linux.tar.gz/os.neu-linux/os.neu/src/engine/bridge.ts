export type BridgeStatus = {
  ok: boolean
  driver: 'xdotool' | 'win32' | 'dry-run'
  live?: boolean
  vlm: 'graph' | 'remote'
  browse: 'proxy' | 'electron'
  speak?: 'openai' | 'off'
  display?: string
  detail: string
  samples?: number
}

export type DriverActResult = {
  ok: boolean
  backend: BridgeStatus['driver']
  dryRun: boolean
  command?: string[]
  reason?: string
}

export type BootHealth = {
  ok: boolean
  t: number
  pid?: number
  jeos?: boolean
  platform?: string
  stage?: string
  last?: string
  act?: string
  stale?: boolean
  ageMs?: number
  missing?: boolean
}

export type UsbDisk = {
  name: string
  path: string
  size: string
  model: string
  removable: boolean
  system: boolean
}

export type UsbList = {
  ok: boolean
  disks: UsbDisk[]
  usb: UsbDisk[]
  iso: string
  command: string
}

export type JeosAsk = {
  ok: boolean
  act: string
  reply: string
  health: BootHealth
  plan?: AppPlan
}

export type HostProfile = {
  family: string
  distro: string
  version: string
  pretty: string
  pkg: string
  arch: string
  hostname: string
  cores: number
  memGb: number
  platform: string
  cpuBrief?: string
}

export type AppPlan = {
  app: string
  kind: 'install' | 'remove'
  command: string
  url?: string
  next?: string
  host?: HostProfile
}

export type InstallRun = {
  ok: boolean
  percent: number
  test?: boolean
  steps?: string[]
  command?: string
  wiped?: boolean
  host?: HostProfile
}

function api(path: string, init?: RequestInit): Promise<Response> {
  return fetch(path, {
    ...init,
    headers: { 'content-type': 'application/json', ...(init?.headers ?? {}) },
  })
}

export async function fetchBridgeStatus(): Promise<BridgeStatus | null> {
  try {
    const res = await api('/api/health')
    if (!res.ok) return null
    return (await res.json()) as BridgeStatus
  } catch {
    return null
  }
}

export async function actDriver(body: unknown): Promise<DriverActResult> {
  const res = await api('/api/driver/act', {
    method: 'POST',
    body: JSON.stringify(body),
  })
  return (await res.json()) as DriverActResult
}

export async function inferVision(body: unknown): Promise<unknown> {
  const res = await api('/api/vlm/infer', {
    method: 'POST',
    body: JSON.stringify(body),
  })
  return res.json()
}

export async function recordVisionSample(body: unknown): Promise<void> {
  await api('/api/vlm/sample', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function fetchBootHealth(refresh = true): Promise<BootHealth> {
  const res = await api(`/api/boot-health${refresh ? '?refresh=1' : ''}`)
  return (await res.json()) as BootHealth
}

export async function askJeos(text: string): Promise<JeosAsk> {
  const res = await api('/api/jeos/ask', {
    method: 'POST',
    body: JSON.stringify({ text }),
  })
  return (await res.json()) as JeosAsk
}

export async function coachChat(
  message: string,
  history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
  opts: { audio?: boolean } = {},
): Promise<{
  ok: boolean
  reply: string
  audio?: { data: string; format: string }
}> {
  const res = await api('/api/speak/chat', {
    method: 'POST',
    body: JSON.stringify({ message, history, audio: opts.audio === true }),
  })
  return (await res.json()) as { ok: boolean; reply: string; audio?: { data: string; format: string } }
}

export async function transcribeSpeech(blob: Blob): Promise<string> {
  const res = await fetch('/api/speak/asr', {
    method: 'POST',
    headers: { 'content-type': blob.type || 'audio/webm' },
    body: blob,
  })
  const body = (await res.json()) as { ok?: boolean; transcript?: string; reason?: string }
  const text = body.transcript?.trim() ?? ''
  if (text) return text
  if (res.status === 503 || body.reason === 'openai-unconfigured') {
    throw new Error('Coach is not configured on this machine.')
  }
  if (body.reason === 'asr-unavailable' || res.status >= 500) {
    throw new Error('Could not hear that. Try one short sentence, then tap the mic again.')
  }
  throw new Error('Could not hear that. Tap the mic, speak, then tap again.')
}

export async function fetchUsbDisks(): Promise<UsbList> {
  const res = await api('/api/usb/disks')
  return (await res.json()) as UsbList
}

export async function planUsb(device: string): Promise<{ ok: boolean; command: string; allow?: boolean }> {
  const res = await api('/api/usb/plan', {
    method: 'POST',
    body: JSON.stringify({ device }),
  })
  return (await res.json()) as { ok: boolean; command: string; allow?: boolean }
}

export async function installHost(): Promise<{ ok: boolean; stdout?: string }> {
  const res = await api('/api/install/host', { method: 'POST', body: '{}' })
  return (await res.json()) as { ok: boolean; stdout?: string }
}

export type UninstallStatus = {
  ok: boolean
  autostart: boolean
  unit: boolean
  planted: boolean
  forced: boolean
}

export async function fetchUninstallStatus(): Promise<UninstallStatus> {
  const res = await api('/api/uninstall/status')
  return (await res.json()) as UninstallStatus
}

export async function uninstallHost(files = false): Promise<{ ok: boolean; stdout?: string }> {
  const res = await api('/api/uninstall', {
    method: 'POST',
    body: JSON.stringify({ files }),
  })
  return (await res.json()) as { ok: boolean; stdout?: string }
}

export async function fetchHostProfile(): Promise<HostProfile> {
  const res = await api('/api/host-profile')
  return (await res.json()) as HostProfile
}

export async function runInstall(body: { mode: 'host' | 'usb'; device?: string; test?: boolean }): Promise<InstallRun> {
  const res = await api('/api/install/run', { method: 'POST', body: JSON.stringify(body) })
  return (await res.json()) as InstallRun
}

export async function planAppInstall(text: string, source: 'prompt' | 'lui' | 'wizard' = 'lui') {
  const res = await api('/api/apps/plan', {
    method: 'POST',
    body: JSON.stringify({ text, source }),
  })
  return (await res.json()) as { ok: boolean; plan: AppPlan; preference?: { installSurface: 'prompt' | 'neuos' } }
}

export async function appendStart(which: 'jeos' | 'loop') {
  await api('/api/monitor', {
    method: 'POST',
    body: JSON.stringify({ source: 'wizard', kind: 'start', note: which }),
  })
}

export function sandboxRect(el: HTMLElement): {
  left: number
  top: number
  width: number
  height: number
} {
  const box = el.getBoundingClientRect()
  return {
    left: window.screenX + box.left,
    top: window.screenY + box.top,
    width: box.width,
    height: box.height,
  }
}
