import { describe, expect, it } from 'vitest'
import { isAuthHost, normalizeAddress } from './browser'

describe('normalizeAddress', () => {
  it('sends brand host home', () => {
    expect(normalizeAddress('https://os.neu.local')).toEqual({ kind: 'home' })
    expect(normalizeAddress('https://neuos.local')).toEqual({ kind: 'home' })
    expect(normalizeAddress('')).toEqual({ kind: 'home' })
  })

  it('blocks dangerous schemes', () => {
    const result = normalizeAddress('javascript:alert(1)')
    expect(result).toEqual({ kind: 'invalid', reason: 'This kind of address cannot be opened.' })
  })

  it('uses http for loopback hosts', () => {
    expect(normalizeAddress('127.0.0.1:4178/api/demo')).toEqual({
      kind: 'url',
      href: 'http://127.0.0.1:4178/api/demo',
    })
  })

  it('opens the public web home as https', () => {
    expect(normalizeAddress('www.neuavenue.com')).toEqual({
      kind: 'url',
      href: 'https://www.neuavenue.com/',
    })
  })

  it('treats Google sign-in as an auth host', () => {
    expect(isAuthHost('https://accounts.google.com/ServiceLogin')).toBe(true)
    expect(isAuthHost('https://www.neuavenue.com/')).toBe(false)
  })

  it('turns a sentence into a search', () => {
    const result = normalizeAddress('오늘 날씨')
    expect(result.kind).toBe('url')
    if (result.kind === 'url') {
      expect(result.href).toContain('duckduckgo.com')
      expect(result.href).toContain(encodeURIComponent('오늘 날씨'))
    }
  })
})
