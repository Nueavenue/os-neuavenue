import { describe, expect, it } from 'vitest'
import {
  COMMAND_VIEW_APP_URL,
  COMMAND_VIEW_LEADER_EMAIL,
  commandViewHref,
  isAuthHost,
  isCommandViewLeaderEmail,
  isOllamaApiUrl,
  normalizeAddress,
} from './browser'

describe('normalizeAddress', () => {
  it('sends brand host home', () => {
    expect(normalizeAddress('https://os.neu.local')).toEqual({ kind: 'home' })
    expect(normalizeAddress('https://neuos.local')).toEqual({ kind: 'home' })
    expect(normalizeAddress('')).toEqual({ kind: 'home' })
  })

  it('blocks dangerous schemes', () => {
    const result = normalizeAddress('javascript:alert(1)')
    expect(result).toEqual({ kind: 'invalid', reason: 'This kind of address cannot be opened.' })
  })

  it('uses http for loopback hosts', () => {
    expect(normalizeAddress('127.0.0.1:4178/api/demo')).toEqual({
      kind: 'url',
      href: 'http://127.0.0.1:4178/api/demo',
    })
    expect(normalizeAddress('http://127.0.0.1:11434')).toEqual({
      kind: 'url',
      href: 'http://127.0.0.1:11434/',
    })
  })

  it('opens the public web home as https', () => {
    expect(normalizeAddress('www.neuavenue.com')).toEqual({
      kind: 'url',
      href: 'https://www.neuavenue.com/',
    })
  })

  it('treats Google sign-in as an auth host', () => {
    expect(isAuthHost('https://accounts.google.com/ServiceLogin')).toBe(true)
    expect(isAuthHost('https://www.neuavenue.com/')).toBe(false)
  })

  it('turns a sentence into a SearXNG search by default', () => {
    const result = normalizeAddress('오늘 날씨')
    expect(result.kind).toBe('url')
    if (result.kind === 'url') {
      expect(result.href).toContain('searx.be/search')
      expect(result.href).toContain(encodeURIComponent('오늘 날씨'))
    }
  })

  it('honors an explicit engine on the same query', () => {
    const ddg = normalizeAddress('오늘 날씨', 'ddg')
    expect(ddg.kind).toBe('url')
    if (ddg.kind === 'url') {
      expect(ddg.href).toContain('duckduckgo.com')
      expect(ddg.href).not.toContain('searx.be')
    }
    const google = normalizeAddress('오늘 날씨', 'google')
    expect(google.kind).toBe('url')
    if (google.kind === 'url') expect(google.href).toContain('google.com/search')
  })

  it('detects the Ollama API port', () => {
    expect(isOllamaApiUrl('http://127.0.0.1:11434/')).toBe(true)
    expect(isOllamaApiUrl('http://127.0.0.1:4178/api/health')).toBe(false)
  })
})

describe('Command View href', () => {
  it('does not put a non-JWT in the hash', () => {
    expect(commandViewHref('')).toBe(COMMAND_VIEW_APP_URL)
    expect(commandViewHref('local-device-hex-token')).toBe(COMMAND_VIEW_APP_URL)
  })

  it('carries a seat JWT so Door A can skip Google', () => {
    const href = commandViewHref('aaa.bbb.ccc', 'refresh-1')
    expect(href.startsWith(COMMAND_VIEW_APP_URL)).toBe(true)
    expect(href).toContain('access_token=aaa.bbb.ccc')
    expect(href).toContain('refresh_token=refresh-1')
    expect(href).toContain('view=shareholder')
  })
})

describe('Command View leader mailbox', () => {
  it('matches neuavenue@gmail.com only', () => {
    expect(isCommandViewLeaderEmail(COMMAND_VIEW_LEADER_EMAIL)).toBe(true)
    expect(isCommandViewLeaderEmail('NeuAvenue@gmail.com')).toBe(true)
    expect(isCommandViewLeaderEmail(' staff@example.com ')).toBe(false)
    expect(isCommandViewLeaderEmail('')).toBe(false)
    expect(isCommandViewLeaderEmail(null)).toBe(false)
  })
})
