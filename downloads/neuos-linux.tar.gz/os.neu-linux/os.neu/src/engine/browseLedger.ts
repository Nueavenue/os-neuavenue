export type VisitRecord = {
  id: string
  url: string
  title: string
  t: number
}

export type DownloadRecord = {
  id: string
  filename: string
  url: string
  path?: string
  mime?: string
  bytes?: number
  received?: number
  state: 'progress' | 'done' | 'failed' | 'cancelled'
  t: number
}

export type ToolUse = {
  id: string
  tool: string
  label: string
  t: number
}

export type BrowseLedger = {
  visits: VisitRecord[]
  downloads: DownloadRecord[]
  tools: ToolUse[]
}

export type DayGroup<T> = {
  day: string
  key: string
  items: T[]
}

export type AssignedTool = {
  id: string
  label: string
  reason: string
  run: 'url' | 'devtools' | 'office-doc' | 'office-sheet' | 'downloads'
  href?: string
}

const CAP = 400

export const emptyLedger = (): BrowseLedger => ({ visits: [], downloads: [], tools: [] })

export function ledgerStorageKey(email?: string | null) {
  const neat = String(email || 'guest').trim().toLowerCase() || 'guest'
  return `os.neu.browse.${neat}`
}

export function newId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
}

export function migrateHistory(raw: unknown): VisitRecord[] {
  if (!Array.isArray(raw)) return []
  return raw
    .map((item, index) => {
      if (typeof item === 'string' && item.trim()) {
        return {
          id: `hist-${index}-${item.slice(0, 24)}`,
          url: item,
          title: hostOf(item),
          t: Date.now() - index * 1000,
        }
      }
      if (item && typeof item === 'object') {
        const row = item as Partial<VisitRecord>
        if (!row.url) return null
        return {
          id: String(row.id || newId('hist')),
          url: String(row.url),
          title: String(row.title || hostOf(String(row.url))),
          t: Number(row.t) || Date.now(),
        }
      }
      return null
    })
    .filter((row): row is VisitRecord => Boolean(row))
}

export function hostOf(href: string) {
  try {
    return new URL(href).hostname.replace(/^www\./, '')
  } catch {
    return href
  }
}

export function loadLedger(email?: string | null): BrowseLedger {
  const fallback = emptyLedger()
  try {
    const raw = localStorage.getItem(ledgerStorageKey(email))
    if (!raw) {
      const legacy = localStorage.getItem('os.neu.history')
      if (!legacy) return fallback
      return { ...fallback, visits: migrateHistory(JSON.parse(legacy) as unknown).slice(0, CAP) }
    }
    const parsed = JSON.parse(raw) as Partial<BrowseLedger>
    return {
      visits: migrateHistory(parsed.visits).slice(0, CAP),
      downloads: Array.isArray(parsed.downloads) ? parsed.downloads.slice(0, CAP) : [],
      tools: Array.isArray(parsed.tools) ? parsed.tools.slice(0, CAP) : [],
    }
  } catch {
    return fallback
  }
}

export function saveLedger(email: string | null | undefined, ledger: BrowseLedger) {
  const next = {
    visits: ledger.visits.slice(0, CAP),
    downloads: ledger.downloads.slice(0, CAP),
    tools: ledger.tools.slice(0, CAP),
  }
  localStorage.setItem(ledgerStorageKey(email), JSON.stringify(next))
  return next
}

export function upsertVisit(ledger: BrowseLedger, visit: Omit<VisitRecord, 'id' | 't'> & Partial<VisitRecord>) {
  const url = visit.url.trim()
  if (!url) return ledger
  const row: VisitRecord = {
    id: visit.id || newId('hist'),
    url,
    title: (visit.title || hostOf(url)).trim(),
    t: visit.t || Date.now(),
  }
  return {
    ...ledger,
    visits: [row, ...ledger.visits.filter((item) => item.id !== row.id && item.url !== url)].slice(0, CAP),
  }
}

export function editVisit(ledger: BrowseLedger, id: string, patch: { url?: string; title?: string }) {
  return {
    ...ledger,
    visits: ledger.visits.map((row) => {
      if (row.id !== id) return row
      const url = (patch.url ?? row.url).trim()
      return {
        ...row,
        url,
        title: (patch.title ?? row.title).trim() || hostOf(url),
      }
    }),
  }
}

export function deleteVisit(ledger: BrowseLedger, id: string) {
  return { ...ledger, visits: ledger.visits.filter((row) => row.id !== id) }
}

export function upsertDownload(ledger: BrowseLedger, rec: DownloadRecord) {
  const rest = ledger.downloads.filter((row) => row.id !== rec.id)
  return { ...ledger, downloads: [rec, ...rest].sort((a, b) => b.t - a.t).slice(0, CAP) }
}

export function recordTool(ledger: BrowseLedger, tool: string, label: string) {
  const row: ToolUse = { id: newId('tool'), tool, label, t: Date.now() }
  return { ...ledger, tools: [row, ...ledger.tools].slice(0, CAP) }
}

export function dayKey(t: number) {
  const d = new Date(t)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function groupByDay<T extends { t: number }>(rows: T[], locale = 'en'): DayGroup<T>[] {
  const sorted = rows.slice().sort((a, b) => b.t - a.t)
  const map = new Map<string, T[]>()
  for (const row of sorted) {
    const key = dayKey(row.t)
    const list = map.get(key)
    if (list) list.push(row)
    else map.set(key, [row])
  }
  return [...map.entries()].map(([key, items]) => ({
    key,
    day: new Date(items[0].t).toLocaleDateString(locale, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      weekday: 'short',
    }),
    items,
  }))
}

function countBy(rows: Array<{ url?: string; filename?: string; tool?: string }>, pick: (row: (typeof rows)[number]) => string) {
  const map = new Map<string, number>()
  for (const row of rows) {
    const key = pick(row)
    if (!key) continue
    map.set(key, (map.get(key) || 0) + 1)
  }
  return [...map.entries()].sort((a, b) => b[1] - a[1])
}

export function suggestTools(ledger: BrowseLedger, ko = false): AssignedTool[] {
  const hosts = countBy(ledger.visits, (row) => hostOf(row.url || ''))
  const files = countBy(ledger.downloads, (row) => {
    const name = String(row.filename || '')
    const ext = name.includes('.') ? name.slice(name.lastIndexOf('.') + 1).toLowerCase() : ''
    return ext
  })
  const used = new Set(ledger.tools.map((row) => row.tool))
  const slots: AssignedTool[] = []
  const take = (tool: AssignedTool) => {
    if (slots.some((row) => row.id === tool.id)) return
    slots.push(tool)
  }

  if (files.some(([ext]) => ['pdf'].includes(ext))) {
    take({
      id: 'pdf',
      label: ko ? 'PDF 보기' : 'PDF viewer',
      reason: ko ? '받은 PDF가 있습니다.' : 'You downloaded PDFs.',
      run: 'url',
      href: 'https://mozilla.github.io/pdf.js/web/viewer.html',
    })
  }
  if (files.some(([ext]) => ['xlsx', 'csv', 'tsv'].includes(ext)) || hosts.some(([host]) => host.includes('sheets.google'))) {
    take({
      id: 'sheets',
      label: ko ? '시트' : 'Sheets',
      reason: ko ? '표 파일을 자주 다룹니다.' : 'You work with sheets.',
      run: 'office-sheet',
    })
  }
  if (files.some(([ext]) => ['doc', 'docx'].includes(ext)) || hosts.some(([host]) => host.includes('docs.google'))) {
    take({
      id: 'docs',
      label: ko ? '문서' : 'Docs',
      reason: ko ? '문서를 자주 엽니다.' : 'You open documents often.',
      run: 'office-doc',
    })
  }
  if (hosts.some(([host]) => host.includes('github') || host.includes('gitlab') || host.includes('stackoverflow'))) {
    take({
      id: 'devtools',
      label: ko ? '개발툴' : 'DevTools',
      reason: ko ? '코드 사이트를 자주 봅니다.' : 'You visit developer sites.',
      run: 'devtools',
    })
  }
  if (used.has('devtools')) {
    take({
      id: 'devtools',
      label: ko ? '개발툴' : 'DevTools',
      reason: ko ? '개발툴을 이미 썼습니다.' : 'You already opened DevTools.',
      run: 'devtools',
    })
  }
  const top = hosts[0]
  if (top && top[1] >= 2) {
    take({
      id: `host-${top[0]}`,
      label: top[0],
      reason: ko ? `가장 많이 연 사이트입니다 (${top[1]}회).` : `Most visited site (${top[1]} times).`,
      run: 'url',
      href: `https://${top[0]}`,
    })
  }
  if (files.some(([ext]) => ['zip', 'gz', '7z', 'deb', 'rpm', 'exe', 'dmg', 'appimage'].includes(ext))) {
    take({
      id: 'downloads',
      label: ko ? '설치 파일' : 'Installers',
      reason: ko ? '설치용 파일을 받았습니다.' : 'You downloaded installers.',
      run: 'downloads',
    })
  }
  if (!slots.length) {
    take({
      id: 'search',
      label: ko ? '검색' : 'Search',
      reason: ko ? '방문이 쌓이면 도구가 배정됩니다.' : 'Tools are assigned as you browse.',
      run: 'url',
      href: 'https://html.duckduckgo.com/html/',
    })
  }
  return slots.slice(0, 6)
}
