import type { CraftBins } from './craftDetect'
import { isInsideSandbox } from './craftConvert'

export type CraftMcpRoots = {
  readRoot?: string | null
  writeRoot?: string | null
  sandbox: string
}

function cleanRoot(value: string | null | undefined) {
  const raw = String(value || '').trim()
  if (!raw || raw.includes('\0')) return null
  const norm = raw.replace(/\\/g, '/')
  if (!norm.startsWith('/')) return null
  if (norm.includes('..')) return null
  const trimmed = norm.replace(/\/+$/, '')
  return trimmed || '/'
}

/** Both automation roots must be set, equal, and the 002 sandbox. Else refuse. */
export function craftMcpArgv(roots: CraftMcpRoots): string[] | null {
  const sandbox = cleanRoot(roots.sandbox)
  const readRoot = cleanRoot(roots.readRoot)
  const writeRoot = cleanRoot(roots.writeRoot)
  if (!sandbox || !readRoot || !writeRoot) return null
  if (readRoot !== writeRoot || readRoot !== sandbox) return null
  if (!isInsideSandbox(sandbox, readRoot) || !isInsideSandbox(sandbox, writeRoot)) return null
  return ['mcp', '--automation-read-root', sandbox, '--automation-write-root', sandbox]
}

export function craftMcpCliPath(bins: CraftBins) {
  return bins.wordcraft || bins.gridcraft || bins.deckcraft
}
