import { describe, expect, it } from 'vitest'
import {
  baseSlideTitle,
  numberedLabel,
  parseRenameIntent,
  patchSlideTitleInHtml,
} from './htmlDeckRename'

const slides = [
  { id: 'a', label: '04 카테고리' },
  { id: 'b', label: '05 새 슬라이드' },
  { id: 'c', label: '06 차별성' },
]

describe('htmlDeckRename', () => {
  it('parses current-slide rename', () => {
    const r = parseRenameIntent('현재 장 제목을 제품구조로', slides, 1)
    expect(r?.title).toBe('제품구조')
    expect(r?.index).toBe(1)
  })

  it('parses numbered rename', () => {
    const r = parseRenameIntent('05장 이름을 제품구조로 변경', slides, 0)
    expect(r?.index).toBe(1)
    expect(r?.title).toBe('제품구조')
  })

  it('parses colon form', () => {
    const r = parseRenameIntent('장 이름: 제품구조', slides, 1)
    expect(r?.title).toBe('제품구조')
  })

  it('numbers labels', () => {
    expect(numberedLabel(4, '제품구조')).toBe('05 제품구조')
    expect(baseSlideTitle('05 새 슬라이드')).toBe('새 슬라이드')
  })

  it('patches h1 and title in html', () => {
    const html = '<!DOCTYPE html><html><head><title>옛</title></head><body><h1 style="x">새 슬라이드</h1></body></html>'
    const next = patchSlideTitleInHtml(html, '제품구조')
    expect(next).toContain('<title>제품구조</title>')
    expect(next).toContain('>제품구조</h1>')
  })
})
