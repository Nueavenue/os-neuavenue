import { describe, expect, it } from 'vitest'
import {
  ENTIRE_DECK_SCOPE_ENABLED,
  addOnSelected,
  agentInstruction,
  applySelectedText,
  deleteSelected,
  historyLine,
  instructionTouchesWholeDeck,
  parseElementReply,
  parseSlideReply,
  patchDeckSlide,
  selectedText,
} from './slideAgentEdit'
import type { RecipeSlide } from './slidesRecipe'

const deck: RecipeSlide[] = [
  { layout: 'title', title: 'Cover', body: 'Hello', bullets: [], table: null },
  {
    layout: 'bullets',
    title: 'Why',
    body: 'Fast\nLocal\nPrivate',
    bullets: ['Fast', 'Local', 'Private'],
    table: null,
  },
  {
    layout: 'table',
    title: 'Numbers',
    body: '',
    bullets: [],
    table: { headers: ['Metric', 'Value'], rows: [['Users', '10']] },
  },
]

function snap(slides: RecipeSlide[]) {
  return JSON.stringify(slides)
}

describe('slideAgentEdit Phase 1', () => {
  it('rewrites only the selected title and leaves other slides byte-identical', () => {
    const beforeOthers = snap(deck.slice(1))
    const next = patchDeckSlide(deck, 0, applySelectedText(deck[0], { kind: 'title' }, 'New cover'))
    expect(next[0].title).toBe('New cover')
    expect(next[0].body).toBe('Hello')
    expect(snap(next.slice(1))).toBe(beforeOthers)
    expect(next[1]).toBe(deck[1])
    expect(next[2]).toBe(deck[2])
  })

  it('rewrites one bullet only', () => {
    const before = snap([deck[0], deck[2]])
    const edited = applySelectedText(deck[1], { kind: 'bullet', bulletIndex: 1 }, 'On this PC')
    const next = patchDeckSlide(deck, 1, edited)
    expect(selectedText(next[1], { kind: 'bullet', bulletIndex: 1 })).toBe('On this PC')
    expect(next[1].bullets[0]).toBe('Fast')
    expect(snap([next[0], next[2]])).toBe(before)
  })

  it('rewrites one table cell only', () => {
    const edited = applySelectedText(deck[2], { kind: 'cell', row: 0, col: 1 }, '12')
    const next = patchDeckSlide(deck, 2, edited)
    expect(next[2].table?.rows[0][1]).toBe('12')
    expect(next[2].table?.headers).toEqual(['Metric', 'Value'])
    expect(next[0]).toBe(deck[0])
    expect(next[1]).toBe(deck[1])
  })

  it('delete and add touch that bullet only', () => {
    const removed = deleteSelected(deck[1], { kind: 'bullet', bulletIndex: 0 })
    expect(removed.bullets).toEqual(['Local', 'Private'])
    expect(removed.title).toBe('Why')
    const added = addOnSelected(deck[1], { kind: 'bullet', bulletIndex: 0 })
    expect(added?.body.split('\n')).toHaveLength(4)
    expect(added?.title).toBe('Why')
    expect(addOnSelected(deck[0], { kind: 'title' })).toBeNull()
  })

  it('does not invent text from an empty or deck-shaped reply', () => {
    expect(parseElementReply('', { kind: 'title' })).toBeNull()
    expect(parseElementReply('   ', { kind: 'title' })).toBeNull()
    expect(parseElementReply('{"version":1,"slides":[]}', { kind: 'title' })).toBeNull()
    expect(parseSlideReply('plain leftover')).toBeNull()
  })

  it('takes a title out of a one-slide JSON without using the rest of a deck', () => {
    const raw = JSON.stringify({
      version: 1,
      slides: [
        { layout: 'title', title: 'Only this', body: 'ignore me' },
        { layout: 'bullets', title: 'Other', body: 'no' },
      ],
    })
    expect(parseElementReply(raw, { kind: 'title' })).toBe('Only this')
  })

  it('element and slide instructions never ask for a whole-deck rewrite', () => {
    const element = agentInstruction({
      action: 'rewrite',
      scope: 'element',
      sel: { kind: 'title' },
      extra: '',
    })
    const slide = agentInstruction({
      action: 'improve',
      scope: 'slide',
      sel: null,
      extra: '',
    })
    expect(instructionTouchesWholeDeck(element)).toBe(false)
    expect(instructionTouchesWholeDeck(slide)).toBe(false)
    expect(element.toLowerCase()).not.toContain('whole deck')
    expect(slide.toLowerCase()).not.toContain('whole deck')
  })

  it('enables entire-presentation scope (Apply still needs confirm)', () => {
    expect(ENTIRE_DECK_SCOPE_ENABLED).toBe(true)
  })

  it('history lines name the field', () => {
    expect(historyLine({ source: 'ai', action: 'rewrite', sel: { kind: 'title' }, ko: false })).toBe(
      'AI: rewrote the title',
    )
    expect(historyLine({ source: 'user', sel: { kind: 'title' }, ko: false })).toBe('User: edited the title')
  })
})
