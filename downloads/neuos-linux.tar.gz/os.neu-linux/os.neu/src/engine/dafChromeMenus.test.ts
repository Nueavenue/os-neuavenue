import { describe, expect, it } from 'vitest'
import { pageMenuItems, reorderTabs, TAB_ACTION_IDS, tabMenuItems } from './dafChromeMenus'

describe('dafChromeMenus', () => {
  it('lists the 14 Chrome tab actions', () => {
    expect(TAB_ACTION_IDS).toHaveLength(14)
    const items = tabMenuItems({
      ko: true,
      pinned: false,
      muted: false,
      canReopen: false,
      canClose: true,
      hasOthers: true,
      hasRight: true,
      hasLeft: true,
    })
    expect(items.filter((row) => row.kind === 'item')).toHaveLength(14)
  })

  it('adds Copy and Search when text is selected', () => {
    const items = pageMenuItems({
      ko: true,
      engineLabel: 'SearXNG',
      selection: '오늘 날씨',
      link: '',
      canBack: true,
      canForward: false,
    })
    const ids = items.filter((row) => row.kind === 'item').map((row) => row.id)
    expect(ids[0]).toBe('copy')
    expect(ids[1]).toBe('search-selection')
    expect(ids).toContain('inspect')
  })

  it('moves a tab beside its neighbor', () => {
    const tabs = [{ id: 'a' }, { id: 'b' }, { id: 'c' }]
    expect(reorderTabs(tabs, 'a', 'b', 'after').map((tab) => tab.id)).toEqual(['b', 'a', 'c'])
    expect(reorderTabs(tabs, 'c', 'a', 'before').map((tab) => tab.id)).toEqual(['c', 'a', 'b'])
  })
})
