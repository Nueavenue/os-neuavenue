import { isRepeatingDraft } from './draftText'
import { parsePrompt } from './promptParse'
import { seatIdentity, type SeatAccount, type SeatIdentity } from './seatIdentity'
import { seatPolicy, wantsExternalSend, wantsPageResearch, type SeatPolicy } from './seatPolicy'

/** Local models still stop. This is the machine ceiling, not a 20-line product cap. */
export const SEAT_PREDICT = { small: 1200, large: 4096 } as const

export type SeatStepStatus = 'pending' | 'running' | 'ok' | 'warn' | 'fail' | 'wait'

export type SeatStep = {
  n: number
  name: string
  status: SeatStepStatus
  detail: string
}

export type SeatGate = 'web' | 'send' | null

export type SeatPrepared = {
  request: string
  steps: SeatStep[]
  identity: SeatIdentity
  policy: SeatPolicy
  gate: SeatGate
  plan: string
  webHref: string | null
}

const NAMES = [
  'Intent',
  'Context',
  'Permission',
  'Agent',
  'Plan',
  'Execute',
  'Verify',
  'Approval',
  'Result',
  'Evidence',
] as const

function step(n: number, status: SeatStepStatus, detail: string): SeatStep {
  return { n, name: NAMES[n - 1], status, detail }
}

function pending(from: number): SeatStep[] {
  const rows: SeatStep[] = []
  for (let n = from; n <= 10; n++) rows.push(step(n, 'pending', ''))
  return rows
}

export function prepareSeat(input: {
  text: string
  model: string
  account: SeatAccount | null
  authUserId?: string | null
  phase: string
  online: boolean
  webHref?: string | null
}): SeatPrepared {
  const text = input.text.trim()
  const parsed = parsePrompt(text)
  const identity = seatIdentity({ account: input.account, authUserId: input.authUserId })
  const policy = seatPolicy({ docWrite: true, browserOpenUrl: false })
  const webHref = input.webHref || null
  const snippetSearch = Boolean(webHref || parsed.searchQuery)
  const research = wantsPageResearch(text) && !parsed.factual
  const send = wantsExternalSend(text)
  const gate: SeatGate = send ? 'send' : research ? 'web' : null

  const intent = text
    ? step(
        1,
        'ok',
        parsed.tokens.length
          ? `단어 ${parsed.tokens.length}개 · ${parsed.tokens.join(' · ')} · 언어 ${parsed.language}`
          : '문장 한 건을 일로 남겼습니다. 채팅 말풍선은 결과 파일이 아닙니다.',
      )
    : step(1, 'fail', '문장이 비어 있습니다.')

  const contextBits = [
    identity.kind === 'supabase' ? `로그인 ${identity.email} · id 있음` : identity.reason,
    `화면: ${input.phase || '없음'}`,
    input.online ? '네트워크: 연결됨' : '네트워크: 없음',
    snippetSearch
      ? `프롬프트 검색: ${parsed.searchQuery || '없음'}`
      : research
        ? '이 문장이 요구하는 사업·웹 수치는 이 자리에 없습니다.'
        : '열린 문서의 수치는 이 단계에서 읽지 않습니다.',
  ]
  const context = step(2, identity.kind === 'supabase' ? 'ok' : 'warn', contextBits.join(' '))

  let permission: SeatStep
  if (!text) permission = step(3, 'pending', '')
  else if (send) permission = step(3, 'wait', '메일·결제·게시는 막혀 있습니다. 파일만 쓸지 멈추실지 고르세요.')
  else if (research) permission = step(3, 'wait', '웹 페이지 글은 가져오지 않습니다. 주소만 열거나, 수치 없이 초안만 쓸 수 있습니다.')
  else if (snippetSearch)
    permission = step(3, 'ok', '선택한 검색 엔진 스니펫만 붙입니다. 페이지 본문은 긁지 않습니다.')
  else permission = step(3, 'ok', '파일 쓰기는 허용. 웹 페이지는 열지 않습니다. 외부 전송 없음.')

  const agent = step(
    4,
    text ? 'ok' : 'pending',
    text
      ? `Writer = ${input.model || '없음'}. Checker = 결정적 검사(모델 호출 없음). 다른 모델로 바꾸지 않습니다.`
      : '',
  )

  const plan = [
    `Writer가 고른 모델 하나로 답 전체를 씁니다. 줄 수 상한은 두지 않습니다. 기기 출력 상한은 작은 모델 ${SEAT_PREDICT.small}, 큰 모델 ${SEAT_PREDICT.large} 토큰입니다.`,
    'Checker가 반복, 빈 칸, 입력에 없는 금액을 봅니다.',
    parsed.office
      ? `결과는 ${parsed.office} 앱 본문에 씁니다.`
      : '결과는 화면 텍스트와 문서 파일 하나입니다.',
    snippetSearch ? '프롬프트에 달린 검색 엔진 스니펫을 참고합니다.' : '웹을 보지 않음.',
  ].join('\n')
  const planStep = step(5, text && !gate ? 'ok' : text ? 'wait' : 'pending', text ? plan : '')

  return {
    request: text,
    steps: [intent, context, permission, agent, planStep, ...pending(6)],
    identity,
    policy,
    gate: text ? gate : null,
    plan,
    webHref,
  }
}

export function releaseGate(prepared: SeatPrepared, choice: 'draft' | 'open-url' | 'stop'): SeatPrepared {
  const steps = prepared.steps.map((row) => ({ ...row }))
  const set = (n: number, status: SeatStepStatus, detail: string) => {
    const hit = steps.find((row) => row.n === n)
    if (hit) {
      hit.status = status
      hit.detail = detail
    }
  }
  if (choice === 'stop') {
    set(3, 'fail', '사용자가 이 단계에서 멈췄습니다.')
    set(5, 'fail', '계획이 실행되지 않았습니다.')
    return { ...prepared, steps, gate: null, policy: seatPolicy({ docWrite: false, browserOpenUrl: false }) }
  }
  if (choice === 'open-url') {
    set(3, 'warn', '주소만 엽니다. 페이지 글은 읽지 않았고, 조사했다고 쓰지 않습니다.')
    set(5, 'ok', prepared.plan)
    return {
      ...prepared,
      steps,
      gate: null,
      policy: seatPolicy({ docWrite: true, browserOpenUrl: Boolean(prepared.webHref) }),
    }
  }
  set(3, 'warn', '초안만 씁니다. 웹을 보지 않았고, 입력에 없는 금액은 만들지 않습니다.')
  set(5, 'ok', prepared.plan)
  return { ...prepared, steps, gate: null, policy: seatPolicy({ docWrite: true, browserOpenUrl: false }) }
}

function hasCurrency(text: string) {
  return /(\$|USD|KRW)\s?\d|\d[\d,.]*\s*(원|달러|억|만원)/.test(text)
}

export function judgeSeatText(userText: string, body: string): { ok: boolean; detail: string } {
  const page = body.trim()
  if (!page) return { ok: false, detail: '결과 텍스트가 비어 있습니다.' }
  if (isRepeatingDraft(page) || /(\[insert\s)/i.test(page)) {
    return { ok: false, detail: '같은 문장이나 빈 칸([Insert …])이 반복됩니다. 구조 실패입니다.' }
  }
  if (hasCurrency(page) && !hasCurrency(userText)) {
    return { ok: false, detail: '입력에 없는 금액이 있습니다. 그 숫자는 사실이 아닙니다.' }
  }
  return { ok: true, detail: '구조 검사는 통과입니다. 금액·날짜가 맞다는 뜻이 아닙니다. 웹을 보지 않음.' }
}

export function finishSeat(prepared: SeatPrepared, input: { body: string; modelError?: string }): SeatStep[] {
  const steps = prepared.steps.map((row) => ({ ...row }))
  const set = (n: number, status: SeatStepStatus, detail: string) => {
    const hit = steps.find((row) => row.n === n)
    if (hit) {
      hit.status = status
      hit.detail = detail
    }
  }
  if (prepared.steps.some((row) => row.n === 3 && row.status === 'fail')) {
    set(6, 'fail', '실행하지 않았습니다.')
    set(7, 'fail', '검증할 결과가 없습니다.')
    set(8, 'fail', '승인할 결과가 없습니다.')
    set(9, 'fail', '결과 파일을 만들지 않습니다.')
    set(10, 'ok', evidenceLine(prepared, '멈춤', input.modelError))
    return steps
  }
  if (input.modelError) {
    set(6, 'fail', input.modelError)
    set(7, 'fail', '모델이 글을 쓰지 못해 검증하지 못했습니다.')
    set(8, 'ok', '외부로 보내지 않습니다.')
    set(9, 'fail', '텍스트가 없어 파일을 결과로 치지 않습니다.')
    set(10, 'warn', evidenceLine(prepared, '실패', input.modelError))
    return steps
  }
  const judged = judgeSeatText(prepared.request, input.body)
  set(6, 'ok', `Writer가 텍스트 ${input.body.trim().length}자를 썼습니다.`)
  set(7, judged.ok ? 'ok' : 'fail', judged.detail)
  set(8, 'ok', '승인: 이 기기 화면과 문서 파일만. 메일·결제·게시 없음.')
  set(9, input.body.trim() ? 'ok' : 'fail', input.body.trim() ? '화면 텍스트와 문서 파일에 같은 글을 넣습니다.' : '빈 결과')
  set(10, 'ok', evidenceLine(prepared, judged.ok ? '통과' : '구조 실패', judged.detail))
  return steps
}

export function composeSeatFile(input: { request: string; body: string; plan: string; verdict: string; evidence: string }) {
  return [
    input.body.trim(),
    '',
    '---',
    '요청',
    input.request.trim(),
    '',
    '계획',
    input.plan.trim(),
    '',
    '판정',
    input.verdict.trim(),
    '',
    'Evidence',
    input.evidence.trim(),
    '웹을 보지 않음.',
  ].join('\n')
}

function evidenceLine(prepared: SeatPrepared, verdict: string, extra?: string) {
  const id = prepared.identity.kind === 'supabase' ? prepared.identity.authUserId : 'id 없음'
  const bits = [
    `신원: ${prepared.identity.kind} · ${id}`,
    `Writer 허용 모델은 요청에 적힌 것만`,
    `파일 쓰기: ${prepared.policy['doc.write'] ? '허용' : '거절'}`,
    `주소 열기: ${prepared.policy['browser.open-url'] ? '허용' : '거절'}`,
    `판정: ${verdict}`,
    extra || '',
    '웹을 보지 않음.',
  ]
  return bits.filter(Boolean).join(' · ')
}

export function verdictDetail(steps: SeatStep[]) {
  return steps.find((row) => row.n === 7)?.detail || ''
}

export function evidenceDetail(steps: SeatStep[]) {
  return steps.find((row) => row.n === 10)?.detail || ''
}
