export type GuidePlan = {
  confirm: string
  wantsNet: boolean
  wantsBrowser: boolean
  browseUrl: string | null
  installQuery: string | null
}

export type PendingGuide = GuidePlan & {
  stage: 'confirm' | 'see-page'
}

const YES =
  /^(yes|yeah|yep|yup|ok|okay|sure|please|do it|go ahead|correct|right|맞아|맞아요|응|네|좋아|해줘|부탁|확인|그래)([,.!?…\s].*)?$/i
const NO = /^(no|nope|cancel|stop|nah|아니|아니요|괜찮아|취소|됐어|그만)([,.!?…\s].*)?$/i

export function isAffirmative(raw: string): boolean {
  const t = raw.trim()
  if (!t || t.length > 48) return false
  return YES.test(t)
}

export function isNegative(raw: string): boolean {
  const t = raw.trim()
  if (!t || t.length > 48) return false
  return NO.test(t)
}

export function parseGuide(raw: string): GuidePlan | null {
  const text = raw.trim()
  if (!text) return null
  const wantsNet = /인터넷|네트워크|연결이|online|internet|network/i.test(text)
  const wantsBrowser = /브라우저|browser|크롬|chrome|웹\s*(켜|열|띄)|띄워/i.test(text)
  const wantsInstall = /설치|깔아|깔게|install\b|download|다운/i.test(text)
  const parts = [wantsNet, wantsBrowser, wantsInstall].filter(Boolean).length
  if (parts < 2) return null

  const node = /node\.?js|nodejs|노드/i.test(text)
  const browseUrl = node ? 'https://nodejs.org/en/download' : null
  const installQuery = node ? 'install node.js' : wantsInstall ? text : null

  const bits: string[] = []
  if (wantsNet) bits.push('check the internet')
  if (wantsBrowser) bits.push('open a browser')
  if (node) bits.push('help install Node.js')
  else if (wantsInstall) bits.push('help with the install')

  return {
    confirm: `You want me to ${bits.join(', then ')}. Is that right? Look at this screen and say yes or no.`,
    wantsNet,
    wantsBrowser,
    browseUrl: wantsBrowser ? browseUrl : null,
    installQuery,
  }
}
