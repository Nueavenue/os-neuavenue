import type { Intent } from '../types'

export function classifyIntent(raw: string): Intent {
  const text = raw.trim()
  if (!text) return { kind: 'talk', raw: text }

  if (/레이어|구조|원리|어떻게 작동|구성도|눈과 손|오케스트|layers|how this screen|wie das|cómo funciona|comment ça/i.test(text)) {
    return { kind: 'studio', raw: text }
  }
  if (/설치|깔아|깔게|uninstall|지우|다운로드|다운받|apt install|winget |brew install/i.test(text) && !/인터넷|웹\b|브라우저/i.test(text)) {
    return { kind: 'app-install', raw: text }
  }
  if (/인터넷|브라우저|홈페이지|검색|웹|연결이 안|internet|open the web|abre internet|ouvre internet/i.test(text)) {
    return { kind: 'web', raw: text }
  }
  if (/고장|하드웨어|상태|진단|컴퓨터가 괜찮|화면이 이상|배터리|hardware|computer is ok|device|gerät|ordinateur/i.test(text)) {
    return { kind: 'hardware', raw: text }
  }
  if (/파워포인트|슬라이드|ppt|slides|presentation|프레젠/i.test(text)) {
    return { kind: 'slides', raw: text }
  }
  if (/엑셀|시트|표|보고서|스프레드시트|sheet|excel|spreadsheet|informe|bericht|folha|bảng/i.test(text)) {
    return { kind: 'sheet-report', raw: text }
  }
  if (/워드|문서|메모|글 쓰|리포트|document|doc |memo|documento/i.test(text)) {
    return { kind: 'doc', raw: text }
  }
  return { kind: 'talk', raw: text }
}

export function replyToTalk(raw: string): string {
  if (/안녕|헬로|하이|hello|hi\b|hola|bonjour|ciao/i.test(raw)) {
    return 'Hello. Skip Windows folders. Say one line for what you want.'
  }
  if (/도와|뭐 할|할 수|help|what can/i.test(raw)) {
    return 'Sheet report, document, internet, device health, or the four layers.'
  }
  return `OK. “${raw}” — name a sheet, document, or the web and the hands will move.`
}
