import type { Intent } from '../types'
import { parsePrompt } from './promptParse'

const SLIDES_RE = /파워포인트|슬라이드|프레젠|피피티|\bpptx?\b|\bslides?\b|\bdeck\b|presentation/i
const SHEET_FILE_RE = /엑셀|\bexcel\b|\bxlsx\b|\bcsv\b|스프레드시트|\bspreadsheet\b/i
const SHEET_MAKE_RE =
  /시트\s*(만들|작성|제작|열어|써)|표\s*(만들|제작|작성|뽑아|정리)|open a sheet|write a report/i
const DOC_FILE_RE =
  /워드|\bword\b|\.md\b|\bmarkdown\b|문서|메모|계획서|제안서|백서|기안|\bdocument\b|\bmemo\b|documento/i
const DOC_EN_MAKE_RE = /draft|write (me |a )?(doc|memo|plan|paper)/i
const OPEN_SITE_RE =
  /열어|띄워|사이트|홈페이지|브라우저|인터넷|검색해|검색해서|검색해줘|검색창|구글에서|네이버에서|\bgoogle\b|\bsearch\b|look ?up|open the web|https?:\/\/|www\./i
const WEB_OR_APP_RE = /(웹|앱|\bapps?\b|\bweb\b)/i
const BARE_WEB_QUERY_RE = /^(인터넷|웹|브라우저|사이트|홈페이지|internet|the web)$/i

function wantsSlides(text: string) {
  return SLIDES_RE.test(text)
}

function wantsSheet(text: string) {
  if (wantsSlides(text)) return false
  if (SHEET_FILE_RE.test(text)) return true
  if (SHEET_MAKE_RE.test(text)) return true
  if (/\bsheets?\b/i.test(text) && /report|write|open/i.test(text)) return true
  if (/보고서|리포트|\breport\b/i.test(text) && !/계획서/.test(text) && !DOC_FILE_RE.test(text)) return true
  return false
}

function wantsDoc(text: string) {
  if (wantsSlides(text) || wantsSheet(text)) return false
  return DOC_FILE_RE.test(text) || DOC_EN_MAKE_RE.test(text)
}

function wantsOpenSite(text: string) {
  return OPEN_SITE_RE.test(text)
}

function mentionsWebOrApp(text: string) {
  return WEB_OR_APP_RE.test(text)
}

/** Word / sheet / slides surface from the user's line, or null. */
export function officeSurfaceFromText(text: string): 'doc' | 'sheet' | 'slides' | null {
  const line = text.trim()
  if (!line) return null
  const tagged = parsePrompt(line).office
  if (tagged) return tagged
  if (wantsSlides(line)) return 'slides'
  if (wantsSheet(line)) return 'sheet'
  if (wantsDoc(line)) return 'doc'
  return null
}

export function officeSurface(raw: string): 'doc' | 'sheet' | 'slides' | null {
  const kind = classifyIntent(raw).kind
  if (kind === 'slides') return 'slides'
  if (kind === 'sheet-report') return 'sheet'
  if (kind === 'doc') return 'doc'
  return null
}

export function classifyIntent(raw: string): Intent {
  const text = raw.trim()
  if (!text) return { kind: 'talk', raw: text }

  // Leave the English coach app (highest priority so you can always get out).
  if (/영어\s*(그만|종료|끝|나가|닫)|그만할래|stop english|exit english|quit english|end english/i.test(text)) {
    return { kind: 'english-exit', raw: text }
  }
  // Enter the English study app (explicit — not the catch-all anymore).
  if (
    /영어\s*(공부|연습|회화|말하기|튜터|코치|배우|배울|배워)|영어로\s*(말|대화|연습)|english\s*(practice|lesson|tutor|coach|speaking|conversation)|practice english|teach me english|speak english/i.test(
      text,
    )
  ) {
    return { kind: 'english', raw: text }
  }

  if (/레이어|구조|원리|어떻게 작동|구성도|눈과 손|오케스트|layers|how this screen|wie das|cómo funciona|comment ça/i.test(text)) {
    return { kind: 'studio', raw: text }
  }
  if (/설치|깔아|깔게|uninstall|지우|다운로드|다운받|apt install|winget |brew install/i.test(text) && !/인터넷|웹\b|브라우저/i.test(text)) {
    return { kind: 'app-install', raw: text }
  }
  const office = officeSurfaceFromText(text)
  if (office === 'slides') return { kind: 'slides', raw: text }
  if (office === 'sheet') return { kind: 'sheet-report', raw: text }
  if (office === 'doc') return { kind: 'doc', raw: text }
  if (/고장|하드웨어|상태|진단|컴퓨터가 괜찮|화면이 이상|배터리|hardware|computer is ok|device|gerät|ordinateur/i.test(text)) {
    return { kind: 'hardware', raw: text }
  }
  if (wantsOpenSite(text) || mentionsWebOrApp(text)) {
    const query = extractSearchQuery(text)
    return query ? { kind: 'web', raw: text, query } : { kind: 'web', raw: text }
  }
  return { kind: 'talk', raw: text }
}

/**
 * Pull a search term out of an open-the-web / look-up request.
 * Research verbs like 조사 stay on the in-place console, not daf.neu.
 */
function stripRequestGlue(text: string): string {
  return text
    .replace(/\b(please|can you|could you|google|search for|search|look ?up|find out|find|what is|who is|how much is|tell me about|price of|open)\b/gi, ' ')
    .replace(/(에 ?대해서?|에 ?관해서?|에 ?대한|인터넷에서|웹에서|앱에서|검색해줘|검색해서|검색해|검색창|조사해줘|조사해|찾아줘|찾아봐|찾아|알아봐줘|알아봐|알아보|알려줘|알려|열어줘|열어|띄워|해줘)/g, ' ')
    .replace(/(^|\s)(을|를|이|가|은|는|좀|자세히|뭐야|뭔가요|무엇인가요|무엇|인가요)(?=\s|$)/g, ' ')
    .replace(/[?]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function extractSearchQuery(raw: string): string | null {
  const text = raw.trim()
  if (!text) return null

  const koVerb =
    /(검색해|검색해서|검색해줘|검색창|찾아|찾아줘|알아봐|알아 봐|알아보|서치|열어|열어줘|띄워)/.test(text) ||
    /(에 ?대해|에 ?관해|에 ?대한).*(알려|설명|검색|찾)/.test(text) ||
    /(뭐야|뭔가요|무엇|어떤 ?거|어떤 ?것|누구야|가격|시세|날씨)\??$/.test(text)
  const enVerb = /\b(search|look ?up|google|find( out)?|what is|who is|how much|price of|weather|open)\b/i.test(text)
  const webShaped = OPEN_SITE_RE.test(text) || WEB_OR_APP_RE.test(text)

  if (!koVerb && !enVerb && !webShaped) return null

  const q = stripRequestGlue(text)
  if (q.length < 2) return null
  if (BARE_WEB_QUERY_RE.test(q)) return null
  return q
}

export function replyToTalk(raw: string): string {
  if (/안녕|헬로|하이|hello|hi\b|hola|bonjour|ciao/i.test(raw)) {
    return 'Hello. Skip Windows folders. Say one line for what you want.'
  }
  if (/도와|뭐 할|할 수|help|what can/i.test(raw)) {
    return 'Sheet report, document, internet, device health, or the four layers.'
  }
  return `OK. “${raw}” — name a sheet, document, or the web and the hands will move.`
}
