/**
 * HTML deck slide-order helpers — drag rail + Agent reorder prompts.
 */

const NARRATIVE_KEYS = [
  'cover',
  'problem',
  'pain',
  'solution',
  'product',
  'market',
  'audience',
  'message',
  'channels',
  'architecture',
  'components',
  'technology',
  'business-model',
  'model',
  'traction',
  'metrics',
  'financial',
  'funding',
  'roadmap',
  'timeline',
  'plan',
  'milestones',
  'team',
  'governance',
  'risks',
  'ask',
  'next',
  'closing',
  'resources',
] as const

export function narrativeRank(id: string): number {
  const lower = String(id || '').toLowerCase()
  let best = 900
  NARRATIVE_KEYS.forEach((k, idx) => {
    if (lower.includes(k)) best = Math.min(best, idx)
  })
  return best
}

export function autoNarrativeOrder(ids: string[]): string[] {
  return ids
    .map((id, idx) => ({ id, r: narrativeRank(id), idx }))
    .sort((a, b) => a.r - b.r || a.idx - b.idx)
    .map((row) => row.id)
}

export function moveIdOrder(ids: string[], from: number, to: number): string[] {
  if (from < 0 || to < 0 || from >= ids.length || to >= ids.length || from === to) return ids.slice()
  const next = ids.slice()
  const [row] = next.splice(from, 1)
  next.splice(to, 0, row)
  return next
}

export function applyIdOrder(current: string[], preferred: string[]): string[] {
  const map = new Set(current)
  const next: string[] = []
  preferred.forEach((id) => {
    if (map.has(id)) {
      next.push(id)
      map.delete(id)
    }
  })
  current.forEach((id) => {
    if (map.has(id)) next.push(id)
  })
  return next
}

export type ReorderIntent =
  | { type: 'auto'; order: string[] }
  | { type: 'move'; order: string[]; from?: number; to?: number }
  | { type: 'list'; order: string[] }

export function parseReorderIntent(instruction: string, slideIds: string[]): ReorderIntent | null {
  const text = String(instruction || '').trim()
  if (!text || !slideIds.length) return null
  if (/자동\s*순서|auto\s*order|narrative\s*order|순서\s*정렬/i.test(text)) {
    return { type: 'auto', order: autoNarrativeOrder(slideIds) }
  }
  if (/표지\s*를?\s*맨\s*앞|cover\s*first|표지를\s*맨\s*앞으로/i.test(text)) {
    const cover = slideIds.find((id) => /cover|표지/.test(id)) || slideIds[0]
    return { type: 'move', order: [cover, ...slideIds.filter((id) => id !== cover)] }
  }
  const m = text.match(/(\d+)\s*번\s*(?:을|를)?\s*(\d+)\s*번\s*(?:으로|뒤로|앞에)?\s*이동/)
  if (m) {
    const from = Number(m[1]) - 1
    const to = Number(m[2]) - 1
    if (from >= 0 && from < slideIds.length && to >= 0 && to < slideIds.length) {
      return { type: 'move', order: moveIdOrder(slideIds, from, to), from, to }
    }
  }
  const m2 = text.match(/순서\s*[:：]\s*(.+)/i)
  if (m2) {
    const tokens = m2[1]
      .split(/[→,>\s]+/)
      .map((t) => t.trim())
      .filter(Boolean)
    if (tokens.length >= 2) {
      const preferred = tokens.filter((t) => slideIds.includes(t))
      if (preferred.length) return { type: 'list', order: applyIdOrder(slideIds, preferred) }
    }
  }
  return null
}
