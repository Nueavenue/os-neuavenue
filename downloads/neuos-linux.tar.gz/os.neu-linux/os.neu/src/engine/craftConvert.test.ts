import { describe, expect, it } from 'vitest'
import {
  craftConvertArgv,
  craftIoExt,
  craftSandboxRoot,
  isAllowedCraftCli,
  joinCraftPath,
  prepareCraftConvert,
  sheetDisplayCsv,
  writerBodyOnly,
} from './craftConvert'

const SANDBOX = '/home/billy/.local/share/os.neu/craft'

describe('craftConvert maps and argv', () => {
  it('maps doc → .md/.docx, sheet → .csv/.xlsx, slides → .md/.pptx', () => {
    expect(craftIoExt('doc')).toEqual({ inExt: '.md', outExt: '.docx' })
    expect(craftIoExt('sheet')).toEqual({ inExt: '.csv', outExt: '.xlsx' })
    expect(craftIoExt('slides')).toEqual({ inExt: '.md', outExt: '.pptx' })
  })

  it('argv is convert + relative names only', () => {
    expect(craftConvertArgv('plan.md', 'plan.docx')).toEqual(['convert', 'plan.md', 'plan.docx'])
    const prep = prepareCraftConvert({ sandbox: SANDBOX, surface: 'doc', title: '계획서', body: '본문' })
    if ('error' in prep) throw new Error('expected prep')
    expect(prep.argv).toEqual(['convert', prep.inRel, prep.outRel])
    expect(prep.argv[0]).toBe('convert')
    expect(prep.argv).not.toContain('run')
    expect(prep.argv.join(' ')).not.toContain('--cmd')
  })
})

describe('sandbox join rejects escape', () => {
  it('fails ../etc/passwd style and does not return a write path', () => {
    expect(joinCraftPath(SANDBOX, '../etc/passwd')).toBeNull()
    expect(joinCraftPath(SANDBOX, '/etc/passwd')).toBeNull()
    expect(joinCraftPath(SANDBOX, 'foo/../../etc/passwd')).toBeNull()
    expect(joinCraftPath(SANDBOX, '..\\etc\\passwd')).toBeNull()
  })

  it('keeps a sanitized title under the sandbox', () => {
    const prep = prepareCraftConvert({
      sandbox: SANDBOX,
      surface: 'doc',
      title: '../etc/passwd',
      body: 'ok',
    })
    if ('error' in prep) throw new Error('expected sanitized prep')
    expect(prep.inPath.startsWith(`${SANDBOX}/`)).toBe(true)
    expect(prep.outPath.startsWith(`${SANDBOX}/`)).toBe(true)
    expect(prep.inRel.includes('..')).toBe(false)
    expect(prep.outRel.endsWith('.docx')).toBe(true)
  })

  it('sandbox root is XDG or ~/.local/share/os.neu/craft — not the git tree', () => {
    expect(craftSandboxRoot({ XDG_DATA_HOME: '/var/data' })).toBe('/var/data/os.neu/craft')
    expect(craftSandboxRoot({ HOME: '/home/billy' })).toBe('/home/billy/.local/share/os.neu/craft')
    expect(craftSandboxRoot({ HOME: '/home/billy' }).includes('/neuOS/')).toBe(false)
  })
})

describe('writerBodyOnly + sheet display CSV', () => {
  it('drops the Seat 10-step appendix from convert input', () => {
    const raw = '계획서 본문입니다.\n---\n요청\n계획서 작성해줘'
    expect(writerBodyOnly(raw)).toBe('계획서 본문입니다.')
    const prep = prepareCraftConvert({ sandbox: SANDBOX, surface: 'doc', title: '계획서', body: raw })
    if ('error' in prep) throw new Error('expected prep')
    expect(prep.inputText).toBe('계획서 본문입니다.')
    expect(prep.inputText).not.toContain('요청')
  })

  it('sheet CSV is parseSheetGrid display cells, not formulas', () => {
    const body = ['| = A1 | = 월 |', '| = B1 | = 매출 |', '| = A2 | = 1월 | =B2 | = 50 |'].join('\n')
    const csv = sheetDisplayCsv(body)
    expect(csv).toBe('월,매출\n1월,50')
    expect(csv).not.toContain('=A1')
    expect(csv).not.toContain('= B1')
    const prep = prepareCraftConvert({ sandbox: SANDBOX, surface: 'sheet', title: '엑셀 표', body })
    if ('error' in prep) throw new Error('expected prep')
    expect(prep.inRel.endsWith('.csv')).toBe(true)
    expect(prep.outRel.endsWith('.xlsx')).toBe(true)
    expect(prep.inputText).toBe('월,매출\n1월,50')
  })
})

describe('allowed CLI basename', () => {
  it('accepts only wordcraft-cli / gridcraft-cli / deckcraft-cli', () => {
    expect(isAllowedCraftCli('/usr/bin/wordcraft-cli')).toBe(true)
    expect(isAllowedCraftCli('/opt/gridcraft-cli')).toBe(true)
    expect(isAllowedCraftCli('/home/x/deckcraft-cli')).toBe(true)
    expect(isAllowedCraftCli('/usr/bin/bash')).toBe(false)
    expect(isAllowedCraftCli('wordcraft-cli')).toBe(false)
    expect(isAllowedCraftCli('/tmp/../usr/bin/wordcraft-cli')).toBe(false)
  })
})
