/** Small markdown → safe HTML for the in-app manual card. No raw HTML. */

function escapeHtml(text: string) {
  return text
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
}

function inline(text: string) {
  const escaped = escapeHtml(text)
  return escaped
    .replaceAll(/`([^`]+)`/g, '<code>$1</code>')
    .replaceAll(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replaceAll(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
}

export function markdownToHtml(source: string) {
  const lines = source.replaceAll('\r\n', '\n').split('\n')
  const out: string[] = []
  let list: 'ul' | 'ol' | false = false
  let fence = false

  const closeList = () => {
    if (list) {
      out.push(list === 'ol' ? '</ol>' : '</ul>')
      list = false
    }
  }

  const openList = (kind: 'ul' | 'ol') => {
    if (list !== kind) {
      closeList()
      out.push(kind === 'ol' ? '<ol>' : '<ul>')
      list = kind
    }
  }

  for (const raw of lines) {
    const line = raw.trimEnd()
    if (line.trim().startsWith('```')) {
      closeList()
      if (!fence) {
        fence = true
        out.push('<pre><code>')
      } else {
        fence = false
        out.push('</code></pre>')
      }
      continue
    }
    if (fence) {
      out.push(`${escapeHtml(line)}\n`)
      continue
    }
    if (!line.trim()) {
      closeList()
      continue
    }
    if (line.startsWith('### ')) {
      closeList()
      out.push(`<h3>${inline(line.slice(4))}</h3>`)
      continue
    }
    if (line.startsWith('## ')) {
      closeList()
      out.push(`<h2>${inline(line.slice(3))}</h2>`)
      continue
    }
    if (line.startsWith('# ')) {
      closeList()
      out.push(`<h1>${inline(line.slice(2))}</h1>`)
      continue
    }
    if (line.startsWith('- ') || line.startsWith('* ')) {
      openList('ul')
      out.push(`<li>${inline(line.slice(2))}</li>`)
      continue
    }
    const numbered = line.match(/^(\d+)\.\s+(.*)$/)
    if (numbered) {
      openList('ol')
      out.push(`<li>${inline(numbered[2])}</li>`)
      continue
    }
    closeList()
    out.push(`<p>${inline(line)}</p>`)
  }
  closeList()
  if (fence) out.push('</code></pre>')
  return out.join('')
}

export const MANUAL_DOC = '/docs/manual.md'
export const MANUAL_DOC_EN = '/docs/manual.en.md'
export const DOCS_HOME = 'https://docs.neuavenue.com'
export const DOCS_MANUAL = `${DOCS_HOME}/manual.md`
export const DOCS_MANUAL_EN = `${DOCS_HOME}/manual.en.md`

export async function fetchManualMarkdown(locale: string) {
  const local = locale === 'ko' ? MANUAL_DOC : MANUAL_DOC_EN
  const remote = locale === 'ko' ? DOCS_MANUAL : DOCS_MANUAL_EN
  for (const url of [local, remote]) {
    try {
      const res = await fetch(url)
      if (res.ok) return await res.text()
    } catch {
      /* try next */
    }
  }
  return null
}
