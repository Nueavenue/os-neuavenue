import { describe, expect, it } from 'vitest'
import { detectCraftBins } from './craftDetect'
import { craftHintLine, planCraftJob } from './craftPlan'
import { officeSurface } from './intents'

const absent = detectCraftBins({})
const present = detectCraftBins({
  'wordcraft-cli': '/mock/wordcraft-cli',
  'gridcraft-cli': '/mock/gridcraft-cli',
  'deckcraft-cli': '/mock/deckcraft-cli',
})

describe('planCraftJob from officeSurface', () => {
  it('계획서 작성해줘 → word · .docx · planned or unavailable', () => {
    expect(officeSurface('계획서 작성해줘')).toBe('doc')
    const missing = planCraftJob(officeSurface('계획서 작성해줘'), absent)
    expect(missing.kind).toBe('word')
    expect(missing.cliName).toBe('wordcraft-cli')
    expect(missing.outExt).toBe('.docx')
    expect(missing.status).toBe('unavailable')
    expect(missing.reason).toBe('cli-missing')
    const ready = planCraftJob(officeSurface('계획서 작성해줘'), present)
    expect(ready.status).toBe('planned-not-run')
    expect(ready.reason).toBe('cli-ready')
    expect(ready.cliPath).toBe('/mock/wordcraft-cli')
  })

  it('엑셀 표 제작해줘 → grid · .xlsx', () => {
    expect(officeSurface('엑셀 표 제작해줘')).toBe('sheet')
    const job = planCraftJob(officeSurface('엑셀 표 제작해줘'), absent)
    expect(job.kind).toBe('grid')
    expect(job.cliName).toBe('gridcraft-cli')
    expect(job.outExt).toBe('.xlsx')
  })

  it('슬라이드 만들어줘 → deck · .pptx', () => {
    expect(officeSurface('슬라이드 만들어줘')).toBe('slides')
    const job = planCraftJob(officeSurface('슬라이드 만들어줘'), present)
    expect(job.kind).toBe('deck')
    expect(job.cliName).toBe('deckcraft-cli')
    expect(job.outExt).toBe('.pptx')
    expect(job.status).toBe('planned-not-run')
  })

  it('skips talk with no office intent', () => {
    const job = planCraftJob(officeSurface('안녕하세요'), absent)
    expect(job.kind).toBe('skip')
    expect(job.reason).toBe('no-office-intent')
    expect(job.outExt).toBeNull()
  })
})

describe('craftHintLine converted / convert-failed', () => {
  it('names converted path and convert-failed without claiming a write', () => {
    const ready = planCraftJob(officeSurface('계획서 작성해줘'), present)
    const converted = craftHintLine({ ...ready, status: 'converted', reason: 'converted', outPath: '/home/x/.local/share/os.neu/craft/plan.docx' }, true)
    expect(converted).toContain('status=converted')
    expect(converted).toContain('/home/x/.local/share/os.neu/craft/plan.docx')
    const failed = craftHintLine({ ...ready, status: 'convert-failed', reason: 'convert-failed' }, true)
    expect(failed).toContain('status=convert-failed')
    expect(failed).toContain('변환 실패')
    const sides = craftHintLine({ ...ready, mcp: 'skip', web: 'missing' }, true)
    expect(sides).toContain('mcp: skip')
    expect(sides).toContain('web: missing')
    const ok = craftHintLine({ ...ready, mcp: 'ping-ok', web: 'ready', webHref: 'http://127.0.0.1:4178/craft-web/' }, true)
    expect(ok).toContain('mcp: ping-ok')
    expect(ok).toContain('web: ready')
    const forbidden = /wordcraft|gridcraft|deckcraft|WordCraft|GridCraft|DeckCraft|craft:/i
    expect(converted).not.toMatch(forbidden)
    expect(failed).not.toMatch(forbidden)
    expect(sides).not.toMatch(forbidden)
    expect(ok).not.toMatch(forbidden)
    expect(craftHintLine(ready, false)).not.toMatch(forbidden)
  })
})
