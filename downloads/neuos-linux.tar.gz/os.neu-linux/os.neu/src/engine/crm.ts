export type CrmSectionId =
  | 'promotion'
  | 'campaign'
  | 'audience'
  | 'marketing'
  | 'email'
  | 'feedback'
  | 'monitor'
  | 'admin'

export type CrmSection = {
  id: CrmSectionId
  label: string
  labelEn: string
  kicker: string
  kickerEn: string
}

export const CRM_SECTIONS: CrmSection[] = [
  { id: 'promotion', label: '프로모션', labelEn: 'Promotion', kicker: '제안 · 기간 · 혜택', kickerEn: 'Offer, dates, perk' },
  { id: 'campaign', label: '캠페인', labelEn: 'Campaign', kicker: '이름 · 상태 · 일정', kickerEn: 'Name, status, dates' },
  { id: 'audience', label: '타겟 고객', labelEn: 'Audience', kicker: '세그먼트 · 규모', kickerEn: 'Segments and size' },
  { id: 'marketing', label: '마케팅', labelEn: 'Marketing', kicker: '채널 · 메시지', kickerEn: 'Channels and copy' },
  { id: 'email', label: '이메일 배포', labelEn: 'Email', kicker: '초안 · 발송 대기', kickerEn: 'Draft and queue' },
  { id: 'feedback', label: '피드백', labelEn: 'Feedback', kicker: '응답 · 점수', kickerEn: 'Replies and score' },
  { id: 'monitor', label: '모니터링', labelEn: 'Monitor', kicker: '도달 · 전환', kickerEn: 'Reach and conversion' },
  { id: 'admin', label: '관리자', labelEn: 'Admin', kicker: '권한 · 팀', kickerEn: 'Roles and team' },
]

export type CrmStage = 'todo' | 'now' | 'done'

export function pipelineStages(active: CrmSectionId): { id: CrmSectionId; stage: CrmStage }[] {
  const index = CRM_SECTIONS.findIndex((row) => row.id === active)
  return CRM_SECTIONS.map((row, i) => ({
    id: row.id,
    stage: i < index ? 'done' : i === index ? 'now' : 'todo',
  }))
}

export const CRM_PROMOS = [
  { name: '봄 심기', nameEn: 'Spring plant', perk: 'USB 가이드 묶음', perkEn: 'USB guide bundle', until: '2026-04-30', state: 'live' },
  { name: '게스트 체험', nameEn: 'Guest try', perk: '지금 화면만', perkEn: 'This screen only', until: '2026-06-15', state: 'draft' },
]

export const CRM_CAMPAIGNS = [
  { name: 'OS.neu v1.0 안내', nameEn: 'OS.neu v1.0 note', status: 'running', reach: '1.2k', until: '2026-09-12' },
  { name: '공개 AI 받기', nameEn: 'Get public AI', status: 'queued', reach: '—', until: '2026-10-01' },
]

export const CRM_SEGMENTS = [
  { name: '이 기기 사용자', nameEn: 'This machine', size: '1', note: '로컬 콘솔', noteEn: 'Local console' },
  { name: '게스트 체험', nameEn: 'Guest path', size: '—', note: '심지 않음', noteEn: 'Not planted' },
  { name: 'USB 굽기', nameEn: 'USB burn', size: '—', note: '이동 설치', noteEn: 'Portable plant' },
]

export const CRM_CHANNELS = [
  { id: 'mail', label: '이메일', labelEn: 'Email' },
  { id: 'inapp', label: '콘솔 알림', labelEn: 'Console note' },
  { id: 'web', label: '공개 페이지', labelEn: 'Public page' },
]

export const CRM_FEEDBACK = [
  { who: '콘솔', whoEn: 'Console', score: 5, note: '하드웨어 칸이 잘 열립니다.', noteEn: 'Hardware tile opens cleanly.' },
  { who: '게스트', whoEn: 'Guest', score: 4, note: '대화가 왼쪽에 붙어 있었습니다.', noteEn: 'Chat sat on the left.' },
]

export const CRM_KPIS = [
  { id: 'reach', label: '도달', labelEn: 'Reach', value: '—', hint: '저장 전' },
  { id: 'send', label: '발송', labelEn: 'Sent', value: '0', hint: '대기' },
  { id: 'open', label: '열람', labelEn: 'Opened', value: '—', hint: '연동 전' },
  { id: 'reply', label: '응답', labelEn: 'Replies', value: '2', hint: '화면 예시' },
]

export const CRM_TEAM = [
  { name: '운영', nameEn: 'Ops', role: '관리자', roleEn: 'Admin' },
  { name: '마케터', nameEn: 'Marketer', role: '캠페인', roleEn: 'Campaign' },
  { name: '읽기', nameEn: 'Viewer', role: '모니터링', roleEn: 'Monitor' },
]
