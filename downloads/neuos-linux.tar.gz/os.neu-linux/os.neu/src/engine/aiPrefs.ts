import { cloudCard, officeModelList } from './cloudModels'
import { LOCAL_LLM_CATALOG } from './llmCatalog'
import type { LlmSettingsView } from './llmConnect'

/** Settings › AI & Usage and Privacy & Permissions. Kept on this device only. */

export type AiPrefs = {
  /** Model ids shown in Docs / Sheets / Slides pickers. Empty = not configured yet. */
  shown: string[]
  defaultModel: string
  /** Office AI requests per day. 0 = no limit. */
  dailyLimit: number
  confirmFirstSend: boolean
  /** Cloud vendors the user already agreed to send text to. */
  consented: string[]
  /** Home power page: use a model already on this PC. Does not install one. */
  localService: boolean
  /** 'web-cache' is stored only. Offline web apps are not built. */
  draftMode: 'local' | 'web-cache'
}

export type AiUsage = {
  day: string
  dayCount: number
  month: string
  monthCount: number
  monthChars: number
}

export type PermissionLogRow = { at: number; textKo: string; textEn: string }

export type ModelOption = {
  id: string
  label: string
  kind: 'cloud' | 'local'
  vendorId: string
  vendor: string
}

const PREFS_KEY = 'os.neu.ai.prefs'
const USAGE_KEY = 'os.neu.ai.usage'
const LOG_KEY = 'os.neu.ai.permissionLog'
const LOG_MAX = 40

export const DEFAULT_AI_PREFS: AiPrefs = {
  shown: [],
  defaultModel: '',
  dailyLimit: 200,
  confirmFirstSend: true,
  consented: [],
  localService: false,
  draftMode: 'local',
}

function store(): Storage | null {
  return typeof localStorage === 'undefined' ? null : localStorage
}

function readJson<T>(key: string, fallback: T, storage: Storage | null): T {
  try {
    const raw = storage?.getItem(key)
    return raw ? { ...fallback, ...(JSON.parse(raw) as T) } : fallback
  } catch {
    return fallback
  }
}

export function loadAiPrefs(storage: Storage | null = store()): AiPrefs {
  const row = readJson(PREFS_KEY, DEFAULT_AI_PREFS, storage)
  return {
    shown: Array.isArray(row.shown) ? row.shown.filter((id) => typeof id === 'string') : [],
    defaultModel: typeof row.defaultModel === 'string' ? row.defaultModel : '',
    dailyLimit: Number.isFinite(row.dailyLimit) && row.dailyLimit >= 0 ? Math.floor(row.dailyLimit) : 200,
    confirmFirstSend: row.confirmFirstSend !== false,
    consented: Array.isArray(row.consented) ? row.consented.filter((id) => typeof id === 'string') : [],
    localService: row.localService === true,
    draftMode: row.draftMode === 'web-cache' ? 'web-cache' : 'local',
  }
}

export function saveAiPrefs(next: AiPrefs, storage: Storage | null = store()) {
  storage?.setItem(PREFS_KEY, JSON.stringify(next))
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('osneu:ai-prefs'))
}

export function patchAiPrefs(patch: Partial<AiPrefs>, storage: Storage | null = store()): AiPrefs {
  const next = { ...loadAiPrefs(storage), ...patch }
  saveAiPrefs(next, storage)
  return next
}

export function allModelOptions(): ModelOption[] {
  const office = officeModelList().map((row): ModelOption => {
    const card = cloudCard(row.id)
    if (card) return { id: row.id, label: row.label, kind: 'cloud', vendorId: card.vendorId, vendor: card.vendor }
    if (row.id.startsWith('gpt-')) return { id: row.id, label: row.label, kind: 'cloud', vendorId: 'openai', vendor: 'OpenAI' }
    return { id: row.id, label: row.label, kind: 'local', vendorId: 'local', vendor: 'os.neu' }
  })
  const local = LOCAL_LLM_CATALOG.filter((row) => row.id !== 'llama3.2:1b').map(
    (row): ModelOption => ({ id: row.id, label: row.label, kind: 'local', vendorId: 'local', vendor: 'os.neu' }),
  )
  return [...office, ...local]
}

export function modelOption(id: string): ModelOption | undefined {
  return allModelOptions().find((row) => row.id === id)
}

/** Key present (cloud) or installed (local). Not a live test. */
export function modelReady(id: string, view: LlmSettingsView | null): boolean {
  if (!view) return false
  const row = modelOption(id)
  if (!row) return false
  if (row.kind === 'cloud') {
    if (row.vendorId === 'openai') return Boolean(view.hasKey)
    return Boolean(view.vendorHas?.[row.vendorId] || view.vendorHints?.[row.vendorId])
  }
  const installed = view.installed || []
  if (id === 'os.neu-local') return installed.some((name) => name.startsWith('llama3.2'))
  return installed.includes(id)
}

/**
 * Models for pickers: the user's Settings list in catalog order.
 * Empty Settings list = show the full catalog so Docs / Sheets / Slides stay selectable
 * before the user has ticked anything (first-run / fresh install).
 * Always keeps the current model so a select never goes blank.
 */
export function shownModelOptions(prefs: AiPrefs, current?: string): ModelOption[] {
  const all = allModelOptions()
  const picked = prefs.shown.length ? all.filter((row) => prefs.shown.includes(row.id)) : [...all]
  if (current && !picked.some((row) => row.id === current)) {
    const extra = all.find((row) => row.id === current)
    if (extra) picked.push(extra)
  }
  return picked
}

function dayKey(at: Date) {
  return `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, '0')}-${String(at.getDate()).padStart(2, '0')}`
}

export function loadUsage(storage: Storage | null = store(), now = new Date()): AiUsage {
  const empty: AiUsage = { day: dayKey(now), dayCount: 0, month: dayKey(now).slice(0, 7), monthCount: 0, monthChars: 0 }
  const row = readJson(USAGE_KEY, empty, storage)
  const day = dayKey(now)
  const month = day.slice(0, 7)
  return {
    day,
    dayCount: row.day === day ? row.dayCount : 0,
    month,
    monthCount: row.month === month ? row.monthCount : 0,
    monthChars: row.month === month ? row.monthChars : 0,
  }
}

export function recordUsage(chars: number, countRequest: boolean, storage: Storage | null = store(), now = new Date()) {
  const row = loadUsage(storage, now)
  const next: AiUsage = {
    ...row,
    dayCount: row.dayCount + (countRequest ? 1 : 0),
    monthCount: row.monthCount + (countRequest ? 1 : 0),
    monthChars: row.monthChars + Math.max(0, Math.floor(chars)),
  }
  storage?.setItem(USAGE_KEY, JSON.stringify(next))
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('osneu:ai-usage'))
  return next
}

/** Rough token estimate from characters. Shown as an estimate, never as a bill. */
export function approxTokens(chars: number) {
  return Math.round(chars / 4)
}

export function loadPermissionLog(storage: Storage | null = store()): PermissionLogRow[] {
  try {
    const raw = storage?.getItem(LOG_KEY)
    const rows = raw ? (JSON.parse(raw) as PermissionLogRow[]) : []
    return Array.isArray(rows) ? rows : []
  } catch {
    return []
  }
}

export function logPermission(textKo: string, textEn: string, storage: Storage | null = store()) {
  const rows = [{ at: Date.now(), textKo, textEn }, ...loadPermissionLog(storage)].slice(0, LOG_MAX)
  storage?.setItem(LOG_KEY, JSON.stringify(rows))
}

export function clearPermissionLog(storage: Storage | null = store()) {
  storage?.setItem(LOG_KEY, '[]')
}

export type GateResult = { ok: true } | { ok: false; reason: string }

export function dailyLimitMessage(limit: number) {
  return `daily-limit · 오늘 AI 요청 상한(${limit}회)에 도달했습니다. 설정 › AI 및 사용량에서 바꿀 수 있습니다.`
}

export function limitedReasonFromBridge(body: { reason?: string; limit?: number } | null | undefined): string | null {
  if (!body || body.reason !== 'limited') return null
  const limit = Number.isFinite(body.limit) && (body.limit as number) > 0 ? Number(body.limit) : 200
  return dailyLimitMessage(limit)
}

/** A model id, or a fixed cloud vendor for services that ignore the chosen model (coach, speech-to-text). */
export type GateTarget = { model: string } | { vendorId: string; vendor: string }

export function askFirstSend(vendor: string, whatKo: string, whatEn: string): boolean {
  if (typeof window === 'undefined' || typeof window.confirm !== 'function') return false
  return window.confirm(
    `${vendor}(으)로 ${whatKo}을(를) 보냅니다. 계속할까요?\n회사마다 처음 한 번만 묻습니다. 설정 › 개인정보와 권한에서 바꿀 수 있습니다.\n\nThis sends ${whatEn} to ${vendor}. Continue?`,
  )
}

/**
 * Runs before every AI request: daily limit (hard stop) and first send to each cloud vendor.
 * `ask` is the consent prompt; returns true when the user agrees.
 */
export function gateAiRequest(
  target: GateTarget,
  ask: (vendor: string) => boolean,
  storage: Storage | null = store(),
  now = new Date(),
): GateResult {
  const prefs = loadAiPrefs(storage)
  const usage = loadUsage(storage, now)
  if (prefs.dailyLimit > 0 && usage.dayCount >= prefs.dailyLimit) {
    logPermission(`하루 상한 ${prefs.dailyLimit}회에 도달해 요청을 막음`, `Blocked: daily limit ${prefs.dailyLimit} reached`, storage)
    return {
      ok: false,
      reason: dailyLimitMessage(prefs.dailyLimit),
    }
  }
  const row =
    'model' in target
      ? modelOption(target.model)
      : { kind: 'cloud' as const, vendorId: target.vendorId, vendor: target.vendor }
  if (row?.kind === 'cloud' && prefs.confirmFirstSend && !prefs.consented.includes(row.vendorId)) {
    if (!ask(row.vendor)) {
      logPermission(`${row.vendor}로 보내기 거절`, `Declined sending to ${row.vendor}`, storage)
      return { ok: false, reason: `consent-declined · ${row.vendor}로 보내지 않았습니다.` }
    }
    saveAiPrefs({ ...prefs, consented: [...prefs.consented, row.vendorId] }, storage)
    logPermission(`${row.vendor}로 보내기 허용`, `Allowed sending to ${row.vendor}`, storage)
  }
  return { ok: true }
}

export function gateOfficeRequest(
  model: string,
  ask: (vendor: string) => boolean,
  storage: Storage | null = store(),
  now = new Date(),
): GateResult {
  return gateAiRequest({ model }, ask, storage, now)
}
