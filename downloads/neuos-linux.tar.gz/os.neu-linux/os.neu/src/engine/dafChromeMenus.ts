export type PopupItem =
  | { kind: 'sep'; id: string }
  | { kind: 'item'; id: string; label: string; enabled?: boolean }

export type TabActionId =
  | 'new-right'
  | 'reopen'
  | 'duplicate'
  | 'pin'
  | 'mute'
  | 'close'
  | 'close-others'
  | 'close-right'
  | 'close-left'
  | 'move-window'
  | 'new-group'
  | 'reading-list'
  | 'bookmark-all'
  | 'send'

export type PageActionId =
  | 'copy'
  | 'search-selection'
  | 'back'
  | 'forward'
  | 'reload'
  | 'save-as'
  | 'print'
  | 'translate'
  | 'open-link-tab'
  | 'open-link-window'
  | 'open-link-private'
  | 'save-link'
  | 'copy-link'
  | 'view-source'
  | 'inspect'

export const TAB_ACTION_IDS: TabActionId[] = [
  'new-right',
  'reopen',
  'duplicate',
  'pin',
  'mute',
  'close',
  'close-others',
  'close-right',
  'close-left',
  'move-window',
  'new-group',
  'reading-list',
  'bookmark-all',
  'send',
]

export function tabMenuItems(opts: {
  ko: boolean
  pinned: boolean
  muted: boolean
  canReopen: boolean
  canClose: boolean
  hasOthers: boolean
  hasRight: boolean
  hasLeft: boolean
}): PopupItem[] {
  const { ko } = opts
  return [
    { kind: 'item', id: 'new-right', label: ko ? '오른쪽에 새 탭' : 'New tab to the right' },
    { kind: 'item', id: 'reopen', label: ko ? '닫은 탭 다시 열기' : 'Reopen closed tab', enabled: opts.canReopen },
    { kind: 'sep', id: 'sep-1' },
    { kind: 'item', id: 'duplicate', label: ko ? '탭 복제' : 'Duplicate' },
    { kind: 'item', id: 'pin', label: opts.pinned ? (ko ? '탭 고정 해제' : 'Unpin tab') : ko ? '탭 고정' : 'Pin tab' },
    {
      kind: 'item',
      id: 'mute',
      label: opts.muted ? (ko ? '사이트 음소거 해제' : 'Unmute site') : ko ? '사이트 음소거' : 'Mute site',
    },
    { kind: 'sep', id: 'sep-2' },
    { kind: 'item', id: 'close', label: ko ? '탭 닫기' : 'Close tab', enabled: opts.canClose },
    { kind: 'item', id: 'close-others', label: ko ? '다른 탭 닫기' : 'Close other tabs', enabled: opts.hasOthers },
    { kind: 'item', id: 'close-right', label: ko ? '오른쪽 탭 닫기' : 'Close tabs to the right', enabled: opts.hasRight },
    { kind: 'item', id: 'close-left', label: ko ? '왼쪽 탭 닫기' : 'Close tabs to the left', enabled: opts.hasLeft },
    { kind: 'sep', id: 'sep-3' },
    { kind: 'item', id: 'move-window', label: ko ? '새 창으로 탭 이동' : 'Move tab to new window' },
    { kind: 'item', id: 'new-group', label: ko ? '새 그룹에 탭 추가' : 'Add tab to new group' },
    { kind: 'item', id: 'reading-list', label: ko ? '읽기 목록에 추가' : 'Add to reading list' },
    { kind: 'item', id: 'bookmark-all', label: ko ? '모든 탭 북마크' : 'Bookmark all tabs' },
    { kind: 'item', id: 'send', label: ko ? '다른 기기로 보내기' : 'Send to your devices' },
  ]
}

export function pageMenuItems(opts: {
  ko: boolean
  engineLabel: string
  selection: string
  link: string
  canBack: boolean
  canForward: boolean
}): PopupItem[] {
  const { ko } = opts
  const clip = opts.selection.trim()
  const shown = clip.length > 24 ? `${clip.slice(0, 24)}…` : clip
  const items: PopupItem[] = []
  if (clip) {
    items.push({ kind: 'item', id: 'copy', label: ko ? '복사' : 'Copy' })
    items.push({
      kind: 'item',
      id: 'search-selection',
      label: ko ? `${opts.engineLabel}에서 "${shown}" 검색` : `Search ${opts.engineLabel} for "${shown}"`,
    })
    items.push({ kind: 'sep', id: 'sep-sel' })
  }
  items.push(
    { kind: 'item', id: 'back', label: ko ? '뒤로' : 'Back', enabled: opts.canBack },
    { kind: 'item', id: 'forward', label: ko ? '앞으로' : 'Forward', enabled: opts.canForward },
    { kind: 'item', id: 'reload', label: ko ? '새로고침' : 'Reload' },
    { kind: 'sep', id: 'sep-nav' },
    { kind: 'item', id: 'save-as', label: ko ? '다른 이름으로 저장…' : 'Save as…' },
    { kind: 'item', id: 'print', label: ko ? '인쇄…' : 'Print…' },
    { kind: 'item', id: 'translate', label: ko ? '한국어로 번역' : 'Translate to English' },
  )
  if (opts.link) {
    items.push(
      { kind: 'sep', id: 'sep-link' },
      { kind: 'item', id: 'open-link-tab', label: ko ? '링크를 새 탭에서 열기' : 'Open link in new tab' },
      { kind: 'item', id: 'open-link-window', label: ko ? '링크를 새 창에서 열기' : 'Open link in new window' },
      { kind: 'item', id: 'open-link-private', label: ko ? '링크를 비공개 창에서 열기' : 'Open link in private window' },
      { kind: 'item', id: 'save-link', label: ko ? '링크를 다른 이름으로 저장…' : 'Save link as…' },
      { kind: 'item', id: 'copy-link', label: ko ? '링크 주소 복사' : 'Copy link address' },
    )
  }
  items.push(
    { kind: 'sep', id: 'sep-end' },
    { kind: 'item', id: 'view-source', label: ko ? '페이지 소스 보기' : 'View page source' },
    { kind: 'item', id: 'inspect', label: ko ? '검사' : 'Inspect' },
  )
  return items
}

export function reorderTabs<T extends { id: string; pinned?: boolean }>(
  tabs: T[],
  fromId: string,
  toId: string,
  place: 'before' | 'after',
): T[] {
  if (fromId === toId) return tabs
  const from = tabs.findIndex((tab) => tab.id === fromId)
  const to = tabs.findIndex((tab) => tab.id === toId)
  if (from < 0 || to < 0) return tabs
  const next = tabs.slice()
  const [moved] = next.splice(from, 1)
  let insert = next.findIndex((tab) => tab.id === toId)
  if (insert < 0) return tabs
  if (place === 'after') insert += 1
  next.splice(insert, 0, moved)
  const pinned = next.filter((tab) => tab.pinned)
  const loose = next.filter((tab) => !tab.pinned)
  return [...pinned, ...loose]
}

export function clipSelection(raw: string, max = 24) {
  const text = raw.trim().replace(/\s+/g, ' ')
  if (text.length <= max) return text
  return `${text.slice(0, max)}…`
}
