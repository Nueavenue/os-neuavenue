import { describe, expect, it } from 'vitest'
import { detectCraftBins } from './craftDetect'
import { CRAFT_LAUNCH, CRAFT_LAUNCH_MISSING, craftLaunchFromBridge, launchCraftHref, planCraftLaunch } from './craftLaunch'

describe('craftLaunch tiles', () => {
  it('locks the three labels and does not slash-join them', () => {
    expect(CRAFT_LAUNCH.map((row) => row.label)).toEqual(['NeuWord doc', 'Neu Excel', 'Neu Prez'])
    expect(CRAFT_LAUNCH.map((row) => row.id)).toEqual(['neu-word', 'neu-excel', 'neu-prez'])
    for (const row of CRAFT_LAUNCH) {
      expect(row.label.includes('/')).toBe(false)
    }
    expect(CRAFT_LAUNCH_MISSING).toBe('아직 없음')
  })

  it('empty bins → all ready false', () => {
    const tiles = planCraftLaunch(detectCraftBins({}), false)
    expect(tiles.every((tile) => tile.ready === false)).toBe(true)
    expect(craftLaunchFromBridge(null, null).every((tile) => !tile.ready)).toBe(true)
  })

  it('ready: neu-word = wordcraft-cli OR craft-web; excel/prez = their CLI', () => {
    const webOnly = planCraftLaunch(detectCraftBins({}), true)
    expect(webOnly.find((t) => t.id === 'neu-word')?.ready).toBe(true)
    expect(webOnly.find((t) => t.id === 'neu-excel')?.ready).toBe(false)
    expect(webOnly.find((t) => t.id === 'neu-prez')?.ready).toBe(false)

    const bins = detectCraftBins({
      'wordcraft-cli': '/opt/wordcraft-cli',
      'gridcraft-cli': '/opt/gridcraft-cli',
      'deckcraft-cli': '/opt/deckcraft-cli',
    })
    const all = planCraftLaunch(bins, false)
    expect(all.map((t) => t.ready)).toEqual([true, true, true])
  })

  it('PhoneHome glyphs are N-series, not W/X/P', () => {
    for (const tile of planCraftLaunch()) {
      expect(tile.glyph).toBe('N')
      expect(['W', 'X', 'P']).not.toContain(tile.glyph)
    }
  })

  it('006 click href is craft-web for word only unless extra dirs', () => {
    expect(launchCraftHref('neu-word', null)).toBeNull()
    expect(launchCraftHref('neu-word', { present: true, href: 'http://127.0.0.1:4178/craft-web/' })).toBe(
      'http://127.0.0.1:4178/craft-web/',
    )
    expect(launchCraftHref('neu-excel', { present: true, href: 'http://127.0.0.1:4178/craft-web/' })).toBeNull()
    const rows = planCraftLaunch(detectCraftBins({}), true, {
      present: true,
      href: 'http://127.0.0.1:4178/craft-web/',
    })
    expect(rows.find((t) => t.id === 'neu-word')?.href).toContain('/craft-web/')
    expect(rows.find((t) => t.id === 'neu-prez')?.href).toBeNull()
  })
})
