import { parsePrompt } from './promptParse'
import { readyUiSessionHeaders } from './uiSession'
import { readSearchEngine, searchUrl, type SearchEngineId } from './searchEngines'

export type PromptSearchHit = {
  title: string
  href: string
  snippet: string
}

export type PromptSearchPack = {
  engine: SearchEngineId
  query: string
  href: string
  hits: PromptSearchHit[]
}

async function wikipediaHits(query: string): Promise<PromptSearchHit[]> {
  const lang = /[\uac00-\ud7a3]/.test(query) ? 'ko' : 'en'
  const href = `https://${lang}.wikipedia.org/w/api.php?action=opensearch&limit=5&namespace=0&format=json&origin=*&search=${encodeURIComponent(query)}`
  const res = await fetch(href, { signal: AbortSignal.timeout(8_000) })
  if (!res.ok) return []
  const body = (await res.json()) as [string, string[], string[], string[]]
  return (body[1] || []).map((title, i) => ({
    title,
    href: body[3]?.[i] || '',
    snippet: body[2]?.[i] || '',
  }))
}

export async function fetchPromptSearch(text: string): Promise<PromptSearchPack | null> {
  const parsed = parsePrompt(text)
  if (!parsed.searchQuery) return null
  const engine = readSearchEngine()
  const href = searchUrl(parsed.searchQuery, engine)
  try {
    const res = await fetch('/api/search/snippets', {
      method: 'POST',
      headers: await readyUiSessionHeaders(),
      body: JSON.stringify({ query: parsed.searchQuery, engine }),
      signal: AbortSignal.timeout(12_000),
    })
    const row = (await res.json()) as { ok?: boolean; hits?: PromptSearchHit[] }
    if (res.ok && Array.isArray(row.hits) && row.hits.length) {
      return { engine, query: parsed.searchQuery, href, hits: row.hits.slice(0, 6) }
    }
  } catch {
    /* bridge may still be the previous process */
  }
  try {
    return { engine, query: parsed.searchQuery, href, hits: await wikipediaHits(parsed.searchQuery) }
  } catch {
    return { engine, query: parsed.searchQuery, href, hits: [] }
  }
}

export function composeSeatInstruction(request: string, pack: PromptSearchPack | null): string {
  const parsed = parsePrompt(request)
  const words = parsed.tokens.length ? parsed.tokens.join(' · ') : parsed.clean
  const lines = [
    `User language: ${parsed.language}`,
    `Words: ${words}`,
    `Ask: ${parsed.clean}`,
  ]
  if (pack) {
    lines.push(`Search engine: ${pack.engine}`)
    lines.push(`Search URL: ${pack.href}`)
    if (pack.hits.length) {
      lines.push('Search notes (titles and snippets only — not full pages):')
      pack.hits.forEach((hit, i) => {
        lines.push(`${i + 1}. ${hit.title} — ${hit.snippet}`.trim())
      })
    } else {
      lines.push('Search notes: none. Write a careful draft and mark unknown facts as 확인 필요.')
    }
  }
  return lines.join('\n')
}
