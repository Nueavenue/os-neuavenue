import { describe, expect, it } from 'vitest'
import { linuxPackHref, usbKitHref } from './linuxPack'

describe('linux pack links', () => {
  it('uses the local bridge on this laptop', () => {
    expect(linuxPackHref('127.0.0.1')).toBe('/api/download/linux')
    expect(usbKitHref('localhost')).toBe('/api/download/pack')
  })

  it('uses the public /downloads file on os.neuavenue.com', () => {
    expect(linuxPackHref('os.neuavenue.com')).toBe('/downloads/neuos-linux.tar.gz')
    expect(usbKitHref('os.neuavenue.com')).toBe('/downloads/neuos-boot-kit.tar.gz')
  })
})
