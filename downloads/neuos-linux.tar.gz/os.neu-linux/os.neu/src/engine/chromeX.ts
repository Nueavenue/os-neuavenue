import type { Phase } from '../types'

const HOME_PHASES: Phase[] = ['splash', 'install', 'landing', 'lui', 'jeos']

export function isHomePhase(phase: Phase) {
  return HOME_PHASES.includes(phase)
}

/** Status-bar ×. Home surfaces must leave the app (Ubuntu desktop). */
export function decideChromeX(input: {
  phase: Phase
  previousPhase: Phase | null
  windowFullscreen: boolean
  domFullscreen: boolean
}): 'quit' | 'leave-fullscreen' | 'back' | 'home' {
  if (isHomePhase(input.phase)) return 'quit'
  if (input.windowFullscreen || input.domFullscreen) return 'leave-fullscreen'
  if (input.previousPhase && input.previousPhase !== input.phase) return 'back'
  return 'home'
}
