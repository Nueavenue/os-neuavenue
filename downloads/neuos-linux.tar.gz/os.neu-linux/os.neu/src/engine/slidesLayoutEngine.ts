/**
 * slides.neu layout engine v1.
 * The model picks words. This module owns slots, wrapping, and which
 * primitive a slide uses. It does not invent metrics, sources, or coordinates.
 */
import { bodyFromBullets, bulletsFromBody, type RecipeSlide } from './slidesRecipe'
import type { LayoutPrimitiveId } from './layoutContract'

export const DECK_STAGES = [
  'ANALYZING_PROMPT',
  'PLANNING_DECK',
  'SELECTING_LAYOUT',
  'GENERATING_CONTENT',
  'FITTING_CONTENT',
  'READY',
  'FAILED',
] as const

export type DeckStage = (typeof DECK_STAGES)[number]

export type SlotId = 'title' | 'subtitle' | 'left' | 'right' | 'metric' | 'note'

export type SlotBox = {
  x: number
  y: number
  w: number
  h: number
  maxLines: number
  basePx: number
}

export type FittedText = {
  lines: string[]
  fontPx: number
  overflow: boolean
  /** True when the slot is still too small at the minimum size. Words are kept. */
  needsRewrite: boolean
}

const MIN_PX = 13

const FRAMES: Record<LayoutPrimitiveId, Partial<Record<SlotId, SlotBox>>> = {
  title: {
    title: { x: 8, y: 28, w: 84, h: 28, maxLines: 3, basePx: 32 },
    subtitle: { x: 12, y: 58, w: 76, h: 18, maxLines: 2, basePx: 16 },
  },
  'section-divider': {
    title: { x: 10, y: 36, w: 80, h: 28, maxLines: 3, basePx: 28 },
  },
  bullets: {
    title: { x: 6, y: 8, w: 88, h: 16, maxLines: 2, basePx: 22 },
    left: { x: 6, y: 28, w: 88, h: 62, maxLines: 6, basePx: 16 },
  },
  'two-column': {
    title: { x: 6, y: 6, w: 88, h: 14, maxLines: 2, basePx: 20 },
    left: { x: 6, y: 24, w: 42, h: 66, maxLines: 6, basePx: 15 },
    right: { x: 52, y: 24, w: 42, h: 66, maxLines: 6, basePx: 15 },
  },
  table: {
    title: { x: 6, y: 6, w: 88, h: 14, maxLines: 2, basePx: 20 },
    note: { x: 6, y: 22, w: 88, h: 70, maxLines: 8, basePx: 14 },
  },
  metric: {
    title: { x: 8, y: 10, w: 84, h: 16, maxLines: 2, basePx: 20 },
    metric: { x: 10, y: 34, w: 80, h: 28, maxLines: 2, basePx: 36 },
    note: { x: 15, y: 66, w: 70, h: 16, maxLines: 2, basePx: 14 },
  },
}

export function frameSlots(id: LayoutPrimitiveId): Partial<Record<SlotId, SlotBox>> {
  return FRAMES[id]
}

function charsPerLine(slot: SlotBox, fontPx: number): number {
  const widthPx = (slot.w / 100) * 960
  return Math.max(8, Math.floor(widthPx / (fontPx * 0.55)))
}

function wrap(text: string, chars: number): string[] {
  const words = text.trim().split(/\s+/).filter(Boolean)
  if (!words.length) return []
  const lines: string[] = []
  let line = ''
  for (const word of words) {
    const next = line ? `${line} ${word}` : word
    if (next.length > chars && line) {
      lines.push(line)
      line = word
    } else {
      line = next
    }
  }
  if (line) lines.push(line)
  return lines
}

/** Fit words into a slot. Shrinks type. Does not rewrite or drop words. */
export function fitSlot(text: string, slot: SlotBox): FittedText {
  const raw = text.trim()
  if (!raw) return { lines: [], fontPx: slot.basePx, overflow: false, needsRewrite: false }
  let fontPx = slot.basePx
  let lines = wrap(raw, charsPerLine(slot, fontPx))
  while (lines.length > slot.maxLines && fontPx > MIN_PX) {
    fontPx -= 1
    lines = wrap(raw, charsPerLine(slot, fontPx))
  }
  const overflow = lines.length > slot.maxLines
  return {
    lines: overflow ? lines.slice(0, slot.maxLines) : lines,
    fontPx,
    overflow,
    needsRewrite: overflow,
  }
}

export function metricText(slide: RecipeSlide): { value: string; label: string; sourced: boolean } {
  const value = (slide.table?.rows[0]?.[1] || '').trim()
  const label = (slide.table?.rows[0]?.[0] || slide.bullets[0] || '').trim()
  return { value, label, sourced: Boolean(value) }
}

/** Keep an existing primitive. Otherwise map the recipe fields onto one. */
export function stampLayout(slide: RecipeSlide): RecipeSlide {
  if (slide.primitive) return slide
  if (slide.layout === 'table' || slide.table) return { ...slide, primitive: 'table', layout: 'table' }
  if (slide.layout === 'title') return { ...slide, primitive: 'title' }
  return { ...slide, primitive: 'bullets' }
}

/**
 * Turn the slide's own lines into a table.
 * A line with " | " becomes cells. Otherwise the line stays in column 1 and column 2 is empty.
 * No market figures are added.
 */
export function bulletsToComparisonTable(slide: RecipeSlide): RecipeSlide | null {
  if ((slide.primitive === 'table' || slide.layout === 'table') && slide.table) return null
  const lines = (slide.bullets.length ? slide.bullets : bulletsFromBody(slide.body)).map((line) => line.trim()).filter(Boolean)
  if (!lines.length) return null
  const split = lines.map((line) => line.split(/\s*\|\s*/).map((cell) => cell.trim()))
  const width = Math.min(5, Math.max(...split.map((cells) => cells.length), 2))
  const headers =
    width === 2 && split.every((cells) => cells.length === 1)
      ? ['Item', 'Note']
      : Array.from({ length: width }, (_, i) => `Column ${i + 1}`)
  const rows = split.slice(0, 8).map((cells) => Array.from({ length: width }, (_, i) => cells[i] || ''))
  return {
    ...slide,
    layout: 'table',
    primitive: 'table',
    body: '',
    bullets: [],
    table: { headers, rows },
  }
}

export function columnText(slide: RecipeSlide, side: 'left' | 'right'): string {
  const lines = slide.bullets.length ? slide.bullets : bulletsFromBody(slide.body)
  const mid = Math.ceil(lines.length / 2) || 0
  const part = side === 'left' ? lines.slice(0, mid) : lines.slice(mid)
  return bodyFromBullets(part)
}

/** A bridge or model failure must not become slide copy. */
export function isAssistFailure(text: string): boolean {
  const line = (text || '').trim()
  return /could not reach the bridge|bridge service .*not responding|no text arrived|local model is not answering|^http-\d+$/i.test(line)
}

/**
 * A deck reply is usable when it is recipe JSON, or markdown with real slides.
 * A one-line error must not replace a multi-slide plan.
 */
export function acceptDeckReply(text: string, plannedCount: number): boolean {
  const raw = (text || '').trim()
  if (!raw || isAssistFailure(raw)) return false
  if (raw.includes('"version"') && raw.includes('"slides"')) return true
  if (plannedCount > 1 && !/^#{1,4}\s/m.test(raw)) return false
  return true
}

export function stageLabel(stage: DeckStage, ko: boolean): string {
  const en: Record<DeckStage, string> = {
    ANALYZING_PROMPT: 'Reading the request',
    PLANNING_DECK: 'Planning the deck',
    SELECTING_LAYOUT: 'Choosing a layout for each slide',
    GENERATING_CONTENT: 'Writing into those layouts',
    FITTING_CONTENT: 'Fitting text into the slots',
    READY: 'Ready',
    FAILED: 'The model did not answer. The deck is unchanged.',
  }
  const kr: Record<DeckStage, string> = {
    ANALYZING_PROMPT: '요청을 읽는 중',
    PLANNING_DECK: '장 구성을 잡는 중',
    SELECTING_LAYOUT: '장마다 레이아웃을 고르는 중',
    GENERATING_CONTENT: '그 칸에 글을 쓰는 중',
    FITTING_CONTENT: '칸에 맞게 글자 크기를 맞추는 중',
    READY: '준비됨',
    FAILED: '모델이 답하지 않았습니다. 덱은 그대로입니다.',
  }
  return (ko ? kr : en)[stage]
}
