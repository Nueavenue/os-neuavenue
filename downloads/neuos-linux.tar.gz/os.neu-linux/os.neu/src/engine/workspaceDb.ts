/**
 * neu-workspace — one database for works, activity, artifacts, evidence.
 * Stage 1: IndexedDB on this device (memory in Node tests).
 * Spec: docs/handoff/WO-NEU-WORKSPACE-WORK-CENTRIC-2026-11-03.md
 */

export const WORKSPACE_DB = 'neu-workspace'
export const WORKSPACE_DB_VERSION = 1
export const WORKSPACE_CHANGE = 'neu-workspace-change'

export type WorkStatus = 'open' | 'saved'

export type WsWork = {
  id: string
  title: string
  prompt: string
  audience: string
  audienceNote: string
  status: WorkStatus
  /** Project tag (plan B, later). */
  projectId: string | null
  docId: string | null
  createdAt: number
  updatedAt: number
  savedAt: number | null
  /** Trash marker; the row is kept. */
  deletedAt: number | null
}

export type ActivityKind =
  | 'work.start'
  | 'work.save'
  | 'work.link'
  | 'work.delete'
  | 'work.restore'
  | 'source.add'
  | 'web.visit'
  | 'web.download'
  | 'doc.save'
  | 'sheet.save'
  | 'slides.save'
  | 'slides.export'
  | 'ai.call'

export type WsApp = 'doc' | 'sheet' | 'slides' | 'web'

export type WsActivity = {
  id: string
  workId: string | null
  kind: ActivityKind
  app: WsApp | null
  title: string
  url?: string
  model?: string
  chars?: number
  /** work.link: the activity being linked. *.save: the artifact id. */
  refId?: string
  t: number
}

export type ArtifactApp = 'doc' | 'sheet' | 'slides'

export type WsArtifact = {
  id: string
  workId: string | null
  app: ArtifactApp
  title: string
  payload: unknown
  version: number
  hash: string
  createdAt: number
  updatedAt: number
}

export type WsEvidence = {
  id: string
  workId: string
  url: string
  title: string
  status: string
  contentHash?: string
  addedAt: number
}

export type WsProject = {
  id: string
  name: string
  createdAt: number
}

export type WsMeta = { key: string; value: unknown }

export type StoreName = 'works' | 'activity' | 'artifacts' | 'evidence' | 'projects' | 'meta'

/** Object stores and their indexes (index name = field name). */
export const WORKSPACE_SCHEMA: Record<StoreName, { key: 'id' | 'key'; indexes: string[] }> = {
  works: { key: 'id', indexes: ['updatedAt', 'projectId'] },
  activity: { key: 'id', indexes: ['workId', 't', 'kind'] },
  artifacts: { key: 'id', indexes: ['workId', 'app', 'updatedAt'] },
  evidence: { key: 'id', indexes: ['workId'] },
  projects: { key: 'id', indexes: [] },
  meta: { key: 'key', indexes: [] },
}

export interface WorkspaceBackend {
  /** Insert only; rejects when the key already exists. */
  add<T extends object>(store: StoreName, row: T): Promise<void>
  put<T extends object>(store: StoreName, row: T): Promise<void>
  get<T>(store: StoreName, key: string): Promise<T | undefined>
  all<T>(store: StoreName): Promise<T[]>
  byIndex<T>(store: StoreName, index: string, value: string): Promise<T[]>
}

function keyOf(store: StoreName, row: object): string {
  return String((row as Record<string, unknown>)[WORKSPACE_SCHEMA[store].key])
}

export function memoryBackend(): WorkspaceBackend {
  const data = new Map<StoreName, Map<string, unknown>>()
  const table = (store: StoreName) => {
    let hit = data.get(store)
    if (!hit) {
      hit = new Map()
      data.set(store, hit)
    }
    return hit
  }
  const copy = <T>(row: T): T => JSON.parse(JSON.stringify(row)) as T
  return {
    async add(store, row) {
      const key = keyOf(store, row)
      if (table(store).has(key)) throw new Error(`exists: ${store}/${key}`)
      table(store).set(key, copy(row))
    },
    async put(store, row) {
      table(store).set(keyOf(store, row), copy(row))
    },
    async get(store, key) {
      const row = table(store).get(key)
      return row === undefined ? undefined : copy(row as never)
    },
    async all(store) {
      return [...table(store).values()].map((row) => copy(row as never))
    },
    async byIndex(store, index, value) {
      return [...table(store).values()]
        .filter((row) => (row as Record<string, unknown>)[index] === value)
        .map((row) => copy(row as never))
    },
  }
}

function idbRequest<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(WORKSPACE_DB, WORKSPACE_DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      for (const [name, spec] of Object.entries(WORKSPACE_SCHEMA)) {
        if (db.objectStoreNames.contains(name)) continue
        const os = db.createObjectStore(name, { keyPath: spec.key })
        spec.indexes.forEach((ix) => os.createIndex(ix, ix))
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export function indexedDbBackend(): WorkspaceBackend {
  let dbp: Promise<IDBDatabase> | null = null
  const db = () => (dbp ??= openIdb())
  const store = async (name: StoreName, mode: IDBTransactionMode) =>
    (await db()).transaction(name, mode).objectStore(name)
  return {
    async add(name, row) {
      await idbRequest((await store(name, 'readwrite')).add(row))
    },
    async put(name, row) {
      await idbRequest((await store(name, 'readwrite')).put(row))
    },
    async get(name, key) {
      return (await idbRequest((await store(name, 'readonly')).get(key))) as never
    },
    async all(name) {
      return (await idbRequest((await store(name, 'readonly')).getAll())) as never
    },
    async byIndex(name, index, value) {
      return (await idbRequest((await store(name, 'readonly')).index(index).getAll(value))) as never
    },
  }
}

let backend: WorkspaceBackend | null = null

export function workspace(): WorkspaceBackend {
  if (!backend) backend = typeof indexedDB === 'undefined' ? memoryBackend() : indexedDbBackend()
  return backend
}

/** Tests swap in a fresh memory backend. */
export function setWorkspaceBackend(next: WorkspaceBackend | null) {
  backend = next
}

function announce() {
  if (typeof window === 'undefined') return
  window.dispatchEvent(new CustomEvent(WORKSPACE_CHANGE))
}

export function onWorkspaceChange(handler: () => void) {
  if (typeof window === 'undefined') return () => {}
  window.addEventListener(WORKSPACE_CHANGE, handler)
  return () => window.removeEventListener(WORKSPACE_CHANGE, handler)
}

export function newWsId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export async function sha256Hex(text: string): Promise<string> {
  const subtle = globalThis.crypto?.subtle
  if (subtle) {
    const buf = await subtle.digest('SHA-256', new TextEncoder().encode(text))
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('')
  }
  let h = 0x811c9dc5
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return `fnv1a-${(h >>> 0).toString(16)}`
}

// ---- works ----

export async function putWork(work: WsWork) {
  await workspace().put('works', work)
  announce()
}

export async function listWorks(): Promise<WsWork[]> {
  const rows = await workspace().all<WsWork>('works')
  return rows.sort((a, b) => b.updatedAt - a.updatedAt)
}

// ---- activity (append-only) ----

export async function appendActivity(row: Omit<WsActivity, 'id' | 't'> & Partial<Pick<WsActivity, 'id' | 't'>>) {
  const full: WsActivity = { ...row, id: row.id || newWsId('a'), t: row.t || Date.now() }
  await workspace().add('activity', full)
  announce()
  return full
}

export async function listActivity(): Promise<WsActivity[]> {
  const rows = await workspace().all<WsActivity>('activity')
  return rows.sort((a, b) => b.t - a.t)
}

// ---- artifacts ----

export async function putArtifact(input: {
  id?: string
  workId: string | null
  app: ArtifactApp
  title: string
  payload: unknown
}): Promise<WsArtifact> {
  const now = Date.now()
  const prev = input.id ? await workspace().get<WsArtifact>('artifacts', input.id) : undefined
  const row: WsArtifact = {
    id: input.id || newWsId(input.app),
    workId: input.workId ?? prev?.workId ?? null,
    app: input.app,
    title: input.title.slice(0, 120) || 'Untitled',
    payload: input.payload,
    version: (prev?.version || 0) + 1,
    hash: await sha256Hex(JSON.stringify(input.payload ?? null)),
    createdAt: prev?.createdAt || now,
    updatedAt: now,
  }
  await workspace().put('artifacts', row)
  announce()
  return row
}

export async function getArtifact(id: string) {
  return workspace().get<WsArtifact>('artifacts', id)
}

export async function listArtifacts(): Promise<WsArtifact[]> {
  const rows = await workspace().all<WsArtifact>('artifacts')
  return rows.sort((a, b) => b.updatedAt - a.updatedAt)
}

// ---- evidence ----

export async function putEvidence(row: WsEvidence) {
  await workspace().put('evidence', row)
  announce()
}

export async function listEvidence(): Promise<WsEvidence[]> {
  return workspace().all<WsEvidence>('evidence')
}

// ---- meta ----

export async function getMeta<T>(key: string): Promise<T | undefined> {
  const row = await workspace().get<WsMeta>('meta', key)
  return row?.value as T | undefined
}

export async function setMeta(key: string, value: unknown) {
  await workspace().put('meta', { key, value })
}

// ---- views (pure) ----

/**
 * Which work each activity belongs to. Own workId first; a later
 * `work.link` row re-points its `refId` without editing the original.
 */
export function resolveWorkIds(rows: WsActivity[]): Map<string, string | null> {
  const out = new Map<string, string | null>()
  for (const row of rows) out.set(row.id, row.workId)
  const links = rows.filter((row) => row.kind === 'work.link' && row.refId).sort((a, b) => a.t - b.t)
  for (const link of links) {
    if (out.has(link.refId!)) out.set(link.refId!, link.workId)
  }
  return out
}

/** Visible rows (no link rows) with their resolved work id, newest first. */
export function visibleActivity(rows: WsActivity[]): WsActivity[] {
  const owner = resolveWorkIds(rows)
  return rows
    .filter((row) => row.kind !== 'work.link')
    .map((row) => ({ ...row, workId: owner.get(row.id) ?? null }))
    .sort((a, b) => b.t - a.t)
}

export type WorkCounts = { doc: number; sheet: number; slides: number; sources: number; ai: number; web: number }

export function summarizeWork(
  work: Pick<WsWork, 'id' | 'docId'>,
  activity: WsActivity[],
  artifacts: WsArtifact[],
  evidence: WsEvidence[],
): WorkCounts {
  const mine = artifacts.filter((row) => row.workId === work.id)
  const docs = mine.filter((row) => row.app === 'doc').length
  const acts = activity.filter((row) => row.workId === work.id)
  return {
    doc: docs || (work.docId ? 1 : 0),
    sheet: mine.filter((row) => row.app === 'sheet').length,
    slides: mine.filter((row) => row.app === 'slides').length,
    sources: evidence.filter((row) => row.workId === work.id).length,
    ai: acts.filter((row) => row.kind === 'ai.call').length,
    web: acts.filter((row) => row.kind === 'web.visit').length,
  }
}

export type FeedFilter = 'all' | 'web' | 'doc' | 'sheet' | 'slides' | 'ai'

export function filterActivity(rows: WsActivity[], filter: FeedFilter): WsActivity[] {
  if (filter === 'all') return rows
  if (filter === 'ai') return rows.filter((row) => row.kind === 'ai.call')
  if (filter === 'web') return rows.filter((row) => row.app === 'web')
  return rows.filter((row) => row.app === filter && row.kind !== 'ai.call')
}

export type DayGroup<T> = { key: string; items: T[] }

function dayKey(t: number) {
  const d = new Date(t)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function groupByDay<T extends { t: number }>(rows: T[]): DayGroup<T>[] {
  const out: DayGroup<T>[] = []
  for (const row of rows) {
    const key = dayKey(row.t)
    const last = out[out.length - 1]
    if (last && last.key === key) last.items.push(row)
    else out.push({ key, items: [row] })
  }
  return out
}

export function dayLabel(key: string, ko: boolean, now = Date.now()) {
  if (key === dayKey(now)) return ko ? '오늘' : 'Today'
  if (key === dayKey(now - 86_400_000)) return ko ? '어제' : 'Yesterday'
  return key
}
