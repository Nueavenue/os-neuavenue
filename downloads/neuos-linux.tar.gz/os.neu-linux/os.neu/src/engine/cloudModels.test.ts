import { describe, expect, it } from 'vitest'
import { CLOUD_VENDORS_2026, isCloudModel, officeModelList } from './cloudModels'

describe('cloudModels 2026-10', () => {
  it('lists ten current vendors once each', () => {
    expect(CLOUD_VENDORS_2026).toHaveLength(10)
    expect(new Set(CLOUD_VENDORS_2026.map((row) => row.vendorId)).size).toBe(10)
    expect(CLOUD_VENDORS_2026[0]?.id).toBe('claude-opus-5.5')
    expect(CLOUD_VENDORS_2026[1]?.id).toBe('gpt-6-astra')
  })

  it('treats catalog and legacy GPT ids as cloud, not local tags', () => {
    expect(isCloudModel('claude-opus-5.5')).toBe(true)
    expect(isCloudModel('gpt-4o-mini')).toBe(true)
    expect(isCloudModel('qwen2.5:7b')).toBe(false)
    expect(officeModelList().some((row) => row.id === 'grok-4.7')).toBe(true)
  })
})
