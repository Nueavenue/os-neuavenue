import { CRAFT_CLI } from './craftDetect'
import { parseSheetGrid } from './sheetGrid'

export type CraftSurface = 'doc' | 'sheet' | 'slides'

export type CraftIoExt = {
  inExt: '.md' | '.csv'
  outExt: '.docx' | '.xlsx' | '.pptx'
}

export type CraftConvertPrep = {
  surface: CraftSurface
  inExt: CraftIoExt['inExt']
  outExt: CraftIoExt['outExt']
  inRel: string
  outRel: string
  inPath: string
  outPath: string
  argv: ['convert', string, string]
  inputText: string
}

const ALLOWED_CLI = new Set<string>([CRAFT_CLI.wordcraft, CRAFT_CLI.gridcraft, CRAFT_CLI.deckcraft])

/** Strip Seat 10-step appendix. Convert input uses this body only. */
export function writerBodyOnly(text: string) {
  const raw = String(text || '')
  const cut = raw.search(/\n---\n요청\n/)
  return (cut >= 0 ? raw.slice(0, cut) : raw).replace(/^\s+/, '')
}

export function craftIoExt(surface: CraftSurface): CraftIoExt {
  if (surface === 'sheet') return { inExt: '.csv', outExt: '.xlsx' }
  if (surface === 'slides') return { inExt: '.md', outExt: '.pptx' }
  return { inExt: '.md', outExt: '.docx' }
}

export function craftConvertArgv(inRel: string, outRel: string): ['convert', string, string] {
  return ['convert', inRel, outRel]
}

export function isAllowedCraftCli(cliPath: string) {
  const value = String(cliPath || '').trim()
  if (!value || value.includes('\0') || value.includes('..')) return false
  if (!value.startsWith('/')) return false
  const base = value.split('/').filter(Boolean).pop() || ''
  return ALLOWED_CLI.has(base)
}

export function craftFileStem(title: string) {
  const cleaned = String(title || '')
    .replace(/\\/g, '/')
    .split('/')
    .filter((part) => part && part !== '.' && part !== '..')
    .join('-')
    .replace(/[^\w가-힣.-]+/g, '-')
    .replace(/^[-.]+|[-.]+$/g, '')
    .slice(0, 48)
  return cleaned || 'craft'
}

/** Join sandbox + relative name. Reject `..`, absolute, and empty. */
export function joinCraftPath(root: string, rel: string): string | null {
  const base = String(root || '').trim()
  if (!base || base.includes('\0') || /(^|\/)\.\.(\/|$)/.test(base.replace(/\\/g, '/'))) return null
  const raw = String(rel || '').trim()
  if (!raw || raw.includes('\0')) return null
  const normalized = raw.replace(/\\/g, '/')
  if (normalized.startsWith('/') || /^[A-Za-z]:/.test(normalized)) return null
  const pieces = normalized.split('/')
  if (pieces.some((part) => !part || part === '..')) return null
  const filtered = pieces.filter((part) => part !== '.')
  if (!filtered.length) return null
  return `${base.replace(/\/+$/, '')}/${filtered.join('/')}`
}

export function isInsideSandbox(root: string, abs: string) {
  const a = String(root || '').replace(/\/+$/, '')
  const b = String(abs || '').replace(/\/+$/, '')
  if (!a || !b) return false
  return b === a || b.startsWith(`${a}/`)
}

export function craftSandboxRoot(env: Record<string, string | undefined> = {}) {
  const xdg = String(env.XDG_DATA_HOME || '').trim()
  if (xdg) {
    const joined = joinCraftPath(xdg, 'os.neu/craft')
    if (joined) return joined
  }
  const home = String(env.HOME || '').trim()
  if (home) {
    const joined = joinCraftPath(home, '.local/share/os.neu/craft')
    if (joined) return joined
  }
  return '/tmp/os.neu/craft'
}

/** Display-only CSV. Drops formula / A1 dumps via parseSheetGrid. */
export function sheetDisplayCsv(text: string) {
  const grid = parseSheetGrid(writerBodyOnly(text))
  let maxR = -1
  let maxC = -1
  for (let r = 0; r < grid.length; r += 1) {
    for (let c = 0; c < grid[r].length; c += 1) {
      if (grid[r][c]) {
        maxR = Math.max(maxR, r)
        maxC = Math.max(maxC, c)
      }
    }
  }
  if (maxR < 0) return ''
  const lines: string[] = []
  for (let r = 0; r <= maxR; r += 1) {
    lines.push(grid[r].slice(0, maxC + 1).map(csvCell).join(','))
  }
  return lines.join('\n')
}

function csvCell(value: string) {
  const text = String(value || '')
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`
  return text
}

export function prepareCraftConvert(opts: {
  sandbox: string
  surface: CraftSurface
  title: string
  body: string
}): CraftConvertPrep | { error: 'escape' } {
  const io = craftIoExt(opts.surface)
  const stem = craftFileStem(opts.title)
  const inRel = `${stem}${io.inExt}`
  const outRel = `${stem}${io.outExt}`
  const inPath = joinCraftPath(opts.sandbox, inRel)
  const outPath = joinCraftPath(opts.sandbox, outRel)
  if (!inPath || !outPath || !isInsideSandbox(opts.sandbox, inPath) || !isInsideSandbox(opts.sandbox, outPath)) {
    return { error: 'escape' }
  }
  const inputText = opts.surface === 'sheet' ? sheetDisplayCsv(opts.body) : writerBodyOnly(opts.body)
  return {
    surface: opts.surface,
    inExt: io.inExt,
    outExt: io.outExt,
    inRel,
    outRel,
    inPath,
    outPath,
    argv: craftConvertArgv(inRel, outRel),
    inputText,
  }
}
