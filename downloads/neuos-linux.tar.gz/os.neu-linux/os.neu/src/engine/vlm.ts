import type { UiElement, VisionFrame } from '../types'

export function harvestUiGraph(root: HTMLElement, query: string): VisionFrame {
  const nodes = [...root.querySelectorAll<HTMLElement>('[data-ui]')]
  const elements: UiElement[] = nodes.map((node) => {
    const box = node.getBoundingClientRect()
    const rootBox = root.getBoundingClientRect()
    return {
      id: node.dataset.ui ?? 'unknown',
      label: node.getAttribute('aria-label') ?? node.dataset.ui ?? '',
      x: Math.round(box.left - rootBox.left),
      y: Math.round(box.top - rootBox.top),
      w: Math.round(box.width),
      h: Math.round(box.height),
      confidence: 0.86 + Math.min(0.13, box.width / 4000),
    }
  })

  const preferred = rankForQuery(elements, query)

  return {
    query,
    elements: preferred,
    capturedAt: Date.now(),
    source: 'pixel-graph',
  }
}

function rankForQuery(elements: UiElement[], query: string): UiElement[] {
  const q = query.toLowerCase()
  return [...elements].sort((a, b) => {
    const as = score(a, q)
    const bs = score(b, q)
    return bs - as
  })
}

function score(el: UiElement, q: string): number {
  const hay = `${el.id} ${el.label}`.toLowerCase()
  if (!q) return el.confidence
  if (hay.includes(q)) return el.confidence + 0.2
  if (q.includes('save') && hay.includes('save')) return el.confidence + 0.25
  if (q.includes('저장') && hay.includes('save')) return el.confidence + 0.25
  if (q.includes('title') && hay.includes('title')) return el.confidence + 0.25
  if (q.includes('제목') && hay.includes('title')) return el.confidence + 0.25
  if ((q.includes('input') || q.includes('body') || q.includes('입력')) && (hay.includes('cell') || hay.includes('editor'))) {
    return el.confidence + 0.2
  }
  return el.confidence
}

export function pick(frame: VisionFrame, id: string): UiElement | undefined {
  return frame.elements.find((el) => el.id === id)
}

export function centerOf(el: UiElement): { x: number; y: number } {
  return { x: el.x + el.w / 2, y: el.y + el.h / 2 }
}
