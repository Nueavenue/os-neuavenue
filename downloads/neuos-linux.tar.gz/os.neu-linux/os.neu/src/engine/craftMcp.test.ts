import { describe, expect, it } from 'vitest'
import { detectCraftBins } from './craftDetect'
import { craftMcpArgv, craftMcpCliPath } from './craftMcp'

const SANDBOX = '/home/billy/.local/share/os.neu/craft'

describe('craftMcp argv locks', () => {
  it('refuses unless both automation roots are set and equal to sandbox', () => {
    expect(craftMcpArgv({ sandbox: SANDBOX })).toBeNull()
    expect(craftMcpArgv({ sandbox: SANDBOX, readRoot: SANDBOX })).toBeNull()
    expect(craftMcpArgv({ sandbox: SANDBOX, writeRoot: SANDBOX })).toBeNull()
    expect(
      craftMcpArgv({
        sandbox: SANDBOX,
        readRoot: SANDBOX,
        writeRoot: '/tmp/other',
      }),
    ).toBeNull()
  })

  it('refuses .. escape in any root', () => {
    expect(
      craftMcpArgv({
        sandbox: SANDBOX,
        readRoot: `${SANDBOX}/../etc`,
        writeRoot: `${SANDBOX}/../etc`,
      }),
    ).toBeNull()
    expect(
      craftMcpArgv({
        sandbox: '/tmp/os.neu/craft/../craft',
        readRoot: '/tmp/os.neu/craft/../craft',
        writeRoot: '/tmp/os.neu/craft/../craft',
      }),
    ).toBeNull()
  })

  it('builds mcp argv with both roots and never --connect or run --cmd', () => {
    const argv = craftMcpArgv({
      sandbox: SANDBOX,
      readRoot: SANDBOX,
      writeRoot: SANDBOX,
    })
    expect(argv).toEqual(['mcp', '--automation-read-root', SANDBOX, '--automation-write-root', SANDBOX])
    expect(argv?.join(' ')).not.toContain('--connect')
    expect(argv).not.toContain('run')
    expect(argv?.join(' ')).not.toContain('--cmd')
  })

  it('prefers wordcraft-cli for ping, else grid/deck', () => {
    expect(craftMcpCliPath(detectCraftBins({}))).toBeNull()
    expect(craftMcpCliPath(detectCraftBins({ 'wordcraft-cli': '/opt/wordcraft-cli' }))).toBe('/opt/wordcraft-cli')
    expect(craftMcpCliPath(detectCraftBins({ 'deckcraft-cli': '/opt/deckcraft-cli' }))).toBe('/opt/deckcraft-cli')
  })
})
