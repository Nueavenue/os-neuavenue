/** User-editable console topics. Lives in this browser only. */

export type SeatTopic = { id: string; title: string }
export type SeatTopicItem = { id: string; topicId: string; ask: string; body: string; at: number }

export type SeatTopicStore = {
  topics: SeatTopic[]
  activeId: string
  items: SeatTopicItem[]
}

export const DEFAULT_TOPIC_ID = 'start'
export const DEFAULT_TOPIC_TITLE = '시작'

const KEY = 'os.neu.console.topics'
const MAX_TOPICS = 80
const MAX_ITEMS = 200

function nid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
}

export function emptyTopicStore(): SeatTopicStore {
  return {
    topics: [{ id: DEFAULT_TOPIC_ID, title: DEFAULT_TOPIC_TITLE }],
    activeId: DEFAULT_TOPIC_ID,
    items: [],
  }
}

export function normalizeTopicStore(raw: unknown): SeatTopicStore {
  const seed = emptyTopicStore()
  if (!raw || typeof raw !== 'object') return seed
  const row = raw as Partial<SeatTopicStore>
  const topics = Array.isArray(row.topics)
    ? row.topics
        .map((item) => ({
          id: String((item as SeatTopic)?.id || ''),
          title: String((item as SeatTopic)?.title || '').trim().slice(0, 80),
        }))
        .filter((item) => item.id && item.title)
        .slice(0, MAX_TOPICS)
    : []
  if (!topics.some((item) => item.id === DEFAULT_TOPIC_ID)) {
    topics.unshift({ id: DEFAULT_TOPIC_ID, title: DEFAULT_TOPIC_TITLE })
  }
  const activeId = topics.some((item) => item.id === row.activeId) ? String(row.activeId) : DEFAULT_TOPIC_ID
  const items = Array.isArray(row.items)
    ? row.items
        .map((item) => ({
          id: String((item as SeatTopicItem)?.id || nid('h')),
          topicId: String((item as SeatTopicItem)?.topicId || DEFAULT_TOPIC_ID),
          ask: String((item as SeatTopicItem)?.ask || '').slice(0, 500),
          body: String((item as SeatTopicItem)?.body || '').slice(0, 40_000),
          at: Number((item as SeatTopicItem)?.at) || Date.now(),
        }))
        .filter((item) => item.ask || item.body)
        .slice(-MAX_ITEMS)
    : []
  return { topics, activeId, items }
}

function storage(): Storage | null {
  try {
    if (typeof localStorage === 'undefined') return null
    return localStorage
  } catch {
    return null
  }
}

export function loadTopicStore(): SeatTopicStore {
  try {
    const raw = storage()?.getItem(KEY)
    return normalizeTopicStore(raw ? JSON.parse(raw) : null)
  } catch {
    return emptyTopicStore()
  }
}

export function saveTopicStore(next: SeatTopicStore) {
  const row = normalizeTopicStore(next)
  try {
    storage()?.setItem(KEY, JSON.stringify(row))
  } catch {
    /* private mode */
  }
  return row
}

export function addTopic(store: SeatTopicStore, title: string) {
  const name = title.trim().slice(0, 80) || '토픽'
  const topic = { id: nid('t'), title: name }
  return saveTopicStore({ ...store, topics: [...store.topics, topic], activeId: topic.id })
}

export function renameTopic(store: SeatTopicStore, id: string, title: string) {
  const name = title.trim().slice(0, 80)
  if (!name) return store
  return saveTopicStore({
    ...store,
    topics: store.topics.map((row) => (row.id === id ? { ...row, title: name } : row)),
  })
}

export function selectTopic(store: SeatTopicStore, id: string) {
  if (!store.topics.some((row) => row.id === id)) return store
  return saveTopicStore({ ...store, activeId: id })
}

export function appendTopicItem(store: SeatTopicStore, item: { ask: string; body: string; topicId?: string }) {
  const topicId = item.topicId && store.topics.some((row) => row.id === item.topicId) ? item.topicId : store.activeId
  const next: SeatTopicItem = {
    id: nid('h'),
    topicId,
    ask: item.ask.trim().slice(0, 500),
    body: item.body.slice(0, 40_000),
    at: Date.now(),
  }
  return saveTopicStore({ ...store, items: [...store.items, next].slice(-MAX_ITEMS) })
}

export function itemsFor(store: SeatTopicStore, topicId: string) {
  return store.items.filter((row) => row.topicId === topicId)
}
