/** daf.neu Search Seat — one query, one engine. Not two SERPs at once. */

export type SearchEngineId =
  | 'searxng'
  | 'ddg'
  | 'brave'
  | 'mojeek'
  | 'startpage'
  | 'qwant'
  | 'ecosia'
  | 'google'
  | 'bing'
  | 'yahoo'
  | 'yandex'
  | 'naver'
  | 'daum'
  | 'perplexity'
  | 'you'
  | 'wikipedia'

export type SearchEngineGroupId = 'open' | 'world' | 'korea' | 'answer'

export type SearchEngine = {
  id: SearchEngineId
  group: SearchEngineGroupId
  labelKo: string
  labelEn: string
  open: boolean
  href: (query: string, origin?: string) => string
}

export const SEARCH_ENGINE_STORAGE = 'os.neu.daf.searchEngine'
export const SEARXNG_ORIGIN_STORAGE = 'os.neu.daf.searxngOrigin'
export const DEFAULT_SEARCH_ENGINE: SearchEngineId = 'searxng'
export const DEFAULT_SEARXNG_ORIGIN = 'https://searx.be'

export const SEARCH_ENGINE_GROUP_ORDER: SearchEngineGroupId[] = ['open', 'world', 'korea', 'answer']

export const SEARCH_ENGINE_GROUP_LABEL: Record<SearchEngineGroupId, { ko: string; en: string }> = {
  open: { ko: '오픈', en: 'Open' },
  world: { ko: '세계', en: 'World' },
  korea: { ko: '한국', en: 'Korea' },
  answer: { ko: '답변', en: 'Answer' },
}

export const SEARCH_ENGINES: SearchEngine[] = [
  {
    id: 'searxng',
    group: 'open',
    labelKo: 'SearXNG',
    labelEn: 'SearXNG',
    open: true,
    href: (query, origin) =>
      `${(origin || DEFAULT_SEARXNG_ORIGIN).replace(/\/$/, '')}/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'ddg',
    group: 'open',
    labelKo: 'DuckDuckGo',
    labelEn: 'DuckDuckGo',
    open: true,
    href: (query) => `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'brave',
    group: 'open',
    labelKo: 'Brave',
    labelEn: 'Brave',
    open: true,
    href: (query) => `https://search.brave.com/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'mojeek',
    group: 'open',
    labelKo: 'Mojeek',
    labelEn: 'Mojeek',
    open: true,
    href: (query) => `https://www.mojeek.com/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'startpage',
    group: 'open',
    labelKo: 'Startpage',
    labelEn: 'Startpage',
    open: true,
    href: (query) => `https://www.startpage.com/sp/search?query=${encodeURIComponent(query)}`,
  },
  {
    id: 'qwant',
    group: 'open',
    labelKo: 'Qwant',
    labelEn: 'Qwant',
    open: true,
    href: (query) => `https://www.qwant.com/?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'ecosia',
    group: 'open',
    labelKo: 'Ecosia',
    labelEn: 'Ecosia',
    open: true,
    href: (query) => `https://www.ecosia.org/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'google',
    group: 'world',
    labelKo: 'Google',
    labelEn: 'Google',
    open: false,
    href: (query) => `https://www.google.com/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'bing',
    group: 'world',
    labelKo: 'Bing',
    labelEn: 'Bing',
    open: false,
    href: (query) => `https://www.bing.com/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'yahoo',
    group: 'world',
    labelKo: 'Yahoo',
    labelEn: 'Yahoo',
    open: false,
    href: (query) => `https://search.yahoo.com/search?p=${encodeURIComponent(query)}`,
  },
  {
    id: 'yandex',
    group: 'world',
    labelKo: 'Yandex',
    labelEn: 'Yandex',
    open: false,
    href: (query) => `https://yandex.com/search/?text=${encodeURIComponent(query)}`,
  },
  {
    id: 'naver',
    group: 'korea',
    labelKo: '네이버',
    labelEn: 'Naver',
    open: false,
    href: (query) => `https://search.naver.com/search.naver?query=${encodeURIComponent(query)}`,
  },
  {
    id: 'daum',
    group: 'korea',
    labelKo: '다음',
    labelEn: 'Daum',
    open: false,
    href: (query) => `https://search.daum.net/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'perplexity',
    group: 'answer',
    labelKo: 'Perplexity',
    labelEn: 'Perplexity',
    open: false,
    href: (query) => `https://www.perplexity.ai/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'you',
    group: 'answer',
    labelKo: 'You.com',
    labelEn: 'You.com',
    open: false,
    href: (query) => `https://you.com/search?q=${encodeURIComponent(query)}`,
  },
  {
    id: 'wikipedia',
    group: 'answer',
    labelKo: '위키백과',
    labelEn: 'Wikipedia',
    open: true,
    href: (query) => {
      const lang =
        typeof navigator !== 'undefined' && String(navigator.language || '').toLowerCase().startsWith('ko')
          ? 'ko'
          : 'en'
      return `https://${lang}.wikipedia.org/w/index.php?search=${encodeURIComponent(query)}`
    },
  },
]

export function isSearchEngineId(value: string): value is SearchEngineId {
  return SEARCH_ENGINES.some((engine) => engine.id === value)
}

export function searchEngineGroups(): { id: SearchEngineGroupId; engines: SearchEngine[] }[] {
  return SEARCH_ENGINE_GROUP_ORDER.map((id) => ({
    id,
    engines: SEARCH_ENGINES.filter((engine) => engine.group === id),
  })).filter((group) => group.engines.length > 0)
}

export function readSearxngOrigin(): string {
  if (typeof localStorage !== 'undefined') {
    try {
      const stored = localStorage.getItem(SEARXNG_ORIGIN_STORAGE)?.trim()
      if (stored) return stored.replace(/\/$/, '')
    } catch {
      /* private mode */
    }
  }
  const fromEnv = typeof import.meta !== 'undefined' ? String(import.meta.env?.VITE_SEARXNG_ORIGIN || '').trim() : ''
  if (fromEnv) return fromEnv.replace(/\/$/, '')
  return DEFAULT_SEARXNG_ORIGIN
}

export function readSearchEngine(): SearchEngineId {
  if (typeof localStorage === 'undefined') return DEFAULT_SEARCH_ENGINE
  try {
    const stored = localStorage.getItem(SEARCH_ENGINE_STORAGE) || ''
    if (isSearchEngineId(stored)) return stored
  } catch {
    /* private mode */
  }
  return DEFAULT_SEARCH_ENGINE
}

export function writeSearchEngine(id: SearchEngineId) {
  if (typeof localStorage === 'undefined') return
  try {
    localStorage.setItem(SEARCH_ENGINE_STORAGE, id)
  } catch {
    /* private mode */
  }
}

export function searchUrl(query: string, engineId: SearchEngineId = readSearchEngine()): string {
  const engine = SEARCH_ENGINES.find((row) => row.id === engineId) || SEARCH_ENGINES[0]
  return engine.href(query, engine.id === 'searxng' ? readSearxngOrigin() : undefined)
}
