export const UI_TOKEN_HEADER = 'x-osneu-ui'
export const UI_TOKEN_META = 'osneu-ui-token'

let cached = ''

export function readUiTokenFromDom(doc: Pick<Document, 'querySelector'> | null | undefined): string {
  if (!doc) return ''
  const el = doc.querySelector(`meta[name="${UI_TOKEN_META}"]`)
  const value = el?.getAttribute('content') || ''
  return value.trim()
}

export function peekUiToken(doc: Pick<Document, 'querySelector'> | null | undefined = typeof document === 'undefined' ? null : document): string {
  if (cached) return cached
  cached = readUiTokenFromDom(doc)
  return cached
}

export function rememberUiToken(token: string) {
  cached = String(token || '').trim()
}

function extraToRecord(extra?: HeadersInit): Record<string, string> {
  if (!extra) return {}
  if (extra instanceof Headers) return Object.fromEntries(extra.entries())
  if (Array.isArray(extra)) return Object.fromEntries(extra)
  const out: Record<string, string> = {}
  for (const [key, value] of Object.entries(extra)) {
    if (typeof value === 'string') out[key] = value
  }
  return out
}

export function uiSessionHeaders(extra?: HeadersInit): Record<string, string> {
  const out: Record<string, string> = { 'content-type': 'application/json', ...extraToRecord(extra) }
  const token = peekUiToken()
  if (token) out[UI_TOKEN_HEADER] = token
  return out
}

export async function ensureUiToken(): Promise<string> {
  const have = peekUiToken()
  if (have) return have
  if (typeof fetch === 'undefined') return ''
  try {
    const res = await fetch('/api/ui-session', { signal: AbortSignal.timeout(4000) })
    const fromHeader = res.headers.get(UI_TOKEN_HEADER) || ''
    if (fromHeader.trim()) cached = fromHeader.trim()
  } catch {
    /* bridge down — helpers still send whatever we have */
  }
  return cached
}

export async function readyUiSessionHeaders(extra?: HeadersInit): Promise<Record<string, string>> {
  await ensureUiToken()
  return uiSessionHeaders(extra)
}
