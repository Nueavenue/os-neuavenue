import { PathGlyph, type PathKind } from './PathGlyphs'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function PathTitle({ kind, label }: { kind: PathKind; label: string }) {
  return (
    <b className="path-title">
      <span className="path-glyph" aria-hidden>
        <PathGlyph kind={kind} />
      </span>
      {label}
    </b>
  )
}

export function PathRail() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const items: { kind: PathKind; label: string }[] = [
    { kind: 'host', label: copy.installHost },
    { kind: 'usb', label: copy.installUsb },
    { kind: 'guest', label: copy.installGuest },
  ]

  return (
    <div className="path-rail" role="navigation" aria-label={ko ? '설치 경로' : 'Install paths'}>
      {items.map((item) => (
        <button
          key={item.kind}
          type="button"
          className={`path-icon${neu.installIntent === item.kind ? ' on' : ''}`}
          onClick={() => neu.openPath(item.kind)}
          aria-label={item.label}
          title={item.label}
        >
          <PathGlyph kind={item.kind} />
        </button>
      ))}
    </div>
  )
}
