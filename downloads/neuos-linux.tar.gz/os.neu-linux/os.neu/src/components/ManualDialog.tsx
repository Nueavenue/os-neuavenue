import { useEffect, useRef, useState, type MouseEvent } from 'react'
import { HostGlyph, UsbGlyph, GuestGlyph } from './PathGlyphs'
import { DOCS_HOME, fetchManualMarkdown, markdownToHtml } from '../engine/manualMd'
import { frameForDocsDest, resolveDocsLink } from '../engine/docsLinks'
import { MANUAL_CHAPTERS, findManualPage, manualImg, manualKey, manualVideo } from '../engine/manualTutorial'
import { useNeu } from '../state/neuContext'

type ManualPane = 'intro' | 'manual' | 'classic' | 'frame'

const FIRST_PAGE = manualKey({ chapter: MANUAL_CHAPTERS[0], page: MANUAL_CHAPTERS[0].pages[0] })

export function ManualDialog() {
  const neu = useNeu()
  const [pane, setPane] = useState<ManualPane>('intro')
  const [frameHref, setFrameHref] = useState('')
  const [frameTitle, setFrameTitle] = useState('')
  const [docHtml, setDocHtml] = useState('')
  const [docError, setDocError] = useState(false)
  const [docLoading, setDocLoading] = useState(false)
  const [pageKey, setPageKey] = useState(FIRST_PAGE)
  const [openChapters, setOpenChapters] = useState<Set<string>>(() => new Set(MANUAL_CHAPTERS.map((c) => c.id)))
  const [zoom, setZoom] = useState<{ src: string; caption: string } | null>(null)
  const pageRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (!neu.manualOpen) {
      setPane('intro')
      setFrameHref('')
      setFrameTitle('')
      setDocHtml('')
      setDocError(false)
      setDocLoading(false)
      setZoom(null)
    }
  }, [neu.manualOpen])

  useEffect(() => {
    if (!neu.manualOpen || pane !== 'classic') return
    let cancelled = false
    setDocLoading(true)
    setDocError(false)
    void fetchManualMarkdown('en').then((text) => {
      if (cancelled) return
      setDocLoading(false)
      if (!text) {
        setDocError(true)
        setDocHtml('')
        return
      }
      setDocHtml(markdownToHtml(text))
    })
    return () => {
      cancelled = true
    }
  }, [neu.manualOpen, pane])

  useEffect(() => {
    pageRef.current?.scrollTo({ top: 0 })
  }, [pageKey])

  if (!neu.manualOpen) return null

  const goBack = () => {
    if (zoom) {
      setZoom(null)
      return
    }
    if (pane === 'frame') {
      setPane('classic')
      setFrameHref('')
      return
    }
    if (pane === 'classic') {
      setPane('manual')
      return
    }
    if (pane === 'manual') {
      setPane('intro')
      return
    }
    neu.closeManual()
  }

  const openResolved = (href: string) => {
    const dest = resolveDocsLink(href, window.location.origin)
    if (!dest) {
      window.open(href, '_blank', 'noopener,noreferrer')
      return
    }
    if (dest.kind === 'download') {
      window.open(dest.href, '_blank', 'noopener,noreferrer')
      return
    }
    if (dest.kind === 'manual') {
      setPane('classic')
      return
    }
    const titles: Record<string, string> = {
      'docs-home': 'Docs home',
      tutorial: 'USB recovery',
      'public-home': 'Public home',
    }
    setFrameTitle(titles[dest.kind] || dest.kind)
    setFrameHref(frameForDocsDest(dest, 'en'))
    setPane('frame')
  }

  const onDocClick = (event: MouseEvent<HTMLDivElement>) => {
    const a = (event.target as HTMLElement | null)?.closest?.('a')
    if (!a) return
    const href = a.getAttribute('href') || a.href
    if (!href) return
    const dest = resolveDocsLink(href, window.location.origin)
    if (!dest) return
    event.preventDefault()
    openResolved(href)
  }

  const toggleChapter = (id: string) =>
    setOpenChapters((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  const goPage = (key: string) => {
    setPageKey(key)
    const chapterId = key.split('/')[0]
    setOpenChapters((prev) => (prev.has(chapterId) ? prev : new Set(prev).add(chapterId)))
  }

  const { current, prev, next } = findManualPage(pageKey)
  const title = pane === 'frame' ? frameTitle : 'os.neu manual'
  const backLabel = pane === 'intro' ? 'Close' : 'Back'
  const cardClass =
    pane === 'manual' ? ' manual-doc manual-tutorial' : pane === 'intro' ? '' : ' manual-doc'

  return (
    <div
      className="manual-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="manual-title"
      onClick={goBack}
    >
      <div className={`manual-card${cardClass}`} onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="manual-title">{title}</h2>
          <div className="manual-head-actions">
            {pane !== 'intro' ? (
              <button type="button" className="docs-back" onClick={goBack} aria-label={backLabel} title={backLabel}>
                ← Back
              </button>
            ) : null}
            <button
              type="button"
              className="exit-x"
              onClick={pane === 'intro' ? () => neu.closeManual() : goBack}
              aria-label={pane === 'intro' ? 'Close' : backLabel}
              title={pane === 'intro' ? 'Close' : backLabel}
            >
              ×
            </button>
          </div>
        </div>
        {pane === 'manual' ? (
          <div className="manual-tut">
            <nav className="manual-tut-nav" aria-label="Manual chapters">
              {MANUAL_CHAPTERS.map((chapter, ci) => {
                const open = openChapters.has(chapter.id)
                return (
                  <div key={chapter.id} className="manual-tut-ch">
                    <button
                      type="button"
                      className="manual-tut-ch-head"
                      aria-expanded={open}
                      onClick={() => toggleChapter(chapter.id)}
                    >
                      <span className="manual-tut-no">{ci + 1}</span>
                      <span className="manual-tut-ch-title">{chapter.title}</span>
                      <span className="manual-tut-caret" aria-hidden>
                        {open ? '▾' : '▸'}
                      </span>
                    </button>
                    {open ? (
                      <ul>
                        {chapter.pages.map((page, pi) => {
                          const key = manualKey({ chapter, page })
                          return (
                            <li key={page.id}>
                              <button
                                type="button"
                                className={key === pageKey ? 'on' : ''}
                                aria-current={key === pageKey ? 'page' : undefined}
                                onClick={() => goPage(key)}
                              >
                                <span className="manual-tut-sub-no">
                                  {ci + 1}.{pi + 1}
                                </span>
                                {page.title}
                                {page.preparing ? <span className="manual-tut-soon">Soon</span> : null}
                              </button>
                            </li>
                          )
                        })}
                      </ul>
                    ) : null}
                  </div>
                )
              })}
              <button type="button" className="manual-tut-classic" onClick={() => setPane('classic')}>
                Full install text (one page)
              </button>
            </nav>
            <article className="manual-tut-page" ref={pageRef}>
              <p className="manual-tut-crumb">
                {current.chapterNo}. {current.chapter.title}
              </p>
              <h3>
                {current.chapterNo}.{current.pageNo} {current.page.title}
              </h3>
              <p className="manual-tut-lead">{current.page.lead}</p>
              {current.page.preparing ? (
                <section className="manual-tut-prep" aria-label="In preparation">
                  <p className="manual-tut-prep-badge">In preparation · screenshot guide</p>
                  {current.page.preparing.video ? (
                    <video
                      className="manual-tut-video"
                      src={manualVideo(current.page.preparing.video)}
                      poster={current.page.preparing.poster ? manualImg(current.page.preparing.poster) : undefined}
                      controls
                      preload="metadata"
                    />
                  ) : (
                    <div className="manual-tut-video-slot" role="img" aria-label="Screenshots coming soon">
                      <span aria-hidden>▣</span>
                      <p>Screenshots coming soon</p>
                      <small>This menu is ready. Step-by-step screenshots will be added here.</small>
                    </div>
                  )}
                  <p className="manual-tut-prep-title">This guide will show</p>
                  <ol>
                    {current.page.preparing.covers.map((line) => (
                      <li key={line}>{line}</li>
                    ))}
                  </ol>
                  {current.chapter.id === 'start' ? (
                    <button type="button" className="manual-tut-classic" onClick={() => setPane('classic')}>
                      Full install text (one page)
                    </button>
                  ) : null}
                </section>
              ) : null}
              <ol className="manual-tut-steps">
                {current.page.steps.map((step, i) => (
                  <li key={`${current.page.id}-${i}`} className="manual-tut-step">
                    <div className="manual-tut-step-head">
                      <span className="manual-tut-step-no">{i + 1}</span>
                      <b>{step.title}</b>
                    </div>
                    <p>{step.text}</p>
                    {step.code ? (
                      <pre>
                        <code>{step.code}</code>
                      </pre>
                    ) : null}
                    {step.img ? (
                      <figure className="manual-tut-shot">
                        <button
                          type="button"
                          className="manual-tut-shot-btn"
                          onClick={() => setZoom({ src: manualImg(step.img!), caption: step.comment || step.title })}
                          title="Click to enlarge"
                        >
                          <img src={manualImg(step.img)} alt={step.title} loading="lazy" />
                        </button>
                        {step.comment ? (
                          <figcaption>
                            <span className="manual-tut-cap-tag">Screen {i + 1}</span>
                            {step.comment}
                          </figcaption>
                        ) : null}
                      </figure>
                    ) : step.comment ? (
                      <p className="manual-tut-note">{step.comment}</p>
                    ) : null}
                  </li>
                ))}
              </ol>
              {current.page.tip ? (
                <p className="manual-tut-tip">
                  <b>Tip</b> {current.page.tip}
                </p>
              ) : null}
              <div className="manual-tut-pager">
                {prev ? (
                  <button type="button" onClick={() => goPage(manualKey(prev))}>
                    <small>Previous</small>← {prev.page.title}
                  </button>
                ) : (
                  <span />
                )}
                {next ? (
                  <button type="button" className="next" onClick={() => goPage(manualKey(next))}>
                    <small>Next</small>
                    {next.page.title} →
                  </button>
                ) : null}
              </div>
            </article>
            {zoom ? (
              <div className="manual-tut-zoom" role="presentation" onClick={() => setZoom(null)}>
                <figure onClick={(event) => event.stopPropagation()}>
                  <img src={zoom.src} alt={zoom.caption} />
                  <figcaption>{zoom.caption}</figcaption>
                  <button type="button" className="exit-x" onClick={() => setZoom(null)} aria-label="Close picture">
                    ×
                  </button>
                </figure>
              </div>
            ) : null}
          </div>
        ) : pane === 'classic' ? (
          <div className="manual-doc-body">
            {docLoading ? <p>Loading…</p> : null}
            {docError ? (
              <p>
                Could not load the document.{' '}
                <a href={DOCS_HOME} onClick={(event) => {
                  event.preventDefault()
                  openResolved(DOCS_HOME)
                }}>
                  {DOCS_HOME.replace('https://', '')}
                </a>
              </p>
            ) : null}
            {docHtml ? (
              <div className="manual-md" dangerouslySetInnerHTML={{ __html: docHtml }} onClick={onDocClick} />
            ) : null}
          </div>
        ) : pane === 'frame' ? (
          <div className="manual-doc-body manual-frame-wrap">
            <iframe className="manual-frame" title={frameTitle} src={frameHref} />
          </div>
        ) : (
          <>
            <p>
              Download, then plant on Linux or Windows, and speak one line. The disk is not wiped. Open
              os.neu manual for the Linux and Windows chapters.
            </p>
            <ul className="manual-list">
              <li>
                <span className="path-glyph">
                  <HostGlyph />
                </span>
                <div>
                  <b>Linux</b>
                  <span>
                    Use the Linux screen pack. After plant, click the os.neu icon. No format. USB burn is
                    Linux only.
                  </span>
                </div>
              </li>
              <li>
                <span className="path-glyph">
                  <HostGlyph />
                </span>
                <div>
                  <b>Windows</b>
                  <span>
                    Use os.neu-Setup.exe for the customer install. The source pack and install-windows.ps1
                    are the developer path.
                  </span>
                </div>
              </li>
              <li>
                <span className="path-glyph">
                  <UsbGlyph />
                </span>
                <div>
                  <b>USB</b>
                  <span>On Linux, download the kit and burn only after you confirm. Reboot, F8 (ASUS), UEFI USB.</span>
                </div>
              </li>
              <li>
                <span className="path-glyph">
                  <GuestGlyph />
                </span>
                <div>
                  <b>Try now</b>
                  <span>Look at this session without installing. To keep it, plant Linux or Windows.</span>
                </div>
              </li>
            </ul>
            <p>
              Tap the mic, speak, tap again — or type one line and send with the speaker. On the landing,
              top-right × quits. Inner screens use Back.
            </p>
            <p className="manual-foot">
              <button type="button" className="manual-docs-link" onClick={() => setPane('manual')}>
                docs.neuavenue.com
              </button>
            </p>
          </>
        )}
      </div>
    </div>
  )
}
