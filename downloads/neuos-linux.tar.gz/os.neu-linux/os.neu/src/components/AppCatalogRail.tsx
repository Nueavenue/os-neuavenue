import { useEffect } from 'react'
import { AppCatalogNav } from './AppCatalogNav'
import { MvpNav } from './MvpNav'
import { useAppCatalog } from './appCatalogApi'
import { useI18n } from '../i18n/LocaleContext'

export function AppCatalogRail() {
  const { hidden, host, open, setOpen } = useAppCatalog()
  const { locale } = useI18n()
  const ko = locale === 'ko'

  useEffect(() => {
    const root = document.querySelector('.os-screen')
    if (!root) return
    if (hidden || host === 'nested') {
      root.classList.remove('has-app-catalog', 'app-catalog-open')
      return
    }
    root.classList.add('has-app-catalog')
    root.classList.toggle('app-catalog-open', open)
    return () => {
      root.classList.remove('has-app-catalog', 'app-catalog-open')
    }
  }, [hidden, host, open])

  if (hidden || host === 'nested') return null

  const label = open ? (ko ? '앱 목록 숨기기' : 'Hide apps') : ko ? '앱 목록 펼치기' : 'Show apps'

  return (
    <aside className={`app-catalog-rail${open ? ' open' : ''}`} aria-label={ko ? 'app.neu 앱 막대' : 'app.neu app bar'}>
      <button
        type="button"
        className="app-catalog-toggle"
        aria-expanded={open}
        aria-controls="app-catalog-panel"
        title={label}
        onClick={() => setOpen(!open)}
      >
        <span className="app-catalog-toggle-mark" aria-hidden>
          ▦
        </span>
        <span className="app-catalog-toggle-chevron" aria-hidden>
          {open ? '‹' : '›'}
        </span>
        <span className="app-catalog-toggle-text">{open ? 'app.neu' : ''}</span>
      </button>
      {open ? (
        <div id="app-catalog-panel" className="app-catalog-panel">
          <MvpNav />
          <p className="app-catalog-title">app.neu</p>
          <AppCatalogNav variant="rail" />
        </div>
      ) : null}
    </aside>
  )
}

export function AppCatalogNested() {
  const { hidden, registerNested, open, setOpen } = useAppCatalog()
  const { locale } = useI18n()
  const ko = locale === 'ko'

  useEffect(() => {
    if (hidden) return undefined
    return registerNested()
  }, [hidden, registerNested])

  if (hidden) return null

  return (
    <div className="app-catalog-nested">
      <button
        type="button"
        className="app-catalog-toggle nested"
        aria-expanded={open}
        title={open ? (ko ? '앱 목록 숨기기' : 'Hide apps') : ko ? '앱 목록 펼치기' : 'Show apps'}
        onClick={() => setOpen(!open)}
      >
        <span className="app-catalog-toggle-mark" aria-hidden>
          ▦
        </span>
        <span className="app-catalog-toggle-burger" aria-hidden>
          ☰
        </span>
        <span className="app-catalog-toggle-chevron" aria-hidden>
          {open ? '‹' : '›'}
        </span>
        <span className="app-catalog-toggle-text">app.neu</span>
      </button>
      {open ? (
        <div className="app-catalog-nested-body">
          <MvpNav />
          <AppCatalogNav variant="nested" />
        </div>
      ) : null}
    </div>
  )
}
