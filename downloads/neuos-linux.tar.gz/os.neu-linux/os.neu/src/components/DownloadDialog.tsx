import { HostGlyph } from './PathGlyphs'
import { usbKitHref } from '../engine/linuxPack'
import { detectGuestOsNow, packForGuestOs } from '../engine/detectOs'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function DownloadDialog() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  if (!neu.downloadOpen) return null

  const host = typeof window !== 'undefined' ? window.location.hostname : ''
  const guest = detectGuestOsNow()
  const pack = packForGuestOs(guest, host)
  const usbHref = usbKitHref(host)
  const label = { linux: 'Linux', windows: 'Windows', macos: 'macOS', chromeos: 'ChromeOS', unknown: ko ? '이 PC' : 'this PC' }[guest]

  return (
    <div
      className="manual-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="download-title"
      onClick={neu.closeDownload}
    >
      <div className="manual-card" onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="download-title">{ko ? 'os.neu 스크린 받기' : 'Get the os.neu screen'}</h2>
          <button type="button" className="exit-x" onClick={neu.closeDownload} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </div>
        <p>
          {ko
            ? `이 브라우저는 ${label} 로 보입니다. 웹 사이트는 CPU·RAM을 읽지 않습니다. 설치 파일만 OS에 맞춰 고릅니다.`
            : `This browser looks like ${label}. The public site does not read CPU or RAM. It only picks the pack for the OS.`}
        </p>
        {pack.available ? (
          <>
            <ol className="download-steps">
              <li>
                <b>{ko ? '받기' : 'Download'}</b>
                <span>{ko ? `${pack.file} 를 이 PC에 저장합니다.` : `Save ${pack.file} on this PC.`}</span>
              </li>
              <li>
                <b>{ko ? '설치' : 'Install'}</b>
                <span>
                  {ko
                    ? '터미널에서 tar -xzf neuos-linux.tar.gz 다음 bash os.neu-linux/install.sh'
                    : 'In a terminal: tar -xzf neuos-linux.tar.gz then bash os.neu-linux/install.sh'}
                </span>
              </li>
              <li>
                <b>{ko ? '실행' : 'Open'}</b>
                <span>
                  {ko
                    ? '앱 보기(Show Apps) 또는 바탕화면의 os.neu 아이콘. 별도 브라우저가 아닙니다.'
                    : 'Click os.neu in Show Apps or on the Desktop. That is the app, not another browser window.'}
                </span>
              </li>
            </ol>
            <div className="download-actions">
              <a className="download-primary" href={pack.href} target="_blank" rel="noreferrer">
                <HostGlyph />
                {ko ? 'Linux 스크린 받기' : 'Get Linux screen'}
              </a>
              <a className="download-secondary" href={usbHref}>
                {ko ? 'USB 키트' : 'USB kit'}
              </a>
            </div>
          </>
        ) : (
          <>
            <p className="install-linux-note">
              {ko
                ? `${label} 용 설치 파일은 아직 없습니다. 지금 심기·아이콘·독립 스크린은 Linux만 됩니다. Windows·macOS·ChromeOS 팩은 별도 빌드가 필요합니다.`
                : `No ${label} installer ships yet. Plant, app icon, and the independent screen are Linux only. Windows, macOS, and ChromeOS need their own builds.`}
            </p>
            <div className="download-actions">
              <a className="download-secondary" href={usbHref}>
                {ko ? 'USB 키트 (Linux에서 굽기)' : 'USB kit (burn on Linux)'}
              </a>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
