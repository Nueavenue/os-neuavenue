import { useEffect, useState } from 'react'
import {
  allModelOptions,
  approxTokens,
  clearPermissionLog,
  loadAiPrefs,
  loadPermissionLog,
  modelOption,
  modelReady,
  patchAiPrefs,
  shownModelOptions,
  type PermissionLogRow,
} from '../engine/aiPrefs'
import { fetchDriverConsent, setDriverConsent } from '../engine/bridge'
import { fetchLlmSettings, pingLlm, type LlmSettingsView } from '../engine/llmConnect'
import { loadWorks, saveWorks, setActiveWorkId } from '../engine/mvpWork'
import { onOpenSettings, publishSettingsVisibility, type SettingsSection } from '../engine/settingsBus'
import { useAiPrefs, useAiUsage } from '../hooks/useAiPrefs'
import { useAppVersionLabel } from '../hooks/useAppVersionLabel'
import { useI18n } from '../i18n/LocaleContext'
import { useMvpWork } from '../state/mvpWorkContext'
import { useNeu } from '../state/neuContext'
import { AiConnectDialog } from './AiConnectDialog'
import { BatteryReadout } from './SeatPowerChrome'

const LOCAL_SERVICE_ID = 'llama3.2:1b'

const SECTIONS: Array<{ id: SettingsSection; ko: string; en: string }> = [
  { id: 'power', ko: '전원·오프라인', en: 'Power & offline' },
  { id: 'ai', ko: 'AI 및 사용량', en: 'AI & Usage' },
  { id: 'privacy', ko: '개인정보와 권한', en: 'Privacy & Permissions' },
  { id: 'help', ko: '도움말', en: 'Help' },
]

export function SettingsPanel() {
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [section, setSection] = useState<SettingsSection | null>(null)
  const [connectFor, setConnectFor] = useState<string | null>(null)
  const [view, setView] = useState<LlmSettingsView | null>(null)
  const settingsOpen = section !== null

  useEffect(() => onOpenSettings((next) => setSection(next)), [])

  useEffect(() => {
    publishSettingsVisibility(settingsOpen)
    if (settingsOpen) return () => publishSettingsVisibility(false)
  }, [settingsOpen])

  useEffect(() => {
    if (!section || connectFor) return
    void fetchLlmSettings().then(setView)
  }, [section, connectFor])

  if (!section) return null

  if (connectFor !== null) {
    return <AiConnectDialog open preferModel={connectFor || undefined} onClose={() => setConnectFor(null)} />
  }

  return (
    <div className="mvp-modal-scrim settings-scrim" role="presentation" onClick={() => setSection(null)}>
      <div
        className="mvp-modal settings-panel"
        role="dialog"
        aria-modal
        aria-label={ko ? '설정·도움말' : 'Settings · Help'}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="mvp-modal-head">
          <h2>{ko ? '설정·도움말' : 'Settings · Help'}</h2>
          <button type="button" className="icon-btn" onClick={() => setSection(null)} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </header>
        <div className="settings-body">
          <nav className="settings-nav" aria-label={ko ? '설정 메뉴' : 'Settings menu'}>
            {SECTIONS.map((row) => (
              <button
                key={row.id}
                type="button"
                className={row.id === section ? 'on' : ''}
                onClick={() => setSection(row.id)}
              >
                {ko ? row.ko : row.en}
              </button>
            ))}
          </nav>
          <div className="settings-page">
            {section === 'ai' ? <AiUsagePage ko={ko} view={view} onConnect={(id) => setConnectFor(id)} /> : null}
            {section === 'power' ? <PowerPage ko={ko} /> : null}
            {section === 'privacy' ? <PrivacyPage ko={ko} /> : null}
            {section === 'help' ? <HelpPage ko={ko} onDone={() => setSection(null)} /> : null}
          </div>
        </div>
      </div>
    </div>
  )
}

function PowerPage({ ko }: { ko: boolean }) {
  const neu = useNeu()
  const prefs = useAiPrefs()
  const setLocal = (on: boolean) => {
    if (!on) {
      patchAiPrefs({ localService: false })
      return
    }
    const saved = loadAiPrefs()
    const shown = saved.shown.includes(LOCAL_SERVICE_ID) ? saved.shown : [...saved.shown, LOCAL_SERVICE_ID]
    patchAiPrefs({ localService: true, draftMode: 'local', shown, defaultModel: LOCAL_SERVICE_ID })
    neu.setOfficeModel(LOCAL_SERVICE_ID)
  }
  return (
    <div className="settings-sections">
      <section>
        <h3>{ko ? '이 PC의 로컬 모델' : 'Local model on this PC'}</h3>
        <p className="settings-line">
          <BatteryReadout ko={ko} />
        </p>
        <p className="settings-note">
          {ko
            ? '네트워크가 없어도, 이 PC에 이미 켜 둔 모델로 초안을 쓰려면 아래를 켭니다. 모델을 받아 주는 화면은 아닙니다. AI 및 사용량에서 크기를 고릅니다.'
            : 'Turn this on to draft with a model already running on this PC when the network is down. This page does not download a model. Pick the size under AI & Usage.'}
        </p>
        <label className="settings-line">
          <input type="checkbox" checked={prefs.localService} onChange={(e) => setLocal(e.target.checked)} />
          {ko ? '로컬 모델 쓰기' : 'Use a local model'}
        </label>
        <p className="settings-note">
          {prefs.localService
            ? ko
              ? `켜짐 · 기본 모델 ${LOCAL_SERVICE_ID}. 이 PC에 그 모델이 없으면 초안은 시작되지 않습니다.`
              : `On · default ${LOCAL_SERVICE_ID}. Drafts do not start if that model is not on this PC.`
            : ko
              ? '꺼짐'
              : 'Off'}
        </p>
      </section>
      <section>
        <h3>{ko ? '오프라인 초안 방식' : 'How offline drafts work'}</h3>
        <label className="settings-line">
          <input
            type="radio"
            name="draft-mode"
            checked={prefs.draftMode !== 'web-cache'}
            onChange={() => patchAiPrefs({ draftMode: 'local' })}
          />
          {ko ? '이 PC의 로컬 모델 (동작)' : 'Local model on this PC (works)'}
        </label>
        <label className="settings-line">
          <input
            type="radio"
            name="draft-mode"
            checked={prefs.draftMode === 'web-cache'}
            onChange={() => patchAiPrefs({ draftMode: 'web-cache' })}
          />
          {ko ? '웹 앱 캐시 (선택만 저장 · 아직 동작 안 함)' : 'Web-app cache (choice only · not built)'}
        </label>
        <p className="settings-note">
          {ko
            ? '웹 앱 캐시는 크롬북이 2011–2012년에 쓴 방식입니다. os.neu는 그 캐시를 아직 만들지 않았습니다. 고르면 이 기기에만 기록되고, 문서를 오프라인으로 열지는 않습니다.'
            : 'Web-app cache is what Chromebooks used in 2011–2012. os.neu does not cache web apps yet. The choice is stored on this device only and does not open documents offline.'}
        </p>
      </section>
    </div>
  )
}

function AiUsagePage({ ko, view, onConnect }: { ko: boolean; view: LlmSettingsView | null; onConnect: (id: string) => void }) {
  const neu = useNeu()
  const prefs = useAiPrefs()
  const usage = useAiUsage()
  const [testMsg, setTestMsg] = useState('')
  const [testing, setTesting] = useState(false)
  const shown = shownModelOptions(prefs)
  const all = allModelOptions()
  const target = prefs.defaultModel || neu.officeModel

  const toggle = (id: string, on: boolean) => {
    const saved = loadAiPrefs()
    const rest = saved.shown.filter((row) => row !== id)
    const next = on ? [...rest, id] : rest
    const defaultModel = next.includes(saved.defaultModel) ? saved.defaultModel : next[0] || ''
    patchAiPrefs({ shown: next, defaultModel })
    if (defaultModel) neu.setOfficeModel(defaultModel)
  }

  const test = async () => {
    setTesting(true)
    setTestMsg(ko ? '시험 중… (이 기기 AI는 최대 1분)' : 'Testing… (on-device AI may take up to 1 min)')
    try {
      const result = await pingLlm(target)
      setTestMsg(
        result.ok
          ? ko
            ? `연결됨 · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`
            : `Connected · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`
          : ko
            ? `연결 안 됨 · ${result.reason || '실패'}`
            : `Not connected · ${result.reason || 'failed'}`,
      )
    } catch {
      setTestMsg(ko ? '연결 안 됨 · network' : 'Not connected · network')
    } finally {
      setTesting(false)
    }
  }

  return (
    <div className="settings-sections">
      <section>
        <h3>{ko ? 'AI 연결' : 'AI connection'}</h3>
        <p className="settings-line">
          {ko ? '시험할 모델: ' : 'Model to test: '}
          <strong>{modelOption(target)?.label || target}</strong>
        </p>
        <div className="mvp-modal-actions">
          <button type="button" onClick={() => void test()} disabled={testing}>
            {ko ? '연결 시험' : 'Test connection'}
          </button>
          <button type="button" onClick={() => onConnect(target)}>
            {ko ? '키 연결·바꾸기' : 'Connect or change key'}
          </button>
        </div>
        {testMsg ? <p className="settings-note">{testMsg}</p> : null}
      </section>

      <section>
        <h3>{ko ? '기본 모델' : 'Default model'}</h3>
        <select
          className="model-select"
          value={prefs.defaultModel}
          onChange={(e) => {
            patchAiPrefs({ defaultModel: e.target.value })
            neu.setOfficeModel(e.target.value)
          }}
          disabled={!shown.length}
        >
          {shown.length ? null : <option value="">{ko ? '먼저 아래에서 모델을 켜세요' : 'Turn on a model below first'}</option>}
          {shown.map((row) => (
            <option key={row.id} value={row.id}>
              {row.label}
            </option>
          ))}
        </select>
        <p className="settings-note">{ko ? '새 작업과 문서·시트·슬라이드가 처음 쓰는 모델입니다.' : 'Used first by new work and Docs / Sheets / Slides.'}</p>
      </section>

      <section>
        <h3>{ko ? '화면에 보일 모델' : 'Models shown on screen'}</h3>
        <p className="settings-note">
          {ko
            ? '여기서 켠 모델만 문서·시트·슬라이드 버튼과 편집기 모델 목록에 나옵니다. 키가 있거나 이 기기에 설치된 모델만 켤 수 있습니다.'
            : 'Only models turned on here appear in the Docs / Sheets / Slides buttons and editor model lists. A model needs a key or an on-device install before it can be turned on.'}
        </p>
        <ul className="settings-models">
          {all.map((row) => {
            const on = prefs.shown.includes(row.id)
            const ready = modelReady(row.id, view)
            return (
              <li key={row.id}>
                <label>
                  <input type="checkbox" checked={on} disabled={!on && !ready} onChange={(e) => toggle(row.id, e.target.checked)} />
                  <span>{row.label}</span>
                </label>
                <small>
                  {view
                    ? ready
                      ? row.kind === 'cloud'
                        ? ko
                          ? '키 있음'
                          : 'Key on'
                        : ko
                          ? '설치됨'
                          : 'Installed'
                      : row.kind === 'cloud'
                        ? ko
                          ? '키 필요'
                          : 'Needs key'
                        : ko
                          ? '이 기기에 없음'
                          : 'Not on this device'
                    : '…'}
                </small>
                {!ready && row.kind === 'cloud' ? (
                  <button type="button" className="settings-link" onClick={() => onConnect(row.id)}>
                    {ko ? '키 연결' : 'Connect'}
                  </button>
                ) : null}
              </li>
            )
          })}
        </ul>
      </section>

      <section>
        <h3>{ko ? '사용량' : 'Usage'}</h3>
        <p className="settings-line">
          {ko
            ? `오늘 ${usage.dayCount}회${prefs.dailyLimit ? ` / 상한 ${prefs.dailyLimit}회` : ''} · 이번 달 ${usage.monthCount}회 · 약 ${approxTokens(usage.monthChars).toLocaleString()} 토큰`
            : `Today ${usage.dayCount}${prefs.dailyLimit ? ` / limit ${prefs.dailyLimit}` : ''} · This month ${usage.monthCount} · about ${approxTokens(usage.monthChars).toLocaleString()} tokens`}
        </p>
        <p className="settings-note">
          {ko
            ? '문서·시트·슬라이드, 시작 화면 대화, 영어회화, 마이크 받아쓰기 요청을 이 기기에서 센 값입니다. 토큰은 글자 수로 어림한 값이고, 금액은 각 AI 회사 청구서가 기준입니다. os.neu는 금액을 계산하지 않습니다.'
            : 'Counted on this device for Docs / Sheets / Slides, start-screen chat, English practice, and microphone dictation. Tokens are estimated from characters. Money follows each AI company’s bill; os.neu does not calculate cost.'}
        </p>
      </section>

      <section>
        <h3>{ko ? '하루 요청 상한' : 'Daily request limit'}</h3>
        <label className="settings-line">
          <input
            type="number"
            min={0}
            step={10}
            className="settings-number"
            value={prefs.dailyLimit}
            onChange={(e) => patchAiPrefs({ dailyLimit: Math.max(0, Math.floor(Number(e.target.value) || 0)) })}
          />{' '}
          {ko ? '회 (0 = 상한 없음)' : 'requests (0 = no limit)'}
        </label>
        <p className="settings-note">
          {ko
            ? '경고가 아니라 실제 상한입니다. 넘으면 위의 AI 요청을 보내지 않습니다. 연결 시험은 세지 않습니다.'
            : 'A real limit, not a warning: past it, the AI requests above are not sent. Connection tests are not counted.'}
        </p>
      </section>

      <section>
        <h3>{ko ? '고급 · 내 API 키' : 'Advanced · Your API keys'}</h3>
        <p className="settings-note">
          {ko
            ? '키는 사용자 소유입니다(BYOK). 이 기기의 ~/os.neu/data/user-llm.json 에만 저장되고, 요금은 각 AI 회사가 사용자에게 직접 청구합니다.'
            : 'Keys belong to you (BYOK). They stay on this device in ~/os.neu/data/user-llm.json, and each AI company bills you directly.'}
        </p>
        <div className="mvp-modal-actions">
          <button type="button" onClick={() => onConnect('')}>
            {ko ? '키 관리 열기' : 'Open key manager'}
          </button>
        </div>
      </section>
    </div>
  )
}

function PrivacyPage({ ko }: { ko: boolean }) {
  const neu = useNeu()
  const mvp = useMvpWork()
  const prefs = useAiPrefs()
  const [log, setLog] = useState<PermissionLogRow[]>(() => loadPermissionLog())
  const [screenOn, setScreenOn] = useState(false)
  const current = modelOption(neu.officeModel)
  const workCount = mvp.works.length

  useEffect(() => {
    void fetchDriverConsent().then((row) => setScreenOn(Boolean(row.on)))
  }, [])

  return (
    <div className="settings-sections">
      <section>
        <h3>{ko ? '화면 제어' : 'Screen control'}</h3>
        <p className="settings-note">
          {ko
            ? '기본은 꺼져 있습니다. 켜기 전에 한 번 확인합니다. 기존 화면은 그대로이고, 허용 전에는 연습(dry-run)만 합니다.'
            : 'Off by default. os.neu asks once before it turns on. Existing screens stay the same; until you allow it, moves stay dry-run.'}
        </p>
        <label className="settings-line">
          <input
            type="checkbox"
            checked={screenOn}
            onChange={(e) => {
              const want = e.target.checked
              if (want) {
                const ok = window.confirm(
                  ko
                    ? 'os.neu가 이 기기의 마우스와 키보드를 움직이게 할까요? 허용한 뒤에만 화면 제어가 켜집니다.'
                    : 'Allow os.neu to move the mouse and type on this device? Screen control stays off until you agree.',
                )
                if (!ok) return
              }
              void setDriverConsent(want).then((row) => setScreenOn(Boolean(row.on)))
            }}
          />{' '}
          {ko ? '화면 제어 허용' : 'Allow screen control'}
        </label>
      </section>
      <section>
        <h3>{ko ? 'AI가 읽는 것' : 'What the AI reads'}</h3>
        <ul className="settings-facts">
          <li>
            {ko
              ? '파일: 문서·시트·슬라이드에서 지금 연 내용과 고른 부분만 AI 요청에 들어갑니다.'
              : 'Files: only the content open in Docs / Sheets / Slides and the part you selected go into an AI request.'}
          </li>
          <li>
            {ko
              ? '웹: [자료로 추가]한 주소만 이 작업의 웹 자료로 남습니다. 페이지 본문을 AI가 읽는 기능은 아직 없습니다.'
              : 'Web: only addresses you add with [Add as source] stay as this task’s web sources. The AI does not read page text yet.'}
          </li>
        </ul>
      </section>

      <section>
        <h3>{ko ? '바깥 AI로 보내는 것' : 'What goes to an outside AI'}</h3>
        <p className="settings-line">
          {ko ? '지금 모델: ' : 'Current model: '}
          <strong>{current?.label || neu.officeModel}</strong>
          {current?.kind === 'cloud'
            ? ko
              ? ` → ${current.vendor} 서버로 갑니다`
              : ` → goes to ${current.vendor}`
            : ko
              ? ' → 이 기기 안에서 계산합니다'
              : ' → computed on this device'}
        </p>
        <ul className="settings-facts">
          <li>{ko ? '보내는 것: 요청 문장, 문서 본문 또는 고른 부분, 최근 대화 몇 줄' : 'Sent: your request, the document text or selection, a few recent turns'}</li>
          <li>{ko ? '보내지 않는 것: 다른 작업, 저장된 키, 방문 기록' : 'Not sent: other work, saved keys, browsing history'}</li>
          <li>
            {ko
              ? '마이크 받아쓰기와 영어회화는 고른 모델과 상관없이 OpenAI로 갑니다 (음성 또는 연습 문장).'
              : 'Microphone dictation and English practice always go to OpenAI, whatever model is chosen (audio or practice sentence).'}
          </li>
          <li>
            {ko
              ? '각 AI 회사가 받은 데이터를 어떻게 다루는지는 그 회사 정책을 따르며, os.neu 설정으로 바뀌지 않습니다.'
              : 'How each AI company handles what it receives follows that company’s policy; os.neu settings do not change it.'}
          </li>
        </ul>
        <label className="settings-line">
          <input type="checkbox" checked={prefs.confirmFirstSend} onChange={(e) => patchAiPrefs({ confirmFirstSend: e.target.checked })} />{' '}
          {ko ? '회사마다 처음 보낼 때 확인하기' : 'Ask before the first send to each company'}
        </label>
        {prefs.consented.length ? (
          <div className="settings-line">
            {ko ? '허용한 회사: ' : 'Allowed: '}
            {prefs.consented.join(', ')}{' '}
            <button type="button" className="settings-link" onClick={() => patchAiPrefs({ consented: [] })}>
              {ko ? '다시 묻기' : 'Ask again'}
            </button>
          </div>
        ) : null}
      </section>

      <section>
        <h3>{ko ? '묻지 않고 하는 일' : 'What happens without asking'}</h3>
        <ul className="settings-facts">
          <li>
            {ko
              ? 'AI 문서 수정: 지금은 답이 문서에 바로 들어갑니다. “바꿀 내용 먼저 보여주기”는 다음 단계입니다.'
              : 'AI document edits: replies go straight into the document today. “Show changes first” is the next step.'}
          </li>
          <li>{ko ? '하루 요청 상한을 넘으면 묻지 않고 막습니다.' : 'Past the daily limit, requests are blocked without asking.'}</li>
        </ul>
      </section>

      <section>
        <h3>{ko ? '기록과 삭제' : 'Records and deletion'}</h3>
        <p className="settings-line">
          {ko ? `내 작업 ${workCount}개` : `${workCount} saved work items`}{' '}
          <button
            type="button"
            className="settings-link"
            disabled={!workCount}
            onClick={() => {
              const ok = window.confirm(
                ko
                  ? `내 작업 목록 ${workCount}개를 지웁니다. 작업에 연결된 문서 파일은 지워지지 않습니다. 계속할까요?`
                  : `Remove ${workCount} items from My work? Linked document files are not deleted. Continue?`,
              )
              if (!ok) return
              saveWorks([])
              setActiveWorkId(null)
              mvp.refresh()
              mvp.clearActive()
            }}
          >
            {ko ? '목록 지우기' : 'Clear list'}
          </button>
        </p>
        <p className="settings-note">{ko ? `이 기기에 저장된 작업: ${loadWorks().length}개` : `Work stored on this device: ${loadWorks().length}`}</p>
        <h4>{ko ? '최근 허용·차단 기록' : 'Recent allow / block log'}</h4>
        {log.length ? (
          <ul className="settings-log">
            {log.slice(0, 10).map((row) => (
              <li key={row.at}>
                <small>{new Date(row.at).toLocaleString(ko ? 'ko-KR' : 'en-US')}</small> {ko ? row.textKo : row.textEn}
              </li>
            ))}
          </ul>
        ) : (
          <p className="settings-note">{ko ? '아직 기록이 없습니다.' : 'No entries yet.'}</p>
        )}
        {log.length ? (
          <button
            type="button"
            className="settings-link"
            onClick={() => {
              clearPermissionLog()
              setLog([])
            }}
          >
            {ko ? '기록 지우기' : 'Clear log'}
          </button>
        ) : null}
      </section>
    </div>
  )
}

function HelpPage({ ko, onDone }: { ko: boolean; onDone: () => void }) {
  const neu = useNeu()
  const ver = useAppVersionLabel()
  return (
    <div className="settings-sections">
      <section>
        <h3>{ko ? '정보' : 'About'}</h3>
        <p className="settings-note">
          {ko ? `os.neu ${ver} · NeuAvenue Inc.` : `os.neu ${ver} · NeuAvenue Inc.`}
        </p>
        <p className="settings-note">
          {ko
            ? '브랜드 마크(OS.neu 옆)와 창 제목에도 같은 버전이 표시됩니다. Windows Setup · Linux plant 모두 동일합니다.'
            : 'The same version appears next to the OS.neu brand mark and in the window title. Windows Setup and Linux plant share it.'}
        </p>
      </section>
      <section>
        <h3>{ko ? '도움말' : 'Help'}</h3>
        <div className="mvp-modal-actions">
          <button
            type="button"
            onClick={() => {
              onDone()
              neu.openManual()
            }}
          >
            {ko ? '매뉴얼 열기' : 'Open manual'}
          </button>
          <button
            type="button"
            onClick={() => {
              onDone()
              neu.setAuthPanel('feedback')
            }}
          >
            {ko ? '문제 신고' : 'Report a problem'}
          </button>
        </div>
      </section>
      <section>
        <h3>{ko ? '다음 단계에 들어올 설정' : 'Coming in later steps'}</h3>
        <p className="settings-note">
          {ko
            ? '일반과 접근성 · 작업 공간과 기억 · 문서(app.neu) · 웹과 조사(daf.neu) · 계정과 연결 · 파일과 복구 · 기기와 화면 · 정보·업데이트·진단'
            : 'General & Accessibility · Workspace & Memory · Documents (app.neu) · Web & Research (daf.neu) · Accounts & Connections · Files & Recovery · Device & Display · About, Updates & Diagnostics'}
        </p>
      </section>
    </div>
  )
}
