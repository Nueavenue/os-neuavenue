import { useEffect, useState } from 'react'
import { detectCraftBins } from '../engine/craftDetect'
import { craftLaunchFromBridge, planCraftLaunch, type CraftLaunchTile } from '../engine/craftLaunch'

export function useCraftLaunchTiles() {
  const [tiles, setTiles] = useState<CraftLaunchTile[]>(() => planCraftLaunch())
  useEffect(() => {
    let live = true
    const load = async () => {
      let detect: { wordcraft?: string | null; gridcraft?: string | null; deckcraft?: string | null } | null = null
      let web: { present?: boolean } | null = null
      try {
        const res = await fetch('/api/craft/detect', { signal: AbortSignal.timeout(800) })
        if (res.ok) detect = (await res.json()) as typeof detect
      } catch {
        detect = null
      }
      try {
        const res = await fetch('/api/craft/web', { signal: AbortSignal.timeout(800) })
        if (res.ok) web = (await res.json()) as typeof web
      } catch {
        web = null
      }
      if (!live) return
      if (!detect && !web) {
        setTiles(planCraftLaunch(detectCraftBins({}), false))
        return
      }
      setTiles(craftLaunchFromBridge(detect, web))
    }
    void load()
    return () => {
      live = false
    }
  }, [])
  return tiles
}
