import { useState } from 'react'
import { firstDoc, isDocStored, loadDocProjects, upsertDocProject } from '../engine/docProjects'
import { saveDocumentFile } from '../engine/docExport'
import { confirmWorkSaved, exportOutcome, type ExportResult } from '../engine/mvpWork'
import { useMvpWork } from '../state/mvpWorkContext'
import { useI18n } from '../i18n/LocaleContext'

export function MvpSaveDialog() {
  const mvp = useMvpWork()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const work = mvp.active
  const [busy, setBusy] = useState(false)
  const [hint, setHint] = useState('')
  if (!mvp.saveOpen || !work) return null

  const readDoc = () => {
    const rows = loadDocProjects()
    const hit = (work.docId && rows.find((row) => row.id === work.docId && row.kind === 'doc')) || firstDoc(rows)
    return hit
  }

  // "Saved" is shown only after both records are read back from storage.
  const saveLocal = () => {
    const doc = readDoc()
    const updated = Date.now()
    upsertDocProject(loadDocProjects(), { ...doc, updated })
    const at = mvp.markSaved()
    const ok = isDocStored(doc.id, updated) && at != null && confirmWorkSaved(work.id, at)
    setHint(
      ok
        ? ko
          ? '저장됨 — 내 작업 (이 기기)'
          : 'Saved — My work (this device)'
        : ko
          ? '저장하지 못했습니다. 다시 시도해 주세요.'
          : 'Could not save. Please try again.',
    )
  }

  const exportDocx = async () => {
    const doc = readDoc()
    setBusy(true)
    setHint('')
    try {
      const result = (await saveDocumentFile({
        title: doc.title || work.title,
        body: doc.body,
        format: 'docx',
      })) as ExportResult
      const outcome = exportOutcome(result)
      if (outcome === 'saved') {
        mvp.markSaved()
        setHint(ko ? `저장됨 — ${result.path}` : `Saved — ${result.path}`)
      } else if (outcome === 'download') {
        setHint(
          ko
            ? '내려받기를 시작했습니다. 저장 위치는 브라우저에서 확인해 주세요.'
            : 'Download started. Check the location in your browser.',
        )
      } else if (outcome === 'cancelled') {
        setHint(ko ? '내보내기를 취소했습니다.' : 'Export cancelled.')
      } else if (outcome === 'unverified') {
        setHint(ko ? '저장 결과를 확인하지 못했습니다.' : 'Could not confirm the file was saved.')
      } else {
        setHint(ko ? '내보내기에 실패했습니다.' : 'Export failed.')
      }
    } catch {
      setHint(ko ? '내보내기에 실패했습니다.' : 'Export failed.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mvp-modal-scrim" role="presentation" onClick={() => mvp.setSaveOpen(false)}>
      <div
        className="mvp-modal"
        role="dialog"
        aria-modal="true"
        aria-label={ko ? '보고서 저장' : 'Save report'}
        onClick={(e) => e.stopPropagation()}
      >
        <h3>{ko ? '보고서 저장' : 'Save report'}</h3>
        <p>
          {ko ? '제목' : 'Title'}: <strong>{work.title}</strong>
        </p>
        <p>{ko ? '위치: 내 작업 (이 기기)' : 'Location: My work (this device)'}</p>
        {hint ? (
          <p className="mvp-modal-hint" role="status" aria-live="polite">
            {hint}
          </p>
        ) : null}
        <div className="mvp-modal-actions">
          <button type="button" className="primary" disabled={busy} onClick={saveLocal}>
            {ko ? '저장' : 'Save'}
          </button>
          <button type="button" disabled={busy} onClick={() => void exportDocx()}>
            {ko ? '파일로 내보내기 (.docx)' : 'Export file (.docx)'}
          </button>
          <button type="button" onClick={() => mvp.setSaveOpen(false)}>
            {ko ? '닫기' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  )
}
