import { useState } from 'react'
import { ChatThread } from './ChatThread'
import { PromptDock } from './PromptDock'
import { TalkProjects } from './TalkProjects'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

type TalkMode = 'hidden' | 'compact' | 'open'

export function TalkDrawer() {
  const neu = useNeu()
  const { locale } = useI18n()
  const [mode, setMode] = useState<TalkMode>('hidden')
  const cycle = () => {
    setMode((cur) => (cur === 'hidden' ? 'compact' : cur === 'compact' ? 'open' : 'hidden'))
  }
  const close = () => setMode('hidden')
  const label =
    locale === 'ko'
      ? mode === 'hidden'
        ? '대화 열기'
        : mode === 'compact'
          ? '대화 넓히기'
          : '대화 숨기기'
      : mode === 'hidden'
        ? 'Show chat'
        : mode === 'compact'
          ? 'Expand chat'
          : 'Hide chat'
  const closeLabel = locale === 'ko' ? '닫기' : 'Close'

  return (
    <div className={`talk-drawer ${mode}`}>
      <button type="button" className="talk-handle" onClick={cycle} aria-label={label} title={label}>
        <span className={`talk-arrow ${mode}`}>{mode === 'open' ? '▾' : '▴'}</span>
      </button>
      {mode !== 'hidden' ? (
        <div className="talk-panel">
          <div className="talk-panel-head">
            <button
              type="button"
              className="exit-x talk-close"
              onClick={close}
              aria-label={closeLabel}
              title={closeLabel}
            >
              ×
            </button>
          </div>
          <div className="talk-panel-body">
            <TalkProjects />
            <div className="talk-main">
              <ChatThread
                turns={neu.chats.slice(-10)}
                empty={locale === 'ko' ? '말하면 여기에 대화가 쌓입니다.' : 'Talk and the thread appears here.'}
              />
              {mode === 'open' ? (
                <PromptDock onSubmit={(text, opts) => void neu.submit(text, opts)} hideThread />
              ) : null}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}
