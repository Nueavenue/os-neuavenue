import type { LayerId } from '../types'

const LAYERS: { id: LayerId; label: string }[] = [
  { id: 'lui', label: 'Speech' },
  { id: 'vlm', label: 'Eyes' },
  { id: 'orchestrator', label: 'Brain' },
  { id: 'driver', label: 'Hands' },
]

type LayerRailProps = {
  active: LayerId[]
  onOpen: () => void
}

export function LayerRail({ active, onOpen }: LayerRailProps) {
  return (
    <div className="layer-rail" aria-label="Four-layer status">
      {LAYERS.map((layer) => (
        <button
          key={layer.id}
          type="button"
          className={active.includes(layer.id) ? 'layer-dot on' : 'layer-dot'}
          title={layer.label}
          onClick={onOpen}
        />
      ))}
    </div>
  )
}
