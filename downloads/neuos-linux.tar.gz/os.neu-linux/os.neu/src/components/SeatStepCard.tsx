import { seatCardLines } from '../engine/seatCard'
import type { SeatGate, SeatStep } from '../engine/seatRun'
import type { ReactNode } from 'react'

type SeatStepCardProps = {
  steps: SeatStep[]
  output: string
  gate: SeatGate
  ko: boolean
  expanded: boolean
  onToggle: () => void
  onChoose?: (choice: 'draft' | 'open-url' | 'stop') => void
  canOpenUrl?: boolean
  hint?: ReactNode
  writing?: boolean
  onStopWrite?: () => void
}

export function SeatStepCard({
  steps,
  output,
  gate,
  ko,
  expanded,
  onToggle,
  onChoose,
  canOpenUrl,
  hint,
  writing,
  onStopWrite,
}: SeatStepCardProps) {
  const { stepLine, resultLine } = seatCardLines(steps, output, ko)
  return (
    <article className="seat-step-card" data-expanded={expanded ? 'true' : 'false'}>
      <div className="seat-step-card-line">
        <div className="seat-step-card-copy">
          <span className="seat-step-card-step">{stepLine}</span>
          {resultLine ? <span className="seat-step-card-result">{resultLine}</span> : null}
        </div>
        {writing && onStopWrite ? (
          <button type="button" className="seat-step-card-stop" onClick={onStopWrite}>
            {ko ? '멈추기' : 'Stop'}
          </button>
        ) : null}
        <button
          type="button"
          className="seat-step-card-chevron"
          aria-expanded={expanded}
          aria-label={expanded ? (ko ? '10단계 접기' : 'Collapse 10 steps') : ko ? '10단계 펼치기' : 'Expand 10 steps'}
          onClick={onToggle}
        >
          ▾
        </button>
      </div>
      {expanded ? (
        <div className="seat-step-card-body">
          <ol className="seat-run-steps">
            {steps.map((row) => (
              <li key={row.n} data-status={row.status}>
                <span>
                  {row.n}. {row.name}
                </span>
                {row.detail ? <p>{row.detail}</p> : null}
              </li>
            ))}
          </ol>
          {gate && onChoose ? (
            <div className="seat-run-actions">
              {gate === 'web' ? (
                <button type="button" onClick={() => onChoose('open-url')} disabled={!canOpenUrl}>
                  {ko ? '주소만 열기' : 'Open URL only'}
                </button>
              ) : null}
              <button type="button" onClick={() => onChoose('draft')}>
                {ko ? '초안만 쓰기' : 'Draft only'}
              </button>
              <button type="button" onClick={() => onChoose('stop')}>
                {ko ? '멈추기' : 'Stop'}
              </button>
            </div>
          ) : writing && onStopWrite ? (
            <div className="seat-run-actions">
              <button type="button" onClick={onStopWrite}>
                {ko ? '멈추기' : 'Stop'}
              </button>
            </div>
          ) : null}
          {hint ? <p className="seat-run-file">{hint}</p> : null}
        </div>
      ) : null}
    </article>
  )
}
