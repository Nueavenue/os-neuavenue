import type { AssignedTool } from '../engine/browseLedger'

type BrowseToolsPanelProps = {
  tools: AssignedTool[]
  ko: boolean
  signedIn: boolean
  onRun: (tool: AssignedTool) => void
}

export function BrowseToolsPanel({ tools, ko, signedIn, onRun }: BrowseToolsPanelProps) {
  return (
    <div className="browser-panel">
      <div className="browser-panel-head">
        <b>{ko ? '배정된 도구' : 'Assigned tools'}</b>
      </div>
      <p className="dock-hint">
        {signedIn
          ? ko
            ? '이 로그인으로 쌓인 방문·다운로드·기능 사용을 보고 도구를 붙입니다.'
            : 'Tools are assigned from this login’s visits, downloads, and feature use.'
          : ko
            ? '로그인하면 이 계정 기준으로 도구가 쌓입니다.'
            : 'Sign in to keep tool history on this account.'}
      </p>
      <div className="browser-tools">
        {tools.map((tool) => (
          <button key={tool.id} type="button" className="browser-tool" onClick={() => onRun(tool)}>
            <strong>{tool.label}</strong>
            <span>{tool.reason}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
