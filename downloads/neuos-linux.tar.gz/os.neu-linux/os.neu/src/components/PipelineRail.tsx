import type { Pipeline } from '../types'

export function PipelineRail({ pipeline }: { pipeline: Pipeline }) {
  return (
    <aside className="panel">
      <h3>Brain · run plan</h3>
      <div className="steps">
        {pipeline.steps.map((step, i) => (
          <div key={step.id} className={`step ${step.status}`}>
            <b>
              {i + 1}. {step.title}
            </b>
            <small>{step.healNote ?? step.detail}</small>
          </div>
        ))}
      </div>
    </aside>
  )
}
