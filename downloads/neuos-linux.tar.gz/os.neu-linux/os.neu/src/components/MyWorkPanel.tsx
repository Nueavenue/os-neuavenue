import { useCallback, useEffect, useMemo, useState } from 'react'
import { cloudSyncLine } from '../engine/cloudWorkspace'
import { formatWorkTime } from '../engine/mvpWork'
import { onOpenMyWork, publishShellOverlay } from '../engine/settingsBus'
import {
  dayLabel,
  filterActivity,
  groupByDay,
  listActivity,
  listArtifacts,
  listEvidence,
  listWorks,
  onWorkspaceChange,
  summarizeWork,
  visibleActivity,
  type ActivityKind,
  type FeedFilter,
  type WsActivity,
  type WsArtifact,
  type WsEvidence,
  type WsWork,
} from '../engine/workspaceDb'
import { aiRequestTitle, linkActivity, requestOpenArtifact, toWsWork } from '../engine/workspaceLog'
import { useI18n } from '../i18n/LocaleContext'
import { useMvpWork } from '../state/mvpWorkContext'
import { useNeu } from '../state/neuContext'

type Data = { works: WsWork[]; activity: WsActivity[]; artifacts: WsArtifact[]; evidence: WsEvidence[] }

const EMPTY: Data = { works: [], activity: [], artifacts: [], evidence: [] }
const FEED_LIMIT = 300

const KIND_KO: Record<ActivityKind, string> = {
  'work.start': '작업 시작',
  'work.save': '작업 저장',
  'work.link': '작업에 묶음',
  'work.delete': '휴지통으로',
  'work.restore': '되살림',
  'source.add': '자료 추가',
  'web.visit': '웹',
  'web.download': '다운로드',
  'doc.save': '문서 저장',
  'sheet.save': '시트 저장',
  'slides.save': '슬라이드 저장',
  'slides.export': 'PPTX 내보내기',
  'ai.call': 'AI',
}

const KIND_EN: Record<ActivityKind, string> = {
  'work.start': 'Work started',
  'work.save': 'Work saved',
  'work.link': 'Linked',
  'work.delete': 'Moved to trash',
  'work.restore': 'Restored',
  'source.add': 'Source added',
  'web.visit': 'Web',
  'web.download': 'Download',
  'doc.save': 'Doc saved',
  'sheet.save': 'Sheet saved',
  'slides.save': 'Slides saved',
  'slides.export': 'PPTX export',
  'ai.call': 'AI',
}

const FILTERS: { id: FeedFilter; ko: string; en: string }[] = [
  { id: 'all', ko: '전체', en: 'All' },
  { id: 'web', ko: '웹', en: 'Web' },
  { id: 'doc', ko: '문서', en: 'Docs' },
  { id: 'sheet', ko: '시트', en: 'Sheets' },
  { id: 'slides', ko: '슬라이드', en: 'Slides' },
  { id: 'ai', ko: 'AI', en: 'AI' },
]

function clock(t: number) {
  const d = new Date(t)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function rowText(row: WsActivity) {
  if (row.kind !== 'ai.call') return row.title || row.url || ''
  const model = row.model ? ` · ${row.model}` : ''
  return `${aiRequestTitle(row.title || '')}${model}`
}

export function MyWorkPanel() {
  const neu = useNeu()
  const mvp = useMvpWork()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<'works' | 'feed'>('works')
  const [data, setData] = useState<Data>(EMPTY)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [filter, setFilter] = useState<FeedFilter>('all')

  useEffect(
    () =>
      onOpenMyWork(() => {
        setOpen(true)
        setTab('works')
      }),
    [],
  )

  useEffect(() => {
    publishShellOverlay('my-work', open)
    if (open) return () => publishShellOverlay('my-work', false)
  }, [open])

  const reload = useCallback(async () => {
    try {
      const [works, activity, artifacts, evidence] = await Promise.all([listWorks(), listActivity(), listArtifacts(), listEvidence()])
      setData({ works, activity: visibleActivity(activity), artifacts, evidence })
    } catch {
      setData(EMPTY)
    }
  }, [])

  useEffect(() => {
    if (!open) return
    void reload()
    return onWorkspaceChange(() => void reload())
  }, [open, reload])

  const allWorks = useMemo(() => {
    const local = [...mvp.works, ...mvp.trashed].map(toWsWork)
    const seen = new Set(local.map((row) => row.id))
    return [...local, ...data.works.filter((row) => !seen.has(row.id))].sort((a, b) => b.updatedAt - a.updatedAt)
  }, [data.works, mvp.works, mvp.trashed])
  const works = useMemo(() => allWorks.filter((row) => !row.deletedAt), [allWorks])
  const trash = useMemo(() => allWorks.filter((row) => row.deletedAt), [allWorks])
  const [trashOpen, setTrashOpen] = useState(false)

  const workTitle = useMemo(() => new Map(allWorks.map((row) => [row.id, row.title])), [allWorks])

  if (!open) return null

  const close = () => setOpen(false)
  const kindLabel = (kind: ActivityKind) => (ko ? KIND_KO[kind] : KIND_EN[kind])

  const continueWork = (id: string) => {
    mvp.openWork(id)
    neu.openOffice('doc')
    close()
  }

  const openArtifactLane = (work: WsWork, lane: 'progress' | 'latest' | 'done') => {
    mvp.openWork(work.id)
    const owned = data.artifacts.filter((row) => row.workId === work.id).sort((a, b) => b.updatedAt - a.updatedAt)
    if (lane === 'progress') {
      neu.openOffice('doc')
      close()
      return
    }
    const pick = lane === 'latest' ? owned[0] : owned.find((row) => row.app === 'doc') || owned[0]
    if (pick) {
      requestOpenArtifact(pick.id, pick.app)
      neu.openOffice(pick.app)
    } else {
      neu.openOffice('doc')
    }
    close()
  }

  const openActivity = (row: WsActivity) => {
    if (row.refId && (row.app === 'doc' || row.app === 'sheet' || row.app === 'slides')) {
      if (row.workId) mvp.openWork(row.workId)
      requestOpenArtifact(row.refId, row.app)
      neu.openOffice(row.app)
      close()
      return
    }
    if (row.workId) {
      continueWork(row.workId)
      return
    }
    if (row.url) {
      neu.openWeb(row.url)
      close()
    }
  }

  const openArtifact = (row: WsArtifact) => {
    if (row.app === 'doc') {
      if (row.workId) continueWork(row.workId)
      return
    }
    if (row.workId) mvp.openWork(row.workId)
    requestOpenArtifact(row.id, row.app)
    neu.openOffice(row.app)
    close()
  }

  const appLabel = (app: WsArtifact['app']) =>
    app === 'doc' ? (ko ? '문서' : 'Doc') : app === 'sheet' ? (ko ? '시트' : 'Sheet') : ko ? '슬라이드' : 'Slides'

  const feedRows = filterActivity(data.activity, filter).slice(0, FEED_LIMIT)

  return (
    <div className="mvp-modal-scrim settings-scrim" role="presentation" onClick={close}>
      <div
        className="mvp-modal mywork-panel"
        role="dialog"
        aria-modal
        aria-label={ko ? '내 작업' : 'My work'}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="mvp-modal-head">
          <h2>{ko ? '내 작업' : 'My work'}</h2>
          <small className="mywork-sync" role="status">
            {cloudSyncLine(ko)}
          </small>
          <button type="button" className="icon-btn" onClick={close} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </header>
        <div className="mywork-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={tab === 'works'} className={tab === 'works' ? 'on' : ''} onClick={() => setTab('works')}>
            {ko ? '작업' : 'Works'}
          </button>
          <button type="button" role="tab" aria-selected={tab === 'feed'} className={tab === 'feed' ? 'on' : ''} onClick={() => setTab('feed')}>
            {ko ? '전체 기록' : 'All activity'}
          </button>
        </div>

        {tab === 'works' ? (
          <div className="mywork-body">
            {works.length ? (
              <ul className="mywork-cards">
                {works.map((work) => {
                  const counts = summarizeWork(work, data.activity, data.artifacts, data.evidence)
                  const isOpen = expanded === work.id
                  const timeline = isOpen ? data.activity.filter((row) => row.workId === work.id).slice().reverse() : []
                  const outputs = isOpen ? data.artifacts.filter((row) => row.workId === work.id) : []
                  return (
                    <li key={work.id} className={`mywork-card${isOpen ? ' open' : ''}`}>
                      <button type="button" className="mywork-card-head" aria-expanded={isOpen} onClick={() => setExpanded(isOpen ? null : work.id)}>
                        <span className="mywork-card-title">{work.title}</span>
                        <small>{formatWorkTime(work, ko)}</small>
                        <span className="mywork-counts">
                          {ko
                            ? `문서 ${counts.doc} · 시트 ${counts.sheet} · 슬라이드 ${counts.slides} · 자료 ${counts.sources} · 웹 ${counts.web} · AI ${counts.ai}`
                            : `Docs ${counts.doc} · Sheets ${counts.sheet} · Slides ${counts.slides} · Sources ${counts.sources} · Web ${counts.web} · AI ${counts.ai}`}
                        </span>
                      </button>
                      {isOpen ? (
                        <div className="mywork-detail">
                          <div className="mywork-lanes">
                            <button type="button" onClick={() => openArtifactLane(work, 'progress')}>
                              {ko ? '진행 중' : 'In progress'}
                            </button>
                            <button type="button" onClick={() => openArtifactLane(work, 'latest')}>
                              {ko ? '최근' : 'Latest'}
                            </button>
                            <button type="button" onClick={() => openArtifactLane(work, 'done')}>
                              {ko ? '완료' : 'Done'}
                            </button>
                          </div>
                          <div className="mywork-actions">
                            <button type="button" className="primary" onClick={() => continueWork(work.id)}>
                              {ko ? '이어하기' : 'Continue'}
                            </button>
                            <button
                              type="button"
                              className="mywork-trash-btn"
                              onClick={() => {
                                mvp.trashWork(work.id)
                                setExpanded(null)
                              }}
                              title={ko ? '휴지통으로 옮깁니다. 아래 [지운 작업]에서 되살릴 수 있어요.' : 'Moves to trash. Restore it from Deleted works below.'}
                            >
                              {ko ? '삭제' : 'Delete'}
                            </button>
                          </div>
                          {outputs.length ? (
                            <>
                              <p className="mywork-sub">{ko ? '결과물' : 'Outputs'}</p>
                              <ul className="mywork-outputs">
                                {outputs.map((row) => (
                                  <li key={row.id}>
                                    <button type="button" onClick={() => openArtifact(row)}>
                                      <span className="mywork-tag">{appLabel(row.app)}</span>
                                      {row.title}
                                      <small>
                                        v{row.version} · {clock(row.updatedAt)}
                                      </small>
                                    </button>
                                  </li>
                                ))}
                              </ul>
                            </>
                          ) : null}
                          <p className="mywork-sub">{ko ? '타임라인' : 'Timeline'}</p>
                          {timeline.length ? (
                            <ol className="mywork-timeline">
                              {timeline.map((row) => (
                                <li key={row.id}>
                                  <time>{clock(row.t)}</time>
                                  <span className="mywork-tag">{kindLabel(row.kind)}</span>
                                  <span className="mywork-text">{rowText(row)}</span>
                                </li>
                              ))}
                            </ol>
                          ) : (
                            <p className="mywork-empty">{ko ? '아직 기록이 없습니다.' : 'No activity yet.'}</p>
                          )}
                        </div>
                      ) : null}
                    </li>
                  )
                })}
              </ul>
            ) : (
              <p className="mywork-empty">{ko ? '아직 작업이 없습니다. 새 작업에서 시작해 주세요.' : 'No work yet. Start from New work.'}</p>
            )}
            {trash.length ? (
              <section className="mywork-trash">
                <button type="button" className="mywork-trash-head" aria-expanded={trashOpen} onClick={() => setTrashOpen(!trashOpen)}>
                  {trashOpen ? '▾' : '▸'} {ko ? `지운 작업 (${trash.length})` : `Deleted works (${trash.length})`}
                </button>
                {trashOpen ? (
                  <ul className="mywork-trash-list">
                    {trash.map((work) => (
                      <li key={work.id}>
                        <span className="mywork-card-title">{work.title}</span>
                        <small>
                          {ko ? '지움' : 'Deleted'} {work.deletedAt ? `${new Date(work.deletedAt).toLocaleDateString()} ${clock(work.deletedAt)}` : ''}
                        </small>
                        <button type="button" onClick={() => mvp.restoreWork(work.id)}>
                          {ko ? '되살리기' : 'Restore'}
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </section>
            ) : null}
          </div>
        ) : (
          <div className="mywork-body">
            <div className="mywork-filters" role="group" aria-label={ko ? '기록 종류' : 'Activity type'}>
              {FILTERS.map((row) => (
                <button key={row.id} type="button" className={filter === row.id ? 'on' : ''} aria-pressed={filter === row.id} onClick={() => setFilter(row.id)}>
                  {ko ? row.ko : row.en}
                </button>
              ))}
            </div>
            {feedRows.length ? (
              groupByDay(feedRows).map((group) => (
                <section key={group.key} className="mywork-day">
                  <h3>{dayLabel(group.key, ko)}</h3>
                  <ul className="mywork-feed">
                    {group.items.map((row) => (
                      <li key={row.id}>
                        <button type="button" className="mywork-feed-open" onClick={() => openActivity(row)}>
                          <time>{clock(row.t)}</time>
                          <span className="mywork-tag">{kindLabel(row.kind)}</span>
                          <span className="mywork-text">{rowText(row)}</span>
                        </button>
                        {row.workId ? (
                          <span className="mywork-owner">{workTitle.get(row.workId) || (ko ? '지난 작업' : 'Past work')}</span>
                        ) : (
                          <select
                            className="mywork-link"
                            value=""
                            aria-label={ko ? '작업에 묶기' : 'Link to work'}
                            onChange={(e) => {
                              if (e.target.value) linkActivity(row.id, e.target.value)
                            }}
                            disabled={!works.length}
                          >
                            <option value="">{ko ? '(작업 없음) 작업에 묶기…' : '(no work) Link to work…'}</option>
                            {works.map((work) => (
                              <option key={work.id} value={work.id}>
                                {work.title}
                              </option>
                            ))}
                          </select>
                        )}
                      </li>
                    ))}
                  </ul>
                </section>
              ))
            ) : (
              <p className="mywork-empty">{ko ? '이 종류의 기록이 없습니다.' : 'No activity of this type.'}</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
