import { useEffect, useState } from 'react'
import { AuthBar } from './AuthBar'
import { BrandMark } from './BrandMark'
import { LangPicker } from './LangPicker'
import { DownloadGlyph, ManualGlyph, WindowGlyph } from './PathGlyphs'
import { PathRail } from './PathRail'
import { useI18n } from '../i18n/LocaleContext'
import { isHomePhase } from '../engine/chromeX'
import { useNeu } from '../state/store'

function useClock(locale: string) {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000)
    return () => window.clearInterval(id)
  }, [])
  return now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })
}

function useFullscreen() {
  const [full, setFull] = useState(() => Boolean(document.fullscreenElement))
  useEffect(() => {
    const sync = () => setFull(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', sync)
    return () => document.removeEventListener('fullscreenchange', sync)
  }, [])
  return full
}

export function StatusBar() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const time = useClock(locale)
  const full = useFullscreen()
  const ko = locale === 'ko'
  const electron = Boolean(typeof window !== 'undefined' && window.neuos?.quit)
  const netClass = !neu.network.probed ? '' : neu.network.online ? 'ok' : 'off'
  const health = neu.hardware ? (neu.hardware.healthy ? 'ok' : 'warn') : ''
  const xLabel = isHomePhase(neu.phase)
    ? ko
      ? '종료'
      : 'Quit'
    : full
      ? ko
        ? '화면 축소'
        : 'Shrink screen'
      : ko
        ? '이전 화면'
        : 'Back'

  return (
    <header className="status-bar">
      <div className="status-left">
        <AuthBar />
        <BrandMark onClick={neu.phase === 'install' ? undefined : neu.goHome} />
      </div>
      <div className="status-pills">
        <span className={`pill ${netClass}`}>{neu.network.probed ? neu.network.label : copy.wait}</span>
        {neu.hardware ? (
          <span className={`pill ${health}`}>
            {neu.hardware.healthy ? copy.deviceOk : copy.deviceWarn}
          </span>
        ) : null}
        {neu.bridge && neu.bridge.driver !== 'dry-run' ? (
          <span className={`pill ${neu.bridge.live ? 'ok' : ''}`}>
            {neu.bridge.driver}
            {neu.bridge.live ? ` ${copy.liveClick}` : ''}
          </span>
        ) : null}
        <PathRail />
        <button
          type="button"
          className="path-icon"
          onClick={neu.openDownload}
          aria-label={ko ? '다운로드' : 'Download'}
          title={ko ? 'Linux 스크린 받기' : 'Get Linux screen'}
        >
          <DownloadGlyph />
        </button>
        <button
          type="button"
          className="path-icon"
          onClick={neu.openManual}
          aria-label={ko ? '매뉴얼' : 'Manual'}
          title={ko ? '매뉴얼' : 'Manual'}
        >
          <ManualGlyph />
        </button>
        {electron ? (
          <button
            type="button"
            className="path-icon"
            onClick={() => {
              void window.neuos?.windowMode?.().then((state) => {
                if (state?.maximized || state?.fullscreen) void window.neuos?.setWindowMode?.('windowed')
                else void window.neuos?.setWindowMode?.('maximized')
              })
            }}
            aria-label={ko ? '화면 크기' : 'Window size'}
            title={ko ? '창 크기 조절' : 'Resize window'}
          >
            <WindowGlyph />
          </button>
        ) : null}
        <LangPicker />
        <button
          type="button"
          className="pill exit-btn exit-x"
          onClick={neu.chromeX}
          aria-label={xLabel}
          title={xLabel}
        >
          ×
        </button>
        <span className="pill">{time}</span>
      </div>
    </header>
  )
}
