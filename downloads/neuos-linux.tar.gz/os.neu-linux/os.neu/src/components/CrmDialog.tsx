import {
  CRM_CAMPAIGNS,
  CRM_CHANNELS,
  CRM_FEEDBACK,
  CRM_KPIS,
  CRM_PROMOS,
  CRM_SECTIONS,
  CRM_SEGMENTS,
  CRM_TEAM,
  pipelineStages,
  type CrmSectionId,
} from '../engine/crm'
import { useI18n } from '../i18n/LocaleContext'
import { useEffect, useState } from 'react'

type CrmTool = 'none' | 'search' | 'alerts' | 'settings' | 'help'

function CrmMark() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="16.5" cy="9.5" r="2.4" stroke="currentColor" strokeWidth="1.7" />
      <path d="M4.5 19c.4-3 2.6-4.6 4.5-4.6 1.2 0 2.3.4 3.2 1.2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      <path d="M14 19c.3-2.2 1.8-3.4 3.3-3.4 1.4 0 2.5.8 3 2.2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function IconSearch() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="11" cy="11" r="6.2" stroke="currentColor" strokeWidth="1.8" />
      <path d="M16 16.5 20 20.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}

function IconBell() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M6 16V11a6 6 0 1 1 12 0v5l1.4 2H4.6L6 16Z" stroke="currentColor" strokeWidth="1.7" />
      <path d="M10 19.5a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function IconGear() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.7" />
      <path
        d="M12 4.2v1.8M12 18v1.8M4.2 12h1.8M18 12h1.8M6.4 6.4l1.3 1.3M16.3 16.3l1.3 1.3M17.6 6.4l-1.3 1.3M7.7 16.3l-1.3 1.3"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
    </svg>
  )
}

function IconHelp() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.7" />
      <path d="M9.6 9.4a2.4 2.4 0 1 1 3.3 2.2c-.7.4-1.1.8-1.1 1.6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      <circle cx="12" cy="16.6" r="0.8" fill="currentColor" />
    </svg>
  )
}

function CrmBody({ section, ko }: { section: CrmSectionId; ko: boolean }) {
  if (section === 'promotion') {
    return (
      <>
        <p className="crm-lead">{ko ? '혜택과 기간을 잡고 캠페인으로 넘깁니다. 저장은 나중에 연결됩니다.' : 'Set the offer and dates, then pass it to a campaign. Save comes later.'}</p>
        <div className="crm-grid">
          {CRM_PROMOS.map((row) => (
            <article key={row.name} className="crm-tile">
              <b>{ko ? row.name : row.nameEn}</b>
              <span>{ko ? row.perk : row.perkEn}</span>
              <small>
                {row.until} · {row.state}
              </small>
            </article>
          ))}
        </div>
        <form className="crm-form" onSubmit={(e) => e.preventDefault()}>
          <label>
            {ko ? '프로모션 이름' : 'Promotion name'}
            <input placeholder={ko ? '가을 안내' : 'Autumn note'} />
          </label>
          <label>
            {ko ? '혜택' : 'Perk'}
            <input placeholder={ko ? '체험 연장' : 'Longer try'} />
          </label>
          <button type="submit" className="crm-primary">
            {ko ? '초안 만들기' : 'Make draft'}
          </button>
        </form>
      </>
    )
  }
  if (section === 'campaign') {
    return (
      <>
        <p className="crm-lead">{ko ? '프로모션을 일정과 상태에 묶어 캠페인으로 봅니다.' : 'Bind a promotion to dates and status.'}</p>
        <div className="crm-table">
          {CRM_CAMPAIGNS.map((row) => (
            <div key={row.name} className="crm-row">
              <b>{ko ? row.name : row.nameEn}</b>
              <span>{row.status}</span>
              <span>{row.reach}</span>
              <small>{row.until}</small>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (section === 'audience') {
    return (
      <>
        <p className="crm-lead">{ko ? '누가 이 캠페인을 받는지 세그먼트로 나눕니다.' : 'Split who receives the campaign.'}</p>
        <div className="crm-table">
          {CRM_SEGMENTS.map((row) => (
            <div key={row.name} className="crm-row">
              <b>{ko ? row.name : row.nameEn}</b>
              <span>{row.size}</span>
              <small>{ko ? row.note : row.noteEn}</small>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (section === 'marketing') {
    return (
      <>
        <p className="crm-lead">{ko ? '메시지를 실을 채널을 고릅니다.' : 'Pick the channels that carry the message.'}</p>
        <ul className="crm-checks">
          {CRM_CHANNELS.map((row) => (
            <li key={row.id}>
              <label>
                <input type="checkbox" defaultChecked={row.id !== 'web'} />
                {ko ? row.label : row.labelEn}
              </label>
            </li>
          ))}
        </ul>
      </>
    )
  }
  if (section === 'email') {
    return (
      <>
        <p className="crm-lead">{ko ? '배포 초안입니다. 보내기는 화면만입니다.' : 'A send draft. Delivery is screen-only for now.'}</p>
        <form className="crm-form crm-mail" onSubmit={(e) => e.preventDefault()}>
          <label>
            {ko ? '받는 사람' : 'To'}
            <input placeholder={ko ? '세그먼트: 이 기기 사용자' : 'Segment: this machine'} />
          </label>
          <label>
            {ko ? '제목' : 'Subject'}
            <input placeholder={ko ? 'OS.neu v1.0 캠페인' : 'OS.neu v1.0 campaign'} />
          </label>
          <label>
            {ko ? '본문' : 'Body'}
            <textarea rows={6} placeholder={ko ? '한 줄로 초대합니다.' : 'Invite in one line.'} />
          </label>
          <button type="submit" className="crm-primary">
            {ko ? '대기열에 넣기' : 'Queue send'}
          </button>
        </form>
      </>
    )
  }
  if (section === 'feedback') {
    return (
      <>
        <p className="crm-lead">{ko ? '캠페인 뒤 응답을 모읍니다.' : 'Collect replies after the campaign.'}</p>
        <div className="crm-table">
          {CRM_FEEDBACK.map((row) => (
            <div key={row.note} className="crm-row">
              <b>{ko ? row.who : row.whoEn}</b>
              <span>{row.score}/5</span>
              <small>{ko ? row.note : row.noteEn}</small>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (section === 'monitor') {
    return (
      <>
        <p className="crm-lead">{ko ? '파이프라인이 어디까지 왔는지 숫자로 봅니다. 실제 집계는 이후 연결됩니다.' : 'See how far the pipeline has come. Live totals come later.'}</p>
        <div className="crm-kpis">
          {CRM_KPIS.map((row) => (
            <article key={row.id} className="crm-tile">
              <small>{ko ? row.label : row.labelEn}</small>
              <b>{row.value}</b>
              <span>{row.hint}</span>
            </article>
          ))}
        </div>
      </>
    )
  }
  return (
    <>
      <p className="crm-lead">{ko ? '누가 캠페인을 고치고 누가 보기만 하는지 나눕니다.' : 'Who can edit campaigns, and who can only watch.'}</p>
      <div className="crm-table">
        {CRM_TEAM.map((row) => (
          <div key={row.name} className="crm-row">
            <b>{ko ? row.name : row.nameEn}</b>
            <span>{ko ? row.role : row.roleEn}</span>
          </div>
        ))}
      </div>
    </>
  )
}

function ToolBody({ tool, ko }: { tool: Exclude<CrmTool, 'none'>; ko: boolean }) {
  if (tool === 'search') {
    return (
      <>
        <p className="crm-lead">{ko ? '캠페인 · 세그먼트 · 메일을 찾습니다. 검색은 이 화면에만 있습니다.' : 'Find campaigns, segments, or mail. Search stays on this screen.'}</p>
        <form className="crm-form" onSubmit={(e) => e.preventDefault()}>
          <label>
            {ko ? '찾기' : 'Find'}
            <input placeholder={ko ? 'v1.0' : 'v1.0'} autoFocus />
          </label>
        </form>
      </>
    )
  }
  if (tool === 'alerts') {
    return (
      <>
        <p className="crm-lead">{ko ? '알림은 아직 비어 있습니다.' : 'No alerts yet.'}</p>
        <article className="crm-tile">
          <b>{ko ? '연동 대기' : 'Waiting to connect'}</b>
          <span>{ko ? 'Supabase가 붙으면 여기에 발송·응답이 뜹니다.' : 'Sends and replies will land here after Supabase is wired.'}</span>
        </article>
      </>
    )
  }
  if (tool === 'settings') {
    return (
      <>
        <p className="crm-lead">{ko ? 'neuCRM 화면 설정입니다. 계정 저장은 없습니다.' : 'neuCRM screen settings. No account save yet.'}</p>
        <ul className="crm-checks">
          <li>
            <label>
              <input type="checkbox" defaultChecked />
              {ko ? '파이프라인 풋터 보기' : 'Show pipeline footer'}
            </label>
          </li>
          <li>
            <label>
              <input type="checkbox" defaultChecked />
              {ko ? '한국어 우선' : 'Prefer Korean'}
            </label>
          </li>
        </ul>
      </>
    )
  }
  return (
    <>
      <p className="crm-lead">
        {ko
          ? '왼쪽은 캠페인 파이프라인입니다. 위 아이콘은 찾기·알림·설정입니다. ×는 OS.neu 콘솔로 돌아갑니다.'
          : 'The left list is the campaign pipeline. Top icons are find, alerts, and settings. × returns to the OS.neu console.'}
      </p>
    </>
  )
}

export function CrmDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [section, setSection] = useState<CrmSectionId>('promotion')
  const [tool, setTool] = useState<CrmTool>('none')

  useEffect(() => {
    if (!open) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  useEffect(() => {
    if (open) {
      setSection('promotion')
      setTool('none')
    }
  }, [open])

  if (!open) return null

  const current = CRM_SECTIONS.find((row) => row.id === section) ?? CRM_SECTIONS[0]
  const stages = pipelineStages(section)
  const title = tool === 'none' ? (ko ? current.label : current.labelEn) : tool === 'search' ? (ko ? '찾기' : 'Find') : tool === 'alerts' ? (ko ? '알림' : 'Alerts') : tool === 'settings' ? (ko ? '설정' : 'Settings') : ko ? '도움' : 'Help'

  return (
    <div className="crm-overlay" role="dialog" aria-modal="true" aria-labelledby="crm-title" onClick={onClose}>
      <div className="crm-dialog" onClick={(event) => event.stopPropagation()}>
        <header className="crm-top">
          <div className="crm-brand">
            <span className="crm-mark">
              <CrmMark />
            </span>
            <div>
              <h2 id="crm-title">neuCRM</h2>
              <small>{ko ? '캠페인을 이 화면에서 시작합니다. 저장은 이후 연결됩니다.' : 'Start a campaign on this screen. Save comes later.'}</small>
            </div>
          </div>
          <div className="crm-tools">
            <button type="button" className={tool === 'search' ? 'on' : ''} onClick={() => setTool('search')} aria-label={ko ? '찾기' : 'Search'} title={ko ? '찾기' : 'Search'}>
              <IconSearch />
            </button>
            <button type="button" className={tool === 'alerts' ? 'on' : ''} onClick={() => setTool('alerts')} aria-label={ko ? '알림' : 'Alerts'} title={ko ? '알림' : 'Alerts'}>
              <IconBell />
            </button>
            <button type="button" className={tool === 'settings' ? 'on' : ''} onClick={() => setTool('settings')} aria-label={ko ? '설정' : 'Settings'} title={ko ? '설정' : 'Settings'}>
              <IconGear />
            </button>
            <button type="button" className={tool === 'help' ? 'on' : ''} onClick={() => setTool('help')} aria-label={ko ? '도움' : 'Help'} title={ko ? '도움' : 'Help'}>
              <IconHelp />
            </button>
            <button type="button" className="exit-x" onClick={onClose} aria-label={ko ? 'OS.neu로 돌아가기' : 'Back to OS.neu'} title={ko ? 'OS.neu로 돌아가기' : 'Back to OS.neu'}>
              ×
            </button>
          </div>
        </header>
        <div className="crm-mid">
          <nav className="crm-nav" aria-label={ko ? '캠페인 파이프라인' : 'Campaign pipeline'}>
            {CRM_SECTIONS.map((row) => (
              <button
                key={row.id}
                type="button"
                className={row.id === section && tool === 'none' ? 'on' : ''}
                onClick={() => {
                  setSection(row.id)
                  setTool('none')
                }}
              >
                <b>{ko ? row.label : row.labelEn}</b>
                <span>{ko ? row.kicker : row.kickerEn}</span>
              </button>
            ))}
          </nav>
          <main className="crm-body">
            <h3>{title}</h3>
            {tool === 'none' ? <CrmBody section={section} ko={ko} /> : <ToolBody tool={tool} ko={ko} />}
          </main>
        </div>
        <footer className="crm-foot">
          <p>{ko ? '파이프라인 진행' : 'Pipeline'}</p>
          <ol>
            {stages.map((row) => {
              const meta = CRM_SECTIONS.find((item) => item.id === row.id)
              return (
                <li key={row.id}>
                  <button
                    type="button"
                    className={`crm-step ${row.stage}`}
                    onClick={() => {
                      setSection(row.id)
                      setTool('none')
                    }}
                  >
                    <i />
                    <span>{ko ? meta?.label : meta?.labelEn}</span>
                  </button>
                </li>
              )
            })}
          </ol>
        </footer>
      </div>
    </div>
  )
}

export function CrmGlyph() {
  return <CrmMark />
}
