import { useEffect, useState } from 'react'
import { useI18n } from '../i18n/LocaleContext'

export type TalkLeaf = {
  id: string
  name: string
}

export type TalkProject = {
  id: string
  name: string
  open: boolean
  leaves: TalkLeaf[]
}

const STORAGE_KEY = 'os.neu.talk-projects'

function loadProjects(): TalkProject[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as TalkProject[]
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function saveProjects(next: TalkProject[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
}

function sid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

export function TalkProjects() {
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const [projects, setProjects] = useState<TalkProject[]>([])
  const [active, setActive] = useState<string | null>(null)
  const [adding, setAdding] = useState(false)
  const [draft, setDraft] = useState('')

  useEffect(() => {
    setProjects(loadProjects())
  }, [])

  const commit = (next: TalkProject[]) => {
    setProjects(next)
    saveProjects(next)
  }

  const addProject = () => {
    const name = draft.trim()
    if (!name) return
    const id = sid('p')
    commit([
      ...projects,
      {
        id,
        name,
        open: true,
        leaves: [
          { id: sid('d'), name: copy.doc },
          { id: sid('s'), name: copy.sheet },
          { id: sid('t'), name: ko ? '대화' : 'Talk' },
        ],
      },
    ])
    setActive(id)
    setDraft('')
    setAdding(false)
  }

  return (
    <aside className="talk-projects" aria-label={ko ? '프로젝트' : 'Projects'}>
      <div className="talk-projects-bar">
        <b>{ko ? '프로젝트' : 'Projects'}</b>
        <button
          type="button"
          className="talk-add"
          onClick={() => setAdding((open) => !open)}
        >
          {ko ? '추가하기' : 'Add'}
        </button>
      </div>
      {adding ? (
        <form
          className="talk-add-form"
          onSubmit={(e) => {
            e.preventDefault()
            addProject()
          }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={ko ? '프로젝트 이름' : 'Project name'}
            aria-label={ko ? '프로젝트 이름' : 'Project name'}
            autoFocus
          />
          <button type="submit">{ko ? '만들기' : 'Create'}</button>
        </form>
      ) : null}
      {projects.length ? (
        <ul className="talk-tree">
          {projects.map((project) => (
            <li key={project.id} className={active === project.id ? 'on' : ''}>
              <div className="talk-tree-folder">
                <button
                  type="button"
                  className="talk-tree-mark"
                  aria-label={project.open ? (ko ? '접기' : 'Collapse') : ko ? '펼치기' : 'Expand'}
                  onClick={() =>
                    commit(
                      projects.map((row) =>
                        row.id === project.id ? { ...row, open: !row.open } : row,
                      ),
                    )
                  }
                >
                  {project.open ? '▾' : '▸'}
                </button>
                <button type="button" className="talk-tree-name" onClick={() => setActive(project.id)}>
                  {project.name}
                </button>
              </div>
              {project.open ? (
                <ul className="talk-tree-kids">
                  {project.leaves.map((leaf) => (
                    <li key={leaf.id}>
                      <button
                        type="button"
                        className={active === leaf.id ? 'on' : ''}
                        onClick={() => setActive(leaf.id)}
                      >
                        <span className="talk-tree-mark" aria-hidden>
                          ·
                        </span>
                        {leaf.name}
                      </button>
                    </li>
                  ))}
                </ul>
              ) : null}
            </li>
          ))}
        </ul>
      ) : (
        <p className="talk-projects-empty">
          {ko ? '아직 프로젝트가 없습니다. 추가하기로 폴더를 만드세요.' : 'No projects yet. Tap Add to make a folder.'}
        </p>
      )}
    </aside>
  )
}
