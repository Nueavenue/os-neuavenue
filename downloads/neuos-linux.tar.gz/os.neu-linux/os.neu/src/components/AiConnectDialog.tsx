import { useEffect, useState } from 'react'
import { LOCAL_LLM_CATALOG, localCard } from '../engine/llmCatalog'
import { ALL_CLOUD_VENDORS, cloudCard } from '../engine/cloudModels'
import { cloudAiKeyStatus, cloudConfig, saveAiKeyToCloud, type CloudKeyStatus } from '../engine/cloudWorkspace'
import { OFFICE_MODELS } from '../engine/office'
import { fetchLlmSettings, pingLlm, saveLlmSettings, type LlmSettingsView } from '../engine/llmConnect'
import { seatErrorKo } from '../engine/seatClient'
import { publishShellOverlay } from '../engine/settingsBus'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

type Props = {
  open: boolean
  onClose: () => void
  /** Prefill / focus a cloud model when opened because Ask AI needs a key. */
  preferModel?: string
}

export function AiConnectDialog({ open, onClose, preferModel }: Props) {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [view, setView] = useState<LlmSettingsView | null>(null)
  const [key, setKey] = useState('')
  const [vendorKey, setVendorKey] = useState('')
  const [provider, setProvider] = useState<'auto' | 'local' | 'openai'>('auto')
  const [model, setModel] = useState(preferModel || neu.officeModel)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')
  const [vault, setVault] = useState<CloudKeyStatus[] | null>(null)
  const cloudOn = Boolean(cloudConfig())

  useEffect(() => {
    publishShellOverlay('ai-connect', open)
    if (open) return () => publishShellOverlay('ai-connect', false)
  }, [open])

  useEffect(() => {
    if (!open) return
    setMsg('')
    if (cloudOn) void cloudAiKeyStatus().then(setVault)
    setModel(preferModel || neu.officeModel)
    void fetchLlmSettings().then((row) => {
      setView(row)
      if (row.provider === 'local' || row.provider === 'openai' || row.provider === 'auto') {
        setProvider(row.provider)
      }
    })
  }, [open, preferModel, neu.officeModel])

  if (!open) return null

  const localOk = Boolean(view?.ready?.ok && view.ready.via === 'local')
  const hasKey = Boolean(view?.hasKey)
  const bridgeDown = Boolean(view && !view.ok && view.reason === 'network')
  const vendorKeyOn = (vendorId: string) =>
    vendorId === 'openai'
      ? hasKey || Boolean(view?.vendorHas?.openai)
      : Boolean(view?.vendorHas?.[vendorId])

    const save = async () => {
    setBusy(true)
    setMsg(ko ? '저장 중…' : 'Saving…')
    const picked = cloudCard(model)
    const result = await saveLlmSettings({
      provider,
      openaiKey: key.trim() || undefined,
      vendorKeys: picked && picked.vendorId !== 'openai' && vendorKey.trim() ? { [picked.vendorId]: vendorKey.trim() } : undefined,
    })
    setBusy(false)
    if (!result.ok) {
      setMsg(result.reason || (ko ? '저장 실패' : 'Save failed'))
      return
    }
    neu.setOfficeModel(model)
    setMsg(ko ? '연결 설정을 저장했습니다.' : 'Connection settings saved.')
    const refreshed = await fetchLlmSettings()
    setView(refreshed)
    setKey('')
    setVendorKey('')
  }

  const saveToVault = async () => {
    const picked = cloudCard(model)
    const vendor = picked && picked.vendorId !== 'openai' ? picked.vendorId : 'openai'
    const text = vendor === 'openai' ? key : vendorKey
    if (!text.trim()) {
      setMsg(ko ? '클라우드 금고에 넣을 키를 먼저 입력하세요.' : 'Paste the key first, then save it to the cloud vault.')
      return
    }
    setBusy(true)
    const ok = await saveAiKeyToCloud(vendor, text)
    setBusy(false)
    setMsg(
      ok
        ? ko
          ? '클라우드 금고에 저장했습니다. 로그인한 모든 화면에서 씁니다.'
          : 'Saved to your cloud vault. Every screen you sign in on can use it.'
        : ko
          ? '클라우드 금고에 저장하지 못했습니다. 로그인과 네트워크를 확인하세요.'
          : 'Could not save to the cloud vault. Check sign-in and network.',
    )
    if (ok) {
      setKey('')
      setVendorKey('')
      setVault(await cloudAiKeyStatus())
    }
  }

  const clearKey = async () => {
    setBusy(true)
    const result = await saveLlmSettings({ clearKey: true, provider })
    setBusy(false)
    setKey('')
    setMsg(result.ok ? (ko ? '키를 삭제했습니다.' : 'Key removed.') : result.reason || 'failed')
    setView(await fetchLlmSettings())
  }

  const test = async () => {
    setBusy(true)
    setMsg(ko ? '테스트 중… (로컬은 최대 1분)' : 'Testing… (local may take up to 1 min)')
    const picked = cloudCard(model)
    await saveLlmSettings({
      provider,
      openaiKey: key.trim() || undefined,
      vendorKeys: picked && picked.vendorId !== 'openai' && vendorKey.trim() ? { [picked.vendorId]: vendorKey.trim() } : undefined,
    })
    neu.setOfficeModel(model)
    const result = await pingLlm(model)
    setBusy(false)
    if (!result.ok) {
      setMsg(
        result.reason === 'no-llm'
          ? ko
            ? 'OpenAI 키가 없거나 로컬 AI가 꺼져 있습니다.'
            : 'No OpenAI key, or local AI is offline.'
          : seatErrorKo(result.reason || 'AI failed', ko),
      )
      return
    }
    setMsg(
      ko
        ? `연결됨 · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`
        : `Connected · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`,
    )
    const refreshed = await fetchLlmSettings()
    setView(refreshed)
  }

  return (
    <div className="ai-connect-overlay" role="presentation" onClick={onClose}>
      <div
        className="ai-connect-dialog"
        role="dialog"
        aria-modal
        aria-label={ko ? 'AI 모델 연결' : 'Connect AI model'}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="ai-connect-head">
          <h2>{ko ? 'AI 모델 연결' : 'Connect AI model'}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </header>

        <p className="ai-connect-lead">
          {ko
            ? '2026-10 기준 LLM 업체 10곳 플래그십과 웹 검색형 AI(Perplexity)를 목록에 넣었습니다. 각 업체의 키(BYOK)가 있어야 그 모델이 살아납니다. 키 없는 항목은 연결되지 않습니다. 화면에 보일 모델은 설정 › AI 및 사용량에서 고릅니다.'
            : 'October 2026 top-10 vendor flagships plus a web-search AI (Perplexity) are listed. Each needs that vendor’s key (BYOK). A row without a key stays disconnected. Choose which models appear on screen in Settings › AI & Usage.'}
        </p>
        <ol className="ai-connect-vendors">
          {ALL_CLOUD_VENDORS.map((row) => (
            <li key={row.id}>
              <button type="button" className={model === row.id ? 'on' : ''} onClick={() => setModel(row.id)}>
                {row.label}
              </button>
              <small>
                {bridgeDown
                  ? ko
                    ? '확인 불가'
                    : 'unknown'
                  : vendorKeyOn(row.vendorId)
                    ? ko
                      ? '키 있음'
                      : 'key on'
                    : ko
                      ? '키 없음'
                      : 'no key'}
              </small>
            </li>
          ))}
        </ol>

        <div className="ai-connect-status">
          {bridgeDown ? (
            <div className="ai-pill" role="status">
              {ko
                ? '브리지가 꺼져 있어 키 상태를 볼 수 없습니다. 저장된 키는 지워지지 않았습니다. OS.neu를 다시 시작하세요.'
                : 'The bridge is not running, so key status cannot be read. Saved keys are not lost. Restart OS.neu.'}
            </div>
          ) : null}
          <div className={`ai-pill${localOk ? ' ok' : ''}`}>
            {localOk
              ? ko
                ? '로컬 AI 준비됨 (느릴 수 있음)'
                : 'Local AI ready (may be slow)'
              : ko
                ? '로컬 AI 없음 / 꺼짐'
                : 'Local AI offline'}
          </div>
          <div className={`ai-pill${hasKey ? ' ok' : ''}`}>
            {hasKey
              ? ko
                ? 'OpenAI 키 저장됨'
                : 'OpenAI key saved'
              : bridgeDown
                ? ko
                  ? 'OpenAI 키 상태 확인 불가'
                  : 'OpenAI key status unknown'
                : ko
                  ? 'OpenAI 키 없음'
                  : 'No OpenAI key'}
          </div>
          {cloudOn ? (
            <div className={`ai-pill${vault?.length ? ' ok' : ''}`}>
              {vault === null
                ? ko
                  ? '클라우드 금고: 로그인하면 보입니다'
                  : 'Cloud vault: sign in to see it'
                : vault.length
                  ? `${ko ? '클라우드 금고 키' : 'Cloud vault keys'}: ${vault.map((row) => row.vendor).join(', ')}`
                  : ko
                    ? '클라우드 금고: 키 없음'
                    : 'Cloud vault: no key'}
            </div>
          ) : null}
        </div>

        <label className="ai-connect-label">
          {ko ? '사용할 모델' : 'Model to use'}
          <select value={model} onChange={(e) => setModel(e.target.value)} disabled={busy}>
            {OFFICE_MODELS.map((row) => (
              <option key={row.id} value={row.id}>
                {row.label}
              </option>
            ))}
            {LOCAL_LLM_CATALOG.filter((row) => row.id !== 'llama3.2:1b').map((row) => (
              <option key={row.id} value={row.id}>
                {row.label}
                {view?.installed?.includes(row.id) ? '' : ko ? ' · 이 PC에 없음' : ' · not on this PC'}
              </option>
            ))}
          </select>
        </label>

        <div className="ai-connect-hint">
          <strong>{ko ? '로컬 모델 한계' : 'Local model limits'}</strong>
          <details className="ai-limit">
            <summary>{ko ? '로컬 모델이 못 하는 것' : 'What local models cannot do'}</summary>
            <p>
              {ko
                ? '아래 모델은 인터넷을 검색하지 않습니다. 학습 시점 이후의 사실은 모릅니다. 틀린 문장을 사실처럼 쓸 수 있습니다. 의료·법률·투자 결정에 쓰지 마세요. 로컬을 고르면 문장은 이 PC 안에 남습니다. OpenAI를 고르면 그 문장은 OpenAI로 갑니다. 기업 기밀은 로컬만 쓰세요.'
                : 'These models do not browse. They do not know facts after training. They can state falsehoods. Do not use them for medical, legal, or investment decisions. Local keeps the sentence on this PC. OpenAI sends it to OpenAI.'}
            </p>
          </details>
          {LOCAL_LLM_CATALOG.map((row) => {
            const on = row.id === 'llama3.2:1b' ? view?.installed?.some((name) => name.startsWith('llama3.2')) : view?.installed?.includes(row.id)
            return (
              <details key={row.id} className="ai-limit">
                <summary>
                  {row.label}
                  {on ? (ko ? ' · 설치됨' : ' · installed') : ko ? ' · 이 PC에 없음' : ' · not installed'}
                </summary>
                <p>{ko ? row.limitsKo : row.limitsEn}</p>
              </details>
            )
          })}
          <details className="ai-limit">
            <summary>
              {ko
                ? `남은 공간 약 ${view?.diskFreeBytes ? Math.round(view.diskFreeBytes / 1e9) : '?'}GB`
                : `Free space about ${view?.diskFreeBytes ? Math.round(view.diskFreeBytes / 1e9) : '?'}GB`}
            </summary>
            <p>
              {ko
                ? `모델이 놓인 디스크의 남은 공간은 약 ${view?.diskFreeBytes ? Math.round(view.diskFreeBytes / 1e9) : '?'}GB입니다. 7B–9B는 하나당 약 5GB이고, 1GB를 비워 두므로 공간이 부족하면 받지 않습니다.`
                : `Free space on this PC is about ${view?.diskFreeBytes ? Math.round(view.diskFreeBytes / 1e9) : '?'}GB. Each 7B–9B model is about 5GB, and 1GB is kept free, so a pull is refused when space is short.`}
            </p>
          </details>
          {localCard(model) && model !== 'os.neu-local' ? (
            <details className="ai-limit">
              <summary>
                {ko ? '지금 고른 모델: ' : 'Selected: '}
                {localCard(model)?.label}
              </summary>
              <p>{ko ? localCard(model)?.limitsKo : localCard(model)?.limitsEn}</p>
            </details>
          ) : null}
        </div>

        <label className="ai-connect-label">
          {ko ? '우선 경로' : 'Prefer'}
          <select
            value={provider}
            onChange={(e) => setProvider(e.target.value as 'auto' | 'local' | 'openai')}
            disabled={busy}
          >
            <option value="auto">{ko ? '자동 (로컬 있으면 로컬)' : 'Auto (local if available)'}</option>
            <option value="local">{ko ? '항상 로컬 (무료·느림)' : 'Always local (free · slow)'}</option>
            <option value="openai">{ko ? '항상 OpenAI (키 필요·빠름)' : 'Always OpenAI (key · fast)'}</option>
          </select>
        </label>

        <label className="ai-connect-label">
          {ko ? 'OpenAI API 키' : 'OpenAI API key'}
          <input
            type="password"
            autoComplete="off"
            placeholder={hasKey ? (ko ? '새 키로 바꾸려면 입력' : 'Paste a new key to replace') : 'sk-…'}
            value={key}
            onChange={(e) => setKey(e.target.value)}
            disabled={busy}
          />
        </label>
        {cloudCard(model) && cloudCard(model)?.vendorId !== 'openai' ? (
          <label className="ai-connect-label">
            {ko ? `${cloudCard(model)?.vendorKo} API 키` : `${cloudCard(model)?.vendor} API key`}
            <input
              type="password"
              autoComplete="off"
              placeholder={view?.vendorHas?.[cloudCard(model)?.vendorId || ''] ? (ko ? '새 키로 바꾸려면 입력' : 'Paste a new key to replace') : 'key'}
              value={vendorKey}
              onChange={(e) => setVendorKey(e.target.value)}
              disabled={busy}
            />
            <span className="ai-connect-hint">{ko ? cloudCard(model)?.noteKo : cloudCard(model)?.noteEn}</span>
          </label>
        ) : null}
        <p className="ai-connect-hint">
          {typeof location !== 'undefined' && location.hostname === 'os.neuavenue.com'
            ? ko
              ? '이 사이트(os.neuavenue.com)에는 로컬 llama가 없습니다. OpenAI 키는 이 탭 session에만 둡니다. 키 없이 Ask AI가 되려면 사이트 시크릿이 있어야 합니다.'
              : 'This site has no local llama. Your OpenAI key stays in this tab session. Site secret can serve Ask AI if set.'
            : ko
              ? '키는 이 PC의 ~/os.neu/data/user-llm.json 에만 저장됩니다. Neuavenue 공유 키는 없습니다.'
              : 'Key stays on this PC in ~/os.neu/data/user-llm.json. No shared Neuavenue key.'}
        </p>

        {msg ? <p className="ai-connect-msg">{msg}</p> : null}

        <div className="ai-connect-actions">
          <button type="button" className="btn ghost" onClick={onClose} disabled={busy}>
            {ko ? '닫기' : 'Close'}
          </button>
          {hasKey ? (
            <button type="button" className="btn ghost" onClick={() => void clearKey()} disabled={busy}>
              {ko ? '키 삭제' : 'Remove key'}
            </button>
          ) : null}
          {cloudOn ? (
            <button type="button" className="btn ghost" onClick={() => void saveToVault()} disabled={busy}>
              {ko ? '클라우드 금고에 저장' : 'Save to cloud vault'}
            </button>
          ) : null}
          <button type="button" className="btn ghost" onClick={() => void test()} disabled={busy}>
            {busy ? (ko ? '대기…' : 'Wait…') : ko ? '연결 테스트' : 'Test'}
          </button>
          <button type="button" className="save-btn" onClick={() => void save()} disabled={busy}>
            {ko ? '저장 후 사용' : 'Save & use'}
          </button>
        </div>
      </div>
    </div>
  )
}
