import { LOCALE_LABEL, LOCALES } from '../i18n/catalog'
import { useI18n } from '../i18n/LocaleContext'

export function LangPicker() {
  const { locale, setLocale, copy } = useI18n()
  return (
    <label className="lang-picker">
      <span className="sr-only">{copy.lang}</span>
      <select
        aria-label={copy.lang}
        value={locale}
        onChange={(e) => setLocale(e.target.value as typeof locale)}
      >
        {LOCALES.map((id) => (
          <option key={id} value={id}>
            {LOCALE_LABEL[id]}
          </option>
        ))}
      </select>
    </label>
  )
}
