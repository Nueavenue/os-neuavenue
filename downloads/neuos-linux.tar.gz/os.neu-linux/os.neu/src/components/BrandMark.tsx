import { useAppVersionLabel } from '../hooks/useAppVersionLabel'

type BrandMarkProps = {
  onClick?: () => void
  word?: boolean
  size?: 'mark' | 'lockup'
}

export function BrandMark({ onClick, word = true, size = 'mark' }: BrandMarkProps) {
  const ver = useAppVersionLabel()
  const inner =
    size === 'lockup' ? (
      <img className="brand-lockup" src="/brand/neuos-logo-transparent.png" alt={`NeuAvenue OS.neu ${ver}`} />
    ) : (
      <>
        <span className="brand-main">
          <img className="brand-mark-img" src="/brand/neuos-mark.png" alt="" />
          {word ? (
            <span className="brand-word">
              OS.<span>neu</span>
              <span className="brand-ver">{ver}</span>
            </span>
          ) : null}
        </span>
        {word ? (
          <img
            className="brand-company"
            src="/brand/neuos-logo-transparent.png"
            alt="Neuavenue"
          />
        ) : null}
      </>
    )

  if (onClick) {
    return (
      <button type="button" className="brand" onClick={onClick} aria-label={`OS.neu ${ver} home`}>
        {inner}
      </button>
    )
  }

  return <div className="brand">{inner}</div>
}
