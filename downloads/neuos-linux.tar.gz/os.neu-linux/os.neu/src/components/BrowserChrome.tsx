import { useEffect, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { BrowseDownloadPanel } from './BrowseDownloadPanel'
import { BrowseHistoryPanel } from './BrowseHistoryPanel'
import { BrowseToolsPanel } from './BrowseToolsPanel'
import type { AssignedTool, DownloadRecord, VisitRecord } from '../engine/browseLedger'

export type BrowserTab = {
  id: string
  title: string
  url: string
}

export type BrowserAccount = {
  name: string
  email: string
}

export type ChromeMenu = 'none' | 'history' | 'bookmarks' | 'account' | 'downloads' | 'tools'

type BrowserChromeProps = {
  tabs: BrowserTab[]
  activeId: string
  url: string
  visits: VisitRecord[]
  bookmarks: BrowserTab[]
  downloads: DownloadRecord[]
  tools: AssignedTool[]
  account: BrowserAccount | null
  ko: boolean
  locale: string
  electron: boolean
  onSelectTab: (id: string) => void
  onNewTab: () => void
  onCloseTab: (id: string) => void
  onNewWindow: () => void
  onUrl: (url: string) => void
  onHome: () => void
  onBack: () => void
  onBookmark: () => void
  onOpenSaved: (url: string) => void
  onAddVisit: (url: string, title: string) => void
  onEditVisit: (id: string, patch: { url: string; title: string }) => void
  onDeleteVisit: (id: string) => void
  onOpenDownload: (id: string) => void
  onShowDownload: (id: string) => void
  onRunTool: (tool: AssignedTool) => void
  onRequestSignIn: () => void
  onAskIdentity?: () => void
  onSignOut: () => void
  onMenuChange?: (open: boolean) => void
  openMenu?: ChromeMenu
  children: ReactNode
}

export function BrowserChrome({
  tabs,
  activeId,
  url,
  visits,
  bookmarks,
  downloads,
  tools,
  account,
  ko,
  locale,
  electron,
  onSelectTab,
  onNewTab,
  onCloseTab,
  onNewWindow,
  onUrl,
  onHome,
  onBack,
  onBookmark,
  onOpenSaved,
  onAddVisit,
  onEditVisit,
  onDeleteVisit,
  onOpenDownload,
  onShowDownload,
  onRunTool,
  onRequestSignIn,
  onAskIdentity,
  onSignOut,
  onMenuChange,
  openMenu,
  children,
}: BrowserChromeProps) {
  const [menu, setMenu] = useState<ChromeMenu>('none')
  const toggle = (next: ChromeMenu) => setMenu((cur) => (cur === next ? 'none' : next))

  useEffect(() => {
    if (openMenu && openMenu !== 'none') setMenu(openMenu)
  }, [openMenu])

  useEffect(() => {
    onMenuChange?.(menu !== 'none')
  }, [menu, onMenuChange])

  return (
    <section className="browser">
      <div className="browser-tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={`browser-tab${tab.id === activeId ? ' on' : ''}`}
            onClick={() => onSelectTab(tab.id)}
          >
            <span>{tab.title || 'New tab'}</span>
            {tabs.length > 1 ? (
              <i
                role="presentation"
                onClick={(e) => {
                  e.stopPropagation()
                  onCloseTab(tab.id)
                }}
              >
                ×
              </i>
            ) : null}
          </button>
        ))}
        <button type="button" className="icon-btn" aria-label="New tab" onClick={onNewTab}>
          +
        </button>
        <span className="browser-tabs-spacer" />
        <button
          type="button"
          className={`icon-btn${menu === 'downloads' ? ' on' : ''}`}
          aria-label={ko ? '다운로드' : 'Downloads'}
          title={ko ? '다운로드' : 'Downloads'}
          onClick={() => toggle('downloads')}
        >
          ↓
        </button>
      </div>
      <form
        className="browser-bar"
        onSubmit={(e) => {
          e.preventDefault()
          const data = new FormData(e.currentTarget)
          const next = String(data.get('url') ?? '')
          onUrl(next)
        }}
      >
        <button type="button" className="icon-btn" aria-label="Back" onClick={onBack}>
          ←
        </button>
        <button type="button" className="icon-btn" aria-label="Home" onClick={onHome}>
          ⌂
        </button>
        <input
          name="url"
          data-ui="url"
          aria-label="Address bar"
          defaultValue={url}
          key={url}
          placeholder="Address or what you want to do"
        />
        <button type="submit" className="icon-btn" aria-label="Go">
          →
        </button>
        <button type="button" className="icon-btn" aria-label="Bookmark" onClick={onBookmark} title="Bookmark">
          ★
        </button>
        <button type="button" className="icon-btn" aria-label="History" onClick={() => toggle('history')}>
          ⟳
        </button>
        <button type="button" className="icon-btn" aria-label="Bookmarks" onClick={() => toggle('bookmarks')}>
          ☰
        </button>
        <button
          type="button"
          className="icon-btn"
          aria-label={ko ? '도구' : 'Tools'}
          title={ko ? '배정된 도구' : 'Assigned tools'}
          onClick={() => toggle('tools')}
        >
          ⌗
        </button>
        <button type="button" className="icon-btn" aria-label="New window" onClick={onNewWindow} title="New window">
          ▭
        </button>
        <button
          type="button"
          className="icon-btn"
          aria-label={ko ? '아이디로 들어가기' : 'Enter with an id'}
          title={ko ? '아이디로 들어가기' : 'Enter with an id'}
          onClick={() => onAskIdentity?.()}
        >
          ID
        </button>
        <button
          type="button"
          className="icon-btn account-btn"
          onClick={() => {
            if (account) toggle('account')
            else onRequestSignIn()
          }}
        >
          {account ? account.name.slice(0, 1).toUpperCase() : '👤'}
        </button>
      </form>
      {menu === 'history' ? (
        <BrowseHistoryPanel
          visits={visits}
          ko={ko}
          locale={locale}
          onOpen={(href) => {
            setMenu('none')
            onOpenSaved(href)
          }}
          onAdd={onAddVisit}
          onEdit={onEditVisit}
          onDelete={onDeleteVisit}
        />
      ) : null}
      {menu === 'downloads' ? (
        <BrowseDownloadPanel
          downloads={downloads}
          ko={ko}
          locale={locale}
          electron={electron}
          onOpenFile={onOpenDownload}
          onShowFile={onShowDownload}
          onOpenUrl={(href) => {
            setMenu('none')
            onOpenSaved(href)
          }}
        />
      ) : null}
      {menu === 'tools' ? (
        <BrowseToolsPanel
          tools={tools}
          ko={ko}
          signedIn={Boolean(account)}
          onRun={(tool) => {
            setMenu('none')
            onRunTool(tool)
          }}
        />
      ) : null}
      {menu === 'bookmarks' ? (
        <div className="browser-menu">
          <b>{ko ? '북마크' : 'Bookmarks'}</b>
          {bookmarks.length ? (
            bookmarks.map((item) => (
              <button key={item.id} type="button" onClick={() => onOpenSaved(item.url)}>
                {item.title}
              </button>
            ))
          ) : (
            <p>{ko ? '별을 누르면 여기에 남습니다.' : 'Star a page to save it here.'}</p>
          )}
        </div>
      ) : null}
      {menu === 'account' && account
        ? createPortal(
            <div className="auth-layer" onClick={() => setMenu('none')}>
              <div className="auth-modal" role="dialog" onClick={(event) => event.stopPropagation()}>
                <h3>Signed in</h3>
                <p className="dock-hint">
                  {account.name}
                  <br />
                  {account.email}
                </p>
                <div className="row-actions">
                  <button type="button" className="btn ghost" onClick={() => setMenu('none')}>
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn"
                    onClick={() => {
                      setMenu('none')
                      onSignOut()
                    }}
                  >
                    Sign out
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
      {children}
    </section>
  )
}
