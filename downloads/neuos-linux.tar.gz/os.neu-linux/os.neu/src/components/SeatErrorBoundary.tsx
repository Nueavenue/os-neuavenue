import { Component, type ReactNode } from 'react'
import { reloadSeat } from '../engine/seatReload'

type Props = { children: ReactNode }
type State = { dead: boolean }

/** Chrome died. Hide the leftover guest and restore the seat — never a black hole. */
export class SeatErrorBoundary extends Component<Props, State> {
  state: State = { dead: false }

  static getDerivedStateFromError() {
    return { dead: true }
  }

  componentDidCatch() {
    reloadSeat()
  }

  render() {
    if (!this.state.dead) return this.props.children
    return (
      <div className="os-screen seat-restoring" role="status" aria-live="polite">
        <header className="status-bar">
          <span className="brand-word">
            daf<span>.</span>neu
          </span>
        </header>
        <p>Restoring the seat…</p>
      </div>
    )
  }
}
