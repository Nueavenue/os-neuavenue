import type { AuthUser } from '../engine/auth'

type SiteIdentityProps = {
  open: boolean
  site: string
  account: AuthUser | null
  electron: boolean
  ko: boolean
  onClose: () => void
  onGoogle: () => void
  onOsNeu: () => void
}

export function SiteIdentity({ open, site, account, electron, ko, onClose, onGoogle, onOsNeu }: SiteIdentityProps) {
  if (!open) return null
  const host = (() => {
    try {
      return new URL(site).hostname
    } catch {
      return site
    }
  })()

  return (
    <div className="auth-layer identity-layer" onClick={onClose}>
      <div className="auth-modal identity-modal" role="dialog" aria-labelledby="id-title" onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h3 id="id-title">{ko ? '아이디로 들어가기' : 'Enter with an id'}</h3>
          <button type="button" className="exit-x" onClick={onClose} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </div>
        <p className="dock-hint">
          {ko
            ? `${host || '이 사이트'}에 어떤 아이디로 들어갈까요? 고른 아이디는 os.neu 브라우저에 남습니다.`
            : `Which id should enter ${host || 'this site'}? The choice stays in the os.neu browser.`}
        </p>
        <button type="button" className="install-card" onClick={onGoogle}>
          <b>{ko ? 'Google 메일' : 'Google mail'}</b>
          <span>
            {ko
              ? electron
                ? 'Google 로그인 창을 엽니다. 끝나면 이 사이트로 돌아옵니다.'
                : 'Google 로그인 창을 엽니다. 미리보기에서는 쿠키가 이 탭과 다를 수 있습니다.'
              : electron
                ? 'Opens Google sign-in. Come back to this site when done.'
                : 'Opens Google sign-in. Preview cookies may not match this tab.'}
          </span>
        </button>
        <button type="button" className="install-card" onClick={onOsNeu}>
          <b>{account ? account.email : ko ? 'os.neu 계정' : 'os.neu account'}</b>
          <span>
            {account
              ? ko
                ? '이 아이디로 os.neu에 들어가 있는 상태입니다.'
                : 'You are already in os.neu with this id.'
              : ko
                ? 'os.neu에 로그인한 뒤 이 목록에 남깁니다.'
                : 'Sign in to os.neu to keep this list on your id.'}
          </span>
        </button>
        {!electron ? (
          <p className="dock-hint">
            {ko
              ? '사이트 로그인이 막히면 os.neu 화면에서 같은 주소를 여세요.'
              : 'If a site login is blocked, open the same address in the os.neu screen.'}
          </p>
        ) : null}
      </div>
    </div>
  )
}
