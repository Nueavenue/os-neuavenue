import { useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import type { PopupItem } from '../engine/dafChromeMenus'

const openMenus = new Set<() => void>()

export function DafPopupMenu({
  x,
  y,
  items,
  onPick,
  onClose,
}: {
  x: number
  y: number
  items: PopupItem[]
  onPick: (id: string) => void
  onClose: () => void
}) {
  const onCloseRef = useRef(onClose)
  onCloseRef.current = onClose

  useEffect(() => {
    const close = () => onCloseRef.current()
    for (const other of openMenus) other()
    openMenus.add(close)
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close()
    }
    window.addEventListener('pointerdown', close)
    window.addEventListener('keydown', onKey)
    return () => {
      openMenus.delete(close)
      window.removeEventListener('pointerdown', close)
      window.removeEventListener('keydown', onKey)
    }
  }, [])

  const left = Math.min(x, window.innerWidth - 280)
  const top = Math.min(y, window.innerHeight - 360)

  return createPortal(
    <div
      className="daf-popup"
      role="menu"
      data-allow-context
      data-ui="daf-popup"
      style={{ left, top }}
      onPointerDown={(event) => event.stopPropagation()}
    >
      {items.map((row) =>
        row.kind === 'sep' ? (
          <hr key={row.id} />
        ) : (
          <button
            key={row.id}
            type="button"
            role="menuitem"
            disabled={row.enabled === false}
            onClick={() => {
              onPick(row.id)
              onCloseRef.current()
            }}
          >
            {row.label}
          </button>
        ),
      )}
    </div>,
    document.body,
  )
}
