import { useState } from 'react'
import { createPortal } from 'react-dom'
import { GOOGLE_SIGNIN } from '../engine/browser'
import { loginRequest, logoutRequest, registerRequest, sendFeedback, trackEvent, type AuthUser } from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function AuthBar() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const open = neu.authPanel
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [hint, setHint] = useState('')
  const [mode, setMode] = useState<'login' | 'create'>('login')

  const resetForm = () => {
    setName('')
    setEmail('')
    setPassword('')
    setTitle('')
    setBody('')
    setHint('')
    setMode('login')
  }

  const closePanel = () => {
    resetForm()
    neu.setAuthPanel('none')
  }

  const cancel = () => {
    closePanel()
  }

  const finishAuth = (user: AuthUser) => {
    neu.setAccount(user)
    void trackEvent('login', neu.phase, user.email)
    resetForm()
    neu.setAuthPanel('none')
  }

  const login = async () => {
    const result = await loginRequest(email, password)
    if (result.ok && result.user) finishAuth(result.user)
    else setHint(ko ? '이메일 또는 비밀번호가 맞지 않습니다.' : 'Email or password is wrong.')
  }

  const create = async () => {
    const result = await registerRequest(name, email, password)
    if (result.needsConfirm) {
      setHint(ko ? '메일함에서 계정을 확인해 주세요.' : 'Check your email to confirm the account.')
      return
    }
    if (result.ok && result.user) finishAuth(result.user)
    else if (result.reason === 'email-taken') setHint(ko ? '이미 있는 이메일입니다.' : 'Email already used.')
    else if (result.reason === 'weak-password') setHint(ko ? '비밀번호는 6자 이상이어야 합니다.' : 'Password must be 6 or more characters.')
    else setHint(ko ? '이름, 이메일, 비밀번호를 적어 주세요.' : 'Name, email, and password are required.')
  }

  const logout = async () => {
    void trackEvent('logout', neu.phase, neu.account?.email)
    await logoutRequest()
    neu.setAccount(null)
  }

  const panel =
    open === 'login' ? (
      <div className="auth-layer" onClick={closePanel}>
        <div
          className="auth-modal"
          role="dialog"
          aria-labelledby="auth-title"
          onClick={(event) => event.stopPropagation()}
        >
          <h3 id="auth-title">{mode === 'login' ? (ko ? '로그인' : 'Sign in') : ko ? '계정 만들기' : 'Create account'}</h3>
          {mode === 'create' ? <input value={name} onChange={(e) => setName(e.target.value)} placeholder={ko ? '이름' : 'Name'} /> : null}
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder={ko ? '비밀번호' : 'Password'} type="password" />
          {hint ? <p className="dock-hint">{hint}</p> : null}
          {mode === 'login' ? (
            <button
              type="button"
              className="install-card auth-id"
              onClick={() => {
                closePanel()
                if (neu.phase === 'landing' && window.neuos?.browse?.newWindow) {
                  void window.neuos.browse.newWindow(GOOGLE_SIGNIN)
                  return
                }
                neu.openWeb(GOOGLE_SIGNIN)
              }}
            >
              <b>{ko ? 'Google 메일로 들어가기' : 'Enter with Google mail'}</b>
              <span>{ko ? '브라우저에서 Google 아이디를 고릅니다. 지금 보던 화면으로 돌아갑니다.' : 'Pick a Google id in the browser. You stay on this screen.'}</span>
            </button>
          ) : null}
          <div className="row-actions">
            <button type="button" className="btn ghost" onClick={cancel}>
              {ko ? '취소' : 'Cancel'}
            </button>
            <button type="button" className="btn" onClick={() => void (mode === 'login' ? login() : create())}>
              {mode === 'login' ? (ko ? '로그인' : 'Sign in') : ko ? '만들기' : 'Create'}
            </button>
          </div>
          <button
            type="button"
            className="text-link"
            onClick={() => {
              setHint('')
              setMode(mode === 'login' ? 'create' : 'login')
            }}
          >
            {mode === 'login' ? (ko ? '새 계정 만들기' : 'Create an account') : ko ? '이미 계정이 있습니다' : 'I already have an account'}
          </button>
        </div>
      </div>
    ) : open === 'feedback' ? (
      <div className="auth-layer" onClick={closePanel}>
        <div
          className="auth-modal"
          role="dialog"
          aria-labelledby="feedback-title"
          onClick={(event) => event.stopPropagation()}
        >
          <h3 id="feedback-title">{ko ? '피드백 남기기' : 'Leave feedback'}</h3>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={ko ? '제목' : 'Title'} />
          <textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={ko ? '내용' : 'Message'} rows={5} />
          {hint ? <p className="dock-hint">{hint}</p> : null}
          <div className="row-actions">
            <button type="button" className="btn ghost" onClick={closePanel}>
              {ko ? '취소' : 'Cancel'}
            </button>
            <button
              type="button"
              className="btn"
              onClick={async () => {
                try {
                  const result = await sendFeedback(title, body)
                  if (!result.ok) {
                    setHint(ko ? '제목 또는 내용을 적어 주세요.' : 'Write a title or a message.')
                    return
                  }
                  setTitle('')
                  setBody('')
                  setHint(result.cloud === false
                    ? ko
                      ? '이 기기에 저장했습니다.'
                      : 'Saved on this device.'
                    : ko
                      ? '저장했습니다.'
                      : 'Saved.')
                  window.setTimeout(() => {
                    resetForm()
                    neu.setAuthPanel('none')
                  }, 700)
                } catch {
                  setHint(ko ? '저장하지 못했습니다. 다시 시도해 주세요.' : 'Could not save. Try again.')
                }
              }}
            >
              {ko ? '저장' : 'Save'}
            </button>
          </div>
        </div>
      </div>
    ) : null

  return (
    <div className="auth-bar">
      {neu.account ? (
        <button type="button" className="pill" onClick={() => void logout()}>
          {neu.account.name} · {ko ? '로그아웃' : 'Sign out'}
        </button>
      ) : (
        <button
          type="button"
          className="pill"
          onClick={() => {
            resetForm()
            neu.setAuthPanel('login')
          }}
        >
          {ko ? '로그인' : 'Sign in'}
        </button>
      )}
      <button
        type="button"
        className="pill"
        onClick={() => {
          void trackEvent('click', neu.phase, 'feedback')
          resetForm()
          neu.setAuthPanel('feedback')
        }}
      >
        {ko ? '피드백' : 'Feedback'}
      </button>
      {neu.account?.admin ? (
        <button
          type="button"
          className="pill admin-pill"
          onClick={() => {
            void trackEvent('click', neu.phase, 'admin')
            neu.setAuthPanel('none')
            neu.go('admin')
          }}
        >
          Admin
        </button>
      ) : null}
      {panel ? createPortal(panel, document.body) : null}
    </div>
  )
}
