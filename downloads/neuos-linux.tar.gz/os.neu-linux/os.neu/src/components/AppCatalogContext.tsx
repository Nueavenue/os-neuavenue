import { useCallback, useMemo, useState, type ReactNode } from 'react'
import {
  appCatalogHiddenPhase,
  catalogItemState,
  readCatalogOpen,
  writeCatalogOpen,
  type CatalogItem,
} from '../engine/appCatalog'
import { trackEvent } from '../engine/auth'
import { setPromptOfficeTag } from '../engine/promptTags'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'
import { useCraftLaunchTiles } from './useCraftLaunchTiles'
import { AppCatalogCtx, type AppCatalogApi } from './appCatalogApi'

export function AppCatalogProvider({ children }: { children: ReactNode }) {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const tiles = useCraftLaunchTiles()
  const hidden = appCatalogHiddenPhase(neu.phase)
  const [open, setOpenState] = useState(() => readCatalogOpen(typeof localStorage === 'undefined' ? null : localStorage))
  const [nested, setNested] = useState(0)
  const [crmOpen, setCrmOpen] = useState(false)
  const [hint, setHint] = useState('')

  const setOpen = useCallback((next: boolean) => {
    setOpenState(next)
    writeCatalogOpen(typeof localStorage === 'undefined' ? null : localStorage, next)
  }, [])

  const registerNested = useCallback(() => {
    setNested((n) => n + 1)
    return () => setNested((n) => Math.max(0, n - 1))
  }, [])

  const neuOpen = useMemo(() => {
    const pick = (id: 'neu-word' | 'neu-excel' | 'neu-prez') => {
      const tile = tiles.find((row) => row.id === id)
      return { ready: Boolean(tile?.ready), href: tile?.href ?? null }
    }
    return { 'neu-word': pick('neu-word'), 'neu-excel': pick('neu-excel'), 'neu-prez': pick('neu-prez') }
  }, [tiles])

  const launch = useCallback(
    (item: CatalogItem) => {
      const state = catalogItemState(item, neuOpen)
      void trackEvent('click', neu.phase, `catalog-${item.id}`)
      if (!state.enabled) {
        setHint(ko ? `${item.labelKo} · 아직 없음` : `${item.labelEn} · not yet`)
        return
      }
      const office =
        item.launch === 'office-doc' ? 'doc' : item.launch === 'office-sheet' ? 'sheet' : item.launch === 'office-slides' ? 'slides' : null
      if (office) {
        // Only the home prompt can pick the chip up; on daf.neu, workspace, or console open the app itself.
        if (neu.phase === 'lui' || neu.phase === 'home') setPromptOfficeTag(office)
        else neu.openOffice(office)
      }
      else if (item.launch === 'neu-word' || item.launch === 'neu-excel' || item.launch === 'neu-prez') {
        const href = neuOpen[item.launch]?.href
        if (href) neu.openWeb(href)
        else setHint(ko ? `${item.labelKo} · CLI · 화면 앱은 없음` : `${item.labelEn} · CLI only`)
      } else if (item.launch === 'speak') {
        void neu.submit(ko ? '영어 회화 연습해줘' : 'practice english conversation')
      } else if (item.launch === 'crm') setCrmOpen(true)
      else if (item.launch === 'daf') neu.openDaf()
      else if (item.launch === 'cloud') {
        setHint(
          ko
            ? 'cloud.neu · 준비 중'
            : 'cloud.neu · coming later',
        )
      }
    },
    [ko, neu, neuOpen],
  )

  const api = useMemo<AppCatalogApi>(
    () => ({
      hidden,
      host: nested > 0 ? 'nested' : 'rail',
      open,
      setOpen,
      crmOpen,
      setCrmOpen,
      hint,
      registerNested,
      launch,
    }),
    [hidden, nested, open, setOpen, crmOpen, hint, registerNested, launch],
  )

  return <AppCatalogCtx.Provider value={api}>{children}</AppCatalogCtx.Provider>
}
