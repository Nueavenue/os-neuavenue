import { APP_CATALOG, catalogAccessLabel, catalogCategoryLabel, catalogItemLabel, catalogItemState } from '../engine/appCatalog'
import { useI18n } from '../i18n/LocaleContext'
import { useAppCatalog, useCatalogNeuState } from './appCatalogApi'

export function AppCatalogNav({ variant }: { variant: 'rail' | 'nested' }) {
  const { launch, hint } = useAppCatalog()
  const neu = useCatalogNeuState()
  const { locale } = useI18n()
  const ko = locale === 'ko'

  return (
    <nav className={`app-catalog-nav app-catalog-nav-${variant}`} aria-label={ko ? 'app.neu 앱 목록' : 'app.neu apps'}>
      {APP_CATALOG.map((category) => (
        <div key={category.id} className="app-catalog-cat">
          <p className="app-catalog-cat-label">
            <span>{catalogCategoryLabel(category, ko)}</span>
            <small>{catalogAccessLabel(category.access, ko)}</small>
          </p>
          {category.items.map((item) => {
            const state = catalogItemState(item, neu)
            const missing = !state.enabled
            const spoken = missing
              ? `${catalogItemLabel(item, ko)} · ${ko ? '아직 없음' : 'not yet'}`
              : catalogItemLabel(item, ko)
            return (
              <button
                key={item.id}
                type="button"
                className="app-catalog-item"
                disabled={missing}
                title={spoken}
                aria-label={spoken}
                onClick={() => launch(item)}
              >
                <span className="app-catalog-glyph">{item.glyph}</span>
                <span className="app-catalog-name">{catalogItemLabel(item, ko)}</span>
                {state.reason === 'cli' ? <small>CLI</small> : null}
              </button>
            )
          })}
        </div>
      ))}
      {hint ? <p className="app-catalog-hint">{hint}</p> : null}
    </nav>
  )
}
