import { useEffect, useRef, useState } from 'react'
import { ChatThread } from './ChatThread'
import { coachChat, transcribeSpeech } from '../engine/bridge'
import { ModelSelect } from './ModelSelect'
import { onPromptDraft } from '../engine/settingsBus'
import { clearPromptTags, includeChip, onPromptTags, type PromptTagState } from '../engine/promptTags'
import { SEARCH_ENGINES, readSearchEngine, writeSearchEngine, type SearchEngineId } from '../engine/searchEngines'
import {
  onCoachSpeaking,
  playCoachAudio,
  rememberCoach,
  stopCoachAudio,
} from '../engine/coachAudio'
import { listenOnce, speechAvailable, startLiveListen } from '../engine/speech'
import { cleanPrompt } from '../engine/mvpWork'
import { SPEECH_LANG } from '../i18n/catalog'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

type PromptDockProps = {
  onSubmit: (text: string, opts?: { userId?: string }) => void
  placeholder?: string
  disabled?: boolean
  /** Parent already draws ChatThread from the same turns. */
  hideThread?: boolean
  /** Home screen: taller, full-width box. Enter sends. */
  tall?: boolean
}

function pickMime(): string {
  if (typeof MediaRecorder === 'undefined') return ''
  if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) return 'audio/webm;codecs=opus'
  if (MediaRecorder.isTypeSupported('audio/webm')) return 'audio/webm'
  if (MediaRecorder.isTypeSupported('audio/mp4')) return 'audio/mp4'
  return ''
}

export function PromptDock({
  onSubmit,
  placeholder,
  disabled,
  hideThread,
  tall,
}: PromptDockProps) {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const [value, setValue] = useState('')
  const [live, setLive] = useState(false)
  const [hearing, setHearing] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [hint, setHint] = useState('')
  const [tags, setTags] = useState<PromptTagState>({
    office: null,
    include: null,
    slidesTemplateId: null,
    slidesTemplateName: null,
  })
  const [engine, setEngine] = useState<SearchEngineId>(() => readSearchEngine())
  const fieldRef = useRef<HTMLTextAreaElement | HTMLInputElement | null>(null)
  const recRef = useRef<{
    recorder: MediaRecorder
    chunks: Blob[]
    stream: MediaStream
  } | null>(null)
  const liveRef = useRef<ReturnType<typeof startLiveListen>>(null)
  const userTurnRef = useRef<string>('')
  const awaitingReplyRef = useRef(false)
  const ph = placeholder ?? copy.prompt
  const online = neu.network.online
  const thinking = neu.chats.some((turn) => turn.role === 'neu' && turn.pending)
  const legend =
    locale === 'ko'
      ? '오른쪽 마이크: 눌러 말하기 → 다시 눌러 보내기. 왼쪽 스피커가 바로 답합니다. 스피커를 다시 누르면 답을 한 번 더 듣습니다.'
      : 'Right mic: tap to talk, tap again to send. Left speaker answers right away. Tap speaker again to replay.'

  useEffect(() => onCoachSpeaking(setSpeaking), [])
  useEffect(() => onPromptTags(setTags), [])
  useEffect(
    () =>
      onPromptDraft((text) => {
        setValue(text)
        fieldRef.current?.focus()
      }),
    [],
  )
  useEffect(() => {
    if (tags.include) fieldRef.current?.focus()
  }, [tags.include])

  useEffect(() => {
    if (!awaitingReplyRef.current) return
    if (thinking) {
      setHint(locale === 'ko' ? '요청을 보냈습니다. 모델 응답을 기다립니다.' : 'Request sent. Waiting for the model.')
      return
    }
    if (speaking) {
      setHint(locale === 'ko' ? 'os.neu가 말하고 있습니다 — 들어 보세요.' : 'os.neu is speaking — listen.')
      return
    }
    if (awaitingReplyRef.current) {
      awaitingReplyRef.current = false
      setHint(
        locale === 'ko'
          ? '당신 차례입니다. 마이크를 눌러 이어서 말하세요.'
          : 'Your turn — tap the mic to continue.',
      )
    }
  }, [thinking, speaking, locale])

  const openUserBubble = () => {
    const id = neu.beginChat('user')
    userTurnRef.current = id
    return id
  }

  const typeUser = (text: string, typing = true) => {
    const id = userTurnRef.current
    if (!id) return
    neu.patchChat(id, { text, pending: !text, typing })
  }

  const send = (text: string, userId?: string) => {
    const next = cleanPrompt(text)
    if (!next) return
    awaitingReplyRef.current = true
    setHint(locale === 'ko' ? '요청을 보냈습니다. 모델 응답을 기다립니다.' : 'Request sent. Waiting for the model.')
    onSubmit(next, userId ? { userId } : undefined)
    setValue('')
    userTurnRef.current = ''
  }

  const transcribeBlob = async (blob: Blob): Promise<string> => {
    if (blob.size <= 200) return ''
    return transcribeSpeech(blob)
  }

  const stopRecording = () => {
    const current = recRef.current
    if (!current) return
    if (current.recorder.state !== 'inactive') {
      try {
        current.recorder.requestData()
      } catch {
        /* some browsers omit requestData */
      }
      current.recorder.stop()
    }
  }

  const startRecording = async () => {
    stopCoachAudio()
    const mime = pickMime()
    openUserBubble()
    if (!online || !mime) {
      if (!speechAvailable()) {
        neu.dropChat(userTurnRef.current)
        userTurnRef.current = ''
        setHint(copy.typeOnly)
        return
      }
      setLive(true)
      setHint(locale === 'ko' ? '듣고 있습니다. 한 문장 말해 주세요.' : 'Listening — speak one sentence.')
      try {
        const said = await listenOnce(SPEECH_LANG[locale])
        typeUser(said, true)
        send(said, userTurnRef.current)
      } catch (err) {
        neu.dropChat(userTurnRef.current)
        userTurnRef.current = ''
        setHint(err instanceof Error ? err.message : 'Please say that again.')
      } finally {
        setLive(false)
      }
      return
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        channelCount: 1,
      },
    })
    const recorder = new MediaRecorder(stream, { mimeType: mime })
    const chunks: Blob[] = []
    const liveListen = startLiveListen(SPEECH_LANG[locale], (partial) => typeUser(partial, false))
    liveRef.current = liveListen
    recorder.ondataavailable = (ev) => {
      if (ev.data.size) chunks.push(ev.data)
    }
    recorder.onstop = () => {
      stream.getTracks().forEach((track) => track.stop())
      recRef.current = null
      const heardLive = liveListen?.stop() ?? ''
      liveRef.current = null
      const type = mime.split(';')[0] || 'audio/webm'
      const blob = new Blob(chunks, { type })
      const userId = userTurnRef.current
      setHearing(true)
      void (async () => {
        try {
          let said = ''
          try {
            said = await transcribeBlob(blob)
          } catch {
            said = heardLive
          }
          if (!said) said = heardLive
          if (!said) {
            throw new Error(
              locale === 'ko'
                ? '말을 못 들었습니다. 마이크를 누르고 말한 뒤, 끝나면 다시 누르세요.'
                : 'Could not hear that. Tap the mic, speak, then tap again.',
            )
          }
          typeUser(said, true)
          setValue(said)
          send(said, userId)
        } catch (err) {
          if (userId) neu.dropChat(userId)
          userTurnRef.current = ''
          setHint(err instanceof Error ? err.message : 'Please say that again.')
        } finally {
          setHearing(false)
          setLive(false)
        }
      })()
    }
    recRef.current = { recorder, chunks, stream }
    recorder.start(200)
    setLive(true)
    setHint(
      locale === 'ko'
        ? '듣고 있습니다. 말을 마치면 마이크를 다시 누르세요.'
        : 'Listening — tap the mic again when you finish speaking.',
    )
  }

  const mic = async () => {
    if (disabled) return
    if (speaking || thinking) stopCoachAudio()
    if (live && recRef.current) {
      stopRecording()
      setHint(locale === 'ko' ? '그 말을 글로 옮기는 중…' : 'Hearing that line…')
      return
    }
    if (live || hearing) return
    try {
      await startRecording()
    } catch {
      setLive(false)
      if (userTurnRef.current) {
        neu.dropChat(userTurnRef.current)
        userTurnRef.current = ''
      }
      setHint(
        locale === 'ko'
          ? '마이크 사용을 허용한 뒤 다시 눌러 주세요.'
          : 'Please allow the microphone, then tap again.',
      )
    }
  }

  const speaker = async () => {
    if (!online) {
      setHint(locale === 'ko' ? '스피커는 인터넷이 필요합니다.' : 'Speaker needs an internet connection.')
      return
    }
    const line = value.trim()
    if (line) {
      send(line)
      return
    }
    if (speaking) {
      stopCoachAudio()
      setHint(locale === 'ko' ? '멈췄습니다. 마이크를 눌러 이어서 말하세요.' : 'Stopped. Tap the mic to continue.')
      return
    }
    const replayed = await playCoachAudio()
    if (replayed) {
      setHint(locale === 'ko' ? 'os.neu 답을 다시 듣는 중…' : 'Replaying os.neu…')
      return
    }
    const neuId = neu.beginChat('neu')
    try {
      setHint(locale === 'ko' ? 'os.neu가 인사하는 중…' : 'os.neu is greeting you…')
      const coach = await coachChat(
        'Please greet me in one short English line and ask what I want to do on this computer.',
        neu.chats.slice(-8).map((turn) => ({
          role: turn.role === 'user' ? ('user' as const) : ('assistant' as const),
          content: turn.text,
        })),
        { audio: true },
      )
      if (!coach.ok || !coach.reply) throw new Error('Coach is unavailable.')
      rememberCoach(coach.reply, coach.audio)
      neu.patchChat(neuId, { text: coach.reply, pending: false, typing: true })
      await playCoachAudio()
      setHint(
        locale === 'ko'
          ? '당신 차례입니다. 마이크를 눌러 말하세요.'
          : 'Your turn — tap the mic and speak.',
      )
    } catch (err) {
      neu.dropChat(neuId)
      setHint(err instanceof Error ? err.message : 'Speaker is unavailable.')
    }
  }

  const speakerOn = online && (speaking || thinking || Boolean(value.trim()))

  const pickEngine = (id: SearchEngineId) => {
    setEngine(id)
    writeSearchEngine(id)
  }

  const included = includeChip(tags.include)

  return (
    <div className={`dock-wrap${tall ? ' is-tall' : ''}`}>
      <form
        className={`dock${tall ? ' is-tall' : ''}${tags.include ? ' has-include' : ''}`}
        onSubmit={(e) => {
          e.preventDefault()
          send(value)
        }}
      >
        {tags.include ? (
          <div className="dock-include">
            <span className="dock-include-chip" role="status">
              {included}
            </span>
            {tags.include === 'daf' ? (
              <select
                className="dock-include-list"
                value={engine}
                onChange={(e) => pickEngine(e.target.value as SearchEngineId)}
                aria-label={locale === 'ko' ? '검색 엔진' : 'Search engine'}
              >
                {SEARCH_ENGINES.map((row) => (
                  <option key={row.id} value={row.id}>
                    {locale === 'ko' ? row.labelKo : row.labelEn}
                  </option>
                ))}
              </select>
            ) : (
              <ModelSelect className="dock-include-list" />
            )}
            <button
              type="button"
              className="dock-include-clear"
              onClick={() => clearPromptTags()}
              aria-label={locale === 'ko' ? '포함 해제' : 'Clear include'}
            >
              ×
            </button>
          </div>
        ) : null}
        <div className="dock-row">
        {tall ? (
          <textarea
            ref={(node) => {
              fieldRef.current = node
            }}
            value={value}
            disabled={disabled}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                send(value)
              }
            }}
            placeholder={ph}
            aria-label="Command"
            rows={4}
          />
        ) : (
          <input
            ref={(node) => {
              fieldRef.current = node
            }}
            value={value}
            disabled={disabled}
            onChange={(e) => setValue(e.target.value)}
            placeholder={ph}
            aria-label="Command"
            autoComplete="off"
          />
        )}
        <button
          type="button"
          className={`speaker${speakerOn ? ' on' : ''}${speaking ? ' speaking' : ''}${thinking ? ' thinking' : ''}`}
          onClick={() => void speaker()}
          aria-label={locale === 'ko' ? '스피커: 전송 또는 os.neu 목소리' : 'Speaker: send or replay os.neu'}
          disabled={disabled || !online}
          title={
            locale === 'ko'
              ? '답을 다시 듣거나, 적은 말을 보냅니다'
              : 'Replay the answer, or send a typed line'
          }
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
            <path d="M3 10v4h4l5 4V6L7 10H3z" fill="currentColor" />
            <path d="M16 9a4 4 0 0 1 0 6" stroke="currentColor" strokeWidth="2" />
            <path d="M18.5 7a7 7 0 0 1 0 10" stroke="currentColor" strokeWidth="2" />
          </svg>
        </button>
        <button
          type="button"
          className={`mic${live ? ' live' : ''}${hearing ? ' hearing' : ''}`}
          onClick={() => void mic()}
          aria-label={live ? 'Stop listening' : 'Speak and send'}
          title={
            locale === 'ko'
              ? '눌러 말하고, 끝나면 다시 누릅니다'
              : 'Tap to talk, tap again to stop'
          }
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
            <rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor" />
            <path d="M6 11a6 6 0 0 0 12 0" stroke="currentColor" strokeWidth="2" />
            <path d="M12 17v4" stroke="currentColor" strokeWidth="2" />
          </svg>
        </button>
        </div>
      </form>
      <p className="dock-legend">{legend}</p>
      {hint ? <p className="dock-hint">{hint}</p> : null}
      {!hideThread && neu.chats.length ? (
        <ChatThread turns={neu.chats.slice(-8)} />
      ) : null}
    </div>
  )
}
