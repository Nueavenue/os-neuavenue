import { useEffect, useState } from 'react'
import { loadAiPrefs, modelReady, shownModelOptions } from '../engine/aiPrefs'
import { fetchLlmSettings, type LlmSettingsView } from '../engine/llmConnect'
import type { OfficeApp } from '../engine/office'
import { onModelPick, openSettings, publishShellOverlay } from '../engine/settingsBus'
import { useAiPrefs } from '../hooks/useAiPrefs'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

const APP_NAME: Record<OfficeApp, { ko: string; en: string }> = {
  doc: { ko: '문서', en: 'Document' },
  sheet: { ko: '시트', en: 'Sheet' },
  slides: { ko: '슬라이드', en: 'Slides' },
}

/** "Which AI should write this?" — shown when Docs / Sheets / Slides is pressed. */
export function ModelPickDialog() {
  const neu = useNeu()
  const prefs = useAiPrefs()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [app, setApp] = useState<OfficeApp | null>(null)
  const [view, setView] = useState<LlmSettingsView | null>(null)

  useEffect(() => onModelPick((next) => setApp(next)), [])

  useEffect(() => {
    const saved = loadAiPrefs().defaultModel
    if (saved) neu.setOfficeModel(saved)
    // Apply the saved default once at start.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    publishShellOverlay('model-pick', Boolean(app))
    if (app) return () => publishShellOverlay('model-pick', false)
  }, [app])

  useEffect(() => {
    if (!app) return
    void fetchLlmSettings().then(setView)
  }, [app])

  if (!app) return null

  const options = shownModelOptions(prefs)
  const current = options.some((row) => row.id === neu.officeModel) ? neu.officeModel : prefs.defaultModel
  const name = ko ? APP_NAME[app].ko : APP_NAME[app].en

  const pick = (model: string) => {
    neu.setOfficeModel(model)
    setApp(null)
    neu.openOffice(app)
  }

  return (
    <div className="mvp-modal-scrim settings-scrim" role="presentation" onClick={() => setApp(null)}>
      <div
        className="mvp-modal model-pick"
        role="dialog"
        aria-modal
        aria-label={ko ? `${name} — AI 모델 고르기` : `${name} — choose AI model`}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="mvp-modal-head">
          <h2>{ko ? `${name} 만들기 — 어떤 AI로 쓸까요?` : `New ${name.toLowerCase()} — which AI should write it?`}</h2>
          <button type="button" className="icon-btn" onClick={() => setApp(null)} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </header>
        {options.length ? (
          <div className="model-pick-list">
            {options.map((row) => {
              const ready = modelReady(row.id, view)
              return (
                <button
                  key={row.id}
                  type="button"
                  className={`model-pick-chip${row.id === current ? ' on' : ''}`}
                  onClick={() => pick(row.id)}
                >
                  <strong>{row.label.replace(/^\d+ · /, '')}</strong>
                  <small>
                    {row.id === prefs.defaultModel ? (ko ? '기본 · ' : 'Default · ') : ''}
                    {view ? (ready ? (ko ? '연결됨' : 'Connected') : ko ? '키 필요 / 설치 안 됨' : 'Needs key / not installed') : '…'}
                  </small>
                </button>
              )
            })}
          </div>
        ) : (
          <p className="model-pick-empty">
            {ko
              ? '아직 고른 모델이 없습니다. 설정에서 화면에 보일 모델을 켜 주세요.'
              : 'No models chosen yet. Turn on the models to show in Settings.'}
          </p>
        )}
        <div className="mvp-modal-actions">
          <button
            type="button"
            className="btn ghost"
            onClick={() => {
              setApp(null)
              openSettings('ai')
            }}
          >
            {ko ? '설정에서 모델 더 켜기' : 'Turn on more models'}
          </button>
          <button type="button" className="btn ghost" onClick={() => pick(neu.officeModel)}>
            {ko ? '지금 모델로 열기' : 'Open with current model'}
          </button>
        </div>
      </div>
    </div>
  )
}
