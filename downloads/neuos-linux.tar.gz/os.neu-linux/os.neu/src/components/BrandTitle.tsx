const LETTERS: { ch: string; neu?: boolean }[] = [
  { ch: 'O' },
  { ch: 'S' },
  { ch: '.' },
  { ch: 'n', neu: true },
  { ch: 'e', neu: true },
  { ch: 'u', neu: true },
]

type BrandTitleProps = {
  wave?: boolean
  as?: 'h1' | 'h2'
  className?: string
}

export function BrandTitle({ wave = false, as = 'h1', className }: BrandTitleProps) {
  const Tag = as
  return (
    <Tag className={`brand-title${wave ? ' wave' : ''}${className ? ` ${className}` : ''}`}>
      {LETTERS.map((item, index) => (
        <span
          key={`${item.ch}-${index}`}
          className={item.neu ? 'neu' : undefined}
          style={wave ? { animationDelay: `${index * 0.12}s` } : undefined}
        >
          {item.ch}
        </span>
      ))}
      <small>v1.0</small>
    </Tag>
  )
}
