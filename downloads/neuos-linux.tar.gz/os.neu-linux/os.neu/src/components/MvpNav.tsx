import { useMvpWork } from '../state/mvpWorkContext'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'
import { formatWorkTime } from '../engine/mvpWork'
import { openMyWork, openSettings } from '../engine/settingsBus'

export function MvpNav() {
  const neu = useNeu()
  const mvp = useMvpWork()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const recent = mvp.works.slice(0, 5)

  return (
    <div className="mvp-nav" aria-label={ko ? '작업 목록' : 'Work list'}>
      <p className="mvp-nav-title">{ko ? '작업' : 'Work'}</p>
      <button
        type="button"
        className="mvp-nav-item"
        onClick={() => {
          mvp.clearActive()
          mvp.setPending(null)
          neu.go('lui')
        }}
      >
        {ko ? '새 작업' : 'New work'}
      </button>
      <button
        type="button"
        className="mvp-nav-item"
        onClick={() => openMyWork()}
      >
        {ko ? '내 작업' : 'My work'}
      </button>
      {recent.length ? (
        <ul className="mvp-nav-recent">
          {recent.map((row) => (
            <li key={row.id}>
              <button
                type="button"
                onClick={() => {
                  mvp.openWork(row.id)
                  neu.openOffice('doc')
                }}
              >
                <span>{row.title}</span>
                <small>{formatWorkTime(row, ko)}</small>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      <button
        type="button"
        className="mvp-nav-item"
        onClick={() => {
          if (mvp.active) {
            mvp.setTab('web')
            neu.openOffice('doc')
          } else {
            neu.openDaf()
          }
        }}
      >
        {ko ? '웹 자료' : 'Web sources'}
      </button>
      <button type="button" className="mvp-nav-item" onClick={() => openSettings('ai')}>
        {ko ? '설정·도움말' : 'Settings · Help'}
      </button>
    </div>
  )
}
