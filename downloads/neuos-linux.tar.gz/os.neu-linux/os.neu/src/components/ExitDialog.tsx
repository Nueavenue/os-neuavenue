import { useEffect, useState } from 'react'
import { fetchUninstallStatus } from '../engine/bridge'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function ExitDialog() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const [files, setFiles] = useState(false)
  const [forced, setForced] = useState(false)
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')

  useEffect(() => {
    if (!neu.exitOpen) return
    void fetchUninstallStatus()
      .then((status) => setForced(status.forced))
      .catch(() => setForced(false))
  }, [neu.exitOpen])

  if (!neu.exitOpen) return null

  const health = neu.bootHealth
  const checking = health === null
  const healthText = checking
    ? copy.exitChecking
    : health.missing
      ? copy.deviceWarn
      : health.stale
        ? `heartbeat ${Math.round((health.ageMs ?? 0) / 1000)}s ago · ${health.stage ?? ''}`
        : `ok · ${health.stage ?? 'loop'} · ${health.jeos ? 'os.neu' : 'host'}`

  const leaveUbuntu = async () => {
    setBusy(true)
    setNote(copy.exitUninstallHint)
    await neu.uninstallAndLeave(files)
  }

  return (
    <div className="exit-overlay" role="dialog" aria-modal="true" aria-labelledby="exit-title">
      <div className="exit-card">
        <div className="exit-card-head">
          <h2 id="exit-title">{copy.exitTitle}</h2>
          <button
            type="button"
            className="exit-x"
            onClick={neu.closeExit}
            disabled={busy}
            aria-label={locale === 'ko' ? '닫기' : 'Close'}
            title={locale === 'ko' ? '닫기' : 'Close'}
          >
            ×
          </button>
        </div>
        <p>{copy.exitBody}</p>
        <div className={`pill ${checking ? '' : health?.ok && !health.stale ? 'ok' : 'warn'}`}>{healthText}</div>
        <div className="exit-choices">
          <button type="button" className="install-card" onClick={neu.chooseJeos} disabled={checking || busy}>
            <b>{copy.exitJeos}</b>
            <span>{copy.exitJeosHint}</span>
          </button>
          <button type="button" className="install-card" onClick={neu.chooseLoop} disabled={checking || busy}>
            <b>{copy.exitLoop}</b>
            <span>{copy.exitLoopHint}</span>
          </button>
        </div>
        <button
          type="button"
          className="install-card uninstall-card"
          onClick={() => void leaveUbuntu()}
          disabled={busy}
        >
          <b>{copy.exitUninstall}</b>
          <span>{copy.exitUninstallHint}</span>
          {forced ? <span className="uninstall-flag">autostart on</span> : null}
        </button>
        <label className="uninstall-files">
          <input type="checkbox" checked={files} onChange={(e) => setFiles(e.target.checked)} disabled={busy} />
          <span>
            <b>{copy.exitRemoveFiles}</b>
            <small>{copy.exitRemoveFilesHint}</small>
          </span>
        </label>
        <div className="row-actions">
          <button type="button" className="btn ghost" onClick={neu.closeExit} disabled={busy}>
            {copy.exitCancel}
          </button>
          <button type="button" className="btn danger" onClick={() => void neu.quitApp()} disabled={busy}>
            {copy.exitQuit}
          </button>
        </div>
        <p className="exit-quit-hint">{note || copy.exitQuitHint}</p>
      </div>
    </div>
  )
}
