import { useMvpWork } from '../state/mvpWorkContext'
import { useI18n } from '../i18n/LocaleContext'
import type { MvpAudience } from '../engine/mvpWork'

export function MvpPurposeCard({ onStart, onEdit }: { onStart: () => void; onEdit: () => void }) {
  const mvp = useMvpWork()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const pending = mvp.pending
  if (!pending) return null

  const pick = (audience: MvpAudience) => mvp.patchPending({ audience, audienceNote: audience === 'other' ? pending.audienceNote : '' })

  return (
    <div className="mvp-purpose" role="region" aria-label={ko ? '목적 확인' : 'Confirm purpose'}>
      <p className="mvp-purpose-label">{ko ? '요청' : 'Your request'}</p>
      <p className="mvp-purpose-request">{pending.prompt}</p>
      <p className="mvp-purpose-q">{ko ? '누가 사용할 자료인가요?' : 'Who is this for?'}</p>
      <div className="mvp-purpose-picks">
        <button type="button" className={pending.audience === 'team' ? 'on' : ''} onClick={() => pick('team')}>
          {ko ? '우리 팀 내부 검토용' : 'Internal team review'}
        </button>
        <button type="button" className={pending.audience === 'customer' ? 'on' : ''} onClick={() => pick('customer')}>
          {ko ? '고객 제출용' : 'Customer-facing'}
        </button>
        <button type="button" className={pending.audience === 'other' ? 'on' : ''} onClick={() => pick('other')}>
          {ko ? '직접 입력' : 'Other'}
        </button>
      </div>
      {pending.audience === 'other' ? (
        <input
          className="mvp-purpose-note"
          value={pending.audienceNote}
          placeholder={ko ? '용도를 적으세요' : 'Describe the use'}
          onChange={(e) => mvp.patchPending({ audienceNote: e.target.value })}
        />
      ) : null}
      <div className="mvp-purpose-plan">
        <p className="mvp-purpose-label">{ko ? '진행할 작업' : 'Plan'}</p>
        <ol>
          <li>{ko ? '서비스별 공식 자료 확인 (daf.neu)' : 'Check official sources (daf.neu)'}</li>
          <li>{ko ? '기능·가격·제약 비교' : 'Compare features, price, limits'}</li>
          <li>{ko ? '비교표가 포함된 보고서 작성 (app.neu 문서)' : 'Write a report with a comparison table (app.neu doc)'}</li>
        </ol>
      </div>
      <div className="mvp-purpose-actions">
        <button type="button" onClick={onEdit}>
          {ko ? '수정' : 'Edit'}
        </button>
        <button type="button" className="primary" onClick={onStart} disabled={!pending.audience || (pending.audience === 'other' && !pending.audienceNote.trim())}>
          {ko ? '시작' : 'Start'}
        </button>
      </div>
    </div>
  )
}
