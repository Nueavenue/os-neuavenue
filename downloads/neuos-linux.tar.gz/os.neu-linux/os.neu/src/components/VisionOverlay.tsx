import type { VisionFrame } from '../types'

export function VisionOverlay({ frame }: { frame: VisionFrame | null }) {
  if (!frame) return null
  return (
    <>
      {frame.elements.slice(0, 8).map((el) => (
        <div
          key={el.id}
          className="vision-box"
          style={{ left: el.x, top: el.y, width: el.w, height: el.h }}
        >
          <span>
            {el.label} {el.x},{el.y}
          </span>
        </div>
      ))}
    </>
  )
}
