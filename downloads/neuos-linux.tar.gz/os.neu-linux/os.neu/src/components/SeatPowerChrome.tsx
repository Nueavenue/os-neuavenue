import { useEffect, useState } from 'react'

type BatteryState = { pct: number | null; charging: boolean; known: boolean }

function useBattery(): BatteryState {
  const [state, setState] = useState<BatteryState>({ pct: null, charging: false, known: false })
  useEffect(() => {
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<{
        level: number
        charging: boolean
        addEventListener: (type: string, fn: () => void) => void
        removeEventListener: (type: string, fn: () => void) => void
      }>
    }
    if (!nav.getBattery) return
    let battery: Awaited<ReturnType<NonNullable<typeof nav.getBattery>>> | null = null
    let stop = false
    const sync = () => {
      if (!battery || stop) return
      setState({
        pct: Math.round(battery.level * 100),
        charging: Boolean(battery.charging),
        known: true,
      })
    }
    void nav.getBattery().then((row) => {
      if (stop) return
      battery = row
      sync()
      row.addEventListener('levelchange', sync)
      row.addEventListener('chargingchange', sync)
    })
    return () => {
      stop = true
      battery?.removeEventListener('levelchange', sync)
      battery?.removeEventListener('chargingchange', sync)
    }
  }, [])
  return state
}

/** Live battery percent. No number when this browser does not report power. */
export function BatteryReadout({ ko }: { ko: boolean }) {
  const bat = useBattery()
  const label = !bat.known
    ? ko
      ? '전력 확인 불가'
      : 'Power unknown'
    : `${bat.charging ? (ko ? '충전 ' : 'Charging ') : ''}${bat.pct}%`
  return (
    <span className="power-readout" title={ko ? '이 PC의 배터리. 전원이 0이면 화면이 꺼집니다.' : 'This PC battery. At 0% the screen is off.'}>
      {label}
    </span>
  )
}
