import { useEffect, useState } from 'react'
import { loadHardwareInventory, type HardwareGroup, type HardwareInventory, type UpdateFlag } from '../engine/hardwareMenu'
import { useI18n } from '../i18n/LocaleContext'

function updateLabel(flag: UpdateFlag, ko: boolean) {
  if (flag === 'current') return ko ? '최신' : 'Up to date'
  if (flag === 'available') return ko ? '확인 필요' : 'Needs attention'
  return ko ? '확인 안 됨' : 'Not checked'
}

function when(ts: number, locale: string) {
  return new Date(ts).toLocaleString(locale, { dateStyle: 'medium', timeStyle: 'short' })
}

export function HardwareMenu() {
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [open, setOpen] = useState(false)
  const [pack, setPack] = useState<HardwareInventory | null>(null)
  const [active, setActive] = useState('system')

  useEffect(() => {
    if (!open) return
    let cancelled = false
    void loadHardwareInventory().then((next) => {
      if (!cancelled) setPack(next)
    })
    return () => {
      cancelled = true
    }
  }, [open])

  const group: HardwareGroup | undefined = pack?.groups.find((row) => row.id === active) ?? pack?.groups[0]

  return (
    <>
      <button
        type="button"
        className={`hw-edge${open ? ' on' : ''}`}
        onClick={() => setOpen((cur) => !cur)}
        aria-expanded={open}
        aria-label={ko ? '하드웨어 설정' : 'Hardware settings'}
        title={ko ? '하드웨어 설정' : 'Hardware settings'}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
          <rect x="4" y="4" width="6" height="6" rx="1.2" stroke="currentColor" strokeWidth="1.8" />
          <rect x="14" y="4" width="6" height="6" rx="1.2" stroke="currentColor" strokeWidth="1.8" />
          <rect x="4" y="14" width="6" height="6" rx="1.2" stroke="currentColor" strokeWidth="1.8" />
          <rect x="14" y="14" width="6" height="6" rx="1.2" stroke="currentColor" strokeWidth="1.8" />
        </svg>
      </button>
      {open ? (
        <button type="button" className="hw-scrim" aria-label={ko ? '닫기' : 'Close'} onClick={() => setOpen(false)} />
      ) : null}
      <aside className={`hw-sheet${open ? ' open' : ''}`} aria-hidden={!open}>
        <div className="hw-sheet-nav">
          <p className="hw-sheet-kicker">{ko ? '설정' : 'Settings'}</p>
          {(pack?.groups ?? []).map((row) => (
            <button
              key={row.id}
              type="button"
              className={row.id === group?.id ? 'on' : ''}
              onClick={() => setActive(row.id)}
            >
              {ko ? row.label : row.labelEn}
            </button>
          ))}
        </div>
        <div className="hw-sheet-body">
          <header className="hw-sheet-head">
            <h3>{group ? (ko ? group.label : group.labelEn) : ko ? '하드웨어' : 'Hardware'}</h3>
            <button type="button" className="exit-x" onClick={() => setOpen(false)} aria-label={ko ? '닫기' : 'Close'}>
              ×
            </button>
          </header>
          {!pack ? <p>{ko ? '이 기기를 읽는 중…' : 'Reading this machine…'}</p> : null}
          {group?.items.map((row) => (
            <article key={row.id} className="hw-device">
              <div className="hw-device-top">
                <b>{row.name}</b>
                <span className={`hw-flag ${row.update}`}>{updateLabel(row.update, ko)}</span>
              </div>
              <dl>
                <div>
                  <dt>{ko ? '상품명' : 'Name'}</dt>
                  <dd>{row.name}</dd>
                </div>
                <div>
                  <dt>{ko ? '버전' : 'Version'}</dt>
                  <dd>{row.version}</dd>
                </div>
                <div>
                  <dt>{ko ? '기능' : 'Features'}</dt>
                  <dd>{row.features.filter(Boolean).join(' · ') || '—'}</dd>
                </div>
                <div>
                  <dt>{ko ? '확인 날짜' : 'Checked'}</dt>
                  <dd>{when(row.checkedAt, locale)}</dd>
                </div>
                <div>
                  <dt>{ko ? '업데이트' : 'Update'}</dt>
                  <dd>{updateLabel(row.update, ko)}</dd>
                </div>
              </dl>
              {row.detail ? <p>{row.detail}</p> : null}
            </article>
          ))}
        </div>
      </aside>
    </>
  )
}
