import { createContext, useContext, useMemo } from 'react'
import type { CatalogItem } from '../engine/appCatalog'
import { useCraftLaunchTiles } from './useCraftLaunchTiles'

export type CatalogHost = 'rail' | 'nested'

export type AppCatalogApi = {
  hidden: boolean
  host: CatalogHost
  open: boolean
  setOpen: (open: boolean) => void
  crmOpen: boolean
  setCrmOpen: (open: boolean) => void
  hint: string
  registerNested: () => () => void
  launch: (item: CatalogItem) => void
}

export const AppCatalogCtx = createContext<AppCatalogApi | null>(null)

export function useAppCatalog() {
  const ctx = useContext(AppCatalogCtx)
  if (!ctx) throw new Error('AppCatalogProvider missing')
  return ctx
}

export function useCatalogNeuState() {
  const tiles = useCraftLaunchTiles()
  return useMemo(() => {
    const pick = (id: 'neu-word' | 'neu-excel' | 'neu-prez') => {
      const tile = tiles.find((row) => row.id === id)
      return { ready: Boolean(tile?.ready), href: tile?.href ?? null }
    }
    return { 'neu-word': pick('neu-word'), 'neu-excel': pick('neu-excel'), 'neu-prez': pick('neu-prez') }
  }, [tiles])
}
