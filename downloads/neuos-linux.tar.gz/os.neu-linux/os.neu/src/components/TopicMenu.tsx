import type { AuthUser } from '../engine/auth'
import {
  addGroup,
  addTopicToGroup,
  findGroup,
  type ConsoleTopic,
  type TalkPack,
} from '../engine/consoleTopics'
import { useI18n } from '../i18n/LocaleContext'
import { useState } from 'react'

type TopicMenuProps = {
  pack: TalkPack
  account: AuthUser | null
  onPack: (next: TalkPack) => void
  onPick: (topic: ConsoleTopic) => void
  onAsk: (topic: ConsoleTopic) => void
  onSignIn: () => void
}

export function TopicMenu({ pack, account, onPack, onPick, onAsk, onSignIn }: TopicMenuProps) {
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [open, setOpen] = useState(false)
  const [addingGroup, setAddingGroup] = useState(false)
  const [addingTalk, setAddingTalk] = useState(false)
  const [groupDraft, setGroupDraft] = useState('')
  const [talkDraft, setTalkDraft] = useState('')
  const group = findGroup(pack, pack.activeGroupId)
  const firstVisit = !pack.customized

  const pickGroup = (id: string) => {
    onPack({ ...pack, activeGroupId: id })
    setAddingGroup(false)
    setAddingTalk(false)
  }

  const createGroup = () => {
    const next = addGroup(pack, groupDraft)
    if (next === pack) return
    setGroupDraft('')
    setAddingGroup(false)
    onPack(next)
  }

  const createTalk = () => {
    const next = addTopicToGroup(pack, group.id, talkDraft)
    if (next === pack) return
    setTalkDraft('')
    setAddingTalk(false)
    onPack(next)
  }

  return (
    <>
      <button
        type="button"
        className={`topic-edge${open ? ' on' : ''}`}
        onClick={() => setOpen((cur) => !cur)}
        aria-expanded={open}
        aria-label={ko ? '대화 주제' : 'Talk topics'}
        title={ko ? '대화 주제' : 'Talk topics'}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
          <path d="M5 6.5h14M5 12h10M5 17.5h12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </button>
      {open ? (
        <button type="button" className="hw-scrim" aria-label={ko ? '닫기' : 'Close'} onClick={() => setOpen(false)} />
      ) : null}
      <aside className={`topic-sheet${open ? ' open' : ''}`} aria-hidden={!open}>
        <div className="topic-sheet-nav">
          <p className="hw-sheet-kicker">{ko ? '상위 목록' : 'Lists'}</p>
          <p className="topic-who">
            {account
              ? account.email
              : ko
                ? '처음 화면 · 손님'
                : 'Default · guest'}
          </p>
          {pack.groups.map((row) => (
            <button
              key={row.id}
              type="button"
              className={row.id === group.id ? 'on' : ''}
              onClick={() => pickGroup(row.id)}
            >
              {ko ? row.title : row.titleEn}
            </button>
          ))}
          <button type="button" className="topic-nav-add" onClick={() => setAddingGroup((cur) => !cur)}>
            {ko ? '상위 목록 추가' : 'Add a list'}
          </button>
          {addingGroup ? (
            <form
              className="topic-add-form topic-nav-form"
              onSubmit={(e) => {
                e.preventDefault()
                createGroup()
              }}
            >
              <input
                value={groupDraft}
                onChange={(e) => setGroupDraft(e.target.value)}
                placeholder={ko ? '목록 이름' : 'List name'}
                aria-label={ko ? '목록 이름' : 'List name'}
                autoFocus
              />
              <button type="submit">{ko ? '만들기' : 'Create'}</button>
            </form>
          ) : null}
        </div>
        <div className="hw-sheet-body">
          <header className="hw-sheet-head">
            <h3>{ko ? group.title : group.titleEn}</h3>
            <button type="button" className="exit-x" onClick={() => setOpen(false)} aria-label={ko ? '닫기' : 'Close'}>
              ×
            </button>
          </header>
          {firstVisit ? (
            <div className="topic-default">
              <b>{ko ? '처음 온 화면입니다' : 'This is the default screen'}</b>
              <p>
                {account
                  ? ko
                    ? `${account.email}로 아직 만든 목록이 없어 기본 주제를 보여 줍니다. 상위 목록을 추가하면 이 아이디의 대화가 됩니다.`
                    : `${account.email} has no lists yet, so the default topics are shown. Add a top list to keep talks on this id.`
                  : ko
                    ? '기본 주제로 대화를 시작합니다. 상위 목록을 추가하고, 로그인하면 그 아이디의 최종 리스트가 남습니다.'
                    : 'Start with the default topics. Add a top list, then sign in to keep the final list on that id.'}
              </p>
              {!account ? (
                <button type="button" className="topic-add" onClick={onSignIn}>
                  {ko ? '로그인하고 내 목록 쓰기' : 'Sign in to keep my lists'}
                </button>
              ) : null}
            </div>
          ) : (
            <p className="topic-lead">
              {account
                ? ko
                  ? `${account.email}의 대화 목록입니다.`
                  : `${account.email}’s talk lists.`
                : ko
                  ? '이 기기 손님 목록입니다. 로그인하면 아이디별로 남습니다.'
                  : 'Guest lists on this machine. Sign in to keep them on an id.'}
            </p>
          )}
          <div className="topic-add-bar">
            <button type="button" className="topic-add" onClick={() => setAddingTalk((cur) => !cur)}>
              {ko ? '대화 추가' : 'Add a talk'}
            </button>
          </div>
          {addingTalk ? (
            <form
              className="topic-add-form"
              onSubmit={(e) => {
                e.preventDefault()
                createTalk()
              }}
            >
              <input
                value={talkDraft}
                onChange={(e) => setTalkDraft(e.target.value)}
                placeholder={ko ? '대화 이름' : 'Talk name'}
                aria-label={ko ? '대화 이름' : 'Talk name'}
                autoFocus
              />
              <button type="submit">{ko ? '만들기' : 'Create'}</button>
            </form>
          ) : null}
          {group.topics.length ? (
            <ul className="topic-list">
              {group.topics.map((row) => {
                const title = ko ? row.title : row.titleEn
                const hint = ko ? row.hint : row.hintEn
                const on = row.id === pack.activeTopicId
                return (
                  <li key={row.id}>
                    <article className={`topic-card${on ? ' on' : ''}`}>
                      <button type="button" className="topic-card-main" onClick={() => onPick(row)}>
                        <b>{title}</b>
                        <span>{hint}</span>
                      </button>
                      <button
                        type="button"
                        className="topic-ask"
                        onClick={() => {
                          onAsk(row)
                          setOpen(false)
                        }}
                      >
                        {ko ? '이어서 묻기' : 'Ask this'}
                      </button>
                    </article>
                  </li>
                )
              })}
            </ul>
          ) : (
            <p>{ko ? '이 목록에 아직 대화가 없습니다. 대화 추가로 만드세요.' : 'No talks in this list yet. Tap Add a talk.'}</p>
          )}
        </div>
      </aside>
    </>
  )
}
