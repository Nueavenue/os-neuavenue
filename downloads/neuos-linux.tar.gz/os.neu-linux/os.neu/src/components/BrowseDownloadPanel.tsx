import { groupByDay, type DownloadRecord } from '../engine/browseLedger'

type BrowseDownloadPanelProps = {
  downloads: DownloadRecord[]
  ko: boolean
  locale: string
  electron: boolean
  onOpenFile: (id: string) => void
  onShowFile: (id: string) => void
  onOpenUrl: (url: string) => void
}

function sizeOf(bytes?: number) {
  if (!bytes || bytes < 0) return ''
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 102.4) / 10} KB`
  return `${Math.round(bytes / 104857.6) / 10} MB`
}

export function BrowseDownloadPanel({
  downloads,
  ko,
  locale,
  electron,
  onOpenFile,
  onShowFile,
  onOpenUrl,
}: BrowseDownloadPanelProps) {
  const groups = groupByDay(downloads, locale)

  return (
    <div className="browser-panel">
      <div className="browser-panel-head">
        <b>{ko ? '다운로드' : 'Downloads'}</b>
      </div>
      {!electron ? (
        <p className="dock-hint">
          {ko
            ? '사이트에서 받는 파일은 os.neu 화면에서 열 때 이 패널에 쌓입니다.'
            : 'Files from sites are listed here when you open pages in the os.neu screen.'}
        </p>
      ) : null}
      {groups.length ? (
        groups.map((group) => (
          <section key={group.key} className="browser-day">
            <h4>{group.day}</h4>
            {group.items.map((row) => (
              <div key={row.id} className="browser-row">
                <button
                  type="button"
                  className="browser-row-main"
                  onClick={() => (row.state === 'done' ? onOpenFile(row.id) : onOpenUrl(row.url))}
                >
                  <strong>{row.filename}</strong>
                  <span>
                    {row.state === 'progress'
                      ? ko
                        ? '받는 중'
                        : 'Downloading'
                      : row.state === 'done'
                        ? ko
                          ? '완료'
                          : 'Done'
                        : row.state}
                    {row.bytes ? ` · ${sizeOf(row.received || row.bytes)}` : ''}
                  </span>
                </button>
                {row.state === 'done' ? (
                  <button type="button" className="text-link" onClick={() => onShowFile(row.id)}>
                    {ko ? '폴더' : 'Folder'}
                  </button>
                ) : null}
              </div>
            ))}
          </section>
        ))
      ) : (
        <p className="dock-hint">{ko ? '받은 파일이 아직 없습니다.' : 'No downloads yet.'}</p>
      )}
    </div>
  )
}
