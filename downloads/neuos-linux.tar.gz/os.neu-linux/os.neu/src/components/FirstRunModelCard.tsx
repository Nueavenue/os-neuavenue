import { useI18n } from '../i18n/LocaleContext'

const LATER_KEY = 'os.neu.firstRun.modelLater'

export function firstRunLater(): boolean {
  try {
    return sessionStorage.getItem(LATER_KEY) === '1'
  } catch {
    return false
  }
}

export function markFirstRunLater() {
  try {
    sessionStorage.setItem(LATER_KEY, '1')
  } catch {
    /* private mode */
  }
}

/** Shown when a work starts while no model is turned on (Settings › AI & Usage › Default model empty). */
export function FirstRunModelCard({
  prompt,
  onConnect,
  onLocal,
  onLater,
}: {
  prompt: string
  onConnect: () => void
  onLocal: () => void
  onLater: () => void
}) {
  const { locale } = useI18n()
  const ko = locale === 'ko'

  return (
    <div className="mvp-purpose" role="region" aria-label={ko ? '먼저 AI를 고르세요' : 'Pick your AI first'}>
      <p className="mvp-purpose-q">{ko ? '먼저 AI를 고르세요' : 'Pick your AI first'}</p>
      <p className="mvp-purpose-request">
        {ko
          ? 'os.neu는 사용자가 고른 AI 모델로 일합니다. 아직 켜진 모델이 없어서 초안을 시작할 수 없습니다. 아래에서 한 가지를 고르세요. 1분이면 됩니다.'
          : 'os.neu does the work with an AI model you choose. Nothing is turned on yet, so a draft cannot start. Choose one way below — it takes about a minute.'}
      </p>
      <p className="mvp-purpose-label">{ko ? '요청 (그대로 남습니다)' : 'Your request (kept)'}</p>
      <p className="mvp-purpose-request">{prompt}</p>
      <div className="mvp-purpose-plan">
        <ol>
          <li>
            <strong>{ko ? '내 클라우드 키 쓰기' : 'Use my cloud key'}</strong>
            {ko
              ? ' — OpenAI, Anthropic, Google 등에서 받은 키가 있을 때. 초안이 가장 빠릅니다.'
              : ' — you have a key from OpenAI, Anthropic, Google, or another vendor. Fastest drafts.'}
          </li>
          <li>
            <strong>{ko ? '이 PC에서 모델 돌리기' : 'Run a model on this PC'}</strong>
            {ko
              ? ' — 키 없이, 오프라인 가능. 일반 CPU에서는 느립니다. 짧은 작업에 알맞습니다.'
              : ' — no key, works offline. Slower on a normal CPU; best for short tasks.'}
          </li>
        </ol>
      </div>
      <p className="settings-note">
        {ko
          ? '키는 이 기기에만 저장됩니다. 저장한 뒤에는 다시 화면에 보이지 않고, 기록에도 남지 않습니다.'
          : 'Your key stays on this device. os.neu never shows it again after you save it, and never puts it in logs.'}
      </p>
      <div className="mvp-purpose-actions">
        <button type="button" onClick={onLater}>
          {ko ? '나중에' : 'Later'}
        </button>
        <button type="button" onClick={onLocal}>
          {ko ? '로컬 모델 쓰기' : 'Use a local model'}
        </button>
        <button type="button" className="primary" onClick={onConnect}>
          {ko ? '키 연결하기' : 'Connect a key'}
        </button>
      </div>
    </div>
  )
}
