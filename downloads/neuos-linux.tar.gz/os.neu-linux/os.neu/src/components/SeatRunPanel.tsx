import { useEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { SeatStepCard } from './SeatStepCard'
import { createPromptDraft, loadDocProjects, upsertDocProject } from '../engine/docProjects'
import { bindSeatAbort, bindSeatListener, type SeatAsk } from '../engine/seatBus'
import { firstTextWaitMs, seatErrorKo, streamSeatWrite } from '../engine/seatClient'
import { finishSeat, prepareSeat, releaseGate, type SeatPrepared, type SeatStep } from '../engine/seatRun'
import { officeSurface } from '../engine/intents'
import { composeSeatInstruction, fetchPromptSearch } from '../engine/promptSearch'
import { stagePromptSlides } from '../engine/slidesPrompt'
import { writerBodyOnly } from '../engine/craftConvert'
import { detectCraftBins, type CraftBins } from '../engine/craftDetect'
import { craftHintLine, planCraftJob, type CraftJob } from '../engine/craftPlan'
import { craftUserLine } from '../engine/craftUserLine'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'
import { readyUiSessionHeaders } from '../engine/uiSession'

function saveSeatFile(
  ask: SeatAsk,
  prepared: SeatPrepared,
  body: string,
  fileId: string | null,
  done: boolean,
): { title: string; id: string } {
  const full = writerBodyOnly(body)
  const title = (prepared.request.slice(0, 42) || 'Seat').replace(/\s+/g, ' ')
  const rows = loadDocProjects()
  const wantId = fileId || ask.fileId
  const existing = wantId ? rows.find((row) => row.id === wantId && row.kind === 'doc') : undefined
  const persist = (id: string) => {
    try {
      sessionStorage.setItem('os.neu.seat.file', id)
    } catch {
      /* private mode */
    }
    window.dispatchEvent(new CustomEvent('osneu-seat-file', { detail: { id, title, done, body: full } }))
  }
  if (existing) {
    upsertDocProject(rows, { ...existing, title, name: title, body: full, updated: Date.now() })
    persist(existing.id)
    return { title, id: existing.id }
  }
  const { node } = createPromptDraft(rows, prepared.request || title)
  const again = loadDocProjects()
  const saved = again.find((row) => row.id === node.id)
  if (saved) upsertDocProject(again, { ...saved, title, name: title, body: full, updated: Date.now() })
  persist(node.id)
  return { title, id: node.id }
}

function HomeConsolePortal({ children }: { children: ReactNode }) {
  const [node, setNode] = useState<HTMLElement | null>(() =>
    typeof document === 'undefined' ? null : document.getElementById('osneu-home-console'),
  )
  useEffect(() => {
    const read = () => setNode(document.getElementById('osneu-home-console'))
    read()
    const timer = window.setInterval(read, 200)
    return () => window.clearInterval(timer)
  }, [])
  if (!node) return null
  return createPortal(children, node)
}

export function SeatRunPanel() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [ask, setAsk] = useState<SeatAsk | null>(null)
  const [prepared, setPrepared] = useState<SeatPrepared | null>(null)
  const [steps, setSteps] = useState<SeatStep[]>([])
  const [output, setOutput] = useState('')
  const [docked, setDocked] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [craftJob, setCraftJob] = useState<CraftJob | null>(null)
  const [writing, setWriting] = useState(false)
  const abortRef = useRef<AbortController | null>(null)
  const askRef = useRef<SeatAsk | null>(null)
  const preparedRef = useRef<SeatPrepared | null>(null)
  const outputRef = useRef('')
  const streamTurnIdRef = useRef('')
  const dumpAtRef = useRef(0)
  const fileAtRef = useRef(0)
  const writingRef = useRef(false)
  const followSurfaceRef = useRef<'doc' | 'sheet' | 'slides' | null>(null)
  const fileIdRef = useRef<string | null>(null)
  const craftGenRef = useRef(0)
  const beginChatRef = useRef(neu.beginChat)
  const patchChatRef = useRef(neu.patchChat)
  const openOfficeRef = useRef(neu.openOffice)
  beginChatRef.current = neu.beginChat
  patchChatRef.current = neu.patchChat
  openOfficeRef.current = neu.openOffice

  const publishConsole = (body: string, done: boolean, force = false) => {
    if (followSurfaceRef.current) return
    const turnId = streamTurnIdRef.current
    if (!turnId) return
    const now = Date.now()
    if (!done && !force && now - dumpAtRef.current < 80) return
    dumpAtRef.current = now
    const text = writerBodyOnly(body)
    patchChatRef.current(turnId, {
      text: text || (done ? (ko ? '출력이 비어 있습니다.' : 'No output yet.') : ''),
      pending: !done && !text,
      typing: false,
    })
  }

  const publishFile = (body: string, done: boolean, force = false) => {
    const currentAsk = askRef.current
    const currentPrepared = preparedRef.current
    if (!currentAsk || !currentPrepared) return
    const now = Date.now()
    if (!force && !done && now - fileAtRef.current < 80) return
    fileAtRef.current = now
    const saved = saveSeatFile(currentAsk, currentPrepared, body, fileIdRef.current, done)
    fileIdRef.current = saved.id
    askRef.current = { ...currentAsk, fileId: saved.id }
  }

  const publishOffice = (body: string, done: boolean, force = false) => {
    const surface = followSurfaceRef.current
    if (!surface) return
    if (surface === 'doc') {
      publishFile(body, done, force)
      return
    }
    const now = Date.now()
    if (!force && !done && now - fileAtRef.current < 80) return
    fileAtRef.current = now
    const title = (askRef.current?.text || 'Seat').slice(0, 42).replace(/\s+/g, ' ')
    const name = surface === 'sheet' ? 'osneu-seat-sheet' : 'osneu-seat-slides'
    window.dispatchEvent(
      new CustomEvent(name, { detail: { title, body: writerBodyOnly(body), done } }),
    )
  }

  const publishCraftPath = (craftPath: string) => {
    const surface = followSurfaceRef.current
    if (!surface || !craftPath) return
    const title = (askRef.current?.text || 'Seat').slice(0, 42).replace(/\s+/g, ' ')
    if (surface === 'doc') {
      window.dispatchEvent(
        new CustomEvent('osneu-seat-file', {
          detail: { id: fileIdRef.current, title, done: true, craftPath },
        }),
      )
      return
    }
    const name = surface === 'sheet' ? 'osneu-seat-sheet' : 'osneu-seat-slides'
    window.dispatchEvent(
      new CustomEvent(name, {
        detail: { title, body: writerBodyOnly(outputRef.current), done: true, craftPath },
      }),
    )
  }

  const runWrite = async (currentAsk: SeatAsk, current: SeatPrepared) => {
    abortRef.current?.abort()
    const ctrl = new AbortController()
    abortRef.current = ctrl
    writingRef.current = true
    setWriting(true)
    if (!followSurfaceRef.current && !streamTurnIdRef.current) {
      streamTurnIdRef.current = beginChatRef.current('neu')
    }
    let timedOut = false
    const timer = window.setTimeout(() => {
      timedOut = true
      ctrl.abort()
    }, 300_000)
    setSteps((rows) => rows.map((row) => (row.n === 6 ? { ...row, status: 'running', detail: 'Writer가 글을 쓰는 중입니다.' } : row)))
    const officeApp = followSurfaceRef.current
    if (officeApp) {
      try {
        const readyRes = await fetch('/api/llm/ready', { signal: AbortSignal.timeout(4000) })
        const ready = (await readyRes.json()) as { ok?: boolean }
        if (!ready.ok) {
          window.clearTimeout(timer)
          writingRef.current = false
          setWriting(false)
          const reason = seatErrorKo('no-llm', ko)
          const done = finishSeat(current, { body: reason, modelError: reason })
          setSteps(done)
          setOutput(reason)
          outputRef.current = reason
          publishConsole(reason, true, true)
          publishOffice(reason, true, true)
          return
        }
      } catch {
        /* streamSeatWrite will surface the same fail */
      }
    }
    const pack = officeApp ? null : await fetchPromptSearch(current.request)
    const instruction = officeApp ? current.request : composeSeatInstruction(current.request, pack)
    let sawToken = false
    const waitMs = firstTextWaitMs(currentAsk.model)
    const firstTimer = window.setTimeout(() => {
      if (!sawToken) ctrl.abort()
    }, waitMs)
    const result = await streamSeatWrite(
      currentAsk.model,
      instruction,
      (full) => {
        if (full.trim()) sawToken = true
        outputRef.current = full
        setOutput(full)
        publishConsole(full, false)
        if (followSurfaceRef.current) publishOffice(full, false)
      },
      ctrl.signal,
      { app: officeApp, title: current.request },
    )
    window.clearTimeout(firstTimer)
    window.clearTimeout(timer)
    writingRef.current = false
    setWriting(false)
    if (ctrl.signal.aborted && abortRef.current !== ctrl) return
    const userStopped = result.reason === 'aborted'
    const firstStuck = !userStopped && ctrl.signal.aborted && !sawToken && abortRef.current === ctrl
    const reason = result.ok
      ? undefined
      : seatErrorKo(
          timedOut ? 'timeout' : userStopped ? 'aborted' : firstStuck ? 'first-token-timeout' : result.reason || '',
          ko,
          Math.round(waitMs / 1000),
        )
    const bodyOut = result.text.trim() && !userStopped ? result.text : reason || result.text
    const done = finishSeat(current, { body: bodyOut, modelError: result.ok ? undefined : reason })
    setSteps(done)
    setOutput(bodyOut)
    outputRef.current = bodyOut
    publishConsole(bodyOut, true, true)
    if (followSurfaceRef.current) publishOffice(bodyOut, true, true)
    void planCraftAfterWrite()
  }

  const planCraftAfterWrite = async () => {
    if (writingRef.current) return
    const surface = officeSurface(askRef.current?.text || '')
    if (!surface) {
      setCraftJob(null)
      return
    }
    const gen = craftGenRef.current
    let bins: CraftBins = detectCraftBins({})
    try {
      const res = await fetch('/api/craft/detect', { signal: AbortSignal.timeout(800) })
      if (res.ok) {
        const data = (await res.json()) as { wordcraft?: string | null; gridcraft?: string | null; deckcraft?: string | null }
        bins = detectCraftBins({
          'wordcraft-cli': data.wordcraft,
          'gridcraft-cli': data.gridcraft,
          'deckcraft-cli': data.deckcraft,
        })
      }
    } catch {
      bins = detectCraftBins({})
    }
    if (craftGenRef.current !== gen || writingRef.current) return
    let next = planCraftJob(surface, bins)
    setCraftJob(next)
    if (next.reason === 'cli-ready' && next.surface && !writingRef.current) {
      try {
        const res = await fetch('/api/craft/convert', {
          method: 'POST',
          headers: await readyUiSessionHeaders(),
          body: JSON.stringify({
            surface: next.surface,
            title: askRef.current?.text || 'Seat',
            body: outputRef.current,
          }),
          signal: AbortSignal.timeout(32_000),
        })
        const data = (await res.json()) as { converted?: boolean; reason?: string; path?: string }
        if (craftGenRef.current !== gen || writingRef.current) return
        if (data.converted && data.path) {
          next = { ...next, status: 'converted', reason: 'converted', outPath: data.path }
          publishCraftPath(data.path)
        } else {
          next = { ...next, status: 'convert-failed', reason: 'convert-failed' }
        }
      } catch {
        if (craftGenRef.current !== gen) return
        next = { ...next, status: 'convert-failed', reason: 'convert-failed' }
      }
      setCraftJob(next)
    }
    if (writingRef.current || craftGenRef.current !== gen) return
    if (next.reason === 'cli-ready' || next.reason === 'converted' || next.reason === 'convert-failed') {
      try {
        const res = await fetch('/api/craft/mcp', {
          method: 'POST',
          headers: await readyUiSessionHeaders(),
          body: JSON.stringify({ action: 'ping' }),
          signal: AbortSignal.timeout(9_000),
        })
        const data = (await res.json()) as { mcp?: boolean }
        if (craftGenRef.current !== gen) return
        next = { ...next, mcp: data.mcp ? 'ping-ok' : 'skip' }
      } catch {
        if (craftGenRef.current !== gen) return
        next = { ...next, mcp: 'skip' }
      }
    } else {
      next = { ...next, mcp: 'skip' }
    }
    setCraftJob(next)
    try {
      const res = await fetch('/api/craft/web', { signal: AbortSignal.timeout(800) })
      const data = (await res.json()) as { present?: boolean; href?: string }
      if (craftGenRef.current !== gen) return
      next = {
        ...next,
        web: data.present && data.href ? 'ready' : 'missing',
        webHref: data.present && data.href ? data.href : null,
      }
    } catch {
      if (craftGenRef.current !== gen) return
      next = { ...next, web: 'missing', webHref: null }
    }
    setCraftJob(next)
  }

  const stopWrite = () => {
    abortRef.current?.abort()
    writingRef.current = false
    setWriting(false)
    const msg = seatErrorKo('aborted', ko)
    setOutput(msg)
    outputRef.current = msg
    if (followSurfaceRef.current) publishOffice(msg, true, true)
    else publishConsole(msg, true, true)
  }

  useEffect(() => {
    const unbindAbort = bindSeatAbort(stopWrite)
    const unbind = bindSeatListener((next) => {
      abortRef.current?.abort()
      if (streamTurnIdRef.current && !followSurfaceRef.current && outputRef.current) {
        patchChatRef.current(streamTurnIdRef.current, {
          text: writerBodyOnly(outputRef.current),
          pending: false,
          typing: false,
        })
      }
      const preparedNext = prepareSeat({
        text: next.text,
        model: next.model,
        account: next.account,
        phase: next.phase,
        online: next.online,
        webHref: next.webHref,
      })
      askRef.current = next
      preparedRef.current = preparedNext
      outputRef.current = ''
      streamTurnIdRef.current = ''
      followSurfaceRef.current = null
      fileIdRef.current = next.fileId
      craftGenRef.current += 1
      setAsk(next)
      setPrepared(preparedNext)
      setSteps(preparedNext.steps)
      setOutput('')
      setCraftJob(null)
      const surface = officeSurface(next.text)
      if (surface) {
        followSurfaceRef.current = surface
        setDocked(false)
        setExpanded(false)
        if (surface === 'slides') stagePromptSlides(next.text)
        if (surface === 'doc') publishFile('', false, true)
        else publishOffice('', false, true)
        if (!preparedNext.gate && preparedNext.steps[0]?.status !== 'fail') void runWrite(next, preparedNext)
        openOfficeRef.current(surface)
        return
      }
      setDocked(true)
      setExpanded(preparedNext.gate === 'send')
      if (preparedNext.steps[0]?.status === 'fail') return
      if (preparedNext.gate === 'send') return
      if (preparedNext.gate === 'web') {
        const released = releaseGate(preparedNext, 'draft')
        preparedRef.current = released
        setPrepared(released)
        setSteps(released.steps)
        void runWrite(next, released)
        return
      }
      void runWrite(next, preparedNext)
    })
    return () => {
      unbindAbort()
      unbind()
      abortRef.current?.abort()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const choose = (choice: 'draft' | 'open-url' | 'stop') => {
    const currentAsk = askRef.current
    const current = preparedRef.current
    if (!currentAsk || !current) return
    const released = releaseGate(current, choice)
    preparedRef.current = released
    setPrepared(released)
    setSteps(released.steps)
    if (choice === 'open-url' && current.webHref) neu.openWeb(current.webHref)
    if (choice === 'stop') {
      setSteps(finishSeat(released, { body: '' }))
      return
    }
    void runWrite(currentAsk, released)
  }

  const hint = craftJob ? craftUserLine(craftJob, ko) : ''
  const diagnostics = craftJob ? craftHintLine(craftJob, ko) : ''
  const openCraftWeb = () => {
    const href = craftJob?.webHref
    if (!href || craftJob?.web !== 'ready') return
    neu.openWeb(href)
  }
  const hintNode = hint ? (
    craftJob?.web === 'ready' && craftJob.webHref ? (
      <button type="button" className="seat-craft-web" onClick={openCraftWeb} title={diagnostics}>
        {hint}
      </button>
    ) : (
      <span title={diagnostics}>{hint}</span>
    )
  ) : null

  if (docked && prepared) {
    return (
      <HomeConsolePortal>
        <SeatStepCard
          steps={steps}
          output={output}
          gate={prepared.gate}
          ko={ko}
          expanded={expanded}
          onToggle={() => setExpanded((on) => !on)}
          onChoose={prepared.gate ? choose : undefined}
          canOpenUrl={Boolean(ask?.webHref)}
          hint={hintNode}
          writing={writing}
          onStopWrite={stopWrite}
        />
      </HomeConsolePortal>
    )
  }

  if (!hintNode) return null
  return (
    <p className="seat-craft-hint" role="status">
      {hintNode}
    </p>
  )
}
