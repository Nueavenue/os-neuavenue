import { useEffect, useMemo, useRef, useState } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import {
  addOfficeItem,
  loadOfficeList,
  removeOfficeItem,
  upsertOfficeItem,
  type OfficeListItem,
} from '../../engine/officeList'
import { applySheetSeatBody, emptySheetGrid } from '../../engine/sheetGrid'
import { abortSeatRun } from '../../engine/seatBus'
import { seatErrorKo } from '../../engine/seatClient'
import { onOpenArtifact, saveArtifact } from '../../engine/workspaceLog'
import { useI18n } from '../../i18n/LocaleContext'
import { useNeu } from '../../state/neuContext'

const COLS = ['A', 'B', 'C', 'D', 'E', 'F']
const DEFAULTS = { name: 'Untitled', title: 'Untitled spreadsheet' }

type SheetPayload = { grid: string[][] }
type SheetFile = OfficeListItem<SheetPayload>

function blankPayload(): SheetPayload {
  return { grid: emptySheetGrid() }
}

export function SheetApp() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const defaults = ko
    ? { name: '새 시트', title: '새 스프레드시트' }
    : DEFAULTS

  const [boot] = useState(() => loadOfficeList<SheetPayload>('sheet', blankPayload, defaults))
  const [files, setFiles] = useState<SheetFile[]>(boot)
  const [activeId, setActiveId] = useState(boot[0]?.id || '')
  const filesRef = useRef(files)
  const activeIdRef = useRef(activeId)
  filesRef.current = files
  activeIdRef.current = activeId

  const active = files.find((row) => row.id === activeId) || files[0]
  const [title, setTitle] = useState(active?.title || defaults.title)
  const [grid, setGrid] = useState<string[][]>(active?.payload.grid || emptySheetGrid())
  const [saved, setSaved] = useState(true)
  const [busy, setBusy] = useState(false)
  const [hint, setHint] = useState('')
  const [waitSec, setWaitSec] = useState(0)
  const [firstToken, setFirstToken] = useState(false)
  const firstTokenRef = useRef(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [railOpen, setRailOpen] = useState(true)
  const renameRef = useRef<HTMLInputElement>(null)
  const artifactIdRef = useRef<string | null>(null)

  const commitActive = (nextTitle: string, nextGrid: string[][]) => {
    const id = activeIdRef.current
    const cur = filesRef.current.find((row) => row.id === id)
    if (!cur) return
    const neat = nextTitle.trim() || cur.title
    const list = upsertOfficeItem('sheet', filesRef.current, {
      ...cur,
      name: neat,
      title: neat,
      updated: Date.now(),
      payload: { grid: nextGrid },
    })
    filesRef.current = list
    setFiles(list)
  }

  const openFile = (id: string) => {
    commitActive(title, grid)
    const row = filesRef.current.find((item) => item.id === id)
    if (!row) return
    setActiveId(row.id)
    activeIdRef.current = row.id
    setTitle(row.title)
    setGrid(row.payload.grid?.length ? row.payload.grid : emptySheetGrid())
    setSaved(true)
    setHint('')
    artifactIdRef.current = null
  }

  const addFile = () => {
    setRailOpen(true)
    commitActive(title, grid)
    const { rows, node } = addOfficeItem('sheet', filesRef.current, {
      name: ko ? '새 시트' : 'New sheet',
      title: ko ? '새 스프레드시트' : 'Untitled spreadsheet',
      payload: blankPayload(),
    })
    filesRef.current = rows
    setFiles(rows)
    setActiveId(node.id)
    activeIdRef.current = node.id
    setTitle(node.title)
    setGrid(node.payload.grid)
    setSaved(false)
    artifactIdRef.current = null
    setHint(ko ? '새 시트를 만들었습니다. 저장을 눌러 남기세요.' : 'New sheet created. Press Save to keep it.')
  }

  const commitRename = (id: string) => {
    const next = editName.trim()
    setEditingId(null)
    if (!next) return
    const cur = filesRef.current.find((row) => row.id === id)
    if (!cur || cur.name === next) return
    const list = upsertOfficeItem('sheet', filesRef.current, {
      ...cur,
      name: next,
      title: next,
      updated: Date.now(),
    })
    filesRef.current = list
    setFiles(list)
    if (id === activeIdRef.current) {
      setTitle(next)
      setSaved(false)
    }
  }

  const deleteFile = (id: string) => {
    if (id === activeIdRef.current) commitActive(title, grid)
    const list = removeOfficeItem('sheet', filesRef.current, id, blankPayload, defaults)
    filesRef.current = list
    setFiles(list)
    const next = list.find((row) => row.id === activeIdRef.current) || list[0]
    setActiveId(next.id)
    activeIdRef.current = next.id
    setTitle(next.title)
    setGrid(next.payload.grid?.length ? next.payload.grid : emptySheetGrid())
    setSaved(true)
  }

  useEffect(
    () =>
      onOpenArtifact('sheet', (row) => {
        const payload = (row.payload || {}) as { grid?: string[][] }
        const gridPayload = Array.isArray(payload.grid) && payload.grid.length ? payload.grid : emptySheetGrid()
        commitActive(title, grid)
        const { rows, node } = addOfficeItem('sheet', filesRef.current, {
          name: row.title || defaults.name,
          title: row.title || defaults.title,
          payload: { grid: gridPayload },
        })
        filesRef.current = rows
        setFiles(rows)
        setActiveId(node.id)
        activeIdRef.current = node.id
        artifactIdRef.current = row.id
        setTitle(row.title)
        setGrid(gridPayload)
        setSaved(true)
        setHint('')
        setRailOpen(true)
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- open once; live title/grid read from refs at click time
    [],
  )

  const save = async () => {
    commitActive(title, grid)
    setSaved(true)
    try {
      const row = await saveArtifact('sheet', title, { grid }, artifactIdRef.current)
      artifactIdRef.current = row.id
      setHint(ko ? '이 기기에 저장했습니다.' : 'Saved on this device.')
    } catch {
      setHint(ko ? '목록에는 저장됐습니다. My Work 동기화는 다시 눌러 주세요.' : 'Kept in the list. Tap Save again to sync My Work.')
    }
  }

  useEffect(() => {
    if (!busy) {
      setWaitSec(0)
      return
    }
    setWaitSec(0)
    setFirstToken(false)
    firstTokenRef.current = false
    const tick = window.setInterval(() => setWaitSec((n) => n + 1), 1000)
    return () => window.clearInterval(tick)
  }, [busy])

  useEffect(() => {
    const writingHint = ko ? '작성 중… 첫 행이 이 표에 붙습니다.' : 'Writing… the first rows appear in this grid.'
    const emptyHint = ko ? '작성이 비었습니다. AI 연결을 확인하세요.' : 'Draft is empty. Check Connect AI.'

    const applySeat = (body: string | undefined, done?: boolean) => {
      const raw = typeof body === 'string' ? body : ''
      if (!done && !raw.trim()) {
        setBusy((was) => was || true)
        setHint(writingHint)
        setGrid(applySheetSeatBody(writingHint))
        setSaved(false)
        return
      }
      setGrid(applySheetSeatBody(raw.trim() ? raw : emptyHint))
      if (raw.trim()) {
        firstTokenRef.current = true
        setFirstToken(true)
        setHint('')
      } else {
        setHint(emptyHint)
      }
      if (done) {
        setBusy(false)
        setSaved(true)
      } else {
        setBusy((was) => was || true)
        setSaved(false)
      }
    }

    const onSeat = (ev: Event) => {
      const detail = (ev as CustomEvent<{ title?: string; body?: string; done?: boolean }>).detail
      if (!detail) return
      if (detail.title) setTitle(detail.title)
      applySeat(detail.body, detail.done)
    }
    window.addEventListener('osneu-seat-sheet', onSeat)
    return () => window.removeEventListener('osneu-seat-sheet', onSeat)
  }, [ko])

  useEffect(() => {
    if (saved) return
    const t = window.setTimeout(() => commitActive(title, grid), 400)
    return () => window.clearTimeout(t)
  }, [title, grid, saved])

  const tsv = useMemo(() => grid.map((row) => row.join('\t')).join('\n'), [grid])

  const setCell = (r: number, c: number, value: string) => {
    setGrid((rows) => rows.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? value : cell)) : row)))
    setSaved(false)
  }

  return (
    <div className={`sheet-shell${railOpen ? '' : ' rail-collapsed'}`}>
      <aside className="doc-rail" aria-label={ko ? '스프레드시트 목록' : 'Spreadsheets'}>
        <div className="doc-rail-head">
          <button type="button" className="icon-btn" onClick={() => setRailOpen((v) => !v)} aria-expanded={railOpen}>
            {railOpen ? '‹' : '☰'}
          </button>
          {railOpen ? <b>{ko ? '시트' : 'Sheets'}</b> : null}
          <div className="doc-rail-adds">
            <button type="button" className="doc-rail-add" onClick={addFile} title={ko ? '새 시트' : 'New sheet'}>
              +
            </button>
          </div>
        </div>
        {railOpen ? (
          <ul className="doc-rail-list">
            {files.map((row) => (
              <li key={row.id} className={row.id === activeId ? 'on' : ''}>
                <button type="button" className="doc-rail-item" onClick={() => openFile(row.id)}>
                  <span className="doc-rail-folder" aria-hidden>
                    ·
                  </span>
                  {editingId === row.id ? (
                    <input
                      ref={renameRef}
                      className="doc-rail-rename"
                      value={editName}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setEditName(e.target.value)}
                      onBlur={() => commitRename(row.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          commitRename(row.id)
                        }
                        if (e.key === 'Escape') {
                          e.preventDefault()
                          setEditingId(null)
                        }
                      }}
                    />
                  ) : (
                    <span>{row.name}</span>
                  )}
                </button>
                <div className="doc-rail-actions">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      setEditingId(row.id)
                      setEditName(row.name)
                      window.requestAnimationFrame(() => renameRef.current?.focus())
                    }}
                    title={ko ? '이름' : 'Rename'}
                  >
                    ✎
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteFile(row.id)
                    }}
                    title={ko ? '삭제' : 'Delete'}
                  >
                    ×
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : null}
      </aside>

      <div className="sheet-main">
        <AppToolbar
          title={title}
          saved={saved}
          onSave={() => void save()}
          onAssist={async (instruction) => {
            const result = await assistOffice({
              model: neu.officeModel,
              app: 'sheet',
              instruction,
              content: `${title}\n${tsv}`,
            })
            if (result.ok && result.text) {
              const lines = result.text.split('\n')
              const maybeTitle = lines[0]?.startsWith('#') ? lines.shift() : ''
              if (maybeTitle) {
                const neat = maybeTitle.replace(/^#+\s*/, '')
                setTitle(neat)
              }
              setGrid(applySheetSeatBody(lines.join('\n')))
              setSaved(false)
              setHint('')
              return
            }
            const reason = seatErrorKo(result.reason || '', ko)
            setGrid(applySheetSeatBody(reason))
            setHint(reason)
          }}
          extra={
            <button type="button" className="icon-btn" title={ko ? '새 시트' : 'New sheet'} onClick={addFile}>
              +
            </button>
          }
        />
        <div className="sheet-head-row">
          <input
            className="sheet-name"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value)
              setSaved(false)
            }}
            aria-label="Sheet title"
          />
        </div>
        {busy ? (
          <div className="doc-ai-loading sheet-status" role="status" aria-live="polite">
            <span className="doc-ai-spinner" aria-hidden />
            <div>
              <strong>
                {firstToken
                  ? ko
                    ? 'AI가 타이핑 중…'
                    : 'AI is typing…'
                  : ko
                    ? 'AI 로딩 중…'
                    : 'AI loading…'}
              </strong>
              <p>
                {ko
                  ? `경과 ${waitSec}초 · 멈추려면 Stop을 누르세요.`
                  : `${waitSec}s elapsed · press Stop to disconnect this run.`}
              </p>
            <button
              type="button"
              className="btn ghost"
              onClick={() => {
                abortSeatRun()
                setBusy(false)
                setHint(ko ? 'AI를 멈췄습니다.' : 'AI stopped.')
              }}
            >
              {ko ? '멈추기' : 'Stop'}
            </button>
            </div>
          </div>
        ) : hint ? (
          <p className="dock-hint sheet-status">{hint}</p>
        ) : null}
        <div className="sheet-grid live" data-ui="grid" aria-label="Sheet grid">
          <div className="cell head" />
          {COLS.map((col) => (
            <div key={col} className="cell head">
              {col}
            </div>
          ))}
          {grid.map((row, r) => (
            <div key={r} style={{ display: 'contents' }}>
              <div className="cell head">{r + 1}</div>
              {row.map((value, c) => (
                <input
                  key={`${r}-${c}`}
                  className="cell input"
                  data-ui={r === 0 && c === 0 ? 'cell-0-0' : `cell-${r}-${c}`}
                  value={value}
                  onChange={(e) => setCell(r, c, e.target.value)}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
