import { useMemo, useState } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import { useNeu } from '../../state/store'

const COLS = ['A', 'B', 'C', 'D', 'E', 'F']
const ROWS = 12

function emptyGrid() {
  return Array.from({ length: ROWS }, () => Array.from({ length: COLS.length }, () => ''))
}

function parseTsv(text: string) {
  const grid = emptyGrid()
  const lines = text.trim().split(/\n/)
  lines.forEach((line, r) => {
    line.split(/\t|,/).forEach((cell, c) => {
      if (grid[r] && c < COLS.length) grid[r][c] = cell.trim()
    })
  })
  return grid
}

export function SheetApp() {
  const neu = useNeu()
  const [title, setTitle] = useState('Untitled spreadsheet')
  const [grid, setGrid] = useState<string[][]>(emptyGrid)
  const [saved, setSaved] = useState(false)

  const tsv = useMemo(() => grid.map((row) => row.join('\t')).join('\n'), [grid])

  const setCell = (r: number, c: number, value: string) => {
    setGrid((rows) => rows.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? value : cell)) : row)))
    setSaved(false)
  }

  return (
    <div className="sheet">
      <AppToolbar
        title={title}
        saved={saved}
        onSave={() => setSaved(true)}
        onAssist={async (instruction) => {
          const result = await assistOffice({
            model: neu.officeModel,
            app: 'sheet',
            instruction,
            content: `${title}\n${tsv}`,
          })
          if (result.ok && result.text) {
            const lines = result.text.split('\n')
            const maybeTitle = lines[0]?.startsWith('#') ? lines.shift() : ''
            if (maybeTitle) setTitle(maybeTitle.replace(/^#+\s*/, ''))
            setGrid(parseTsv(lines.join('\n')))
          }
        }}
      />
      <input className="sheet-name" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="Sheet title" />
      <div className="sheet-grid live" data-ui="grid" aria-label="Sheet grid">
        <div className="cell head" />
        {COLS.map((col) => (
          <div key={col} className="cell head">
            {col}
          </div>
        ))}
        {grid.map((row, r) => (
          <div key={r} style={{ display: 'contents' }}>
            <div className="cell head">{r + 1}</div>
            {row.map((value, c) => (
              <input
                key={`${r}-${c}`}
                className="cell input"
                data-ui={r === 0 && c === 0 ? 'cell-0-0' : `cell-${r}-${c}`}
                value={value}
                onChange={(e) => setCell(r, c, e.target.value)}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
