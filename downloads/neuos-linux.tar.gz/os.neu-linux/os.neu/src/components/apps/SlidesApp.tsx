import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import { useNeu } from '../../state/neuContext'
import { useI18n } from '../../i18n/LocaleContext'
import {
  MAX_BULLETS,
  bulletsFromBody,
  parseAssistText,
  serializeRecipe,
  type RecipeSlide,
  type SlideLayout,
} from '../../engine/slidesRecipe'
import { exportSlidesToPptx, savePptxFile } from '../../engine/pptxExport'
import { PRESENTATION_TEMPLATES, getTemplateById, type PresentationTemplate } from '../../engine/presentationTemplates'
import {
  applyPromptToPlannedSlides,
  defaultSlideCount,
  planSlidesFromTemplate,
  parseRequestedSlideCount,
} from '../../engine/generationPlanner'
import {
  phaseAfterEditorExport,
  phaseAfterExportBack,
  phaseAfterGalleryCardUse,
  phaseAfterPreviewPrompt,
  phaseAfterPromptContinue,
  phaseAfterStoryboardConfirm,
  type StudioPhase,
} from '../../engine/studioPhase'
import { pushRecentTemplate } from '../../engine/pptStudioStorage'
import { themeForEditor, themeToCssVars, themeToPptxHints } from '../../engine/presentationThemes'
import { takePromptSlides } from '../../engine/slidesPrompt'
import { recommendTemplates } from '../../engine/templateRecommend'
import { setTemplateLocation, templateIdFromLocation } from '../../engine/slidesStudioRoute'
import { setPromptSlidesTemplate } from '../../engine/promptTags'
import { TemplateGalleryHome, type GalleryView } from './ppt-studio/TemplateGalleryHome'
import { TemplatePreviewScreen } from './ppt-studio/TemplatePreviewScreen'
import { TemplatePromptSettings } from './ppt-studio/TemplatePromptStub'
import { TemplateStoryboardScreen } from './ppt-studio/TemplateStoryboardScreen'
import { ExportHubScreen } from './ppt-studio/ExportHubScreen'
import { OverflowWarning } from './ppt-studio/OverflowWarning'
import { DeckProgress, SlideLayoutFrame } from './ppt-studio/SlideLayoutFrame'
import { StudioAgentPanel, type PanelAction } from './ppt-studio/StudioAgentPanel'
import { generationChangeSet } from '../../engine/generationPath'
import { bulletsToComparisonTable, stampLayout, type DeckStage } from '../../engine/slidesLayoutEngine'
import {
  addOnSelected,
  agentFailMessage,
  agentInstruction,
  deleteSelected,
  historyLine,
  parseElementReply,
  parseSlideReply,
  selectedText,
  type AgentScope,
  type SlideElementSel,
} from '../../engine/slideAgentEdit'
import {
  applyChangeSet,
  canApply,
  historyLabel,
  proposeCreateSlide,
  proposeDeckRewrite,
  proposeDeleteSlides,
  proposeDuplicateSlide,
  proposeElementEdit,
  proposeMergeSlides,
  proposeMoveSlide,
  proposeQaFix,
  proposeSlideReplace,
  proposeUnavailable,
  proposeVerifyFact,
  qaSummaryText,
  railStatus,
  rejectChangeSet,
  restoreVersion,
  redoVersion,
  runQa,
  snapshotVersion,
  undoVersion,
  withDeckConfirm,
  type ChangeSet,
  type QaCheckId,
  type QaFinding,
  type SessionVersion,
} from '../../engine/slideChangeSet'
import { fitSlide } from '../../engine/contentFitter'
import {
  addOfficeItem,
  bootOfficeList,
  recallOfficeActive,
  rememberOfficeActive,
  removeOfficeItem,
  upsertOfficeItem,
  type OfficeListItem,
} from '../../engine/officeList'
import { logActivity, onOpenArtifact, saveArtifact } from '../../engine/workspaceLog'

type DeckPayload = { slides: RecipeSlide[]; templateId: string | null }
type DeckFile = OfficeListItem<DeckPayload>

function blankDeck(ko: boolean): RecipeSlide[] {
  return [
    {
      layout: 'title',
      title: ko ? '제목 슬라이드' : 'Title slide',
      body: ko ? '메모를 적으세요' : 'Click to add notes',
      bullets: [],
      table: null,
    },
  ]
}

const LAYOUTS: { id: SlideLayout; en: string; ko: string }[] = [
  { id: 'title', en: 'Title', ko: '제목' },
  { id: 'bullets', en: 'Bullets', ko: '목록' },
  { id: 'table', en: 'Table', ko: '표' },
]

function emptyTable() {
  return { headers: ['', ''], rows: [['', '']] }
}

export function SlidesApp() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const deckDefaults = ko
    ? { name: '새 덱', title: '새 프레젠테이션' }
    : { name: 'New deck', title: 'Untitled presentation' }
  const [deckBoot] = useState(() =>
    bootOfficeList<DeckPayload>('slides', () => ({ slides: blankDeck(false), templateId: null }), deckDefaults),
  )
  const bootDeck = deckBoot.rows.find((row) => row.id === deckBoot.activeId) || deckBoot.rows[0]
  const [decks, setDecks] = useState<DeckFile[]>(deckBoot.rows)
  const [deckId, setDeckId] = useState(deckBoot.activeId)
  const [deckTitle, setDeckTitle] = useState(bootDeck?.title || deckDefaults.title)
  const [slides, setSlides] = useState<RecipeSlide[]>(
    bootDeck?.payload.slides?.length ? bootDeck.payload.slides : blankDeck(ko),
  )
  const [index, setIndex] = useState(0)
  const [saved, setSaved] = useState(true)
  const [exportHint, setExportHint] = useState('')
  const [studio, setStudio] = useState<StudioPhase>(() => (recallOfficeActive('slides') ? 'editor' : 'gallery'))
  const [galleryView, setGalleryView] = useState<GalleryView>('home')
  const [activeTemplateId, setActiveTemplateId] = useState<string | null>(bootDeck?.payload.templateId || null)
  const [promptDraft, setPromptDraft] = useState('')
  const [audience, setAudience] = useState('')
  const [slideCount, setSlideCount] = useState(10)
  const [orderedTemplates, setOrderedTemplates] = useState(PRESENTATION_TEMPLATES)
  const [assistBusy, setAssistBusy] = useState(false)
  const [deckStage, setDeckStage] = useState<DeckStage | null>(null)
  const [agentSel, setAgentSel] = useState<SlideElementSel | null>(null)
  const [agentScope, setAgentScope] = useState<AgentScope>('element')
  const [pickedSlides, setPickedSlides] = useState<number[]>([0])
  const [agentPrompt, setAgentPrompt] = useState('')
  const [agentBusy, setAgentBusy] = useState(false)
  const [agentStatus, setAgentStatus] = useState('')
  const [change, setChange] = useState<ChangeSet | null>(null)
  const [confirmDeck, setConfirmDeck] = useState(false)
  const [versions, setVersions] = useState<SessionVersion[]>([])
  const [versionCursor, setVersionCursor] = useState(0)
  const [modified, setModified] = useState<number[]>([])
  const [qa, setQa] = useState<QaFinding[]>([])
  const [qaRan, setQaRan] = useState<QaCheckId[]>([])
  const [exportSummary, setExportSummary] = useState('')
  const skipUserHistory = useRef(false)
  const fieldSnap = useRef('')
  const current = slides[index] || slides[0]
  const currentFit = fitSlide(current)
  const activeTemplate = activeTemplateId ? getTemplateById(activeTemplateId) : undefined
  const editorTheme = themeForEditor(activeTemplate)
  const editorThemeStyle = themeToCssVars(editorTheme) as CSSProperties
  const activeTemplateIdRef = useRef(activeTemplateId)
  activeTemplateIdRef.current = activeTemplateId
  const seatBodyRef = useRef('')
  const slidesRef = useRef(slides)
  slidesRef.current = slides
  const deckTitleRef = useRef(deckTitle)
  deckTitleRef.current = deckTitle
  const plannedCountRef = useRef(0)
  const artifactIdRef = useRef<string | null>(null)
  const decksRef = useRef(decks)
  const deckIdRef = useRef(deckId)
  decksRef.current = decks
  deckIdRef.current = deckId
  const [deckEditingId, setDeckEditingId] = useState<string | null>(null)
  const [deckEditName, setDeckEditName] = useState('')
  const [deckRailOpen, setDeckRailOpen] = useState(true)
  const deckRenameRef = useRef<HTMLInputElement>(null)

  const commitDeckList = (nextTitle: string, nextSlides: RecipeSlide[], templateId: string | null) => {
    const id = deckIdRef.current
    const cur = decksRef.current.find((row) => row.id === id)
    if (!cur) return
    const neat = nextTitle.trim() || cur.title
    const list = upsertOfficeItem('slides', decksRef.current, {
      ...cur,
      name: neat,
      title: neat,
      updated: Date.now(),
      payload: { slides: nextSlides, templateId },
    })
    decksRef.current = list
    setDecks(list)
    rememberOfficeActive('slides', id)
  }

  const openDeck = (id: string) => {
    commitDeckList(deckTitle, slidesRef.current, activeTemplateIdRef.current)
    const row = decksRef.current.find((item) => item.id === id)
    if (!row) return
    setDeckId(row.id)
    deckIdRef.current = row.id
    rememberOfficeActive('slides', row.id)
    setDeckTitle(row.title)
    setSlides(row.payload.slides?.length ? row.payload.slides : blankDeck(ko))
    setIndex(0)
    setActiveTemplateId(row.payload.templateId || null)
    setStudio('editor')
    setSaved(true)
    artifactIdRef.current = null
  }

  useEffect(() => {
    if (saved) return
    const t = window.setTimeout(() => {
      commitDeckList(deckTitleRef.current, slidesRef.current, activeTemplateIdRef.current)
    }, 400)
    return () => window.clearTimeout(t)
  }, [saved, slides, deckTitle, activeTemplateId])

  useEffect(() => {
    return () => {
      commitDeckList(deckTitleRef.current, slidesRef.current, activeTemplateIdRef.current)
    }
  }, [])

  const addDeck = () => {
    setDeckRailOpen(true)
    commitDeckList(deckTitle, slidesRef.current, activeTemplateIdRef.current)
    const { rows, node } = addOfficeItem('slides', decksRef.current, {
      name: ko ? '새 덱' : 'New deck',
      title: ko ? '새 프레젠테이션' : 'Untitled presentation',
      payload: { slides: blankDeck(ko), templateId: null },
    })
    decksRef.current = rows
    setDecks(rows)
    setDeckId(node.id)
    deckIdRef.current = node.id
    rememberOfficeActive('slides', node.id)
    setDeckTitle(node.title)
    setSlides(node.payload.slides)
    setIndex(0)
    setActiveTemplateId(null)
    setStudio('editor')
    setSaved(false)
    artifactIdRef.current = null
    setExportHint(ko ? '새 덱을 만들었습니다. 저장을 눌러 남기세요.' : 'New deck created. Press Save to keep it.')
  }

  const commitDeckRename = (id: string) => {
    const next = deckEditName.trim()
    setDeckEditingId(null)
    if (!next) return
    const cur = decksRef.current.find((row) => row.id === id)
    if (!cur || cur.name === next) return
    const list = upsertOfficeItem('slides', decksRef.current, {
      ...cur,
      name: next,
      title: next,
      updated: Date.now(),
    })
    decksRef.current = list
    setDecks(list)
    if (id === deckIdRef.current) {
      setDeckTitle(next)
      setSaved(false)
    }
  }

  const deleteDeck = (id: string) => {
    if (id === deckIdRef.current) commitDeckList(deckTitle, slidesRef.current, activeTemplateIdRef.current)
    const list = removeOfficeItem(
      'slides',
      decksRef.current,
      id,
      () => ({ slides: blankDeck(ko), templateId: null }),
      deckDefaults,
    )
    decksRef.current = list
    setDecks(list)
    const next = list.find((row) => row.id === deckIdRef.current) || list[0]
    setDeckId(next.id)
    deckIdRef.current = next.id
    setDeckTitle(next.title)
    setSlides(next.payload.slides?.length ? next.payload.slides : blankDeck(ko))
    setIndex(0)
    setActiveTemplateId(next.payload.templateId || null)
    setSaved(true)
  }

  useEffect(
    () =>
      onOpenArtifact('slides', (row) => {
        const payload = (row.payload || {}) as { slides?: RecipeSlide[]; templateId?: string | null }
        if (!Array.isArray(payload.slides) || !payload.slides.length) return
        commitDeckList(deckTitle, slidesRef.current, activeTemplateIdRef.current)
        const { rows, node } = addOfficeItem('slides', decksRef.current, {
          name: row.title || deckDefaults.name,
          title: row.title || deckDefaults.title,
          payload: { slides: payload.slides, templateId: payload.templateId || null },
        })
        decksRef.current = rows
        setDecks(rows)
        setDeckId(node.id)
        deckIdRef.current = node.id
        setDeckTitle(node.title)
        artifactIdRef.current = row.id
        setSlides(payload.slides)
        setIndex(0)
        setActiveTemplateId(payload.templateId || null)
        setStudio('editor')
        setSaved(true)
        setDeckRailOpen(true)
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  )

  const saveDeck = async () => {
    const checked = runQa(slides)
    const summary = qaSummaryText(checked.findings, checked.ran, ko)
    setQa(checked.findings)
    setQaRan(checked.ran)
    setExportSummary(summary)
    setExportHint(summary)
    const title = deckTitle.trim() || slides[0]?.title || (ko ? '이름 없는 덱' : 'Untitled deck')
    commitDeckList(title, slides, activeTemplateId)
    setDeckTitle(title)
    setSaved(true)
    try {
      const row = await saveArtifact('slides', title, { slides, templateId: activeTemplateId }, artifactIdRef.current)
      artifactIdRef.current = row.id
      setExportHint(ko ? '이 기기에 저장했습니다.' : 'Saved on this device.')
    } catch {
      setExportHint(ko ? '목록에는 저장됐습니다. My Work 동기화는 다시 눌러 주세요.' : 'Kept in the list. Tap Save again to sync My Work.')
    }
  }

  const proposeGeneration = useCallback(
    (currentSlides: RecipeSlide[], text: string, expectedCount: number) => {
      const next = generationChangeSet(currentSlides, text, expectedCount)
      if (!next) {
        setChange(null)
        setDeckStage('FAILED')
        return
      }
      setConfirmDeck(false)
      setChange(next)
      setDeckStage(null)
      setAgentStatus(
        ko
          ? '제안이 있습니다. Apply 전에는 덱이 바뀌지 않습니다.'
          : 'A proposal is ready. The deck stays as it is until Apply.',
      )
    },
    [ko],
  )

  const fillDeck = useCallback(
    async (currentSlides: RecipeSlide[], planned: RecipeSlide[], prompt: string) => {
      const seat = seatBodyRef.current.trim()
      seatBodyRef.current = ''
      if (seat) {
        proposeGeneration(currentSlides, seat, planned.length)
        return
      }
      if (!prompt.trim()) return
      setAssistBusy(true)
      setDeckStage('ANALYZING_PROMPT')
      setDeckStage('PLANNING_DECK')
      setDeckStage('SELECTING_LAYOUT')
      const laid = planned.map(stampLayout)
      setExportHint('')
      try {
        setDeckStage('GENERATING_CONTENT')
        const result = await assistOffice({
          model: neu.officeModel,
          app: 'slides',
          instruction:
            `Rewrite the whole deck (${laid.length} slides) for this request: "${prompt.trim()}". ` +
            'Keep the same slide order, count and layouts. Replace placeholder titles with words from the request. ' +
            'Do not invent market sizes, percentages, dates, or company figures. Leave a metric blank when the request has no number. ' +
            'Write in the language of the request.',
          content: JSON.stringify(serializeRecipe(undefined, laid)),
        })
        setDeckStage('FITTING_CONTENT')
        if (result.ok && result.text) proposeGeneration(currentSlides, result.text, planned.length)
        else {
          setChange(null)
          setDeckStage('FAILED')
        }
      } catch {
        setChange(null)
        setDeckStage('FAILED')
      } finally {
        setAssistBusy(false)
      }
    },
    [neu.officeModel, proposeGeneration],
  )

  const update = (patch: Partial<RecipeSlide>) => {
    setSlides((rows) => rows.map((slide, i) => (i === index ? { ...slide, ...patch } : slide)))
    setSaved(false)
  }

  const setLayout = (layout: SlideLayout) => {
    if (layout === 'table' && !current.table) update({ layout, table: emptyTable() })
    else update({ layout })
  }

  const openEditorWithTemplate = useCallback(
    (template: PresentationTemplate, slideCount?: number) => {
      const fromPrompt = parseRequestedSlideCount(promptDraft, template)
      const planned = applyPromptToPlannedSlides(planSlidesFromTemplate(template, slideCount ?? fromPrompt), promptDraft)
      plannedCountRef.current = planned.length
      setChange(null)
      setConfirmDeck(false)
      void fillDeck(slides, planned, promptDraft)
      setIndex(0)
      setPickedSlides([0])
      setVersions([snapshotVersion(slides, 0, ko ? '시작' : 'Start')])
      setVersionCursor(0)
      setModified([])
      setQa([])
      setQaRan([])
      setExportSummary('')
      setSaved(false)
      setActiveTemplateId(template.id)
      pushRecentTemplate(template.id)
      setPromptSlidesTemplate(template.id, template.name)
      setStudio('editor')
      setTemplateLocation(template.id, 'editor')
    },
    [promptDraft, fillDeck, ko, slides],
  )

  const openTemplateDirect = (template: PresentationTemplate) => {
    setStudio(phaseAfterGalleryCardUse())
    openEditorWithTemplate(template)
  }

  const openPreview = (template: PresentationTemplate) => {
    setActiveTemplateId(template.id)
    setStudio('preview')
    setTemplateLocation(template.id, 'preview')
  }

  useEffect(() => {
    const id = templateIdFromLocation()
    if (!id) return
    const t = getTemplateById(id)
    if (!t) return
    setActiveTemplateId(id)
    setStudio('preview')
  }, [])

  useEffect(() => {
    const staged = takePromptSlides()
    if (!staged) return
    setPromptDraft(staged)
    void recommendTemplates(staged, neu.officeModel).then(setOrderedTemplates)
  }, [neu.officeModel])

  useEffect(() => {
    const onSeat = (ev: Event) => {
      const detail = (ev as CustomEvent<{ title?: string; body?: string; done?: boolean }>).detail
      if (!detail) return
      const incoming = (detail.body || '').trim()
      const title = (detail.title || '').trim()
      if (incoming) setPromptDraft((prev) => prev || incoming)
      else if (title) setPromptDraft((prev) => prev || title)
      if (incoming) seatBodyRef.current = incoming
      if (!incoming && !detail.done) return
      if (!activeTemplateIdRef.current) return
      const expected = plannedCountRef.current || slidesRef.current.length
      if (!incoming) {
        setChange(null)
        setDeckStage('FAILED')
        return
      }
      const next = generationChangeSet(slidesRef.current, incoming, expected)
      seatBodyRef.current = ''
      if (!next) {
        setChange(null)
        setDeckStage('FAILED')
        return
      }
      setConfirmDeck(false)
      setChange(next)
      setDeckStage(null)
      setAgentStatus(ko ? '제안이 있습니다. Apply 전에는 덱이 바뀌지 않습니다.' : 'A proposal is ready. The deck stays as it is until Apply.')
      setStudio('editor')
    }
    window.addEventListener('osneu-seat-slides', onSeat)
    return () => window.removeEventListener('osneu-seat-slides', onSeat)
  }, [ko])

  const liveQa = runQa(slides)
  const proposedTargets = change?.status === 'proposed' ? change.targetIds : []
  const modifiedSet = new Set(modified)

  const pushVersion = (nextSlides: RecipeSlide[], nextIndex: number, label: string) => {
    const snap = snapshotVersion(nextSlides, nextIndex, label)
    setVersions((rows) => [...rows.slice(0, versionCursor + 1), snap])
    setVersionCursor((n) => n + 1)
  }

  const offerChange = (next: ChangeSet) => {
    setChange(next.scope === 'deck' ? withDeckConfirm(next, confirmDeck) : next)
    if (next.applyBlocked === 'unverified') {
      setAgentStatus(ko ? '출처가 없어 미확인입니다. 숫자를 쓰지 않았습니다.' : 'Unverified: no stored source. No number was written.')
    } else if (next.applyBlocked === 'unavailable') {
      setAgentStatus(ko ? '이 레시피에서는 아직 없습니다.' : 'Unavailable on this recipe.')
    } else if (next.capMessage) {
      setAgentStatus(next.capMessage)
    } else {
      setAgentStatus('')
    }
  }

  const pickElement = (sel: SlideElementSel, currentValue: string) => {
    setAgentSel(sel)
    setAgentScope('element')
    fieldSnap.current = currentValue
  }

  const noteUserEdit = (sel: SlideElementSel, nextValue: string) => {
    if (skipUserHistory.current) return
    if (nextValue === fieldSnap.current) return
    pushVersion(slides, index, historyLine({ source: 'user', sel, ko }))
    fieldSnap.current = nextValue
  }

  const runTextAction = async (action: 'rewrite' | 'shorten' | 'improve' | 'translate') => {
    const slide = slides[index]
    if (!slide) return
    if (agentScope === 'element' && !agentSel) return
    setAgentBusy(true)
    try {
      const scoped = agentScope === 'slides' || agentScope === 'deck' ? 'slide' : agentScope === 'slide' ? 'slide' : 'element'
      const instruction = agentInstruction({
        action,
        scope: scoped,
        sel: agentSel,
        extra: agentPrompt,
      })
      const targets = agentScope === 'slides' ? pickedSlides : agentScope === 'deck' ? slides.map((_, i) => i) : [index]
      const content =
        agentScope === 'element'
          ? selectedText(slide, agentSel)
          : JSON.stringify(serializeRecipe(undefined, targets.map((i) => slides[i]).filter(Boolean)))
      const result = await assistOffice({
        model: neu.officeModel,
        app: 'slides',
        instruction,
        content,
        selection: agentScope === 'element' ? content : undefined,
        title: agentPrompt || action,
      })
      if (!result.ok || !String(result.text || '').trim()) {
        setAgentStatus(agentFailMessage(result.reason || 'no-llm', ko))
        return
      }
      if (agentScope === 'element' && agentSel) {
        const after = parseElementReply(result.text || '', agentSel)
        if (after == null) {
          setAgentStatus(agentFailMessage('empty', ko))
          return
        }
        offerChange(
          proposeElementEdit(slides, index, agentSel, after, {
            action: action === 'translate' ? 'TRANSLATE' : 'REWRITE_CONTENT',
            extra: agentPrompt,
            reason: agentPrompt || action,
          }),
        )
        return
      }
      if (agentScope === 'deck') {
        const recipe = parseAssistText(result.text || '')
        if (!recipe.slides.length) {
          setAgentStatus(agentFailMessage('empty', ko))
          return
        }
        offerChange(proposeDeckRewrite(slides, recipe.slides, confirmDeck, agentPrompt || action))
        return
      }
      const one = parseSlideReply(result.text || '')
      if (!one) {
        setAgentStatus(agentFailMessage('empty', ko))
        return
      }
      offerChange(proposeSlideReplace(slides, index, one, agentPrompt || action))
    } finally {
      setAgentBusy(false)
    }
  }

  const runAgentAction = async (action: PanelAction) => {
    setAgentStatus('')
    const slide = slides[index]
    if (!slide) return
    const picked = pickedSlides.length ? pickedSlides : [index]
    if (action === 'rewrite' || action === 'shorten' || action === 'improve' || action === 'translate') {
      await runTextAction(action)
      return
    }
    if (action === 'delete-element') {
      if (!agentSel) return
      const nextSlide = deleteSelected(slide, agentSel)
      offerChange({
        ...proposeSlideReplace(slides, index, nextSlide, 'delete field'),
        scope: 'element',
        action: 'EDIT_TEXT',
        targetIds: [`slide:${index}`, `el:${agentSel.kind}`],
        before: selectedText(slide, agentSel),
        after: selectedText(nextSlide, agentSel),
      })
      return
    }
    if (action === 'add-element') {
      if (!agentSel) return
      const nextSlide = addOnSelected(slide, agentSel)
      if (!nextSlide) {
        setAgentStatus(ko ? `항목은 ${MAX_BULLETS}개를 넘길 수 없습니다.` : `Bullet cap is ${MAX_BULLETS}.`)
        return
      }
      const addSel: SlideElementSel =
        agentSel.kind === 'bullet' ? { kind: 'bullet', bulletIndex: (agentSel.bulletIndex ?? 0) + 1 } : agentSel
      offerChange({
        ...proposeSlideReplace(slides, index, nextSlide, 'add field'),
        scope: 'element',
        action: 'EDIT_TEXT',
        targetIds: [`slide:${index}`, `el:${addSel.kind}`],
        before: selectedText(slide, agentSel),
        after: selectedText(nextSlide, addSel),
      })
      return
    }
    if (action === 'create-slide') {
      offerChange(proposeCreateSlide(slides, index))
      return
    }
    if (action === 'delete-slide') {
      offerChange(proposeDeleteSlides(slides, agentScope === 'slides' ? picked : [index]))
      return
    }
    if (action === 'duplicate-slide') {
      offerChange(proposeDuplicateSlide(slides, index))
      return
    }
    if (action === 'move-up') {
      offerChange(proposeMoveSlide(slides, index, index - 1))
      return
    }
    if (action === 'move-down') {
      offerChange(proposeMoveSlide(slides, index, index + 1))
      return
    }
    if (action === 'merge-slide') {
      const other = agentScope === 'slides' && picked.length >= 2 ? picked[1] : index + 1
      offerChange(proposeMergeSlides(slides, index, other))
      return
    }
    if (action === 'run-qa') {
      const result = runQa(slides)
      setQa(result.findings)
      setQaRan(result.ran)
      setExportSummary(qaSummaryText(result.findings, result.ran, ko))
      const first = result.findings[0]
      if (first) {
        const fix = proposeQaFix(slides, first)
        if (fix) offerChange(fix)
      } else {
        setAgentStatus(ko ? '검사함: overflow, empty-title, duplicate-title. 문제 없음.' : 'Ran overflow, empty-title, duplicate-title. No issues.')
      }
      return
    }
    if (action === 'verify-fact') {
      offerChange(proposeVerifyFact(slides, index, agentSel))
      return
    }
    if (action === 'use-table') {
      const next = bulletsToComparisonTable(slide)
      if (!next) {
        setAgentStatus(ko ? '이 장은 이미 표이거나, 옮길 항목이 없습니다.' : 'This slide is already a table, or it has no lines to move.')
        return
      }
      offerChange(proposeSlideReplace(slides, index, next, 'replace bullets with a table'))
      return
    }
    if (action === 'image' || action === 'chart' || action === 'freeform') {
      offerChange(proposeUnavailable(slides, index, action === 'image' ? 'IMAGE' : action === 'chart' ? 'CHART' : 'FREEFORM'))
    }
  }

  const applyProposed = () => {
    if (!change) return
    const gated = change.scope === 'deck' ? withDeckConfirm(change, confirmDeck) : change
    if (!canApply(gated, confirmDeck)) return
    const applied = applyChangeSet(gated, confirmDeck)
    if (!applied.ok) return
    skipUserHistory.current = true
    setSlides(applied.slides)
    setIndex(applied.index)
    setPickedSlides([applied.index])
    setSaved(false)
    const marks = applied.change.targetIds
      .map((id) => Number(id.replace('slide:', '')))
      .filter((n) => Number.isFinite(n))
    setModified((rows) => [...new Set([...rows, ...marks])])
    pushVersion(applied.slides, applied.index, historyLabel(applied.change))
    const result = runQa(applied.slides)
    setQa(result.findings)
    setQaRan(result.ran)
    setExportSummary(qaSummaryText(result.findings, result.ran, ko))
    setChange(null)
    setAgentStatus('')
    skipUserHistory.current = false
  }

  const rejectProposed = () => {
    if (change) setChange(rejectChangeSet(change))
    setChange(null)
    setAgentStatus('')
  }

  const jumpVersion = (next: { cursor: number; snap: SessionVersion } | null) => {
    if (!next) return
    skipUserHistory.current = true
    setSlides(next.snap.slides)
    setIndex(next.snap.index)
    setPickedSlides([next.snap.index])
    setVersionCursor(next.cursor)
    setChange(null)
    skipUserHistory.current = false
  }

  const runAssist = async (instruction: string) => {
    setAgentPrompt(instruction)
    await runTextAction('rewrite')
  }

  const downloadPptx = async () => {
    const checked = runQa(slides)
    const summary = qaSummaryText(checked.findings, checked.ran, ko)
    setQa(checked.findings)
    setQaRan(checked.ran)
    setExportSummary(summary)
    const recipe = serializeRecipe(current.title || undefined, slides)
    const bytes = exportSlidesToPptx(recipe, new Date(), editorTheme ? themeToPptxHints(editorTheme) : undefined)
    const result = await savePptxFile(bytes, recipe.title || slides[0]?.title || 'slides')
    if (result.ok) logActivity('slides.export', { app: 'slides', title: recipe.title || slides[0]?.title || 'slides' })
    const done = result.ok ? (ko ? 'PPTX 내보냈습니다.' : 'Exported PPTX.') : ko ? '내보내기를 취소했습니다.' : 'Export cancelled.'
    setExportHint(`${summary}\n${done}`)
    window.setTimeout(() => setExportHint(''), 6000)
  }

  const handleDiscover = async (query: string) => {
    setPromptDraft(query)
    const ranked = await recommendTemplates(query, neu.officeModel)
    setOrderedTemplates(ranked)
  }

  const handleNav = (id: 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant') => {
    if (id === 'my-templates') setGalleryView('my-templates')
    else if (id === 'recent') setGalleryView('recent')
    else setGalleryView('home')
    setStudio('gallery')
    setTemplateLocation(null, 'gallery')
  }

  if (studio === 'gallery') {
    return (
      <TemplateGalleryHome
        ko={ko}
        galleryView={galleryView}
        onGalleryView={setGalleryView}
        onNav={handleNav}
        orderedTemplates={orderedTemplates}
        prompt={promptDraft}
        onPrompt={setPromptDraft}
        onDiscover={handleDiscover}
        onSelectTemplate={openTemplateDirect}
        onPreviewTemplate={openPreview}
      />
    )
  }

  if (studio === 'preview' && activeTemplate) {
    return (
      <TemplatePreviewScreen
        template={activeTemplate}
        ko={ko}
        onBack={() => {
          setStudio('gallery')
          setTemplateLocation(null, 'gallery')
        }}
        onUse={() => openEditorWithTemplate(activeTemplate)}
        onPromptStep={() => {
          setSlideCount(defaultSlideCount(activeTemplate))
          setStudio(phaseAfterPreviewPrompt())
        }}
      />
    )
  }

  if (studio === 'prompt' && activeTemplate) {
    return (
      <TemplatePromptSettings
        template={activeTemplate}
        ko={ko}
        audience={audience}
        onAudience={setAudience}
        slideCount={slideCount}
        onSlideCount={setSlideCount}
        prompt={promptDraft}
        onPrompt={setPromptDraft}
        onBack={() => setStudio('preview')}
        onContinue={() => setStudio(phaseAfterPromptContinue())}
      />
    )
  }

  if (studio === 'storyboard' && activeTemplate) {
    return (
      <TemplateStoryboardScreen
        template={activeTemplate}
        ko={ko}
        slideCount={slideCount}
        audience={audience}
        prompt={promptDraft}
        onBack={() => setStudio('prompt')}
        onConfirm={() => {
          setStudio(phaseAfterStoryboardConfirm())
          openEditorWithTemplate(activeTemplate, slideCount)
        }}
      />
    )
  }

  if (studio === 'export') {
    return (
      <ExportHubScreen
        template={activeTemplate}
        slides={slides}
        ko={ko}
        exportHint={exportHint}
        onBack={() => setStudio(phaseAfterExportBack())}
        onDownload={downloadPptx}
      />
    )
  }

  const editor = (
    <div className={`slides-shell${deckRailOpen ? '' : ' rail-collapsed'}`}>
      <aside className="doc-rail" aria-label={ko ? '프레젠테이션 목록' : 'Presentations'}>
        <div className="doc-rail-head">
          <button type="button" className="icon-btn" onClick={() => setDeckRailOpen((v) => !v)} aria-expanded={deckRailOpen}>
            {deckRailOpen ? '‹' : '☰'}
          </button>
          {deckRailOpen ? <b>{ko ? '덱' : 'Decks'}</b> : null}
          <div className="doc-rail-adds">
            <button type="button" className="doc-rail-add" onClick={addDeck} title={ko ? '새 덱' : 'New deck'}>
              +
            </button>
          </div>
        </div>
        {deckRailOpen ? (
          <ul className="doc-rail-list">
            {decks.map((row) => (
              <li key={row.id} className={row.id === deckId ? 'on' : ''}>
                <button type="button" className="doc-rail-item" onClick={() => openDeck(row.id)}>
                  <span className="doc-rail-folder" aria-hidden>
                    ·
                  </span>
                  {deckEditingId === row.id ? (
                    <input
                      ref={deckRenameRef}
                      className="doc-rail-rename"
                      value={deckEditName}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setDeckEditName(e.target.value)}
                      onBlur={() => commitDeckRename(row.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          commitDeckRename(row.id)
                        }
                        if (e.key === 'Escape') {
                          e.preventDefault()
                          setDeckEditingId(null)
                        }
                      }}
                    />
                  ) : (
                    <span>{row.name}</span>
                  )}
                </button>
                <div className="doc-rail-actions">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      setDeckEditingId(row.id)
                      setDeckEditName(row.name)
                      window.requestAnimationFrame(() => deckRenameRef.current?.focus())
                    }}
                    title={ko ? '이름' : 'Rename'}
                  >
                    ✎
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteDeck(row.id)
                    }}
                    title={ko ? '삭제' : 'Delete'}
                  >
                    ×
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : null}
      </aside>
      <div className="slides-app ppt-s5-shell slides-main" data-ui="s5-editor-shell">
      <div className="ppt-s5-template-bar" data-ui="template-dialog">
        <button
          type="button"
          onClick={() => {
            setStudio('gallery')
            setTemplateLocation(null, 'gallery')
          }}
        >
          {ko ? '템플릿' : 'Templates'}
        </button>
        <input
          className="sheet-name"
          value={deckTitle}
          onChange={(e) => {
            setDeckTitle(e.target.value)
            setSaved(false)
          }}
          aria-label={ko ? '덱 이름' : 'Deck title'}
        />
        <span>
          {slides.length} {ko ? '장' : 'slides'}
          {activeTemplate ? ` · ${activeTemplate.category}` : ''}
        </span>
      </div>
      <AppToolbar
        title={deckTitle || current.title || 'Slides'}
        saved={saved}
        onSave={() => void saveDeck()}
        onAssist={runAssist}
        extra={
          <>
            <button type="button" className="icon-btn" onClick={addDeck} title={ko ? '새 덱' : 'New deck'}>
              ⌂+
            </button>
            <button
              type="button"
              className="icon-btn"
              onClick={() => offerChange(proposeCreateSlide(slides, index))}
              aria-label={ko ? '슬라이드 추가' : 'Add slide'}
              title={ko ? '슬라이드 추가' : 'Add slide'}
            >
              +
            </button>
            <button
              type="button"
              className="icon-btn text"
              data-ui="export-hub"
              onClick={() => {
                const checked = runQa(slides)
                setQa(checked.findings)
                setQaRan(checked.ran)
                setExportSummary(qaSummaryText(checked.findings, checked.ran, ko))
                setStudio(phaseAfterEditorExport())
              }}
              title={ko ? '내보내기 허브' : 'Export hub'}
            >
              {ko ? '내보내기' : 'Export'}
            </button>
            <button
              type="button"
              className="icon-btn text"
              data-ui="export-pptx"
              onClick={downloadPptx}
              title={ko ? 'PPTX보내기' : 'Export PPTX'}
            >
              {ko ? 'PPTX보내기' : 'Export PPTX'}
            </button>
          </>
        }
      />
      {exportHint ? <div className="slides-export-hint">{exportHint}</div> : null}
      <OverflowWarning result={currentFit} ko={ko} />
      {deckStage ? <DeckProgress stage={deckStage} ko={ko} /> : null}
      <div className="slides-stage ppt-s5-body">
        <aside className="slides-rail ppt-s5-filmstrip" data-ui="s5-filmstrip">
          {slides.map((slide, i) => {
            const overflow = fitSlide(slide).overflow
            const status = railStatus({
              slide,
              index: i,
              current: index,
              busy: agentBusy || assistBusy,
              proposedTargets,
              modified: modifiedSet,
              findings: liveQa.findings,
            })
            const picked = pickedSlides.includes(i)
            return (
              <button
                key={i}
                type="button"
                className={`${i === index ? 'on' : ''}${picked && i !== index ? ' picked' : ''}`}
                data-overflow={overflow ? 'true' : undefined}
                data-status={status}
                data-ui="rail-card"
                onClick={(ev) => {
                  if (ev.metaKey || ev.ctrlKey) {
                    setPickedSlides((rows) => (rows.includes(i) ? rows.filter((n) => n !== i) : [...rows, i]))
                    setIndex(i)
                    setAgentSel(null)
                    setAgentScope('slides')
                    return
                  }
                  if (ev.shiftKey) {
                    const from = Math.min(index, i)
                    const to = Math.max(index, i)
                    setPickedSlides(Array.from({ length: to - from + 1 }, (_, n) => from + n))
                    setIndex(i)
                    setAgentSel(null)
                    setAgentScope('slides')
                    return
                  }
                  setIndex(i)
                  setPickedSlides([i])
                  setAgentSel(null)
                }}
              >
                <span className="ppt-rail-status" data-status={status}>
                  {status}
                </span>
                {i + 1}. {slide.title || 'Slide'}
                {overflow ? ' · !' : ''}
              </button>
            )
          })}
        </aside>
        <div className="slide-canvas ppt-editor-themed" style={editorThemeStyle}>
          <SlideLayoutFrame slide={current} />
          <div className="slide-layout-row">
            {LAYOUTS.map((l) => (
              <button
                key={l.id}
                type="button"
                className={`layout-pick${current.layout === l.id ? ' on' : ''}`}
                onClick={() => setLayout(l.id)}
              >
                {ko ? l.ko : l.en}
              </button>
            ))}
          </div>
          <input
            className={agentSel?.kind === 'title' ? 'slide-el-on' : ''}
            data-el="title"
            value={current.title}
            onClick={() => pickElement({ kind: 'title' }, current.title)}
            onFocus={() => pickElement({ kind: 'title' }, current.title)}
            onBlur={() => noteUserEdit({ kind: 'title' }, current.title)}
            onChange={(e) => update({ title: e.target.value })}
            aria-label="Slide title"
          />

          {current.layout === 'table' ? (
            <div className="slide-table-editor">
              <table>
                <thead>
                  <tr>
                    {current.table?.headers.map((h, ci) => (
                      <th key={ci}>
                        <input
                          className={agentSel?.kind === 'cell' && agentSel.row === -1 && agentSel.col === ci ? 'slide-el-on' : ''}
                          data-el="cell"
                          value={h}
                          onClick={() => pickElement({ kind: 'cell', row: -1, col: ci }, h)}
                          onFocus={() => pickElement({ kind: 'cell', row: -1, col: ci }, h)}
                          onBlur={() => noteUserEdit({ kind: 'cell', row: -1, col: ci }, h)}
                          onChange={(e) => {
                            const headers = [...(current.table?.headers || [])]
                            headers[ci] = e.target.value
                            update({ table: { headers, rows: current.table?.rows || [] } })
                          }}
                          aria-label={`Header ${ci + 1}`}
                        />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(current.table?.rows || []).map((row, ri) => (
                    <tr key={ri}>
                      {(current.table?.headers || []).map((_, ci) => (
                        <td key={ci}>
                          <input
                            className={agentSel?.kind === 'cell' && agentSel.row === ri && agentSel.col === ci ? 'slide-el-on' : ''}
                            data-el="cell"
                            value={row[ci] || ''}
                            onClick={() => pickElement({ kind: 'cell', row: ri, col: ci }, row[ci] || '')}
                            onFocus={() => pickElement({ kind: 'cell', row: ri, col: ci }, row[ci] || '')}
                            onBlur={() => noteUserEdit({ kind: 'cell', row: ri, col: ci }, row[ci] || '')}
                            onChange={(e) => {
                              const rows = (current.table?.rows || []).map((r) => [...r])
                              rows[ri][ci] = e.target.value
                              update({ table: { headers: current.table?.headers || [], rows } })
                            }}
                            aria-label={`Row ${ri + 1} col ${ci + 1}`}
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="slide-table-controls">
                <button
                  type="button"
                  className="icon-btn"
                  disabled={(current.table?.headers.length || 0) >= 5}
                  onClick={() => {
                    const headers = [...(current.table?.headers || []), '']
                    const rows = (current.table?.rows || []).map((r) => [...r, ''])
                    update({ table: { headers, rows } })
                  }}
                >
                  {ko ? '열 추가' : '+ Column'}
                </button>
                <button
                  type="button"
                  className="icon-btn"
                  disabled={(current.table?.rows.length || 0) >= 8}
                  onClick={() => {
                    const cols = current.table?.headers.length || 2
                    const rows = [...(current.table?.rows || []), Array.from({ length: cols }, () => '')]
                    update({ table: { headers: current.table?.headers || [], rows } })
                  }}
                >
                  {ko ? '행 추가' : '+ Row'}
                </button>
              </div>
            </div>
          ) : current.layout === 'bullets' ? (
            <div className="slide-bullets-editor" data-ui="slide-bullets">
              {(current.body ? current.body.split(/\r?\n/) : ['']).map((line, bi) => (
                <input
                  key={bi}
                  className={agentSel?.kind === 'bullet' && agentSel.bulletIndex === bi ? 'slide-el-on' : ''}
                  data-el="bullet"
                  value={line}
                  onClick={() => pickElement({ kind: 'bullet', bulletIndex: bi }, line)}
                  onFocus={() => pickElement({ kind: 'bullet', bulletIndex: bi }, line)}
                  onBlur={() => noteUserEdit({ kind: 'bullet', bulletIndex: bi }, line)}
                  onChange={(e) => {
                    const lines = (current.body ? current.body.split(/\r?\n/) : ['']).slice()
                    lines[bi] = e.target.value
                    const body = lines.join('\n')
                    update({ body, bullets: bulletsFromBody(body) })
                  }}
                  placeholder={ko ? '항목' : 'Bullet'}
                  aria-label={`Bullet ${bi + 1}`}
                />
              ))}
            </div>
          ) : (
            <textarea
              className={agentSel?.kind === 'body' ? 'slide-el-on' : ''}
              data-el="body"
              value={current.body}
              onClick={() => pickElement({ kind: 'body' }, current.body)}
              onFocus={() => pickElement({ kind: 'body' }, current.body)}
              onBlur={() => noteUserEdit({ kind: 'body' }, current.body)}
              onChange={(e) => update({ body: e.target.value })}
              placeholder={ko ? '부제목' : 'Subtitle'}
              aria-label="Slide body"
            />
          )}
        </div>
        <StudioAgentPanel
          ko={ko}
          sel={agentSel}
          scope={agentScope}
          onScope={setAgentScope}
          selectedCount={pickedSlides.length || 1}
          prompt={agentPrompt}
          onPrompt={setAgentPrompt}
          busy={agentBusy || assistBusy}
          status={agentStatus}
          change={change}
          confirmDeck={confirmDeck}
          onConfirmDeck={(value) => {
            setConfirmDeck(value)
            setChange((row) => (row && row.scope === 'deck' ? withDeckConfirm(row, value) : row))
          }}
          qa={qa}
          qaRan={qaRan}
          exportSummary={exportSummary}
          history={versions}
          versionCursor={versionCursor}
          onAction={(action) => void runAgentAction(action)}
          onApply={applyProposed}
          onReject={rejectProposed}
          onUndo={() => jumpVersion(undoVersion(versions, versionCursor))}
          onRedo={() => jumpVersion(redoVersion(versions, versionCursor))}
          onRestore={(id) => jumpVersion(restoreVersion(versions, id))}
          onFixFinding={(finding) => {
            const fix = proposeQaFix(slides, finding)
            if (fix) offerChange(fix)
          }}
        />
      </div>
    </div>
    </div>
  )
  return editor
}
