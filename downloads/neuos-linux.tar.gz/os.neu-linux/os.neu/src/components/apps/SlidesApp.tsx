import { useState } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import { useNeu } from '../../state/store'

type Slide = { title: string; body: string }

function parseSlides(text: string): Slide[] {
  const chunks = text.split(/^##\s+/m).map((part) => part.trim()).filter(Boolean)
  if (!chunks.length) return [{ title: 'New slide', body: text }]
  return chunks.map((chunk) => {
    const [title, ...rest] = chunk.split('\n')
    return { title: title.trim(), body: rest.join('\n').trim() }
  })
}

export function SlidesApp() {
  const neu = useNeu()
  const [slides, setSlides] = useState<Slide[]>([{ title: 'Title slide', body: 'Click to add notes' }])
  const [index, setIndex] = useState(0)
  const [saved, setSaved] = useState(false)
  const current = slides[index] || slides[0]

  const update = (patch: Partial<Slide>) => {
    setSlides((rows) => rows.map((slide, i) => (i === index ? { ...slide, ...patch } : slide)))
    setSaved(false)
  }

  return (
    <div className="slides-app">
      <AppToolbar
        title={current.title || 'Slides'}
        saved={saved}
        onSave={() => setSaved(true)}
        onAssist={async (instruction) => {
          const result = await assistOffice({
            model: neu.officeModel,
            app: 'slides',
            instruction,
            content: slides.map((slide) => `## ${slide.title}\n${slide.body}`).join('\n\n'),
          })
          if (result.ok && result.text) {
            setSlides(parseSlides(result.text))
            setIndex(0)
          }
        }}
        extra={
          <button
            type="button"
            className="icon-btn"
            onClick={() => {
              setSlides((rows) => [...rows, { title: `Slide ${rows.length + 1}`, body: '' }])
              setIndex(slides.length)
            }}
          >
            +
          </button>
        }
      />
      <div className="slides-stage">
        <aside className="slides-rail">
          {slides.map((slide, i) => (
            <button key={i} type="button" className={i === index ? 'on' : ''} onClick={() => setIndex(i)}>
              {i + 1}. {slide.title || 'Slide'}
            </button>
          ))}
        </aside>
        <div className="slide-canvas">
          <input value={current.title} onChange={(e) => update({ title: e.target.value })} aria-label="Slide title" />
          <textarea value={current.body} onChange={(e) => update({ body: e.target.value })} aria-label="Slide body" />
        </div>
      </div>
    </div>
  )
}
