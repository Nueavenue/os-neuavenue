import type { AgentScope, SlideElementSel } from '../../../engine/slideAgentEdit'
import { ENTIRE_DECK_SCOPE_ENABLED, elementLabel } from '../../../engine/slideAgentEdit'
import type { ChangeSet, QaCheckId, QaFinding, SessionVersion } from '../../../engine/slideChangeSet'
import { canApply } from '../../../engine/slideChangeSet'

export type PanelAction =
  | 'rewrite'
  | 'shorten'
  | 'improve'
  | 'translate'
  | 'delete-element'
  | 'add-element'
  | 'create-slide'
  | 'delete-slide'
  | 'duplicate-slide'
  | 'move-up'
  | 'move-down'
  | 'merge-slide'
  | 'use-table'
  | 'run-qa'
  | 'verify-fact'
  | 'image'
  | 'chart'
  | 'freeform'

type Props = {
  ko: boolean
  sel: SlideElementSel | null
  scope: AgentScope
  onScope: (scope: AgentScope) => void
  selectedCount: number
  prompt: string
  onPrompt: (value: string) => void
  busy: boolean
  status: string
  change: ChangeSet | null
  confirmDeck: boolean
  onConfirmDeck: (value: boolean) => void
  qa: QaFinding[]
  qaRan: QaCheckId[]
  exportSummary: string
  history: SessionVersion[]
  versionCursor: number
  onAction: (action: PanelAction) => void
  onApply: () => void
  onReject: () => void
  onUndo: () => void
  onRedo: () => void
  onRestore: (id: string) => void
  onFixFinding: (finding: QaFinding) => void
}

const TEXT_ACTIONS: { id: PanelAction; en: string; ko: string }[] = [
  { id: 'rewrite', en: 'Rewrite', ko: '다시 쓰기' },
  { id: 'shorten', en: 'Shorten', ko: '짧게' },
  { id: 'improve', en: 'Improve', ko: '다듬기' },
  { id: 'translate', en: 'Translate', ko: '번역' },
  { id: 'delete-element', en: 'Delete field', ko: '칸 삭제' },
  { id: 'add-element', en: 'Add field', ko: '칸 추가' },
]

const STRUCT_ACTIONS: { id: PanelAction; en: string; ko: string }[] = [
  { id: 'create-slide', en: 'Create slide', ko: '장 만들기' },
  { id: 'delete-slide', en: 'Delete slide', ko: '장 삭제' },
  { id: 'duplicate-slide', en: 'Duplicate', ko: '복제' },
  { id: 'move-up', en: 'Move up', ko: '위로' },
  { id: 'move-down', en: 'Move down', ko: '아래로' },
  { id: 'merge-slide', en: 'Merge', ko: '합치기' },
  { id: 'use-table', en: 'Bullets to table', ko: '항목을 표로' },
]

const LATER: { id: PanelAction; en: string; ko: string }[] = [
  { id: 'image', en: 'Image', ko: '이미지' },
  { id: 'chart', en: 'Chart', ko: '차트' },
  { id: 'freeform', en: 'Freeform', ko: '자유 도형' },
]

export function StudioAgentPanel({
  ko,
  sel,
  scope,
  onScope,
  selectedCount,
  prompt,
  onPrompt,
  busy,
  status,
  change,
  confirmDeck,
  onConfirmDeck,
  qa,
  qaRan,
  exportSummary,
  history,
  versionCursor,
  onAction,
  onApply,
  onReject,
  onUndo,
  onRedo,
  onRestore,
  onFixFinding,
}: Props) {
  const needSel = scope === 'element' && !sel
  const addOk = sel?.kind === 'bullet' || sel?.kind === 'body'
  const applyOk = change ? canApply(change, confirmDeck) : false

  return (
    <aside className="ppt-s5-assist ppt-agent-panel" data-ui="agent-panel">
      <h2>{ko ? '에이전트' : 'Agent'}</h2>
      <p data-ui="selected-element">
        {ko ? '고른 요소' : 'Selected element'}: <strong>{elementLabel(sel, ko)}</strong>
      </p>
      <div className="ppt-agent-scope" role="group" aria-label={ko ? '범위' : 'Scope'}>
        <button type="button" className={scope === 'element' ? 'on' : ''} data-ui="scope-element" onClick={() => onScope('element')}>
          {ko ? '이 요소' : 'This element'}
        </button>
        <button type="button" className={scope === 'slide' ? 'on' : ''} data-ui="scope-slide" onClick={() => onScope('slide')}>
          {ko ? '이 슬라이드' : 'This slide'}
        </button>
        <button type="button" className={scope === 'slides' ? 'on' : ''} data-ui="scope-slides" onClick={() => onScope('slides')}>
          {ko ? `고른 장 (${selectedCount})` : `Selected slides (${selectedCount})`}
        </button>
        <button
          type="button"
          className={scope === 'deck' ? 'on' : ''}
          data-ui="scope-deck"
          disabled={!ENTIRE_DECK_SCOPE_ENABLED}
          onClick={() => onScope('deck')}
        >
          {ko ? '덱 전체' : 'Entire presentation'}
        </button>
      </div>
      <textarea
        value={prompt}
        onChange={(e) => onPrompt(e.target.value)}
        placeholder={ko ? '이 범위에 대한 지시 (선택)' : 'Optional note for this scope'}
        aria-label={ko ? '에이전트 지시' : 'Agent prompt'}
      />
      <div className="ppt-agent-actions">
        {TEXT_ACTIONS.map((row) => {
          const blocked =
            busy ||
            (scope === 'element' && needSel) ||
            (row.id === 'add-element' && (scope !== 'element' || !addOk)) ||
            (row.id === 'delete-element' && scope !== 'element')
          return (
            <button key={row.id} type="button" data-ui={`agent-${row.id}`} disabled={blocked} onClick={() => onAction(row.id)}>
              {ko ? row.ko : row.en}
            </button>
          )
        })}
      </div>
      <div className="ppt-agent-actions" data-ui="agent-structural">
        {STRUCT_ACTIONS.map((row) => (
          <button key={row.id} type="button" data-ui={`agent-${row.id}`} disabled={busy} onClick={() => onAction(row.id)}>
            {ko ? row.ko : row.en}
          </button>
        ))}
      </div>
      <div className="ppt-agent-actions">
        <button type="button" data-ui="agent-run-qa" disabled={busy} onClick={() => onAction('run-qa')}>
          {ko ? 'QA' : 'QA'}
        </button>
        <button type="button" data-ui="agent-verify-fact" disabled={busy} onClick={() => onAction('verify-fact')}>
          {ko ? '사실 확인' : 'Verify fact'}
        </button>
      </div>
      <div className="ppt-agent-actions" data-ui="agent-unavailable">
        {LATER.map((row) => (
          <button
            key={row.id}
            type="button"
            data-ui={`unavailable-${row.id}`}
            disabled={busy}
            title={ko ? '이 레시피에서는 아직 없음' : 'Unavailable on this recipe'}
            onClick={() => onAction(row.id)}
          >
            {ko ? `${row.ko} (나중)` : `${row.en} (later)`}
          </button>
        ))}
      </div>
      {status ? (
        <p className="ppt-agent-status" data-ui="agent-status" role="status">
          {status}
        </p>
      ) : null}
      {change ? (
        <div className="ppt-agent-preview" data-ui="agent-changeset" data-status={change.status}>
          <p data-ui="changeset-status">
            {ko ? '상태' : 'Status'}: <strong>{change.status}</strong>
            {change.applyBlocked ? ` · ${change.applyBlocked}` : ''}
          </p>
          {change.capMessage ? <p data-ui="agent-cap">{change.capMessage}</p> : null}
          <div>
            <span>{ko ? '이전' : 'Before'}</span>
            <pre data-ui="agent-before">{change.before || '—'}</pre>
          </div>
          <div>
            <span>{ko ? '이후' : 'After'}</span>
            <pre data-ui="agent-after">{change.after || '—'}</pre>
          </div>
          {change.scope === 'deck' ? (
            <label className="ppt-agent-confirm">
              <input
                type="checkbox"
                data-ui="confirm-deck"
                checked={confirmDeck}
                onChange={(e) => onConfirmDeck(e.target.checked)}
              />
              {ko ? '덱 전체 변경을 확인합니다' : 'Confirm entire-presentation change'}
            </label>
          ) : null}
          <div className="ppt-agent-preview-actions">
            <button type="button" data-ui="agent-reject" disabled={busy} onClick={onReject}>
              {ko ? '거절' : 'Reject'}
            </button>
            <button
              type="button"
              className="ppt-tmpl-card-action primary"
              data-ui="agent-apply"
              disabled={busy || !applyOk}
              onClick={onApply}
            >
              {ko ? '적용' : 'Apply'}
            </button>
          </div>
        </div>
      ) : (
        <p className="ppt-agent-hint">
          {ko
            ? '칸을 고르거나 장 동작을 고르세요. 적용 전까지 덱은 그대로입니다.'
            : 'Select a field or a slide action. The deck does not change until Apply.'}
        </p>
      )}
      <div className="ppt-agent-preview-actions">
        <button type="button" data-ui="agent-undo" disabled={busy || versionCursor <= 0} onClick={onUndo}>
          {ko ? '실행 취소' : 'Undo'}
        </button>
        <button
          type="button"
          data-ui="agent-redo"
          disabled={busy || versionCursor >= history.length - 1}
          onClick={onRedo}
        >
          {ko ? '다시 실행' : 'Redo'}
        </button>
      </div>
      {qaRan.length ? (
        <div className="ppt-agent-qa" data-ui="qa-list">
          <p data-ui="qa-ran">
            {ko ? '검사함' : 'Ran'}: {qaRan.join(', ')}
          </p>
          {qa.length ? (
            <ul>
              {qa.map((row) => (
                <li key={`${row.check}-${row.slideIndex}-${row.overflowKey || ''}`}>
                  <button type="button" data-ui="qa-item" onClick={() => onFixFinding(row)}>
                    {ko ? row.messageKo : row.messageEn}
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p>{ko ? '이 세 검사에서 문제 없음.' : 'No issues from these three checks.'}</p>
          )}
        </div>
      ) : null}
      {exportSummary ? (
        <pre className="ppt-agent-export-qa" data-ui="export-qa-summary">
          {exportSummary}
        </pre>
      ) : null}
      {history.length ? (
        <ol className="ppt-agent-history" data-ui="agent-history">
          {history.map((row, i) => (
            <li key={row.id} className={i === versionCursor ? 'on' : ''}>
              <button type="button" data-ui="agent-restore" onClick={() => onRestore(row.id)}>
                <time dateTime={row.at}>{new Date(row.at).toLocaleTimeString(ko ? 'ko-KR' : 'en-US')}</time> {row.label}
              </button>
            </li>
          ))}
        </ol>
      ) : null}
    </aside>
  )
}
