import { forwardRef } from 'react'

type Props = {
  value: string
  ko: boolean
  onChange: (value: string) => void
  onSubmit: () => void
}

export const PromptDiscoveryBar = forwardRef<HTMLFormElement, Props>(function PromptDiscoveryBar(
  { value, ko, onChange, onSubmit },
  ref,
) {
  return (
    <form
      ref={ref}
      className="ppt-tmpl-prompt"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit()
      }}
    >
      <textarea
        value={value}
        rows={value.trim() ? Math.min(6, Math.max(2, value.split('\n').length + 1)) : 1}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
            e.preventDefault()
            onSubmit()
          }
        }}
        placeholder={
          ko
            ? '예: os.neu 투자 덱, 10장, AI와 보안 중심…'
            : 'e.g. Investor deck for os.neu, 10 slides, focus on AI and security…'
        }
        aria-label={ko ? '무엇을 만들까요?' : 'What do you want to create?'}
        data-ui="ppt-prompt"
      />
      <button type="submit" className="ppt-tmpl-prompt-go" aria-label={ko ? '찾기' : 'Discover'}>
        →
      </button>
    </form>
  )
})
