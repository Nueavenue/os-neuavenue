import { primitiveOf } from '../../../engine/contentFitter'
import type { RecipeSlide } from '../../../engine/slidesRecipe'
import {
  columnText,
  fitSlot,
  frameSlots,
  metricText,
  stageLabel,
  type DeckStage,
  type SlotId,
} from '../../../engine/slidesLayoutEngine'

function SlotText({ text, slotId, slide }: { text: string; slotId: SlotId; slide: RecipeSlide }) {
  const slot = frameSlots(primitiveOf(slide))[slotId]
  if (!slot) return null
  const fit = fitSlot(text, slot)
  const shown = fit.lines.join('\n') || (slotId === 'metric' ? '' : '')
  return (
    <div
      className="slide-slot"
      data-slot={slotId}
      data-overflow={fit.needsRewrite ? 'true' : 'false'}
      style={{
        left: `${slot.x}%`,
        top: `${slot.y}%`,
        width: `${slot.w}%`,
        height: `${slot.h}%`,
        fontSize: fit.fontPx,
      }}
    >
      {shown || (slotId === 'metric' ? '—' : '')}
    </div>
  )
}

/** Read-only picture of the layout. Editing stays on the fields under it. */
export function SlideLayoutFrame({ slide }: { slide: RecipeSlide }) {
  const id = primitiveOf(slide)
  const metric = metricText(slide)
  return (
    <div className="slide-layout-frame" data-ui="layout-frame" data-layout={id}>
      <SlotText slide={slide} slotId="title" text={slide.title} />
      {id === 'title' ? <SlotText slide={slide} slotId="subtitle" text={slide.body} /> : null}
      {id === 'bullets' ? <SlotText slide={slide} slotId="left" text={slide.body || slide.bullets.join('\n')} /> : null}
      {id === 'two-column' ? (
        <>
          <SlotText slide={slide} slotId="left" text={columnText(slide, 'left')} />
          <SlotText slide={slide} slotId="right" text={columnText(slide, 'right')} />
        </>
      ) : null}
      {id === 'metric' ? (
        <>
          <SlotText slide={slide} slotId="metric" text={metric.sourced ? metric.value : '—'} />
          <SlotText slide={slide} slotId="note" text={metric.sourced ? metric.label : 'No sourced figure'} />
        </>
      ) : null}
      {id === 'table' ? <SlotText slide={slide} slotId="note" text="Table" /> : null}
    </div>
  )
}

export function DeckProgress({ stage, ko }: { stage: DeckStage; ko: boolean }) {
  const order: DeckStage[] = [
    'ANALYZING_PROMPT',
    'PLANNING_DECK',
    'SELECTING_LAYOUT',
    'GENERATING_CONTENT',
    'FITTING_CONTENT',
    'READY',
  ]
  if (stage === 'FAILED') {
    return (
      <ol className="deck-progress" data-ui="deck-progress">
        <li data-state="failed">{stageLabel('FAILED', ko)}</li>
      </ol>
    )
  }
  const at = order.indexOf(stage)
  return (
    <ol className="deck-progress" data-ui="deck-progress">
      {order.map((id, i) => (
        <li key={id} data-state={i < at ? 'done' : i === at ? 'now' : 'wait'}>
          {stageLabel(id, ko)}
        </li>
      ))}
    </ol>
  )
}
