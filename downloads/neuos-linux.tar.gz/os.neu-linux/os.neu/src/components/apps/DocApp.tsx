import { useState } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import { useNeu } from '../../state/store'

export function DocApp({ text = '' }: { text?: string }) {
  const neu = useNeu()
  const [title, setTitle] = useState('Untitled document')
  const [body, setBody] = useState(text)
  const [saved, setSaved] = useState(false)

  return (
    <div className="doc-app">
      <AppToolbar
        title={title}
        saved={saved}
        onSave={() => setSaved(true)}
        onAssist={async (instruction) => {
          const result = await assistOffice({
            model: neu.officeModel,
            app: 'doc',
            instruction,
            content: `${title}\n${body}`,
          })
          if (result.ok && result.text) {
            const [first, ...rest] = result.text.split('\n')
            setTitle(first.replace(/^#+\s*/, '') || title)
            setBody(rest.join('\n').trim() || result.text)
          }
        }}
      />
      <input
        className="sheet-name"
        value={title}
        onChange={(e) => {
          setTitle(e.target.value)
          setSaved(false)
        }}
        aria-label="Document title"
        data-ui="title"
      />
      <textarea
        className="doc-editor"
        data-ui="editor"
        aria-label="Body field"
        value={body}
        onChange={(e) => {
          setBody(e.target.value)
          setSaved(false)
        }}
        placeholder="Start writing…"
      />
    </div>
  )
}
