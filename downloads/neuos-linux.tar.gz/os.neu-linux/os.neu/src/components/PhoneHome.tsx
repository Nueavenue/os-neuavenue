import { WEB_HOME } from '../engine/browser'
import { useNeu } from '../state/store'
import { useI18n } from '../i18n/LocaleContext'
import { trackEvent } from '../engine/auth'
import { BrandTitle } from './BrandTitle'
import { StepNav } from './StepNav'

export function PhoneHome() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const apps = [
    { id: 'doc', glyph: 'W', label: locale === 'ko' ? '문서' : 'Docs', run: () => neu.openOffice('doc') },
    { id: 'sheet', glyph: 'X', label: locale === 'ko' ? '시트' : 'Sheets', run: () => neu.openOffice('sheet') },
    { id: 'slides', glyph: 'P', label: locale === 'ko' ? '슬라이드' : 'Slides', run: () => neu.openOffice('slides') },
    { id: 'web', glyph: '⌁', label: copy.web, run: () => neu.openWeb(WEB_HOME) },
    { id: 'health', glyph: '○', label: copy.health, run: () => neu.go('post') },
    { id: 'layers', glyph: '▣', label: copy.layers, run: () => neu.go('studio') },
  ] as const

  return (
    <div className="landing">
      <div className="hero-block">
        <BrandTitle />
        <p>{copy.homeIntro}</p>
      </div>
      <div className="app-grid">
        {apps.map((app) => (
          <button
            key={app.id}
            type="button"
            className="app-tile"
            onClick={() => {
              void trackEvent('click', 'landing', app.id)
              app.run()
            }}
          >
            <span className="glyph">{app.glyph}</span>
            {app.label}
          </button>
        ))}
      </div>
      {!neu.network.online ? (
        <p className="offline-note">{copy.offlineHint}</p>
      ) : (
        <p className="offline-note" style={{ color: 'var(--mint)', borderColor: 'var(--mint)' }}>
          {copy.onlineHint}
        </p>
      )}
      <StepNav onBack={() => neu.go('announce')} />
    </div>
  )
}
