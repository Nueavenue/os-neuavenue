import { useState } from 'react'
import { groupByDay, type VisitRecord } from '../engine/browseLedger'

type BrowseHistoryPanelProps = {
  visits: VisitRecord[]
  ko: boolean
  locale: string
  onOpen: (url: string) => void
  onAdd: (url: string, title: string) => void
  onEdit: (id: string, patch: { url: string; title: string }) => void
  onDelete: (id: string) => void
}

export function BrowseHistoryPanel({ visits, ko, locale, onOpen, onAdd, onEdit, onDelete }: BrowseHistoryPanelProps) {
  const [url, setUrl] = useState('')
  const [title, setTitle] = useState('')
  const [editId, setEditId] = useState<string | null>(null)
  const [draft, setDraft] = useState({ url: '', title: '' })
  const groups = groupByDay(visits, locale)

  return (
    <div className="browser-panel">
      <div className="browser-panel-head">
        <b>{ko ? '방문 기록' : 'History'}</b>
      </div>
      <form
        className="browser-panel-add"
        onSubmit={(event) => {
          event.preventDefault()
          if (!url.trim()) return
          onAdd(url.trim(), title.trim())
          setUrl('')
          setTitle('')
        }}
      >
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={ko ? '제목' : 'Title'} />
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={ko ? '주소 추가' : 'Add address'} />
        <button type="submit" className="btn">
          {ko ? '추가' : 'Add'}
        </button>
      </form>
      {groups.length ? (
        groups.map((group) => (
          <section key={group.key} className="browser-day">
            <h4>{group.day}</h4>
            {group.items.map((row) =>
              editId === row.id ? (
                <form
                  key={row.id}
                  className="browser-edit"
                  onSubmit={(event) => {
                    event.preventDefault()
                    onEdit(row.id, draft)
                    setEditId(null)
                  }}
                >
                  <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
                  <input value={draft.url} onChange={(e) => setDraft({ ...draft, url: e.target.value })} />
                  <button type="submit" className="btn">
                    {ko ? '수정' : 'Save'}
                  </button>
                  <button type="button" className="btn ghost" onClick={() => setEditId(null)}>
                    {ko ? '취소' : 'Cancel'}
                  </button>
                </form>
              ) : (
                <div key={row.id} className="browser-row">
                  <button type="button" className="browser-row-main" onClick={() => onOpen(row.url)}>
                    <strong>{row.title}</strong>
                    <span>{row.url}</span>
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    aria-label={ko ? '수정' : 'Edit'}
                    onClick={() => {
                      setEditId(row.id)
                      setDraft({ url: row.url, title: row.title })
                    }}
                  >
                    ✎
                  </button>
                  <button type="button" className="icon-btn" aria-label={ko ? '삭제' : 'Delete'} onClick={() => onDelete(row.id)}>
                    ×
                  </button>
                </div>
              ),
            )}
          </section>
        ))
      ) : (
        <p className="dock-hint">{ko ? '아직 방문 기록이 없습니다.' : 'No history yet.'}</p>
      )}
    </div>
  )
}
