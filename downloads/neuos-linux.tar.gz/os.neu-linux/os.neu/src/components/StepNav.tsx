import { useI18n } from '../i18n/LocaleContext'

function ChevronLeft() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M15 5l-8 7 8 7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function ChevronRight() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M9 5l8 7-8 7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

type StepNavProps = {
  onBack?: () => void
  onNext?: () => void
  nextDisabled?: boolean
  backDisabled?: boolean
  className?: string
}

export function StepNav({ onBack, onNext, nextDisabled, backDisabled, className }: StepNavProps) {
  const { locale } = useI18n()
  const backLabel = locale === 'ko' ? '뒤로' : 'Back'
  const nextLabel = locale === 'ko' ? '다음' : 'Next'

  return (
    <div className={`row-actions step-nav${className ? ` ${className}` : ''}`}>
      <button
        type="button"
        className="step-nav-btn"
        onClick={onBack}
        disabled={!onBack || backDisabled}
        aria-label={backLabel}
        title={backLabel}
      >
        <ChevronLeft />
      </button>
      <button
        type="button"
        className="step-nav-btn next"
        onClick={onNext}
        disabled={!onNext || nextDisabled}
        aria-label={nextLabel}
        title={nextLabel}
      >
        <ChevronRight />
      </button>
    </div>
  )
}
