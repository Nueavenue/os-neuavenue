import { useState, type ReactNode } from 'react'
import { OFFICE_MODELS } from '../engine/office'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

type AppToolbarProps = {
  title: string
  onSave: () => void
  saved?: boolean
  onAssist?: (instruction: string) => Promise<void>
  extra?: ReactNode
}

export function AppToolbar({ title, onSave, saved, onAssist, extra }: AppToolbarProps) {
  const neu = useNeu()
  const { locale } = useI18n()
  const [ask, setAsk] = useState('')
  const [busy, setBusy] = useState(false)
  const ko = locale === 'ko'

  return (
    <div className="app-toolbar">
      <div className="app-toolbar-left">
        <button type="button" className="icon-btn" aria-label={ko ? '이전' : 'Back'} title={ko ? '이전 화면' : 'Back'} onClick={neu.goBack}>
          ←
        </button>
        <button type="button" className="icon-btn" aria-label={ko ? '홈' : 'Home'} title={ko ? '홈' : 'Home'} onClick={neu.goHome}>
          ⌂
        </button>
        <strong data-ui="title">{title}</strong>
      </div>
      <div className="app-toolbar-right">
        <select
          className="model-select"
          value={neu.officeModel}
          onChange={(e) => neu.setOfficeModel(e.target.value)}
          aria-label={ko ? 'AI 모델' : 'AI model'}
        >
          {OFFICE_MODELS.map((model) => (
            <option key={model.id} value={model.id}>
              {model.label}
            </option>
          ))}
        </select>
        {onAssist ? (
          <form
            className="ai-ask"
            onSubmit={(e) => {
              e.preventDefault()
              const line = ask.trim()
              if (!line || busy) return
              setBusy(true)
              void onAssist(line).finally(() => {
                setBusy(false)
                setAsk('')
              })
            }}
          >
            <input
              value={ask}
              onChange={(e) => setAsk(e.target.value)}
              placeholder={ko ? 'AI에게 시키기' : 'Ask AI'}
            />
            <button type="submit" className="save-btn" disabled={busy}>
              {busy ? '…' : 'AI'}
            </button>
          </form>
        ) : null}
        {extra}
        <button type="button" className="save-btn" data-ui="save" aria-label="Save" onClick={onSave}>
          {saved ? (ko ? '저장됨' : 'Saved') : ko ? '저장' : 'Save'}
        </button>
      </div>
    </div>
  )
}
