import { useState, type ReactNode } from 'react'
import { AiConnectDialog } from './AiConnectDialog'
import { ModelSelect } from './ModelSelect'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

type AppToolbarProps = {
  title: string
  onSave: () => void
  saved?: boolean
  onAssist?: (instruction: string) => Promise<void>
  extra?: ReactNode
}

export function AppToolbar({ title, onSave, saved, onAssist, extra }: AppToolbarProps) {
  const neu = useNeu()
  const { locale } = useI18n()
  const [ask, setAsk] = useState('')
  const [busy, setBusy] = useState(false)
  const [waitSec, setWaitSec] = useState(0)
  const [connectOpen, setConnectOpen] = useState(false)
  const ko = locale === 'ko'

  return (
    <div className="app-toolbar">
      <div className="app-toolbar-left">
        <button type="button" className="icon-btn" aria-label={ko ? '이전' : 'Back'} title={ko ? '이전 화면' : 'Back'} onClick={neu.goBack}>
          ←
        </button>
        <button type="button" className="icon-btn" aria-label={ko ? '홈' : 'Home'} title={ko ? '홈' : 'Home'} onClick={neu.goHome}>
          ⌂
        </button>
        <strong data-ui="title">{title}</strong>
      </div>
      <div className="app-toolbar-right">
        <ModelSelect />
        <button type="button" className="doc-skin-btn" onClick={() => setConnectOpen(true)}>
          {ko ? 'AI 연결' : 'Connect AI'}
        </button>
        {onAssist ? (
          <form
            className="ai-ask"
            onSubmit={(e) => {
              e.preventDefault()
              const line = ask.trim()
              if (!line || busy) return
              setBusy(true)
              setWaitSec(0)
              const tick = window.setInterval(() => setWaitSec((n) => n + 1), 1000)
              void onAssist(line)
                .catch(() => {
                  if (neu.officeModel.startsWith('gpt-')) setConnectOpen(true)
                })
                .finally(() => {
                  window.clearInterval(tick)
                  setBusy(false)
                  setWaitSec(0)
                  setAsk('')
                })
            }}
          >
            <input
              value={ask}
              onChange={(e) => setAsk(e.target.value)}
              placeholder={busy ? (ko ? `로딩 중… ${waitSec}s` : `Loading… ${waitSec}s`) : ko ? 'AI에게 시키기' : 'Ask AI'}
              disabled={busy}
            />
            <button type="submit" className="save-btn" disabled={busy}>
              {busy ? `${waitSec}s` : 'AI'}
            </button>
          </form>
        ) : null}
        {extra}
        <button type="button" className="save-btn" data-ui="save" aria-label="Save" onClick={onSave}>
          {saved ? (ko ? '저장됨' : 'Saved') : ko ? '저장' : 'Save'}
        </button>
      </div>
      <AiConnectDialog open={connectOpen} preferModel={neu.officeModel} onClose={() => setConnectOpen(false)} />
    </div>
  )
}
