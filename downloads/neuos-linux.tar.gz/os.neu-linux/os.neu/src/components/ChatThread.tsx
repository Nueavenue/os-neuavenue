import { useEffect, useRef, useState } from 'react'
import { useI18n } from '../i18n/LocaleContext'

export type ChatBubble = {
  id: string
  role: 'user' | 'neu'
  text: string
  pending?: boolean
  typing?: boolean
}

function TypeLine({ text, pending, typing }: { text: string; pending?: boolean; typing?: boolean }) {
  const [shown, setShown] = useState(typing ? '' : text)

  useEffect(() => {
    if (pending && !text) {
      setShown('')
      return
    }
    if (!typing) {
      setShown(text)
      return
    }
    let i = 0
    setShown('')
    const id = window.setInterval(() => {
      i += 1
      setShown(text.slice(0, i))
      if (i >= text.length) window.clearInterval(id)
    }, 16)
    return () => window.clearInterval(id)
  }, [text, pending, typing])

  if (pending && !shown) {
    return (
      <p className="wa-dots" aria-label="waiting">
        <span>.</span>
        <span>.</span>
        <span>.</span>
      </p>
    )
  }

  return (
    <p>
      {shown}
      {typing && shown.length < text.length ? <span className="wa-caret">▍</span> : null}
    </p>
  )
}

export function ChatThread({ turns, empty }: { turns: ChatBubble[]; empty?: string }) {
  const scroller = useRef<HTMLDivElement>(null)
  const { locale } = useI18n()
  const you = locale === 'ko' ? '나' : 'You'

  useEffect(() => {
    const node = scroller.current
    if (!node) return
    node.scrollTop = node.scrollHeight
  }, [turns])

  if (!turns.length) {
    return empty ? <p className="wa-empty">{empty}</p> : null
  }
  return (
    <div className="wa-thread" aria-live="polite" ref={scroller}>
      {turns.map((turn) => (
        <div key={turn.id} className={`wa-row ${turn.role}`}>
          <div className={`wa-bubble ${turn.role}`}>
            <TypeLine text={turn.text} pending={turn.pending} typing={turn.typing} />
            <span className="wa-meta">{turn.role === 'user' ? you : 'os.neu'}</span>
          </div>
        </div>
      ))}
    </div>
  )
}
