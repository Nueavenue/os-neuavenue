import { CRAFT_LAUNCH_MISSING } from '../engine/craftLaunch'
import { useCraftLaunchTiles } from './useCraftLaunchTiles'

type CraftLaunchTilesProps = {
  kind: 'shortcut' | 'tile'
  onTrack?: (id: string) => void
  /** 006: openWeb only. Never openOffice / spawn. */
  onLaunch?: (href: string, id: string) => void
}

export function CraftLaunchTiles({ kind, onTrack, onLaunch }: CraftLaunchTilesProps) {
  const tiles = useCraftLaunchTiles()
  return (
    <>
      {tiles.map((tile) => {
        const missing = !tile.ready
        const spoken = missing ? `${tile.label} · ${CRAFT_LAUNCH_MISSING}` : tile.label
        return (
          <button
            key={tile.id}
            type="button"
            className={kind === 'tile' ? 'app-tile' : 'office-shortcut'}
            disabled={missing}
            title={missing ? CRAFT_LAUNCH_MISSING : tile.href ? tile.label : `${tile.label} · CLI`}
            aria-label={spoken}
            onClick={(event) => {
              event.preventDefault()
              onTrack?.(tile.id)
              if (missing || !tile.href || !onLaunch) return
              onLaunch(tile.href, tile.id)
            }}
          >
            {kind === 'tile' ? <span className="glyph">{tile.glyph}</span> : null}
            {tile.label}
          </button>
        )
      })}
    </>
  )
}
