import type { DriverState } from '../types'

export function DriverCursor({ driver }: { driver: DriverState }) {
  if (!driver.cursor.visible) return null
  return (
    <div
      className="cursor"
      style={{ left: driver.cursor.x, top: driver.cursor.y }}
      aria-hidden
    />
  )
}
