import { useAiPrefs } from '../hooks/useAiPrefs'
import { shownModelOptions } from '../engine/aiPrefs'
import { openSettings } from '../engine/settingsBus'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/neuContext'

const MORE = '__osneu-more-models'

type Props = {
  className?: string
  /** Called after the model changes (for example to open the connect dialog). */
  onPicked?: (model: string) => void
}

/** Office model dropdown limited to Settings › AI & Usage › models shown on screen. */
export function ModelSelect({ className = 'model-select', onPicked }: Props) {
  const neu = useNeu()
  const prefs = useAiPrefs()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const options = shownModelOptions(prefs, neu.officeModel)

  return (
    <select
      className={className}
      value={neu.officeModel}
      onChange={(e) => {
        const next = e.target.value
        if (next === MORE) {
          openSettings('ai')
          return
        }
        neu.setOfficeModel(next)
        onPicked?.(next)
      }}
      aria-label={ko ? 'AI 모델' : 'AI model'}
    >
      {options.map((row) => (
        <option key={row.id} value={row.id}>
          {row.label}
          {prefs.shown.includes(row.id) ? '' : ko ? ' · 목록 밖' : ' · not in list'}
        </option>
      ))}
      <option value={MORE}>{ko ? '＋ 설정에서 모델 고르기…' : '+ Choose models in Settings…'}</option>
    </select>
  )
}
