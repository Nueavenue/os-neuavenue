#!/usr/bin/env node
// Wi-Fi join for the os.neu USB seat (JeOS only). Used by the Wi-Fi step of
// the boot setup screen (electron/wifi.html) and from the console.
//
//   node osneu-wifi.mjs up        load the staged Wi-Fi drivers, start wpa_supplicant
//   node osneu-wifi.mjs scan      JSON list of networks (strongest per SSID)
//   node osneu-wifi.mjs connect   stdin JSON {"ssid": "...", "password": "..."}
//   node osneu-wifi.mjs status    JSON {iface, state, ssid, ip, online}
//
// The password never goes on a command line (the boot recorder snapshots ps).
// It lives only in /run/osneu-wifi/wpa.conf (RAM, mode 600): never on the
// stick, in /tmp logs, or on the ESP. DHCP reuses /tmp/osneu-udhcpc.sh from
// usb-screen-jeos.sh (same hook osneu-netdiag.mjs uses).

import { spawnSync } from 'node:child_process'
import { pbkdf2Sync } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, readFileSync, readdirSync, readlinkSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const JEOS = process.env.NEUOS_JEOS === '1' && existsSync('/etc/neuos-release')
const RUN = '/run/osneu-wifi'
const CONF = `${RUN}/wpa.conf`
const CTRL = `${RUN}/ctrl`
const KMOD = '/opt/neuos/kmod/wifi'
const LOG = '/tmp/osneu-wifi.log'
const HOOK = '/tmp/osneu-udhcpc.sh'

function log(line) {
  try {
    writeFileSync(LOG, `${new Date().toISOString()} ${line}\n`, { flag: 'a' })
  } catch {
    /* /tmp missing */
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function bin(names) {
  for (const n of names) if (existsSync(n)) return n
  return ''
}
const WPA = bin(['/usr/sbin/wpa_supplicant', '/sbin/wpa_supplicant', '/usr/bin/wpa_supplicant'])
const WPA_CLI = bin(['/usr/sbin/wpa_cli', '/sbin/wpa_cli', '/usr/bin/wpa_cli'])
const BB = bin(['/usr/bin/busybox'])

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: 'utf8', timeout: 15_000, ...opts })
  return { ok: r.status === 0, out: (r.stdout || '').trim(), err: (r.stderr || '').trim() }
}

const bb = (applet, args, opts) => (BB ? run(BB, [applet, ...args], opts) : run(applet, args, opts))

export function wifiIfaces() {
  let names = []
  try {
    names = readdirSync('/sys/class/net')
  } catch {
    return []
  }
  return names
    .filter((n) => existsSync(`/sys/class/net/${n}/wireless`) || existsSync(`/sys/class/net/${n}/phy80211`))
    .map((n) => {
      let driver = ''
      try {
        driver = path.basename(readlinkSync(`/sys/class/net/${n}/device/driver`))
      } catch {
        driver = ''
      }
      return { name: n, driver }
    })
}

function ipv4(name) {
  return ((os.networkInterfaces()[name] || []).find((a) => a.family === 'IPv4') || {}).address || ''
}

function defaultRouteIface() {
  try {
    for (const line of readFileSync('/proc/net/route', 'utf8').split('\n').slice(1)) {
      const f = line.trim().split(/\s+/)
      if (f[1] === '00000000') return f[0]
    }
  } catch {
    /* no /proc */
  }
  return ''
}

function loadDrivers() {
  const order = `${KMOD}/load-order`
  if (!existsSync(order)) return 'no staged Wi-Fi drivers'
  try {
    writeFileSync('/sys/module/firmware_class/parameters/path', '/opt/neuos/firmware')
  } catch {
    /* read-only or missing */
  }
  const failed = []
  for (const ko of readFileSync(order, 'utf8').split('\n').map((s) => s.trim()).filter(Boolean)) {
    const mod = ko.replace(/\.ko$/, '').replace(/-/g, '_')
    if (existsSync(`/sys/module/${mod}`)) continue
    const r = bb('insmod', [`${KMOD}/${ko}`])
    if (!r.ok && !/exists/i.test(r.err)) failed.push(`${ko}:${r.err.split('\n')[0] || 'fail'}`)
  }
  return failed.length ? `insmod ${failed.join(' ')}` : 'ok'
}

function cli(iface, args) {
  return run(WPA_CLI, ['-p', CTRL, '-i', iface, ...args], { timeout: 8000 })
}

const supplicantUp = (iface) => cli(iface, ['ping']).out === 'PONG'
const baseConf = () => `ctrl_interface=${CTRL}\nupdate_config=0\n`

function writeConf(body) {
  mkdirSync(RUN, { recursive: true, mode: 0o700 })
  writeFileSync(CONF, body, { mode: 0o600 })
  chmodSync(CONF, 0o600)
}

export async function up() {
  if (!JEOS) return { ok: false, error: 'not a JeOS boot (host Wi-Fi is managed by Ubuntu)' }
  if (!WPA || !WPA_CLI) return { ok: false, error: 'wpa_supplicant missing on this stick' }
  let drivers = 'already loaded'
  let list = wifiIfaces()
  if (!list.length) {
    drivers = loadDrivers()
    for (let i = 0; i < 20 && !list.length; i++) {
      await sleep(500)
      list = wifiIfaces()
    }
  }
  if (!list.length) return { ok: false, error: `no Wi-Fi adapter found (${drivers})` }
  const iface = list[0].name
  bb('ip', ['link', 'set', iface, 'up'])
  if (!supplicantUp(iface)) {
    if (!existsSync(CONF)) writeConf(baseConf())
    const r = run(WPA, ['-B', '-i', iface, '-c', CONF, '-D', 'nl80211,wext'])
    for (let i = 0; i < 10 && !supplicantUp(iface); i++) await sleep(300)
    // The boot-time `up` and the setup screen can race; the loser sees the
    // control socket already taken by a working supplicant.
    if (!supplicantUp(iface)) return { ok: false, error: `wpa_supplicant: ${(r.err || r.out).split('\n')[0] || 'did not start'}` }
  }
  log(`UP ${iface} driver=${list[0].driver} drivers=${drivers}`)
  return { ok: true, iface, driver: list[0].driver }
}

export function security(flags) {
  if (/SAE/.test(flags) && !/PSK/.test(flags)) return 'WPA3'
  if (/EAP/.test(flags)) return 'Enterprise'
  if (/PSK|WPA/.test(flags)) return 'WPA2'
  if (/WEP/.test(flags)) return 'WEP'
  return 'Open'
}

// wpa_cli prints SSIDs with printf-style escapes (\xNN).
export function unescapeSsid(s) {
  const bytes = []
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '\\' && s[i + 1] === 'x' && /^[0-9a-f]{2}$/i.test(s.slice(i + 2, i + 4))) {
      bytes.push(parseInt(s.slice(i + 2, i + 4), 16))
      i += 3
    } else if (s[i] === '\\' && i + 1 < s.length) {
      bytes.push(s.charCodeAt(++i))
    } else {
      bytes.push(...Buffer.from(s[i], 'utf8'))
    }
  }
  return Buffer.from(bytes).toString('utf8')
}

export function parseScan(text) {
  const best = new Map()
  for (const row of text.split('\n').slice(1).filter(Boolean)) {
    const [bssid, freq, signal, flags, ...rest] = row.split('\t')
    const ssid = unescapeSsid(rest.join('\t'))
    if (!ssid) continue
    const net = { ssid, signal: Number(signal), freq: Number(freq), security: security(flags || ''), bssid }
    const prev = best.get(ssid)
    if (!prev || net.signal > prev.signal) best.set(ssid, net)
  }
  return [...best.values()].sort((a, b) => b.signal - a.signal)
}

export async function scan() {
  const u = await up()
  if (!u.ok) return u
  cli(u.iface, ['scan'])
  let text = ''
  for (let i = 0; i < 8; i++) {
    await sleep(1000)
    text = cli(u.iface, ['scan_results']).out
    if (i >= 2 && text.split('\n').length > 1) break
  }
  const networks = parseScan(text)
  log(`SCAN ${u.iface} ${networks.length} networks`)
  return { ok: true, iface: u.iface, networks }
}

function ensureHook() {
  if (existsSync(HOOK)) return
  writeFileSync(
    HOOK,
    [
      '#!/usr/bin/sh',
      'case "$1" in',
      '  deconfig) ip addr flush dev "$interface" 2>/dev/null; ip link set "$interface" up ;;',
      '  bound|renew)',
      '    ip addr flush dev "$interface" 2>/dev/null',
      '    ip addr add "$ip/${mask:-24}" dev "$interface"',
      '    for r in $router; do ip route add default via "$r" dev "$interface" 2>/dev/null; break; done',
      '    if [ -n "$dns" ]; then : > /tmp/osneu-resolv.dhcp; for d in $dns; do echo "nameserver $d" >> /tmp/osneu-resolv.dhcp; done; cat /tmp/osneu-resolv.dhcp > /etc/resolv.conf 2>/dev/null || true; fi',
      '    ;;',
      'esac',
      '',
    ].join('\n'),
    { mode: 0o755 },
  )
}

export function networkBlock(ssid, password) {
  let net = `network={\n  ssid=${Buffer.from(ssid, 'utf8').toString('hex')}\n  scan_ssid=1\n`
  if (password) {
    const psk = pbkdf2Sync(password, ssid, 4096, 32, 'sha1').toString('hex')
    net += `  key_mgmt=WPA-PSK WPA-PSK-SHA256 SAE\n  psk=${psk}\n  ieee80211w=1\n`
    if (!/["\n\r\\]/.test(password)) net += `  sae_password="${password}"\n`
  } else {
    net += '  key_mgmt=NONE\n'
  }
  return `${net}}\n`
}

export async function connect(input) {
  const ssid = String(input.ssid || '')
  const password = String(input.password || '')
  if (!ssid) return { ok: false, error: 'no network selected' }
  if (password && (password.length < 8 || password.length > 63)) return { ok: false, error: 'Wi-Fi password must be 8–63 characters' }
  const u = await up()
  if (!u.ok) return u
  writeConf(baseConf() + networkBlock(ssid, password))
  cli(u.iface, ['reconfigure'])
  let state = ''
  for (let i = 0; i < 40; i++) {
    await sleep(500)
    state = (cli(u.iface, ['status']).out.match(/^wpa_state=(.*)$/m) || [])[1] || ''
    if (state === 'COMPLETED') break
  }
  if (state !== 'COMPLETED') {
    log(`CONNECT ${u.iface} failed state=${state || 'none'}`)
    const pw = state === '4WAY_HANDSHAKE' || state === 'DISCONNECTED' || state === 'SCANNING'
    return { ok: false, iface: u.iface, state, error: pw ? 'wrong password, or the network refused this device' : `could not join (state ${state || 'none'})` }
  }
  ensureHook()
  const dh = bb('udhcpc', ['-i', u.iface, '-n', '-q', '-t', '6', '-T', '2', '-s', HOOK], { timeout: 25_000 })
  const addr = ipv4(u.iface)
  if (!dh.ok || !addr) {
    log(`CONNECT ${u.iface} joined but no DHCP lease`)
    return { ok: false, iface: u.iface, state, error: 'joined the network but the router gave no address (DHCP)' }
  }
  log(`CONNECT ${u.iface} ok ip=${addr}`)
  return { ok: true, iface: u.iface, ip: addr, online: defaultRouteIface() !== '' }
}

export async function status() {
  const list = wifiIfaces()
  const iface = list[0]?.name || ''
  let state = ''
  let ssid = ''
  if (iface && WPA_CLI && supplicantUp(iface)) {
    const st = cli(iface, ['status']).out
    state = (st.match(/^wpa_state=(.*)$/m) || [])[1] || ''
    ssid = (st.match(/^ssid=(.*)$/m) || [])[1] || ''
  }
  const route = defaultRouteIface()
  return { ok: true, jeos: JEOS, iface, driver: list[0]?.driver || '', state, ssid: ssid ? unescapeSsid(ssid) : '', ip: iface ? ipv4(iface) : '', online: route !== '', route }
}

function readStdin() {
  try {
    return JSON.parse(readFileSync(0, 'utf8') || '{}')
  } catch {
    return {}
  }
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname)
if (isMain) {
  const cmd = process.argv[2] || 'status'
  const done = (obj) => process.stdout.write(`${JSON.stringify(obj)}\n`)
  try {
    if (cmd === 'up') done(await up())
    else if (cmd === 'scan') done(await scan())
    else if (cmd === 'connect') done(await connect(readStdin()))
    else if (cmd === 'status') done(await status())
    else {
      done({ ok: false, error: `unknown command ${cmd}` })
      process.exitCode = 2
    }
  } catch (err) {
    done({ ok: false, error: String(err && err.message ? err.message : err).split('\n')[0] })
    process.exitCode = 1
  }
}
