#!/usr/bin/env node
/**
 * os.neu boot diagnostics for the USB seat, in this order:
 *   link (wired, Wi-Fi) → DNS → clock · proxy · TLS → app.neu API →
 *   daf.neu browser runtime → LLM key + permission → first prompt.
 *
 * On a JeOS boot it repairs only RAM state: DHCP retry on a cable that came
 * up late, fallback DNS when the DHCP server does not answer, and the clock
 * from an HTTP Date header (TLS rejects every certificate on a wrong RTC).
 * On a host desktop it only reports. Key values are never printed or logged.
 *
 *   osneu-netdiag.mjs connect|ai|prompt|all|watch|note [--no-fix] [--quiet] [--root DIR]
 *   exit 0 = all ok · 1 = warnings · 2 = a failure
 */
import { spawnSync } from 'node:child_process'
import dns from 'node:dns'
import { accessSync, appendFileSync, constants, existsSync, readFileSync, readdirSync, readlinkSync, writeFileSync } from 'node:fs'
import http from 'node:http'
import https from 'node:https'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { OLLAMA_HOST, completeText, readLlmSettings, userOpenAiKey } from '../boot/localLlm.mjs'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const REPO = path.resolve(HERE, '..')
const argv = process.argv.slice(2)
const MODE = argv[0] && !argv[0].startsWith('--') ? argv[0] : 'all'
const flag = (name) => argv.includes(name)
const opt = (name) => {
  const k = argv.indexOf(name)
  return k >= 0 ? argv[k + 1] : undefined
}
const JEOS = process.env.NEUOS_JEOS === '1' && existsSync('/etc/neuos-release')
const FIX = JEOS && !flag('--no-fix')
const QUIET = flag('--quiet')
const LLM_ROOT = opt('--root') || REPO
const DIR = process.env.NEUOS_NETDIAG_DIR || (JEOS ? '/tmp' : os.tmpdir())
const JSON_OUT = path.join(DIR, JEOS ? 'osneu-netdiag.json' : 'osneu-netdiag-host.json')
const LOG = path.join(DIR, JEOS ? 'osneu-netdiag.log' : 'osneu-netdiag-host.log')
const STATUS_ENV = '/tmp/osneu-input-status.env'
const APP_API = 'https://os.neuavenue.com/api/health'
const APP_WEB = 'https://app.neuavenue.com/'
const DAF_WEB = 'https://www.neuavenue.com/'
const RANK = { ok: 0, skip: 0, warn: 1, fail: 2 }

// ---------- report ----------

function loadReport() {
  try {
    return JSON.parse(readFileSync(JSON_OUT, 'utf8'))
  } catch {
    return { checks: {} }
  }
}
const report = loadReport()
report.checks ||= {}
report.jeos = JEOS
report.boot = readText('/proc/sys/kernel/random/boot_id').slice(0, 8) || 'host'
const touched = []

function readText(p) {
  try {
    return readFileSync(p, 'utf8').trim()
  } catch {
    return ''
  }
}

function serial(line) {
  if (process.env.NEUOS_VIRT_TEST !== '1') return
  try {
    appendFileSync('/dev/ttyS0', `${line}\n`)
  } catch {
    /* no UART */
  }
}

function set(id, state, detail, extra = {}) {
  report.checks[id] = { state, detail, at: new Date().toISOString(), ...extra }
  touched.push(id)
  const line = `NETDIAG ${id.toUpperCase()} ${state.toUpperCase()} ${detail}`
  if (!QUIET) console.log(line)
  try {
    appendFileSync(LOG, `${new Date().toISOString()} ${line}\n`)
  } catch {
    /* log dir read-only */
  }
  if (JEOS) {
    try {
      appendFileSync(STATUS_ENV, `NETDIAG_${id.toUpperCase()}=${state} ${detail}\n`)
    } catch {
      /* status file belongs to usb-screen-jeos.sh */
    }
  }
  serial(line)
  return state
}

function save() {
  report.updated = new Date().toISOString()
  try {
    writeFileSync(JSON_OUT, JSON.stringify(report, null, 2))
  } catch {
    /* report still printed */
  }
}

const state = (id) => report.checks[id]?.state

// ---------- helpers ----------

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function withTimeout(p, ms, label) {
  return Promise.race([p, sleep(ms).then(() => Promise.reject(Object.assign(new Error(`${label} timeout`), { code: 'TIMEOUT' })))])
}

/** One request, no redirects. Never pass headers that should not reach a log. */
function request(url, { method = 'GET', headers = {}, timeout = 6000, body = 4096 } = {}) {
  const t0 = Date.now()
  const lib = url.startsWith('https:') ? https : http
  return new Promise((resolve) => {
    const req = lib.request(url, { method, headers, timeout, agent: false }, (res) => {
      const chunks = []
      let size = 0
      let cert = null
      try {
        cert = res.socket.getPeerCertificate?.() || null
      } catch {
        cert = null
      }
      res.on('data', (c) => {
        if (size < body) chunks.push(c)
        size += c.length
      })
      res.on('end', () =>
        resolve({
          ok: true,
          status: res.statusCode,
          headers: res.headers,
          text: Buffer.concat(chunks).toString('utf8').slice(0, body),
          ms: Date.now() - t0,
          issuer: cert?.issuer?.O || cert?.issuer?.CN || '',
        }),
      )
    })
    req.on('timeout', () => req.destroy(Object.assign(new Error('timeout'), { code: 'TIMEOUT' })))
    req.on('error', (err) => resolve({ ok: false, code: err.code || err.message, ms: Date.now() - t0 }))
    req.end()
  })
}

function nameservers() {
  return readText('/etc/resolv.conf')
    .split('\n')
    .map((l) => /^nameserver\s+(\S+)/.exec(l.trim())?.[1])
    .filter(Boolean)
}

function ifaces() {
  let names = []
  try {
    names = readdirSync('/sys/class/net')
  } catch {
    return []
  }
  const addrs = os.networkInterfaces()
  return names
    .filter((n) => n !== 'lo' && existsSync(`/sys/class/net/${n}/device`))
    .map((n) => {
      let driver = ''
      try {
        driver = path.basename(readlinkSync(`/sys/class/net/${n}/device/driver`))
      } catch {
        driver = ''
      }
      return {
        name: n,
        wireless: existsSync(`/sys/class/net/${n}/wireless`) || existsSync(`/sys/class/net/${n}/phy80211`) || /^wl/.test(n),
        carrier: readText(`/sys/class/net/${n}/carrier`) || '?',
        oper: readText(`/sys/class/net/${n}/operstate`) || '?',
        driver,
        ipv4: (addrs[n] || []).filter((a) => a.family === 'IPv4').map((a) => a.address),
      }
    })
}

function defaultRouteIface() {
  for (const line of readText('/proc/net/route').split('\n').slice(1)) {
    const f = line.trim().split(/\s+/)
    if (f[1] === '00000000') return f[0]
  }
  return ''
}

// ---------- 1. link ----------

function dhcpRetry(name) {
  const hook = '/tmp/osneu-udhcpc.sh'
  const args = ['-i', name, '-n', '-q', '-t', '4', '-T', '1']
  if (existsSync(hook)) args.push('-s', hook)
  const r = spawnSync('udhcpc', args, { timeout: 12_000, encoding: 'utf8' })
  return r.status === 0
}

function checkLink() {
  let list = ifaces()
  let route = defaultRouteIface()
  const up = () => list.find((i) => i.name === route && i.ipv4.length)
  let fixed = ''
  if (!up() && FIX) {
    for (const i of list.filter((x) => !x.wireless && x.carrier === '1' && !x.ipv4.length)) {
      if (dhcpRetry(i.name)) {
        fixed = ` (fixed: DHCP retry on ${i.name})`
        break
      }
    }
    list = ifaces()
    route = defaultRouteIface()
  }
  const wired = list.filter((i) => !i.wireless)
  const live = up()
  if (live) {
    return set('link', 'ok', `${live.name} ${live.ipv4[0]} ${live.wireless ? 'Wi-Fi' : 'wired'} driver=${live.driver || '?'} default-route${fixed}`, {
      iface: live.name,
      wireless: live.wireless,
    })
  }
  if (!wired.length) return set('link', 'fail', 'no wired adapter (no NIC driver loaded)', { ifaces: list.map((i) => i.name) })
  const w = wired.map((i) => `${i.name}:carrier=${i.carrier}${i.ipv4.length ? `:${i.ipv4[0]}` : ''}`).join(' ')
  if (wired.every((i) => i.carrier !== '1')) return set('link', 'fail', `${w} — no cable (plug in a network cable)`)
  if (wired.some((i) => i.ipv4.length)) return set('link', 'fail', `${w} — address but no default route (router/gateway missing)`)
  return set('link', 'fail', `${w} — cable in but no DHCP lease (router did not answer)`)
}

function checkWifi() {
  const wl = ifaces().filter((i) => i.wireless)
  const linkOk = state('link') === 'ok'
  const joined = wl.find((i) => i.ipv4.length)
  if (joined) return set('wifi', 'ok', `${joined.name} ${joined.ipv4[0]} driver=${joined.driver || '?'}`)
  if (wl.length) {
    const names = wl.map((i) => `${i.name}(${i.driver || '?'})`).join(' ')
    return set('wifi', linkOk ? 'skip' : 'warn', `${names} present, not joined — choose a network in the os.neu Wi-Fi window (Ctrl+Alt+W)`)
  }
  return set('wifi', linkOk ? 'skip' : 'warn', 'no Wi-Fi adapter driver loaded on this boot')
}

// ---------- 2. DNS ----------

async function lookupAll(names) {
  const out = []
  for (const name of names) {
    const t0 = Date.now()
    try {
      const r = await withTimeout(dns.promises.lookup(name, { family: 4 }), 4000, name)
      out.push({ name, ok: true, addr: r.address, ms: Date.now() - t0 })
    } catch (err) {
      out.push({ name, ok: false, code: err.code || err.message })
    }
  }
  return out
}

async function checkDns() {
  if (state('link') !== 'ok') return set('dns', 'skip', 'no network link yet')
  const names = ['app.neuavenue.com', 'os.neuavenue.com', 'api.openai.com']
  const servers = nameservers()
  let res = await lookupAll(names)
  if (res.every((r) => r.ok)) {
    return set('dns', 'ok', `nameservers ${servers.join(',') || 'none'} · ${res[0].name} → ${res[0].addr} (${res[0].ms}ms)`)
  }
  const bad = res.filter((r) => !r.ok).map((r) => `${r.name}:${r.code}`).join(' ')
  const fallback = ['1.1.1.1', '8.8.8.8']
  let fallbackOk = false
  try {
    const r = new dns.promises.Resolver({ timeout: 2500, tries: 1 })
    r.setServers(fallback)
    fallbackOk = (await withTimeout(r.resolve4(names[0]), 6000, 'fallback')).length > 0
  } catch {
    fallbackOk = false
  }
  if (fallbackOk && FIX) {
    const keep = servers.filter((s) => !fallback.includes(s))
    writeFileSync('/etc/resolv.conf', [...fallback, ...keep].map((s) => `nameserver ${s}`).join('\n') + '\n')
    res = await lookupAll(names)
    if (res.every((r) => r.ok)) {
      return set('dns', 'ok', `fixed: DHCP DNS ${servers.join(',') || 'none'} did not answer (${bad}); now ${fallback.join(',')}`)
    }
  }
  if (fallbackOk) return set('dns', 'fail', `DHCP DNS ${servers.join(',') || 'none'} failed (${bad}); 1.1.1.1 answers — set it as DNS`)
  return set('dns', 'fail', `no DNS answer from ${servers.join(',') || 'none'} or 1.1.1.1 (${bad}) — UDP 53 blocked or no internet behind the router`)
}

// ---------- 3a. clock / proxy / TLS ----------

function setClock(epochMs) {
  const iso = new Date(epochMs).toISOString()
  const stamp = `${iso.slice(0, 10)} ${iso.slice(11, 19)}`
  for (const [bin, args] of [
    ['/usr/bin/busybox', ['date', '-u', '-s', stamp]],
    ['date', ['-u', '-s', stamp]],
  ]) {
    const r = spawnSync(bin, args, { timeout: 4000, encoding: 'utf8' })
    if (r.status === 0) return true
  }
  return false
}

async function checkClock() {
  const year = new Date().getUTCFullYear()
  if (state('dns') !== 'ok') {
    if (year < 2026) return set('clock', 'warn', `clock reads ${new Date().toISOString()} and cannot be checked offline — TLS will reject certificates`)
    return set('clock', 'skip', 'no DNS yet')
  }
  let remote = 0
  for (const u of ['http://cp.cloudflare.com/', 'http://www.gstatic.com/generate_204']) {
    const r = await request(u, { method: 'HEAD', timeout: 5000 })
    const d = r.ok && Date.parse(r.headers.date || '')
    if (d) {
      remote = d + Math.round(r.ms / 2)
      break
    }
  }
  if (!remote) return set('clock', 'warn', 'no HTTP Date header reachable (port 80 blocked?) — clock not verified')
  const skew = Date.now() - remote
  const human = Math.abs(skew) >= 3_600_000 ? `${(skew / 3_600_000).toFixed(1)}h` : `${Math.round(skew / 1000)}s`
  if (Math.abs(skew) <= 120_000) return set('clock', 'ok', `skew ${human}`)
  if (FIX && setClock(remote) && Math.abs(Date.now() - remote) < 15_000) {
    return set('clock', 'ok', `fixed: clock was off by ${human} — set from HTTP Date`)
  }
  return set('clock', 'fail', `clock off by ${human} — TLS certificates will be rejected`)
}

function proxyEnv() {
  const out = []
  for (const k of ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy']) {
    const v = process.env[k]
    if (!v) continue
    let host = '(set)'
    try {
      host = new URL(v).host
    } catch {
      host = '(set, not a URL)'
    }
    out.push(`${k}=${host}`)
  }
  return out
}

async function checkProxy() {
  const env = proxyEnv()
  if (state('dns') !== 'ok') return set('proxy', 'skip', `no DNS yet${env.length ? ` · env ${env.join(' ')}` : ''}`)
  const r = await request('http://www.gstatic.com/generate_204', { timeout: 5000 })
  const envText = env.length ? `env ${env.join(' ')}` : 'no proxy env'
  if (r.ok && r.status === 204) return set('proxy', 'ok', `direct · ${envText} · generate_204=204`)
  if (r.ok) {
    let loc = ''
    try {
      loc = r.headers.location ? ` → ${new URL(r.headers.location).host}` : ''
    } catch {
      loc = ''
    }
    return set('proxy', 'warn', `captive portal or intercepting proxy: generate_204 answered ${r.status}${loc} — sign in to the network in daf.neu`)
  }
  return set('proxy', 'warn', `plain HTTP blocked (${r.code}) · ${envText} — HTTPS may still work`)
}

const CLOCK_CODES = new Set(['CERT_NOT_YET_VALID', 'CERT_HAS_EXPIRED'])
const MITM_CODES = new Set([
  'SELF_SIGNED_CERT_IN_CHAIN',
  'UNABLE_TO_GET_ISSUER_CERT_LOCALLY',
  'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'DEPTH_ZERO_SELF_SIGNED_CERT',
])

async function checkTls() {
  if (state('dns') !== 'ok') return set('tls', 'skip', 'no DNS yet')
  const rows = []
  let worst = 'ok'
  for (const host of ['os.neuavenue.com', 'api.openai.com']) {
    const r = await request(`https://${host}/`, { method: 'HEAD', timeout: 6000 })
    if (r.ok) {
      rows.push(`${host} ok (${r.issuer || 'issuer ?'})`)
      continue
    }
    worst = 'fail'
    if (CLOCK_CODES.has(r.code)) rows.push(`${host} ${r.code} — clock is wrong`)
    else if (MITM_CODES.has(r.code)) rows.push(`${host} ${r.code} — a proxy is intercepting TLS; its root CA is not trusted`)
    else rows.push(`${host} ${r.code}`)
  }
  return set('tls', worst, rows.join(' · '))
}

// ---------- 3b. app.neu / daf.neu ----------

async function checkAppNeu() {
  if (state('dns') !== 'ok') return set('appneu', 'skip', 'no DNS yet')
  const api = await request(APP_API, { timeout: 8000 })
  let body = null
  try {
    body = api.ok ? JSON.parse(api.text) : null
  } catch {
    body = null
  }
  const web = await request(APP_WEB, { timeout: 8000 })
  const apiOk = Boolean(api.ok && api.status === 200 && body?.ok === true)
  const webOk = Boolean(web.ok && web.status === 200)
  const detail = `API ${api.ok ? `HTTP ${api.status}` : api.code}${apiOk ? ` ok ${api.ms}ms browse=${body.browse || '?'}` : ''} · web ${web.ok ? `HTTP ${web.status}` : web.code}`
  const extra = { browse: body?.browse || '' }
  if (apiOk && webOk) return set('appneu', 'ok', detail, extra)
  if (apiOk || webOk) return set('appneu', 'warn', detail, extra)
  return set('appneu', 'fail', detail, extra)
}

function executable(p) {
  try {
    accessSync(p, constants.X_OK)
    return true
  } catch {
    return false
  }
}

async function checkDaf() {
  const electron = [process.env.NEUOS_ELECTRON, '/opt/neuos/runtime/electron/electron', path.join(REPO, 'node_modules/electron/dist/electron')]
    .filter(Boolean)
    .find(executable)
  const nssDir = '/usr/lib/x86_64-linux-gnu'
  const nssMissing = ['libsoftokn3.so', 'libfreeblpriv3.so', 'libnssckbi.so'].filter((f) => !existsSync(path.join(nssDir, f)))
  let shm = true
  try {
    accessSync('/dev/shm', constants.W_OK)
  } catch {
    shm = false
  }
  const parts = [`electron ${electron ? 'ok' : 'MISSING'}`, `nss ${nssMissing.length ? `MISSING ${nssMissing.join(',')}` : 'ok'}`, `shm ${shm ? 'ok' : 'NOT WRITABLE'}`]
  const bridge = await request('http://127.0.0.1:4178/api/health', { timeout: 1200 })
  if (bridge.ok) parts.push(`bridge ${bridge.status}`)
  const browse = report.checks.appneu?.browse
  if (browse) parts.push(`app.neu browse=${browse}`)
  let web = null
  if (state('dns') === 'ok') {
    web = await request(DAF_WEB, { timeout: 8000 })
    parts.push(`web ${web.ok ? `HTTP ${web.status}` : web.code}`)
  } else {
    parts.push('web skipped (no DNS)')
  }
  if (!electron || nssMissing.length || !shm) return set('daf', 'fail', `${parts.join(' · ')} — browser runtime cannot start`)
  if (!web || !web.ok || web.status !== 200) return set('daf', 'warn', `${parts.join(' · ')} — runtime ok, pages unreachable`)
  return set('daf', 'ok', parts.join(' · '))
}

// ---------- 3c. LLM ----------

async function localModels() {
  try {
    const r = await fetch(`${OLLAMA_HOST}/api/tags`, { signal: AbortSignal.timeout(1500) })
    const j = await r.json()
    return (j.models || []).length
  } catch {
    return 0
  }
}

async function checkLlm() {
  const key = userOpenAiKey(LLM_ROOT)
  const source = readLlmSettings(LLM_ROOT).openaiKey ? 'user-llm.json' : process.env.OPENAI_API_KEY ? 'env' : 'none'
  const local = await localModels()
  const localText = local ? ` · local models ${local}` : ''
  if (!key) {
    if (local) return set('llm', 'ok', `no cloud key · local model available${localText}`, { key: 'absent', local })
    return set('llm', 'warn', 'no LLM key on this stick yet — enter your own OpenAI key in os.neu (keys are never baked into the image)', {
      key: 'absent',
      local,
    })
  }
  if (state('dns') !== 'ok') return set('llm', 'warn', `key present (${source}) · permission not checked (no DNS)${localText}`, { key: 'present', source })
  const r = await request('https://api.openai.com/v1/models', { headers: { authorization: `Bearer ${key}` }, timeout: 8000, body: 1_000_000 })
  const extra = { key: 'present', source, http: r.ok ? r.status : r.code }
  if (!r.ok) return set('llm', 'warn', `key present (${source}) · api.openai.com ${r.code}${localText}`, extra)
  if (r.status === 200) {
    const listed = r.text.includes('"gpt-4o-mini"')
    return set('llm', listed ? 'ok' : 'warn', `key present (${source}) · /v1/models 200 · gpt-4o-mini ${listed ? 'allowed' : 'not listed'}${localText}`, extra)
  }
  if (r.status === 401) return set('llm', 'fail', `key present (${source}) but rejected (401 invalid or revoked) — re-enter it in os.neu`, extra)
  if (r.status === 403) return set('llm', 'fail', `key present (${source}) but has no model permission (403) — check project/org restrictions`, extra)
  if (r.status === 429) return set('llm', 'warn', `key present (${source}) · rate limited or out of quota (429)`, extra)
  return set('llm', 'warn', `key present (${source}) · /v1/models HTTP ${r.status}`, extra)
}

async function checkPrompt() {
  if (state('llm') !== 'ok') return set('prompt', 'skip', 'LLM not ready — first prompt not sent')
  const t0 = Date.now()
  try {
    const out = await withTimeout(
      completeText({ messages: [{ role: 'user', content: 'Reply with exactly one word: ready' }], root: LLM_ROOT }),
      30_000,
      'first prompt',
    )
    const reply = String(out.text || '').replace(/\s+/g, ' ').slice(0, 40)
    return set('prompt', 'ok', `answered via ${out.provider || 'local'}/${out.model || '?'} in ${Date.now() - t0}ms: "${reply}"`)
  } catch (err) {
    return set('prompt', 'fail', `first prompt failed: ${String(err.message || err).slice(0, 80)}`)
  }
}

// ---------- modes ----------

async function connect() {
  checkLink()
  checkWifi()
  await checkDns()
  await checkClock()
  await checkProxy()
  await checkTls()
  await checkAppNeu()
  await checkDaf()
}

export function noteLine(checks = report.checks) {
  const c = (id) => checks[id] || {}
  const parts = []
  if (c('link').state === 'ok') parts.push(c('link').detail.split(' ').slice(0, 2).join(' '))
  else if (c('link').detail) parts.push(c('link').detail.split(' — ')[1] || c('link').detail)
  for (const [id, name] of [
    ['dns', 'DNS'],
    ['appneu', 'app.neu'],
    ['daf', 'daf.neu'],
    ['llm', 'AI'],
  ]) {
    if (c(id).state && c(id).state !== 'skip') parts.push(`${name} ${c(id).state}`)
  }
  return parts.join(' · ').slice(0, 110)
}

function worst(ids) {
  return ids.reduce((w, id) => Math.max(w, RANK[report.checks[id]?.state] ?? 0), 0)
}

async function main() {
  if (MODE === 'note') {
    console.log(noteLine())
    return 0
  }
  if (MODE === 'connect') await connect()
  else if (MODE === 'ai') await checkLlm()
  else if (MODE === 'prompt') await checkPrompt()
  else if (MODE === 'all') {
    await connect()
    await checkLlm()
    await checkPrompt()
  } else if (MODE === 'watch') {
    for (let round = 1; round <= 40; round++) {
      await connect()
      save()
      if (worst(['link', 'dns', 'appneu']) < 2) break
      await sleep(15_000)
    }
    if (state('llm') !== 'ok') await checkLlm()
    if (state('prompt') !== 'ok') await checkPrompt()
  } else {
    console.error('usage: osneu-netdiag.mjs connect|ai|prompt|all|watch|note [--no-fix] [--quiet] [--root DIR]')
    return 2
  }
  save()
  const rank = worst([...new Set(touched)])
  const counts = { ok: 0, warn: 0, fail: 0, skip: 0 }
  for (const id of new Set(touched)) counts[report.checks[id].state]++
  const verdict = ['PASS', 'WARN', 'FAIL'][rank]
  const summary = `NETDIAG RESULT ${verdict} ok=${counts.ok} warn=${counts.warn} fail=${counts.fail} skip=${counts.skip} mode=${MODE} fix=${FIX ? 'on' : 'off'} json=${JSON_OUT}`
  if (!QUIET) console.log(summary)
  serial(summary)
  try {
    appendFileSync(LOG, `${new Date().toISOString()} ${summary}\n`)
  } catch {
    /* read-only */
  }
  return rank
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().then(
    (code) => {
      process.exitCode = code
    },
    (err) => {
      console.error(`NETDIAG ERROR ${err?.message || err}`)
      process.exitCode = 2
    },
  )
}
