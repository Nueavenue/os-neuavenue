#!/usr/bin/env bash
# Root helper after a kiosk proof check. Advances the 3-boot cycle.
# Uses one-time /usr/sbin/grub-reboot for os.neu; permanent default stays Ubuntu.
set -euo pipefail
STATE="/home/billy-lee/.local/state/osneu/boot-proof"
GOAL=3
COUNTER="$STATE/counter"
LOG="$STATE/advance.log"
mkdir -p "$STATE"
note() { echo "$(date -Is) $*" | tee -a "$LOG"; }

[[ "$(id -u)" = 0 ]] || { echo "must be root" >&2; exit 1; }

# Wait up to 120s for the user check to finish
for i in $(seq 1 120); do
  [[ -s "$STATE/READY_FOR_ADVANCE" ]] && break
  sleep 1
done
if [[ ! -s "$STATE/READY_FOR_ADVANCE" ]]; then
  note "TIMEOUT waiting for READY_FOR_ADVANCE — rebooting to Ubuntu default"
  rm -f "$STATE/READY_FOR_ADVANCE"
  systemctl reboot
  exit 0
fi

run_dir="$(cat "$STATE/READY_FOR_ADVANCE")"
rm -f "$STATE/READY_FOR_ADVANCE"
n=0
if [[ -f "$COUNTER" ]]; then
  n="$(tr -cd '0-9' < "$COUNTER" || true)"
  n="${n:-0}"
fi
n=$((n + 1))
printf '%s\n' "$n" > "$COUNTER"
chown billy-lee:billy-lee "$COUNTER" 2>/dev/null || true
note "completed_osneu_boot=$n/$GOAL run=$run_dir"

if [[ "$n" -lt "$GOAL" ]]; then
  note "arming one-time next boot: os.neu"
  /usr/sbin/grub-reboot 'os.neu'
  # Confirm one-time entry
  if [[ -r /boot/grub/grubenv ]]; then
    note "grubenv: $(tr '\0' ' ' </boot/grub/grubenv | tr -s ' ' | cut -c1-200)"
  fi
  note "rebooting for next os.neu cycle"
  systemctl reboot
else
  note "goal reached — recovery path: reboot to Ubuntu default (no grub-reboot)"
  # Clear any leftover next_entry
  /usr/sbin/grub-editenv /boot/grub/grubenv unset next_entry 2>/dev/null || true
  touch "$STATE/NEED_RECOVER_CHECK"
  # Disable further kiosk proof triggers after this reboot lands on Ubuntu
  systemctl disable osneu-boot-proof.service 2>/dev/null || true
  note "rebooting to Ubuntu for recovery verification"
  systemctl reboot
fi
