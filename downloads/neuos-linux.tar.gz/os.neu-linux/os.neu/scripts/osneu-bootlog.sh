#!/usr/bin/sh
# Boot recorder for the os.neu USB. Copies boot state to
# NEUOS-ESP/osneu-logs/boot-NNN/ so a physical boot can be read back from
# Ubuntu (scripts/usb-logs-pull.sh) instead of photographing the screen.
#
#   osneu-bootlog.sh mark <stage> [note]   record a stage, then snapshot in the background
#   osneu-bootlog.sh note <stage> [note]   record a stage only
#   osneu-bootlog.sh snap                  snapshot only
#   osneu-bootlog.sh watch                 snapshot every 10s for 2 min, 20s to 5 min, then every 60s up to 30 min
#
# JeOS only (NEUOS_JEOS=1 and /etc/neuos-release): on an Ubuntu host a
# plugged stick is never mounted or written. Never copies /opt/neuos/data
# (OpenAI key, accounts). POSIX sh; the stick has dash and BusyBox only.

BB=/usr/bin/busybox
ESP_MNT=/run/osneu-esp
DIR_FILE=/run/osneu-bootlog.dir
STAGES=/run/osneu-bootlog.stages
LOCK=/run/osneu-bootlog.lock
NLS_DIR=/opt/neuos/kmod/boot
MAX_COPY=2097152

[ "$NEUOS_JEOS" = "1" ] || exit 0
[ -f /etc/neuos-release ] || exit 0

bb() {
  if [ -x "$BB" ]; then "$BB" "$@"; else "$@"; fi
}

now() {
  printf '%s up=%s' "$(bb date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null)" "$(cut -d' ' -f1 /proc/uptime 2>/dev/null)"
}

blkid_bin() {
  for b in /usr/sbin/blkid /usr/bin/blkid /sbin/blkid; do
    [ -x "$b" ] && { echo "$b"; return 0; }
  done
  return 1
}

esp_mounted_at() {
  while read -r dev mnt fstype _; do
    [ "$fstype" = "vfat" ] || continue
    [ "$dev" = "$1" ] && { echo "$mnt"; return 0; }
  done < /proc/mounts
  return 1
}

find_esp() {
  if [ -e /dev/disk/by-label/NEUOS-ESP ]; then
    bb readlink -f /dev/disk/by-label/NEUOS-ESP
    return 0
  fi
  b="$(blkid_bin)" || b=""
  if [ -n "$b" ]; then
    d="$("$b" -t LABEL=NEUOS-ESP -o device 2>/dev/null | head -n 1)"
    [ -n "$d" ] && { echo "$d"; return 0; }
  fi
  # Same disk as the root partition, partition 1.
  root="$(awk '$2 == "/" && $1 ~ /^\/dev\// { print $1 }' /proc/mounts | tail -n 1)"
  case "$root" in
    /dev/nvme*p[0-9]*|/dev/mmcblk*p[0-9]*) d="${root%p[0-9]*}p1" ;;
    /dev/sd*[0-9]) d="$(echo "$root" | sed 's/[0-9]*$//')1" ;;
    *) d="" ;;
  esac
  if [ -n "$d" ] && [ -b "$d" ]; then
    if [ -n "$b" ] && [ "$("$b" -o value -s TYPE "$d" 2>/dev/null)" != "vfat" ]; then
      return 1
    fi
    echo "$d"
    return 0
  fi
  return 1
}

# The kernel's default FAT iocharset (iso8859-1) is a module. Load the staged
# NLS modules; if they are missing, cp437 is built in.
mount_esp() {
  dev="$1"
  mkdir -p "$ESP_MNT" 2>/dev/null
  for k in nls_iso8859-1.ko nls_utf8.ko; do
    [ -f "$NLS_DIR/$k" ] && bb insmod "$NLS_DIR/$k" 2>/dev/null
  done
  mount -t vfat -o rw,noatime,flush "$dev" "$ESP_MNT" 2>/dev/null && return 0
  mount -t vfat -o rw,noatime,flush,iocharset=cp437 "$dev" "$ESP_MNT" 2>/dev/null && return 0
  echo "$(now) ESP mount failed $dev" >> "$STAGES"
  return 1
}

esp_dir() {
  if [ -f "$DIR_FILE" ]; then
    d="$(cat "$DIR_FILE")"
    [ -d "$d" ] && { echo "$d"; return 0; }
  fi
  dev="$(find_esp)" || { echo "$(now) ESP not found" >> "$STAGES"; return 1; }
  mnt="$(esp_mounted_at "$dev")" || {
    mount_esp "$dev" || return 1
    mnt="$ESP_MNT"
  }
  mkdir -p "$mnt/osneu-logs" 2>/dev/null || return 1
  n=$(( $(ls -d "$mnt"/osneu-logs/boot-* 2>/dev/null | bb wc -l) + 1 ))
  d="$(printf '%s/osneu-logs/boot-%03d' "$mnt" "$n")"
  mkdir -p "$d/tmp" 2>/dev/null || return 1
  echo "$d" > "$DIR_FILE"
  echo "$(now) ESP $dev at $mnt dir $(basename "$d")" >> "$STAGES"
  echo "$d"
}

put() {
  # put <dest> <command...>: write command output, never fail the boot.
  dest="$1"
  shift
  "$@" > "$dest.new" 2>&1
  mv -f "$dest.new" "$dest" 2>/dev/null
}

copy_tail() {
  src="$1"
  dest="$2"
  [ -f "$src" ] || return 0
  sz="$(bb wc -c < "$src" 2>/dev/null || echo 0)"
  if [ "$sz" -gt "$MAX_COPY" ]; then
    tail -c "$MAX_COPY" "$src" > "$dest.new" 2>/dev/null
  else
    cat "$src" > "$dest.new" 2>/dev/null
  fi
  mv -f "$dest.new" "$dest" 2>/dev/null
}

drm_state() {
  echo "## /sys/class/drm"; ls -l /sys/class/drm 2>&1
  for s in /sys/class/drm/card*-*/status; do
    [ -f "$s" ] && echo "$s $(cat "$s")"
  done
  echo "## /dev/dri"; ls -l /dev/dri 2>&1
  echo "## /proc/fb"; cat /proc/fb 2>&1
  echo "## fbcon bind"
  for v in /sys/class/vtconsole/vtcon*; do
    [ -d "$v" ] && echo "$v $(cat "$v/name" 2>/dev/null) bind=$(cat "$v/bind" 2>/dev/null)"
  done
  echo "## firmware path $(cat /sys/module/firmware_class/parameters/path 2>/dev/null)"
}

net_state() {
  echo "## ip addr"; bb ip addr 2>&1
  echo "## ip route"; bb ip route 2>&1
  echo "## resolv.conf"; cat /etc/resolv.conf 2>&1
  echo "## /sys/class/net"
  for n in /sys/class/net/*; do
    [ -e "$n" ] && echo "${n##*/} oper=$(cat "$n/operstate" 2>/dev/null) carrier=$(cat "$n/carrier" 2>/dev/null) driver=$(basename "$(bb readlink "$n/device/driver" 2>/dev/null)" 2>/dev/null)"
  done
}

snap() {
  stage_line "snap-begin pid=$$"
  d="$(esp_dir)" || { stage_line "snap-fail esp_dir"; return 1; }
  put "$d/cmdline.txt" cat /proc/cmdline
  put "$d/release.txt" cat /etc/neuos-release
  put "$d/dmesg.txt" bb dmesg
  put "$d/modules.txt" cat /proc/modules
  put "$d/drm.txt" drm_state
  put "$d/net.txt" net_state
  put "$d/input.txt" cat /proc/bus/input/devices
  put "$d/mounts.txt" cat /proc/mounts
  put "$d/ps.txt" bb ps
  put "$d/meminfo.txt" head -n 5 /proc/meminfo
  for f in /tmp/osneu-* /tmp/weston/*.log /run/osneu-splash.json; do
    [ -f "$f" ] || continue
    case "$f" in *.pid|*.sh) continue ;; esac
    copy_tail "$f" "$d/tmp/$(basename "$f")"
  done
  echo "$(now) snapshot" >> "$STAGES"
  copy_tail "$STAGES" "$d/stages.txt"
  stage_line "snap-done"
  # vfat is mounted with flush; a global sync can block on the stick's ext4.
  sync &
}

# The stick's /usr/bin has no rmdir link: plain rmdir left the lock forever
# (boot-001..004 had at most one snapshot) and boot-005/006 spun on it.
unlock() {
  rm -f "$LOCK/pid" 2>/dev/null
  bb rmdir "$LOCK" 2>/dev/null
}

locked() {
  i=0
  stale=0
  while ! mkdir "$LOCK" 2>/dev/null; do
    holder="$(cat "$LOCK/pid" 2>/dev/null)"
    if [ -z "$holder" ] || [ ! -d "/proc/$holder" ]; then
      stale=$((stale + 1))
      [ "$stale" -gt 3 ] && { stage_line "lock stuck (cannot clear $LOCK) — skipped"; return 1; }
      unlock
      stage_line "stale lock cleared (holder=${holder:-none})"
      sleep 1
      continue
    fi
    i=$((i + 1))
    [ "$i" -ge 10 ] && { stage_line "lock busy (holder=$holder $(tr '\0' ' ' < "/proc/$holder/cmdline" 2>/dev/null | cut -c1-80)) — skipped"; return 1; }
    sleep 1
  done
  # $$ in a "( locked snap ) &" subshell is the parent's pid, which has
  # already exited; /proc/self/stat read by a builtin is this subshell.
  read -r me _ < /proc/self/stat 2>/dev/null || me=$$
  echo "$me" > "$LOCK/pid"
  trap unlock EXIT
  "$@"
  rc=$?
  unlock
  trap - EXIT
  return $rc
}

# Stage lines also go straight to the ESP so they survive a failed snapshot.
stage_line() {
  line="$(now) STAGE $*"
  echo "$line" >> "$STAGES"
  if [ -f "$DIR_FILE" ]; then
    d="$(cat "$DIR_FILE")"
    [ -d "$d" ] && echo "$line" >> "$d/stages-live.txt" 2>/dev/null
  fi
}

trap '' HUP
mode="${1:-snap}"
[ $# -gt 0 ] && shift
case "$mode" in
  # The boot must never wait for a snapshot: boot-003 wrote "screen-start"
  # and then the snapshot never finished, so usb-screen-jeos.sh (which waited
  # on it) never loaded i915 or started cage.
  mark)
    [ -f "$DIR_FILE" ] || locked esp_dir >/dev/null
    stage_line "$@"
    ( locked snap ) </dev/null >/dev/null 2>&1 &
    ;;
  note)
    [ -f "$DIR_FILE" ] || locked esp_dir >/dev/null
    stage_line "$@"
    ;;
  snap)
    locked snap
    ;;
  watch)
    stage_line "watch-start pid=$$"
    t=0
    while [ "$t" -lt 1800 ]; do
      if [ "$t" -lt 120 ]; then step=10; elif [ "$t" -lt 300 ]; then step=20; else step=60; fi
      sleep "$step"
      t=$((t + step))
      stage_line "watch t=${t}s"
      ( locked snap ) </dev/null >/dev/null 2>&1 &
    done
    ;;
  *)
    echo "usage: osneu-bootlog.sh mark|note|snap|watch [stage] [note]" >&2
    exit 2
    ;;
esac
exit 0
