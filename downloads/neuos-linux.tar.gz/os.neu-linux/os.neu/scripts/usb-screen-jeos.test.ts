import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const jeos = readFileSync(join(root, 'scripts/usb-screen-jeos.sh'), 'utf8')
const host = readFileSync(join(root, 'scripts/usb-screen.sh'), 'utf8')
const make = readFileSync(join(root, 'scripts/make-usb.sh'), 'utf8')
const init = readFileSync(join(root, 'boot/live/init'), 'utf8')

describe('USB JeOS GPU seat helpers', () => {
  it('does not call tr or basename (dash on the stick has no those applets)', () => {
    expect(jeos).not.toMatch(/\|\s*tr\b/)
    expect(host).not.toMatch(/\|\s*tr\b/)
    expect(jeos).not.toMatch(/\$\(\s*basename\b/)
    expect(host).not.toMatch(/\$\(\s*basename\b/)
  })

  it('publishes weston drm-backend and XKB for the flicker path', () => {
    expect(jeos).toContain('drm-backend.so')
    expect(jeos).toContain('XKB_CONFIG_ROOT')
    expect(jeos).toContain('chmod 700')
    expect(jeos).toContain('--use-pixman')
    expect(jeos).not.toMatch(/exec .*--ozone-platform=drm/)
    expect(jeos).not.toMatch(/chmod 666/)
  })

  it('captures compositor output inside each fresh VT', () => {
    expect(jeos).toContain('CAGE_LOG="${LOG}.${compositor}.vt${VT}"')
    expect(jeos).toContain('VT=$((VT + 1))')
    expect(jeos).toContain('-c "$VT" -f -s -w')
    expect(jeos).toContain('exec \\"\\$@\\" >> \'$CAGE_LOG\' 2>&1')
  })

  it('plants tr and basename BusyBox applets on the next stick update', () => {
    expect(make).toMatch(/\btr\b/)
    expect(make).toMatch(/\bbasename\b/)
    expect(make).toContain('xkb-data')
  })

  it('carries the launcher in initrd when NEUOS-ROOT is emergency_ro', () => {
    expect(make).toContain('cp "$ROOT/scripts/usb-screen-jeos.sh" "$initdir/usb-screen-jeos.sh"')
    expect(init).toContain('mount --bind /usb-screen-jeos.sh /newroot/opt/neuos/scripts/usb-screen-jeos.sh')
    expect(init).toContain('screen launcher override active (initrd)')
  })
})
