#!/usr/bin/env bash
# Runs once on Ubuntu after the 3 os.neu boots. Confirms recovery path.
set -uo pipefail
STATE="/home/billy-lee/.local/state/osneu/boot-proof"
DIR="$STATE/runs/recover-$(date +%Y%m%dT%H%M%S)"
mkdir -p "$DIR"
REPORT="$DIR/report.txt"
{
  echo "os.neu recovery check · $(date -Is)"
  echo "host=$(hostname) user=$(id -un 2>/dev/null || echo root)"
  echo "systemd default=$(systemctl get-default)"
  echo "kiosk_active=$(systemctl is-active osneu-kiosk.service 2>&1 || true)"
  echo "kiosk_target=$(systemctl is-active osneu-kiosk.target 2>&1 || true)"
  echo "cmdline=$(cat /proc/cmdline)"
} > "$REPORT"

ok=1
if systemctl is-active osneu-kiosk.service 2>/dev/null | grep -q active; then
  echo "FAIL kiosk still active on Ubuntu boot" >> "$REPORT"
  ok=0
else
  echo "PASS kiosk not active" >> "$REPORT"
fi
if grep -q "systemd.unit=osneu-kiosk.target" /proc/cmdline; then
  echo "FAIL still on osneu-kiosk cmdline" >> "$REPORT"
  ok=0
else
  echo "PASS cmdline is not osneu-kiosk.target" >> "$REPORT"
fi
if grep -q "GRUB_DEFAULT='os.neu'" /etc/default/grub.d/90-osneu.cfg 2>/dev/null; then
  echo "FAIL permanent default is os.neu" >> "$REPORT"
  ok=0
else
  echo "PASS permanent GRUB default is not os.neu" >> "$REPORT"
fi
def="$(grep -E '^GRUB_DEFAULT=' /etc/default/grub | tail -1)"
echo "info $def" >> "$REPORT"
if ping -c1 -W2 1.1.1.1 >/dev/null 2>&1; then
  echo "PASS network icmp" >> "$REPORT"
else
  echo "FAIL network icmp" >> "$REPORT"
  ok=0
fi
code="$(curl -fsS -o /dev/null -w '%{http_code}' --max-time 10 -A 'Mozilla/5.0 os.neu-boot-proof' https://os.neuavenue.com/ 2>/dev/null || echo 000)"
echo "info http=$code" >> "$REPORT"
[[ "$code" == "200" ]] && echo "PASS network http" >> "$REPORT" || echo "FAIL network http $code" >> "$REPORT"

if [[ "$ok" = 1 ]]; then
  echo "SUMMARY RECOVERY_PASS" >> "$REPORT"
  printf 'PASS\n' > "$STATE/RECOVERY_RESULT"
else
  echo "SUMMARY RECOVERY_FAIL" >> "$REPORT"
  printf 'FAIL\n' > "$STATE/RECOVERY_RESULT"
fi
printf '%s\n' "$DIR" > "$STATE/LAST_RECOVER"
rm -f "$STATE/NEED_RECOVER_CHECK"
# Disable recover unit
systemctl disable osneu-boot-proof-recover.service 2>/dev/null || true
echo "$DIR"
