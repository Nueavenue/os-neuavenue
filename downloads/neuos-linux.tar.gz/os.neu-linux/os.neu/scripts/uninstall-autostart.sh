#!/usr/bin/env bash
# Stop os.neu from opening at Linux graphical login, and remove launcher icons.
# Does NOT wipe disks. Does NOT delete this git tree (neuOS).
# Optional: --files removes only $HOME/os.neu if it is a planted copy.
set -euo pipefail
HOME_DIR="${NEUOS_HOME:-$HOME}"
AUTO="${HOME_DIR}/.config/autostart/neuos.desktop"
APP="${HOME_DIR}/.local/share/applications/neuos.desktop"
DESK="${HOME_DIR}/Desktop/neuos.desktop"
UNIT_DIR="${HOME_DIR}/.config/systemd/user"
UNIT="${UNIT_DIR}/neuos.service"
PLANTED="${HOME_DIR}/os.neu"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILES=0
if [[ "${1:-}" == "--files" ]]; then
  FILES=1
fi

if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now neuos.service >/dev/null 2>&1 || true
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi

rm -f "$AUTO" "$APP" "$DESK" "$UNIT"
echo "autostart removed: $AUTO"
echo "launcher removed:  $APP"
echo "desktop removed:   $DESK"
echo "user unit removed: $UNIT"

if ((FILES)); then
  if [[ -d "$PLANTED" && "$PLANTED" != "$ROOT" ]]; then
    rm -rf "$PLANTED"
    echo "removed planted copy: $PLANTED"
  else
    echo "skip files: $PLANTED is missing or is this source tree ($ROOT)"
  fi
fi

echo "os.neu will not open at the next Linux login."
echo "This desktop is unchanged. Disks were not wiped."
