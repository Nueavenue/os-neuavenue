#!/usr/bin/env bash
# Older launchers still call kiosk.sh. The screen is scripts/screen.sh.
exec bash "$(cd "$(dirname "$0")" && pwd)/screen.sh" "$@"
