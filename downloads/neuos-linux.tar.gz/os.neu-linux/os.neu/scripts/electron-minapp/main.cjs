// Crash-isolation probe for the USB launcher: one plain window, no os.neu
// main.cjs, no bridge. If this survives where the real app segfaults, the
// cause is in os.neu startup code, not Chromium on the stick.
//   MINAPP_FRAME=0  frameless window (skips the GTK client-side frame)
//   MINAPP_MENU=0   no application menu (Electron otherwise adds its default)
const { app, BrowserWindow, Menu } = require('electron')

const framed = process.env.MINAPP_FRAME !== '0'
const menu = process.env.MINAPP_MENU !== '0'
const mark = (s) => process.stderr.write(`MINAPP ${s} frame=${framed ? 1 : 0} menu=${menu ? 1 : 0}\n`)

mark('start')
app.whenReady().then(() => {
  mark('ready')
  if (!menu) Menu.setApplicationMenu(null)
  const win = new BrowserWindow({ width: 640, height: 360, show: true, frame: framed, hasShadow: framed })
  mark('window')
  win.webContents.once('did-finish-load', () => {
    mark('loaded')
    setTimeout(() => app.quit(), 2000)
  })
  win.loadURL('data:text/html,<h1 style="font-family:sans-serif">os.neu probe</h1>')
})
