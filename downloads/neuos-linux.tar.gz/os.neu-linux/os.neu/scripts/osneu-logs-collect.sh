#!/usr/bin/env bash
# Collect os.neu boot logs into one folder for the agent to read, after
# booting back into Ubuntu. No photos needed.
#
#   bash scripts/osneu-logs-collect.sh        last 3 local boots + USB stick if plugged
#   bash scripts/osneu-logs-collect.sh 5      last 5 local boots
#
# Sources:
#   local boot (GRUB "os.neu")  ~/.local/state/osneu/boots/<time>-<boot>/
#                               (session.log, marks.log, info.txt, screen-*.png)
#   systemd journal             osneu-kiosk.service + warnings/errors per boot
#   USB stick                   scripts/usb-logs-pull.sh (read-only mount)
#
# Writes only to a new folder ~/osneu-logs/<time>/. Never deletes, never writes
# to the stick. Copies no app data (keys, accounts); masks key-like strings.
set -uo pipefail

N="${1:-3}"
HERE="$(cd "$(dirname "$0")" && pwd)"
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/osneu"
OUT="$HOME/osneu-logs/$(date +%Y%m%dT%H%M%S)"
mkdir -p "$OUT/local" "$OUT/journal"
SUM="$OUT/SUMMARY.txt"

mask() { sed -E 's/(sk-[A-Za-z0-9_-]{6})[A-Za-z0-9_-]+/\1…MASKED/g; s/(eyJ[A-Za-z0-9_-]{6})[A-Za-z0-9._-]+/\1…MASKED/g'; }
epoch() { date -d "$1" +%s 2>/dev/null || echo ""; }

{
  echo "os.neu boot log bundle · collected $(date -Is)"
  echo "host $(hostname) · kernel $(uname -r)"
  echo
} > "$SUM"

# ---- local boots ------------------------------------------------------------
echo "== Local boots (GRUB os.neu), newest first" >> "$SUM"
mapfile -t BOOTS < <(ls -1dt "$STATE"/boots/*/ 2>/dev/null | head -n "$N")
if [[ ${#BOOTS[@]} -eq 0 ]]; then
  echo "(none recorded yet under $STATE/boots — boot os.neu once with the new kiosk script)" >> "$SUM"
fi
for d in "${BOOTS[@]}"; do
  name="$(basename "$d")"
  dest="$OUT/local/$name"
  mkdir -p "$dest"
  for f in info.txt marks.log session.log; do
    [[ -s "$d/$f" ]] && mask < "$d/$f" > "$dest/$f"
  done
  cp -p "$d"/screen-*.png "$dest/" 2>/dev/null || true

  {
    echo
    echo "-- $name"
    start="$(sed -n 's/^kiosk_start=//p' "$d/info.txt" 2>/dev/null)"
    up="$(sed -n 's/^uptime_s=//p' "$d/info.txt" 2>/dev/null)"
    settings="$(grep -m1 -E 'compositor=' "$d/session.log" 2>/dev/null | cut -c1-200)"
    echo "settings: ${settings:-UNKNOWN}"
    loaded="$(grep -m1 'APP_WINDOW did-finish-load' "$d/marks.log" 2>/dev/null)"
    nav="$(grep 'APP_WINDOW navigate' "$d/marks.log" 2>/dev/null | head -n 1)"
    echo "home page: ${nav:-no navigate mark}"
    if [[ -n "$loaded" && -n "$start" && -n "$up" ]]; then
      s0="$(epoch "$start")"; s1="$(epoch "${loaded%% *}")"
      if [[ -n "$s0" && -n "$s1" ]]; then
        boot0="$(awk -v a="$s0" -v b="$up" 'BEGIN{printf "%d", a-b}')"
        echo "time: Linux start → kiosk $(awk -v b="$up" 'BEGIN{printf "%d", b}')s · → screen loaded $((s1 - boot0))s"
      fi
      echo "loaded: ${loaded#* }"
    else
      echo "loaded: NO did-finish-load mark"
    fi
    grep 'kiosk.env' "$d/session.log" 2>/dev/null | cut -c1-120
    grep -E 'BRIDGE|ZOOM|did-fail-load|RENDERER gone|SCREEN_CAPTURE| API .* (4[0-9][0-9]|5[0-9][0-9]|ERROR)' "$d/marks.log" 2>/dev/null | cut -c1-200 | head -n 20
    echo "-- failure reasons (API_REASON, deduped)"
    grep 'API_REASON' "$d/marks.log" 2>/dev/null | cut -d' ' -f2- | sort | uniq -c | sort -rn | cut -c1-220 | head -n 12
    echo "-- Google login (LOGIN_WINDOW / LOGIN_HANDOFF)"
    grep -E 'LOGIN_(WINDOW|HANDOFF)' "$d/marks.log" 2>/dev/null | cut -c1-200 | head -n 20
    echo "-- app close / child exits"
    grep -E 'close requested|APP quit|APP_CHILD' "$d/marks.log" 2>/dev/null | cut -c1-200 | head -n 10
    echo "-- file dialog (session.log)"
    grep -iE 'select_file_dialog|export window handle|FileChooser' "$d/session.log" 2>/dev/null | cut -c1-200 | head -n 5
    errs="$(grep -ciE 'error|failed|fatal' "$d/session.log" 2>/dev/null)"
    echo "session.log error-like lines: ${errs:-0} (see local/$name/session.log)"
    ls "$dest"/screen-*.png 2>/dev/null | sed "s#^$OUT/#screen: #"
    ex="$(grep -E '(cage|sway) exit=' "$d/session.log" 2>/dev/null | tail -n 1)"
    echo "session end: ${ex:-still running or cut by power off}"
  } >> "$SUM"
done

# ---- journal ----------------------------------------------------------------
echo >> "$SUM"
echo "== systemd journal (last $N boots)" >> "$SUM"
mapfile -t JB < <(journalctl --list-boots --no-pager 2>/dev/null | awk '$1 ~ /^-?[0-9]+$/ {print $1}' | tail -n "$N")
for b in "${JB[@]}"; do
  tag="boot${b}"
  journalctl -b "$b" --no-pager -o short-iso -u osneu-kiosk.service 2>/dev/null | mask > "$OUT/journal/$tag-osneu-kiosk.log"
  journalctl -b "$b" --no-pager -o short-iso -p warning 2>/dev/null | mask | tail -n 400 > "$OUT/journal/$tag-warnings.log"
  first="$(journalctl -b "$b" --no-pager -o short-iso 2>/dev/null | head -n 1 | cut -c1-25)"
  target="$(journalctl -b "$b" --no-pager 2>/dev/null | grep -m1 -oE 'systemd\.unit=[^ ]+' || true)"
  kiosk="$(grep -m1 'Started osneu-kiosk' "$OUT/journal/$tag-osneu-kiosk.log" 2>/dev/null | cut -c1-25)"
  failed="$(grep -E 'Failed to start' "$OUT/journal/$tag-warnings.log" 2>/dev/null | sed -E 's/.*Failed to start //' | sort -u | tr '\n' ';' | cut -c1-200)"
  echo "boot $b: start ${first:-?} · ${target:-desktop (no systemd.unit)} · kiosk started ${kiosk:-no} · failed units: ${failed:-none}" >> "$SUM"
  journalctl -b "$b" --no-pager -o short-iso -k 2>/dev/null | grep -E 'segfault' | grep -E 'cage|sway|electron' | cut -c1-200 | sed 's/^/  crash: /' >> "$SUM"
done

# ---- USB stick ----------------------------------------------------------------
echo >> "$SUM"
echo "== USB stick" >> "$SUM"
if lsblk -rno LABEL 2>/dev/null | grep -qx 'NEUOS-ESP'; then
  if out="$(bash "$HERE/usb-logs-pull.sh" 2>&1)"; then
    src="$(printf '%s\n' "$out" | sed -n 's/^copied to //p' | tail -n 1)"
    if [[ -n "$src" && -d "$src" ]]; then
      mkdir -p "$OUT/usb"
      cp -r "$src/." "$OUT/usb/"
      printf '%s\n' "$out" | tail -n 30 >> "$SUM"
    fi
  else
    printf 'usb-logs-pull failed:\n%s\n' "$out" | tail -n 10 >> "$SUM"
  fi
else
  echo "(no NEUOS-ESP stick plugged — skipped)" >> "$SUM"
fi

echo
cat "$SUM"
echo
echo "Tell the agent: logs at $OUT"
