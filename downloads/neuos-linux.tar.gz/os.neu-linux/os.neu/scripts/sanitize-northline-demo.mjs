#!/usr/bin/env node
/**
 * Northline DEMO IR — drop poster slides 23–29 from manifest (files kept on disk),
 * renumber remaining, scrub founder names + soften BP-specific copy.
 * Add-only / overwrite non-empty. Never rm source PSST or poster files.
 */
import fs from 'node:fs'
import path from 'node:path'

const ROOTS = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['/home/billy-lee/os.neu', '/home/billy-lee/neuOS']

const DROP_IDS = new Set([
  'poster-a',
  'poster-b',
  'poster-c',
  'poster-d',
  'poster-c4-architecture',
  'poster-oauth-flow',
  'poster-trust-boundary',
])

const REPLACEMENTS = [
  ['SOUKHEE (BILLY LEE)', 'Demo Founder'],
  ['SOUKHEE (BILLY LEE)', 'Demo Founder'],
  ['이석희 / SOUKHEE (BILLY LEE)', 'Demo Founder'],
  ['이석희', 'Demo Founder'],
  ['SOUKHEE', 'Demo Founder'],
  ['BILLY LEE', 'Demo Founder'],
  ['Billy Lee', 'Demo Founder'],
  ['Jordan Hale', 'Demo Founder'],
  ['Leader / CEO', 'Sample role'],
  ['대표이사 / CEO', '샘플 역할'],
  ['대표자 · 운영 통제', '샘플 · 운영 역할'],
  ['대표자 표기 · 통일', '역할 표기 · 샘플'],
  ['대표의 한 줄 지시', '운영자 한 줄 지시'],
  ['Toronto, Canada · 법인 실체 PAPER', 'Sample City · DEMO entity'],
  ['Toronto, Canada · PAPER', 'Sample City · DEMO'],
  ['Toronto —', 'Sample City —'],
  ['Toronto,', 'Sample City,'],
  ['Toronto', 'Sample City'],
  ['Northline Systems Inc.', 'Sample Co. (DEMO)'],
  ['Northline Systems', 'Sample Co.'],
  ['Northline', 'Sample Co.'],
  ['north.seat', 'sample.desk'],
  ['NORTH.SEAT', 'SAMPLE.DESK'],
  ['atlas.browse', 'sample.browse'],
  ['Guided Operator Desk', 'Sample Operator Desk'],
  ['Operator Coordination Layer', 'Sample Coordination Layer'],
  ['Harbor Desk', 'Sample Desk'],
  ['Harbor Hub', 'Sample Hub'],
  ['샘플 사업계획서', '샘플 덱'],
  ['사업계획서', '샘플 덱'],
  ['외부 자금', '샘플 자금란'],
  ['NOT RAISED', 'DEMO · NOT A RAISE'],
  ['법인 등록번호', '샘플 등록란'],
  ['세무 등록', '샘플 세무란'],
  // Soften projected money language
  ['유료 ARR(기업용 제외)', '샘플 지표(가정)'],
  ['연말 ARR', '연말 지표(가정)'],
  ['연간 매출', '연간 지표(가정)'],
  ['시나리오 매출', '시나리오 지표'],
  ['실제 매출이 아닌 계획 가정', '데모용 가정 · 실제 수치 아님'],
  ['확정 수치로 읽지 말 것', '데모 플레이스홀더로 읽을 것'],
  ['$4.5M · 60,000명 가설은 폐기.', '대형 가설 수치는 데모에서 제거.'],
  ['조달 가정(Seed · Series A · Series B)', '조달 가정(데모 라벨만)'],
  ['현재 외부 자금 DEMO · NOT A RAISE.', '외부 조달 없음 · 데모 전용.'],
]

function scrub(html) {
  let out = html
  const parts = out.split(/(<style[\s\S]*?<\/style>)/i)
  for (let i = 0; i < parts.length; i++) {
    if (/^<style/i.test(parts[i])) continue
    let chunk = parts[i]
    for (const [from, to] of REPLACEMENTS) chunk = chunk.split(from).join(to)
    // Strip leftover Billy / Lee name fragments in visible text
    chunk = chunk.replace(/BILLY\s*LEE/gi, 'Demo Founder')
    chunk = chunk.replace(/\bBilly\b/gi, 'Demo')
    // Dollar projection cells → DEMO
    chunk = chunk.replace(/\$\d+(?:\.\d+)?[KMB]?/g, 'DEMO')
    // Page counters like 05 / 26 or 19 / 32
    parts[i] = chunk
  }
  return parts.join('')
}

function setPageCounter(html, n, total) {
  return html.replace(/(\d+)\s*\/\s*(\d+)/g, (_, a, b) => {
    // Only replace slide counters that look like page/total (total was 26–32 range or similar)
    const t = Number(b)
    if (t >= 10 && t <= 40) return `${String(n).padStart(2, '0')} / ${String(total).padStart(2, '0')}`
    return `${a} / ${b}`
  })
}

for (const root of ROOTS) {
  const dir = path.join(root, 'public', 'html-templates', 'northline-ir-demo')
  const manPath = path.join(dir, 'manifest.json')
  if (!fs.existsSync(manPath)) {
    console.error('skip', manPath)
    continue
  }
  const man = JSON.parse(fs.readFileSync(manPath, 'utf8'))
  const kept = (man.slides || []).filter((s) => !DROP_IDS.has(s.id))
  const total = kept.length
  const slides = []
  kept.forEach((row, idx) => {
    const n = idx + 1
    const filePath = path.join(dir, 'slides', row.file)
    if (!fs.existsSync(filePath)) {
      console.warn('missing', filePath)
      return
    }
    let html = fs.readFileSync(filePath, 'utf8')
    html = scrub(html)
    html = setPageCounter(html, n, total)
    // Soft titles in financial / funding eyebrow if still harsh
    html = html.replace(/재무 모델/g, '샘플 지표 표')
    html = html.replace(/자금 계획/g, '샘플 조달란')
    fs.writeFileSync(filePath, html, 'utf8')
    if (fs.statSync(filePath).size < 2) throw new Error('empty ' + filePath)
    const baseLabel = String(row.label || row.id).replace(/^\d+\s*/, '')
    // Friendly label scrub
    let labelCore = baseLabel
      .replace(/재무 모델/g, '샘플 지표 표')
      .replace(/자금 계획/g, '샘플 조달란')
      .replace(/근거 자료/g, '샘플 근거')
      .replace(/Northline/g, 'Sample Co.')
      .replace(/DEMO IR/g, 'DEMO')
    slides.push({
      id: row.id,
      file: row.file,
      label: `${String(n).padStart(2, '0')} ${labelCore}`,
    })
  })

  const nextMan = {
    ...man,
    id: 'northline-ir-demo',
    title: 'Sample Co. DEMO IR',
    titleKo: 'Sample Co. · DEMO IR 샘플',
    locks: [
      'DEMO only · fictional / sanitized',
      'no founder personal name',
      'posters 23–29 omitted from deck (files retained on disk)',
      'not a live business plan',
      'Sample Operator Desk',
    ],
    omittedFromDeck: [...DROP_IDS],
    slides,
  }
  fs.writeFileSync(manPath, JSON.stringify(nextMan, null, 2) + '\n', 'utf8')
  console.log('OK', root, 'slides', slides.length, 'omitted', DROP_IDS.size)
}
console.log('DONE')
