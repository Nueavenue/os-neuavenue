#!/usr/bin/env bash
# GDM/Wayland session: os.neu is the screen on THIS machine.
# Ubuntu kernel, drivers, networking stay. This is not a new kernel.
# Needs a compositor (cage preferred). GNOME shell is a fallback and still looks like Ubuntu.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export HOME="${HOME:-/home/billy-lee}"
export NEUOS_SCREEN=1
export NEUOS_DRIVER=live
export XDG_SESSION_TYPE=wayland
export XDG_CURRENT_DESKTOP="${XDG_CURRENT_DESKTOP:-os.neu}"
RT="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export XDG_RUNTIME_DIR="$RT"
mkdir -p "$RT"
chmod 700 "$RT" 2>/dev/null || true

if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.nvm/nvm.sh"
fi

SCREEN=(bash "$ROOT/scripts/open-neuos.sh")

if command -v cage >/dev/null; then
  exec cage -- "${SCREEN[@]}"
fi

wait_wayland() {
  local i=0
  while [[ "$i" -lt 40 ]]; do
    if [[ -S "$RT/wayland-0" ]]; then
      export WAYLAND_DISPLAY=wayland-0
      return 0
    fi
    if [[ -S "$RT/wayland-1" ]]; then
      export WAYLAND_DISPLAY=wayland-1
      return 0
    fi
    i=$((i + 1))
    sleep 0.25
  done
  return 1
}

if command -v gnome-shell >/dev/null; then
  dbus-run-session gnome-shell --wayland >/tmp/osneu-session-shell.log 2>&1 &
  gs=$!
  if wait_wayland; then
    "${SCREEN[@]}"
    kill "$gs" 2>/dev/null || true
    exit 0
  fi
  kill "$gs" 2>/dev/null || true
fi

echo "OS-NEU-SX-000  no compositor for the os.neu session on this machine." >&2
echo "Ubuntu 26.04: sudo apt install -y cage seatd" >&2
echo "Then at GDM pick session os.neu (not Ubuntu)." >&2
sleep 6
exit 1
