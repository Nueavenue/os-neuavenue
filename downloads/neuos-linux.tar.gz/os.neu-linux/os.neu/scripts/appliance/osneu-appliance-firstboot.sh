#!/usr/bin/env bash
# Factory first boot on Ubuntu Server (hidden host). Plants neuOS + kiosk boot.
# Hidden host remains Linux. This is not a custom kernel.
#
#   sudo bash osneu-appliance-firstboot.sh           # live apply
#   OSNEU_DESTDIR=/tmp/x bash ...                    # plant under DESTDIR only
#   OSNEU_DESTDIR=/tmp/x bash ... --dry-run          # log only
#
# Seed tree: /opt/osneu-seed  (or $OSNEU_SEED)
set -euo pipefail

DRY=0
for a in "$@"; do
  case "$a" in
    --dry-run) DRY=1 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
  esac
done

SEED="${OSNEU_SEED:-/opt/osneu-seed}"
KUSER="${OSNEU_USER:-osneu}"
KHOME="$(getent passwd "$KUSER" 2>/dev/null | cut -d: -f6 || true)"
[[ -n "$KHOME" ]] || KHOME="/home/$KUSER"
APP="${NEUOS_APP:-$KHOME/neuOS}"
D="${OSNEU_DESTDIR:-}"
MARK_DONE="$KHOME/.config/osneu-appliance/firstboot.done"
if [[ -n "$D" ]]; then
  LOG="${OSNEU_FIRSTBOOT_LOG:-$D/var/log/osneu-appliance-firstboot.log}"
  mkdir -p "$(dirname "$LOG")"
else
  LOG="${OSNEU_FIRSTBOOT_LOG:-/var/log/osneu-appliance-firstboot.log}"
fi

note() {
  local line
  line="$(date -Is) $*"
  echo "$line"
  if [[ "$DRY" = 0 ]]; then
    mkdir -p "$(dirname "$LOG")" 2>/dev/null || true
    echo "$line" >> "$LOG" 2>/dev/null || true
  fi
}
die() { note "FAIL: $*"; exit 1; }

[[ "$(id -u)" = 0 || -n "$D" || "$DRY" = 1 ]] || die "run as root (or --dry-run / OSNEU_DESTDIR)"

if [[ -z "$D" && "$DRY" = 0 && -f "$MARK_DONE" ]]; then
  note "already done ($MARK_DONE) — exit 0"
  exit 0
fi

[[ -d "$SEED" || "$DRY" = 1 ]] || die "missing seed $SEED"

note "start seed=$SEED user=$KUSER app=$APP dry=$DRY destdir=${D:-/}"

# 1) Ensure kiosk packages (idempotent; live host only)
PKGS=(sway swaybg foot fcitx5 fcitx5-hangul fcitx5-frontend-gtk3 cage gnome-keyring libsecret-1-0 curl ca-certificates)
if [[ "$DRY" = 1 ]]; then
  note "DRY apt install ${PKGS[*]}"
elif [[ -z "$D" ]]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq "${PKGS[@]}"
else
  note "DESTDIR skip apt"
fi

# 2) Plant seed → ~/neuOS (add-only rsync; no --delete)
TARGET_APP="$APP"
TARGET_MARK="$MARK_DONE"
TARGET_HOME="$KHOME"
if [[ -n "$D" ]]; then
  TARGET_APP="$D$APP"
  TARGET_MARK="$D$MARK_DONE"
  TARGET_HOME="$D$KHOME"
fi

if [[ "$DRY" = 1 ]]; then
  note "DRY rsync $SEED/ → $TARGET_APP/"
else
  mkdir -p "$TARGET_APP" "$(dirname "$TARGET_MARK")"
  rsync -a --exclude '.git' \
    "$SEED/" "$TARGET_APP/" || die "rsync seed failed"
  if [[ -z "$D" ]]; then
    chown -R "$KUSER:$KUSER" "$APP" "$KHOME/.config" 2>/dev/null || true
  fi
fi

# 3) Local boot units + GRUB (default os.neu on appliance; Ubuntu stays as recovery entry)
BOOT_SH_HOST="$APP/scripts/osneu-local-boot.sh"
BOOT_SH_TARGET="$TARGET_APP/scripts/osneu-local-boot.sh"
if [[ "$DRY" = 1 ]]; then
  note "DRY OSNEU_USER=$KUSER NEUOS_APP=$APP bash $BOOT_SH_HOST --apply --default-osneu"
elif [[ -n "$D" ]]; then
  [[ -x "$BOOT_SH_TARGET" ]] || die "missing $BOOT_SH_TARGET"
  OSNEU_DESTDIR="$D" OSNEU_USER="$KUSER" NEUOS_APP="$APP" \
    OSNEU_ROOT_UUID="${OSNEU_ROOT_UUID:-00000000-0000-0000-0000-000000000001}" \
    bash "$BOOT_SH_TARGET" --apply --default-osneu || die "local-boot apply failed"
else
  [[ -x "$BOOT_SH_HOST" ]] || die "missing $BOOT_SH_HOST"
  OSNEU_USER="$KUSER" NEUOS_APP="$APP" bash "$BOOT_SH_HOST" --apply --default-osneu || die "local-boot apply failed"
fi

# 4) Security harden (SUID sandbox + kiosk.env) — live only
if [[ "$DRY" = 0 && -z "$D" ]]; then
  HELPER="$APP/node_modules/electron/dist/chrome-sandbox"
  if [[ -e "$HELPER" ]]; then
    chown root:root "$HELPER"
    chmod 4755 "$HELPER"
    note "chrome-sandbox $(stat -c '%U:%G %a' "$HELPER")"
  else
    note "WARN no chrome-sandbox in seed — run npm install before packing"
  fi
  mkdir -p "$APP/data" "$KHOME/.config/osneu-kiosk"
  chmod 700 "$APP/data"
  if [[ ! -f "$KHOME/.config/osneu-kiosk/kiosk.env" ]]; then
    cat > "$KHOME/.config/osneu-kiosk/kiosk.env" <<'ENV'
# Appliance defaults — read by osneu-local-kiosk.sh
OSNEU_COMPOSITOR=sway
OSNEU_ZOOM=2
NEUOS_WIZARD=0
NEUOS_POWER_GUARD=0
ENV
    chmod 600 "$KHOME/.config/osneu-kiosk/kiosk.env"
  fi
  chown -R "$KUSER:$KUSER" "$KHOME/.config/osneu-kiosk" "$APP/data"
elif [[ "$DRY" = 1 ]]; then
  note "DRY harden chrome-sandbox + kiosk.env"
elif [[ -n "$D" ]]; then
  mkdir -p "$TARGET_HOME/.config/osneu-kiosk" "$TARGET_APP/data"
  cat > "$TARGET_HOME/.config/osneu-kiosk/kiosk.env" <<'ENV'
# Appliance defaults — read by osneu-local-kiosk.sh
OSNEU_COMPOSITOR=sway
OSNEU_ZOOM=2
NEUOS_WIZARD=0
NEUOS_POWER_GUARD=0
ENV
  note "DESTDIR wrote kiosk.env under $TARGET_HOME"
fi

# 5) Mark done
if [[ "$DRY" = 0 ]]; then
  mkdir -p "$(dirname "$TARGET_MARK")"
  printf 'done=%s\napp=%s\n' "$(date -Is)" "$APP" > "$TARGET_MARK"
  if [[ -z "$D" ]]; then
    chown "$KUSER:$KUSER" "$MARK_DONE"
    systemctl daemon-reload || true
    note "firstboot complete — next reboot uses GRUB default os.neu (Ubuntu remains in menu)"
  else
    note "DESTDIR firstboot complete under $D"
  fi
fi

note "OK"
exit 0
