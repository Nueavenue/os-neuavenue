#!/usr/bin/env bash
# Pack Ubuntu Server + os.neu kiosk factory seed (no disk wipe on this host).
#
#   bash osneu-appliance-pack.sh pack [--out DIR] [--full-modules]
#   bash osneu-appliance-pack.sh verify [--out DIR]
#   bash osneu-appliance-pack.sh dry-firstboot [--out DIR]
#
# Does NOT: download ISO, write USB, format disks, reboot this PC.
# Separate GRANT required for: ISO remaster, dd to media, provision other disk.
set -euo pipefail

CMD="${1:-}"
shift || true
OUT=""
FULL_MOD=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --out) OUT="$2"; shift 2 ;;
    --full-modules) FULL_MOD=1; shift ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="${OUT:-$ROOT/build/appliance-$STAMP}"
SEED="$OUT/osneu-seed"
AUTO="$OUT/autoinstall"
MANIFEST="$OUT/MANIFEST.txt"

die() { echo "FAIL: $*" >&2; exit 1; }
note() { echo "$*"; }

need_file() { [[ -e "$1" ]] || die "missing $1"; }

pack() {
  note "pack root=$ROOT → $OUT"
  mkdir -p "$SEED" "$AUTO" "$OUT/logs"
  need_file "$ROOT/scripts/osneu-local-boot.sh"
  need_file "$ROOT/scripts/osneu-local-kiosk.sh"
  need_file "$ROOT/scripts/appliance/osneu-appliance-firstboot.sh"
  need_file "$ROOT/scripts/appliance/autoinstall/user-data"
  need_file "$ROOT/dist-web"
  need_file "$ROOT/node_modules/electron/dist/chrome-sandbox"

  # Seed: app tree without .git / huge caches; electron + prod runtime
  rsync -a \
    --exclude '.git' \
    --exclude 'build/' \
    --exclude 'coverage/' \
    --exclude '.vite' \
    --exclude '.vite-temp' \
    --exclude 'data/*.json' \
    --exclude 'data/*.jsonl' \
    --exclude 'data/backups/' \
    --exclude 'node_modules' \
    --exclude 'dist/neuos-usb' \
    --exclude 'dist/neuos-usb-*' \
    --exclude 'dist/*.img' \
    --exclude 'dist/*.iso' \
    "$ROOT/" "$SEED/"

  mkdir -p "$SEED/node_modules"
  rsync -a "$ROOT/node_modules/electron/" "$SEED/node_modules/electron/"
  # Minimal runtime deps for screen.js (electron + common natives if present)
  for m in electron electron-store conf atomically type-fest debounce-fn mimic-fn onetime is-obj \
           env-paths dot-prop json-schema-typed ajv uri-js fast-deep-equal json-schema-traverse \
           require-from-string; do
    if [[ -d "$ROOT/node_modules/$m" ]]; then
      rsync -a "$ROOT/node_modules/$m/" "$SEED/node_modules/$m/"
    fi
  done

  if [[ "$FULL_MOD" = 1 ]]; then
    note "FULL_MOD: copying entire node_modules (large)"
    rsync -a --delete "$ROOT/node_modules/" "$SEED/node_modules/"
  fi

  # Autoinstall templates
  cp -a "$ROOT/scripts/appliance/autoinstall/user-data" "$AUTO/user-data"
  cp -a "$ROOT/scripts/appliance/autoinstall/meta-data" "$AUTO/meta-data"

  # Firstboot unit (also embedded in late-commands; keep copy for operators)
  cat > "$OUT/osneu-appliance-firstboot.service" <<'UNIT'
[Unit]
Description=os.neu appliance first boot plant
After=network-online.target
Wants=network-online.target
ConditionPathExists=!/home/osneu/.config/osneu-appliance/firstboot.done

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/osneu-appliance-firstboot.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
UNIT

  # Operator README (short)
  cat > "$OUT/README-FACTORY.txt" <<EOF
os.neu appliance factory pack — $STAMP
Hidden host = Ubuntu Server. Product surface = Direct-boot kiosk (GRUB os.neu).
Not a custom kernel. Not "boots without Linux".

Contents:
  autoinstall/     cloud-init nocloud (user-data, meta-data)
  osneu-seed/      planted to /opt/osneu-seed then ~/neuOS on first boot
  osneu-appliance-firstboot.service

Safe next steps on THIS Leader PC:
  bash scripts/appliance/osneu-appliance-pack.sh verify --out $OUT
  bash scripts/appliance/osneu-appliance-pack.sh dry-firstboot --out $OUT

Needs separate Leader GRANT (destructive):
  - Download Ubuntu Server ISO + remaster with this autoinstall + seed
  - Write installer USB / provision another disk
  - Wipe any disk on neuavenue or other machines

Default login (change before ship): osneu / ChangeMe-osneu
EOF

  {
    echo "stamp=$STAMP"
    echo "root=$ROOT"
    echo "out=$OUT"
    echo "seed_bytes=$(du -sb "$SEED" | awk '{print $1}')"
    echo "electron=$(test -e "$SEED/node_modules/electron/dist/chrome-sandbox" && echo yes || echo no)"
    echo "dist_web=$(test -d "$SEED/dist-web" && echo yes || echo no)"
    echo "firstboot=$(test -x "$SEED/scripts/appliance/osneu-appliance-firstboot.sh" && echo yes || echo no)"
    echo "local_boot=$(test -x "$SEED/scripts/osneu-local-boot.sh" && echo yes || echo no)"
    echo "claim=hidden_ubuntu_host_plus_kiosk_not_custom_kernel"
  } > "$MANIFEST"

  (cd "$OUT" && find . -type f ! -name 'SHA256SUMS' -print0 | sort -z | xargs -0 sha256sum) > "$OUT/SHA256SUMS"

  note "OK pack $OUT"
  cat "$MANIFEST"
}

verify() {
  [[ -d "$OUT" ]] || die "missing out $OUT — run pack first"
  need_file "$OUT/MANIFEST.txt"
  need_file "$OUT/autoinstall/user-data"
  need_file "$OUT/osneu-seed/scripts/appliance/osneu-appliance-firstboot.sh"
  need_file "$OUT/osneu-seed/scripts/osneu-local-boot.sh"
  need_file "$OUT/osneu-seed/node_modules/electron/dist/chrome-sandbox"
  need_file "$OUT/osneu-seed/dist-web"

  python3 - <<'PY' "$OUT/autoinstall/user-data"
import sys
p = sys.argv[1]
raw = open(p, encoding="utf-8").read()
# Strip leading comment block before first autoinstall-ish YAML; keep as text check
assert "autoinstall:" in raw, "user-data missing autoinstall"
assert "username: osneu" in raw
assert "osneu-appliance-firstboot" in raw
assert "ChangeMe-osneu" in raw or "password:" in raw
print("user-data structure OK")
PY

  # Checksums
  (cd "$OUT" && sha256sum -c SHA256SUMS >/dev/null)
  note "OK verify $OUT"
}

dry_firstboot() {
  [[ -d "$OUT/osneu-seed" ]] || die "missing seed — pack first"
  DEST="/tmp/osneu-appliance-dry-$STAMP"
  mkdir -p "$DEST"
  export OSNEU_SEED="$OUT/osneu-seed"
  export OSNEU_DESTDIR="$DEST"
  export OSNEU_USER=osneu
  export NEUOS_APP="/home/osneu/neuOS"
  export OSNEU_FIRSTBOOT_LOG="$DEST/firstboot.log"
  bash "$OUT/osneu-seed/scripts/appliance/osneu-appliance-firstboot.sh" --dry-run
  # Also exercise DESTDIR plant path (no --dry-run) into /tmp only
  bash "$OUT/osneu-seed/scripts/appliance/osneu-appliance-firstboot.sh"
  need_file "$DEST/home/osneu/neuOS/scripts/osneu-local-boot.sh"
  need_file "$DEST/etc/grub.d/40_osneu" || need_file "$DEST/boot/grub/custom.cfg" || true
  # local-boot --apply under DESTDIR writes units under DEST
  if [[ -d "$DEST/etc/systemd/system" ]]; then
    note "DESTDIR systemd present"
  fi
  note "OK dry-firstboot DEST=$DEST"
  echo "$DEST" > "$OUT/logs/last-dry-destdir.txt"
}

case "$CMD" in
  pack) pack ;;
  verify) verify ;;
  dry-firstboot) dry_firstboot ;;
  *)
    echo "usage: $0 pack|verify|dry-firstboot [--out DIR] [--full-modules]" >&2
    exit 2
    ;;
esac
