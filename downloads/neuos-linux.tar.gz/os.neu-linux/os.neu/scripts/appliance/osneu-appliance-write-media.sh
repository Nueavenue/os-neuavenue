#!/usr/bin/env bash
# Write remastered appliance ISO to a removable installer USB.
#
#   sudo bash osneu-appliance-write-media.sh --iso /tmp/osneu-appliance.iso --device /dev/sdd --yes
#   bash osneu-appliance-write-media.sh --plan --device /dev/sdd
#
# HARD BANS (exit 2):
#   /dev/sdb  — neuavenue root
#   /dev/sda  — internal NTFS data disks on this host
#   /dev/sdc  — 7TB Data-01/02 volume
# Only removable USB (RM=1) accepted unless --force-internal (still bans sda/sdb/sdc).
set -euo pipefail

ISO=""
DEV=""
YES=0
PLAN=0
FORCE_INTERNAL=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --iso) ISO="$2"; shift 2 ;;
    --device) DEV="$2"; shift 2 ;;
    --yes) YES=1; shift ;;
    --plan) PLAN=1; shift ;;
    --force-internal) FORCE_INTERNAL=1; shift ;;
    -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
    *) echo "unknown: $1" >&2; exit 2 ;;
  esac
done

die() { echo "FAIL: $*" >&2; exit 1; }
ban() { echo "BANNED: $*" >&2; exit 2; }
note() { echo "$*"; }

[[ -n "$DEV" ]] || die "--device required"
DEV="$(readlink -f "$DEV")"
[[ -b "$DEV" ]] || die "not a block device: $DEV"
# whole disk only
[[ "$DEV" =~ ^/dev/sd[a-z]$ || "$DEV" =~ ^/dev/nvme[0-9]+n[0-9]+$ ]] || die "pass whole disk (e.g. /dev/sdd), not a partition"

case "$DEV" in
  /dev/sdb|/dev/sda|/dev/sdc) ban "$DEV is protected on neuavenue (root or data)" ;;
esac
# also ban by mount of /
ROOT_SRC="$(findmnt -no SOURCE /)"
ROOT_DISK="$(lsblk -no PKNAME "$ROOT_SRC" 2>/dev/null || true)"
[[ -n "$ROOT_DISK" && "$DEV" = "/dev/$ROOT_DISK" ]] && ban "$DEV hosts mounted /"

RM="$(lsblk -no RM "$DEV" | head -1 | tr -d ' ')"
TRAN="$(lsblk -no TRAN "$DEV" | head -1 | tr -d ' ')"
MODEL="$(lsblk -no MODEL "$DEV" | head -1)"
SIZE="$(lsblk -no SIZE "$DEV" | head -1)"
NAME="$(basename "$DEV")"

if [[ "$RM" != "1" && "$FORCE_INTERNAL" != "1" ]]; then
  die "$DEV is not removable (RM=$RM TRAN=$TRAN). Refusing. Use a USB stick."
fi

note "PLAN device=$DEV model=$MODEL size=$SIZE rm=$RM tran=$TRAN"
lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT "$DEV"

if [[ "$PLAN" = 1 ]]; then
  note "plan only — no write"
  exit 0
fi

[[ -n "$ISO" && -s "$ISO" ]] || die "--iso required for write"
[[ "$YES" = 1 ]] || die "refusing write without --yes"
[[ "$(id -u)" = 0 ]] || die "write requires root"

# Unmount any mounted partitions on device
while read -r mp; do
  [[ -n "$mp" ]] || continue
  note "umount $mp"
  umount "$mp" || umount -l "$mp" || true
done < <(lsblk -no MOUNTPOINT "$DEV" | awk 'NF')

note "dd $ISO → $DEV"
dd if="$ISO" of="$DEV" bs=4M status=progress oflag=sync conv=fsync
sync
blockdev --rereadpt "$DEV" || true
sleep 2
note "post-write lsblk:"
lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT "$DEV"
# Verify ISO9660 signature / readable
if command -v blkid >/dev/null; then
  blkid "$DEV" || true
  blkid "${DEV}1" 2>/dev/null || true
fi
note "OK wrote $ISO → $DEV"
