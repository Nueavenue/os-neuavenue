#!/usr/bin/env bash
# Remaster Ubuntu Server live ISO with os.neu appliance autoinstall + seed.
# Does NOT write disks. Write media separately with osneu-appliance-write-media.sh.
#
#   bash osneu-appliance-remaster.sh \
#     --iso /path/to/ubuntu-24.04.x-live-server-amd64.iso \
#     --pack /tmp/osneu-appliance-20261121 \
#     --out /tmp/osneu-appliance.iso
#
# Hard bans: never targets neuavenue root (/dev/sdb). Scratch under /tmp only.
set -euo pipefail

ISO=""
PACK=""
OUT=""
WORK=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --iso) ISO="$2"; shift 2 ;;
    --pack) PACK="$2"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    --work) WORK="$2"; shift 2 ;;
    -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
    *) echo "unknown: $1" >&2; exit 2 ;;
  esac
done

die() { echo "FAIL: $*" >&2; exit 1; }
note() { echo "$*"; }

[[ -n "$ISO" && -f "$ISO" ]] || die "--iso required"
[[ -n "$PACK" && -d "$PACK/autoinstall" && -d "$PACK/osneu-seed" ]] || die "--pack required (autoinstall + osneu-seed)"
OUT="${OUT:-/tmp/osneu-appliance-$(date -u +%Y%m%dT%H%M%SZ).iso}"
WORK="${WORK:-/tmp/osneu-iso-work-$$}"
SRC="$WORK/src"
MBR="$WORK/mbr.img"
EFIIMG="$WORK/efi.img"

command -v xorriso >/dev/null || die "xorriso missing"
command -v rsync >/dev/null || die "rsync missing"

rm -rf "$WORK"
mkdir -p "$SRC" "$WORK/logs"

note "extract $ISO → $SRC"
xorriso -osirrox on -indev "$ISO" -extract / "$SRC" 2>"$WORK/logs/extract.log"
# Extracted tree is often mode 555 / non-writable — fix before inject/patch.
chmod -R u+rwX "$SRC"

[[ -d "$SRC/casper" || -d "$SRC/install" ]] || die "not an Ubuntu live/server ISO layout"
[[ -f "$SRC/boot/grub/grub.cfg" ]] || die "missing boot/grub/grub.cfg"

note "inject nocloud + osneu-seed"
mkdir -p "$SRC/nocloud"
cp -a "$PACK/autoinstall/user-data" "$SRC/nocloud/user-data"
cp -a "$PACK/autoinstall/meta-data" "$SRC/nocloud/meta-data"
# cloud-init wants user-data without requiring #cloud-config only once — keep as-is
rsync -a --delete "$PACK/osneu-seed/" "$SRC/osneu-seed/"

note "patch grub for autoinstall"
patch_grub() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  cp -a "$f" "$f.bak"
  # Insert autoinstall ds= after vmlinuz token on linux lines that lack it.
  python3 - "$f" <<'PY'
import pathlib, re, sys
p = pathlib.Path(sys.argv[1])
text = p.read_text(encoding="utf-8", errors="replace")
needle = r"autoinstall ds=nocloud\\;s=/cdrom/nocloud/"
def fix_line(line: str) -> str:
    if "vmlinuz" not in line:
        return line
    if "autoinstall" in line:
        return line
    # linux /casper/vmlinuz [args...] ---
    return re.sub(
        r"(vmlinuz\S*)(\s+)",
        r"\1 autoinstall ds=nocloud\;s=/cdrom/nocloud/\2",
        line,
        count=1,
    )
out = "\n".join(fix_line(L) for L in text.splitlines())
if not text.endswith("\n"):
    pass
else:
    out += "\n"
p.write_text(out, encoding="utf-8")
print(f"patched {p}")
PY
}
patch_grub "$SRC/boot/grub/grub.cfg"
patch_grub "$SRC/boot/grub/loopback.cfg"
# Some ISOs also ship EFI grub copy
find "$SRC" -path '*/grub.cfg' -o -path '*/loopback.cfg' 2>/dev/null | while read -r g; do
  patch_grub "$g"
done

# Record claim file on media
cat > "$SRC/OSNEU-APPLIANCE.txt" <<EOF
os.neu appliance installer media
Hidden host = Ubuntu Server. Not a custom kernel.
Pack source: $PACK
Base ISO: $ISO
Built: $(date -Is)
EOF

note "capture boot images from original ISO"
# Hybrid MBR (first 446 bytes) + EFI system partition image from original
dd if="$ISO" bs=1 count=446 of="$MBR" status=none
# Locate EFI partition start/size via xorriso report
EFI_START=""
EFI_SIZE=""
eval "$(xorriso -indev "$ISO" -report_system_area as_mkisofs 2>/dev/null | python3 - <<'PY'
import sys, re
text = sys.stdin.read()
# Fallback parse from -report_el_torito
print("")
PY
)"
# Prefer el torito appended partition 2 for EFI
REPORT="$(xorriso -indev "$ISO" -report_el_torito plain -report_system_area plain 2>&1 || true)"
echo "$REPORT" > "$WORK/logs/xorriso-report.txt"
# Extract efi.img from ISO if present
if [[ -f "$SRC/boot/grub/efi.img" ]]; then
  cp -a "$SRC/boot/grub/efi.img" "$EFIIMG"
elif [[ -f "$SRC/EFI/boot/bootx64.efi" ]]; then
  # Build a small FAT efi image from EFI tree
  truncate -s 10M "$EFIIMG"
  mkfs.vfat -n ESP "$EFIIMG" >/dev/null
  mmd -i "$EFIIMG" ::/EFI ::/EFI/boot 2>/dev/null || true
  mcopy -i "$EFIIMG" "$SRC/EFI/boot/"* ::/EFI/boot/ 2>/dev/null || {
    # fallback: use xorriso interval extract if available
    note "WARN mcopy missing — will try xorriso replay path"
  }
fi

note "rebuild ISO → $OUT"
# Use xorriso boot_image replay when possible (most reliable for Ubuntu hybrids)
if xorriso -indev "$ISO" -outdev "$OUT" -boot_image any replay \
    -map "$SRC/nocloud" /nocloud \
    -map "$SRC/osneu-seed" /osneu-seed \
    -map "$SRC/OSNEU-APPLIANCE.txt" /OSNEU-APPLIANCE.txt \
    -map "$SRC/boot/grub/grub.cfg" /boot/grub/grub.cfg \
    -map "$SRC/boot/grub/loopback.cfg" /boot/grub/loopback.cfg \
    -chmod_r u+r,go+r /nocloud -- \
    2>"$WORK/logs/rebuild-replay.log"; then
  note "rebuild via boot_image replay OK"
else
  note "replay failed — falling back to mkisofs mode"
  [[ -f "$EFIIMG" ]] || die "no efi.img for mkisofs fallback — see $WORK/logs"
  xorriso -as mkisofs \
    -r -V "OSNEU_APPLIANCE" \
    -o "$OUT" \
    --grub2-mbr "$MBR" \
    -partition_offset 16 \
    --mbr-force-bootable \
    -append_partition 2 0xef "$EFIIMG" \
    -appended_part_as_gpt \
    -iso_mbr_part_type 0x00 \
    -c /boot.catalog \
    -b /boot/grub/i386-pc/eltorito.img \
    -no-emul-boot -boot-load-size 4 -boot-info-table --grub2-boot-info \
    -eltorito-alt-boot \
    -e '--interval:appended_partition_2:::' \
    -no-emul-boot \
    "$SRC" 2>"$WORK/logs/rebuild-mkisofs.log"
fi

[[ -s "$OUT" ]] || die "output ISO empty"
# Verify injected paths exist inside new ISO
xorriso -indev "$OUT" -ls /nocloud /osneu-seed 2>"$WORK/logs/verify-ls.log" | tee "$WORK/logs/verify-ls.out"
xorriso -indev "$OUT" -cat_md5 /boot/grub/grub.cfg 2>/dev/null | head -1 || true
if ! xorriso -indev "$OUT" -exec pwd -- -find /boot/grub/grub.cfg -exec cat -- 2>/dev/null | grep -q 'autoinstall'; then
  # alternate cat
  TMPG="$WORK/grub-out.cfg"
  xorriso -osirrox on -indev "$OUT" -extract /boot/grub/grub.cfg "$TMPG" 2>/dev/null || true
  grep -q 'autoinstall' "$TMPG" || die "remastered ISO grub.cfg missing autoinstall"
fi

SHA="$(sha256sum "$OUT" | awk '{print $1}')"
SIZE="$(stat -c%s "$OUT")"
cat > "${OUT}.sha256" <<EOF
$SHA  $(basename "$OUT")
EOF
cat > "${OUT}.MANIFEST.txt" <<EOF
out=$OUT
bytes=$SIZE
sha256=$SHA
base_iso=$ISO
pack=$PACK
work=$WORK
claim=hidden_ubuntu_host_plus_kiosk_not_custom_kernel
built=$(date -Is)
EOF
note "OK $OUT ($SIZE bytes)"
note "sha256 $SHA"
echo "$OUT"
