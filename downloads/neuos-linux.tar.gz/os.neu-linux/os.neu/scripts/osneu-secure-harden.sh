#!/usr/bin/env bash
# GRANT 2 — apply Chromium SUID sandbox, tighten local perms, snapshot dist-web.
# Does not delete files. Does not change GRUB. Does not reboot.
set -euo pipefail
APP="${NEUOS_APP:-$HOME/neuOS}"
HELPER="$APP/node_modules/electron/dist/chrome-sandbox"
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/osneu"
SNAP_ROOT="$STATE/dist-snapshots"
MODE="${1:-apply}"

die() { echo "FAIL: $*" >&2; exit 1; }
note() { echo "$*"; }

[[ "$(id -u)" != 0 ]] || die "run as the kiosk user, not root (pkexec is used only for chrome-sandbox)"

case "$MODE" in
  apply|check|snapshot) ;;
  *) die "usage: $0 [apply|check|snapshot]" ;;
esac

sandbox_ok() {
  [[ -e "$HELPER" ]] || return 1
  [[ "$(stat -c %u "$HELPER")" = 0 ]] || return 1
  [[ -u "$HELPER" ]] || return 1
}

apply_sandbox() {
  if sandbox_ok; then
    note "chrome-sandbox already root setuid: $(stat -c '%U:%G %a' "$HELPER")"
    return 0
  fi
  [[ -e "$HELPER" ]] || die "missing $HELPER — run npm install in $APP"
  note "Setting chrome-sandbox root:root mode 4755 (pkexec may ask for a password)…"
  pkexec bash -c "chown root:root '$HELPER' && chmod 4755 '$HELPER'" || die "pkexec chrome-sandbox failed"
  sandbox_ok || die "chrome-sandbox still not root setuid after pkexec"
  note "chrome-sandbox OK: $(stat -c '%U:%G %a' "$HELPER")"
}

tighten_perms() {
  mkdir -p "$APP/data" "$HOME/.config/osneu-kiosk"
  chmod 700 "$APP/data" 2>/dev/null || true
  chmod 700 "$HOME/.config/osneu-kiosk" 2>/dev/null || true
  [[ -f "$HOME/.config/osneu-kiosk/kiosk.env" ]] && chmod 600 "$HOME/.config/osneu-kiosk/kiosk.env" || true
  for f in user-llm.json oauth-handoff.json accounts.json; do
    [[ -f "$APP/data/$f" ]] && chmod 600 "$APP/data/$f" || true
  done
  note "perms: data=$(stat -c %a "$APP/data") kiosk.cfg=$(stat -c %a "$HOME/.config/osneu-kiosk" 2>/dev/null || echo missing)"
}

snapshot_dist() {
  local idx js css stamp dest
  idx="$APP/dist-web/index.html"
  [[ -s "$idx" ]] || die "missing $idx — npm run build first"
  js="$(grep -oE 'index-[A-Za-z0-9_-]+\.js' "$idx" | head -1 || true)"
  css="$(grep -oE 'index-[A-Za-z0-9_-]+\.css' "$idx" | head -1 || true)"
  [[ -n "$js" && -s "$APP/dist-web/assets/$js" ]] || die "bundle js not found in $idx"
  stamp="$(date +%Y%m%dT%H%M%S)"
  dest="$SNAP_ROOT/$stamp"
  mkdir -p "$dest/assets"
  cp -a "$idx" "$dest/index.html"
  cp -a "$APP/dist-web/assets/$js" "$dest/assets/$js"
  [[ -n "$css" && -s "$APP/dist-web/assets/$css" ]] && cp -a "$APP/dist-web/assets/$css" "$dest/assets/$css"
  {
    echo "stamp=$stamp"
    echo "app=$APP"
    echo "js=$js"
    echo "css=${css:-}"
    echo "bridge_sha=$(sha256sum "$APP/dist-bridge/index.mjs" 2>/dev/null | awk '{print $1}')"
    echo "created=$(date -Is)"
  } > "$dest/info.txt"
  [[ -s "$dest/index.html" && -s "$dest/info.txt" ]] || die "snapshot incomplete"
  note "snapshot $dest (js=$js)"
  # Keep a pointer to the latest snapshot (overwrite non-empty).
  printf '%s\n' "$stamp" > "$SNAP_ROOT/LATEST"
}

print_check() {
  echo "=== os.neu security check ==="
  echo "user=$(id -un) uid=$(id -u) (must not be root)"
  echo "app=$APP"
  if sandbox_ok; then echo "chromium_sandbox=ON $(stat -c '%U:%G %a' "$HELPER")"
  else echo "chromium_sandbox=OFF helper=$(stat -c '%U:%G %a' "$HELPER" 2>/dev/null || echo missing)"
  fi
  echo "userns_clone=$(sysctl -n kernel.unprivileged_userns_clone 2>/dev/null || echo ?)"
  echo "apparmor_restrict_userns=$(sysctl -n kernel.apparmor_restrict_unprivileged_userns 2>/dev/null || echo ?)"
  echo "sway=$(command -v sway || echo missing) fcitx5=$(command -v fcitx5 || echo missing) foot=$(command -v foot || echo missing) cage=$(command -v cage || echo missing)"
  echo "gnome-keyring-daemon=$(command -v gnome-keyring-daemon || echo missing)"
  echo "kiosk.env compositor=$(grep -E '^OSNEU_COMPOSITOR=' "$HOME/.config/osneu-kiosk/kiosk.env" 2>/dev/null || echo unset)"
  echo "service_user=$(grep -E '^User=' /etc/systemd/system/osneu-kiosk.service 2>/dev/null || echo missing)"
  echo "dist=$(grep -oE 'index-[A-Za-z0-9_-]+\.js' "$APP/dist-web/index.html" 2>/dev/null | head -1 || echo missing)"
  echo "latest_snapshot=$(cat "$SNAP_ROOT/LATEST" 2>/dev/null || echo none)"
  echo "recovery: GRUB Ubuntu entry · Ctrl+Alt+t console · Ctrl+Alt+Shift+e leave sway · bash $APP/scripts/osneu-dist-rollback.sh <stamp>"
}

case "$MODE" in
  check)
    print_check
    ;;
  snapshot)
    snapshot_dist
    print_check
    ;;
  apply)
    apply_sandbox
    tighten_perms
    snapshot_dist
    print_check
    ;;
esac
