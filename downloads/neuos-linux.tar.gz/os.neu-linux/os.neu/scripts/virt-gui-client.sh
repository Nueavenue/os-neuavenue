#!/bin/sh
# QEMU-only observer for the real packaged Electron client.
# The physical USB path never sets NEUOS_VIRT_TEST and does not call this file.
set -u

APP="${NEUOS_ROOT:-/opt/neuos}"
ELECTRON="${NEUOS_ELECTRON:-/opt/neuos/runtime/electron/electron}"
NODE="${NEUOS_NODE:-/opt/neuos/runtime/node}"
DIAG_JS="$APP/scripts/input-diag.mjs"
SERIAL=""
for t in $(cat /sys/class/tty/console/active 2>/dev/null); do
  case "$t" in
    ttyS[0-9]*|ttyAMA[0-9]*|hvc[0-9]*) SERIAL="/dev/$t"; break ;;
  esac
done
[ -n "$SERIAL" ] || SERIAL=/dev/ttyS0

diag() {
  [ -x "$NODE" ] && [ -f "$DIAG_JS" ] && "$NODE" "$DIAG_JS" "$@" >/dev/null 2>&1 || true
}

mark() {
  echo "$1"
  if [ -c "$SERIAL" ]; then
    echo "$1" > "$SERIAL" 2>/dev/null || true
  fi
}

dump_electron_log() {
  [ -f /tmp/osneu-virt-electron.log ] || return 0
  tail -n 40 /tmp/osneu-virt-electron.log 2>/dev/null | while IFS= read -r line; do
    mark "NEUOS_VIRT_ELECTRON_LOG:$line"
  done
}

health_ok() {
  [ -x "$NODE" ] || return 1
  "$NODE" -e '
    const http = require("http");
    const req = http.get("http://127.0.0.1:4178/api/health", (res) => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    });
    req.on("error", () => process.exit(1));
    req.setTimeout(800, () => { req.destroy(); process.exit(1); });
  ' >/dev/null 2>&1
}

export NEUOS_PACKAGED="${NEUOS_PACKAGED:-1}"
export NEUOS_VIRT_TEST="${NEUOS_VIRT_TEST:-1}"
export NEUOS_SCREEN="${NEUOS_SCREEN:-1}"
export NEUOS_DRIVER="${NEUOS_DRIVER:-live}"
export NEUOS_ROOT="${NEUOS_ROOT:-$APP}"
# QEMU user-net maps 10.0.2.2 to the host's loopback: a host Ollama on
# 127.0.0.1:11434 is the guest's local model. Virt only; USB keeps localhost.
export OLLAMA_HOST="${OLLAMA_HOST:-http://10.0.2.2:11434}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/tmp/osneu-cache}"
mkdir -p "$XDG_CACHE_HOME"
export HOME=/tmp/osneu-home
mkdir -p "$HOME"

mkdir -p /tmp/osneu-electron-profile /tmp/osneu-electron-cache
rm -f /tmp/osneu-window-ok
mark "[app] launcher entered uid=$(id -u 2>/dev/null) pwd=$(pwd) XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-} WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-} socket=$( [ -S "${XDG_RUNTIME_DIR:-/nonexistent}/${WAYLAND_DISPLAY:-x}" ] && echo yes || echo no )"
mark "[app] exec starting $ELECTRON"
: > /tmp/osneu-virt-electron.log
"$ELECTRON" "$APP" --no-sandbox --disable-gpu --disable-gpu-compositing \
  --disable-gpu-sandbox --password-store=basic \
  --user-data-dir=/tmp/osneu-electron-profile \
  --disk-cache-dir=/tmp/osneu-electron-cache \
  >/tmp/osneu-virt-electron.log 2>&1 &
electron_pid=$!
mark "[app] electron pid=$electron_pid"
if [ -x "$NODE" ] && [ -f "$DIAG_JS" ]; then
  "$NODE" "$DIAG_JS" follow /tmp/osneu-virt-electron.log electron >/dev/null 2>&1 &
fi
mark "NEUOS_VIRT_COMPOSITOR_READY"

compositor_pid() {
  pid="${1:-$$}"
  i=0
  while [ "$i" -lt 12 ]; do
    [ -r "/proc/$pid/comm" ] || break
    comm=$(cat "/proc/$pid/comm" 2>/dev/null || true)
    case "$comm" in
      cage|weston)
        echo "$pid"
        return 0
        ;;
    esac
    pp=$(awk '/^PPid:/{print $2}' "/proc/$pid/status" 2>/dev/null || true)
    [ -n "$pp" ] && [ "$pp" != 0 ] && [ "$pp" != "$pid" ] || break
    pid="$pp"
    i=$((i + 1))
  done
  for d in /proc/[0-9]*; do
    comm=$(cat "$d/comm" 2>/dev/null || true)
    case "$comm" in
      cage|weston)
        echo "${d##*/}"
        return 0
        ;;
    esac
  done
  return 1
}

# JeOS BusyBox has no readlink applet; `ls -l` prints the fd targets.
compositor_input_fds() {
  ls -l "/proc/$1/fd" 2>/dev/null | grep -c ' /dev/input/' || true
}

cpid="$(compositor_pid $$ || true)"
opened=0
if [ -n "$cpid" ]; then
  w=0
  while [ "$w" -lt 8 ]; do
    opened="$(compositor_input_fds "$cpid")"
    [ "$opened" != "0" ] && break
    w=$((w + 1))
    sleep 1
  done
  ev=0
  for e in /dev/input/event*; do
    [ -e "$e" ] || continue
    ev=$((ev + 1))
  done
  mark "NEUOS_VIRT_COMPOSITOR_INPUT_FDS:$opened pid=$cpid comm=$(cat /proc/$cpid/comm 2>/dev/null) event_nodes=$ev"
  devfds="$(ls -l "/proc/$cpid/fd" 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="->" && $(i+1) ~ /^\/dev\//) s[$(i+1)]=1} END{for(k in s) printf "%s ", k}' || true)"
  mark "NEUOS_VIRT_COMPOSITOR_DEV_FDS: ${devfds:-none}"
  # Report only. On 2026-10-27 this read 0 while cage had libinput up and
  # the landing painted; killing on it would drop a live seat.
  if [ "$opened" = "0" ] && [ "$ev" -ge 1 ]; then
    mark "NEUOS_VIRT_NO_LIBINPUT_FDS_SEEN"
  fi
fi

i=0
while [ "$i" -lt 60 ]; do
  if ! kill -0 "$electron_pid" 2>/dev/null; then
    wait "$electron_pid"
    status=$?
    dump_electron_log
    mark "[app] exit=$status"
    mark "NEUOS_VIRT_ELECTRON_EXIT:$status"
    exit "$status"
  fi
  if health_ok && [ -f /tmp/osneu-window-ok ]; then
    sleep 3
    kill -0 "$electron_pid" 2>/dev/null || continue
    mark "NEUOS_VIRT_GUI_OK"
    mark "NEUOS_VIRT_WINDOW_OK"
    diag procs
    diag net
    diag status
    wait "$electron_pid"
    status=$?
    mark "[app] exit=$status"
    exit "$status"
  fi
  i=$((i + 1))
  sleep 1
done

dump_electron_log
mark "NEUOS_VIRT_GUI_TIMEOUT"
kill "$electron_pid" 2>/dev/null || true
wait "$electron_pid" 2>/dev/null || true
exit 4
