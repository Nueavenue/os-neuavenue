#!/bin/sh
# Raise the os.neu screen from the USB JeOS session itself.
# No Ubuntu login. No host /home plant. No GDM.
# cage (or weston) on a free VT + Electron from this stick.
# Does not wipe disks. Does not chmod /dev/dri. Does not use --ozone-platform=drm.
# BusyBox/dash on this stick have no GNU extras — never call `tr`, `basename`, or `dirname`.
set -eu

GO="${NEUOS_GO:-lui}"
export NEUOS_JEOS=1
LOG=/tmp/osneu-usb-screen-jeos.log
APP=/opt/neuos
ELECTRON="${NEUOS_ELECTRON:-/opt/neuos/runtime/electron/electron}"
KIOSK=/opt/neuos/runtime/kiosk
CAGE_BIN=""
SEATD_BIN=""
WESTON_BIN=""

log() {
  echo "os.neu screen: $*"
  echo "os.neu screen: $*" >> "$LOG" 2>/dev/null || true
  if [ "${NEUOS_VIRT_TEST:-0}" = "1" ] && [ -c /dev/ttyS0 ]; then
    echo "os.neu screen: $*" > /dev/ttyS0 2>/dev/null || true
  fi
}

if [ "${NEUOS_USB_SCREEN_DRY:-}" = "1" ]; then
  log "dry-run jeos app=$APP electron=$ELECTRON"
  exit 0
fi

: > "$LOG"
BOOTLOG=/opt/neuos/scripts/osneu-bootlog.sh
bootlog() {
  [ -f "$BOOTLOG" ] && /usr/bin/sh "$BOOTLOG" "$@" </dev/null >/dev/null 2>&1 || true
}
bootlog mark screen-start "go=$GO"
trap 'rc=$?; bootlog mark screen-exit "rc=$rc"' EXIT
if [ -x /usr/bin/ip ]; then
  /usr/bin/ip link set lo up 2>/dev/null || true
elif [ -x /usr/bin/busybox ]; then
  /usr/bin/busybox ip link set lo up 2>/dev/null || true
fi
# VendorCo NEUOS-ROOT: /lib/firmware and /lib/modules inodes are corrupt
# (Bad message / EXT4 dir csum). Never mkdir there. Firmware+modules live
# under /opt/neuos (same tree as neuos-init).
mkdir -p /tmp /run /run/osneu-wl /opt/neuos/firmware /opt/neuos/lib/modules || true
if [ -w /sys/module/firmware_class/parameters/path ]; then
  echo -n /opt/neuos/firmware > /sys/module/firmware_class/parameters/path 2>/dev/null || true
fi
export FIRMWARE_DIR=/opt/neuos/firmware

if [ ! -x "$ELECTRON" ]; then
  log "OS-NEU-SX-000  electron missing at $ELECTRON"
  exit 3
fi
if [ ! -f "$APP/dist-web/index.html" ] || [ ! -f "$APP/dist-bridge/index.mjs" ]; then
  log "OS-NEU-SX-000  packaged UI missing (dist-web / dist-bridge) under $APP"
  exit 3
fi

NODE_BIN=/opt/neuos/runtime/node
DIAG_JS=/opt/neuos/scripts/input-diag.mjs
export NEUOS_DIAG_BOOT="${NEUOS_DIAG_BOOT:-$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | cut -c1-8 || echo boot)}"
: > /tmp/osneu-input-status.env
diag() {
  if [ -x "$NODE_BIN" ] && [ -f "$DIAG_JS" ]; then
    "$NODE_BIN" "$DIAG_JS" "$@" 2>&1 || true
  fi
}
status_set() {
  echo "$1=$2" >> /tmp/osneu-input-status.env
}

# Boot splash steps (neuos.splash=1) and the boot diagnostics service.
SPLASH_JS=/opt/neuos/boot/splash/osneu-splash.mjs
NETDIAG_JS=/opt/neuos/scripts/osneu-netdiag.mjs
SPLASH=0
case " $(cat /proc/cmdline 2>/dev/null) " in
  *" neuos.splash=1 "*) SPLASH=1 ;;
esac
splash() {
  if [ "$SPLASH" = 1 ] && [ -x "$NODE_BIN" ] && [ -f "$SPLASH_JS" ]; then
    "$NODE_BIN" "$SPLASH_JS" "$@" >/dev/null 2>&1 || true
  fi
}
netdiag() {
  if [ ! -x "$NODE_BIN" ] || [ ! -f "$NETDIAG_JS" ]; then
    log "NETDIAG missing $NETDIAG_JS"
    return 1
  fi
  "$NODE_BIN" "$NETDIAG_JS" "$@" >> "$LOG" 2>&1
}
netdiag_note() {
  [ -x "$NODE_BIN" ] && [ -f "$NETDIAG_JS" ] && "$NODE_BIN" "$NETDIAG_JS" note 2>/dev/null || true
}
verdict() {
  case "$1" in
    0) echo ok ;;
    1) echo warn ;;
    *) echo fail ;;
  esac
}
# Any exit (no compositor, cage closed) hands the screen back to the console.
trap 'rc=$?; splash quit; bootlog mark screen-exit "rc=$rc"' EXIT
diag snapshot before-module-load

# GPU (i915) and wired NIC (r8169) are not loaded by neuos-init on purpose.
# Root busybox insmod cannot read .zst, so make-usb stages plain .ko files.
load_open_kmods() {
  dir=/opt/neuos/kmod
  if [ ! -f "$dir/load-order" ]; then
    status_set KMOD_LOAD "MISSING $dir/load-order"
    return 0
  fi
  res=""
  while read -r ko; do
    [ -n "$ko" ] || continue
    name="${ko%.ko}"
    if [ -d "/sys/module/$(echo "$name" | sed 's/-/_/g')" ]; then
      res="$res $name:present"
    elif insmod "$dir/$ko" 2>/tmp/osneu-insmod.err; then
      res="$res $name:ok"
    else
      err="$(head -c 60 /tmp/osneu-insmod.err 2>/dev/null || true)"
      res="$res $name:FAIL(${err:-unknown})"
    fi
  done < "$dir/load-order"
  status_set KMOD_LOAD "${res# }"
  log "KMOD_LOAD${res}"
}
bootlog note kmods-start
load_open_kmods
bootlog note kmods-done "$(grep '^KMOD_LOAD=' /tmp/osneu-input-status.env 2>/dev/null | tail -n 1 | cut -c1-160)"
# Wi-Fi drivers + supplicant in the background; the os.neu setup screen joins
# a network if there is no cable (scripts/osneu-wifi.mjs, electron/wifi.html).
if [ -x "$NODE_BIN" ] && [ -f /opt/neuos/scripts/osneu-wifi.mjs ]; then
  "$NODE_BIN" /opt/neuos/scripts/osneu-wifi.mjs up >> "$LOG" 2>&1 &
fi
# i915 replaces simpledrm's fb0; the next draw paints the new framebuffer.
splash step 1 ok
splash step 2 run

# DHCP on wired NICs in the background. BusyBox udhcpc is on root but nothing
# ran it, so the landing probe always said Offline. Never blocks the screen.
net_up() {
  UDHCPC_SCRIPT=/tmp/osneu-udhcpc.sh
  {
    # JeOS has no /bin; a #!/bin/sh hook never ran (lease taken, no address set).
    echo '#!/usr/bin/sh'
    echo 'case "$1" in'
    echo '  deconfig) ip addr flush dev "$interface" 2>/dev/null; ip link set "$interface" up ;;'
    echo '  bound|renew)'
    echo '    ip addr flush dev "$interface" 2>/dev/null'
    echo '    ip addr add "$ip/${mask:-24}" dev "$interface"'
    echo '    for r in $router; do ip route add default via "$r" dev "$interface" 2>/dev/null; break; done'
    # neuos-init binds /tmp/osneu-resolv.conf over /etc/resolv.conf; build the
    # list in another file or `cat same > same` truncates it to empty.
    echo '    if [ -n "$dns" ]; then : > /tmp/osneu-resolv.dhcp; for d in $dns; do echo "nameserver $d" >> /tmp/osneu-resolv.dhcp; done; cat /tmp/osneu-resolv.dhcp > /etc/resolv.conf 2>/dev/null || true; fi'
    echo '    echo "NETWORK=UP $interface $ip/${mask:-?} gw ${router:-none} dns ${dns:-none}" >> /tmp/osneu-input-status.env'
    echo '    ;;'
    echo 'esac'
  } > "$UDHCPC_SCRIPT"
  chmod +x "$UDHCPC_SCRIPT"
  ifs=""
  w=0
  while [ "$w" -lt 5 ]; do
    for n in /sys/class/net/*; do
      [ -e "$n" ] || continue
      i="${n##*/}"
      case "$i" in lo|wl*|ww*) continue ;; esac
      ifs="$ifs $i"
    done
    [ -n "$ifs" ] && break
    w=$((w + 1))
    sleep 1
  done
  if [ -z "$ifs" ]; then
    status_set NETWORK "NO_WIRED_INTERFACE (Wi-Fi not handled on JeOS)"
    log "NETWORK no wired interface"
    return 0
  fi
  if ! command -v udhcpc >/dev/null 2>&1; then
    status_set NETWORK "NO_DHCP_CLIENT ifs=${ifs# }"
    log "NETWORK udhcpc missing ifs=${ifs# }"
    return 0
  fi
  carriers=""
  for i in $ifs; do
    ip link set "$i" up 2>/dev/null || true
    c=0
    while [ "$c" -lt 5 ] && [ "$(cat "/sys/class/net/$i/carrier" 2>/dev/null)" != "1" ]; do
      c=$((c + 1))
      sleep 1
    done
    carriers="$carriers $i:carrier=$(cat "/sys/class/net/$i/carrier" 2>/dev/null || echo ?)"
    if udhcpc -i "$i" -n -q -t 4 -T 1 -s "$UDHCPC_SCRIPT" >/tmp/osneu-udhcpc.$i.log 2>&1; then
      log "NETWORK dhcp ok on $i"
      return 0
    fi
    log "NETWORK dhcp no lease on $i"
  done
  status_set NETWORK "NO_LEASE${carriers} (carrier=0 means no cable)"
}
net_up &
NET_PID=$!

# Input modules one by one: rc, output, and whether the kernel module is present
# afterwards. Earlier load (initramfs insmod) counts as present, not as this rc.
load_input_mod() {
  m="$1"
  pre=no
  [ -d "/sys/module/$m" ] && pre=yes
  set +e
  out="$(modprobe -v -d /opt/neuos "$m" 2>&1)"
  rc=$?
  if [ "$rc" -ne 0 ]; then
    out2="$(modprobe -v "$m" 2>&1)"
    rc2=$?
    out="$out | fallback rc=$rc2 $out2"
    [ "$rc2" -eq 0 ] && rc=0
  fi
  set -e
  post=no
  [ -d "/sys/module/$m" ] && post=yes
  log "MODLOAD $m before=$pre rc=$rc after=$post ${out:-}" >&2
  if [ "$post" = yes ]; then
    echo "LOADED (before=$pre rc=$rc)"
  else
    echo "FAILED (rc=$rc ${out:-})"
  fi
}
if command -v modprobe >/dev/null 2>&1; then
  status_set VIRTIO_INPUT_LOAD "$(load_input_mod virtio_input)"
  status_set PSMOUSE_LOAD "$(load_input_mod psmouse)"
  tp=""
  for m in i2c_hid_acpi hid_multitouch intel_lpss_pci; do
    tp="$tp $m:$(load_input_mod "$m" | cut -d' ' -f1)"
  done
  status_set TOUCHPAD_LOAD "${tp# }"
  for m in hid hid_generic usbhid evdev \
           drm drm_kms_helper i915 xe amdgpu nouveau virtio_gpu simpledrm virtio_net; do
    modprobe -d /opt/neuos "$m" 2>/dev/null || modprobe "$m" 2>/dev/null || true
  done
else
  # JeOS root has no modprobe binary. Only initramfs insmod can have loaded these.
  for pair in VIRTIO_INPUT_LOAD:virtio_input PSMOUSE_LOAD:psmouse; do
    key="${pair%%:*}"
    m="${pair##*:}"
    if [ -d "/sys/module/$m" ]; then
      status_set "$key" "LOADED (initramfs insmod; no modprobe on root)"
    else
      status_set "$key" "FAILED (not in kernel; no modprobe on root)"
    fi
    log "MODLOAD $m no-modprobe present=$( [ -d "/sys/module/$m" ] && echo yes || echo no )"
  done
  tp=""
  for m in i2c_hid_acpi hid_multitouch intel_lpss_pci; do
    tp="$tp $m:$( [ -d "/sys/module/$m" ] && echo LOADED || echo ABSENT )"
  done
  status_set TOUCHPAD_LOAD "${tp# } (no modprobe on root)"
fi
diag snapshot after-module-load
# GPU often loads after the boot udev settle. Without a second trigger,
# cage/weston see a card but no ID_SEAT / ID_INPUT (OS-NEU-SX-000).
if [ -x /usr/bin/udevadm ]; then
  /usr/bin/udevadm trigger --type=subsystems --action=add 2>/dev/null || true
  /usr/bin/udevadm trigger --type=devices --action=add 2>/dev/null || true
  /usr/bin/udevadm trigger --subsystem-match=input --action=add 2>/dev/null || true
  /usr/bin/udevadm settle --timeout=8 2>/dev/null || true
fi
in_n=0
in_w=0
while [ "$in_w" -lt 8 ]; do
  in_n=0
  for ev in /dev/input/event*; do
    [ -e "$ev" ] || continue
    in_n=$((in_n + 1))
  done
  [ "$in_n" -ge 1 ] && break
  in_w=$((in_w + 1))
  sleep 1
done
log "input event nodes=$in_n"
if [ -x /usr/bin/udevadm ]; then
  for ev in /dev/input/event*; do
    [ -e "$ev" ] || continue
    props="$(/usr/bin/udevadm info -q property -n "$ev" 2>/dev/null | grep -E '^ID_INPUT|^ID_SEAT|^NAME=' || true)"
    log "input ${ev##*/} ${props:-none}"
  done
fi
if [ -x /usr/bin/libinput ]; then
  /usr/bin/libinput list-devices 2>/dev/null | while IFS= read -r line; do
    log "libinput $line"
  done
fi

# JeOS often has /dev/input/event* from devtmpfs while udevd writes no
# properties (event0/1/2 = none). wlroots then exits: "libinput
# initialization failed, no input devices". Stamp the udev db so libinput
# and weston see ID_INPUT / ID_SEAT=seat0. Do not set WLR_LIBINPUT_NO_DEVICES.
stamp_libinput_udev() {
  mkdir -p /run/udev /run/udev/data || true
  if [ ! -S /run/udev/control ] && [ -x /usr/lib/systemd/systemd-udevd ]; then
    log "starting udevd for libinput properties"
    /usr/lib/systemd/systemd-udevd --daemon --resolve-names=never >>/tmp/osneu-udevd.log 2>&1 || true
    s=0
    while [ "$s" -lt 5 ] && [ ! -S /run/udev/control ]; do
      s=$((s + 1))
      sleep 1
    done
  fi
  if [ -x /usr/bin/udevadm ]; then
    /usr/bin/udevadm control --reload-rules 2>/dev/null || true
    /usr/bin/udevadm trigger --subsystem-match=input --action=add 2>/dev/null || true
    /usr/bin/udevadm settle --timeout=5 2>/dev/null || true
  fi
  tagged=0
  pointers=0
  for ev in /dev/input/event*; do
    [ -e "$ev" ] || continue
    base=${ev##*/}
    sysdev="/sys/class/input/$base/dev"
    [ -f "$sysdev" ] || continue
    majmin=$(cat "$sysdev")
    [ -n "$majmin" ] || continue
    name=""
    if [ -f "/sys/class/input/$base/device/name" ]; then
      name=$(cat "/sys/class/input/$base/device/name")
    fi
    kbd=0
    mouse=0
    tablet=0
    # Kernel capabilities decide (EV_REL/EV_ABS X+Y with a button = pointer;
    # KEY_A = keyboard). A label is not hardware. Buttons get key only.
    cls=""
    if [ -x "$NODE_BIN" ] && [ -f "$DIAG_JS" ]; then
      cls="$("$NODE_BIN" "$DIAG_JS" classify "$base" 2>/dev/null || true)"
    fi
    case "$cls" in
      *kbd=1*) kbd=1 ;;
    esac
    case "$cls" in
      *mouse=1*) mouse=1 ;;
    esac
    case "$cls" in
      *tablet=1*) tablet=1 ;;
    esac
    if [ -z "$cls" ]; then
      case "$name" in
        *[Kk]eyboard*|*[Kk]bd*|AT\ Translated*) kbd=1 ;;
      esac
      case "$name" in
        *[Tt]ablet*) tablet=1; mouse=1 ;;
        *[Mm]ouse*|ImPS/2*|*[Tt]rack*) mouse=1 ;;
      esac
    fi
    if [ "$kbd" = 0 ] && [ "$mouse" = 0 ]; then
      kbd=1
    fi
    [ "$mouse" = 1 ] && pointers=$((pointers + 1))
    {
      echo "I:1"
      echo "E:ID_INPUT=1"
      echo "E:ID_SEAT=seat0"
      [ -n "$name" ] && echo "E:NAME=$name"
      [ "$kbd" = 1 ] && echo "E:ID_INPUT_KEY=1" && echo "E:ID_INPUT_KEYBOARD=1"
      [ "$mouse" = 1 ] && echo "E:ID_INPUT_MOUSE=1"
      [ "$tablet" = 1 ] && echo "E:ID_INPUT_TABLET=1"
      echo "G:seat"
      echo "Q:seat"
      echo "V:1"
    } > "/run/udev/data/c${majmin}"
    for inp in /sys/class/input/input*; do
      if [ -e "$inp/$base" ] || [ -d "$inp/$base" ]; then
        iname=${inp##*/}
        {
          echo "I:1"
          echo "E:ID_INPUT=1"
          echo "E:ID_SEAT=seat0"
          [ -n "$name" ] && echo "E:NAME=$name"
          [ "$kbd" = 1 ] && echo "E:ID_INPUT_KEY=1" && echo "E:ID_INPUT_KEYBOARD=1"
          [ "$mouse" = 1 ] && echo "E:ID_INPUT_MOUSE=1"
          [ "$tablet" = 1 ] && echo "E:ID_INPUT_TABLET=1"
          echo "G:seat"
          echo "Q:seat"
          echo "V:1"
        } > "/run/udev/data/+input:${iname}"
      fi
    done
    tagged=$((tagged + 1))
    log "udev-stamp $base c${majmin} name=${name:-unknown} kbd=$kbd mouse=$mouse tablet=$tablet"
  done
  log "udev-stamp tagged=$tagged pointers=$pointers"
  if [ "$pointers" = 0 ]; then
    log "POINTER: MISSING (NO POINTER DEVICE) — kernel capabilities show no pointer. Screen still opens; clicks cannot reach the page."
  fi
  if [ -x /usr/bin/udevadm ]; then
    for ev in /dev/input/event*; do
      [ -e "$ev" ] || continue
      props="$(/usr/bin/udevadm info -q property -n "$ev" 2>/dev/null | grep -E '^ID_INPUT|^ID_SEAT|^NAME=' || true)"
      log "input-after ${ev##*/} ${props:-none}"
    done
  fi
}
stamp_libinput_udev
diag snapshot before-compositor
status_set COMPOSITOR "NOT_STARTED"
diag status
diag esp

# Event counter runs beside the compositor (read-only, no grab) so movement
# is counted while the landing is up. One watcher per boot.
if [ -f /tmp/osneu-input-watch.pid ]; then
  kill "$(cat /tmp/osneu-input-watch.pid)" 2>/dev/null || true
fi
if [ -x "$NODE_BIN" ] && [ -f "$DIAG_JS" ]; then
  "$NODE_BIN" "$DIAG_JS" watch >/dev/null 2>&1 &
  echo $! > /tmp/osneu-input-watch.pid
fi

i=0
while [ "$i" -lt 10 ]; do
  if [ -e /dev/dri/card0 ] || [ -e /dev/dri/card1 ]; then
    break
  fi
  i=$((i + 1))
  sleep 1
done
# No `tr` / `basename` — dash/BusyBox on JeOS do not ship those applets
# (set -eu plus basename in a command substitution aborted: basename not found).
drm_names=""
if [ -d /dev/dri ]; then
  for n in /dev/dri/*; do
    [ -e "$n" ] || continue
    drm_names="$drm_names ${n##*/}"
  done
  log "DRM$drm_names"
else
  log "no /dev/dri yet — compositor may still fail (OS-NEU-SX-000)"
fi

DRM_DEV=""
for card in card1 card0 card2; do
  u="/sys/class/drm/$card/device/uevent"
  [ -f "$u" ] || continue
  drv="$(grep ^DRIVER= "$u" 2>/dev/null | sed 's/^DRIVER=//')"
  log "DRM $card DRIVER=${drv:-unknown}"
  case "$drv" in
    i915|xe|amdgpu|nouveau|virtio_gpu|radeon|simple-framebuffer)
      DRM_DEV="/dev/dri/$card"
      break
      ;;
  esac
done
if [ -z "$DRM_DEV" ]; then
  if [ -e /dev/dri/card1 ]; then
    DRM_DEV=/dev/dri/card1
  elif [ -e /dev/dri/card0 ]; then
    DRM_DEV=/dev/dri/card0
  fi
fi
log "WLR_DRM_DEVICES=${DRM_DEV:-none}"
export WLR_DRM_DEVICES="${DRM_DEV:-}"
status_set GPU_DRIVER "${drv:-none} dev=${DRM_DEV:-none} i915_loaded=$( [ -d /sys/module/i915 ] && echo yes || echo no )"

find_bin() {
  name="$1"
  for p in \
    "$KIOSK/$name" \
    "/opt/neuos/runtime/kiosk/$name" \
    "/usr/bin/$name" \
    "/usr/sbin/$name" \
    "/bin/$name"; do
    if [ -x "$p" ]; then
      echo "$p"
      return 0
    fi
  done
  if command -v "$name" >/dev/null 2>&1; then
    command -v "$name"
    return 0
  fi
  return 1
}

# Weston 14 dlopens backends from a compile-time path, not LD_LIBRARY_PATH.
# Keep the real files under /opt (VendorCo /usr/lib can be a dead inode) and
# publish them to the path weston already searches.
publish_dir() {
  src="$1"
  dest="$2"
  [ -d "$src" ] || return 1
  mkdir -p "$dest" 2>/dev/null || true
  if cp -a "$src/." "$dest/" 2>/dev/null; then
    return 0
  fi
  mount --bind "$src" "$dest" 2>/dev/null || return 1
}

publish_dir "$KIOSK/lib/x86_64-linux-gnu/libweston-14" /usr/lib/x86_64-linux-gnu/libweston-14 || true
publish_dir "$KIOSK/lib/libweston-14" /usr/lib/x86_64-linux-gnu/libweston-14 || true
publish_dir "$KIOSK/lib/x86_64-linux-gnu/weston" /usr/lib/x86_64-linux-gnu/weston || true
if [ -d /usr/share/X11/xkb/rules ]; then
  :
elif [ -d "$KIOSK/share/X11/xkb/rules" ]; then
  publish_dir "$KIOSK/share/X11/xkb" /usr/share/X11/xkb || true
fi
if [ -d "$KIOSK/share/X11/xkb/rules" ]; then
  export XKB_CONFIG_ROOT="$KIOSK/share/X11/xkb"
elif [ -d /usr/share/X11/xkb/rules ]; then
  export XKB_CONFIG_ROOT=/usr/share/X11/xkb
fi
log "xkb=${XKB_CONFIG_ROOT:-none} drm-backend=$( [ -f /usr/lib/x86_64-linux-gnu/libweston-14/drm-backend.so ] && echo ok || echo missing ) kiosk-shell=$( [ -f /usr/lib/x86_64-linux-gnu/weston/kiosk-shell.so ] && echo ok || echo missing )"

SEATD_BIN="$(find_bin seatd || true)"
CAGE_BIN="$(find_bin cage || true)"
WESTON_BIN="$(find_bin weston || true)"
OPENVT="$(find_bin openvt || true)"
log "bins cage=${CAGE_BIN:-none} seatd=${SEATD_BIN:-none} weston=${WESTON_BIN:-none} electron=$ELECTRON"

if [ -n "$SEATD_BIN" ]; then
  SEATD_SOCK="${SEATD_SOCK:-/run/seatd.sock}"
  export SEATD_SOCK
  if [ ! -S "$SEATD_SOCK" ]; then
    "$SEATD_BIN" >> "$LOG" 2>&1 &
    s=0
    while [ "$s" -lt 5 ] && [ ! -S "$SEATD_SOCK" ]; do
      s=$((s + 1))
      sleep 1
    done
  fi
  log "seatd sock $( [ -S "$SEATD_SOCK" ] && echo ready || echo missing )"
fi

# Let the landing's first network probe see the lease. Bounded; the screen
# opens either way.
w=0
while [ "$w" -lt 6 ] && kill -0 "$NET_PID" 2>/dev/null; do
  w=$((w + 1))
  sleep 1
done
log "NETWORK $(grep '^NETWORK=' /tmp/osneu-input-status.env 2>/dev/null | tail -n 1 || echo 'NETWORK=PENDING')"

# Boot diagnostics before the first window: link → DNS → clock/proxy/TLS →
# app.neu API → daf.neu runtime, then LLM key + permission. RAM-only repairs
# (DHCP retry, fallback DNS, clock) happen inside osneu-netdiag.mjs.
wait "$NET_PID" 2>/dev/null || true
net_line="$(grep '^NETWORK=' /tmp/osneu-input-status.env 2>/dev/null | tail -n 1 || true)"
case "$net_line" in
  NETWORK=UP*) splash step 2 ok "${net_line#NETWORK=UP }" ;;
  *) splash step 2 warn "${net_line#NETWORK=}" ;;
esac
splash step 3 run
bootlog note netdiag-connect "$net_line"
set +e
netdiag connect --quiet
diag_rc=$?
set -e
bootlog note netdiag-connect-done "rc=$diag_rc"
status_set NETDIAG_CONNECT "$(verdict "$diag_rc") rc=$diag_rc"
splash step 3 "$(verdict "$diag_rc")" "$(netdiag_note)"
splash step 4 run
set +e
netdiag ai --quiet
diag_rc=$?
set -e
bootlog note netdiag-ai-done "rc=$diag_rc"
status_set NETDIAG_AI "$(verdict "$diag_rc") rc=$diag_rc"
splash step 4 "$(verdict "$diag_rc")" "$(netdiag_note)"
log "NETDIAG $(netdiag_note)"

# Weston requires XDG_RUNTIME_DIR owned by this uid with mode 0700.
# 1777 sticky made weston refuse the dir and flicker off VT7.
WL=/run/osneu-wl
mkdir -p "$WL"
chmod 700 "$WL" 2>/dev/null || true
export XDG_RUNTIME_DIR="$WL"
export XDG_SESSION_TYPE=wayland
export WLR_RENDERER="${WLR_RENDERER:-pixman}"
# Electron talks to cage on this socket. cage itself must not inherit it or
# wlroots tries a nested Wayland backend and libinput never attaches.
export WAYLAND_DISPLAY=wayland-0
# Do not force WLR_BACKENDS=drm — that paints and drops libinput.
# Do not force drm,libinput as a string — without a session, cage exits.
unset WLR_BACKENDS || true
export NEUOS_GO="$GO"
export NEUOS_SCREEN=1
export NEUOS_DRIVER=live
export NEUOS_JEOS=1
export NEUOS_PACKAGED=1
export ELECTRON_OZONE_PLATFORM_HINT=wayland
export CHROME_PASSWORD_STORE=basic
if [ -S "${SEATD_SOCK:-/run/seatd.sock}" ]; then
  export LIBSEAT_BACKEND="${LIBSEAT_BACKEND:-seatd}"
else
  export LIBSEAT_BACKEND="${LIBSEAT_BACKEND:-builtin}"
fi
export WLR_NO_HARDWARE_CURSORS=1
export XCURSOR_THEME="${XCURSOR_THEME:-DMZ-White}"
export XCURSOR_SIZE="${XCURSOR_SIZE:-24}"
export XCURSOR_PATH="${XCURSOR_PATH:-/usr/share/icons:/opt/neuos/runtime/kiosk/share/icons}"
export GDK_PIXBUF_MODULE_FILE=/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders.cache

LD_KIOSK="$KIOSK/lib/x86_64-linux-gnu:$KIOSK/lib:$KIOSK:/opt/neuos/runtime/electron:/usr/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu/weston:/usr/lib/x86_64-linux-gnu/libweston-14"
export LD_LIBRARY_PATH="$LD_KIOSK${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

VT=7
CAGE_LOG=""
CLIENT=/tmp/osneu-jeos-client.sh
{
  echo '#!/bin/sh'
  echo "cd '$APP' || exit 1"
  echo "export XDG_RUNTIME_DIR='$WL'"
  echo "export XDG_SESSION_TYPE=wayland"
  echo "export WAYLAND_DISPLAY=\${WAYLAND_DISPLAY:-wayland-0}"
  echo "export NEUOS_JEOS=1"
  echo "export NEUOS_PACKAGED=1"
  echo "export NEUOS_SCREEN=1"
  echo "export NEUOS_DRIVER=live"
  echo "export NEUOS_GO='$GO'"
  echo "export NEUOS_ROOT='$APP'"
  echo "export NEUOS_VIRT_TEST='${NEUOS_VIRT_TEST:-0}'"
  echo "export ELECTRON_OZONE_PLATFORM_HINT=wayland"
  echo "export CHROME_PASSWORD_STORE=basic"
  echo "export XDG_CACHE_HOME=/tmp/osneu-cache; mkdir -p /tmp/osneu-cache"
  # Chromium keeps its NSS db in \$HOME/.pki; JeOS root HOME is unset or read-only.
  echo "export HOME=/tmp/osneu-home; mkdir -p /tmp/osneu-home"
  echo "export XCURSOR_THEME='${XCURSOR_THEME:-DMZ-White}'"
  echo "export XCURSOR_SIZE='${XCURSOR_SIZE:-24}'"
  echo "export XCURSOR_PATH='${XCURSOR_PATH:-/usr/share/icons:/opt/neuos/runtime/kiosk/share/icons}'"
  echo "export LD_LIBRARY_PATH='$LD_KIOSK'"
  # Launcher boundary: entered / env / socket / exit, so "no start signal"
  # and "app not started" stay separate conclusions.
  echo "sock=no; [ -S \"\$XDG_RUNTIME_DIR/\$WAYLAND_DISPLAY\" ] && sock=yes"
  echo "{ echo \"entered=\$(date +%T 2>/dev/null) uid=\$(id -u 2>/dev/null) pwd=\$(pwd)\"; echo \"XDG_RUNTIME_DIR=\$XDG_RUNTIME_DIR WAYLAND_DISPLAY=\$WAYLAND_DISPLAY socket=\$sock\"; } > /tmp/osneu-app-launcher.env"
  echo "echo \"[app] launcher entered uid=\$(id -u 2>/dev/null) XDG_RUNTIME_DIR=\$XDG_RUNTIME_DIR WAYLAND_DISPLAY=\$WAYLAND_DISPLAY socket=\$sock\" >&2"
  echo "if [ '${NEUOS_VIRT_TEST:-0}' = '1' ]; then"
  echo "  exec /usr/bin/sh '$APP/scripts/virt-gui-client.sh'"
  echo "fi"
  echo "echo '[app] exec starting' >&2"
  # cage renders with pixman, so Electron gains nothing from GBM/EGL here and
  # a Mesa mismatch on the stick ended in exit 139 (2026-10-28 boot-001).
  # NEUOS_ELECTRON_GPU=1 opts back into the GPU path.
  echo "gpu='--disable-gpu'"
  echo "[ '${NEUOS_ELECTRON_GPU:-0}' = '1' ] && gpu=''"
  echo "echo \"[app] electron flags: \${gpu:-gpu-on}\" >&2"
  # Physical boots 001/004/007: main process SIGSEGV right after app ready,
  # also with no GBM backend; host cage with the same app and env never
  # crashes. Record where: Chromium's stack dump, the kernel segfault line,
  # and an strace of the retry. Trace files stay outside /tmp/osneu-* so the
  # boot recorder does not copy megabytes to the ESP every 10s.
  # Why GTK fails on the stick is still open: record its inputs (no GTK calls).
  echo "{ env | grep -E '^(GTK|GDK|GIO|GSETTINGS|XDG_)' ; for d in /usr/lib/x86_64-linux-gnu/gtk-3.0 /usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0 /usr/lib/x86_64-linux-gnu/gio/modules /usr/share/glib-2.0/schemas /usr/share/gtk-3.0 /etc/gtk-3.0 /usr/share/icons /usr/share/themes; do echo \"== \$d\"; ls \"\$d\" 2>&1 | head -n 12; done; } > /tmp/osneu-gtk-env.txt 2>&1"
  echo "ELECTRON_ENABLE_STACK_DUMPING=1 '$ELECTRON' '$APP' --no-sandbox --disable-gpu-sandbox --password-store=basic --enable-logging=stderr \$gpu"
  echo "rc=\$?"
  echo "if [ \"\$rc\" -ge 128 ]; then"
  echo "  { echo \"== first run exit=\$rc\"; /usr/bin/busybox dmesg | grep -E 'segfault|traps:' | tail -n 10; } > /tmp/osneu-electron-crash.txt 2>&1"
  echo "  { echo '== electron sha256 vs build'; ( cd '${ELECTRON%/*}' && /usr/bin/busybox sha256sum -c electron.sha256 ); } >> /tmp/osneu-electron-crash.txt 2>&1"
  echo "  { echo '== dmesg storage errors'; /usr/bin/busybox dmesg | grep -iE 'usb .*reset|I/O error|EXT4-fs (error|warning)|sd [0-9:]+.*(error|sense)|blk_update_request' | tail -n 20; } >> /tmp/osneu-electron-crash.txt 2>&1"
  echo "  echo \"[app] exit=\$rc (signal) — retry under strace\" >&2"
  echo "  tr=''; [ -x /usr/bin/strace ] && tr='/usr/bin/strace -f -tt -s 120 -o /tmp/strace-electron.txt'"
  echo "  ELECTRON_ENABLE_STACK_DUMPING=1 \$tr '$ELECTRON' '$APP' --no-sandbox --disable-gpu-sandbox --password-store=basic --enable-logging=stderr --disable-gpu"
  echo "  rc=\$?"
  echo "  {"
  echo "    echo \"== retry exit=\$rc strace=\${tr:+yes}\""
  echo "    /usr/bin/busybox dmesg | grep -E 'segfault|traps:' | tail -n 10"
  echo "    if [ -f /tmp/strace-electron.txt ]; then"
  echo "      pid=\$(grep -m1 -- '--- SIGSEGV' /tmp/strace-electron.txt | cut -d' ' -f1)"
  echo "      echo \"== strace pid=\$pid (last 150 lines)\""
  echo "      [ -n \"\$pid\" ] && grep \"^\$pid \" /tmp/strace-electron.txt | tail -n 150"
  echo "      echo '== strace failed opens (all pids, last 60)'"
  echo "      grep -E 'open.*= -1 ENOENT' /tmp/strace-electron.txt | grep -v -E '\\.so|locale|icons' | tail -n 60"
  echo "    fi"
  echo "  } >> /tmp/osneu-electron-crash.txt 2>&1"
  echo "  echo \"retry exit=\$rc\" >> /tmp/osneu-app-launcher.env"
  # Isolation probes (same boot): binary only, Node only, plain window
  # without os.neu code. Each answers one branch of the crash tree.
  echo "  probe() { name=\$1; shift; out=\$(/usr/bin/busybox timeout 20 \"\$@\" 2>&1); prc=\$?; echo \"== probe \$name rc=\$prc\"; echo \"\$out\" | tail -n 25; }"
  echo "  {"
  echo "    probe version '$ELECTRON' --version"
  echo "    probe node env ELECTRON_RUN_AS_NODE=1 '$ELECTRON' -e 'console.log(\"node ok\", process.versions.electron)'"
  echo "    for v in 'framed-menu 1 1' 'framed-nomenu 1 0' 'frameless-menu 0 1' 'frameless-nomenu 0 0'; do"
  echo "      set -- \$v"
  echo "      probe minapp-\$1 env MINAPP_FRAME=\$2 MINAPP_MENU=\$3 ELECTRON_ENABLE_STACK_DUMPING=1 '$ELECTRON' '$APP/scripts/electron-minapp' --no-sandbox --disable-gpu-sandbox --password-store=basic --enable-logging=stderr --disable-gpu"
  echo "    done"
  echo "    /usr/bin/busybox dmesg | grep -E 'segfault|traps:' | tail -n 5"
  echo "  } >> /tmp/osneu-electron-crash.txt 2>&1"
  echo "fi"
  echo "echo \"[app] exit=\$rc\" >&2"
  echo "echo \"exit=\$rc\" >> /tmp/osneu-app-launcher.env"
  echo "exit \$rc"
} > "$CLIENT"
chmod +x "$CLIENT"

run_on_vt() {
  compositor="$1"
  shift
  log "starting $compositor on VT${VT} drm=${DRM_DEV:-none} bin=$1"
  CAGE_LOG="${LOG}.${compositor}.vt${VT}"
  : > "$CAGE_LOG"
  WRAP=/tmp/osneu-vt-jeos-${compositor}.sh
  {
    echo '#!/bin/sh'
    echo "export XDG_RUNTIME_DIR='$WL'"
    echo "export XDG_SESSION_TYPE=wayland"
    echo "export WAYLAND_DISPLAY=wayland-0"
    echo "export LIBSEAT_BACKEND='${LIBSEAT_BACKEND:-builtin}'"
    echo "export WLR_RENDERER='${WLR_RENDERER}'"
    if [ "$compositor" = cage ]; then
      echo "unset WAYLAND_DISPLAY"
      echo "unset WAYLAND_SOCKET"
      echo "unset DISPLAY"
      echo "unset WLR_BACKENDS"
    else
      echo "export WAYLAND_DISPLAY=wayland-0"
    fi
    echo "export WLR_DRM_DEVICES='${DRM_DEV}'"
    echo "export WLR_NO_HARDWARE_CURSORS=1"
    echo "export XCURSOR_THEME='${XCURSOR_THEME:-DMZ-White}'"
    echo "export XCURSOR_SIZE='${XCURSOR_SIZE:-24}'"
    echo "export XCURSOR_PATH='${XCURSOR_PATH:-/usr/share/icons:/opt/neuos/runtime/kiosk/share/icons}'"
    echo "export SEATD_SOCK='${SEATD_SOCK:-}'"
    echo "export XKB_CONFIG_ROOT='${XKB_CONFIG_ROOT:-}'"
    echo "export NEUOS_JEOS=1"
    echo "export NEUOS_PACKAGED=1"
    echo "export NEUOS_VIRT_TEST='${NEUOS_VIRT_TEST:-0}'"
    echo "export LD_LIBRARY_PATH='$LD_KIOSK'"
    # Redirect inside the new VT. Redirecting openvt itself only captures
    # openvt's cleanup error; cage/weston writes to the new console.
    echo "exec \"\$@\" >> '$CAGE_LOG' 2>&1"
  } > "$WRAP"
  chmod +x "$WRAP"
  follow_pid=""
  if [ -x "$NODE_BIN" ] && [ -f "$DIAG_JS" ]; then
    "$NODE_BIN" "$DIAG_JS" follow "$CAGE_LOG" "$compositor" >/dev/null 2>&1 &
    follow_pid=$!
  fi
  status_set COMPOSITOR "$compositor started VT${VT} (running while this line is last)"
  set +e
  if [ -n "$OPENVT" ]; then
    # Each attempt gets a fresh VT. Reusing VT7 after openvt could not
    # deallocate it made every fallback fail before it reached the GPU.
    "$OPENVT" -c "$VT" -f -s -w -- /usr/bin/sh "$WRAP" "$@" >> "$CAGE_LOG" 2>&1
  else
    chvt "$VT" 2>/dev/null || true
    /usr/bin/sh "$WRAP" "$@" >> "$CAGE_LOG" 2>&1
  fi
  st=$?
  set -e
  sleep 1
  [ -n "$follow_pid" ] && kill "$follow_pid" 2>/dev/null || true
  status_set COMPOSITOR "$compositor exited rc=$st VT${VT}"
  attempted_vt="$VT"
  VT=$((VT + 1))
  if [ "$st" -ne 0 ]; then
    chvt 1 2>/dev/null || true
    log "$compositor exit $st on VT${attempted_vt} — last log:"
    if command -v tail >/dev/null 2>&1; then
      tail -n 24 "$CAGE_LOG" 2>/dev/null | while IFS= read -r line; do
        log "  $line"
      done
    elif [ -f "$CAGE_LOG" ]; then
      while IFS= read -r line; do
        log "  $line"
      done < "$CAGE_LOG"
    fi
  fi
  return "$st"
}

try_cage() {
  [ -x "$CAGE_BIN" ] || return 1
  log "trying cage autocreate LIBSEAT=$LIBSEAT_BACKEND (no WLR_BACKENDS)"
  if run_on_vt cage "$CAGE_BIN" -- /usr/bin/sh "$CLIENT"; then
    return 0
  fi
  if [ -S "${SEATD_SOCK:-/run/seatd.sock}" ] && [ "$LIBSEAT_BACKEND" != seatd ]; then
    export LIBSEAT_BACKEND=seatd
    log "trying cage autocreate LIBSEAT=seatd"
    if run_on_vt cage "$CAGE_BIN" -- /usr/bin/sh "$CLIENT"; then
      return 0
    fi
  fi
  return 1
}

try_weston() {
  [ -x "$WESTON_BIN" ] || return 1
  mkdir -p /tmp/weston
  {
    echo '#!/bin/sh'
    echo "exec /usr/bin/sh '$CLIENT'"
  } > /tmp/weston/client.sh
  chmod +x /tmp/weston/client.sh
  {
    echo '[core]'
    echo 'backend=drm'
    echo 'idle-time=0'
    echo '[libinput]'
    echo 'enable-tap=true'
    echo '[autolaunch]'
    echo 'path=/tmp/weston/client.sh'
  } > /tmp/weston/weston.ini
  export LIBSEAT_BACKEND=builtin
  # drm-backend.so opens libinput itself. --use-pixman: JeOS has no GL guarantee.
  log "trying weston drm-backend (libinput built in) LIBSEAT=builtin"
  # Weston 14 rejects --tty ("fatal: unhandled option"); libseat takes the VT openvt gave it.
  if run_on_vt weston "$WESTON_BIN" --backend=drm --shell=kiosk-shell.so \
    --use-pixman --config=/tmp/weston/weston.ini; then
    return 0
  fi
  return 1
}

finish() {
  diag status
  diag esp
  exit "$1"
}

# Keep re-checking in the background while the window is up (cable plugged in
# late, DNS repaired), then send the first prompt once the LLM is ready.
if [ -f /tmp/osneu-netdiag-watch.pid ]; then
  kill "$(cat /tmp/osneu-netdiag-watch.pid)" 2>/dev/null || true
fi
if [ -x "$NODE_BIN" ] && [ -f "$NETDIAG_JS" ]; then
  "$NODE_BIN" "$NETDIAG_JS" watch --quiet >/dev/null 2>&1 &
  echo $! > /tmp/osneu-netdiag-watch.pid
fi

# Stop drawing but leave fbcon unbound: the last splash frame stays on screen
# until cage paints, instead of a flash of the text console.
splash release
bootlog mark compositor-start

# One order for virt and USB. 2026-10-27 run 025440Z: cage autocreate painted the
# landing with libinput up once real input nodes existed; weston (14.0.2) stayed
# black with no client. Weston is the fallback.
if try_cage; then
  finish 0
fi
if try_weston; then
  finish 0
fi

log "OS-NEU-SX-000  no compositor (cage/weston) could open a USB GPU seat"
diag status
diag esp
log "kiosk $(ls "$KIOSK" 2>/dev/null || echo missing)"
log "retry: open os.neu   log: $LOG"
chvt 1 2>/dev/null || true
exit 4
