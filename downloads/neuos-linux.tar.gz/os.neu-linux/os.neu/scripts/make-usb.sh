#!/usr/bin/env bash
# Pack a bootable OS.neu USB or ISO.
# Copies this repo + a Node binary + the builder's Linux kernel, then GRUB.
# After grub-install, copies grub.cfg onto the ESP so removable EFI does not
# drop to a bare grub> prompt. Does not flash motherboard firmware.
# Refuses to write the disk that holds /.
#
#   bash scripts/make-usb.sh                 # ISO → dist/neuos-live.iso
#   bash scripts/make-usb.sh --list
#   bash scripts/make-usb.sh --plan /dev/sdb
#   sudo bash scripts/make-usb.sh /dev/sdb --yes
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
STAGE="$ROOT/dist/neuos-usb"
ISO="$ROOT/dist/neuos-live.iso"
YES=0
LIST=0
PLAN=0
TEST=0
PATCH=0
DEVICE=""

usage() {
  cat <<EOF
neuOS USB / ISO builder (os.neu image)

  bash scripts/make-usb.sh                 write dist/neuos-live.iso
  bash scripts/make-usb.sh --list          show disks (USB candidates marked)
  bash scripts/make-usb.sh --plan DEV      print the wipe/write plan, do not write
  sudo bash scripts/make-usb.sh DEV --yes   partition DEV and install neuOS
  sudo bash scripts/make-usb.sh DEV --update  refresh initrd on an existing stick (no wipe)

The target PC boots this stick even if it has no installed OS.
Graphical os.neu screen from USB: \`install os.neu\` plants ~/os.neu on the PC
disk, then opens the os.neu screen (in-app browser) in that same session.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --list) LIST=1; shift ;;
    --plan) PLAN=1; shift; DEVICE="${1:-}"; shift || true ;;
    --yes|-y) YES=1; shift ;;
    --update|--patch-initrd) PATCH=1; YES=1; shift ;;
    --test) TEST=1; shift ;;
    --iso) DEVICE=""; shift ;;
    /dev/*) DEVICE="$1"; shift ;;
    *) echo "unknown arg: $1" >&2; usage; exit 2 ;;
  esac
done

root_src() {
  findmnt -n -o SOURCE / 2>/dev/null || true
}

is_system_dev() {
  local dev="$1"
  local src
  src="$(root_src)"
  [[ -n "$src" && "$src" == "$dev"* ]]
}

list_disks() {
  echo "== block disks =="
  lsblk -o NAME,PATH,SIZE,MODEL,RM,TYPE,MOUNTPOINT
  echo
  echo "USB candidates (removable, not the / disk):"
  lsblk -dn -o PATH,SIZE,MODEL,RM,TYPE | awk '$4==1 && $5=="disk" {print}'
}

if [[ "$LIST" == 1 ]]; then
  list_disks
  exit 0
fi

# Copy a host file (and symlink target) into the USB tree at the same path.
# Node's PT_INTERP is /lib64/ld-linux-x86-64.so.2 — if that path is missing on
# the stick, PID 1 `exec node` returns 127 and the kernel panics (0x7f00).
stage_copy_path() {
  local src="$1"
  local real
  [[ -e "$src" ]] || return 0
  real="$(readlink -f "$src" 2>/dev/null || echo "$src")"
  mkdir -p "$STAGE$(dirname "$real")"
  cp -a "$real" "$STAGE$real"
  if [[ "$src" != "$real" ]]; then
    mkdir -p "$STAGE$(dirname "$src")"
    ln -sfn "$real" "$STAGE$src"
  fi
}

copy_bin_with_libs() {
  local src="$1"
  local dest_dir="$2"
  mkdir -p "$dest_dir"
  local base interp lib
  base="$(basename "$src")"
  cp -a "$src" "$dest_dir/$base"
  if command -v readelf >/dev/null; then
    interp="$(readelf -l "$src" 2>/dev/null | sed -n 's/.*interpreter: \([^]]*\).*/\1/p' | head -1)"
    if [[ -n "$interp" ]]; then
      stage_copy_path "$interp"
    fi
  fi
  if command -v ldd >/dev/null && ldd "$src" >/dev/null 2>&1; then
    while read -r lib; do
      [[ -z "$lib" || ! -e "$lib" ]] && continue
      stage_copy_path "$lib"
    done < <(ldd "$src" | awk '{
      if ($2 == "=>" && $3 ~ /^\//) print $3
      else if ($1 ~ /^\//) print $1
    }')
  fi
}

stage_host_tools() {
  local bin
  for bin in /usr/bin/mount /bin/mount /usr/bin/umount /bin/umount \
             /usr/sbin/chroot /usr/bin/chroot /sbin/chroot \
             /sbin/blkid /usr/sbin/blkid \
             /sbin/modprobe /usr/sbin/modprobe \
             /usr/bin/chvt /bin/chvt \
             /usr/bin/openvt /bin/openvt; do
    if [[ -x "$bin" ]]; then
      copy_bin_with_libs "$bin" "$STAGE/usr/bin"
    fi
  done
  chmod +x "$STAGE/opt/neuos/scripts/usb-screen.sh" 2>/dev/null || true
}

stage_kiosk() {
  local kiosk="$STAGE/opt/neuos/runtime/kiosk"
  mkdir -p "$kiosk" "$STAGE/usr/lib/x86_64-linux-gnu/dri"
  local bin
  for bin in cage weston seatd; do
    if command -v "$bin" >/dev/null; then
      copy_bin_with_libs "$(command -v "$bin")" "$kiosk"
    fi
  done
  if [[ ! -x "$kiosk/cage" ]] && command -v apt-get >/dev/null && command -v dpkg-deb >/dev/null; then
    local box
    box="$(mktemp -d)"
    mkdir -p "$box/partial"
    if (cd "$box" && apt-get download -q cage seatd libseat1 weston libpixman-1-0 \
         libwayland-client0 libwayland-server0 libwayland-cursor0 libxkbcommon0 \
         libinput10 libdrm2 libgbm1 libegl1 libgles2 2>/dev/null); then
      local deb
      for deb in "$box"/*.deb; do
        [[ -f "$deb" ]] || continue
        dpkg-deb -x "$deb" "$box/x" 2>/dev/null || true
      done
      if [[ -d "$box/x" ]]; then
        mkdir -p "$STAGE/usr" "$STAGE/lib"
        rsync -a "$box/x/usr/" "$STAGE/usr/" 2>/dev/null || true
        rsync -a "$box/x/lib/" "$STAGE/lib/" 2>/dev/null || true
        for bin in cage weston seatd; do
          if [[ -x "$box/x/usr/bin/$bin" ]]; then
            cp -a "$box/x/usr/bin/$bin" "$kiosk/$bin"
          fi
        done
      fi
    fi
    rm -rf "$box"
  fi
  local dri
  for dri in /usr/lib/x86_64-linux-gnu/dri/{iris,crocus,i915,radeonsi,nouveau,virtio_gpu,zink,swrast,kms_swrast}_dri.so; do
    if [[ -f "$dri" ]]; then
      cp -a "$dri" "$STAGE/usr/lib/x86_64-linux-gnu/dri/" 2>/dev/null || true
    fi
  done
}

copy_kmods() {
  local initdir="$1"
  local kver name ko
  kver="$(uname -r)"
  mkdir -p "$initdir/lib/modules/$kver"
  for name in usb-common usbcore xhci-hcd xhci-pci ehci-hcd uhci-hcd ohci-hcd \
    usb-storage uas hid usbhid hid-generic hid-logitech-hidpp hid-logitech-dj \
    sd_mod scsi_mod scsi_common ext4 crc32c crc16 jbd2 mbcache; do
    ko="$(modinfo -n "$name" 2>/dev/null || true)"
    if [[ -f "$ko" ]]; then
      mkdir -p "$initdir$(dirname "$ko")"
      cp -a "$ko" "$initdir$ko"
    fi
  done
  # busybox insmod cannot unpack .zst; kernel may, but unpack here so USB/HID always load.
  if command -v zstd >/dev/null; then
    find "$initdir/lib/modules" -name '*.ko.zst' -print0 2>/dev/null | while IFS= read -r -d '' z; do
      zstd -d -f -q "$z" -o "${z%.zst}" && rm -f "$z"
    done
  fi
  if command -v depmod >/dev/null; then
    depmod -b "$initdir" "$kver" 2>/dev/null || true
  fi
}

pack_initramfs() {
  local initdir
  initdir="$(mktemp -d)"
  mkdir -p "$initdir"/{bin,sbin,proc,sys,dev,newroot,lib,lib64,usr/bin}
  cp "$ROOT/boot/live/init" "$initdir/init"
  chmod +x "$initdir/init"
  if command -v busybox >/dev/null; then
    copy_bin_with_libs "$(command -v busybox)" "$initdir/bin"
    (cd "$initdir/bin" && ln -sf busybox sh && ln -sf busybox mount && ln -sf busybox umount \
      && ln -sf busybox sleep && ln -sf busybox mkdir && ln -sf busybox echo && ln -sf busybox ls \
      && ln -sf busybox cat && ln -sf busybox switch_root && ln -sf busybox setsid \
      && ln -sf busybox cttyhack && ln -sf busybox mknod && ln -sf busybox insmod \
      && ln -sf busybox find && ln -sf busybox true && ln -sf busybox blkid)
  else
    for bin in bash sh mount umount sleep mkdir echo ls; do
      if command -v "$bin" >/dev/null; then
        copy_bin_with_libs "$(command -v "$bin")" "$initdir/bin"
      fi
    done
    [[ -e $initdir/bin/sh ]] || ln -sf bash "$initdir/bin/sh"
  fi
  if command -v switch_root >/dev/null; then
    copy_bin_with_libs "$(command -v switch_root)" "$initdir/sbin"
  fi
  copy_kmods "$initdir"
  (cd "$initdir" && find . | cpio -o -H newc 2>/dev/null | gzip -9) > "$STAGE/boot/initrd.img"
  rm -rf "$initdir"
}

stage_tree() {
  rm -rf "$STAGE"
  mkdir -p "$STAGE"/{boot/grub,opt/neuos,sbin,usr/bin,etc}
  rsync -a --delete \
    --exclude node_modules \
    --exclude .git \
    --exclude dist \
    --exclude .env \
    --exclude .env.* \
    --exclude data/vlm-samples \
    "$ROOT/" "$STAGE/opt/neuos/"
  # Do not copy .env. USB users pick public AI or their own key after `install os.neu`.
  cp "$ROOT/boot/kernel.mjs" "$STAGE/opt/neuos/kernel.mjs"
  cp "$ROOT/boot/init/neuos-init" "$STAGE/sbin/neuos-init"
  chmod +x "$STAGE/sbin/neuos-init"
  ln -sfn neuos-init "$STAGE/sbin/init"
  printf 'neuOS USB\n' > "$STAGE/etc/neuos-release"
  mkdir -p "$STAGE/bin" "$STAGE/lib64"
  if command -v busybox >/dev/null; then
    copy_bin_with_libs "$(command -v busybox)" "$STAGE/bin"
    (cd "$STAGE/bin" && for a in sh mount umount mkdir ls cat chmod chown cp mv rm ln \
        chroot chvt openvt setsid blkid find grep sed awk sleep true false \
        insmod modprobe mknod switch_root cttyhack sync kill ps id; do
      ln -sf busybox "$a"
    done)
  elif command -v dash >/dev/null; then
    copy_bin_with_libs "$(command -v dash)" "$STAGE/bin"
    ln -sfn dash "$STAGE/bin/sh"
  elif command -v bash >/dev/null; then
    copy_bin_with_libs "$(command -v bash)" "$STAGE/bin"
    ln -sfn bash "$STAGE/bin/sh"
  fi
  cp "$ROOT/boot/init/inittab" "$STAGE/etc/inittab"

  local node
  node="$(command -v node)"
  mkdir -p "$STAGE/opt/neuos/runtime"
  copy_bin_with_libs "$node" "$STAGE/opt/neuos/runtime"
  ln -sfn /opt/neuos/runtime/node "$STAGE/usr/bin/node"
  for lib in /usr/lib/x86_64-linux-gnu/libnss_files.so.2 \
             /usr/lib/x86_64-linux-gnu/libnss_dns.so.2 \
             /usr/lib/x86_64-linux-gnu/libresolv.so.2; do
    stage_copy_path "$lib"
  done
  if [[ -f /etc/nsswitch.conf ]]; then
    cp /etc/nsswitch.conf "$STAGE/etc/nsswitch.conf"
  fi
  printf 'root:x:0:0:root:/:/bin/sh\n' > "$STAGE/etc/passwd"
  printf 'root:x:0:\n' > "$STAGE/etc/group"
  stage_host_tools
  if [[ "$TEST" != 1 ]]; then
    stage_kiosk || true
  fi

  if [[ "$TEST" != 1 ]]; then
    local kver
    kver="$(uname -r)"
    local vmlinuz=""
    for cand in "/boot/vmlinuz-$kver" /boot/vmlinuz /boot/vmlinuz-linux; do
      if [[ -f "$cand" ]]; then
        vmlinuz="$cand"
        break
      fi
    done
    if [[ -n "$vmlinuz" ]]; then
      cp "$vmlinuz" "$STAGE/boot/vmlinuz"
    else
      echo "WARN: no /boot/vmlinuz on this builder — ISO will not Linux-boot until you copy one." >&2
    fi
    if [[ -d "/lib/modules/$kver" ]]; then
      mkdir -p "$STAGE/lib/modules"
      rsync -a "/lib/modules/$kver" "$STAGE/lib/modules/"
    fi
    pack_initramfs
  else
    echo "TEST stage: skip kernel modules and initramfs"
    echo "neuOS test payload" > "$STAGE/boot/TEST"
  fi

  cat > "$STAGE/boot/grub/grub.cfg" <<'EOF'
set timeout=3
set default=0
insmod all_video
insmod gzio
insmod part_gpt
insmod fat
insmod ext2
search --label NEUOS-ROOT --set=root --no-floppy
menuentry "neuOS" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=tty0 loglevel=4 init=/sbin/neuos-init
    initrd /boot/initrd.img
}
menuentry "neuOS (this ISO)" {
    linux /boot/vmlinuz console=tty0 loglevel=4 init=/sbin/neuos-init
    initrd /boot/initrd.img
}
EOF
  echo "staged $STAGE"
}

# GRUB on the ESP cannot see /boot/vmlinuz on partition 2 until ext4 is loaded.
# Copy kernel, initrd, cfg, and EFI GRUB modules onto the FAT ESP.
sync_esp_boot() {
  local esp="$1"
  local rootmnt="$2"
  mkdir -p "$esp/boot/grub" "$esp/EFI/BOOT" "$esp/boot"
  if [[ -f "$rootmnt/boot/vmlinuz" ]]; then
    cp -a "$rootmnt/boot/vmlinuz" "$esp/boot/vmlinuz"
  fi
  if [[ -f "$rootmnt/boot/initrd.img" ]]; then
    cp -a "$rootmnt/boot/initrd.img" "$esp/boot/initrd.img"
  fi
  if [[ -f "$rootmnt/boot/grub/grub.cfg" ]]; then
    cp "$rootmnt/boot/grub/grub.cfg" "$esp/boot/grub/grub.cfg"
    cp "$rootmnt/boot/grub/grub.cfg" "$esp/EFI/BOOT/grub.cfg"
  fi
  if [[ -d "$rootmnt/boot/grub/x86_64-efi" ]]; then
    mkdir -p "$esp/EFI/BOOT/x86_64-efi" "$esp/boot/grub/x86_64-efi"
    cp -a "$rootmnt/boot/grub/x86_64-efi/." "$esp/EFI/BOOT/x86_64-efi/" 2>/dev/null || true
    cp -a "$rootmnt/boot/grub/x86_64-efi/." "$esp/boot/grub/x86_64-efi/" 2>/dev/null || true
  fi
}

write_iso() {
  mkdir -p "$ROOT/dist"
  if command -v grub-mkrescue >/dev/null; then
    grub-mkrescue -o "$ISO" "$STAGE"
    echo "ISO $ISO"
  else
    echo "MISS grub-mkrescue — tree is in $STAGE"
    echo "Install: sudo apt install grub-pc-bin grub-efi-amd64-bin xorriso mtools"
    echo "Then re-run: bash scripts/make-usb.sh"
    return 0
  fi
}

if [[ -z "$DEVICE" ]]; then
  stage_tree
  if [[ "$TEST" == 1 ]]; then
    echo "TEST payload $STAGE (no disk write)"
    exit 0
  fi
  write_iso
  echo
  echo "Next: sudo dd if=$ISO of=/dev/sdX bs=4M status=progress conv=fsync"
  echo "  or: sudo bash scripts/make-usb.sh /dev/sdX --yes"
  exit 0
fi

if [[ ! -b "$DEVICE" ]]; then
  echo "not a block device: $DEVICE" >&2
  exit 1
fi

if is_system_dev "$DEVICE"; then
  echo "refusing to overwrite the disk that holds / ($DEVICE)" >&2
  exit 1
fi

rm_flag="$(lsblk -dn -o RM "$DEVICE" 2>/dev/null || echo 0)"
if [[ "$rm_flag" != "1" ]]; then
  echo "WARN: $DEVICE is not flagged removable (RM=1)." >&2
fi

if [[ "$PATCH" == 1 ]]; then
  echo "plan: update initrd on $DEVICE (no wipe)"
else
  echo "plan: wipe $DEVICE and install os.neu"
fi
lsblk "$DEVICE"
if [[ "$PATCH" == 1 ]]; then
  if [[ "$(id -u)" != 0 ]]; then
    echo "USB update needs root. sudo bash scripts/make-usb.sh $DEVICE --update" >&2
    exit 1
  fi
  stage_tree
  ESP="${DEVICE}1"
  ROOTP="${DEVICE}2"
  if [[ "$DEVICE" == *[0-9] ]]; then
    ESP="${DEVICE}p1"
    ROOTP="${DEVICE}p2"
  fi
  ESP_MNT="$(mktemp -d)"
  ROOT_MNT="$(mktemp -d)"
  mount "$ROOTP" "$ROOT_MNT"
  mount "$ESP" "$ESP_MNT" || true
  mkdir -p "$ROOT_MNT/boot/grub" "$ESP_MNT/EFI/BOOT" "$ESP_MNT/boot/grub"
  rsync -a "$STAGE/" "$ROOT_MNT/"
  sync_esp_boot "$ESP_MNT" "$ROOT_MNT"
  sync
  umount "$ESP_MNT" 2>/dev/null || true
  umount "$ROOT_MNT"
  rmdir "$ESP_MNT" "$ROOT_MNT"
  echo "updated initrd and payload on $DEVICE (no partition wipe)."
  exit 0
fi
if [[ "$PLAN" == 1 || "$YES" != 1 ]]; then
  echo
  echo "To write: sudo bash scripts/make-usb.sh $DEVICE --yes"
  exit 0
fi

if [[ "$(id -u)" != 0 ]]; then
  echo "USB write needs root. sudo bash scripts/make-usb.sh $DEVICE --yes" >&2
  exit 1
fi

stage_tree

wipefs -a "$DEVICE" || true
parted -s "$DEVICE" mklabel gpt
parted -s "$DEVICE" mkpart ESP fat32 1MiB 512MiB
parted -s "$DEVICE" set 1 esp on
parted -s "$DEVICE" mkpart ROOT ext4 512MiB 100%
sleep 1
ESP="${DEVICE}1"
ROOTP="${DEVICE}2"
if [[ "$DEVICE" == *[0-9] ]]; then
  ESP="${DEVICE}p1"
  ROOTP="${DEVICE}p2"
fi
mkfs.vfat -F 32 -n NEUOS-ESP "$ESP"
mkfs.ext4 -F -L NEUOS-ROOT "$ROOTP"

ESP_MNT="$(mktemp -d)"
ROOT_MNT="$(mktemp -d)"
mount "$ROOTP" "$ROOT_MNT"
mount "$ESP" "$ESP_MNT"
mkdir -p "$ESP_MNT/EFI" "$ROOT_MNT/boot"
rsync -a "$STAGE/" "$ROOT_MNT/"
if command -v grub-install >/dev/null; then
  grub-install --target=x86_64-efi --efi-directory="$ESP_MNT" --boot-directory="$ROOT_MNT/boot" --removable --recheck "$DEVICE" || true
  grub-install --target=i386-pc --boot-directory="$ROOT_MNT/boot" --recheck "$DEVICE" || true
fi
sync_esp_boot "$ESP_MNT" "$ROOT_MNT"
sync
umount "$ESP_MNT" "$ROOT_MNT"
rmdir "$ESP_MNT" "$ROOT_MNT"
echo "neuOS is on $DEVICE. Firmware boot menu → USB."
