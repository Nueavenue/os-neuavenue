#!/usr/bin/env bash
# Pack a bootable OS.neu USB or ISO.
# Copies this repo + a Node binary + the builder's Linux kernel, then GRUB.
# After grub-install, copies grub.cfg onto the ESP so removable EFI does not
# drop to a bare grub> prompt. Does not flash motherboard firmware.
# Refuses to write the disk that holds /.
#
#   bash scripts/make-usb.sh                 # ISO → dist/neuos-live.iso
#   bash scripts/make-usb.sh --list
#   bash scripts/make-usb.sh --plan /dev/sdb
#   sudo bash scripts/make-usb.sh /dev/sdb --yes
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
STAGE="${NEUOS_STAGE_DIR:-/tmp/neuos-usb-stage-$$}"
ISO="${NEUOS_ISO_PATH:-$ROOT/dist/neuos-live.iso}"
YES=0
LIST=0
PLAN=0
TEST=0
PATCH=0
DEVICE=""
# parted end of ROOT. 100% = rest of the stick. VendorCo 048d:1234 (117G listing,
# last working ROOT 15.5G) needs 16GiB so ROOT stays in real media:
#   sudo ROOT_END=16GiB bash scripts/make-usb.sh /dev/sdc --yes
ROOT_END="${ROOT_END:-100%}"
FORCE_FULL_ROOT="${FORCE_FULL_ROOT:-0}"

usage() {
  cat <<EOF
neuOS USB / ISO builder (os.neu image)

  bash scripts/make-usb.sh                 write dist/neuos-live.iso
  bash scripts/make-usb.sh --list          show disks (USB candidates marked)
  bash scripts/make-usb.sh --plan DEV      print the wipe/write plan, do not write
  sudo bash scripts/make-usb.sh DEV --yes   partition DEV and install neuOS
  sudo bash scripts/make-usb.sh DEV --update  refresh initrd on an existing stick (no wipe)

  ROOT_END=16GiB   --yes only: ROOT ends at 16GiB (15.5G, matches this
                   VendorCo stick's last working layout). Default 100%.

The target PC boots this stick even if it has no installed OS.
Graphical os.neu screen from USB: \`install os.neu\` plants ~/os.neu on the PC
disk, then opens the os.neu screen (in-app browser) in that same session.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --list) LIST=1; shift ;;
    --plan) PLAN=1; shift; DEVICE="${1:-}"; shift || true ;;
    --yes|-y) YES=1; shift ;;
    --update|--patch-initrd) PATCH=1; YES=1; shift ;;
    --test) TEST=1; shift ;;
    --iso) DEVICE=""; shift ;;
    /dev/*) DEVICE="$1"; shift ;;
    *) echo "unknown arg: $1" >&2; usage; exit 2 ;;
  esac
done

root_src() {
  findmnt -n -o SOURCE / 2>/dev/null || true
}

is_system_dev() {
  local dev="$1"
  local src
  src="$(root_src)"
  [[ -n "$src" && "$src" == "$dev"* ]]
}

# Kernel often keeps the previous 15G ROOT after wipefs. GPT backup at the
# stick tail also makes parted print "primary GPT table is corrupt".
settle_block() {
  local dev="$1"
  [[ -n "$dev" && -b "$dev" ]] || return 0
  partprobe "$dev" 2>/dev/null || blockdev --rereadpt "$dev" 2>/dev/null || true
  udevadm settle --timeout=15 2>/dev/null || true
  sleep 1
}

zap_gpt() {
  local dev="$1"
  local sectors end
  wipefs -a "$dev" || true
  if command -v sgdisk >/dev/null; then
    sgdisk --zap-all "$dev" >/dev/null || true
  fi
  dd if=/dev/zero of="$dev" bs=1M count=2 status=none conv=fsync || true
  sectors="$(blockdev --getsz "$dev" 2>/dev/null || echo 0)"
  if [[ "$sectors" -gt 4096 ]]; then
    end=$((sectors / 2048 - 2))
    if [[ "$end" -gt 0 ]]; then
      dd if=/dev/zero of="$dev" bs=1M seek="$end" count=2 status=none conv=fsync || true
    fi
  fi
  settle_block "$dev"
}

wait_part_node() {
  local p="$1"
  local n=0
  while [[ "$n" -lt 20 ]]; do
    if [[ -b "$p" ]]; then
      return 0
    fi
    sleep 0.3
    n=$((n + 1))
  done
  echo "partition node $p did not appear" >&2
  return 1
}

disk_of_part() {
  lsblk -npo PKNAME "$1" 2>/dev/null | head -1
}

usb_id_prop() {
  udevadm info -q property -n "$1" 2>/dev/null | awk -F= -v k="$2" '$1==k {print $2; exit}'
}

# Generic 048d:1234 "VendorCo ProductCode" 117G listing. Last working ROOT here
# was 15.5G. 116G ext4 bitmaps from ~22GiB fail checksum.
is_vendorco_stick() {
  [[ "$(usb_id_prop "$1" ID_VENDOR_ID)" == "048d" && "$(usb_id_prop "$1" ID_MODEL_ID)" == "1234" ]]
}

refuse_fake_full_root() {
  echo "$1" >&2
  echo "This USB only (wipes THIS stick; ROOT ends at 16GiB = 15.5G):" >&2
  echo "  sudo ROOT_END=16GiB bash $ROOT/scripts/make-usb.sh $DEVICE --yes" >&2
  echo "Do not --update the 116G ROOT again. Do not --yes at 100% on this stick." >&2
  exit 1
}

# /bin /sbin on this stick are inodes 524289/524290 (group 64). Lookup prints
# "bad extra_isize 16416" and the live init used to treat that as no payload.
# Clear an inode by number only while the root entry with that number is still
# bin or sbin: on 2026-10-29 the same numbers were lib and proc.
zap_corrupt_root_bins() {
  local part="$1"
  command -v debugfs >/dev/null || return 0
  local listing ino cmds=""
  listing="$(debugfs -R 'ls -l /' "$part" 2>/dev/null || true)"
  for ino in 524289 524290; do
    if awk -v i="$ino" '$1 == i && ($NF == "bin" || $NF == "sbin") { f = 1 } END { exit !f }' <<<"$listing"; then
      cmds+="clri <$ino>"$'\n'
    fi
  done
  echo "zap corrupt /bin /sbin on $part (clri: $(printf '%s' "${cmds:-none}" | tr '\n' ' '))"
  debugfs -w -f - "$part" >/dev/null 2>&1 <<EOF || true
${cmds}unlink /bin
unlink /sbin
kill_file /bin
kill_file /sbin
EOF
}

ext4_io_errors_since() {
  local partbn t0
  partbn="$(basename "$1")"
  t0="$2"
  journalctl -k --since "@$t0" --no-pager 2>/dev/null | grep -F "EXT4-fs error (device $partbn)" || true
}

# boot-008: electron died at garbage instructions (SIGILL / GP fault) in
# 0x904xxxx-0x90Cxxxx while the same binary runs on the host. rsync -a skips a
# same-size same-mtime file, so in-place corruption survived every --update.
# Compare from the medium (page cache dropped) and show where the file lives.
verify_electron_readback() {
  local mnt="$1" rel=opt/neuos/runtime/electron/electron
  [[ -f "$STAGE/$rel" ]] || return 0
  sync
  { echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null || true
  local maxgib
  maxgib="$(filefrag -v "$mnt/$rel" 2>/dev/null | awk -F'[ .:]+' '/^ *[0-9]+:/ { e = $6 + 0; if (e > m) m = e } END { printf "%.1f", m * 4096 / 1073741824 }')"
  local diff
  diff="$(cmp "$STAGE/$rel" "$mnt/$rel" 2>&1 | head -n 1)"
  if [[ -n "$diff" ]]; then
    echo "FAIL: electron read-back differs from the staged copy: $diff (extents end at ${maxgib} GiB into $(basename "$(findmnt -n -o SOURCE "$mnt")"))" >&2
    echo "      The stick returns different bytes than were written: suspect a counterfeit or failing stick (real flash smaller than the partition)." >&2
    return 1
  fi
  echo "electron read-back matches staged copy (sha256 $(sha256sum "$STAGE/$rel" | cut -c1-16), extents end at ${maxgib} GiB)"
}

# Writes can "succeed" on this USB; directory checksums fail on the next read.
verify_jeos_root() {
  local mnt="$1"
  if [[ ! -f "$mnt/boot/vmlinuz" ]]; then
    echo "FAIL: $mnt/boot/vmlinuz missing after write" >&2
    return 1
  fi
  if [[ ! -x "$mnt/usr/sbin/neuos-init" ]]; then
    echo "FAIL: $mnt/usr/sbin/neuos-init missing or not executable" >&2
    return 1
  fi
  if [[ ! -e "$mnt/usr/bin/sh" ]]; then
    echo "FAIL: $mnt/usr/bin/sh missing (PID 1 shebang)" >&2
    return 1
  fi
  if [[ ! -x "$mnt/usr/bin/dash" ]]; then
    echo "FAIL: $mnt/usr/bin/dash missing (PID 1 must not be busybox)" >&2
    return 1
  fi
  if [[ -L "$mnt/usr/bin/sh" ]] && [[ "$(readlink "$mnt/usr/bin/sh")" == *busybox* ]]; then
    echo "FAIL: $mnt/usr/bin/sh is busybox (PID 1 would run init applet → kill init)" >&2
    return 1
  fi
  if ! ls "$mnt/usr/sbin" >/dev/null 2>&1; then
    echo "FAIL: cannot listdir $mnt/usr/sbin (Bad message / dir csum)" >&2
    return 1
  fi
  local bb="$mnt/usr/bin/busybox"
  if [[ ! -x "$bb" ]]; then
    echo "FAIL: $bb missing" >&2
    return 1
  fi
  local bbsz
  bbsz="$(stat -c%s "$bb" 2>/dev/null || echo 0)"
  if [[ "$bbsz" -lt 500000 ]]; then
    echo "FAIL: $bb is ${bbsz} bytes (openvt clobber — mkdir would be openvt)" >&2
    return 1
  fi
  # Capture the complete banner before matching. A direct `grep -q` pipeline
  # under `set -o pipefail` can report failure when grep closes the pipe after
  # the first match and the USB executable receives SIGPIPE.
  local bb_banner
  bb_banner="$("$bb" 2>&1 || true)"
  if [[ "$bb_banner" != *BusyBox* ]]; then
    echo "FAIL: $bb did not print a BusyBox banner" >&2
    return 1
  fi
  if [[ -f "$STAGE/usr/bin/busybox" ]] && ! cmp -s "$STAGE/usr/bin/busybox" "$bb"; then
    echo "FAIL: $bb does not match the staged BusyBox read-back" >&2
    return 1
  fi
  if [[ -x "$mnt/opt/neuos/runtime/electron/electron" ]]; then
    echo "JeOS electron client present"
    verify_electron_readback "$mnt" || return 1
  else
    echo "WARN: no electron on ROOT — open os.neu has no window client" >&2
  fi
  if [[ ! -e "$mnt/usr/lib/x86_64-linux-gnu/libva.so.2" ]] \
    || [[ ! -e "$mnt/usr/lib/x86_64-linux-gnu/libva-drm.so.2" ]]; then
    echo "FAIL: Weston VA-API runtime is missing after write" >&2
    return 1
  fi
  if [[ ! -x "$mnt/usr/bin/xdg-settings" ]]; then
    echo "FAIL: Electron helper $mnt/usr/bin/xdg-settings is missing after write" >&2
    return 1
  fi
  if [[ ! -x "$mnt/usr/bin/udevadm" ]] \
    || [[ ! -x "$mnt/usr/lib/systemd/systemd-udevd" ]] \
    || [[ ! -f "$mnt/usr/share/libinput/10-generic-keyboard.quirks" ]]; then
    echo "FAIL: udev/libinput runtime is missing after write" >&2
    return 1
  fi
  echo "ROOT payload verified (vmlinuz + dash + BusyBox ${bbsz} + neuos-init)"
}

fsck_root_no_journal() {
  local part="$1"
  local conf rc
  echo "drop ext4 journal on $part (USB live does not need one)"
  tune2fs -O ^has_journal "$part" 2>/dev/null || true
  conf="$(mktemp)"
  # PR_6_RECREATE_JOURNAL 0x060001 — e2fsck -y otherwise writes a 512MiB journal
  # onto offsets this stick does not keep, then mount still fails.
  cat >"$conf" <<'EOF'
[problems]
0x060001 = {
	answer = false
}
EOF
  echo "fsck NEUOS-ROOT $part (no wipe, do not recreate journal)"
  set +e
  E2FSCK_CONFIG="$conf" e2fsck -D -fy "$part"
  rc=$?
  set -e
  rm -f "$conf"
  tune2fs -O ^has_journal "$part" 2>/dev/null || true
  FSCK_RC="$rc"
}

mount_retry() {
  local dev="$1"
  local mnt="$2"
  local n=0
  mkdir -p "$mnt"
  while [[ "$n" -lt 3 ]]; do
    settle_block "$(disk_of_part "$dev")"
    if mount "$dev" "$mnt"; then
      return 0
    fi
    sleep 1
    n=$((n + 1))
  done
  return 1
}

# USB often reports mkfs/e2fsck success while the journal inode is still
# unreadable (kernel: Could not load journal inode). ESP at the start of the
# stick can still mount. Live ROOT does not need a journal.
mount_neuos_root() {
  local part="$1"
  local mnt="$2"
  local disk
  disk="$(disk_of_part "$part")"
  sync
  blockdev --flushbufs "$part" 2>/dev/null || true
  settle_block "$disk"
  if mount_retry "$part" "$mnt"; then
    return 0
  fi
  echo "WARN: $part mount failed. Drop ext4 journal and retry (USB live)." >&2
  tune2fs -O ^has_journal "$part" 2>/dev/null || true
  sync
  blockdev --flushbufs "$part" 2>/dev/null || true
  settle_block "$disk"
  mkdir -p "$mnt"
  if mount -o noload "$part" "$mnt"; then
    return 0
  fi
  if mount_retry "$part" "$mnt"; then
    return 0
  fi
  echo "NEUOS-ROOT $part still not mountable (Could not load journal inode)." >&2
  echo "NEUOS-ESP at the start of this stick can mount; ROOT cannot." >&2
  echo "A 117G listing whose ROOT used to be 15.5G is often fake capacity. Unplug, rear port, wait. Do not --yes until ROOT mounts." >&2
  return 1
}

# Ubuntu grub-install --removable plants Microsoft shim as BOOTX64.EFI and a
# non-PE GRUB core as grubx64.efi. Firmware loads shim; shim start_image(grub)
# then prints:
#   Platform does not support this image
#   Failed to read header: Unsupported
#   start_image() returned Unsupported
# Put a PE32+ grubx64.efi on both names so removable USB does not need shim.
plant_pe_grub_on_esp() {
  local esp="$1"
  local img="" mod src
  mkdir -p "$esp/EFI/BOOT/x86_64-efi" "$esp/EFI/ubuntu/x86_64-efi" "$esp/boot/grub"
  # Ubuntu's signed grubx64.efi has prefix /EFI/ubuntu, so it looks for
  # all_video.mod there and prints "file not found" before the menu.
  # Build a removable PE with prefix /EFI/BOOT. Also drop a few mods at
  # /EFI/ubuntu so a leftover Ubuntu-prefix binary still finds them.
  if command -v grub-mkimage >/dev/null && [[ -d /usr/lib/grub/x86_64-efi ]]; then
    img="$(mktemp)"
    if grub-mkimage -O x86_64-efi -o "$img" -p /EFI/BOOT \
      fat ext2 part_gpt normal configfile linux echo search search_label \
      ls cat test sleep gzio reboot efi_gop gfxterm; then
      cp -a "$img" "$esp/EFI/BOOT/BOOTX64.EFI"
      cp -a "$img" "$esp/EFI/BOOT/grubx64.efi"
    fi
    rm -f "$img"
  fi
  for mod in all_video fat ext2 part_gpt linux normal configfile echo search \
    search_label gzio efi_gop gfxterm ls cat test sleep reboot; do
    src="/usr/lib/grub/x86_64-efi/${mod}.mod"
    if [[ -f "$src" ]]; then
      cp -a "$src" "$esp/EFI/BOOT/x86_64-efi/" 2>/dev/null || true
      cp -a "$src" "$esp/EFI/ubuntu/x86_64-efi/" 2>/dev/null || true
    fi
  done
  if [[ ! -f "$esp/EFI/BOOT/BOOTX64.EFI" ]] || ! file "$esp/EFI/BOOT/BOOTX64.EFI" | grep -q 'PE32+ executable for EFI'; then
    echo "FAIL: BOOTX64.EFI is not PE32+ after grub-mkimage" >&2
    return 1
  fi
  echo "ESP PE GRUB (grub-mkimage prefix=/EFI/BOOT)"
}

# EFI files live on FAT. Do not mkdir GRUB modules on a broken ext4 ROOT.
install_removable_grub() {
  local device="$1"
  local esp="$2"
  mkdir -p "$esp/EFI/BOOT" "$esp/boot/grub"
  if ! command -v grub-install >/dev/null; then
    echo "FAIL: grub-install not on PATH" >&2
    return 1
  fi
  if ! grub-install --target=x86_64-efi --efi-directory="$esp" --boot-directory="$esp/boot" --removable --no-nvram --recheck "$device"; then
    echo "FAIL: grub-install x86_64-efi (BOOTX64.EFI not written)" >&2
    return 1
  fi
  if [[ -f /usr/lib/grub/i386-pc/modinfo.sh ]]; then
    grub-install --target=i386-pc --boot-directory="$esp/boot" --recheck "$device" || true
  else
    echo "WARN: grub-pc-bin not installed — UEFI-only stick (no i386-pc)." >&2
  fi
  if ! plant_pe_grub_on_esp "$esp"; then
    return 1
  fi
  echo "ESP BOOTX64.EFI ready"
}

list_disks() {
  echo "== block disks =="
  lsblk -o NAME,PATH,SIZE,MODEL,RM,TYPE,MOUNTPOINT
  echo
  echo "USB candidates (removable, not the / disk):"
  lsblk -dn -o PATH,SIZE,MODEL,RM,TYPE | awk '$4==1 && $5=="disk" {print}'
}

if [[ "$LIST" == 1 ]]; then
  list_disks
  exit 0
fi

# Copy a host file (and symlink target) into the USB tree at the same path.
# Node's PT_INTERP is /lib64/ld-linux-x86-64.so.2 — if that path is missing on
# the stick, PID 1 `exec node` returns 127 and the kernel panics (0x7f00).
stage_copy_path() {
  local src="$1"
  local real
  [[ -e "$src" ]] || return 0
  real="$(readlink -f "$src" 2>/dev/null || echo "$src")"
  mkdir -p "$STAGE$(dirname "$real")"
  cp -a "$real" "$STAGE$real"
  if [[ "$src" != "$real" ]]; then
    mkdir -p "$STAGE$(dirname "$src")"
    ln -sfn "$real" "$STAGE$src"
  fi
}

copy_bin_with_libs() {
  local src="$1"
  local dest_dir="$2"
  mkdir -p "$dest_dir"
  local base interp lib
  base="$(basename "$src")"
  # Never `cp` onto a busybox applet symlink — GNU cp follows the link and
  # overwrites the busybox binary (this stick’s mkdir/mount became openvt).
  rm -f "$dest_dir/$base"
  cp -a "$src" "$dest_dir/$base"
  if command -v readelf >/dev/null; then
    interp="$(readelf -l "$src" 2>/dev/null | sed -n 's/.*interpreter: \([^]]*\).*/\1/p' | head -1)"
    if [[ -n "$interp" ]]; then
      stage_copy_path "$interp"
    fi
  fi
  if command -v ldd >/dev/null && ldd "$src" >/dev/null 2>&1; then
    while read -r lib; do
      [[ -z "$lib" || ! -e "$lib" ]] && continue
      stage_copy_path "$lib"
    done < <(ldd "$src" | awk '{
      if ($2 == "=>" && $3 ~ /^\//) print $3
      else if ($1 ~ /^\//) print $1
    }')
  fi
}

stage_host_tools() {
  local bin real
  for bin in /usr/bin/mount /bin/mount /usr/bin/umount /bin/umount \
             /usr/sbin/chroot /usr/bin/chroot /sbin/chroot \
             /sbin/blkid /usr/sbin/blkid \
             /sbin/modprobe /usr/sbin/modprobe \
             /usr/bin/chvt /bin/chvt \
             /usr/bin/openvt /bin/openvt \
             /usr/bin/strace; do
    [[ -e "$bin" ]] || continue
    real="$(readlink -f "$bin" 2>/dev/null || echo "$bin")"
    if [[ "$real" == *cargo/bin/coreutils* ]]; then
      continue
    fi
    if [[ -x "$bin" ]]; then
      copy_bin_with_libs "$bin" "$STAGE/usr/bin"
    fi
  done
  chmod +x "$STAGE/opt/neuos/scripts/usb-screen.sh" 2>/dev/null || true
  chmod +x "$STAGE/opt/neuos/scripts/usb-screen-jeos.sh" 2>/dev/null || true
}

# Replant real BusyBox AFTER host-tool copies. GNU cp onto applet symlinks
# used to overwrite /usr/bin/busybox with openvt (mkdir -p → VT help).
plant_jeos_core() {
  local src="/bin/busybox"
  [[ -x "$src" ]] || src="/usr/bin/busybox"
  local sz
  sz="$(stat -c%s "$src" 2>/dev/null || echo 0)"
  if [[ "$sz" -lt 500000 ]]; then
    echo "FAIL: $src is ${sz} bytes — not a real BusyBox" >&2
    return 1
  fi
  mkdir -p "$STAGE/usr/bin" "$STAGE/usr/sbin"
  rm -f "$STAGE/usr/bin/busybox"
  cp -a "$src" "$STAGE/usr/bin/busybox"
  (cd "$STAGE/usr/bin" && for a in mkdir rmdir ls cat chmod chown cp mv rm ln \
      chroot env cut tr find grep sed awk sleep true false \
      basename dirname tail head printf which \
      ip ifconfig udhcpc \
      insmod mknod switch_root cttyhack sync kill ps id; do
    ln -sfn busybox "$a"
  done)
  local pair srcbin dest
  for pair in \
    /usr/bin/mount:/usr/bin/mount \
    /usr/sbin/blkid:/usr/bin/blkid \
    /usr/sbin/blkid:/usr/sbin/blkid \
    /usr/bin/openvt:/usr/bin/openvt \
    /usr/bin/chvt:/usr/bin/chvt \
    /usr/sbin/modprobe:/usr/bin/modprobe
  do
    srcbin="${pair%%:*}"
    dest="${pair##*:}"
    [[ -x "$srcbin" && ! -L "$srcbin" ]] || continue
    rm -f "$STAGE$dest"
    copy_bin_with_libs "$srcbin" "$(dirname "$STAGE$dest")"
  done
  echo "plant_jeos_core busybox=${sz} mount=$(file -b "$STAGE/usr/bin/mount" | cut -c1-40)"
}

# JeOS root has only busybox insmod (no .zst, no dependency walk), and
# neuos-init must not load GPU drivers before `open os.neu`. Stage plain
# .ko files plus an insmod order for usb-screen-jeos.sh to load at open time.
stage_open_kmods() {
  local dir="$STAGE/opt/neuos/kmod" mod path base
  mkdir -p "$dir"
  : > "$dir/load-order"
  for mod in i915 r8169; do
    while read -r _ path _; do
      [[ -f "$path" ]] || continue
      base="$(basename "$path")"
      base="${base%.zst}"
      base="${base%.xz}"
      [[ -f "$dir/$base" ]] && continue
      case "$path" in
        *.zst) zstd -d -f -q "$path" -o "$dir/$base" ;;
        *.xz) xz -d -c "$path" > "$dir/$base" ;;
        *) cp -a "$path" "$dir/$base" ;;
      esac
      echo "$base" >> "$dir/load-order"
    done < <(modprobe --show-depends "$mod" 2>/dev/null | grep '^insmod ')
  done
  echo "stage_open_kmods $(tr '\n' ' ' < "$dir/load-order")"
  # FAT's default iocharset (iso8859-1) is a module on this kernel. Without it
  # the boot recorder and input-diag cannot mount NEUOS-ESP for osneu-logs.
  mkdir -p "$dir/boot"
  for mod in nls_iso8859-1 nls_utf8; do
    path="$(modinfo -n "$mod" 2>/dev/null || true)"
    [[ -f "$path" ]] || continue
    case "$path" in
      *.zst) zstd -d -f -q "$path" -o "$dir/boot/$mod.ko" ;;
      *.xz) xz -d -c "$path" > "$dir/boot/$mod.ko" ;;
      *) cp -a "$path" "$dir/boot/$mod.ko" ;;
    esac
  done
  echo "stage_boot_kmods $(ls "$dir/boot" 2>/dev/null | tr '\n' ' ')"
  # Wi-Fi for the boot setup screen (scripts/osneu-wifi.mjs loads these in
  # order). Realtek rtw88 USB/PCIe (this PC: RTL88x2bu 0bda:b812), Intel, MediaTek.
  mkdir -p "$dir/wifi"
  : > "$dir/wifi/load-order"
  for mod in rtw88_8822bu rtw88_8821cu rtw88_8822cu rtw88_8822be rtw88_8821ce rtw88_8822ce \
             iwlmvm mt7921u mt7921e; do
    while read -r _ path _; do
      [[ -f "$path" ]] || continue
      base="$(basename "$path")"
      base="${base%.zst}"
      base="${base%.xz}"
      [[ -f "$dir/wifi/$base" ]] && continue
      case "$path" in
        *.zst) zstd -d -f -q "$path" -o "$dir/wifi/$base" ;;
        *.xz) xz -d -c "$path" > "$dir/wifi/$base" ;;
        *) cp -a "$path" "$dir/wifi/$base" ;;
      esac
      echo "$base" >> "$dir/wifi/load-order"
    done < <(modprobe --show-depends "$mod" 2>/dev/null | grep '^insmod ')
  done
  echo "stage_wifi_kmods $(wc -l < "$dir/wifi/load-order") modules"
}

stage_jeos_screen() {
  chmod +x "$STAGE/opt/neuos/scripts/usb-screen-jeos.sh" 2>/dev/null || true
  chmod +x "$STAGE/opt/neuos/scripts/virt-gui-client.sh" 2>/dev/null || true
  chmod +x "$STAGE/opt/neuos/scripts/osneu-bootlog.sh" 2>/dev/null || true
  # Never stage into STAGE/lib/firmware — rsync onto this VendorCo stick
  # hits a dead /lib/firmware inode (Bad message). Keep firmware under /opt.
  if [[ -d /lib/firmware/i915 ]]; then
    mkdir -p "$STAGE/opt/neuos/firmware"
    rsync -a /lib/firmware/i915 "$STAGE/opt/neuos/firmware/"
  fi
  if [[ -d /lib/firmware/rtl_nic ]]; then
    mkdir -p "$STAGE/opt/neuos/firmware"
    rsync -a /lib/firmware/rtl_nic "$STAGE/opt/neuos/firmware/"
  fi
  # Wi-Fi firmware + regulatory db (cfg80211) and the supplicant for the
  # boot setup screen. Passwords are never staged; they live in RAM at boot.
  mkdir -p "$STAGE/opt/neuos/firmware"
  [[ -d /lib/firmware/rtw88 ]] && rsync -a /lib/firmware/rtw88 "$STAGE/opt/neuos/firmware/"
  if [[ -d /lib/firmware/intel/iwlwifi ]]; then
    mkdir -p "$STAGE/opt/neuos/firmware/intel"
    rsync -a /lib/firmware/intel/iwlwifi "$STAGE/opt/neuos/firmware/intel/"
    rsync -a /lib/firmware/iwlwifi-* "$STAGE/opt/neuos/firmware/" 2>/dev/null || true
  fi
  if compgen -G "/lib/firmware/mediatek/WIFI_*MT79*" >/dev/null; then
    mkdir -p "$STAGE/opt/neuos/firmware/mediatek"
    rsync -a /lib/firmware/mediatek/WIFI_*MT79* "$STAGE/opt/neuos/firmware/mediatek/"
  fi
  for f in regulatory.db regulatory.db.p7s; do
    [[ -f "/lib/firmware/$f" ]] && cp -a "/lib/firmware/$f" "$STAGE/opt/neuos/firmware/"
  done
  for b in /usr/sbin/wpa_supplicant /usr/sbin/wpa_cli; do
    [[ -x "$b" ]] && copy_bin_with_libs "$b" "$STAGE/usr/sbin"
  done
  echo "stage_wifi wpa_supplicant=$([[ -x "$STAGE/usr/sbin/wpa_supplicant" ]] && echo yes || echo MISSING) firmware=$(du -sh "$STAGE/opt/neuos/firmware" 2>/dev/null | cut -f1)"
  stage_open_kmods
  local kver_fw
  kver_fw="$(uname -r)"
  if [[ -d "/lib/modules/$kver_fw" ]]; then
    mkdir -p "$STAGE/opt/neuos/lib/modules"
    rsync -a "/lib/modules/$kver_fw" "$STAGE/opt/neuos/lib/modules/"
    if command -v depmod >/dev/null; then
      depmod -b "$STAGE/opt/neuos" "$kver_fw" 2>/dev/null || true
    fi
  fi
  if [[ -d "$ROOT/dist-web" ]]; then
    mkdir -p "$STAGE/opt/neuos/dist-web"
    rsync -a "$ROOT/dist-web/" "$STAGE/opt/neuos/dist-web/"
  fi
  if [[ -d "$ROOT/dist-bridge" ]]; then
    mkdir -p "$STAGE/opt/neuos/dist-bridge"
    rsync -a "$ROOT/dist-bridge/" "$STAGE/opt/neuos/dist-bridge/"
  fi
  local ed="$ROOT/node_modules/electron/dist"
  if [[ -x "$ed/electron" ]]; then
    mkdir -p "$STAGE/opt/neuos/runtime/electron"
    rsync -a "$ed/" "$STAGE/opt/neuos/runtime/electron/"
    copy_bin_with_libs "$ed/electron" "$STAGE/opt/neuos/runtime/electron"
    (cd "$STAGE/opt/neuos/runtime/electron" && sha256sum electron > electron.sha256)
    stage_ldd_libs "$STAGE/opt/neuos/runtime/electron/electron" || true
    # NSS dlopens these on the first TLS connection; ldd never lists them.
    # Without them Electron aborts (FATAL nss_util, exit 133) once DNS works.
    local nss
    for nss in libsoftokn3.so libsoftokn3.chk libfreebl3.so libfreebl3.chk \
               libfreeblpriv3.so libfreeblpriv3.chk libnssdbm3.so libnssdbm3.chk libnssckbi.so; do
      if [[ -e "/usr/lib/x86_64-linux-gnu/$nss" ]]; then
        stage_copy_path "/usr/lib/x86_64-linux-gnu/$nss"
      fi
    done
    stage_ldd_libs "$STAGE/usr/lib/x86_64-linux-gnu/libsoftokn3.so" || true
    echo "stage_jeos_screen electron=$(ls -l "$STAGE/opt/neuos/runtime/electron/electron")"
  else
    echo "WARN: no electron on this builder — USB open os.neu has no window client" >&2
  fi
}

# Copy host .so files that ldd still marks "not found" after the deb extract.
stage_ldd_libs() {
  local bin="$1"
  local ldpath="$STAGE/usr/lib/x86_64-linux-gnu:$STAGE/usr/lib/x86_64-linux-gnu/weston:$STAGE/usr/lib/x86_64-linux-gnu/libweston-14"
  local line dest soname d
  [[ -e "$bin" ]] || return 0
  if command -v readelf >/dev/null; then
    local interp
    interp="$(readelf -l "$bin" 2>/dev/null | sed -n 's/.*interpreter: \([^]]*\).*/\1/p' | head -1)"
    if [[ -n "$interp" ]]; then
      stage_copy_path "$interp"
    fi
  fi
  command -v ldd >/dev/null || return 0
  while IFS= read -r line; do
    dest=""
    if [[ "$line" == *'not found'* ]]; then
      soname="$(echo "$line" | awk '{print $1}')"
      for d in \
        "$STAGE/usr/lib/x86_64-linux-gnu" \
        "$STAGE/usr/lib/x86_64-linux-gnu/weston" \
        "$STAGE/usr/lib/x86_64-linux-gnu/libweston-14" \
        /usr/lib/x86_64-linux-gnu \
        /lib/x86_64-linux-gnu \
        /usr/lib \
        /lib; do
        if [[ -e "$d/$soname" ]]; then
          dest="$d/$soname"
          break
        fi
      done
    else
      dest="$(echo "$line" | awk '{ if ($2=="=>" && $3 ~ /^\//) print $3; else if ($1 ~ /^\//) print $1 }')"
    fi
    [[ -n "$dest" && -e "$dest" ]] || continue
    case "$dest" in
      "$STAGE"/*) continue ;;
    esac
    stage_copy_path "$dest"
  done < <(LD_LIBRARY_PATH="$ldpath${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ldd "$bin" 2>/dev/null)
}

stage_kiosk() {
  local kiosk="$STAGE/opt/neuos/runtime/kiosk"
  mkdir -p "$kiosk" "$STAGE/usr/lib/x86_64-linux-gnu/dri"
  local bin src
  for bin in cage weston seatd; do
    if command -v "$bin" >/dev/null; then
      copy_bin_with_libs "$(command -v "$bin")" "$kiosk"
    fi
  done
  # This builder has no cage/weston on PATH. Planted copies lack libwlroots.
  # Always extract compositor debs onto JeOS ROOT so USB can exec them.
  if command -v apt-get >/dev/null && command -v dpkg-deb >/dev/null; then
    local box deb gbm_pkg gbm_ver
    box="$(mktemp -d)"
    mkdir -p "$box/partial"
    # libgbm1 must match the builder's mesa-libgallium (staged below). A newer
    # libgbm1 dlopens a libgallium-<ver>.so that is not on the stick, and
    # Electron exited 139 on the physical USB (2026-10-28 boot-001).
    gbm_ver="$(dpkg-query -W -f='${Version}' libgbm1:amd64 2>/dev/null || true)"
    gbm_pkg="libgbm1${gbm_ver:+=$gbm_ver}"
    kiosk_debs() {
      apt-get download -q \
         cage seatd libseat1 weston libweston-14-0 libwlroots-0.19 \
         libpixman-1-0 libwayland-client0 libwayland-server0 libwayland-cursor0 \
         libxkbcommon0 xkb-data libinput10 libinput-bin udev \
         libdrm2 "$1" libegl1 libgles2 libva2 libva-drm2 xdg-utils \
         libliftoff0 libxcb-ewmh2 libxcb-errors0
    }
    if (cd "$box" && { kiosk_debs "$gbm_pkg" || { echo "WARN: $gbm_pkg not downloadable; using archive libgbm1" >&2; kiosk_debs libgbm1; }; }); then
      for deb in "$box"/*.deb; do
        [[ -f "$deb" ]] || continue
        dpkg-deb -x "$deb" "$box/x" 2>/dev/null || true
      done
      if [[ -d "$box/x" ]]; then
        mkdir -p "$STAGE/usr" "$STAGE/lib"
        rsync -a "$box/x/usr/" "$STAGE/usr/" 2>/dev/null || true
        rsync -a "$box/x/lib/" "$STAGE/lib/" 2>/dev/null || true
        for bin in cage weston; do
          if [[ -x "$box/x/usr/bin/$bin" ]]; then
            cp -a "$box/x/usr/bin/$bin" "$kiosk/$bin"
          fi
        done
        if [[ -x "$box/x/usr/sbin/seatd" ]]; then
          cp -a "$box/x/usr/sbin/seatd" "$kiosk/seatd"
        elif [[ -x "$box/x/usr/bin/seatd" ]]; then
          cp -a "$box/x/usr/bin/seatd" "$kiosk/seatd"
        fi
      fi
    else
      echo "WARN: stage_kiosk apt-get download failed — USB cage may stay 127" >&2
    fi
    rm -rf "$box"
  fi
  for src in "${HOME}/os.neu/runtime/kiosk" "/home/${SUDO_USER:-billy-lee}/os.neu/runtime/kiosk"; do
    for bin in cage weston seatd; do
      if [[ ! -x "$kiosk/$bin" && -x "$src/$bin" ]]; then
        copy_bin_with_libs "$src/$bin" "$kiosk"
      fi
    done
  done
  for bin in "$kiosk/cage" "$kiosk/weston" "$kiosk/seatd" \
             "$STAGE/usr/bin/cage" "$STAGE/usr/bin/weston" "$STAGE/usr/sbin/seatd" \
             "$STAGE/usr/bin/udevadm" "$STAGE/usr/lib/systemd/systemd-udevd" \
             "$STAGE/usr/lib/x86_64-linux-gnu/libweston-14/drm-backend.so" \
             "$kiosk/lib/x86_64-linux-gnu/libweston-14/drm-backend.so"; do
    stage_ldd_libs "$bin"
  done
  local dri
  for dri in /usr/lib/x86_64-linux-gnu/dri/{iris,crocus,i915,radeonsi,nouveau,virtio_gpu,zink,swrast,kms_swrast}_dri.so; do
    if [[ -f "$dri" ]]; then
      cp -a "$dri" "$STAGE/usr/lib/x86_64-linux-gnu/dri/" 2>/dev/null || true
    fi
  done
  # Mesa 25+: gbm/dri_gbm.so and the *_dri.so stubs dlopen libgallium-<ver>.so.
  local gal
  for gal in /usr/lib/x86_64-linux-gnu/libgallium-*.so; do
    [[ -f "$gal" ]] || continue
    cp -a "$gal" "$STAGE/usr/lib/x86_64-linux-gnu/" 2>/dev/null || true
    stage_ldd_libs "$gal"
    echo "stage_mesa $(basename "$gal") gbm=${gbm_ver:-unknown}"
  done
  # Weston 14 dlopens drm-backend.so from /usr/lib/.../libweston-14.
  # Also keep a copy under /opt so JeOS can publish if /usr/lib is a dead inode.
  mkdir -p "$kiosk/lib/x86_64-linux-gnu" "$kiosk/share"
  if [[ -d "$STAGE/usr/lib/x86_64-linux-gnu/libweston-14" ]]; then
    mkdir -p "$kiosk/lib/x86_64-linux-gnu/libweston-14"
    rsync -a "$STAGE/usr/lib/x86_64-linux-gnu/libweston-14/" "$kiosk/lib/x86_64-linux-gnu/libweston-14/" 2>/dev/null || true
  fi
  if [[ -d "$STAGE/usr/lib/x86_64-linux-gnu/weston" ]]; then
    mkdir -p "$kiosk/lib/x86_64-linux-gnu/weston"
    rsync -a "$STAGE/usr/lib/x86_64-linux-gnu/weston/" "$kiosk/lib/x86_64-linux-gnu/weston/" 2>/dev/null || true
  fi
  if [[ -d "${HOME}/neuOS/runtime/kiosk/lib" ]]; then
    rsync -a "${HOME}/neuOS/runtime/kiosk/lib/" "$kiosk/lib/" 2>/dev/null || true
  fi
  if [[ -d /usr/share/X11/xkb ]]; then
    mkdir -p "$kiosk/share/X11/xkb" "$STAGE/usr/share/X11/xkb"
    rsync -a /usr/share/X11/xkb/ "$kiosk/share/X11/xkb/" 2>/dev/null || true
    rsync -a /usr/share/X11/xkb/ "$STAGE/usr/share/X11/xkb/" 2>/dev/null || true
  fi
  # xdg-utils scripts use /bin/sh, but this JeOS intentionally keeps its
  # interpreter at /usr/bin/sh. Electron also needs a minimal fontconfig tree.
  if [[ -f "$STAGE/usr/bin/xdg-settings" ]]; then
    sed -i '1s|^#!/bin/sh|#!/usr/bin/sh|' "$STAGE/usr/bin/xdg-settings"
  fi
  if [[ -d /etc/fonts ]]; then
    mkdir -p "$STAGE/etc/fonts"
    rsync -a /etc/fonts/ "$STAGE/etc/fonts/"
  fi
  if [[ -d /usr/share/fonts/truetype/dejavu ]]; then
    mkdir -p "$STAGE/usr/share/fonts/truetype/dejavu"
    rsync -a /usr/share/fonts/truetype/dejavu/ "$STAGE/usr/share/fonts/truetype/dejavu/"
  fi
  # Korean UI/console lines drew as tofu boxes on JeOS (2026-10-27 virt run).
  # Nanum Gothic regular+bold only (OFL, ~9 MB).
  for f in NanumGothic.ttf NanumGothicBold.ttf; do
    if [[ -f "/usr/share/fonts/truetype/nanum/$f" ]]; then
      mkdir -p "$STAGE/usr/share/fonts/truetype/nanum"
      cp -a "/usr/share/fonts/truetype/nanum/$f" "$STAGE/usr/share/fonts/truetype/nanum/"
    fi
  done
  # cage/wlroots software cursor is invisible without a theme (JeOS had none).
  if [[ -d /usr/share/icons/DMZ-White/cursors ]]; then
    mkdir -p "$STAGE/usr/share/icons/DMZ-White" "$STAGE/usr/share/icons/default" \
      "$kiosk/share/icons/DMZ-White"
    rsync -a /usr/share/icons/DMZ-White/ "$STAGE/usr/share/icons/DMZ-White/"
    rsync -a /usr/share/icons/DMZ-White/ "$kiosk/share/icons/DMZ-White/"
    printf '%s\n' '[Icon Theme]' 'Inherits=DMZ-White' > "$STAGE/usr/share/icons/default/index.theme"
  fi
  if [[ -d /usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0 ]]; then
    mkdir -p "$STAGE/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0"
    rsync -a /usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/ \
      "$STAGE/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/"
    local loader
    for loader in /usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders/*.so; do
      [[ -f "$loader" ]] && stage_ldd_libs "$loader"
    done
  fi
  if [[ -d /usr/share/mime ]]; then
    mkdir -p "$STAGE/usr/share/mime"
    rsync -a /usr/share/mime/ "$STAGE/usr/share/mime/"
  fi
  if [[ -d /usr/share/icons/Adwaita ]]; then
    mkdir -p "$STAGE/usr/share/icons/Adwaita"
    rsync -a /usr/share/icons/Adwaita/ "$STAGE/usr/share/icons/Adwaita/"
  fi
  if [[ -d /usr/libexec/glycin-loaders && -d /usr/share/glycin-loaders ]]; then
    mkdir -p "$STAGE/usr/libexec/glycin-loaders" "$STAGE/usr/share/glycin-loaders"
    rsync -a /usr/libexec/glycin-loaders/ "$STAGE/usr/libexec/glycin-loaders/"
    rsync -a /usr/share/glycin-loaders/ "$STAGE/usr/share/glycin-loaders/"
    local glycin
    for glycin in /usr/libexec/glycin-loaders/2+/*; do
      [[ -x "$glycin" ]] && stage_ldd_libs "$glycin"
    done
  fi
  if [[ -x /usr/bin/bwrap ]]; then
    copy_bin_with_libs /usr/bin/bwrap "$STAGE/usr/bin"
  fi
  if [[ ! -e "$STAGE/usr/lib/x86_64-linux-gnu/libva.so.2" ]] \
    || [[ ! -e "$STAGE/usr/lib/x86_64-linux-gnu/libva-drm.so.2" ]]; then
    echo "FAIL: stage_kiosk has no libva.so.2/libva-drm.so.2" >&2
    return 1
  fi
  if [[ ! -x "$STAGE/usr/bin/xdg-settings" ]]; then
    echo "FAIL: stage_kiosk has no xdg-settings" >&2
    return 1
  fi
  if [[ ! -x "$STAGE/usr/bin/udevadm" ]] \
    || [[ ! -x "$STAGE/usr/lib/systemd/systemd-udevd" ]] \
    || [[ ! -f "$STAGE/usr/share/libinput/10-generic-keyboard.quirks" ]]; then
    echo "FAIL: stage_kiosk has no udev/libinput runtime data" >&2
    return 1
  fi
  mkdir -p "$STAGE/usr/lib/udev/rules.d" "$STAGE/etc/udev/rules.d"
  if [[ -f "$ROOT/boot/udev/61-neuos-virt-input.rules" ]]; then
    cp -a "$ROOT/boot/udev/61-neuos-virt-input.rules" \
      "$STAGE/usr/lib/udev/rules.d/61-neuos-virt-input.rules"
    cp -a "$ROOT/boot/udev/61-neuos-virt-input.rules" \
      "$STAGE/etc/udev/rules.d/61-neuos-virt-input.rules"
  fi
  if [[ -f /usr/lib/udev/hwdb.bin ]]; then
    cp -a /usr/lib/udev/hwdb.bin "$STAGE/usr/lib/udev/hwdb.bin"
  fi
  if [[ -d /usr/lib/udev/hwdb.d ]]; then
    mkdir -p "$STAGE/usr/lib/udev/hwdb.d"
    rsync -a /usr/lib/udev/hwdb.d/ "$STAGE/usr/lib/udev/hwdb.d/"
  fi
  if [[ -x "$kiosk/cage" ]]; then
    echo "stage_kiosk cage=$(ls -l "$kiosk/cage") drm=$(ls "$kiosk/lib/x86_64-linux-gnu/libweston-14/drm-backend.so" 2>/dev/null || echo missing) xkb=$(ls "$kiosk/share/X11/xkb/rules/evdev" 2>/dev/null || echo missing)"
  else
    echo "WARN: stage_kiosk has no cage binary" >&2
  fi
}

copy_kmods() {
  local initdir="$1"
  local kver name ko
  kver="$(uname -r)"
  mkdir -p "$initdir/lib/modules/$kver"
  for name in usb-common usbcore xhci-hcd xhci-pci ehci-hcd uhci-hcd ohci-hcd \
    usb-storage uas hid usbhid hid-generic hid-logitech-hidpp hid-logitech-dj \
    sd_mod scsi_mod scsi_common ahci libahci libata ata_piix ata_generic \
      sr_mod cdrom nvme nvme-core isofs ext4 crc32c crc16 jbd2 mbcache \
      virtio virtio-ring virtio-pci virtio-pci-legacy-dev virtio-pci-modern-dev \
      virtio-blk virtio-scsi virtio-gpu virtio-net virtio-input evdev atkbd i8042 psmouse; do
    ko="$(modinfo -n "$name" 2>/dev/null || true)"
    if [[ -f "$ko" ]]; then
      mkdir -p "$initdir$(dirname "$ko")"
      cp -a "$ko" "$initdir$ko"
    fi
  done
  # busybox insmod cannot unpack .zst; kernel may, but unpack here so USB/HID always load.
  if command -v zstd >/dev/null; then
    find "$initdir/lib/modules" -name '*.ko.zst' -print0 2>/dev/null | while IFS= read -r -d '' z; do
      zstd -d -f -q "$z" -o "${z%.zst}" && rm -f "$z"
    done
  fi
  if command -v depmod >/dev/null; then
    depmod -b "$initdir" "$kver" 2>/dev/null || true
  fi
}

pack_initramfs() {
  local initdir
  initdir="$(mktemp -d)"
  mkdir -p "$initdir"/{bin,sbin,proc,sys,dev,newroot,lib,lib64,usr/bin}
  cp "$ROOT/boot/live/init" "$initdir/init"
  chmod +x "$initdir/init"
  # Recovery overlay: NEUOS-ROOT may remount emergency_ro after ext4 bitmap
  # errors. The init script bind-mounts this fresh launcher over the existing
  # root path without requiring a writable ext4 inode.
  cp "$ROOT/scripts/usb-screen-jeos.sh" "$initdir/usb-screen-jeos.sh"
  chmod +x "$initdir/usb-screen-jeos.sh"
  if command -v busybox >/dev/null; then
    copy_bin_with_libs "$(command -v busybox)" "$initdir/bin"
    (cd "$initdir/bin" && ln -sf busybox sh && ln -sf busybox mount && ln -sf busybox umount \
      && ln -sf busybox sleep && ln -sf busybox mkdir && ln -sf busybox echo && ln -sf busybox ls \
      && ln -sf busybox cat && ln -sf busybox switch_root && ln -sf busybox setsid \
      && ln -sf busybox cttyhack && ln -sf busybox mknod && ln -sf busybox insmod \
      && ln -sf busybox find && ln -sf busybox true \
      && ln -sf busybox sed && ln -sf busybox tr && ln -sf busybox readlink)
  else
    for bin in bash sh mount umount sleep mkdir echo ls; do
      if command -v "$bin" >/dev/null; then
        copy_bin_with_libs "$(command -v "$bin")" "$initdir/bin"
      fi
    done
    [[ -e $initdir/bin/sh ]] || ln -sf bash "$initdir/bin/sh"
  fi
  # This Ubuntu busybox has no blkid applet. Pack util-linux blkid + its libs
  # into the initrd tree (copy_bin_with_libs sends .so files to STAGE, not here).
  if [[ -x /usr/sbin/blkid ]]; then
    rm -f "$initdir/bin/blkid"
    cp -a /usr/sbin/blkid "$initdir/bin/blkid"
    chmod +x "$initdir/bin/blkid"
    if command -v readelf >/dev/null; then
      _interp="$(readelf -l /usr/sbin/blkid 2>/dev/null | sed -n 's/.*interpreter: \([^]]*\).*/\1/p' | head -1)"
      if [[ -n "$_interp" && -f "$_interp" ]]; then
        mkdir -p "$initdir$(dirname "$_interp")"
        cp -a "$_interp" "$initdir$_interp"
      fi
    fi
    if command -v ldd >/dev/null; then
      while read -r _lib; do
        [[ -f "$_lib" ]] || continue
        mkdir -p "$initdir$(dirname "$_lib")"
        cp -a "$_lib" "$initdir$_lib"
      done < <(ldd /usr/sbin/blkid | awk '{
        if ($2 == "=>" && $3 ~ /^\//) print $3
        else if ($1 ~ /^\//) print $1
      }')
    fi
  fi
  if command -v switch_root >/dev/null; then
    copy_bin_with_libs "$(command -v switch_root)" "$initdir/sbin"
  fi
  copy_kmods "$initdir"
  (cd "$initdir" && find . | cpio -o -H newc 2>/dev/null | gzip -9) > "$STAGE/boot/initrd.img"
  rm -rf "$initdir"
}

# Boot splash glyph atlas + logo (boot/splash/osneu-splash.mjs). Generated per
# build from host fonts; the splash still draws shapes if this step fails.
stage_splash_assets() {
  local out="$STAGE/opt/neuos/boot/splash/assets"
  if python3 "$ROOT/boot/splash/build-assets.py" "$out" "$ROOT"; then
    return 0
  fi
  echo "WARN: splash assets not built (python3-pil or fonts missing) — splash draws shapes only" >&2
}

stage_tree() {
  if [[ -e "$STAGE" ]]; then
    echo "FAIL: stage path already exists; refusing to replace it: $STAGE" >&2
    return 1
  fi
  mkdir -p "$STAGE"/{boot/grub,opt/neuos,sbin,usr/bin,etc,mnt,tmp,run,proc,sys,dev/pts}
  rsync -a --delete \
    --exclude node_modules \
    --exclude .git \
    --exclude dist \
    --exclude .env \
    --exclude .env.* \
    --exclude data/vlm-samples \
    --exclude /data/user-llm.json \
    --exclude /data/accounts.json \
    --exclude /data/oauth-handoff.json \
    --exclude /data/analytics.json \
    --exclude /data/feedback.json \
    --exclude /data/browse-ledger.json \
    --exclude /data/user-monitor.json \
    --exclude /data/user-preference.json \
    --exclude /data/boot-health.json \
    "$ROOT/" "$STAGE/opt/neuos/"
  # Do not copy .env or the builder's own data/ (OpenAI key in user-llm.json,
  # accounts, OAuth handoff). USB users enter their own key on the stick.
  local leaked=""
  for f in user-llm.json accounts.json oauth-handoff.json analytics.json feedback.json \
           browse-ledger.json user-monitor.json user-preference.json; do
    if [[ -e "$STAGE/opt/neuos/data/$f" ]]; then
      leaked="$leaked $f"
    fi
  done
  if [[ -n "$leaked" || -e "$STAGE/opt/neuos/.env" ]]; then
    echo "FAIL: builder secrets/personal data staged into the image:$leaked — refusing to build" >&2
    return 1
  fi
  cp "$ROOT/boot/kernel.mjs" "$STAGE/opt/neuos/kernel.mjs"
  stage_splash_assets
  mkdir -p "$STAGE/usr/bin" "$STAGE/usr/sbin" "$STAGE/lib64"
  cp "$ROOT/boot/init/neuos-init" "$STAGE/usr/sbin/neuos-init"
  chmod +x "$STAGE/usr/sbin/neuos-init"
  ln -sfn neuos-init "$STAGE/usr/sbin/init"
  printf 'neuOS USB\n' > "$STAGE/etc/neuos-release"
  printf 'nameserver 10.0.2.3\nnameserver 1.1.1.1\n' > "$STAGE/etc/resolv.conf"
  # /bin and /sbin as real directories landed in a high inode group on the
  # VendorCo stick (dir csum Bad message). Keep tools under /usr which read back.
  if command -v busybox >/dev/null; then
    copy_bin_with_libs "$(command -v busybox)" "$STAGE/usr/bin"
    # Do not link sh → busybox. BusyBox as PID 1 with argv0=busybox/init
    # runs the init applet and exits 0 (kernel panic kill init).
    (cd "$STAGE/usr/bin" && for a in mount umount mkdir ls cat chmod chown cp mv rm ln \
        chroot chvt openvt env cut tr setsid blkid find grep sed awk sleep true false \
        basename dirname tail head printf which \
        ip ifconfig udhcpc \
        insmod modprobe mknod switch_root cttyhack sync kill ps id; do
      ln -sf busybox "$a"
    done)
  fi
  # PID 1 interpreter after switch_root: real dash, never busybox.
  if command -v dash >/dev/null; then
    copy_bin_with_libs "$(command -v dash)" "$STAGE/usr/bin"
    ln -sfn dash "$STAGE/usr/bin/sh"
  elif command -v bash >/dev/null; then
    copy_bin_with_libs "$(command -v bash)" "$STAGE/usr/bin"
    ln -sfn bash "$STAGE/usr/bin/sh"
    ln -sfn bash "$STAGE/usr/bin/dash"
  fi
  # Do not plant /bin or /sbin. On this VendorCo stick those names are
  # stuck on corrupt inodes (524289/524290); rsync symlink replace exits 23.
  # switch_root execs /usr/bin/dash /usr/sbin/neuos-init (shebang /usr/bin/sh).
  rm -rf "$STAGE/bin" "$STAGE/sbin"
  cp "$ROOT/boot/init/inittab" "$STAGE/etc/inittab"

  local node
  node="$(command -v node)"
  mkdir -p "$STAGE/opt/neuos/runtime"
  copy_bin_with_libs "$node" "$STAGE/opt/neuos/runtime"
  ln -sfn /opt/neuos/runtime/node "$STAGE/usr/bin/node"
  for lib in /usr/lib/x86_64-linux-gnu/libnss_files.so.2 \
             /usr/lib/x86_64-linux-gnu/libnss_dns.so.2 \
             /usr/lib/x86_64-linux-gnu/libresolv.so.2; do
    stage_copy_path "$lib"
  done
  if [[ -f /etc/nsswitch.conf ]]; then
    cp /etc/nsswitch.conf "$STAGE/etc/nsswitch.conf"
  fi
  printf 'root:x:0:0:root:/:/bin/sh\n' > "$STAGE/etc/passwd"
  printf 'root:x:0:\n' > "$STAGE/etc/group"
  stage_host_tools
  if [[ "$TEST" != 1 ]]; then
    stage_kiosk || true
  fi
  plant_jeos_core
  if [[ "$TEST" != 1 ]]; then
    stage_jeos_screen || true
  fi

  if [[ "$TEST" != 1 ]]; then
    local kver
    kver="$(uname -r)"
    local vmlinuz=""
    for cand in "/boot/vmlinuz-$kver" /boot/vmlinuz /boot/vmlinuz-linux; do
      if [[ -f "$cand" ]]; then
        vmlinuz="$cand"
        break
      fi
    done
    if [[ -n "$vmlinuz" && -r "$vmlinuz" ]]; then
      cp "$vmlinuz" "$STAGE/boot/vmlinuz"
    elif [[ -n "$vmlinuz" ]] && command -v apt-get >/dev/null \
      && command -v dpkg-deb >/dev/null; then
      local kernel_box kernel_pkg kernel_deb
      kernel_box="$(mktemp -d)"
      kernel_pkg="$(dpkg-query -S "$vmlinuz" 2>/dev/null | head -1 | cut -d: -f1)"
      if [[ -n "$kernel_pkg" ]] \
        && (cd "$kernel_box" && apt-get download -q "$kernel_pkg") \
        && kernel_deb="$(find "$kernel_box" -maxdepth 1 -name '*.deb' -print -quit)" \
        && [[ -n "$kernel_deb" ]]; then
        dpkg-deb -x "$kernel_deb" "$kernel_box/x"
        cp "$kernel_box/x/boot/vmlinuz-$kver" "$STAGE/boot/vmlinuz"
      else
        echo "WARN: installed kernel is unreadable and package extraction failed" >&2
      fi
      rm -rf "$kernel_box"
    else
      echo "WARN: no /boot/vmlinuz on this builder — ISO will not Linux-boot until you copy one." >&2
    fi
    if [[ -d "/lib/modules/$kver" ]]; then
      mkdir -p "$STAGE/opt/neuos/lib/modules"
      rsync -a "/lib/modules/$kver" "$STAGE/opt/neuos/lib/modules/"
      if command -v depmod >/dev/null; then
        depmod -b "$STAGE/opt/neuos" "$kver" 2>/dev/null || true
      fi
    fi
    pack_initramfs
  else
    echo "TEST stage: skip kernel modules and initramfs"
    echo "neuOS test payload" > "$STAGE/boot/TEST"
  fi

  # Entry 0 is the product boot: splash on the firmware framebuffer, then
  # os.neu straight into cage (no display manager, no login). Entries 1 and 2
  # keep their indexes for the virt harness defaults below.
  cat > "$STAGE/boot/grub/grub.cfg" <<'EOF'
set timeout=3
set default=0
set color_normal=light-gray/black
set menu_color_normal=light-gray/black
set menu_color_highlight=white/blue
insmod gzio
insmod part_gpt
insmod fat
insmod ext2
search --file --set=root /boot/vmlinuz
menuentry "os.neu" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 quiet loglevel=3 vt.global_cursor_default=0 init=/usr/sbin/neuos-init neuos.autostart=1 neuos.splash=1
    initrd /boot/initrd.img
}
menuentry "neuOS (this ISO)" {
    linux /boot/vmlinuz ro console=ttyS0,115200n8 console=tty0 loglevel=4 init=/usr/sbin/neuos-init neuos.test=console
    initrd /boot/initrd.img
}
menuentry "neuOS automated GUI test" {
    linux /boot/vmlinuz ro console=tty0 console=ttyS0,115200n8 loglevel=4 init=/usr/sbin/neuos-init neuos.test=gui
    initrd /boot/initrd.img
}
menuentry "os.neu (this ISO, splash + autostart)" {
    linux /boot/vmlinuz ro console=ttyS0,115200n8 console=tty0 quiet loglevel=3 vt.global_cursor_default=0 init=/usr/sbin/neuos-init neuos.test=console neuos.autostart=1 neuos.splash=1
    initrd /boot/initrd.img
}
menuentry "os.neu console (no autostart)" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 loglevel=4 init=/usr/sbin/neuos-init
    initrd /boot/initrd.img
}
menuentry "os.neu network check (text)" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 loglevel=4 init=/usr/sbin/neuos-init neuos.netdiag=console
    initrd /boot/initrd.img
}
EOF
  if [[ "${NEUOS_VIRT_AUTOSTART:-0}" == "1" ]]; then
    sed -i 's/^set default=0$/set default=3/' "$STAGE/boot/grub/grub.cfg"
  elif [[ "${NEUOS_VIRT_AUTOGUI:-0}" == "1" ]]; then
    sed -i 's/^set default=0$/set default=2/' "$STAGE/boot/grub/grub.cfg"
  elif [[ "${NEUOS_VIRT_OPEN:-0}" == "1" ]]; then
    sed -i 's/^set default=0$/set default=1/' "$STAGE/boot/grub/grub.cfg"
  elif [[ -n "${NEUOS_ISO_PATH:-}" ]]; then
    sed -i 's/^set default=0$/set default=1/' "$STAGE/boot/grub/grub.cfg"
  fi
  # A stick boots from NEUOS-ROOT only. The ISO/test entries above booted the
  # physical USB read-only with a RAM data overlay (2026-10-28 boot-001).
  if [[ -n "$DEVICE" ]]; then
    cat > "$STAGE/boot/grub/grub.cfg" <<'EOF'
set timeout=5
set default=0
set color_normal=light-gray/black
set menu_color_normal=light-gray/black
set menu_color_highlight=white/blue
insmod gzio
insmod part_gpt
insmod fat
insmod ext2
search --file --set=root /boot/vmlinuz
menuentry "os.neu" {
    linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 quiet loglevel=3 vt.global_cursor_default=0 init=/usr/sbin/neuos-init neuos.autostart=1 neuos.splash=1
    initrd /boot/initrd.img
}
submenu "Advanced (console · network check)" {
    menuentry "os.neu console (type open.neu)" {
        linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 loglevel=4 init=/usr/sbin/neuos-init
        initrd /boot/initrd.img
    }
    menuentry "os.neu network check (text)" {
        linux /boot/vmlinuz root=LABEL=NEUOS-ROOT rw console=ttyS0,115200n8 console=tty0 loglevel=4 init=/usr/sbin/neuos-init neuos.netdiag=console
        initrd /boot/initrd.img
    }
}
EOF
    echo "grub: USB menu (os.neu · Advanced: console · network check)"
  fi
  echo "staged $STAGE"
}

# Dirty USB FAT often fails `mount` as "wrong fs type / bad superblock".
# fsck.vfat does not wipe the partition. Returns 0 if the mount is live.
mount_esp() {
  local dev="$1"
  local mnt="$2"
  mkdir -p "$mnt"
  set +e
  if command -v fsck.vfat >/dev/null; then
    fsck.vfat -a "$dev" >/dev/null
  fi
  mount -t vfat -o rw,flush,utf8 "$dev" "$mnt"
  local rc=$?
  if [[ "$rc" -ne 0 ]]; then
    echo "WARN: first vfat mount of $dev failed (rc $rc). Retry after fsck.vfat." >&2
    if command -v fsck.vfat >/dev/null; then
      fsck.vfat -a "$dev"
    fi
    mount -t vfat -o rw,flush "$dev" "$mnt"
    rc=$?
  fi
  set -e
  if [[ "$rc" -ne 0 ]]; then
    return 1
  fi
  if ! findmnt -n "$mnt" >/dev/null 2>&1; then
    return 1
  fi
  return 0
}

# GRUB on the ESP cannot see /boot/vmlinuz on partition 2 until ext4 is loaded.
# Copy kernel, initrd, cfg, and EFI GRUB modules onto the FAT ESP.
sync_esp_boot() {
  local esp="$1"
  local rootmnt="$2"
  if ! findmnt -n "$esp" >/dev/null 2>&1; then
    echo "WARN: ESP is not mounted at $esp — skip boot copy (ROOT payload may already be current)." >&2
    return 1
  fi
  mkdir -p "$esp/boot/grub" "$esp/EFI/BOOT" "$esp/boot"
  local src
  for src in "$rootmnt" "$STAGE"; do
    if [[ -f "$src/boot/vmlinuz" ]]; then
      cp -a "$src/boot/vmlinuz" "$esp/boot/vmlinuz"
      break
    fi
  done
  for src in "$rootmnt" "$STAGE"; do
    if [[ -f "$src/boot/initrd.img" ]]; then
      cp -a "$src/boot/initrd.img" "$esp/boot/initrd.img"
      break
    fi
  done
  for src in "$rootmnt" "$STAGE"; do
    if [[ -f "$src/boot/grub/grub.cfg" ]]; then
      cp "$src/boot/grub/grub.cfg" "$esp/boot/grub/grub.cfg"
      cp "$src/boot/grub/grub.cfg" "$esp/EFI/BOOT/grub.cfg"
      break
    fi
  done
  if [[ -d "$rootmnt/boot/grub/x86_64-efi" ]]; then
    mkdir -p "$esp/EFI/BOOT/x86_64-efi" "$esp/boot/grub/x86_64-efi"
    cp -a "$rootmnt/boot/grub/x86_64-efi/." "$esp/EFI/BOOT/x86_64-efi/" 2>/dev/null || true
    cp -a "$rootmnt/boot/grub/x86_64-efi/." "$esp/boot/grub/x86_64-efi/" 2>/dev/null || true
  fi
}

# NTFS/fuseblk stage trees lose Unix +x. RockRidge then stores 0444 and
# the live initrd rejects /usr/sbin/neuos-init as "no-neuos-init".
restore_iso_exec() {
  local iso="$1"
  local path
  command -v xorriso >/dev/null || return 0
  # JeOS has /usr/bin not /bin. Missing find paths must not abort the ISO.
  xorriso -dev "$iso" -boot_image any keep -abort_on NEVER \
    -find /usr/bin -type f -exec chmod a+x -- \
    -find /usr/sbin -type f -exec chmod a+x -- \
    -find /opt/neuos/runtime -type f -exec chmod a+x -- \
    -find /opt/neuos/scripts -type f -exec chmod a+x -- \
    -find /usr/lib/systemd -type f -exec chmod a+x -- \
    -find /lib64 -type f -exec chmod a+x -- \
    -commit
  xorriso -indev "$iso" -find /usr/sbin/neuos-init -exec lsdl -- 2>/dev/null \
    | grep -q 'r-x'
}

write_iso() {
  mkdir -p "$(dirname "$ISO")"
  if command -v grub-mkrescue >/dev/null; then
    grub-mkrescue -o "$ISO" "$STAGE"
    restore_iso_exec "$ISO"
    echo "ISO $ISO"
  else
    echo "MISS grub-mkrescue — tree is in $STAGE"
    echo "Install: sudo apt install grub-pc-bin grub-efi-amd64-bin xorriso mtools"
    echo "Then re-run: bash scripts/make-usb.sh"
    return 0
  fi
}

if [[ -z "$DEVICE" ]]; then
  stage_tree
  if [[ "$TEST" == 1 ]]; then
    echo "TEST payload $STAGE (no disk write)"
    exit 0
  fi
  write_iso
  echo
  echo "Next: sudo dd if=$ISO of=/dev/sdX bs=4M status=progress conv=fsync"
  echo "  or: sudo bash scripts/make-usb.sh /dev/sdX --yes"
  exit 0
fi

if [[ ! -b "$DEVICE" ]]; then
  echo "not a block device: $DEVICE" >&2
  exit 1
fi

if is_system_dev "$DEVICE"; then
  echo "refusing to overwrite the disk that holds / ($DEVICE)" >&2
  exit 1
fi

rm_flag="$(lsblk -dn -o RM "$DEVICE" 2>/dev/null || echo 0)"
if [[ "$rm_flag" != "1" ]]; then
  echo "WARN: $DEVICE is not flagged removable (RM=1)." >&2
fi

if [[ "$PATCH" == 1 ]]; then
  echo "plan: update initrd on $DEVICE (no wipe)"
else
  echo "plan: wipe $DEVICE and install os.neu (ROOT_END=$ROOT_END)"
fi
lsblk "$DEVICE"
if is_vendorco_stick "$DEVICE" && [[ "$PATCH" != 1 ]] && [[ "$ROOT_END" == "100%" ]]; then
  echo "WARN: VendorCo/ProductCode 048d:1234 — 117G listing, last working ROOT was 15.5G."
  echo "      116G ROOT does not keep ext4 (journal inode / bitmap checksums from ~22GiB)."
  echo "      This stick: sudo ROOT_END=16GiB bash scripts/make-usb.sh $DEVICE --yes"
fi
if [[ "$PATCH" == 1 ]]; then
  if [[ "$(id -u)" != 0 ]]; then
    echo "USB update needs root. sudo bash scripts/make-usb.sh $DEVICE --update" >&2
    exit 1
  fi
  ESP="${DEVICE}1"
  ROOTP="${DEVICE}2"
  if [[ "$DEVICE" == *[0-9] ]]; then
    ESP="${DEVICE}p1"
    ROOTP="${DEVICE}p2"
  fi
  root_type="$(blkid -o value -s TYPE "$ROOTP" 2>/dev/null || true)"
  if [[ -z "$root_type" ]]; then
    echo "NEUOS-ROOT $ROOTP has no filesystem (not mountable)." >&2
    echo "Firmware can list UEFI USB then blink — JeOS console never starts. --update cannot proceed." >&2
    echo "This USB only: bash scripts/make-usb.sh --plan $DEVICE && sudo bash scripts/make-usb.sh $DEVICE --yes" >&2
    exit 1
  fi
  root_bytes="$(blockdev --getsize64 "$ROOTP" 2>/dev/null || echo 0)"
  if is_vendorco_stick "$DEVICE" && [[ "$root_bytes" -gt 30000000000 ]]; then
    refuse_fake_full_root "NEUOS-ROOT $ROOTP is $(lsblk -dn -o SIZE "$ROOTP") on VendorCo 117G listing. --update already noload-mounted then rsync hit bad block bitmap checksums from ~22GiB. ESP has kernel files but no BOOTX64.EFI — firmware blinks."
  fi
  stage_tree
  ESP_MNT=""
  ROOT_MNT=""
  update_cleanup() {
    if [[ -n "${ESP_MNT:-}" ]]; then
      umount "$ESP_MNT" 2>/dev/null || umount -l "$ESP_MNT" 2>/dev/null || true
      rmdir "$ESP_MNT" 2>/dev/null || true
    fi
    if [[ -n "${ROOT_MNT:-}" ]]; then
      umount "$ROOT_MNT" 2>/dev/null || umount -l "$ROOT_MNT" 2>/dev/null || true
      rmdir "$ROOT_MNT" 2>/dev/null || true
    fi
  }
  trap update_cleanup EXIT
  # A failed rsync (EUCLEAN) used to skip umount because of set -e.
  while tgt="$(findmnt -n -o TARGET "$ROOTP" 2>/dev/null | head -1)" && [[ -n "$tgt" ]]; do
    umount "$tgt" || umount -l "$tgt" || break
  done
  while tgt="$(findmnt -n -o TARGET "$ESP" 2>/dev/null | head -1)" && [[ -n "$tgt" ]]; do
    umount "$tgt" || umount -l "$tgt" || break
  done
  zap_corrupt_root_bins "$ROOTP"
  FSCK_RC=0
  fsck_root_no_journal "$ROOTP"
  # 0 clean, 1 corrected, 2 corrected+reboot. >=4 still dirty.
  if [[ "$FSCK_RC" -ge 4 ]]; then
    echo "NEUOS-ROOT still dirty after e2fsck (code $FSCK_RC). Re-plug the stick, or --plan then --yes to rebuild this USB only." >&2
    exit 1
  fi
  ESP_MNT="$(mktemp -d)"
  ROOT_MNT="$(mktemp -d)"
  if ! mount_neuos_root "$ROOTP" "$ROOT_MNT"; then
    exit 1
  fi
  mkdir -p "$ROOT_MNT/boot/grub"
  # Leftover /bin /sbin inodes stay corrupt after e2fsck salvage. Do not
  # rsync them (symlink replace → EIO 74 / EUCLEAN 117, script used to abort
  # before ESP grub.cfg). JeOS uses /usr/sbin/neuos-init.
  if command -v debugfs >/dev/null; then
    umount "$ROOT_MNT" 2>/dev/null || true
    debugfs -w -R 'unlink /bin' "$ROOTP" >/dev/null 2>&1 || true
    debugfs -w -R 'unlink /sbin' "$ROOTP" >/dev/null 2>&1 || true
    if ! mount_neuos_root "$ROOTP" "$ROOT_MNT"; then
      exit 1
    fi
  fi
  rsync_t0="$(date +%s)"
  set +e
  rsync -a --checksum --exclude='/bin' --exclude='/sbin' \
    --exclude='/lib/firmware' --exclude='/lib/modules' \
    "$STAGE/" "$ROOT_MNT/"
  rs_rc=$?
  set -e
  sync
  if [[ "$rs_rc" -ne 0 && "$rs_rc" -ne 23 ]]; then
    echo "rsync failed (code $rs_rc)" >&2
    exit 1
  fi
  if [[ "$rs_rc" -eq 23 ]]; then
    echo "WARN: rsync skipped some files. Checking whether JeOS payload read back..." >&2
  fi
  if [[ -n "$(ext4_io_errors_since "$ROOTP" "$rsync_t0")" ]]; then
    echo "WARN: EXT4 reported errors during rsync (often leftover /bin /sbin). Checking read-back..." >&2
  fi
  if ! verify_jeos_root "$ROOT_MNT"; then
    echo "FAIL: ROOT write did not read back. Do not treat this --update as success." >&2
    exit 1
  fi
  e2label "$ROOTP" NEUOS-ROOT 2>/dev/null || true
  echo "volume label $(e2label "$ROOTP" 2>/dev/null || echo unknown)"
  echo "updated payload on $ROOTP (NEUOS-ROOT, no partition wipe)."
  if mount_esp "$ESP" "$ESP_MNT"; then
    if [[ ! -f "$ESP_MNT/EFI/BOOT/BOOTX64.EFI" ]]; then
      echo "ESP has no BOOTX64.EFI — installing removable GRUB (no partition wipe)."
      if ! install_removable_grub "$DEVICE" "$ESP_MNT"; then
        echo "FAIL: ESP still has no BOOTX64.EFI — firmware will blink." >&2
        exit 1
      fi
    fi
    sync_esp_boot "$ESP_MNT" "$ROOT_MNT"
    sync
    if [[ ! -f "$ESP_MNT/EFI/BOOT/BOOTX64.EFI" ]]; then
      echo "FAIL: sync_esp_boot left ESP without BOOTX64.EFI." >&2
      exit 1
    fi
    echo "updated EFI boot files on $ESP (NEUOS-ESP)."
  else
    echo "WARN: NEUOS-ESP $ESP did not mount (vfat). ROOT payload is current." >&2
    echo "Re-plug the stick, then: sudo bash $ROOT/scripts/make-usb.sh $DEVICE --update" >&2
    echo "F8 may still work: GRUB search LABEL=NEUOS-ROOT loads kernel/initrd from partition 2." >&2
  fi
  exit 0
fi
if [[ "$PLAN" == 1 || "$YES" != 1 ]]; then
  echo
  if is_vendorco_stick "$DEVICE" && [[ "$ROOT_END" == "100%" ]]; then
    echo "To write this stick: sudo ROOT_END=16GiB bash scripts/make-usb.sh $DEVICE --yes"
  else
    echo "To write: sudo bash scripts/make-usb.sh $DEVICE --yes"
  fi
  exit 0
fi

if [[ "$(id -u)" != 0 ]]; then
  echo "USB write needs root. sudo bash scripts/make-usb.sh $DEVICE --yes" >&2
  exit 1
fi

if is_vendorco_stick "$DEVICE" && [[ "$ROOT_END" == "100%" && "$FORCE_FULL_ROOT" != "1" ]]; then
  refuse_fake_full_root "VendorCo ProductCode $DEVICE reports 117G. A 116G NEUOS-ROOT does not keep ext4 bitmaps (errors from ~22GiB)."
fi

stage_tree

zap_gpt "$DEVICE"
parted -s "$DEVICE" mklabel gpt
parted -s "$DEVICE" mkpart ESP fat32 1MiB 512MiB
parted -s "$DEVICE" set 1 esp on
parted -s "$DEVICE" mkpart ROOT ext4 512MiB "$ROOT_END"
settle_block "$DEVICE"
ESP="${DEVICE}1"
ROOTP="${DEVICE}2"
if [[ "$DEVICE" == *[0-9] ]]; then
  ESP="${DEVICE}p1"
  ROOTP="${DEVICE}p2"
fi
wait_part_node "$ESP"
wait_part_node "$ROOTP"
root_bytes="$(blockdev --getsize64 "$ROOTP" 2>/dev/null || echo 0)"
if [[ "$ROOT_END" == "100%" && "$root_bytes" -lt 30000000000 ]]; then
  echo "ROOT $ROOTP is ${root_bytes} bytes — kernel still has the old 15G table." >&2
  echo "Unplug this USB, plug the rear port, then: sudo bash $ROOT/scripts/make-usb.sh $DEVICE --yes" >&2
  exit 1
fi
if [[ "$ROOT_END" != "100%" && "$root_bytes" -lt 8000000000 ]]; then
  echo "ROOT $ROOTP is ${root_bytes} bytes after ROOT_END=$ROOT_END — too small." >&2
  exit 1
fi
mkfs.vfat -F 32 -n NEUOS-ESP "$ESP"
mkfs.ext4 -F -L NEUOS-ROOT -O ^has_journal "$ROOTP"
settle_block "$DEVICE"

ESP_MNT="$(mktemp -d)"
ROOT_MNT="$(mktemp -d)"
if ! mount_neuos_root "$ROOTP" "$ROOT_MNT"; then
  echo "could not mount $ROOTP after mkfs. Unplug/replug, then --update (no wipe) if NEUOS-ROOT is visible." >&2
  exit 1
fi
if ! mount_esp "$ESP" "$ESP_MNT"; then
  echo "could not mount $ESP after mkfs. ROOT is formatted. Re-plug, then --update." >&2
  exit 1
fi
mkdir -p "$ESP_MNT/EFI" "$ROOT_MNT/boot"
rsync_t0="$(date +%s)"
rsync -a "$STAGE/" "$ROOT_MNT/"
sync
if [[ -n "$(ext4_io_errors_since "$ROOTP" "$rsync_t0")" ]]; then
  echo "NEUOS-ROOT $ROOTP took EXT4 I/O errors during rsync. Payload is NOT on the stick." >&2
  exit 1
fi
if ! verify_jeos_root "$ROOT_MNT"; then
  echo "FAIL: ROOT write did not read back. Do not boot this stick." >&2
  exit 1
fi
if ! install_removable_grub "$DEVICE" "$ESP_MNT"; then
  echo "FAIL: BOOTX64.EFI not on ESP — firmware will blink." >&2
  exit 1
fi
sync_esp_boot "$ESP_MNT" "$ROOT_MNT"
sync
if [[ ! -f "$ESP_MNT/EFI/BOOT/BOOTX64.EFI" ]]; then
  echo "FAIL: ESP has no BOOTX64.EFI." >&2
  exit 1
fi
umount "$ESP_MNT" "$ROOT_MNT"
rmdir "$ESP_MNT" "$ROOT_MNT"
echo "neuOS is on $DEVICE (ROOT_END=$ROOT_END). Firmware boot menu → USB."
