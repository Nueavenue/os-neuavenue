#!/usr/bin/env node
/**
 * Generate HTML cream/theme packs for every PPT Studio recipe + CC BY pilot template.
 * Output: <root>/public/html-templates/<id>/{manifest.json,index.html,slides/*.html}
 * Safe: add-only / overwrite same paths with non-empty content. Never deletes.
 */
import fs from 'node:fs'
import path from 'node:path'

const ROOTS = process.argv.slice(2)
const targets = ROOTS.length
  ? ROOTS
  : ['/home/billy-lee/os.neu', '/home/billy-lee/neuOS']

const THEMES = {
  paper: {
    bg: '#ECE3D2', ink: '#14181D', soft: '#4A4D52', accent: '#BC4F2B',
    card: 'rgba(255,255,255,.45)', line: 'rgba(20,24,29,.16)', rail: '#BC4F2B',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'light',
  },
  'neu-investor': {
    bg: '#0B0D12', ink: '#E8EAED', soft: '#9AA0A8', accent: '#818CF8',
    card: 'rgba(255,255,255,.06)', line: 'rgba(255,255,255,.12)', rail: '#6366F1',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'dark',
  },
  'modern-business': {
    bg: '#F8FAFC', ink: '#0F172A', soft: '#475569', accent: '#334155',
    card: '#FFFFFF', line: 'rgba(15,23,42,.12)', rail: '#0F172A',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'light',
  },
  'tech-arch': {
    bg: '#070B14', ink: '#E2E8F0', soft: '#94A3B8', accent: '#38BDF8',
    card: 'rgba(56,189,248,.08)', line: 'rgba(56,189,248,.25)', rail: '#0EA5E9',
    font: "'Space Grotesk', Inter, sans-serif", mode: 'dark',
  },
  'minimal-corp': {
    bg: '#FFFFFF', ink: '#111827', soft: '#6B7280', accent: '#111827',
    card: '#F9FAFB', line: 'rgba(17,24,39,.1)', rail: '#111827',
    font: "'IBM Plex Sans', Inter, sans-serif", mode: 'light',
  },
  'dark-tech': {
    bg: '#09090B', ink: '#FAFAFA', soft: '#A1A1AA', accent: '#A78BFA',
    card: 'rgba(167,139,250,.1)', line: 'rgba(255,255,255,.1)', rail: '#7C3AED',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'dark',
  },
  pitch: {
    bg: '#0F172A', ink: '#F8FAFC', soft: '#94A3B8', accent: '#60A5FA',
    card: 'rgba(96,165,250,.1)', line: 'rgba(255,255,255,.12)', rail: '#3B82F6',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'dark',
  },
  report: {
    bg: '#F1F5F9', ink: '#0F172A', soft: '#475569', accent: '#0D9488',
    card: '#FFFFFF', line: 'rgba(13,148,136,.2)', rail: '#0D9488',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'light',
  },
  marketing: {
    bg: '#FFF7ED', ink: '#1C1917', soft: '#78716C', accent: '#EA580C',
    card: '#FFFFFF', line: 'rgba(234,88,12,.2)', rail: '#EA580C',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'light',
  },
  training: {
    bg: '#F0FDF4', ink: '#14532D', soft: '#3F6212', accent: '#059669',
    card: '#FFFFFF', line: 'rgba(5,150,105,.2)', rail: '#059669',
    font: "Inter, 'Noto Sans KR', sans-serif", mode: 'light',
  },
}

function humanize(key) {
  return key.split('-').map((w) => (w ? w[0].toUpperCase() + w.slice(1) : '')).join(' ')
}

function slideKind(key, index) {
  if (index === 0 || key === 'cover' || key === 'closing' || key === 'ask' || key === 'next') return 'title'
  if (/metric|table|roadmap|timeline|comparison|verification|funding/.test(key)) return 'table'
  if (/grid|feature|channel|persona|component/.test(key)) return 'grid'
  return 'bullets'
}

function slideHtml(pack, key, index, theme) {
  const t = THEMES[theme] || THEMES.paper
  const title = index === 0 ? pack.name : humanize(key)
  const kind = slideKind(key, index)
  const subtitle = pack.cardSubtitle || pack.name
  const label = String(index + 1).padStart(2, '0') + ' · ' + humanize(key)
  let body = ''
  if (kind === 'title') {
    body = `
  <p style="position:absolute;left:96px;top:120px;font-size:16px;font-weight:700;letter-spacing:.16em;color:${t.accent};">${esc(pack.nameKo || pack.name).toUpperCase()}</p>
  <h1 style="position:absolute;left:96px;top:220px;margin:0;width:1600px;font-size:72px;font-weight:800;line-height:1.08;letter-spacing:-.03em;color:${t.ink};">${esc(title)}</h1>
  <p style="position:absolute;left:96px;top:460px;width:1200px;font-size:26px;line-height:1.45;color:${t.soft};">${esc(subtitle)}</p>
  <p style="position:absolute;left:96px;top:980px;font-size:15px;color:${t.soft};">HTML template · ${esc(pack.id)} · placeholders only · no invented metrics</p>`
  } else if (kind === 'table') {
    body = `
  <p style="position:absolute;left:96px;top:72px;font-size:14px;font-weight:700;letter-spacing:.14em;color:${t.accent};">${esc(label)}</p>
  <h1 style="position:absolute;left:96px;top:120px;margin:0;font-size:48px;font-weight:800;color:${t.ink};">${esc(title)}</h1>
  <div style="position:absolute;left:96px;top:240px;width:1728px;border:1px solid ${t.line};border-radius:12px;overflow:hidden;background:${t.card};">
    <div style="display:grid;grid-template-columns:1fr 2fr;padding:18px 28px;font-size:18px;font-weight:700;border-bottom:1px solid ${t.line};color:${t.ink};"><span>Topic</span><span>Notes</span></div>
    <div style="display:grid;grid-template-columns:1fr 2fr;padding:18px 28px;font-size:20px;border-bottom:1px solid ${t.line};color:${t.ink};"><span>Item A</span><span>Outline · edit with Agent</span></div>
    <div style="display:grid;grid-template-columns:1fr 2fr;padding:18px 28px;font-size:20px;color:${t.ink};"><span>Item B</span><span>Outline · edit with Agent</span></div>
  </div>
  <p style="position:absolute;left:96px;top:980px;font-size:15px;color:${t.soft};">Table layout · HTML pack</p>`
  } else if (kind === 'grid') {
    const cards = ['Point one', 'Point two', 'Point three'].map((txt, n) => `
    <div style="position:absolute;left:${96 + n * 560}px;top:280px;width:520px;height:520px;border:1px solid ${t.line};border-radius:16px;background:${t.card};padding:36px;box-sizing:border-box;">
      <p style="margin:0;font-size:14px;font-weight:700;letter-spacing:.12em;color:${t.accent};">0${n + 1}</p>
      <h2 style="margin:24px 0 16px;font-size:32px;font-weight:800;color:${t.ink};">${txt}</h2>
      <p style="margin:0;font-size:20px;line-height:1.5;color:${t.soft};">Placeholder copy. Replace via surgical Agent ops.</p>
    </div>`).join('')
    body = `
  <p style="position:absolute;left:96px;top:72px;font-size:14px;font-weight:700;letter-spacing:.14em;color:${t.accent};">${esc(label)}</p>
  <h1 style="position:absolute;left:96px;top:120px;margin:0;font-size:48px;font-weight:800;color:${t.ink};">${esc(title)}</h1>
  ${cards}`
  } else {
    body = `
  <p style="position:absolute;left:96px;top:72px;font-size:14px;font-weight:700;letter-spacing:.14em;color:${t.accent};">${esc(label)}</p>
  <h1 style="position:absolute;left:96px;top:120px;margin:0;font-size:48px;font-weight:800;color:${t.ink};">${esc(title)}</h1>
  <ul style="position:absolute;left:96px;top:260px;margin:0;padding:0;list-style:none;width:1600px;">
    <li style="margin:0 0 28px;padding-left:28px;border-left:4px solid ${t.accent};font-size:28px;line-height:1.4;color:${t.ink};">Key point one</li>
    <li style="margin:0 0 28px;padding-left:28px;border-left:4px solid ${t.accent};font-size:28px;line-height:1.4;color:${t.ink};">Key point two</li>
    <li style="margin:0 0 28px;padding-left:28px;border-left:4px solid ${t.accent};font-size:28px;line-height:1.4;color:${t.ink};">Key point three</li>
  </ul>
  <p style="position:absolute;left:96px;top:980px;font-size:15px;color:${t.soft};">Bullets layout · HTML pack</p>`
  }

  return `<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8"><title>${esc(title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+KR:wght@400;700;800&family=Space+Grotesk:wght@500;700&family=IBM+Plex+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body{margin:0;overflow:hidden;font-family:${t.font};background:${t.bg};color:${t.ink};}
p,h1,h2,ul,li{margin:0;}
</style></head>
<body>
<div class="slide-container" data-slide-key="${esc(key)}" style="position:relative;width:1920px;height:1080px;background:${t.bg};">
  <div style="position:absolute;left:0;top:0;width:12px;height:1080px;background:${t.rail};"></div>
  ${body}
</div>
</body></html>
`
}

function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

const PACKS = [
  { id: 'neu-investor-dark', name: 'NEU Investor Deck', nameKo: 'NEU 투자 덱', cardSubtitle: 'For funding and partnerships', previewTheme: 'neu-investor',
    structure: ['cover','problem','solution','market','product','technology','business-model','traction','roadmap','team','funding','closing'] },
  { id: 'modern-business', name: 'Modern Business', nameKo: '모던 비즈니스', cardSubtitle: 'Clean & professional', previewTheme: 'modern-business',
    structure: ['cover','agenda','overview','highlights','next-steps','team','risks','closing'] },
  { id: 'tech-architecture', name: 'Tech Architecture', nameKo: '기술 아키텍처', cardSubtitle: 'Technical diagrams', previewTheme: 'tech-arch',
    structure: ['cover','context','architecture','components','data-flow','security','scalability','integration','roadmap','closing'] },
  { id: 'minimal-corporate', name: 'Minimal Corporate', nameKo: '미니멀 코퍼레이트', cardSubtitle: 'Simple & elegant', previewTheme: 'minimal-corp',
    structure: ['cover','summary','vision','progress','metrics','risks','team','next'] },
  { id: 'dark-tech', name: 'Dark Tech', nameKo: '다크 테크', cardSubtitle: 'Bold & modern', previewTheme: 'dark-tech',
    structure: ['cover','problem','product','features','comparison','next'] },
  { id: 'product-launch', name: 'Product Launch', nameKo: '제품 런치', cardSubtitle: 'Ship the story', previewTheme: 'dark-tech',
    structure: ['cover','problem','audience','steps','feature-comparison','benefits','timeline','next'] },
  { id: 'popular-pitch-deck', name: 'Pitch Deck', nameKo: '피치 덱', cardSubtitle: 'Problem → Ask', previewTheme: 'pitch',
    structure: ['cover','problem','solution','market','team','ask'] },
  { id: 'business-plan', name: 'Business Plan', nameKo: '사업 계획', cardSubtitle: 'Strategy outline', previewTheme: 'paper',
    structure: ['cover','vision','market','model','plan','milestones'] },
  { id: 'research-report', name: 'Research Report', nameKo: '리서치 보고', cardSubtitle: 'Findings & metrics', previewTheme: 'report',
    structure: ['cover','summary','method','findings','metrics','recommendations'] },
  { id: 'marketing-plan', name: 'Marketing Plan', nameKo: '마케팅 계획', cardSubtitle: 'Campaign focus', previewTheme: 'marketing',
    structure: ['cover','audience','message','channels','timeline','kpis'] },
  { id: 'training-education', name: 'Training & Education', nameKo: '교육 · 트레이닝', cardSubtitle: 'Steps & exercises', previewTheme: 'training',
    structure: ['cover','objectives','steps','demo','quiz','resources'] },
  // CC BY pilots (schema → HTML shells; attribution in manifest)
  { id: 'ccby-pilot-business', name: 'Business Brief (CC BY pilot)', nameKo: '비즈니스 브리프 (CC BY 파일럿)', cardSubtitle: 'CC BY 4.0 · schema', previewTheme: 'modern-business',
    structure: ['cover','problem','solution','market','traction','roadmap','ask','closing'], license: 'CC BY 4.0 · ppttemplate.ai' },
  { id: 'ccby-pilot-education', name: 'Education Outline (CC BY pilot)', nameKo: '교육 개요 (CC BY 파일럿)', cardSubtitle: 'CC BY 4.0 · schema', previewTheme: 'report',
    structure: ['cover','objectives','overview','steps','comparison','resources','next','closing'], license: 'CC BY 4.0 · ppttemplate.ai' },
  { id: 'ccby-pilot-marketing', name: 'Marketing Update (CC BY pilot)', nameKo: '마케팅 업데이트 (CC BY 파일럿)', cardSubtitle: 'CC BY 4.0 · schema', previewTheme: 'marketing',
    structure: ['cover','problem','solution','market','product','metrics','roadmap','closing'], license: 'CC BY 4.0 · ppttemplate.ai' },
]

const INDEX_HTML = `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8" />
<title>HTML Deck</title>
<link rel="stylesheet" href="/html-deck/shell.css" />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+KR:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="app" id="app">
  <aside class="rail">
    <div class="rail-h" id="railTitle">HTML DECK</div>
    <div class="rail-sub">드래그로 순서 변경 · 클릭=미리보기 · Agent=부분수정/순서/이미지→HTML</div>
    <div class="thumbs" id="thumbs"></div>
  </aside>
  <main class="stage-wrap">
    <div class="topbar">
      <div>
        <h1 id="deckTitle">HTML Deck</h1>
        <div class="meta" id="pageMeta">…</div>
      </div>
      <div class="navbtns">
        <button type="button" id="prev">← 이전</button>
        <button type="button" id="next">다음 →</button>
        <button type="button" class="primary" id="presentBtn">Present</button>
        <button type="button" id="exportCream">크림 내보내기</button>
        <button type="button" id="openRaw">원본 HTML</button>
      </div>
    </div>
    <div class="stage">
      <div class="viewport" id="viewport">
        <div class="viewport-inner" id="viewportInner">
          <iframe id="stageFrame" title="slide" sandbox="allow-same-origin allow-scripts"></iframe>
        </div>
      </div>
    </div>
  </main>
  <aside class="agent" id="agentPane">
    <div class="agent-h">HTML Deck · Agent</div>
    <div class="agent-sub">intent → route → ChangeSet → Apply. 순서 이동 · 이미지 추출 지원.</div>
    <div class="agent-body">
      <div class="lock" id="lockBox">LOCK 로드 중…</div>
      <div class="route" id="routeBox">
        <div class="route-title">AGENT ROUTE</div>
        <ol id="routeList">
          <li data-step="idle" class="on">idle · 슬라이드 선택 대기</li>
          <li data-step="thinking">thinking · 지시 해석</li>
          <li data-step="planning">planning · 템플릿 슬롯 맞춤</li>
          <li data-step="previewing">previewing · ChangeSet 제안</li>
          <li data-step="waiting_approval">waiting_approval · Apply / Reject</li>
          <li data-step="applying">applying · override 기록</li>
          <li data-step="completed">completed / failed</li>
        </ol>
      </div>
      <div class="chips" id="chips">
        <button type="button" class="chip" data-prompt='삭제: "여기에 지울 문장을 그대로 인용"'>인용 삭제</button>
        <button type="button" class="chip" data-prompt="제목 문구만 더 짧게. 표·카드·좌표는 건드리지 마. 수치 발명 금지.">짧게(부분)</button>
        <button type="button" class="chip" data-prompt="순서: 표지를 맨 앞으로">표지 맨앞</button>
        <button type="button" class="chip" data-prompt="자동 순서 정렬: cover→problem→solution→market→product→team→ask→closing">자동 순서</button>
        <button type="button" class="chip" data-prompt="3번을 1번으로 이동">3→1 이동</button>
        <button type="button" class="chip" data-prompt="이미지에서 레이아웃 추출">이미지→HTML</button>
      </div>
      <label class="file-lab" for="imageIn">이미지 파일 → HTML 슬라이드</label>
      <input type="file" id="imageIn" accept="image/*,.png,.jpg,.jpeg,.webp" />
      <label for="prompt" style="font-size:12px;color:var(--muted);">프롬프트 · 기본=부분 수정 · 순서/이미지 명령 지원</label>
      <textarea id="prompt" placeholder='예: 삭제: "문장"  ·  2번을 5번 뒤로  ·  자동 순서 정렬'></textarea>
      <div class="navbtns">
        <button type="button" class="btn primary" id="runAgent">Agent 실행</button>
        <button type="button" class="btn" id="applyCs" disabled>Apply</button>
        <button type="button" class="btn" id="rejectCs" disabled>Reject</button>
        <button type="button" class="btn" id="restore">원본 복원</button>
      </div>
      <div class="changeset" id="csBox">ChangeSet: 없음</div>
      <div class="log" id="log">드래그로 썸네일 순서 변경 · Agent로 순서/이미지→HTML</div>
    </div>
  </aside>
</div>
<div class="present-hint" id="presentHint">클릭/← → 넘기기 · Esc 종료</div>
<nav class="present-nav" id="presentNav" aria-label="Present navigation">
  <button type="button" class="hit hit-prev" id="presentHitPrev" aria-label="Previous slide"></button>
  <button type="button" class="hit hit-next" id="presentHitNext" aria-label="Next slide"></button>
  <button type="button" class="fab fab-prev" id="presentFabPrev">← 이전</button>
  <button type="button" class="fab fab-next" id="presentFabNext">다음 →</button>
  <button type="button" class="fab fab-exit" id="presentFabExit">Esc · 종료</button>
</nav>
<script src="/html-deck/runtime.js"></script>
</body>
</html>
`

function writePack(root, pack) {
  const dir = path.join(root, 'public', 'html-templates', pack.id)
  const slidesDir = path.join(dir, 'slides')
  fs.mkdirSync(slidesDir, { recursive: true })
  const slides = pack.structure.map((key, index) => {
    const file = `${String(index + 1).padStart(2, '0')}-${key}.html`
    const html = slideHtml(pack, key, index, pack.previewTheme)
    const out = path.join(slidesDir, file)
    fs.writeFileSync(out, html, 'utf8')
    if (fs.statSync(out).size < 2) throw new Error('empty slide: ' + out)
    return {
      id: key,
      file,
      label: `${String(index + 1).padStart(2, '0')} ${humanize(key)}`,
    }
  })
  const locks = [
    'Trusted Agent Seat',
    'Agent Operating Layer',
    'not AI desktop OS',
    'placeholders only · no invented revenue',
  ]
  if (pack.license) locks.push(pack.license)
  const manifest = {
    id: pack.id,
    title: pack.name,
    titleKo: pack.nameKo,
    visual: pack.previewTheme,
    locks,
    structure: pack.structure,
    slides,
  }
  const manPath = path.join(dir, 'manifest.json')
  fs.writeFileSync(manPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8')
  const idxPath = path.join(dir, 'index.html')
  fs.writeFileSync(idxPath, INDEX_HTML, 'utf8')
  return { dir, slides: slides.length, bytes: fs.statSync(idxPath).size }
}

let total = 0
for (const root of targets) {
  if (!fs.existsSync(path.join(root, 'public'))) {
    console.error('skip missing public:', root)
    continue
  }
  for (const pack of PACKS) {
    const r = writePack(root, pack)
    total += 1
    console.log('OK', root, pack.id, r.slides, 'slides')
  }
}
console.log('DONE packs=', total)
