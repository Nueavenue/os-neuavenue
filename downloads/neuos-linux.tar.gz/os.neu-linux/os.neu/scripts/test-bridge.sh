#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== unit tests =="
npx vitest run

echo "== bridge health =="
curl -sf http://127.0.0.1:4178/api/health | tee /tmp/neuos-health.json
python3 - <<'PY'
import json
from pathlib import Path
data = json.loads(Path("/tmp/neuos-health.json").read_text())
assert data.get("ok") is True
print("health ok", data.get("driver"), data.get("browse"))
PY

echo "== browse proxy =="
curl -sf "http://127.0.0.1:4178/api/browse?url=http://127.0.0.1:4178/api/demo" | grep -q NEUOS_BROWSER_OK

echo "== sandbox reject =="
curl -s -X POST http://127.0.0.1:4178/api/driver/act \
  -H 'content-type: application/json' \
  -d '{"kind":"click","x":1,"y":1,"sandbox":{"left":100,"top":100,"width":200,"height":200}}' \
  | grep -q '"ok":false'

echo "== dry click inside sandbox =="
curl -sf -X POST http://127.0.0.1:4178/api/driver/act \
  -H 'content-type: application/json' \
  -d '{"kind":"click","x":120,"y":120,"sandbox":{"left":100,"top":100,"width":200,"height":200}}' \
  | grep -q '"ok":true'

if command -v xdotool >/dev/null && command -v Xvfb >/dev/null; then
  echo "== xdotool on Xvfb =="
  Xvfb :99 -screen 0 800x600x24 >/tmp/neuos-xvfb.log 2>&1 &
  XVFB_PID=$!
  sleep 0.4
  DISPLAY=:99 NEUOS_DRIVER=live npx tsx -e '
    import { act } from "./server/driver.ts";
    const r = await act({ kind:"click", x:40, y:40, sandbox:{left:0,top:0,width:800,height:600} });
    if (!r.ok) throw new Error("live click failed");
    console.log("xvfb click", r);
  '
  kill "$XVFB_PID" 2>/dev/null || true
fi

echo "== vlm check =="
python3 scripts/finetune_vlm.py --check-only

echo "all driver/browser checks passed"
