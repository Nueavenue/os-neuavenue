#!/usr/bin/env bash
# Copy os.neu USB boot logs (NEUOS-ESP/osneu-logs) to /tmp for review after
# booting back into Ubuntu. Read-only: mounts the ESP with -o ro through
# udisks (no sudo), copies, and unmounts only if this script mounted it.
# Never writes to the stick. Refuses non-removable disks.
#
#   bash scripts/usb-logs-pull.sh            find NEUOS-ESP by label
#   bash scripts/usb-logs-pull.sh /dev/sdX1  explicit ESP partition
set -euo pipefail

OUT_ROOT=/tmp/osneu-usb-logs
TS="$(date +%Y%m%dT%H%M%S)"

find_esp() {
  local path label fstype removable pk
  while read -r path label fstype removable pk; do
    [[ "$label" == "NEUOS-ESP" ]] && { echo "$path"; return 0; }
  done < <(lsblk -rpno PATH,LABEL,FSTYPE,RM,PKNAME 2>/dev/null)
  # Label not in the udev db yet: partition 1 of a removable VendorCo disk.
  while read -r path removable model; do
    [[ "$removable" == "1" && "$model" == "ProductCode" ]] || continue
    [[ -b "${path}1" ]] && { echo "${path}1"; return 0; }
  done < <(lsblk -dpno PATH,RM,MODEL 2>/dev/null)
  return 1
}

ESP="${1:-}"
if [[ -z "$ESP" ]]; then
  ESP="$(find_esp)" || { echo "NEUOS-ESP not found. Plug the os.neu stick, then: lsblk -o NAME,SIZE,MODEL,LABEL" >&2; exit 1; }
fi
[[ -b "$ESP" ]] || { echo "$ESP is not a block device" >&2; exit 1; }
DISK="/dev/$(lsblk -no PKNAME "$ESP" | head -n 1)"
if [[ "$(lsblk -dno RM "$DISK" 2>/dev/null | tr -d ' ')" != "1" ]]; then
  echo "REFUSE: $DISK is not removable. This script only reads the os.neu USB stick." >&2
  exit 1
fi
echo "ESP $ESP on $DISK ($(lsblk -dno MODEL,SIZE "$DISK" | xargs))"

MNT="$(lsblk -no MOUNTPOINT "$ESP" | head -n 1)"
MOUNTED_HERE=0
if [[ -z "$MNT" ]]; then
  if ! out="$(udisksctl mount -b "$ESP" -o ro --no-user-interaction 2>&1)"; then
    echo "udisks mount failed: $out" >&2
    echo "Fallback (read-only): sudo mkdir -p /mnt/osneu-esp && sudo mount -o ro $ESP /mnt/osneu-esp && bash $0" >&2
    exit 1
  fi
  MNT="$(lsblk -no MOUNTPOINT "$ESP" | head -n 1)"
  MOUNTED_HERE=1
fi
cleanup() {
  if [[ "$MOUNTED_HERE" == 1 ]]; then
    udisksctl unmount -b "$ESP" --no-user-interaction >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

if [[ ! -d "$MNT/osneu-logs" ]]; then
  echo "No osneu-logs on $ESP ($MNT). Boot did not reach the recorder, or the ESP mount failed on the stick." >&2
  ls -la "$MNT" >&2 || true
  exit 2
fi

OUT="$OUT_ROOT/$TS"
mkdir -p "$OUT"
cp -r "$MNT/osneu-logs/." "$OUT/"
echo "copied to $OUT"
for d in "$OUT"/boot-*/; do
  [[ -d "$d" ]] || continue
  echo
  echo "== $(basename "$d")"
  tail -n 12 "$d/stages.txt" 2>/dev/null || echo "(no stages.txt)"
done
ls "$OUT"/input-*.log 2>/dev/null | sed 's/^/input log: /' || true
echo
echo "Tell the agent: logs at $OUT"
