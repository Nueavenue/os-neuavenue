#!/usr/bin/env bash
# Copy already-downloaded Ollama models onto a USB mount.
# Does not wipe the stick. Does not download. Refuses when the stick is too small.
# Usage: bash scripts/pack-llm-usb.sh /media/$USER/STICK
set -euo pipefail

MOUNT="${1:-}"
if [[ -z "$MOUNT" || ! -d "$MOUNT" ]]; then
  echo "USB 마운트 경로를 주세요. 예: bash scripts/pack-llm-usb.sh /media/\$USER/STICK" >&2
  echo "이 스크립트는 디스크를 지우지 않습니다. 받아 둔 모델만 복사합니다." >&2
  exit 2
fi

SRC="${OLLAMA_MODELS:-$HOME/.ollama/models}"
DEST="$MOUNT/os.neu-llm"
mkdir -p "$DEST"

cat >"$DEST/LIMITS.txt" <<'EOF'
os.neu 로컬 LLM 한계 — USB에 담아도 동일합니다.

공통
- 웹을 검색하지 않습니다. 인터넷이 켜져 있어도 모델은 학습 때 본 것만 말합니다.
- 틀린 문장을 사실처럼 쓸 수 있습니다. 의료·법률·투자 결정에 쓰지 마세요.
- 계산은 이 PC 안입니다. OpenAI를 고르면 그 문장은 OpenAI로 나갑니다. 기업 기밀은 로컬만 쓰세요.
- 100줄을 보장하지 않습니다. 1B는 약 120토큰. 7B–9B는 약 1024토큰(최대 약 80줄).
- CPU만이면 7B–9B는 한 문단도 1B보다 오래 걸리고, 시간 제한으로 끊길 수 있습니다.
- 기존 Windows/Linux 없이 USB만으로 os.neu 그래픽 화면이 뜨는 기능은 아직 없습니다.
  USB는 텍스트 JeOS입니다. 그래픽 좌석은 이미 설치된 호스트 OS 위에 심습니다.

모델
- llama3.2:1b — Meta, 지식 약 2023-12까지. 짧은 답만.
- llama3.1:8b — Meta, 지식 2023-12까지. Llama 커뮤니티 라이선스. 약 4.9GB.
- qwen2.5:7b — Alibaba, 2024-09 공개. 그 이후 사건은 모름. 약 4.7GB.
- gemma2:9b — Google, 2024-06 공개. 영어 중심. 약 5.5GB. Gemma 약관.
EOF

if [[ ! -d "$SRC" ]]; then
  echo "이 PC에 Ollama 모델 디렉터리가 없습니다. LIMITS.txt만 썼습니다: $DEST/LIMITS.txt" >&2
  exit 0
fi

mapfile -t blobs < <(find "$SRC" -type f -size +1M 2>/dev/null || true)
if [[ ${#blobs[@]} -eq 0 ]]; then
  echo "복사할 모델 파일이 없습니다. LIMITS.txt만 썼습니다: $DEST/LIMITS.txt" >&2
  exit 0
fi

need=$(du -sb "$SRC" | awk '{print $1}')
avail=$(df -B1 --output=avail "$MOUNT" | tail -1 | tr -d ' ')
if [[ "$avail" -lt $((need + 1000000000)) ]]; then
  echo "USB 여유 ${avail}바이트, 모델 ${need}바이트. 1GB 여유를 남기려면 부족합니다. 복사하지 않았습니다." >&2
  exit 1
fi

echo "복사: $SRC → $DEST/models"
mkdir -p "$DEST/models"
cp -a "$SRC/." "$DEST/models/"
echo "끝났습니다. 한계 설명: $DEST/LIMITS.txt"
