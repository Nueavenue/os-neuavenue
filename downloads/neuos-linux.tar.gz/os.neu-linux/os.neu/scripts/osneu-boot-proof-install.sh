#!/usr/bin/env bash
# Install systemd units for the 3× os.neu boot proof (root).
set -euo pipefail
APP="${NEUOS_APP:-/home/billy-lee/neuOS}"
[[ "$(id -u)" = 0 ]] || { echo "run with pkexec/sudo" >&2; exit 1; }

install -d -o billy-lee -g billy-lee /home/billy-lee/.local/state/osneu/boot-proof
printf '0\n' > /home/billy-lee/.local/state/osneu/boot-proof/counter
chown billy-lee:billy-lee /home/billy-lee/.local/state/osneu/boot-proof/counter
rm -f /home/billy-lee/.local/state/osneu/boot-proof/READY_FOR_ADVANCE \
  /home/billy-lee/.local/state/osneu/boot-proof/NEED_RECOVER_CHECK \
  /home/billy-lee/.local/state/osneu/boot-proof/RECOVERY_RESULT

cat > /etc/systemd/system/osneu-boot-proof.service <<EOF
# os.neu boot proof (3 cycles) — scripts/osneu-boot-proof-install.sh
[Unit]
Description=os.neu boot proof checks after kiosk start
After=osneu-kiosk.service
Wants=osneu-kiosk.service
# Only when this boot asked for the kiosk target
ConditionKernelCommandLine=systemd.unit=osneu-kiosk.target

[Service]
Type=oneshot
User=billy-lee
PAMName=login
Environment=HOME=/home/billy-lee
Environment=NEUOS_APP=$APP
Environment=XDG_RUNTIME_DIR=/run/user/1000
ExecStart=$APP/scripts/osneu-boot-proof-check.sh
# Root advance: next os.neu or Ubuntu recovery
ExecStartPost=+$APP/scripts/osneu-boot-proof-advance.sh

[Install]
WantedBy=osneu-kiosk.target
EOF

cat > /etc/systemd/system/osneu-boot-proof-recover.service <<EOF
# os.neu boot proof recovery check on Ubuntu
[Unit]
Description=os.neu boot proof recovery check after returning to Ubuntu
After=network-online.target
Wants=network-online.target
ConditionPathExists=/home/billy-lee/.local/state/osneu/boot-proof/NEED_RECOVER_CHECK
ConditionKernelCommandLine=!systemd.unit=osneu-kiosk.target

[Service]
Type=oneshot
ExecStart=$APP/scripts/osneu-boot-proof-recover.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

chmod 0755 "$APP/scripts/osneu-boot-proof-check.sh" \
  "$APP/scripts/osneu-boot-proof-advance.sh" \
  "$APP/scripts/osneu-boot-proof-recover.sh"
systemctl daemon-reload
systemctl enable osneu-boot-proof.service
systemctl enable osneu-boot-proof-recover.service
echo "installed and enabled osneu-boot-proof (+ recover)"
systemctl cat osneu-boot-proof.service | head -25
