@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"

if not exist "%ROOT%\electron\main.cjs" (
  echo os.neu: missing electron\main.cjs in %ROOT%
  exit /b 1
)

where powershell >nul 2>nul
if errorlevel 1 (
  echo Need PowerShell to open the os.neu screen on Windows.
  exit /b 2
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0screen.ps1" %*
endlocal
