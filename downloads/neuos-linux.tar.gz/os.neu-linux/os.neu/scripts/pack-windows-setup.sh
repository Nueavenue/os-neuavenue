#!/usr/bin/env bash
# Slice 1: unsigned per-user NSIS os.neu-Setup.exe. Does not publish Door B.
# Does not sign. Does not wipe disks. Windows/JeOS USB is a different product.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  if grep -E '^[A-Za-z0-9_]*(SERVICE_ROLE|service_role|SECRET_KEY)' .env >/dev/null 2>&1; then
    echo "FAIL: refusing to pack while a service-role / secret key name is in .env (WS-4)."
    exit 2
  fi
fi

npm run build
npm run bundle:bridge

if [[ ! -f dist-bridge/index.mjs || ! -f dist-web/index.html ]]; then
  echo "FAIL: dist-bridge or dist-web missing after build"
  exit 1
fi

export CSC_IDENTITY_AUTO_DISCOVERY=false
npx electron-builder --win nsis --x64

echo "PASS: unsigned installer at $ROOT/dist-installer/os.neu-Setup.exe"
echo "Next: copy that file into a Win11 x64 VM. SmartScreen → More info → Run anyway."
