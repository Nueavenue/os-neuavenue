#!/usr/bin/env python3
"""Validate neuOS VLM fine-tune samples. Optional torch training is off by default."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "data" / "vlm-samples"


def load_samples() -> list[dict]:
    items: list[dict] = []
    if not SAMPLES.exists():
        return items
    for path in sorted(SAMPLES.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data.get("boxes"), list):
            raise SystemExit(f"boxes missing in {path}")
        items.append(data)
    return items


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    items = load_samples()
    print(f"vlm samples: {len(items)}")
    if args.check_only or not items:
        return
    print("Fine-tune next step: map boxes to a detection model")
    print("https://huggingface.co/docs/transformers/en/tasks/object_detection")


if __name__ == "__main__":
    main()
