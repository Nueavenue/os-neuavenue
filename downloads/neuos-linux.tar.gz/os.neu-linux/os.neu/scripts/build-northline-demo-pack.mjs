#!/usr/bin/env node
/**
 * Copy PSST full HTML pack → public demo with third-party-looking copy.
 * Layout + CSS colors unchanged; text/brand strings rewritten only.
 * Add-only: never deletes source pack.
 */
import fs from 'node:fs'
import path from 'node:path'

const ROOTS = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['/home/billy-lee/os.neu', '/home/billy-lee/neuOS']

/** Longest-first replacements (text / titles only — colors & CSS vars untouched). */
const REPLACEMENTS = [
  ['NeuAvenue Inc.', 'Northline Systems Inc.'],
  ['NEU Avenue Inc.', 'Northline Systems Inc.'],
  ['NeuAvenue', 'Northline'],
  ['neuavenue.com', 'northline.example'],
  ['www.neuavenue.com', 'www.northline.example'],
  ['app.neuavenue.com', 'app.northline.example'],
  ['Life-Force Platform', 'Harbor Hub Platform'],
  ['Life-Force hub', 'Harbor Hub'],
  ['Life-Force', 'Harbor Hub'],
  ['Life Force', 'Harbor Hub'],
  ['Intent-first Trusted Agent Seat', 'Intent-first Guided Operator Desk'],
  ['Trusted Agent Seat', 'Guided Operator Desk'],
  ['Agent Operating Layer', 'Operator Coordination Layer'],
  ['Ambient Seat', 'Harbor Desk'],
  ['Billy Lee', 'Jordan Hale'],
  ['daf.neu', 'atlas.browse'],
  ['os.neu', 'north.seat'],
  ['OS.NEU', 'NORTH.SEAT'],
  ['PSST ·', 'DEMO IR ·'],
  ['PSST', 'DEMO IR'],
  ['IR PSST', 'Northline DEMO IR'],
  ['사업계획서', '샘플 사업계획서'],
  ['앱 중심에서 의도 중심 검색 운영체제', '앱 중심에서 의도 중심 작업 좌석'],
  ['검색 운영체제', '의도 작업 좌석'],
  ['독립 OS', '독립 Host 계층'],
  ["Don't build another Agent. Build the Seat for Agents.", "Don't ship another chatbot. Build the Desk for Operators."],
  ['Charge the Seat, not the Kernel', 'Charge the Desk, not the Kernel'],
  ['Y1 plant $0', 'Y1 lab $0'],
  ['KEY-KEEPS', 'KEY-KEEPS · DEMO'],
]

function rewriteText(html) {
  let out = html
  // Do not touch <style>…</style> blocks (colors / layout tokens)
  const parts = out.split(/(<style[\s\S]*?<\/style>)/i)
  for (let i = 0; i < parts.length; i++) {
    if (/^<style/i.test(parts[i])) continue
    let chunk = parts[i]
    for (const [from, to] of REPLACEMENTS) {
      chunk = chunk.split(from).join(to)
    }
    parts[i] = chunk
  }
  return parts.join('')
}

const INDEX_HTML = fs.readFileSync(
  '/home/billy-lee/os.neu/public/html-templates/neu-investor-dark/index.html',
  'utf8',
)

for (const root of ROOTS) {
  const srcDir = path.join(root, 'public', 'psst-ir-pack')
  const srcSlides = path.join(srcDir, 'slides')
  const destDir = path.join(root, 'public', 'html-templates', 'northline-ir-demo')
  const destSlides = path.join(destDir, 'slides')
  if (!fs.existsSync(srcSlides)) {
    console.error('skip missing', srcSlides)
    continue
  }
  fs.mkdirSync(destSlides, { recursive: true })

  const manSrc = JSON.parse(fs.readFileSync(path.join(srcDir, 'manifest.json'), 'utf8'))
  const slides = []
  for (const row of manSrc.slides || []) {
    const srcFile = path.join(srcSlides, row.file)
    if (!fs.existsSync(srcFile)) {
      console.warn('MISSING slide', srcFile)
      continue
    }
    const raw = fs.readFileSync(srcFile, 'utf8')
    const out = rewriteText(raw)
    const destFile = path.join(destSlides, row.file)
    fs.writeFileSync(destFile, out, 'utf8')
    if (fs.statSync(destFile).size < 2) throw new Error('empty ' + destFile)
    slides.push({
      id: row.id,
      file: row.file,
      label: rewriteText(row.label),
    })
  }

  const manifest = {
    id: 'northline-ir-demo',
    title: 'Northline DEMO IR',
    titleKo: 'Northline · DEMO IR 샘플',
    visual: 'paper-cream',
    locks: [
      'DEMO only · fictional company',
      'Guided Operator Desk',
      'Operator Coordination Layer',
      'layout/colors from PSST shell · copy rewritten',
      'not NeuAvenue business content',
    ],
    sourceNote: 'Layout cloned from psst-ir-pack; branding rewritten for public gallery demo.',
    slides,
  }
  fs.writeFileSync(path.join(destDir, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8')
  fs.writeFileSync(path.join(destDir, 'index.html'), INDEX_HTML, 'utf8')
  console.log('OK', root, 'slides', slides.length)
}
console.log('DONE')
