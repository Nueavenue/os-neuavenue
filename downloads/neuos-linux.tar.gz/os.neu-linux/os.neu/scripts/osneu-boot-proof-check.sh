#!/usr/bin/env bash
# Run inside the os.neu kiosk session (User=billy-lee). Writes one report per boot.
# Does not delete. Does not type passwords. OAuth is handler/structure only.
set -uo pipefail
APP="${NEUOS_APP:-$HOME/neuOS}"
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/osneu/boot-proof"
BOOT_ID="$(tr -d - < /proc/sys/kernel/random/boot_id 2>/dev/null | cut -c1-8)"
STAMP="$(date +%Y%m%dT%H%M%S)"
DIR="$STATE/runs/${STAMP}-${BOOT_ID:-noid}"
mkdir -p "$DIR" "$STATE"
REPORT="$DIR/report.txt"
JSON="$DIR/checks.jsonl"
: > "$REPORT"
: > "$JSON"

pass=0; fail=0; unknown=0
row() {
  local name="$1" status="$2" detail="$3"
  printf '%s\n' "{\"t\":\"$(date -Is)\",\"name\":\"$name\",\"status\":\"$status\",\"detail\":$(printf '%s' "$detail" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')}" >> "$JSON"
  printf '%-12s %-8s %s\n' "$name" "$status" "$detail" >> "$REPORT"
  case "$status" in
    PASS) pass=$((pass+1)) ;;
    FAIL) fail=$((fail+1)) ;;
    *) unknown=$((unknown+1)) ;;
  esac
}

{
  echo "os.neu boot proof check · $(date -Is)"
  echo "host=$(hostname) user=$(id -un) uid=$(id -u) boot_id=$BOOT_ID"
  echo "app=$APP"
  echo "WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-} DISPLAY=${DISPLAY:-} XDG_SESSION_TYPE=${XDG_SESSION_TYPE:-}"
  echo
} >> "$REPORT"

# Wait up to 90s for Electron / Wayland
for i in $(seq 1 90); do
  if pgrep -u "$(id -u)" -x electron >/dev/null 2>&1 || pgrep -u "$(id -u)" -f 'electron.*neuOS' >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

# Screen / compositor
if pgrep -u "$(id -u)" -x sway >/dev/null 2>&1; then
  row screen PASS "sway running pid=$(pgrep -u "$(id -u)" -x sway | tr '\n' ' ')"
elif pgrep -u "$(id -u)" -x cage >/dev/null 2>&1; then
  row screen PASS "cage running"
else
  row screen FAIL "neither sway nor cage"
fi
if pgrep -u "$(id -u)" -f 'electron' >/dev/null 2>&1; then
  row electron PASS "electron present"
else
  row electron FAIL "electron not running after wait"
fi

# Network
if ping -c1 -W2 1.1.1.1 >/dev/null 2>&1; then
  row network_icmp PASS "1.1.1.1 reachable"
else
  row network_icmp FAIL "1.1.1.1 unreachable"
fi
code="$(curl -fsS -o /dev/null -w '%{http_code}' --max-time 10 -A 'Mozilla/5.0 os.neu-boot-proof' https://os.neuavenue.com/ 2>/dev/null || echo 000)"
if [[ "$code" == "200" || "$code" == "301" || "$code" == "302" || "$code" == "307" ]]; then
  row network_http PASS "os.neuavenue.com HTTP $code"
else
  row network_http FAIL "os.neuavenue.com HTTP $code"
fi

# Audio (PipeWire via wpctl; needs session bus in kiosk)
if command -v wpctl >/dev/null 2>&1; then
  if wpctl status >/tmp/osneu-wpctl.$$ 2>&1; then
    if grep -qiE 'sinks|audio| Speakers|Headphones' /tmp/osneu-wpctl.$$; then
      row audio PASS "wpctl status has audio graph"
    else
      row audio UNKNOWN "wpctl ran but no sink lines seen"
    fi
  else
    row audio FAIL "wpctl status failed"
  fi
  rm -f /tmp/osneu-wpctl.$$
else
  row audio UNKNOWN "wpctl missing"
fi

# Input method
if pgrep -u "$(id -u)" -x fcitx5 >/dev/null 2>&1; then
  row ime PASS "fcitx5 running"
else
  row ime FAIL "fcitx5 not running (Hangul path needs it on sway)"
fi
if [[ -s "${XDG_CONFIG_HOME:-$HOME/.config}/osneu-kiosk/fcitx5/profile" ]] || [[ -s "$HOME/.config/osneu-kiosk/fcitx5/profile" ]]; then
  row ime_profile PASS "fcitx5 profile present under osneu-kiosk"
else
  row ime_profile UNKNOWN "no osneu-kiosk fcitx5 profile yet"
fi

# OAuth — structure only (no credentials)
proto="$(xdg-mime query default x-scheme-handler/osneu 2>/dev/null || true)"
if [[ "$proto" == *osneu* || "$proto" == *neuos* ]]; then
  row oauth_handler PASS "x-scheme-handler/osneu → $proto"
else
  row oauth_handler FAIL "osneu protocol handler unset ($proto)"
fi
if grep -q "setAsDefaultProtocolClient" "$APP/electron/main.cjs" 2>/dev/null; then
  row oauth_code PASS "electron registers protocol client"
else
  row oauth_code FAIL "protocol client missing in main.cjs"
fi
row oauth_login UNKNOWN "full Google sign-in not automated (no password typed)"

# Sandbox / user
helper="$APP/node_modules/electron/dist/chrome-sandbox"
if [[ -u "$helper" && "$(stat -c %u "$helper" 2>/dev/null)" = 0 ]]; then
  row sandbox PASS "chrome-sandbox root setuid"
else
  row sandbox FAIL "chrome-sandbox not root setuid"
fi
if [[ "$(id -u)" != 0 ]]; then
  row user PASS "kiosk user $(id -un) not root"
else
  row user FAIL "running as root"
fi

# Recovery controls present in session
if pgrep -u "$(id -u)" -x sway >/dev/null 2>&1; then
  if grep -q 'Ctrl+Alt+Shift+e' "${XDG_CONFIG_HOME:-$HOME/.config}/osneu-kiosk/sway/config" 2>/dev/null \
    || grep -q 'Ctrl+Alt+Shift+e' "$HOME/.config/osneu-kiosk/sway/config" 2>/dev/null; then
    row recovery_keys PASS "sway exit bind present"
  else
    row recovery_keys UNKNOWN "sway config bind not found"
  fi
else
  row recovery_keys PASS "cage -s keeps VT switch (Ctrl+Alt+Fn)"
fi

{
  echo
  echo "SUMMARY pass=$pass fail=$fail unknown=$unknown"
} >> "$REPORT"

# Publish latest pointers (non-empty overwrite)
printf '%s\n' "$DIR" > "$STATE/LAST_RUN"
printf 'pass=%s\nfail=%s\nunknown=%s\nstamp=%s\nboot_id=%s\n' "$pass" "$fail" "$unknown" "$STAMP" "$BOOT_ID" > "$STATE/LAST_SUMMARY"
# Signal for root advance script
printf '%s\n' "$DIR" > "$STATE/READY_FOR_ADVANCE"
echo "$DIR"
exit 0
