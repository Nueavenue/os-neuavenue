#!/usr/bin/env bash
# Open the os.neu screen (fullscreen Electron).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

complete_tree() {
  local dir="$1"
  [[ -f "$dir/electron/main.cjs" && -f "$dir/package.json" && -f "$dir/index.html" ]]
}

if ! complete_tree "$ROOT"; then
  for cand in "${NEUOS_EXEC_ROOT:-}" "$HOME/neuOS" /opt/neuos; do
    [[ -n "${cand:-}" && -d "$cand" ]] || continue
    if complete_tree "$cand"; then
      echo "os.neu: $ROOT is missing electron/main.cjs. Opening from $cand" >&2
      ROOT="$cand"
      break
    fi
  done
fi
if ! complete_tree "$ROOT"; then
  echo "os.neu: Electron app is not in $ROOT (missing electron/main.cjs)." >&2
  echo "This folder is not a full plant. From Ubuntu: bash ~/neuOS/scripts/open-neuos.sh" >&2
  exit 1
fi

cd "$ROOT"
ulimit -n 65536 2>/dev/null || true
PORT="${PORT:-5173}"
BRIDGE_PORT="${NEUOS_BRIDGE_PORT:-4178}"
export NEUOS_DRIVER=live
export NEUOS_SCREEN=1
GO="${NEUOS_GO:-}"
if [[ -n "$GO" ]]; then
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}/?go=${GO}"
else
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}"
fi

OWNED_PIDS=()
cleanup() {
  if ((${#OWNED_PIDS[@]})); then
    kill "${OWNED_PIDS[@]}" 2>/dev/null || true
  fi
}
trap cleanup EXIT

healthy() {
  curl -sf "$1" >/dev/null
}

port_listen() {
  local port="$1"
  if command -v ss >/dev/null; then
    ss -ltn "sport = :${port}" 2>/dev/null | grep -q ":${port}"
  else
    lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
  fi
}

explain_busy() {
  local port="$1"
  echo "OS-NEU-SX-001  Port ${port} is in use but not serving os.neu. Stop that process and retry:" >&2
  lsof -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || ss -ltnp "sport = :${port}" || true
}

start_or_reuse() {
  local url="$1"
  local port="$2"
  shift 2
  if healthy "$url"; then
    echo "reusing ${url}"
    return 0
  fi
  if port_listen "$port"; then
    explain_busy "$port"
    exit 1
  fi
  "$@" &
  OWNED_PIDS+=("$!")
}

start_or_reuse "http://127.0.0.1:${BRIDGE_PORT}/api/health" "$BRIDGE_PORT" \
  npx tsx server/index.ts
start_or_reuse "http://127.0.0.1:${PORT}" "$PORT" \
  npx vite --host 127.0.0.1 --port "$PORT" --strictPort

for _ in $(seq 1 80); do
  if healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" && healthy "http://127.0.0.1:${PORT}"; then
    break
  fi
  sleep 0.2
done

if ! healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" || ! healthy "http://127.0.0.1:${PORT}"; then
  echo "OS-NEU-SX-002  os.neu bridge/UI did not become ready on ${BRIDGE_PORT}/${PORT}" >&2
  exit 1
fi

# Keep the window in front of the terminal that launched it.
export ELECTRON_OZONE_PLATFORM_HINT="${ELECTRON_OZONE_PLATFORM_HINT:-auto}"
echo "Opening the os.neu window. This terminal waits until you close that window (×)."
LOG=/tmp/osneu-electron.log
started_at="$(date +%s)"
set +e
npx electron . --no-sandbox --disable-gpu-sandbox 2>"$LOG"
st=$?
set -e
elapsed=$(( $(date +%s) - started_at ))
if [[ "$st" -ne 0 ]]; then
  echo "Electron exited ${st}. Last lines from ${LOG}:" >&2
  tail -n 30 "$LOG" >&2 || true
  exit "$st"
fi
if [[ "$elapsed" -lt 3 ]]; then
  echo "The window closed in ${elapsed}s. That is not a successful screen. Log: ${LOG}" >&2
  tail -n 30 "$LOG" >&2 || true
  exit 1
fi
