#!/usr/bin/env bash
# Open the os.neu screen (fullscreen Electron).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
ulimit -n 65536 2>/dev/null || true
PORT="${PORT:-5173}"
BRIDGE_PORT="${NEUOS_BRIDGE_PORT:-4178}"
export NEUOS_DRIVER=live
export NEUOS_SCREEN=1
GO="${NEUOS_GO:-}"
if [[ -n "$GO" ]]; then
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}/?go=${GO}"
else
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}"
fi

OWNED_PIDS=()
cleanup() {
  if ((${#OWNED_PIDS[@]})); then
    kill "${OWNED_PIDS[@]}" 2>/dev/null || true
  fi
}
trap cleanup EXIT

healthy() {
  curl -sf "$1" >/dev/null
}

port_listen() {
  local port="$1"
  if command -v ss >/dev/null; then
    ss -ltn "sport = :${port}" 2>/dev/null | grep -q ":${port}"
  else
    lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
  fi
}

explain_busy() {
  local port="$1"
  echo "Port ${port} is in use but not serving os.neu. Stop that process and retry:" >&2
  lsof -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || ss -ltnp "sport = :${port}" || true
}

start_or_reuse() {
  local url="$1"
  local port="$2"
  shift 2
  if healthy "$url"; then
    echo "reusing ${url}"
    return 0
  fi
  if port_listen "$port"; then
    explain_busy "$port"
    exit 1
  fi
  "$@" &
  OWNED_PIDS+=("$!")
}

start_or_reuse "http://127.0.0.1:${BRIDGE_PORT}/api/health" "$BRIDGE_PORT" \
  npx tsx server/index.ts
start_or_reuse "http://127.0.0.1:${PORT}" "$PORT" \
  npx vite --host 127.0.0.1 --port "$PORT" --strictPort

for _ in $(seq 1 80); do
  if healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" && healthy "http://127.0.0.1:${PORT}"; then
    break
  fi
  sleep 0.2
done

if ! healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" || ! healthy "http://127.0.0.1:${PORT}"; then
  echo "os.neu bridge/UI did not become ready on ${BRIDGE_PORT}/${PORT}" >&2
  exit 1
fi

# --no-sandbox covers npm Electron without a root-owned chrome-sandbox helper.
npx electron . --no-sandbox --disable-gpu-sandbox
