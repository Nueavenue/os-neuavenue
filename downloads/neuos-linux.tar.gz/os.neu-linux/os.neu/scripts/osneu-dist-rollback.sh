#!/usr/bin/env bash
# Restore dist-web index (+ hashed assets if missing) from a prior snapshot.
# Add-only for assets: never deletes other hashed files. No GRUB / reboot.
set -euo pipefail
APP="${NEUOS_APP:-$HOME/neuOS}"
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/osneu"
SNAP_ROOT="$STATE/dist-snapshots"
STAMP="${1:-}"

die() { echo "FAIL: $*" >&2; exit 1; }

[[ "$(id -u)" != 0 ]] || die "run as the kiosk user, not root"
[[ -n "$STAMP" ]] || die "usage: $0 <snapshot-stamp|LATEST>"
[[ "$STAMP" = LATEST ]] && STAMP="$(cat "$SNAP_ROOT/LATEST" 2>/dev/null || true)"
[[ -n "$STAMP" ]] || die "no LATEST snapshot"
SRC="$SNAP_ROOT/$STAMP"
[[ -s "$SRC/index.html" && -s "$SRC/info.txt" ]] || die "snapshot missing: $SRC"

js="$(sed -n 's/^js=//p' "$SRC/info.txt" | head -1)"
css="$(sed -n 's/^css=//p' "$SRC/info.txt" | head -1)"
[[ -n "$js" && -s "$SRC/assets/$js" ]] || die "snapshot js missing"

mkdir -p "$APP/dist-web/assets"
# Copy asset if absent or different; do not remove others.
if [[ ! -s "$APP/dist-web/assets/$js" ]] || ! cmp -s "$SRC/assets/$js" "$APP/dist-web/assets/$js"; then
  cp -a "$SRC/assets/$js" "$APP/dist-web/assets/$js"
fi
if [[ -n "$css" && -s "$SRC/assets/$css" ]]; then
  if [[ ! -s "$APP/dist-web/assets/$css" ]] || ! cmp -s "$SRC/assets/$css" "$APP/dist-web/assets/$css"; then
    cp -a "$SRC/assets/$css" "$APP/dist-web/assets/$css"
  fi
fi

tmp="$(mktemp /tmp/osneu-index.XXXXXX)"
cp -a "$SRC/index.html" "$tmp"
[[ -s "$tmp" ]] || die "refusing empty index"
chmod --reference="$APP/dist-web/index.html" "$tmp" 2>/dev/null || chmod 644 "$tmp"
mv -f "$tmp" "$APP/dist-web/index.html"
[[ -s "$APP/dist-web/index.html" ]] || die "index empty after restore"

echo "restored dist-web → $STAMP (js=$js)"
grep -E 'script src|assets/index' "$APP/dist-web/index.html" || true
