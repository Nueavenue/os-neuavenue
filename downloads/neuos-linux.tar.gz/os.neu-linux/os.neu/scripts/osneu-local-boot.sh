#!/usr/bin/env bash
# os.neu local boot (phase 0): add a GRUB "os.neu" entry on this PC's own
# Ubuntu that boots straight into a cage + os.neu kiosk. No partitioning, no
# disk writes outside /etc and /boot/grub/grub.cfg; the Ubuntu entry stays.
#
#   bash scripts/osneu-local-boot.sh                     plan only (default)
#   sudo bash scripts/osneu-local-boot.sh --apply         install
#   sudo bash scripts/osneu-local-boot.sh --apply --default-osneu
#   sudo bash scripts/osneu-local-boot.sh --revert        hide the entry again
#
# --revert never deletes: it clears the exec bit on the GRUB script and turns
# the GRUB drop-in into a comment. The systemd units stay but only run when the
# os.neu kernel argument asks for osneu-kiosk.target.
set -euo pipefail

MODE=plan
DEFAULT_OSNEU=0
for a in "$@"; do
  case "$a" in
    --plan) MODE=plan ;;
    --apply) MODE=apply ;;
    --revert) MODE=revert ;;
    --default-osneu) DEFAULT_OSNEU=1 ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

MARK="# os.neu local boot (scripts/osneu-local-boot.sh)"
D="${OSNEU_DESTDIR:-}"
KUSER="${OSNEU_USER:-${SUDO_USER:-$(id -un)}}"
KHOME="$(getent passwd "$KUSER" 2>/dev/null | cut -d: -f6 || true)"
[[ -n "$KHOME" ]] || KHOME="/home/$KUSER"
APP="${NEUOS_APP:-$KHOME/neuOS}"
# When OSNEU_DESTDIR is set, file checks use the staged tree (factory dry-run).
APP_CHECK="$APP"
[[ -n "$D" ]] && APP_CHECK="$D$APP"
ROOT_UUID="${OSNEU_ROOT_UUID:-$(findmnt -no UUID / 2>/dev/null || true)}"
[[ -n "$ROOT_UUID" ]] || ROOT_UUID="$(blkid -s UUID -o value "$(findmnt -no SOURCE /)" 2>/dev/null || true)"

KARGS="quiet"
# Opt-in: hide kernel and systemd status text as well (OSNEU_QUIET_BOOT=1).
if [[ "${OSNEU_QUIET_BOOT:-0}" == 1 ]]; then
  KARGS="quiet loglevel=3 systemd.show_status=false rd.systemd.show_status=false rd.udev.log_level=3 udev.log_level=3 vt.global_cursor_default=0"
fi
# Kiosk session extras: sway + fcitx5 give input methods (Hangul) and a
# per-monitor layout; without them osneu-local-kiosk.sh falls back to cage.
APT_KIOSK="sway swaybg foot fcitx5 fcitx5-hangul fcitx5-frontend-gtk3"
APT_OPTIONAL="fcitx5-mozc fcitx5-chinese-addons fcitx5-chewing fcitx5-unikey"

GRUB_SCRIPT="$D/etc/grub.d/42_osneu"
GRUB_CFG_DROPIN="$D/etc/default/grub.d/90-osneu.cfg"
TARGET_UNIT="$D/etc/systemd/system/osneu-kiosk.target"
SERVICE_UNIT="$D/etc/systemd/system/osneu-kiosk.service"

grub_script() {
  cat <<EOF
#!/bin/sh
$MARK
# Same kernel and initrd as Ubuntu; systemd starts osneu-kiosk.target instead
# of the desktop. "splash" is left out so plymouth does not hold the screen;
# the rest keeps kernel and systemd status text off the console.
cat <<'MENU'
menuentry 'os.neu' --class osneu --class os {
	insmod part_gpt
	insmod ext2
	search --no-floppy --fs-uuid --set=root $ROOT_UUID
	linux /boot/vmlinuz root=UUID=$ROOT_UUID ro $KARGS systemd.unit=osneu-kiosk.target
	initrd /boot/initrd.img
}
MENU
EOF
}

grub_dropin() {
  echo "$MARK"
  echo "GRUB_TIMEOUT_STYLE=menu"
  echo "GRUB_TIMEOUT=10"
  if [[ "$DEFAULT_OSNEU" == 1 ]]; then
    echo "GRUB_DEFAULT='os.neu'"
  fi
}

grub_dropin_disabled() {
  echo "$MARK"
  echo "# disabled by --revert $(date -Is); Ubuntu menu settings come from /etc/default/grub again."
}

target_unit() {
  cat <<EOF
$MARK
[Unit]
Description=os.neu kiosk boot (GRUB os.neu entry)
Requires=multi-user.target osneu-kiosk.service
After=multi-user.target
Conflicts=rescue.service rescue.target display-manager.service
AllowIsolate=yes
EOF
}

service_unit() {
  cat <<EOF
$MARK
[Unit]
Description=os.neu kiosk (sway or cage + Electron) on tty7
After=systemd-user-sessions.service plymouth-quit.service plymouth-quit-wait.service network-online.target
Wants=network-online.target
Conflicts=getty@tty7.service
StartLimitIntervalSec=120
StartLimitBurst=3

[Service]
Type=simple
User=$KUSER
PAMName=login
TTYPath=/dev/tty7
TTYReset=yes
TTYVHangup=yes
TTYVTDisallocate=yes
StandardInput=tty-fail
StandardOutput=journal
StandardError=journal
UtmpIdentifier=tty7
UtmpMode=user
ExecStartPre=+/usr/bin/chvt 7
ExecStart=$APP/scripts/osneu-local-kiosk.sh
ExecStopPost=+/usr/bin/chvt 1
Restart=on-failure
RestartSec=5
EOF
}

problems=()
check() { if ! eval "$2"; then problems+=("$1"); fi; }

preflight() {
  check "root filesystem UUID not found" '[[ -n "$ROOT_UUID" ]]'
  if [[ -z "$D" ]]; then
    check "kiosk user '$KUSER' has no home" '[[ -n "$KHOME" && -d "$KHOME" ]]'
    check "/boot/vmlinuz missing" '[[ -e /boot/vmlinuz ]]'
    check "/boot/initrd.img missing" '[[ -e /boot/initrd.img ]]'
    check "neither sway nor cage installed" '[[ -x /usr/bin/sway || -x /usr/bin/cage ]]'
    check "chvt missing (/usr/bin/chvt)" '[[ -x /usr/bin/chvt ]]'
  else
    check "DESTDIR app missing $APP_CHECK" '[[ -d "$APP_CHECK" ]]'
  fi
  check "electron missing in $APP_CHECK/node_modules" '[[ -x "$APP_CHECK/node_modules/electron/dist/electron" ]]'
  check "$APP_CHECK/dist-web missing (npm run build)" '[[ -f "$APP_CHECK/dist-web/index.html" ]]'
  check "$APP_CHECK/dist-bridge missing (npm run bundle:bridge)" '[[ -d "$APP_CHECK/dist-bridge" ]]'
  check "$APP_CHECK/scripts/osneu-local-kiosk.sh not executable" '[[ -x "$APP_CHECK/scripts/osneu-local-kiosk.sh" ]]'
  local f
  for f in "$GRUB_SCRIPT" "$GRUB_CFG_DROPIN" "$TARGET_UNIT" "$SERVICE_UNIT"; do
    if [[ -e "$f" ]] && ! grep -qF "$MARK" "$f"; then
      problems+=("$f exists and was not written by this script — refusing to overwrite")
    fi
  done
}

show() {
  echo "----- $1"
  "$2"
}

# Same-path write that refuses to leave an empty file behind.
put() {
  local path="$1" mode="$2" gen="$3" tmp
  mkdir -p "$(dirname "$path")"
  tmp="$(mktemp "$(dirname "$path")/.osneu.XXXXXX")"
  "$gen" > "$tmp"
  if [[ ! -s "$tmp" ]]; then
    echo "FAIL: generated $path is empty" >&2
    return 1
  fi
  chmod "$mode" "$tmp"
  mv -f "$tmp" "$path"
  echo "wrote $path ($(stat -c%s "$path") bytes)"
}

run_sys() {
  if [[ -n "$D" ]]; then
    echo "(OSNEU_DESTDIR set, skipped) $*"
  else
    "$@"
  fi
}

need_root() {
  if [[ -z "$D" && "$EUID" -ne 0 ]]; then
    echo "--$MODE changes /etc and grub.cfg: run with sudo" >&2
    exit 1
  fi
}

case "$MODE" in
  plan)
    preflight
    echo "os.neu local boot — PLAN (nothing written)"
    echo "kiosk user: $KUSER   app: $APP   root UUID: ${ROOT_UUID:-?}"
    echo "GRUB default after apply: $([[ "$DEFAULT_OSNEU" == 1 ]] && echo os.neu || echo 'unchanged (Ubuntu)')"
    echo "Disks: no partition, format or mount change."
    show "$GRUB_SCRIPT (0755)" grub_script
    show "$GRUB_CFG_DROPIN (0644)" grub_dropin
    show "$TARGET_UNIT (0644)" target_unit
    show "$SERVICE_UNIT (0644)" service_unit
    echo "----- then: systemctl daemon-reload; update-grub; check grub.cfg has menuentry 'os.neu'"
    missing=()
    for p in $APT_KIOSK; do
      dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing+=("$p")
    done
    if ((${#missing[@]})); then
      echo "RECOMMENDED (not a blocker; without these the kiosk uses cage, no Hangul input):"
      echo "  sudo apt install ${missing[*]}"
      echo "  optional input methods: sudo apt install $APT_OPTIONAL"
    else
      echo "kiosk packages: sway + fcitx5 installed"
    fi
    if ((${#problems[@]})); then
      printf 'BLOCKER: %s\n' "${problems[@]}"
      exit 1
    fi
    echo "preflight OK. Apply with: sudo bash $0 --apply$([[ "$DEFAULT_OSNEU" == 1 ]] && echo ' --default-osneu')"
    ;;
  apply)
    need_root
    preflight
    if ((${#problems[@]})); then
      printf 'BLOCKER: %s\n' "${problems[@]}" >&2
      exit 1
    fi
    put "$TARGET_UNIT" 0644 target_unit
    put "$SERVICE_UNIT" 0644 service_unit
    put "$GRUB_CFG_DROPIN" 0644 grub_dropin
    put "$GRUB_SCRIPT" 0755 grub_script
    run_sys systemctl daemon-reload
    run_sys update-grub
    if [[ -z "$D" ]]; then
      if grep -q "menuentry 'os.neu'" /boot/grub/grub.cfg; then
        echo "grub.cfg has the os.neu entry. Reboot and pick 'os.neu' in the menu (10 s)."
      else
        echo "FAIL: /boot/grub/grub.cfg has no os.neu entry after update-grub" >&2
        exit 1
      fi
    fi
    ;;
  revert)
    need_root
    for f in "$GRUB_SCRIPT" "$GRUB_CFG_DROPIN"; do
      if [[ -e "$f" ]] && ! grep -qF "$MARK" "$f"; then
        echo "$f was not written by this script — leaving it alone" >&2
        exit 1
      fi
    done
    [[ -e "$GRUB_SCRIPT" ]] && chmod 0644 "$GRUB_SCRIPT" && echo "cleared exec bit on $GRUB_SCRIPT"
    [[ -e "$GRUB_CFG_DROPIN" ]] && put "$GRUB_CFG_DROPIN" 0644 grub_dropin_disabled
    run_sys update-grub
    if [[ -z "$D" ]] && grep -q "menuentry 'os.neu'" /boot/grub/grub.cfg; then
      echo "FAIL: os.neu entry still in grub.cfg" >&2
      exit 1
    fi
    echo "os.neu entry hidden. Files kept: $GRUB_SCRIPT $SERVICE_UNIT $TARGET_UNIT"
    ;;
esac
