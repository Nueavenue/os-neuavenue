#!/usr/bin/env bash
# Print DPRK-nexus supply-chain search routes and grep local lockfiles.
# Read-only. Does not download payloads or visit C2 hosts.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IOC="$ROOT/docs/watchlists/dprk-supply-iocs.txt"
MODE="all"
SCAN_HOME=0

usage() {
  cat <<EOF
Watch UNC1069 / Lazarus-adjacent software supply chain (names and public intel only).

  bash scripts/watch-dprk-supply.sh           print search URLs, then scan this repo
  bash scripts/watch-dprk-supply.sh --urls    search routes only
  bash scripts/watch-dprk-supply.sh --scan    lockfile / tree grep only
  bash scripts/watch-dprk-supply.sh --home    also scan ~/os.neu and sibling apps

Docs: docs/dprk-supply-watch.md
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --urls) MODE="urls"; shift ;;
    --scan) MODE="scan"; shift ;;
    --home) SCAN_HOME=1; shift ;;
    *) echo "unknown arg: $1" >&2; usage; exit 2 ;;
  esac
done

print_urls() {
  cat <<'EOF'
== weekly search routes (open in a browser; do not curl C2 hosts) ==

1. Google · UNC1069 axios
   https://www.google.com/search?q=UNC1069+axios+npm+WAVESHAPER

2. Google · Contagious Interview npm
   https://www.google.com/search?q=%22Contagious+Interview%22+npm+BeaverTail

3. Google · CISA DPRK
   https://www.google.com/search?q=site%3Acisa.gov+Lazarus+OR+AppleJeus+OR+TraderTraitor+OR+%223CX%22

4. Mandiant / GTIG cluster
   https://www.google.com/search?q=site%3Acloud.google.com+OR+site%3Amandiant.com+UNC1069+OR+%22Sapphire+Sleet%22

5. Microsoft Sapphire Sleet
   https://www.google.com/search?q=site%3Amicrosoft.com+%22Sapphire+Sleet%22+OR+%22CageyChameleon%22

6. Socket Contagious Interview
   https://socket.dev/blog?q=Contagious%20Interview

7. OSV malware · axios
   https://osv.dev/list?q=axios%20MAL

8. OSV · plain-crypto-js
   https://osv.dev/list?q=plain-crypto-js

9. GitHub Advisory · axios embedded malware
   https://github.com/advisories?query=axios+malware

10. OpenSSF malicious packages (living list)
    https://github.com/ossf/malicious-packages

11. CISA AppleJeus (fake trading apps)
    https://www.cisa.gov/news-events/cybersecurity-advisories/aa21-048a

12. CISA TraderTraitor (blockchain firms)
    https://www.cisa.gov/news-events/cybersecurity-advisories/aa22-108a

13. CISA 3CX Desktop App supply chain
    https://www.cisa.gov/news-events/alerts/2023/03/30/supply-chain-attack-against-3cxdesktopapp

14. CISA North Korea page
    https://www.cisa.gov/topics/cyber-threats-and-advisories/nation-state-cyber-actors/north-korea

15. MITRE Lazarus G0032
    https://attack.mitre.org/groups/G0032/

16. MITRE APT38 G0082 (WannaCry / bank heists)
    https://attack.mitre.org/groups/G0082/

17. CSA note · axios / UNC1069
    https://labs.cloudsecurityalliance.org/research/csa-research-note-unc1069-axios-npm-supply-chain-20260403-cs/

18. CSA note · five ecosystems
    https://labs.cloudsecurityalliance.org/research/csa-research-note-dprk-contagious-interview-cross-ecosystem/

== paste-ready Google queries ==
"UNC1069" (WAVESHAPER OR "plain-crypto-js" OR axios)
"Contagious Interview" (BeaverTail OR InvisibleFerret OR OtterCookie)
"BlueNoroff" (RustBucket OR webT OR AppleJeus)
typosquat (loadash-lint OR formmiderable OR sequelization) npm
site:socket.dev (HexEval OR XORIndex) npm
EOF
}

scan_tree() {
  local dir="$1"
  local hits=0
  echo "-- $dir"
  if [[ ! -d "$dir" ]]; then
    echo "   skip (missing)"
    return 0
  fi

  local locks=()
  while IFS= read -r f; do
    locks+=("$f")
  done < <(find "$dir" -maxdepth 3 \( \
    -name package-lock.json -o -name package.json -o -name yarn.lock \
    -o -name pnpm-lock.yaml -o -name requirements.txt -o -name go.mod \
    -o -name Cargo.lock -o -name composer.lock -o -name Pipfile.lock \
  \) ! -path '*/node_modules/*' 2>/dev/null)

  if [[ ${#locks[@]} -eq 0 ]]; then
    echo "   no lockfiles in the first three levels"
  fi

  local name eco
  while IFS=$'\t' read -r eco name; do
    [[ -z "${eco:-}" || "$eco" == \#* ]] && continue
    [[ -z "${name:-}" ]] && continue
    for f in "${locks[@]:-}"; do
      [[ -f "$f" ]] || continue
      if grep -F -q -- "$name" "$f" 2>/dev/null; then
        echo "   HIT  $name  ($eco)  in  $f"
        hits=$((hits + 1))
      fi
    done
    if [[ -d "$dir/node_modules/${name}" ]]; then
      echo "   HIT  node_modules/$name"
      hits=$((hits + 1))
    fi
  done < "$IOC"

  for ver in '1.14.1' '0.30.4'; do
    for f in "${locks[@]:-}"; do
      [[ -f "$f" ]] || continue
      if grep -n 'node_modules/axios' "$f" >/dev/null 2>&1; then
        if awk -v ver="$ver" '
          /node_modules\/axios"/ {p=1}
          p && /"version"/ { if (index($0, ver)) found=1; p=0 }
          END { exit found ? 0 : 1 }
        ' "$f"; then
          echo "   HIT  axios@$ver  in  $f"
          hits=$((hits + 1))
        fi
      fi
    done
  done

  if [[ -e /tmp/ld.py ]]; then
    echo "   HIT  host IoC /tmp/ld.py (Linux dropper from plain-crypto-js campaign)"
    hits=$((hits + 1))
  fi

  if [[ "$hits" -eq 0 ]]; then
    echo "   clean vs this watchlist"
  fi
  return 0
}

if [[ "$MODE" == "all" || "$MODE" == "urls" ]]; then
  print_urls
  echo
fi

if [[ "$MODE" == "all" || "$MODE" == "scan" ]]; then
  echo "== local scan (watchlist $(grep -c $'^[a-z]' "$IOC" || true) names) =="
  scan_tree "$ROOT"
  if [[ "$SCAN_HOME" == 1 ]]; then
    home="${HOME:-/home/billy-lee}"
    scan_tree "$home/os.neu"
    scan_tree "$home/resume.ai"
    scan_tree "$home/instagram.ai"
    scan_tree "$home/cursor-landing-page"
    scan_tree "$home/linktree"
  fi
  echo
  echo "A HIT is a name match, not proof of infection. Open the file and check the version."
  echo "Full living lists: OpenSSF malicious-packages and Socket Contagious Interview posts."
fi
