#!/usr/bin/env npx tsx
/**
 * Live check: TTS clip → ASR transcript → coach reply.
 * Does not print secrets. Exit 0 if the round-trip works.
 */
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadLocalEnv } from '../server/env.ts'
import { coachChat, speakReady } from '../server/speak.ts'
import { transcribeUtterance } from '../server/transcribe.ts'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
loadLocalEnv(ROOT)

async function main() {
  if (!speakReady()) {
    console.log('speak: off (no key) — skip live round-trip')
    process.exit(2)
  }

  const spoken = 'Hello. My name is Billy.'
  const first = await coachChat(
    `Reply with only this sentence, nothing else: ${spoken}`,
  )
  if (!first.reply.trim()) {
    console.log('coach: empty reply')
    process.exit(1)
  }
  console.log('coach: ok', first.audio ? 'with-audio' : 'text-only', 'chars', first.reply.length)

  let heard = ''
  if (first.audio?.data) {
    const buf = Buffer.from(first.audio.data, 'base64')
    heard = await transcribeUtterance(buf, `audio/${first.audio.format || 'wav'}`)
    console.log('asr: chars', heard.length, 'hello', /hello/i.test(heard))
    if (!heard.trim()) {
      console.log('asr: empty transcript')
      process.exit(1)
    }
  } else {
    heard = spoken
    console.log('asr: skipped (no wav); using the spoken line')
  }

  const second = await coachChat(heard, [
    { role: 'user', content: spoken },
    { role: 'assistant', content: first.reply },
  ])
  if (!second.reply.trim()) {
    console.log('turn-2: empty reply')
    process.exit(1)
  }
  console.log('turn-2: ok chars', second.reply.length)
  console.log('talk-listen: pass')
}

main().catch((err) => {
  console.log('talk-listen: fail', err instanceof Error ? err.message : 'error')
  process.exit(1)
})
