#!/usr/bin/env node
// JeOS input diagnosis. Read-only toward devices: never EVIOCGRAB, never writes /dev/input.
// Stages kept apart: kernel registration → event node → compositor/libinput → real events → app.
// The only write outside /tmp is the NEUOS-ESP log folder (Leader grant 2026-10-27).
//
//   node input-diag.mjs snapshot <label>
//   node input-diag.mjs status
//   node input-diag.mjs watch            (long-running event counter)
//   node input-diag.mjs follow <file> <tag>
//   node input-diag.mjs esp              (copy logs to NEUOS-ESP/osneu-logs)
import fs from 'node:fs'
import { execFileSync } from 'node:child_process'

const DIAG_LOG = '/tmp/osneu-input-diag.log'
const STATUS_ENV = '/tmp/osneu-input-status.env'
const EVENTS_JSON = '/tmp/osneu-input-events.json'
const APP_JSON = '/tmp/osneu-app-input.json'
const APP_MARKS = '/tmp/osneu-app-marks.log'
const ESP_MNT = '/run/osneu-esp'
const VIRT = process.env.NEUOS_VIRT_TEST === '1'
const BOOT_TAG = process.env.NEUOS_DIAG_BOOT || String(Math.floor(Date.now() / 1000))

function emit(line, { console: toConsole = true } = {}) {
  if (toConsole) process.stdout.write(`${line}\n`)
  try {
    fs.appendFileSync(DIAG_LOG, `${line}\n`)
  } catch {
    /* /tmp missing: console still has it */
  }
  if (VIRT) {
    const tty = serialDev()
    if (tty) {
      try {
        fs.appendFileSync(tty, `${line}\n`)
      } catch {
        /* no UART on a physical stick */
      }
    }
  }
}

// Guest console from the kernel's own list, not an assumed ttyS0.
let serialCached
function serialDev() {
  if (serialCached !== undefined) return serialCached
  const active = (read('/sys/class/tty/console/active') || '').split(/\s+/)
  const name = active.find((t) => /^(ttyS\d+|ttyAMA\d+|hvc\d+)$/.test(t))
  serialCached = name ? `/dev/${name}` : fs.existsSync('/dev/ttyS0') ? '/dev/ttyS0' : null
  return serialCached
}

function read(p) {
  try {
    return fs.readFileSync(p, 'utf8').trim()
  } catch {
    return null
  }
}

function list(dir) {
  try {
    return fs.readdirSync(dir).sort((a, b) => a.localeCompare(b, 'en', { numeric: true }))
  } catch {
    return []
  }
}

// Kernel bitmaps: space-separated hex longs, most significant first, 64 bits each.
function hasBit(bitmap, bit) {
  if (!bitmap) return false
  const words = bitmap.split(/\s+/).reverse()
  const w = words[Math.floor(bit / 64)]
  if (!w) return false
  return ((BigInt(`0x${w}`) >> BigInt(bit % 64)) & 1n) === 1n
}

const EV_SYN = 0
const EV_KEY = 1
const EV_REL = 2
const EV_ABS = 3
const BTN_MISC = 0x100
const BTN_LEFT = 0x110
const BTN_TOUCH = 0x14a
const BTN_TOOL_PEN = 0x140
const BTN_STYLUS = 0x14b
const KEY_A = 30

function eventDevices() {
  return list('/sys/class/input')
    .filter((n) => /^event\d+$/.test(n))
    .map((node) => {
      const base = `/sys/class/input/${node}/device`
      const caps = {}
      for (const c of ['ev', 'key', 'rel', 'abs']) caps[c] = read(`${base}/capabilities/${c}`)
      const relXY = hasBit(caps.ev, EV_REL) && hasBit(caps.rel, 0) && hasBit(caps.rel, 1)
      const absXY = hasBit(caps.ev, EV_ABS) && hasBit(caps.abs, 0) && hasBit(caps.abs, 1)
      const button = hasBit(caps.key, BTN_LEFT) || hasBit(caps.key, BTN_TOUCH)
      const keyboard = hasBit(caps.ev, EV_KEY) && hasBit(caps.key, KEY_A)
      return {
        node,
        dev: `/dev/input/${node}`,
        devExists: fs.existsSync(`/dev/input/${node}`),
        name: read(`${base}/name`) || '?',
        caps,
        pointer: (relXY || absXY) && button,
        pointerKind: absXY ? 'ABS' : relXY ? 'REL' : '-',
        button,
        keyboard,
      }
    })
}

function kmsgLines(re) {
  const out = []
  let fd
  try {
    fd = fs.openSync('/dev/kmsg', fs.constants.O_RDONLY | fs.constants.O_NONBLOCK)
  } catch (err) {
    return [`(kmsg unreadable: ${err.code || err.message})`]
  }
  const buf = Buffer.alloc(8192)
  for (let i = 0; i < 20000; i++) {
    let n
    try {
      n = fs.readSync(fd, buf, 0, buf.length, null)
    } catch (err) {
      if (err.code === 'EAGAIN') break
      if (err.code === 'EPIPE') continue
      break
    }
    if (!n) break
    const rec = buf.toString('utf8', 0, n)
    const msg = rec.slice(rec.indexOf(';') + 1).split('\n')[0]
    if (re.test(msg)) out.push(msg)
  }
  fs.closeSync(fd)
  return out
}

function virtioBindings() {
  return list('/sys/bus/virtio/devices').map((d) => {
    const p = `/sys/bus/virtio/devices/${d}`
    let driver = '(unbound)'
    try {
      driver = fs.readlinkSync(`${p}/driver`).split('/').pop()
    } catch {
      /* unbound */
    }
    return `${d} device=${read(`${p}/device`)} vendor=${read(`${p}/vendor`)} driver=${driver}`
  })
}

function snapshot(label) {
  emit(`===== INPUT SNAPSHOT ${label} =====`)
  emit(`kernel ${read('/proc/sys/kernel/osrelease')}`)
  emit('===== KERNEL INPUT DEVICES (/proc/bus/input/devices) =====')
  for (const block of (read('/proc/bus/input/devices') || '(none)').split(/\n\s*\n/)) {
    const name = /N: Name="([^"]*)"/.exec(block)?.[1]
    const handlers = /H: Handlers=(.*)/.exec(block)?.[1]
    const ev = /B: EV=(\S+)/.exec(block)?.[1]
    if (name) emit(`  ${name} | Handlers=${handlers} | EV=${ev}`)
  }
  emit('===== EVENT NODES (sysfs vs /dev) + CAPABILITIES =====')
  for (const d of eventDevices()) {
    let sys = '?'
    try {
      sys = fs.realpathSync(`/sys/class/input/${d.node}/device`).replace(/^\/sys/, '')
    } catch {
      /* keep ? */
    }
    emit(
      `  ${d.node} dev=${d.devExists ? 'yes' : 'MISSING'} name="${d.name}" pointer=${d.pointer ? d.pointerKind : 'no'} keyboard=${d.keyboard ? 'yes' : 'no'} sysfs=${sys}`,
    )
    emit(`    ev=${d.caps.ev} key=${(d.caps.key || '').slice(-40)} rel=${d.caps.rel} abs=${d.caps.abs}`)
  }
  emit('===== VIRTIO DRIVER BINDINGS =====')
  for (const line of virtioBindings()) emit(`  ${line}`)
  emit('===== INPUT MODULES (/proc/modules) =====')
  const mods = (read('/proc/modules') || '')
    .split('\n')
    .map((l) => l.split(' ')[0])
    .filter((m) => /virtio_input|psmouse|hid|i2c_hid|evdev|serio|i8042|atkbd|lpss|mousedev/.test(m))
  emit(`  ${mods.join(' ') || '(none listed; may be built in)'}`)
  emit('===== KERNEL LOG (input|virtio|psmouse|i8042|serio|hid|evdev) =====')
  for (const line of kmsgLines(/input|virtio|psmouse|i8042|serio|hid|evdev/i).slice(-60)) emit(`  ${line}`)
}

function readEnvFile() {
  const env = {}
  for (const line of (read(STATUS_ENV) || '').split('\n')) {
    const i = line.indexOf('=')
    if (i > 0) env[line.slice(0, i)] = line.slice(i + 1)
  }
  return env
}

function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'))
  } catch {
    return null
  }
}

function procs() {
  const out = []
  for (const pid of list('/proc').filter((p) => /^\d+$/.test(p))) {
    const comm = read(`/proc/${pid}/comm`)
    if (!comm || !/^(weston|cage|seatd|electron|node|udevd|systemd-udevd|udhcpc)$/.test(comm)) continue
    const cmd = (read(`/proc/${pid}/cmdline`) || '').replace(/\0/g, ' ').trim().slice(0, 160)
    out.push({ pid: Number(pid), comm, cmd })
  }
  return out
}

function waylandSockets() {
  const dirs = [process.env.XDG_RUNTIME_DIR, '/run/osneu-wl', '/tmp/osneu-wl'].filter(Boolean)
  const found = []
  for (const d of [...new Set(dirs)]) {
    for (const f of list(d)) if (/^wayland-\d+$/.test(f)) found.push(`${d}/${f}`)
  }
  return found
}

// Leader standard 2026-10-27: "no exit log" is not "running"; "no start signal"
// is not "not started"; device-added lines are not motion.
function status() {
  const env = readEnvFile()
  const devs = eventDevices()
  const ptrs = devs.filter((d) => d.pointer)
  const kbds = devs.filter((d) => d.keyboard)
  const ev = readJson(EVENTS_JSON)
  const app = readJson(APP_JSON)
  const ps = procs()
  const comp = ps.filter((p) => p.comm === 'cage' || p.comm === 'weston')
  const electron = ps.filter((p) => p.comm === 'electron')
  const marks = (read(APP_MARKS) || '').split('\n').filter(Boolean)
  const launcher = read('/tmp/osneu-app-launcher.env')

  let motion = 0
  let btnDown = 0
  let btnUp = 0
  let keyDown = 0
  const perDev = []
  for (const d of Object.values(ev?.devices || {})) {
    if (d.pointer) {
      motion += d.MOTION || 0
      btnDown += d.BTN_DOWN || 0
      btnUp += d.BTN_UP || 0
    }
    keyDown += d.KEY_DOWN || 0
    if ((d.MOTION || 0) + (d.BTN_DOWN || 0) + (d.KEY_DOWN || 0) > 0) {
      perDev.push(`${d.node}("${d.name}") MOTION=${d.MOTION || 0} BTN_DOWN=${d.BTN_DOWN || 0} BTN_UP=${d.BTN_UP || 0} KEY_DOWN=${d.KEY_DOWN || 0}`)
    }
  }
  const evTest = !ev
    ? 'NOT_RUN'
    : motion >= 2 && btnDown >= 1
      ? `PASS ${perDev.join('; ')}`
      : `NO_PASS_YET ${perDev.join('; ') || '(no motion, button or key frames)'}`

  const appMove = app?.mouseMove || 0
  const appDown = app?.mouseDown || 0
  const appKeys = (app?.rawKeyDown || 0) + (app?.keyDown || 0)
  const appChar = app?.char || 0
  const winLoaded = marks.some((l) => l.includes('APP_WINDOW did-finish-load'))

  emit('===== os.neu INPUT STATUS =====')
  emit(`DISPLAY:              ${winLoaded ? 'APP_PAGE_LOADED (did-finish-load; host screendump decides black/not)' : marks.length ? 'APP_WINDOW_CREATED / PAGE_NOT_LOADED' : env.DISPLAY || 'NOT_RUNNING'}`)
  emit(`COMPOSITOR:           ${env.COMPOSITOR || 'UNKNOWN'}`)
  emit(`COMPOSITOR_LIVENESS:  ${comp.length ? `ALIVE ${comp.map((p) => `${p.comm} pid=${p.pid}`).join(', ')}` : 'NO_PROCESS'}`)
  emit(`ACTIVE_VT:            ${read('/sys/class/tty/tty0/active') || 'UNKNOWN'}`)
  emit(`WAYLAND_SOCKET:       ${waylandSockets().join(', ') || 'NONE_FOUND'}`)
  emit(`APP_START_SIGNAL:     ${launcher ? `LAUNCHER_ENTERED ${launcher.replace(/\n/g, ' ')}` : 'NOT_RECEIVED (not proof the app did not start)'}`)
  emit(`APP_LIVENESS:         ${electron.length ? `ALIVE electron pids=${electron.map((p) => p.pid).join(',')}` : 'NO_PROCESS'}`)
  emit(`APP_LAST_MARK:        ${marks.at(-1) || 'NONE'}`)
  emit(`KEYBOARD:             ${kbds.length ? `REGISTERED ${kbds.map((d) => `${d.node}:"${d.name}"`).join(', ')}` : 'MISSING'}`)
  emit(`POINTER:              ${ptrs.length ? `REGISTERED ${ptrs.map((d) => `${d.node}:${d.pointerKind}:"${d.name}"`).join(', ')}` : 'MISSING (kernel capabilities show no pointer)'}`)
  emit('QEMU_SELECTED_POINTER: HOST_SIDE (query-mice in the run folder input-probe.txt)')
  emit(`VIRTIO_INPUT_LOAD:    ${env.VIRTIO_INPUT_LOAD || 'UNKNOWN'}`)
  emit(`PSMOUSE_LOAD:         ${env.PSMOUSE_LOAD || 'UNKNOWN'}`)
  emit(`TOUCHPAD_LOAD:        ${env.TOUCHPAD_LOAD || 'UNKNOWN'}`)
  emit(`GPU_DRIVER:           ${env.GPU_DRIVER || 'UNKNOWN'}`)
  emit(`KMOD_LOAD:            ${env.KMOD_LOAD || 'UNKNOWN'}`)
  emit(`INPUT_EVENT_TEST:     ${evTest}`)
  emit(`KERNEL_MOTION_FRAMES: ${motion}  BUTTON_PRESS: ${btnDown}  BUTTON_RELEASE: ${btnUp}  KEY_PRESS: ${keyDown}`)
  emit(`LIBINPUT_MOTION:      ${!app ? 'UNTESTED' : appMove >= 2 ? 'PASS (inferred: compositor delivered moves to the app; no libinput CLI on JeOS)' : 'NOT_SEEN'}`)
  emit(`APP_CLICK:            ${!app ? 'UNTESTED' : appDown >= 1 ? `PASS mouseDown=${appDown}` : 'UNTESTED (no click yet)'}`)
  emit(`APP_KEYS:             ${!app ? 'UNTESTED' : appChar >= 1 ? `PASS char=${appChar} rawKeyDown=${appKeys} (valid only if a field had focus)` : 'UNTESTED'}`)
  emit(`NETWORK:              ${env.NETWORK || 'UNKNOWN'}`)
}

function watch() {
  // Button-only nodes too: VMware vmmouse reports buttons on a second node
  // without X/Y (2026-10-27 vmport=on comparison).
  const devs = eventDevices().filter((d) => (d.pointer || d.keyboard || d.button) && d.devExists)
  const counts = {}
  for (const d of devs) {
    const c = { node: d.node, name: d.name, pointer: d.pointer || d.button, MOTION: 0, BTN_DOWN: 0, BTN_UP: 0, KEY_DOWN: 0 }
    counts[d.node] = c
    let rest = Buffer.alloc(0)
    let frameMoved = false
    // Non-blocking poll, not createReadStream: each idle stream parks a libuv
    // pool thread (4 by default), so with 6+ nodes some devices were never
    // read (vmport=on run lost a key and the vmmouse button).
    let fd
    try {
      fd = fs.openSync(d.dev, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK)
    } catch (err) {
      emit(`INPUT_WATCH ${d.node} open error ${err.code || err.message}`)
      continue
    }
    const buf = Buffer.alloc(24 * 128)
    const onData = (chunk) => {
      let b = Buffer.concat([rest, chunk])
      while (b.length >= 24) {
        const type = b.readUInt16LE(16)
        const code = b.readUInt16LE(18)
        const value = b.readInt32LE(20)
        // One motion = one SYN_REPORT frame that carried X or Y. SYN/MSC and
        // key autorepeat (value 2) are never counted.
        if ((type === EV_ABS || type === EV_REL) && (code === 0 || code === 1)) frameMoved = true
        else if (type === EV_SYN && code === 0) {
          if (frameMoved) c.MOTION++
          frameMoved = false
        } else if (type === EV_KEY && code >= BTN_MISC) {
          if (value === 1) c.BTN_DOWN++
          else if (value === 0) c.BTN_UP++
        } else if (type === EV_KEY && value === 1) c.KEY_DOWN++
        b = b.subarray(24)
      }
      rest = b
    }
    const poll = setInterval(() => {
      for (;;) {
        let n
        try {
          n = fs.readSync(fd, buf, 0, buf.length, null)
        } catch (err) {
          if (err.code === 'EAGAIN') return
          emit(`INPUT_WATCH ${d.node} read error ${err.code || err.message}`)
          clearInterval(poll)
          return
        }
        if (!n) return
        onData(buf.subarray(0, n))
      }
    }, 15)
  }
  emit(`INPUT_WATCH started on ${devs.map((d) => `${d.node}(${d.name})`).join(', ') || 'no devices'}`)
  let lastSig = ''
  let lastApp = ''
  let marksSeen = 0
  let lastEsp = 0
  let dirty = true
  setInterval(() => {
    const sig = JSON.stringify(counts)
    const app = read(APP_JSON) || ''
    if (sig !== lastSig) {
      lastSig = sig
      dirty = true
      try {
        fs.writeFileSync(EVENTS_JSON, JSON.stringify({ t: Date.now(), devices: counts }))
      } catch {
        /* /tmp missing */
      }
      emit(
        `INPUT_EVENTS ${Object.values(counts)
          .filter((c) => c.MOTION + c.BTN_DOWN + c.BTN_UP + c.KEY_DOWN > 0)
          .map((c) => `${c.node}(${c.name}) MOTION=${c.MOTION} BTN_DOWN=${c.BTN_DOWN} BTN_UP=${c.BTN_UP} KEY_DOWN=${c.KEY_DOWN}`)
          .join('; ')}`,
        { console: false },
      )
    }
    const marks = (read(APP_MARKS) || '').split('\n').filter(Boolean)
    if (marks.length > marksSeen) {
      for (const l of marks.slice(marksSeen)) emit(`APP_MARK ${l}`, { console: false })
      marksSeen = marks.length
      dirty = true
    }
    if (app && app !== lastApp) {
      lastApp = app
      dirty = true
      emit(`APP_EVENTS ${app}`, { console: false })
    }
    if (dirty && Date.now() - lastEsp > 15000) {
      lastEsp = Date.now()
      dirty = false
      espCopy({ quiet: true })
    }
  }, 5000)
}

function follow(file, tag) {
  let pos = 0
  setInterval(() => {
    let st
    try {
      st = fs.statSync(file)
    } catch {
      return
    }
    if (st.size < pos) pos = 0
    if (st.size === pos) return
    const fd = fs.openSync(file, 'r')
    const buf = Buffer.alloc(st.size - pos)
    fs.readSync(fd, buf, 0, buf.length, pos)
    fs.closeSync(fd)
    pos = st.size
    for (const line of buf.toString('utf8').split('\n')) if (line.trim()) emit(`[${tag}] ${line}`, { console: false })
  }, 1000)
}

function findEsp() {
  for (const line of (read('/proc/mounts') || '').split('\n')) {
    const [dev, mnt, fstype] = line.split(' ')
    if (fstype === 'vfat' && mnt && labelOf(dev) === 'NEUOS-ESP') return { dev, mnt, mounted: true }
  }
  const byLabel = '/dev/disk/by-label/NEUOS-ESP'
  if (fs.existsSync(byLabel)) return { dev: fs.realpathSync(byLabel), mnt: ESP_MNT, mounted: false }
  for (const b of list('/sys/class/block')) {
    if (!/^(sd[a-z]+\d+|nvme\d+n\d+p\d+|mmcblk\d+p\d+)$/.test(b)) continue
    if (labelOf(`/dev/${b}`) === 'NEUOS-ESP') return { dev: `/dev/${b}`, mnt: ESP_MNT, mounted: false }
  }
  return null
}

function labelOf(dev) {
  for (const bin of ['/usr/sbin/blkid', '/usr/bin/blkid', '/sbin/blkid']) {
    if (!fs.existsSync(bin)) continue
    try {
      return execFileSync(bin, ['-o', 'value', '-s', 'LABEL', dev], { encoding: 'utf8', timeout: 3000 }).trim()
    } catch {
      return ''
    }
  }
  return ''
}

let espMissingSaid = false
function espCopy({ quiet = false } = {}) {
  const say = (l) => (quiet ? emit(l, { console: false }) : emit(l))
  // Grant covers the stick while it boots JeOS only. On an Ubuntu host a plugged
  // stick must never be mounted or written by this tool.
  if (process.env.NEUOS_JEOS !== '1') {
    say('ESP_LOG skipped: not a JeOS boot (host disks and plugged sticks are not touched)')
    return
  }
  const esp = findEsp()
  if (!esp) {
    if (!quiet || !espMissingSaid) say('ESP_LOG skipped: no NEUOS-ESP partition (virt ISO has none)')
    espMissingSaid = true
    return
  }
  if (!esp.mounted) {
    // FAT's default iocharset is a module here; cp437 is built in.
    for (const ko of ['nls_iso8859-1.ko', 'nls_utf8.ko']) {
      const p = `/opt/neuos/kmod/boot/${ko}`
      if (fs.existsSync(p)) {
        try {
          execFileSync('/usr/bin/busybox', ['insmod', p], { timeout: 5000, stdio: 'ignore' })
        } catch {}
      }
    }
    let mountErr = null
    fs.mkdirSync(esp.mnt, { recursive: true })
    for (const opts of ['rw,noatime', 'rw,noatime,iocharset=cp437']) {
      try {
        execFileSync('mount', ['-t', 'vfat', '-o', opts, esp.dev, esp.mnt], { timeout: 8000 })
        mountErr = null
        break
      } catch (err) {
        mountErr = err
      }
    }
    if (mountErr) {
      say(`ESP_LOG mount failed ${esp.dev}: ${String(mountErr.message || mountErr).split('\n')[0]}`)
      return
    }
  }
  const dir = `${esp.mnt}/osneu-logs`
  try {
    fs.mkdirSync(dir, { recursive: true })
    const parts = [DIAG_LOG, '/tmp/osneu-usb-screen-jeos.log', EVENTS_JSON, APP_JSON, APP_MARKS, '/tmp/osneu-app-launcher.env', '/tmp/osneu-electron-crash.txt', '/tmp/osneu-netdiag.log', '/tmp/osneu-netdiag.json']
    for (const f of list('/tmp')) if (/^osneu-usb-screen-jeos\.log\..+\.vt\d+$/.test(f)) parts.push(`/tmp/${f}`)
    let body = ''
    for (const p of parts) {
      const t = read(p)
      if (t != null) body += `\n######## ${p}\n${t}\n`
    }
    const out = `${dir}/input-${BOOT_TAG}.log`
    const fd = fs.openSync(out, 'w')
    fs.writeSync(fd, body)
    fs.fsyncSync(fd)
    fs.closeSync(fd)
    say(`ESP_LOG written ${esp.dev} osneu-logs/input-${BOOT_TAG}.log`)
  } catch (err) {
    say(`ESP_LOG write failed: ${err.code || err.message}`)
  }
}

// Same two URLs the landing badge uses, from Node instead of Chromium, so a
// guest network fault and a renderer/probe fault stay separate conclusions.
async function netProbe() {
  const dns = await import('node:dns/promises')
  const https = await import('node:https')
  const ifaces = list('/sys/class/net')
    .filter((n) => n !== 'lo')
    .map((n) => `${n}:${read(`/sys/class/net/${n}/operstate`) || '?'}`)
  const route = (read('/proc/net/route') || '').split('\n').some((l) => /^\S+\s+00000000\s/.test(l))
  emit(`NET_IFACES ${ifaces.join(' ') || 'none'} default_route=${route ? 'yes' : 'no'}`)
  const resolv = read('/etc/resolv.conf')
  emit(`NET_RESOLV ${resolv == null ? 'MISSING' : resolv === '' ? 'EMPTY' : resolv.replace(/\n/g, ' | ')}`)
  for (const u of ['https://www.gstatic.com/generate_204', 'https://cloudflare.com/cdn-cgi/trace']) {
    const host = new URL(u).host
    let addr = 'FAIL'
    try {
      addr = `ok ${(await dns.lookup(host)).address}`
    } catch (err) {
      addr = `FAIL ${err.code || err.message}`
    }
    const res = await new Promise((resolve) => {
      const req = https.get(u, { timeout: 4000 }, (r) => {
        r.resume()
        resolve(`HTTP ${r.statusCode}`)
      })
      req.on('timeout', () => {
        req.destroy()
        resolve('TIMEOUT')
      })
      req.on('error', (err) => resolve(`ERROR ${err.code || err.message}`))
    })
    emit(`NET_PROBE_NODE ${host} dns=${addr} https=${res}`)
  }
  const ollama = (process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').replace(/\/$/, '')
  try {
    const r = await fetch(`${ollama}/api/tags`, { signal: AbortSignal.timeout(3000) })
    const j = await r.json().catch(() => ({}))
    const names = (j.models || []).map((m) => m.name).join(',')
    emit(`LLM_LOCAL ${ollama} HTTP ${r.status} models=${names || 'none'}`)
  } catch (err) {
    emit(`LLM_LOCAL ${ollama} UNREACHABLE ${err.cause?.code || err.name || err.message}`)
  }
}

// udev labels from kernel capabilities, not from device names.
function classify(node) {
  const d = eventDevices().find((x) => x.node === node)
  if (!d) {
    process.stdout.write('kbd=0 mouse=0 tablet=0\n')
    return
  }
  // Same rule as udev input_id: ABS X/Y + BTN_LEFT without a pen tool is an
  // absolute mouse (QEMU/VMware tablet), not a tablet. ID_INPUT_TABLET sends
  // libinput down the pen path and it drops a device with no BTN_TOOL_PEN.
  const pen = hasBit(d.caps.key, BTN_TOOL_PEN) || hasBit(d.caps.key, BTN_STYLUS)
  const tablet = d.pointer && d.pointerKind === 'ABS' && pen ? 1 : 0
  process.stdout.write(`kbd=${d.keyboard ? 1 : 0} mouse=${d.pointer && !tablet ? 1 : 0} tablet=${tablet}\n`)
}

const [mode, a, b] = process.argv.slice(2)
if (mode === 'classify') classify(a)
else if (mode === 'snapshot') snapshot(a || 'now')
else if (mode === 'status') status()
else if (mode === 'watch') watch()
else if (mode === 'follow') follow(a, b || 'log')
else if (mode === 'esp') espCopy()
else if (mode === 'net') netProbe()
else if (mode === 'procs') {
  emit('===== PROCESSES (weston|cage|seatd|electron|node|udevd|udhcpc) =====')
  for (const p of procs()) emit(`  ${p.pid} ${p.comm} ${p.cmd}`)
  emit(`ACTIVE_VT ${read('/sys/class/tty/tty0/active') || 'UNKNOWN'}`)
  emit(`WAYLAND_SOCKET ${waylandSockets().join(', ') || 'NONE_FOUND'}`)
} else {
  process.stderr.write('usage: input-diag.mjs snapshot <label>|status|watch|follow <file> <tag>|esp|procs\n')
  process.exit(2)
}
