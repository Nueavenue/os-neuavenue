# Open the os.neu screen on Windows (twin of screen.sh).
# Does not wipe disks. Does not use USB/JeOS. SX-001: refuse a foreign :4178/:5173.
param(
    [string] $ProtocolUrl = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$UiPort = 5173
$BridgePort = 4178

function Write-OsNeuLine([string] $Level, [string] $Message) {
    Write-Host ("[{0}] {1}" -f $Level, $Message)
}

function Test-OsNeuHttp([string] $Url) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 -Uri $Url
        return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 400)
    }
    catch { return $false }
}

function Get-OsNeuListenPid([int] $Port) {
    try {
        $row = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($row) { return [int] $row.OwningProcess }
    }
    catch { }
    return $null
}

function Test-OsNeuOwnsPid([int] $ProcessId, [string] $Tree) {
    if (-not $ProcessId) { return $false }
    try {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction Stop
        $blob = ("{0} {1}" -f $proc.ExecutablePath, $proc.CommandLine)
        $norm = [IO.Path]::GetFullPath($Tree).TrimEnd('\')
        return $blob.ToLowerInvariant().Contains($norm.ToLowerInvariant())
    }
    catch { return $false }
}

if (-not ((Test-Path (Join-Path $Root "electron\main.cjs")) -and (Test-Path (Join-Path $Root "package.json")))) {
    Write-OsNeuLine FAIL "os.neu: Electron app is not in $Root (missing electron\main.cjs)."
    exit 1
}

$lockDir = Join-Path $env:LOCALAPPDATA "os.neu\screen.lock"
New-Item -ItemType Directory -Force -Path (Split-Path $lockDir) | Out-Null
if (Test-Path -LiteralPath $lockDir) {
    $oldPid = $null
    try { $oldPid = Get-Content -LiteralPath (Join-Path $lockDir "pid") -ErrorAction SilentlyContinue } catch { }
    if ($oldPid -and (Get-Process -Id $oldPid -ErrorAction SilentlyContinue)) {
        Write-OsNeuLine INFO "os.neu screen already open (pid $oldPid). One window only."
        exit 0
    }
    Remove-Item -LiteralPath $lockDir -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $lockDir -Force | Out-Null
[IO.File]::WriteAllText((Join-Path $lockDir "pid"), "$PID")

$bridgeHealth = "http://127.0.0.1:$BridgePort/api/health"
$uiHealth = "http://127.0.0.1:$UiPort/"

function Assert-Port([int] $Port, [string] $HealthUrl, [string] $Label) {
    if (Test-OsNeuHttp $HealthUrl) {
        $owner = Get-OsNeuListenPid $Port
        if (Test-OsNeuOwnsPid $owner $Root) {
            Write-OsNeuLine PASS "reusing ${Label} :$Port"
            return
        }
        Write-OsNeuLine FAIL "OS-NEU-SX-001  Port $Port answers 200 but is not this os.neu tree."
        exit 1
    }
    $owner = Get-OsNeuListenPid $Port
    if ($owner) {
        Write-OsNeuLine FAIL "OS-NEU-SX-001  Port $Port is in use but not serving os.neu (pid $owner)."
        exit 1
    }
}

Set-Location $Root
$env:NEUOS_DRIVER = "live"
$env:NEUOS_SCREEN = "1"
$env:NEUOS_BRIDGE_PORT = "$BridgePort"
$env:NEUOS_DEV_URL = "http://127.0.0.1:$UiPort"
$env:PORT = "$UiPort"

Assert-Port $BridgePort $bridgeHealth "bridge"
Assert-Port $UiPort $uiHealth "ui"

$npx = Get-Command npx.cmd -ErrorAction SilentlyContinue
if (-not $npx) { $npx = Get-Command npx -ErrorAction SilentlyContinue }
if (-not $npx) {
    Write-OsNeuLine FAIL "Need Node.js 20+ / npx on PATH"
    exit 2
}

if (-not (Test-OsNeuHttp $bridgeHealth)) {
    Start-Process -FilePath $npx.Source -WorkingDirectory $Root -WindowStyle Minimized -ArgumentList @("--yes", "tsx", "server/index.ts") | Out-Null
}
if (-not (Test-OsNeuHttp $uiHealth)) {
    Start-Process -FilePath $npx.Source -WorkingDirectory $Root -WindowStyle Minimized -ArgumentList @("--yes", "vite", "--host", "127.0.0.1", "--port", "$UiPort", "--strictPort") | Out-Null
}

$ready = $false
for ($i = 0; $i -lt 80; $i++) {
    if ((Test-OsNeuHttp $bridgeHealth) -and (Test-OsNeuHttp $uiHealth)) { $ready = $true; break }
    Start-Sleep -Milliseconds 250
}
if (-not $ready) {
    Write-OsNeuLine FAIL "OS-NEU-SX-002  os.neu bridge/UI did not become ready on $BridgePort/$UiPort"
    exit 1
}

$electronCmd = Join-Path $Root "node_modules\.bin\electron.cmd"
$launch = @(".")
if ($ProtocolUrl) { $launch += $ProtocolUrl }
Write-OsNeuLine INFO "Opening the os.neu window from $Root"
try {
    if (Test-Path $electronCmd) { & $electronCmd @launch }
    else {
        $npxArgs = @("--yes", "electron", ".")
        if ($ProtocolUrl) { $npxArgs += $ProtocolUrl }
        & $npx.Source @npxArgs
    }
}
finally {
    Remove-Item -LiteralPath $lockDir -Recurse -Force -ErrorAction SilentlyContinue
}
