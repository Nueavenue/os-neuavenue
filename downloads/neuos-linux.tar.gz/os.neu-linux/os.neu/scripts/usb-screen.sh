#!/bin/sh
# Raise the os.neu screen from a USB JeOS session.
# Plants live on the PC disk. This script chroots that Linux and starts
# the os.neu Electron screen (in-app browser) on a free VT.
# Does not wipe disks. Does not use the Ubuntu login session.
set -eu

HOST="${NEUOS_HOST_ROOT:-/mnt/osneu-host}"
USER_NAME="${NEUOS_HOST_USER:-}"
DEST_REL="${NEUOS_HOST_DEST:-}"
GO="${NEUOS_GO:-lui}"
LOG=/tmp/osneu-usb-screen.log

log() {
  echo "os.neu screen: $*"
  echo "os.neu screen: $*" >> "$LOG" 2>/dev/null || true
}

if [ "${NEUOS_USB_SCREEN_DRY:-}" = "1" ]; then
  log "dry-run host=$HOST user=$USER_NAME dest=$DEST_REL"
  exit 0
fi

if [ ! -d "$HOST/home" ] || [ ! -f "$HOST/etc/passwd" ]; then
  log "host Linux is not mounted at $HOST"
  exit 2
fi

if [ -z "$USER_NAME" ]; then
  log "no host user"
  exit 2
fi

if [ -z "$DEST_REL" ]; then
  DEST_REL="/home/$USER_NAME/os.neu"
fi

mkdir -p /tmp /run /lib/firmware "$HOST/proc" "$HOST/sys" "$HOST/dev" "$HOST/dev/pts" "$HOST/run" "$HOST/tmp"
: > "$LOG"

bind() {
  src="$1"
  dst="$2"
  mkdir -p "$dst"
  mountpoint -q "$dst" 2>/dev/null && return 0
  grep -q " $dst " /proc/mounts 2>/dev/null && return 0
  mount --bind "$src" "$dst" 2>/dev/null || true
}

if [ -d "$HOST/lib/firmware" ]; then
  bind "$HOST/lib/firmware" /lib/firmware
fi

if command -v modprobe >/dev/null 2>&1; then
  for m in drm drm_kms_helper simpledrm i915 amdgpu nouveau virtio_gpu; do
    modprobe "$m" 2>/dev/null || true
  done
fi

if [ -d /proc ] && ! grep -q " $HOST/proc " /proc/mounts 2>/dev/null; then
  mount -t proc proc "$HOST/proc" 2>/dev/null || bind /proc "$HOST/proc"
fi
bind /sys "$HOST/sys"
bind /dev "$HOST/dev"
mount -t devpts devpts "$HOST/dev/pts" 2>/dev/null || true
if ! grep -q " $HOST/run " /proc/mounts 2>/dev/null; then
  mount -t tmpfs tmpfs "$HOST/run" 2>/dev/null || bind /run "$HOST/run"
fi
if ! grep -q " $HOST/tmp " /proc/mounts 2>/dev/null; then
  mount -t tmpfs tmpfs "$HOST/tmp" 2>/dev/null || true
fi

UID_NUM="$(awk -F: -v u="$USER_NAME" '$1==u {print $3}' "$HOST/etc/passwd" 2>/dev/null || echo 1000)"
RT="/run/user/$UID_NUM"
mkdir -p "$HOST$RT"
chmod 700 "$HOST$RT" 2>/dev/null || true
chown "$UID_NUM" "$HOST$RT" 2>/dev/null || true

PLANTED="$HOST$DEST_REL"
LAUNCH="$DEST_REL"
KIOSK="$PLANTED/runtime/kiosk"
if [ ! -x "$KIOSK/cage" ]; then
  KIOSK="/opt/neuos/runtime/kiosk"
fi
if [ -d "$PLANTED/runtime/dri" ]; then
  export LIBGL_DRIVERS_PATH="$PLANTED/runtime/dri"
fi
if [ ! -x "$PLANTED/scripts/screen.sh" ]; then
  if [ -x "$HOST/home/$USER_NAME/neuOS/scripts/screen.sh" ]; then
    LAUNCH="/home/$USER_NAME/neuOS"
  fi
fi

if [ -d "$PLANTED" ] && [ ! -e "$PLANTED/node_modules" ]; then
  if [ -d "$HOST/home/$USER_NAME/neuOS/node_modules" ]; then
    ln -sfn "../neuOS/node_modules" "$PLANTED/node_modules"
  fi
fi

if [ ! -e "$HOST$LAUNCH/node_modules/electron" ] && [ ! -x "$HOST$LAUNCH/node_modules/.bin/electron" ]; then
  log "OS-NEU-IC-001  electron is missing under $LAUNCH — autostart is still written for the next Ubuntu login"
  exit 3
fi

find_bin() {
  name="$1"
  for p in "$KIOSK/$name" "/usr/bin/$name" "/usr/sbin/$name" "$HOST/usr/bin/$name" "$HOST/usr/sbin/$name" "$HOST/bin/$name"; do
    if [ -x "$p" ]; then
      echo "$p"
      return 0
    fi
  done
  return 1
}

SEATD="$(find_bin seatd || true)"
CAGE="$(find_bin cage || true)"
WESTON="$(find_bin weston || true)"

if [ -n "$SEATD" ]; then
  "$SEATD" -n 1 >> "$LOG" 2>&1 &
  sleep 1
fi

export XDG_RUNTIME_DIR="$RT"
export XDG_SESSION_TYPE=wayland
export WLR_RENDERER="${WLR_RENDERER:-pixman}"
export LIBSEAT_BACKEND="${LIBSEAT_BACKEND:-seatd}"
export WAYLAND_DISPLAY=wayland-0
export NEUOS_GO="$GO"
export NEUOS_SCREEN=1
export NEUOS_DRIVER=live

if command -v chvt >/dev/null 2>&1; then
  chvt 8 2>/dev/null || true
fi

DRI_ENV=""
if [ -d "$PLANTED/runtime/dri" ]; then
  DRI_ENV="LIBGL_DRIVERS_PATH=$DEST_REL/runtime/dri"
fi
SCREEN_CMD="cd $LAUNCH && export XDG_RUNTIME_DIR=$RT WAYLAND_DISPLAY=wayland-0 XDG_SESSION_TYPE=wayland NEUOS_GO=$GO NEUOS_SCREEN=1 NEUOS_DRIVER=live HOME=/home/$USER_NAME $DRI_ENV && bash scripts/screen.sh"

chroot_user() {
  if [ -x "$HOST/bin/su" ] || [ -x "$HOST/usr/bin/su" ]; then
    chroot "$HOST" /bin/su - "$USER_NAME" -c "$1"
  else
    chroot "$HOST" /bin/sh -c "$1"
  fi
}

run_kiosk() {
  compositor="$1"
  shift
  log "starting $compositor on VT8"
  "$@" >> "$LOG" 2>&1
}

# cage on the USB side, Electron in the host chroot (Wayland socket on shared /run).
if [ -n "$CAGE" ]; then
  bind /run "$HOST/run"
  mkdir -p "$HOST$RT"
  chmod 700 "$HOST$RT" 2>/dev/null || true
  if run_kiosk cage env XDG_RUNTIME_DIR="$HOST$RT" WLR_RENDERER="$WLR_RENDERER" \
      "$CAGE" -- chroot "$HOST" /bin/su - "$USER_NAME" -c "$SCREEN_CMD"; then
    chvt 1 2>/dev/null || true
    exit 0
  fi
fi

if [ -n "$WESTON" ]; then
  mkdir -p /tmp/weston
  printf '[core]\nbackend=drm\nidle-time=0\n[autolaunch]\npath=/bin/sh\n' > /tmp/weston/weston.ini
  if run_kiosk weston env XDG_RUNTIME_DIR="$HOST$RT" "$WESTON" --backend=drm --tty=8 \
      --shell=kiosk-shell.so --config=/tmp/weston/weston.ini; then
    :
  fi
  if chroot_user "$SCREEN_CMD"; then
    chvt 1 2>/dev/null || true
    exit 0
  fi
fi

if [ -x "$HOST/usr/bin/gnome-shell" ]; then
  log "trying host gnome-shell --wayland, then os.neu screen"
  chroot "$HOST" /bin/su - "$USER_NAME" -c "export XDG_RUNTIME_DIR=$RT XDG_SESSION_TYPE=wayland HOME=/home/$USER_NAME; mkdir -p $RT; dbus-run-session gnome-shell --wayland" >> "$LOG" 2>&1 &
  gs=$!
  i=0
  while [ "$i" -lt 25 ]; do
    if [ -S "$HOST$RT/wayland-0" ] || [ -S "$HOST$RT/wayland-1" ]; then
      break
    fi
    i=$((i + 1))
    sleep 1
  done
  if [ -S "$HOST$RT/wayland-0" ] || [ -S "$HOST$RT/wayland-1" ]; then
    if [ -S "$HOST$RT/wayland-1" ]; then
      SCREEN_CMD="cd $LAUNCH && export XDG_RUNTIME_DIR=$RT WAYLAND_DISPLAY=wayland-1 XDG_SESSION_TYPE=wayland NEUOS_GO=$GO NEUOS_SCREEN=1 NEUOS_DRIVER=live HOME=/home/$USER_NAME $DRI_ENV && bash scripts/screen.sh"
    fi
    if chroot_user "$SCREEN_CMD"; then
      kill "$gs" 2>/dev/null || true
      chvt 1 2>/dev/null || true
      exit 0
    fi
  fi
  kill "$gs" 2>/dev/null || true
fi

log "OS-NEU-SX-000  no compositor (cage/weston/gnome-shell) could open a seat from USB"
log "files are on this PC at $DEST_REL — next Ubuntu login still opens the screen"
chvt 1 2>/dev/null || true
exit 4
