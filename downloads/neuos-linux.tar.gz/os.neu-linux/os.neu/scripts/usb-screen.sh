#!/bin/sh
# Raise the os.neu screen from a USB JeOS session.
# Plants live on the PC disk. This script starts a DRM compositor on a free VT
# (cage preferred), then runs the planted Electron screen inside the host
# chroot as that compositor's client.
# Does not wipe disks. Does not chmod /dev/dri. Does not use --ozone-platform=drm.
# Does not use Ubuntu GDM / gnome-shell (that path needs logind; USB does not have it).
set -eu

HOST="${NEUOS_HOST_ROOT:-/mnt/osneu-host}"
USER_NAME="${NEUOS_HOST_USER:-}"
DEST_REL="${NEUOS_HOST_DEST:-}"
GO="${NEUOS_GO:-lui}"
LOG=/tmp/osneu-usb-screen.log

log() {
  echo "os.neu screen: $*"
  echo "os.neu screen: $*" >> "$LOG" 2>/dev/null || true
}

if [ "${NEUOS_USB_SCREEN_DRY:-}" = "1" ]; then
  log "dry-run host=$HOST user=$USER_NAME dest=$DEST_REL"
  exit 0
fi

if [ ! -d "$HOST/home" ] || [ ! -f "$HOST/etc/passwd" ]; then
  log "host Linux is not mounted at $HOST"
  exit 2
fi

if [ -z "$USER_NAME" ]; then
  log "no host user"
  exit 2
fi

if [ -z "$DEST_REL" ]; then
  DEST_REL="/home/$USER_NAME/os.neu"
fi

mkdir -p /tmp /run /opt/neuos/firmware "$HOST/proc" "$HOST/sys" "$HOST/dev" "$HOST/dev/pts" "$HOST/run" "$HOST/tmp" || true
: > "$LOG"

bind() {
  src="$1"
  dst="$2"
  mkdir -p "$dst"
  mountpoint -q "$dst" 2>/dev/null && return 0
  grep -q " $dst " /proc/mounts 2>/dev/null && return 0
  mount --bind "$src" "$dst" 2>/dev/null || true
}

if [ -d "$HOST/lib/firmware" ]; then
  bind "$HOST/lib/firmware" /lib/firmware
fi

# JeOS ROOT does not ship Ubuntu's module tree. Bind the host's so i915/amdgpu
# can replace EFI simpledrm (cage then has a real KMS node).
KVER="$(uname -r 2>/dev/null || true)"
if [ -n "$KVER" ] && [ -d "$HOST/lib/modules/$KVER" ]; then
  mkdir -p "/lib/modules/$KVER"
  bind "$HOST/lib/modules/$KVER" "/lib/modules/$KVER"
fi

if command -v modprobe >/dev/null 2>&1; then
  for m in drm drm_kms_helper i915 amdgpu nouveau virtio_gpu simpledrm; do
    modprobe "$m" 2>/dev/null || true
  done
fi

if [ -d /proc ] && ! grep -q " $HOST/proc " /proc/mounts 2>/dev/null; then
  mount -t proc proc "$HOST/proc" 2>/dev/null || bind /proc "$HOST/proc"
fi
bind /sys "$HOST/sys"
bind /dev "$HOST/dev"
mount -t devpts devpts "$HOST/dev/pts" 2>/dev/null || true
if ! grep -q " $HOST/run " /proc/mounts 2>/dev/null; then
  mount -t tmpfs tmpfs "$HOST/run" 2>/dev/null || bind /run "$HOST/run"
fi
if ! grep -q " $HOST/tmp " /proc/mounts 2>/dev/null; then
  mount -t tmpfs tmpfs "$HOST/tmp" 2>/dev/null || true
fi

UID_NUM="$(awk -F: -v u="$USER_NAME" '$1==u {print $3}' "$HOST/etc/passwd" 2>/dev/null || echo 1000)"
RT="/run/user/$UID_NUM"
mkdir -p "$HOST$RT"
chmod 700 "$HOST$RT" 2>/dev/null || true
chown "$UID_NUM" "$HOST$RT" 2>/dev/null || true

PLANTED="$HOST$DEST_REL"
LAUNCH="$DEST_REL"
# Prefer the stick-staged compositor (libs live on JeOS ROOT). Host-planted
# cage under /mnt/osneu-host/... needs Ubuntu's ld-linux — exec from USB is 127.
if [ -x /opt/neuos/runtime/kiosk/cage ]; then
  KIOSK="/opt/neuos/runtime/kiosk"
elif [ -x "$PLANTED/runtime/kiosk/cage" ]; then
  KIOSK="$PLANTED/runtime/kiosk"
else
  KIOSK="/opt/neuos/runtime/kiosk"
fi
if [ -d "$PLANTED/runtime/dri" ]; then
  export LIBGL_DRIVERS_PATH="$PLANTED/runtime/dri"
fi
if [ ! -x "$PLANTED/scripts/screen.sh" ]; then
  if [ -x "$HOST/home/$USER_NAME/neuOS/scripts/screen.sh" ]; then
    LAUNCH="/home/$USER_NAME/neuOS"
  fi
fi

if [ -d "$PLANTED" ] && [ ! -e "$PLANTED/node_modules" ]; then
  if [ -d "$HOST/home/$USER_NAME/neuOS/node_modules" ]; then
    ln -sfn "../neuOS/node_modules" "$PLANTED/node_modules"
  fi
fi

if [ ! -e "$HOST$LAUNCH/node_modules/electron" ] && [ ! -x "$HOST$LAUNCH/node_modules/.bin/electron" ]; then
  log "OS-NEU-IC-001  electron is missing under $LAUNCH — autostart is still written for the next Ubuntu login"
  exit 3
fi

find_bin() {
  name="$1"
  for p in \
    "/opt/neuos/runtime/kiosk/$name" \
    "/usr/bin/$name" \
    "/usr/sbin/$name" \
    "/bin/$name" \
    "$KIOSK/$name" \
    "$HOST/usr/bin/$name" \
    "$HOST/usr/sbin/$name" \
    "$HOST/bin/$name" \
    "$PLANTED/runtime/kiosk/$name"; do
    if [ -x "$p" ]; then
      echo "$p"
      return 0
    fi
  done
  return 1
}

SEATD="$(find_bin seatd || true)"
CAGE="$(find_bin cage || true)"
WESTON="$(find_bin weston || true)"
log "bins cage=${CAGE:-none} seatd=${SEATD:-none} weston=${WESTON:-none}"
log "kiosk cage=$(ls -l /opt/neuos/runtime/kiosk/cage /usr/bin/cage 2>/dev/null || true)"
log "env=$(command -v env 2>/dev/null || echo none) sh=$(command -v sh 2>/dev/null || echo none)"

# Wait for a DRM node. USB JeOS has no logind; i915/amdgpu must still
# create /dev/dri after the modprobe loop above.
i=0
while [ "$i" -lt 8 ]; do
  if ls /dev/dri/card0 >/dev/null 2>&1 || ls /dev/dri/card1 >/dev/null 2>&1; then
    break
  fi
  i=$((i + 1))
  sleep 1
done
if ls /dev/dri >/dev/null 2>&1; then
  drm_names=""
  for n in /dev/dri/*; do
    [ -e "$n" ] || continue
    drm_names="$drm_names ${n##*/}"
  done
  log "DRM$drm_names"
  for u in /sys/class/drm/card0/device/uevent /sys/class/drm/card1/device/uevent; do
    [ -f "$u" ] || continue
    log "DRM $(echo "$u" | sed 's|.*/drm/||;s|/device/uevent||') $(grep ^DRIVER= "$u" 2>/dev/null || true)"
  done
else
  log "no /dev/dri yet — compositor may still fail (OS-NEU-SX-000)"
fi

# This PC's i915 is card1 (Leader 2026-10-20). Forcing card0 (often simpledrm)
# makes wlroots fail after cage actually starts.
DRM_DEV=""
for card in card1 card0 card2; do
  u="/sys/class/drm/$card/device/uevent"
  [ -f "$u" ] || continue
  drv="$(grep ^DRIVER= "$u" 2>/dev/null | sed 's/^DRIVER=//')"
  case "$drv" in
    i915|xe|amdgpu|nouveau|virtio_gpu|radeon)
      DRM_DEV="/dev/dri/$card"
      break
      ;;
  esac
done
if [ -z "$DRM_DEV" ]; then
  if [ -e /dev/dri/card1 ]; then
    DRM_DEV=/dev/dri/card1
  elif [ -e /dev/dri/card0 ]; then
    DRM_DEV=/dev/dri/card0
  fi
fi
log "WLR_DRM_DEVICES=${DRM_DEV:-none}"
export WLR_DRM_DEVICES="${DRM_DEV:-}"

# First auto-open can leave npx/tsx listening on 4178 after cage dies.
# PID 1 is node kernel.mjs — never fuser the whole node tree.
clear_listen_port() {
  port="$1"
  if command -v fuser >/dev/null 2>&1; then
    fuser -k "${port}/tcp" >/dev/null 2>&1 || true
  elif command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)"
    if [ -n "$pids" ]; then
      for p in $pids; do
        [ "$p" = "1" ] && continue
        kill "$p" 2>/dev/null || true
      done
    fi
  fi
}
clear_listen_port 4178
clear_listen_port 5173
sleep 1

# seatd -n 1 was "notify on fd 1" (stdout), not "one seat". Start a real daemon.
if [ -n "$SEATD" ]; then
  SEATD_SOCK="${SEATD_SOCK:-/run/seatd.sock}"
  export SEATD_SOCK
  if [ ! -S "$SEATD_SOCK" ]; then
    "$SEATD" >> "$LOG" 2>&1 &
    s=0
    while [ "$s" -lt 5 ] && [ ! -S "$SEATD_SOCK" ]; do
      s=$((s + 1))
      sleep 1
    done
  fi
  log "seatd sock $( [ -S "$SEATD_SOCK" ] && echo ready || echo missing )"
fi

# Shared runtime for compositor (USB root) and Electron (host chroot). Both run
# as root on this live stick so the Wayland socket is not dropped by `su -`.
WL=/run/osneu-wl
mkdir -p "$WL"
chmod 700 "$WL" 2>/dev/null || true
bind /run "$HOST/run"
mkdir -p "$HOST$WL" "$HOST$RT"

export XDG_RUNTIME_DIR="$WL"
export XDG_SESSION_TYPE=wayland
export WLR_RENDERER="${WLR_RENDERER:-pixman}"
unset WLR_BACKENDS || true
export WAYLAND_DISPLAY=wayland-0
export NEUOS_GO="$GO"
export NEUOS_SCREEN=1
export NEUOS_DRIVER=live
export ELECTRON_OZONE_PLATFORM_HINT="${ELECTRON_OZONE_PLATFORM_HINT:-wayland}"

DRI_ENV=""
if [ -d "$PLANTED/runtime/dri" ]; then
  DRI_ENV="LIBGL_DRIVERS_PATH=$DEST_REL/runtime/dri"
fi
# Keep WAYLAND_DISPLAY from cage's child environment. Do not `su -` (login su
# wipes that env and the compositor then has no client).
# Pass NEUOS_JEOS so planted screen.sh may reclaim stale 4178 on this stick.
SCREEN_CMD="cd $LAUNCH && export HOME=/home/$USER_NAME XDG_RUNTIME_DIR=$WL XDG_SESSION_TYPE=wayland WAYLAND_DISPLAY=\${WAYLAND_DISPLAY:-wayland-0} NEUOS_JEOS=1 NEUOS_GO=$GO NEUOS_SCREEN=1 NEUOS_DRIVER=live ELECTRON_OZONE_PLATFORM_HINT=wayland $DRI_ENV && bash scripts/screen.sh"

OPENVT="$(find_bin openvt || true)"
VT=7
CAGE_LOG="${LOG}.cage"

# Do not call `env` — JeOS busybox applets did not include it (exit 127, empty log).
# Host-planted cage/weston need Ubuntu libs: run them inside chroot $HOST.
inside_host() {
  _p="$1"
  case "$_p" in
    "$HOST"/*) echo "${_p#"$HOST"}" ;;
    *) echo "" ;;
  esac
}

LD_KIOSK='/opt/neuos/runtime/kiosk/lib/x86_64-linux-gnu:/opt/neuos/runtime/kiosk/lib:/opt/neuos/runtime/kiosk:/usr/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu/weston:/usr/lib/x86_64-linux-gnu/libweston-14'

run_on_vt() {
  compositor="$1"
  shift
  log "starting $compositor on VT${VT} (openvt=${OPENVT:-none} drm=${DRM_DEV:-none} bin=$1)"
  : > "$CAGE_LOG"
  {
    echo "argv: $*"
    ls -l "$1" 2>/dev/null || echo "missing $1"
    if command -v ldd >/dev/null 2>&1; then
      LD_LIBRARY_PATH="$LD_KIOSK${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ldd "$1" 2>/dev/null | head -24
    fi
  } >> "$CAGE_LOG" 2>&1
  WRAP=/tmp/osneu-vt-${compositor}.sh
  {
    echo '#!/bin/sh'
    echo "export XDG_RUNTIME_DIR='$WL'"
    echo "export XDG_SESSION_TYPE=wayland"
    echo "export WAYLAND_DISPLAY=wayland-0"
    echo "export LIBSEAT_BACKEND='${LIBSEAT_BACKEND:-builtin}'"
    echo "export WLR_RENDERER='${WLR_RENDERER}'"
    if [ "$compositor" = cage ]; then
      echo "unset WAYLAND_DISPLAY"
      echo "unset WAYLAND_SOCKET"
      echo "unset DISPLAY"
      echo "unset WLR_BACKENDS"
    fi
    echo "export WLR_DRM_DEVICES='${DRM_DEV}'"
    echo "export WLR_NO_HARDWARE_CURSORS=1"
    echo "export SEATD_SOCK='${SEATD_SOCK:-}'"
    echo "export NEUOS_JEOS=1"
    echo "export LD_LIBRARY_PATH='$LD_KIOSK${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}'"
    echo 'exec "$@"'
  } > "$WRAP"
  chmod +x "$WRAP"
  set +e
  if [ -n "$OPENVT" ]; then
    "$OPENVT" -c "$VT" -s -w -- /bin/sh "$WRAP" "$@" >> "$CAGE_LOG" 2>&1
  else
    chvt "$VT" 2>/dev/null || true
    /bin/sh "$WRAP" "$@" >> "$CAGE_LOG" 2>&1
  fi
  st=$?
  set -e
  if [ "$st" -ne 0 ]; then
    log "$compositor exit $st — last log:"
    tail -n 24 "$CAGE_LOG" 2>/dev/null | while IFS= read -r line; do
      log "  $line"
    done
  fi
  return "$st"
}

run_cage() {
  backend="$1"
  log "cage LIBSEAT_BACKEND=$backend bin=$CAGE"
  export LIBSEAT_BACKEND="$backend"
  _in="$(inside_host "$CAGE")"
  if [ -n "$_in" ]; then
    run_on_vt cage chroot "$HOST" "$_in" -- /bin/bash -c "$SCREEN_CMD"
  else
    run_on_vt cage "$CAGE" -- chroot "$HOST" /bin/bash -c "$SCREEN_CMD"
  fi
}

tried=""
for cand in /opt/neuos/runtime/kiosk/cage /usr/bin/cage "$PLANTED/runtime/kiosk/cage" "$HOST/usr/bin/cage" "$CAGE"; do
  [ -n "$cand" ] && [ -x "$cand" ] || continue
  case " $tried " in
    *" $cand "*) continue ;;
  esac
  tried="$tried $cand"
  CAGE="$cand"
  if run_cage builtin; then
    chvt 1 2>/dev/null || true
    exit 0
  fi
  clear_listen_port 4178
  clear_listen_port 5173
  if [ -S "${SEATD_SOCK:-/run/seatd.sock}" ] && run_cage seatd; then
    chvt 1 2>/dev/null || true
    exit 0
  fi
  clear_listen_port 4178
  clear_listen_port 5173
done

run_weston() {
  _bin="$1"
  mkdir -p /tmp/weston "$HOST/tmp/weston"
  _in="$(inside_host "$_bin")"
  export LIBSEAT_BACKEND=builtin
  log "weston drm kiosk on VT${VT} bin=$_bin"
  if [ -n "$_in" ]; then
    {
      echo '#!/bin/sh'
      echo "exec /bin/bash -c \"$SCREEN_CMD\""
    } > "$HOST/tmp/weston/client.sh"
    chmod +x "$HOST/tmp/weston/client.sh"
    {
      echo '[core]'
      echo 'backend=drm'
      echo 'idle-time=0'
      echo '[autolaunch]'
      echo 'path=/tmp/weston/client.sh'
    } > "$HOST/tmp/weston/weston.ini"
    cp "$HOST/tmp/weston/client.sh" /tmp/weston/client.sh
    cp "$HOST/tmp/weston/weston.ini" /tmp/weston/weston.ini
    run_on_vt weston chroot "$HOST" "$_in" --backend=drm --tty="$VT" --shell=kiosk-shell.so \
      --config=/tmp/weston/weston.ini
  else
    {
      echo '#!/bin/sh'
      echo "exec chroot \"$HOST\" /bin/bash -c \"$SCREEN_CMD\""
    } > /tmp/weston/client.sh
    chmod +x /tmp/weston/client.sh
    {
      echo '[core]'
      echo 'backend=drm'
      echo 'idle-time=0'
      echo '[autolaunch]'
      echo 'path=/tmp/weston/client.sh'
    } > /tmp/weston/weston.ini
    run_on_vt weston "$_bin" --backend=drm --tty="$VT" --shell=kiosk-shell.so \
      --config=/tmp/weston/weston.ini
  fi
}

wtried=""
for cand in /opt/neuos/runtime/kiosk/weston /usr/bin/weston "$PLANTED/runtime/kiosk/weston" "$HOST/usr/bin/weston" "$WESTON"; do
  [ -n "$cand" ] && [ -x "$cand" ] || continue
  case " $wtried " in
    *" $cand "*) continue ;;
  esac
  wtried="$wtried $cand"
  if run_weston "$cand"; then
    chvt 1 2>/dev/null || true
    exit 0
  fi
  clear_listen_port 4178
  clear_listen_port 5173
done

log "OS-NEU-SX-000  no compositor (cage/weston) could open a seat from USB"
log "files are on this PC at $DEST_REL — Ubuntu login still opens the screen: bash ~/os.neu/scripts/open-neuos.sh"
chvt 1 2>/dev/null || true
exit 4
