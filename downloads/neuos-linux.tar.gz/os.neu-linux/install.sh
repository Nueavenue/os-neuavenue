#!/usr/bin/env bash
# Unpack neuos-linux.tar.gz into ~/os.neu and plant the launcher.
# This file sits at the root of the download. Linux only.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ -x "$HERE/os.neu/scripts/install-linux.sh" ]]; then
  exec bash "$HERE/os.neu/scripts/install-linux.sh"
fi
if [[ -x "$HERE/scripts/install-linux.sh" ]]; then
  exec bash "$HERE/scripts/install-linux.sh"
fi
echo "os.neu install script missing next to $0" >&2
exit 1
