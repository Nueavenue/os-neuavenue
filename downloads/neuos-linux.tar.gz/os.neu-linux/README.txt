os.neu Linux screen
Linux only. Does not wipe disks.

  tar -xzf neuos-linux.tar.gz
  bash os.neu-linux/install.sh

Then click the os.neu icon in Applications or on the Desktop.
You do not need to cd ~/os.neu. The icon opens the independent os.neu browser.
The window is resizable.

Need Node.js 20+ and npm on this PC.
