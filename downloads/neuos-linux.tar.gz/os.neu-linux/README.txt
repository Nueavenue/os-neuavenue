os.neu Linux screen
Matches Windows Setup 1.0.14 (2026-11-22): daf.neu site Google SSO in-guest (Leader GRANT).
Linux only. Does not wipe disks.

  tar -xzf neuos-linux.tar.gz
  bash os.neu-linux/install.sh

Then click the os.neu icon in Applications (Show Apps) or on the Desktop.
install.sh plants those icons automatically. You do not need to cd ~/os.neu.
The window is resizable.

Need Node.js 20+ and npm on this PC.
Double-click Install-os.neu.desktop (Allow Launching) or:

  bash os.neu-linux/install.sh
