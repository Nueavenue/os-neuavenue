os.neu on Windows
Not the Linux tar. Not WSL2. USB ISO from the site is Linux JeOS (Rufus) — it does not plant Start Menu.

  Expand-Archive neuos-windows.zip
  powershell -ExecutionPolicy Bypass -File os.neu-windows\install-windows.ps1

That copies to %USERPROFILE%\os.neu and creates Desktop + Start Menu shortcuts named os.neu.
Logon is off unless you pass -EnableLogon (HKCU Run only, never also Startup folder).

Need Node.js 20+ and npm. install-windows.ps1 runs npm install so Electron is the Windows build.

  powershell -File os.neu-windows\os.neu\scripts\uninstall-windows.ps1
