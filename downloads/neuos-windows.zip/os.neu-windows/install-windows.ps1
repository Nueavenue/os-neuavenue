# os.neu Windows plant. No wipe. No explorer replace. No VHD. No HKLM.
# Desktop + Start Menu shortcuts named os.neu.
# Logon is OPT-IN:  powershell -File install-windows.ps1 -EnableLogon
# -EnableLogon uses HKCU Run only (never also a Startup folder .lnk).

param(
  [switch]$EnableLogon,
  [switch]$Uninstall,
  [switch]$Files
)

$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Src = $Here
if (Test-Path (Join-Path $Here 'os.neu\package.json')) {
  $Src = Join-Path $Here 'os.neu'
} elseif ((Test-Path (Join-Path $Here '..\package.json')) -and (Test-Path (Join-Path $Here '..\src'))) {
  $Src = (Resolve-Path (Join-Path $Here '..')).Path
}

$PlantRoot = Join-Path $env:USERPROFILE 'os.neu'
$RunKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$ValueName = 'os.neu'
$Launcher = Join-Path $PlantRoot 'scripts\open-neuos.cmd'
$DesktopDir = [Environment]::GetFolderPath('Desktop')
$StartDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$DesktopLnk = Join-Path $DesktopDir 'os.neu.lnk'
$StartLnk = Join-Path $StartDir 'os.neu.lnk'
$StartupLnk = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\os.neu.lnk'

function Uninstall-OsNeuWindows {
  if (Get-ItemProperty -Path $RunKey -Name $ValueName -ErrorAction SilentlyContinue) {
    Remove-ItemProperty -Path $RunKey -Name $ValueName -ErrorAction SilentlyContinue
  }
  Remove-Item -LiteralPath $DesktopLnk, $StartLnk, $StartupLnk -ErrorAction SilentlyContinue
  if ($Files) {
    if ((Test-Path $PlantRoot) -and ((Resolve-Path $PlantRoot).Path -ne (Resolve-Path $Src).Path)) {
      Remove-Item -LiteralPath $PlantRoot -Recurse -Force
      Write-Host "removed planted copy: $PlantRoot"
    }
  }
  Write-Host 'os.neu Start Menu / Desktop / optional logon removed. Disks were not wiped.'
}

if ($Uninstall) {
  Uninstall-OsNeuWindows
  exit 0
}

New-Item -ItemType Directory -Force -Path $PlantRoot | Out-Null
if ((Resolve-Path $Src).Path -ne (Resolve-Path $PlantRoot).Path) {
  Get-ChildItem -LiteralPath $Src -Force | ForEach-Object {
    if ($_.Name -in @('node_modules', '.git', 'dist', 'dist-web')) { return }
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $PlantRoot $_.Name) -Recurse -Force
  }
}

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
  throw 'Need Node.js 20+ and npm on this Windows PC, then re-run install-windows.ps1'
}

Set-Location $PlantRoot
if (-not (Test-Path (Join-Path $PlantRoot 'node_modules\electron'))) {
  npm install
}

New-Item -ItemType Directory -Force -Path $StartDir | Out-Null
$cmd = (Get-Command cmd.exe).Source
$w = New-Object -ComObject WScript.Shell
foreach ($lnkPath in @($DesktopLnk, $StartLnk)) {
  $s = $w.CreateShortcut($lnkPath)
  $s.TargetPath = $cmd
  $s.Arguments = "/c `"$Launcher`""
  $s.WorkingDirectory = $PlantRoot
  $s.WindowStyle = 7
  $s.Description = 'os.neu'
  $s.Save()
}

# Never both: if EnableLogon, HKCU Run only. Remove any leftover Startup .lnk.
Remove-Item -LiteralPath $StartupLnk -ErrorAction SilentlyContinue
if ($EnableLogon) {
  if (-not (Test-Path $Launcher)) { throw "Missing launcher: $Launcher" }
  New-Item -Path $RunKey -Force | Out-Null
  Set-ItemProperty -Path $RunKey -Name $ValueName -Value ('cmd.exe /c "' + $Launcher + '"')
} else {
  if (Get-ItemProperty -Path $RunKey -Name $ValueName -ErrorAction SilentlyContinue) {
    Remove-ItemProperty -Path $RunKey -Name $ValueName -ErrorAction SilentlyContinue
  }
}

Write-Host "Planted $PlantRoot"
Write-Host "Shortcuts: $DesktopLnk and $StartLnk"
if ($EnableLogon) {
  Write-Host 'Logon: HKCU Run os.neu (Startup folder not used).'
} else {
  Write-Host 'Logon: off. Pass -EnableLogon to start os.neu at sign-in.'
}
Write-Host 'USB ISO from the site is Linux JeOS. It does not plant this Start Menu icon.'
