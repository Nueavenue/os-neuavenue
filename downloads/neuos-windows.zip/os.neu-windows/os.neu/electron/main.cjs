const { app, BrowserWindow, BrowserView, ipcMain, session, dialog, shell, Menu, net } = require('electron')
const fs = require('node:fs')
const path = require('node:path')

const PROTOCOL = 'osneu'
const DEV = process.env.NEUOS_DEV_URL ?? 'http://127.0.0.1:5173'
const WEB_HOME = 'https://www.neuavenue.com'
process.env.NEUOS_ELECTRON = '1'

if (process.defaultApp) {
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient(PROTOCOL, process.execPath, [path.resolve(process.argv[1])])
  }
} else {
  app.setAsDefaultProtocolClient(PROTOCOL)
}

function linuxSuidSandboxOk() {
  if (process.platform !== 'linux') return true
  try {
    const helper = path.join(path.dirname(process.execPath), 'chrome-sandbox')
    const st = fs.statSync(helper)
    return st.uid === 0 && (st.mode & 0o4000) !== 0
  } catch {
    return false
  }
}

// npm-installed Electron cannot use the SUID helper unless chrome-sandbox is
// root:root mode 4755. Without this switch Chromium aborts before the window.
if (!linuxSuidSandboxOk()) {
  app.commandLine.appendSwitch('no-sandbox')
  app.commandLine.appendSwitch('disable-gpu-sandbox')
}

/** @type {BrowserWindow | null} */
let win = null
/** @type {Electron.Session | null} */
let browseSession = null
/** @type {Map<string, { rec: object, item?: Electron.DownloadItem }>} */
const downloads = new Map()
let downloadSeq = 0

/**
 * Each os.neu browser window (the primary app window, plus any secondary
 * "New window" instances — WO-BROWSER-WINDOW-1 follow-up) gets its own
 * browsing controller: its own BrowserView, devtools view, and in-flight
 * navigation state. Keyed by the owning BrowserWindow's id so IPC handlers
 * can resolve "which window's browser is this call for" from the sender.
 * @typedef {{ win: Electron.BrowserWindow, view: Electron.BrowserView | null, dtView: Electron.BrowserView | null, lastGoodUrl: string, restoring: boolean, pendingLoadFinish: ((payload: object) => void) | null }} BrowseController
 * @type {Map<number, BrowseController>}
 */
const controllers = new Map()

function controllerForSender(sender) {
  const bw = BrowserWindow.fromWebContents(sender)
  return (bw && controllers.get(bw.id)) || null
}

function chromeUA() {
  const chrome = process.versions.chrome || '124.0.0.0'
  return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`
}

function findProtocolUrl(argv) {
  const list = Array.isArray(argv) ? argv : []
  return list.find((arg) => typeof arg === 'string' && arg.startsWith(`${PROTOCOL}://`)) || ''
}

function parseOAuthDeepLink(raw) {
  // Preferred (WO-AUTH-ELECTRON-PKCE-1): osneu://oauth?status=success&handoff=…
  // (opaque wake, no token). Legacy fallback: osneu://oauth?token=…&handoff=….
  try {
    const url = new URL(String(raw || ''))
    if (url.protocol !== `${PROTOCOL}:`) return null
    const host = url.hostname || ''
    const pathName = (url.pathname || '').replace(/^\//, '')
    const kind = host || pathName.split('/')[0] || ''
    if (kind === 'focus' || pathName === 'focus') {
      return { token: '', handoff: '', focusOnly: true }
    }
    if (kind !== 'oauth' && pathName !== 'oauth' && !pathName.startsWith('oauth')) return null
    const token = String(url.searchParams.get('token') || '').trim()
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    const status = String(url.searchParams.get('status') || '').trim()
    const hasWake = status === 'success' && Boolean(handoff)
    if (!token && !hasWake) return { token: '', handoff: '', focusOnly: true }
    return { token, handoff, focusOnly: false }
  } catch {
    return null
  }
}

function focusMainWindow() {
  // `win` (the primary window) can be closed by the user while the app stays
  // alive because a secondary "New window" instance is still open — calling
  // any method on that destroyed BrowserWindow throws "Object has been
  // destroyed", crashing the main process (hit during the Google OAuth
  // deep-link handoff, reported 2026-09-02). Fall back to focusing whichever
  // os.neu window is still open instead of assuming `win` is it.
  if (win && !win.isDestroyed()) {
    if (win.isMinimized()) win.restore()
    win.show()
    win.focus()
    return
  }
  for (const ctl of controllers.values()) {
    if (ctl.win && !ctl.win.isDestroyed()) {
      if (ctl.win.isMinimized()) ctl.win.restore()
      ctl.win.show()
      ctl.win.focus()
      return
    }
  }
}

function deliverOAuthDeepLink(raw) {
  const payload = parseOAuthDeepLink(raw)
  if (!payload) {
    // Any other osneu://… still focuses the shell.
    if (String(raw || '').startsWith(`${PROTOCOL}://`)) {
      focusMainWindow()
      return true
    }
    return false
  }
  focusMainWindow()
  if (payload.focusOnly || (!payload.token && !payload.handoff)) return true
  try {
    // Opaque wake (preferred): payload.token is '' — renderer fetches the
    // session itself via the existing handoff-poll endpoint. Legacy: token
    // is present (fallback path, pre-Console-PKCE-setup).
    win?.webContents.send('auth:oauth', { token: payload.token, handoff: payload.handoff })
  } catch {
    /* window may be closing */
  }
  return true
}

// Host-only identity-provider check (Google/Microsoft/Apple/GitHub login).
// Deliberately does NOT special-case `about:blank`/empty — that's handled by
// callers that need it (see `isAuthUrl` below). Split out for
// WO-UI-NEU-DAF-BLANK-POPUP-121 / OS-NEU-DAF-001: the guest popup handler
// must NOT treat a blank/empty `window.open()` as an IdP redirect.
function isIdpHost(url) {
  try {
    const host = new URL(url).hostname
    return (
      host === 'accounts.google.com' ||
      host === 'accounts.youtube.com' ||
      host === 'login.microsoftonline.com' ||
      host === 'login.live.com' ||
      host === 'appleid.apple.com' ||
      (host === 'github.com' && /\/login/.test(url))
    )
  } catch {
    return false
  }
}

// Kept for existing callers (did-fail-load / loadInView restore guards) —
// behavior unchanged: blank/empty still counts as "auth-like" there so a
// failed/empty load doesn't bounce the guest back to lastGoodUrl. Only the
// new setWindowOpenHandler popup-routing decision uses the narrower
// `isIdpHost` above instead of this.
function isAuthUrl(url) {
  if (!url || url === 'about:blank') return true
  return isIdpHost(url)
}

// WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND — per-origin pop-up policy
// (Default | Allow | Block). Keyed on the *opener* page's hostname (the
// guest page calling window.open), persisted to a small JSON file so a
// Leader/Block choice survives an app restart. Default = no entry.
/** @type {Map<string, 'allow' | 'block'>} */
const sitePolicy = new Map()

function sitePolicyFilePath() {
  return path.join(app.getPath('userData'), 'popup-site-policy.json')
}

function loadSitePolicy() {
  try {
    const raw = fs.readFileSync(sitePolicyFilePath(), 'utf8')
    const obj = JSON.parse(raw)
    if (obj && typeof obj === 'object') {
      for (const [host, policy] of Object.entries(obj)) {
        if (policy === 'allow' || policy === 'block') sitePolicy.set(host, policy)
      }
    }
  } catch {
    /* first run, or corrupt file — start with an empty (Default-only) store */
  }
}

function saveSitePolicy() {
  try {
    const file = sitePolicyFilePath()
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, JSON.stringify(Object.fromEntries(sitePolicy), null, 2))
  } catch {
    /* best effort — a failed write just means the choice won't survive restart */
  }
}

function hostOfUrl(url) {
  try {
    return new URL(String(url || '')).hostname
  } catch {
    return ''
  }
}

function getSitePolicy(host) {
  if (!host) return 'default'
  return sitePolicy.get(host) || 'default'
}

function setSitePolicy(host, policy) {
  if (!host) return
  if (policy === 'allow' || policy === 'block') sitePolicy.set(host, policy)
  else sitePolicy.delete(host)
  saveSitePolicy()
}

function emitPopupBlocked(ctl, host) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  try {
    ctl.win.webContents.send('browse:popup-blocked', { host })
  } catch {
    /* window may be closing */
  }
}

function isLoopbackUrl(url) {
  try {
    const host = new URL(url).hostname
    return host === 'localhost' || host === '127.0.0.1' || host === '::1'
  } catch {
    return false
  }
}

function emitBrowseNavigated(ctl, url, title) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  if (!url || !/^https?:\/\//i.test(url)) return
  try {
    ctl.win.webContents.send('browse:navigated', {
      href: url,
      title: typeof title === 'string' && title.trim() ? title.trim() : undefined,
    })
  } catch {
    /* window may be closing */
  }
}

function emitBrowseOpenTab(ctl, url) {
  if (!ctl?.win || ctl.win.isDestroyed()) return
  if (!url || !/^https?:\/\//i.test(url)) return
  try {
    ctl.win.webContents.send('browse:open-tab', { href: url })
  } catch {
    /* window may be closing */
  }
}

// WO-UI-NEU-DAF-SITE-POPUP-121 / OS-NEU-DAF-000: a real popup (explicit
// width/height features, e.g. `window.open(url, 'popup', 'width=450,height=480')`)
// must not be routed into the shared in-app tab strip. Returns the requested
// { width, height } when `features` looks popup-sized, else null.
function popupFeatureSize(features) {
  if (!features || typeof features !== 'string') return null
  const map = {}
  for (const part of features.split(',')) {
    const [rawKey, rawVal] = part.split('=')
    const key = rawKey?.trim().toLowerCase()
    if (!key) continue
    map[key] = rawVal?.trim() ?? ''
  }
  const width = Number(map.width)
  const height = Number(map.height)
  if (Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0) {
    return { width: Math.round(width), height: Math.round(height) }
  }
  return null
}

function attachGuest(guest, ctl) {
  guest.setUserAgent(chromeUA())
  guest.setWindowOpenHandler(({ url, features, disposition }) => {
    // Identity-provider HOSTS (e.g. "Sign in with Google" from a guest page)
    // must never open inside an embedded Electron window/tab — Google blocks
    // embedded user-agents. Hand off to the OS system browser instead
    // (WO-BROWSER-WINDOW-1). Host check only — see isIdpHost above.
    if (isIdpHost(url)) {
      void shell.openExternal(url)
      return { action: 'deny' }
    }
    // WO-UI-NEU-DAF-BLANK-POPUP-121 / OS-NEU-DAF-001: `about:blank` (or an
    // empty target) is NOT an IdP redirect — Korean identity/sign-up flows
    // (e.g. agriedu.net client_sign_up) open a blank child window first, then
    // navigate or `document.write` into it. Previously `isAuthUrl` treated
    // that blank open as auth-like and denied it, so the site's OWN "pop-up
    // blocked" message fired even though os.neu never asked the user for
    // permission. Blank/empty now falls through to the same child-window
    // path as a featured popup, below.
    const isBlankOpen = !url || url === 'about:blank'
    if (!isBlankOpen && !/^https?:\/\//i.test(url)) {
      return { action: 'deny' }
    }
    // Per-origin Default | Allow | Block (UI-B26 AMEND), keyed on the
    // *opener* page's host — not the target. Block stops every window.open
    // from that origin (blank or featured) and surfaces os.neu's own panel
    // instead of the site's silent/alert-style blocker message. There is no
    // global allow-all: Allow only escalates *this* origin.
    const openerHost = hostOfUrl(guest.getURL())
    const policy = getSitePolicy(openerHost)
    if (policy === 'block') {
      emitPopupBlocked(ctl, openerHost)
      return { action: 'deny' }
    }
    // Popup-featured window.open (or Chromium's own 'new-window'
    // disposition), a blank/empty window.open (identity popups), or an
    // Allowed origin all become a real child BrowserWindow. The shared
    // BrowserView backs every in-app tab, so routing a popup into that tab
    // strip instead pushes the current page out of view, and the popup's own
    // `window.close()` then bubbles up to the *window* hosting that shared
    // view — i.e. all of daf.neu — instead of closing just the popup
    // (OS-NEU-DAF-000).
    const size = popupFeatureSize(features)
    if (isBlankOpen || size || disposition === 'new-window' || policy === 'allow') {
      const parentWin = ctl?.win && !ctl.win.isDestroyed() ? ctl.win : undefined
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: size?.width || 480,
          height: size?.height || 600,
          parent: parentWin,
          modal: false,
          show: false,
          autoHideMenuBar: true,
          backgroundColor: '#ffffff',
          title: 'os.neu',
          icon: path.join(__dirname, '..', 'public', 'brand', 'os.neu-app.png'),
          webPreferences: {
            session: browseSession,
            contextIsolation: true,
            sandbox: false,
          },
        },
      }
    }
    // Plain target=_blank / foreground-tab without popup features → keep the
    // existing in-app tab behavior (WO-BROWSER-WINDOW-1), unchanged.
    emitBrowseOpenTab(ctl, url)
    return { action: 'deny' }
  })
  // The child BrowserWindow created above by the 'allow' action above needs
  // the same guest policy attached to its own webContents — auth links still
  // escape to the system browser, and a popup opened *from* a popup (nested)
  // still becomes its own child rather than hijacking this one. `ctl.win` here
  // is the popup window itself, so nav-tracking IPC sends below are harmless
  // no-ops (a bare popup has no preload/React listener for them).
  guest.on('did-create-window', (childWindow, details) => {
    const childCtl = {
      win: childWindow,
      view: null,
      dtView: null,
      lastGoodUrl: details?.url || '',
      restoring: false,
      pendingLoadFinish: null,
    }
    attachGuest(childWindow.webContents, childCtl)
    childWindow.once('ready-to-show', () => {
      if (!childWindow.isDestroyed()) childWindow.show()
    })
    // Belt-and-suspenders, matching createWindow()/createBrowserAppWindow(): if
    // ready-to-show never fires, don't leave the popup invisible forever.
    childWindow.webContents.once('did-finish-load', () => {
      if (!childWindow.isDestroyed() && !childWindow.isVisible()) childWindow.show()
    })
  })
  guest.on('will-redirect', (event, url) => {
    if (/^(https?:|about:)/i.test(url)) return
    event.preventDefault()
  })
  guest.on('did-fail-load', (_event, code, _desc, failedUrl, isMain) => {
    if (!isMain || code === -3 || ctl.restoring) return
    if (isAuthUrl(failedUrl)) return
    // Never bounce a failed loopback (e.g. Ollama :11434) back to the last public site.
    if (isLoopbackUrl(failedUrl)) return
    if (ctl.lastGoodUrl && failedUrl !== ctl.lastGoodUrl) {
      ctl.restoring = true
      void guest.loadURL(ctl.lastGoodUrl).finally(() => {
        ctl.restoring = false
      })
    }
  })
  guest.on('did-navigate', (_event, url) => {
    if (ctl.restoring) return
    if (/^https?:\/\//i.test(url) && !isAuthUrl(url) && !isLoopbackUrl(url)) ctl.lastGoodUrl = url
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('did-navigate-in-page', (_event, url, isMainFrame) => {
    if (!isMainFrame || ctl.restoring) return
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('did-redirect-navigation', (_event, url, isInPlace, isMainFrame) => {
    if (!isMainFrame || ctl.restoring) return
    emitBrowseNavigated(ctl, url, guest.getTitle?.())
  })
  guest.on('page-title-updated', (_event, title) => {
    if (ctl.restoring) return
    emitBrowseNavigated(ctl, guest.getURL(), title)
  })
}

/** Registers a fresh browsing controller for `bw` and cleans it up on close. */
function makeController(bw) {
  /** @type {BrowseController} */
  const ctl = { win: bw, view: null, dtView: null, lastGoodUrl: '', restoring: false, pendingLoadFinish: null }
  controllers.set(bw.id, ctl)
  bw.on('closed', () => controllers.delete(bw.id))
  return ctl
}

/** Gives a browsing controller its own BrowserView, attached to its own window. */
function attachBrowseView(ctl) {
  const view = new BrowserView({
    webPreferences: {
      session: browseSession,
      contextIsolation: true,
      sandbox: false,
      javascript: true,
      images: true,
      webviewTag: false,
    },
  })
  view.setBackgroundColor('#ffffff')
  ctl.win.addBrowserView(view)
  view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  ctl.view = view
  attachGuest(view.webContents, ctl)
  return view
}

/**
 * "New window" (WO-BROWSER-WINDOW-1 follow-up, issue B1): a bare BrowserWindow
 * loading the raw target page has no address bar, tabs, or bookmarks — "no
 * functionability" per Leader's verify. Real parity with the primary window
 * means loading *our own renderer* (same as `createWindow`) in a second
 * window, routed straight to the browser phase with its target pre-opened —
 * it gets the full `LandingBrowser`/`BrowserChrome` UI (tabs, address bar,
 * bookmarks, history) for free, backed by its own BrowserView/controller so
 * it never fights the primary window's shared view.
 *
 * WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): titled `os.neu` this stacked
 * with the primary window's own `os.neu` StatusBar and Chrome's omnibox —
 * three address surfaces, "어느 URL을 치나" (Leader capture, Control NOTE
 * 2026-09-12). Title this `daf.neu` instead (this window *is* the product
 * browser), and parent it to the primary os.neu window so it opens in front
 * of it, closes independently, and is never mistaken for a second os.neu
 * desktop. Not modal (parent stays interactive/visible) and not
 * alwaysOnTop (only above its own parent, not every app).
 */
function createBrowserAppWindow(initialUrl) {
  const child = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 480,
    minHeight: 540,
    backgroundColor: '#0b0c0a',
    icon: path.join(__dirname, '..', 'public', 'brand', 'os.neu-app.png'),
    title: 'daf.neu',
    show: false,
    autoHideMenuBar: true,
    resizable: true,
    maximizable: true,
    fullscreenable: true,
    parent: win && !win.isDestroyed() ? win : undefined,
    modal: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  const ctl = makeController(child)
  attachBrowseView(ctl)

  // Electron syncs a BrowserWindow's native title to its page's
  // `document.title` by default — our own renderer's <title> is the static
  // "os.neu v1.0" from index.html, which would silently clobber the
  // `title: 'daf.neu'` above the instant this window's page finishes
  // loading. Lock it so the OS-level title bar / taskbar entry for this
  // window stays `daf.neu` (the whole point of UI-B17: one product name per
  // window, no more stacked "os.neu" surfaces).
  child.on('page-title-updated', (event) => {
    event.preventDefault()
  })

  let target
  try {
    target = new URL(DEV)
  } catch {
    target = new URL('http://127.0.0.1:5173')
  }
  target.searchParams.set('go', 'landing')
  if (initialUrl) target.searchParams.set('openTarget', initialUrl)
  void child.loadURL(target.toString())
  child.once('ready-to-show', () => {
    child.show()
    child.focus()
    child.moveTop()
  })
  // Belt-and-suspenders: if `ready-to-show` never fires (e.g. renderer load
  // error), don't leave the window invisible forever — same fallback the
  // primary window uses in createWindow().
  child.webContents.once('did-finish-load', () => {
    if (!child.isDestroyed() && !child.isVisible()) {
      child.show()
      child.focus()
      child.moveTop()
    }
  })
  return child
}

function createWindow() {
  const ua = chromeUA()
  app.userAgentFallback = ua
  session.defaultSession.setUserAgent(ua)
  session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(
      permission === 'media' ||
        permission === 'notifications' ||
        permission === 'clipboard-sanitized-write' ||
        permission === 'fullscreen' ||
        permission === 'pointerLock' ||
        permission === 'storage-access',
    )
  })
  browseSession = session.fromPartition('persist:neuos-browse')
  browseSession.setUserAgent(ua)
  browseSession.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(
      permission === 'media' ||
        permission === 'notifications' ||
        permission === 'clipboard-sanitized-write' ||
        permission === 'fullscreen' ||
        permission === 'pointerLock' ||
        permission === 'storage-access',
    )
  })

  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 480,
    minHeight: 540,
    backgroundColor: '#0b0c0a',
    icon: path.join(__dirname, '..', 'public', 'brand', 'os.neu-app.png'),
    title: 'os.neu',
    show: true,
    autoHideMenuBar: true,
    resizable: true,
    maximizable: true,
    fullscreenable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })

  const ctl = makeController(win)
  attachBrowseView(ctl)
  watchDownloads(browseSession)
  win.on('closed', () => {
    win = null
  })

  void win.loadURL(DEV)
  win.once('ready-to-show', () => {
    win?.show()
    win?.focus()
    if (process.env.NEUOS_SCREEN === '1') win?.maximize()
  })
  if (process.env.NEUOS_SCREEN === '1') {
    win.maximize()
  }
  win.show()
  win.focus()
}

function uniqueSavePath(filename) {
  const dir = app.getPath('downloads')
  const ext = path.extname(filename)
  const base = path.basename(filename, ext) || 'download'
  let dest = path.join(dir, filename || 'download')
  let i = 1
  while (fs.existsSync(dest)) {
    dest = path.join(dir, `${base} (${i})${ext}`)
    i += 1
  }
  return dest
}

function emitDownload(rec) {
  // Downloads happen on the shared browsing session's partition regardless
  // of which window's view triggered them — broadcast to every open os.neu
  // browser window's renderer so each one's download panel stays in sync.
  for (const ctl of controllers.values()) {
    if (ctl.win && !ctl.win.isDestroyed()) ctl.win.webContents.send('browse:download', rec)
  }
}

function watchDownloads(sess) {
  if (!sess || sess.__neuosDownloads) return
  sess.__neuosDownloads = true
  sess.on('will-download', (_event, item) => {
    const id = `dl-${Date.now()}-${downloadSeq}`
    downloadSeq += 1
    const rec = {
      id,
      filename: item.getFilename() || 'download',
      url: item.getURL(),
      path: uniqueSavePath(item.getFilename() || 'download'),
      mime: item.getMimeType(),
      bytes: item.getTotalBytes() || 0,
      received: 0,
      state: 'progress',
      t: Date.now(),
    }
    item.setSavePath(rec.path)
    downloads.set(id, { rec, item })
    emitDownload(rec)
    item.on('updated', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.bytes = item.getTotalBytes() || rec.bytes
      rec.state = state === 'interrupted' ? 'failed' : 'progress'
      emitDownload({ ...rec })
    })
    item.once('done', (_e, state) => {
      rec.received = item.getReceivedBytes()
      rec.state = state === 'completed' ? 'done' : state === 'cancelled' ? 'cancelled' : 'failed'
      emitDownload({ ...rec })
    })
  })
}

function ensureDevTools(ctl) {
  if (!ctl?.win || !ctl.view) return
  if (!ctl.dtView) {
    const dtView = new BrowserView({
      webPreferences: {
        sandbox: false,
        contextIsolation: true,
      },
    })
    dtView.setBackgroundColor('#1b1c17')
    ctl.win.addBrowserView(dtView)
    dtView.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    ctl.dtView = dtView
  }
  ctl.view.webContents.setDevToolsWebContents(ctl.dtView.webContents)
}

function hideDevTools(ctl) {
  ctl?.dtView?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  if (ctl?.view?.webContents.isDevToolsOpened()) ctl.view.webContents.closeDevTools()
}

// Only one navigation can be in flight on a given window's BrowserView at a
// time. If a newer loadInView() call supersedes an older one (e.g. quickly
// typing a URL in tab A then switching/navigating tab B before A finishes),
// Chromium aborts A's load with did-fail-load code -3 (ERR_ABORTED).
// Previously that was silently ignored, so A's promise never resolved and
// its tab stayed stuck on "loading" forever — the caller had to hit Reload
// to recover (reported while verifying WO-BROWSER-SESSION-1). Track the
// pending finish() on the controller so a superseded call resolves
// immediately instead of hanging.
function loadInView(ctl, url) {
  return new Promise((resolve) => {
    if (!ctl?.view) {
      resolve({ ok: false, reason: 'no-view' })
      return
    }
    if (ctl.pendingLoadFinish) {
      const superseded = ctl.pendingLoadFinish
      ctl.pendingLoadFinish = null
      superseded({ ok: false, reason: 'superseded' })
    }
    const wc = ctl.view.webContents
    const finish = (payload) => {
      wc.removeListener('did-finish-load', onOk)
      wc.removeListener('did-fail-load', onFail)
      if (ctl.pendingLoadFinish === finish) ctl.pendingLoadFinish = null
      resolve(payload)
    }
    ctl.pendingLoadFinish = finish
    const onFail = (_e, code, desc, failedUrl, isMain) => {
      if (!isMain) return
      // Aborted because a newer navigation superseded this one — already
      // resolved above; nothing left to do for this stale request.
      if (code === -3) return
      if (isAuthUrl(failedUrl) || isAuthUrl(url)) {
        finish({ ok: false, reason: desc || String(code), href: failedUrl })
        return
      }
      // Loopback failures must not silently restore www.neuavenue.com.
      if (isLoopbackUrl(url) || isLoopbackUrl(failedUrl)) {
        finish({ ok: false, reason: desc || String(code), href: failedUrl || url })
        return
      }
      if (ctl.lastGoodUrl && failedUrl !== ctl.lastGoodUrl) {
        ctl.restoring = true
        void wc.loadURL(ctl.lastGoodUrl).finally(() => {
          ctl.restoring = false
        })
        finish({ ok: true, href: ctl.lastGoodUrl, restored: true, reason: desc || String(code) })
        return
      }
      finish({ ok: false, reason: desc || String(code), href: failedUrl })
    }
    const onOk = () => {
      const href = wc.getURL()
      if (!href || href === 'about:blank') {
        finish({ ok: true, href: url })
        return
      }
      if (/^https?:\/\//i.test(href) && !isAuthUrl(href) && !isLoopbackUrl(href)) ctl.lastGoodUrl = href
      finish({ ok: true, href })
    }
    wc.on('did-finish-load', onOk)
    wc.on('did-fail-load', onFail)
    void wc.loadURL(url, { userAgent: chromeUA() })
  })
}

ipcMain.handle('browse:go', async (evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, reason: 'http(s) only' }
  }
  return loadInView(controllerForSender(evt.sender), url)
})

ipcMain.handle('browse:back', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  if (hist?.canGoBack?.()) {
    hist.goBack()
    return { ok: true, href: wc.getURL() }
  }
  if (wc.canGoBack()) {
    wc.goBack()
    return { ok: true, href: wc.getURL() }
  }
  if (ctl.lastGoodUrl) {
    return loadInView(ctl, ctl.lastGoodUrl)
  }
  return { ok: false, reason: 'no-back' }
})

ipcMain.handle('browse:forward', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  if (hist?.canGoForward?.()) {
    hist.goForward()
    return { ok: true, href: wc.getURL() }
  }
  if (typeof wc.canGoForward === 'function' && wc.canGoForward()) {
    wc.goForward()
    return { ok: true, href: wc.getURL() }
  }
  return { ok: false, reason: 'no-forward' }
})

ipcMain.handle('browse:reload', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  ctl.view.webContents.reload()
  return { ok: true, href: ctl.view.webContents.getURL() }
})

ipcMain.handle('browse:zoom', async (evt, delta) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const cur = wc.getZoomFactor()
  let next = cur
  if (delta === 'in') next = Math.min(3, cur + 0.1)
  else if (delta === 'out') next = Math.max(0.5, cur - 0.1)
  else if (delta === 'reset') next = 1
  else if (typeof delta === 'number' && Number.isFinite(delta)) next = Math.min(3, Math.max(0.5, delta))
  wc.setZoomFactor(next)
  return { ok: true, zoom: next }
})

ipcMain.handle('browse:nav', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false }
  const wc = ctl.view.webContents
  const hist = wc.navigationHistory
  return {
    ok: true,
    href: wc.getURL(),
    canGoBack: Boolean(hist?.canGoBack?.() ?? wc.canGoBack?.()),
    canGoForward: Boolean(hist?.canGoForward?.() ?? wc.canGoForward?.()),
    zoom: wc.getZoomFactor(),
  }
})

// Guards against a single "New window" click spawning two windows. Some
// input stacks (touch-emulated click, fast pointerdown+click pairs under
// Wayland) can replay one logical click as two IPC invokes a few ms apart;
// without this a user reported two windows opening per click (Leader
// verify, 2026-09-02). Keyed per-sender so distinct windows/tabs never
// dedupe each other's legitimate calls.
const newWindowGuard = new WeakMap()
const NEW_WINDOW_DEBOUNCE_MS = 800

ipcMain.handle('browse:newWindow', async (evt, url) => {
  const now = Date.now()
  const last = newWindowGuard.get(evt.sender) || 0
  if (now - last < NEW_WINDOW_DEBOUNCE_MS) {
    return { ok: true, deduped: true }
  }
  newWindowGuard.set(evt.sender, now)
  // Auth hosts (Google/Microsoft/Apple/GitHub login) must never load inside an
  // embedded Electron window — route to the system browser instead
  // (WO-BROWSER-WINDOW-1 / Google OAuth policy).
  if (isAuthUrl(url)) {
    await shell.openExternal(url)
    return { ok: true, external: true }
  }
  const href = typeof url === 'string' && /^https?:\/\//i.test(url) ? url : WEB_HOME
  // Full parity with the primary window's browser — real tabs, address bar,
  // bookmarks — not a bare page (WO-BROWSER-WINDOW-1 follow-up, issue B1):
  // load our own renderer in a second window instead of the raw target.
  createBrowserAppWindow(href)
  return { ok: true }
})

ipcMain.handle('browse:hide', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  ctl?.view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
  hideDevTools(ctl)
  return { ok: true }
})

ipcMain.handle('browse:snapshot', async (evt) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view) return { ok: false, reason: 'no-view' }
  const box = ctl.view.getBounds()
  if (box.width < 8 || box.height < 8) return { ok: false, reason: 'hidden' }
  try {
    const img = await ctl.view.webContents.capturePage()
    if (img.isEmpty()) return { ok: false, reason: 'empty' }
    return {
      ok: true,
      dataUrl: img.toDataURL(),
      href: ctl.view.webContents.getURL() || ctl.lastGoodUrl || undefined,
    }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'capture-failed' }
  }
})

function xfoBlocksFrames(value) {
  if (!value) return false
  const v = String(value).toLowerCase()
  return v.includes('deny') || v.includes('sameorigin') || v.includes('allow-from')
}

function cspBlocksFrames(value) {
  if (!value) return false
  const match = /frame-ancestors\s+([^;]+)/i.exec(String(value))
  if (!match) return false
  const tokens = match[1].trim().toLowerCase().split(/\s+/)
  if (tokens.includes("'none'") || tokens.includes('none')) return true
  if (tokens.includes('*')) return false
  return true
}

ipcMain.handle('browse:framePolicy', async (_evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, blocked: true, reason: 'bad-url' }
  }
  return await new Promise((resolve) => {
    let done = false
    const finish = (payload) => {
      if (done) return
      done = true
      resolve(payload)
    }
    const timer = setTimeout(() => finish({ ok: false, blocked: true, reason: 'timeout' }), 4000)
    try {
      const req = net.request({ method: 'GET', url, redirect: 'follow' })
      req.on('response', (res) => {
        const headers = res.headers || {}
        const xfo = headers['x-frame-options']
        const csp = headers['content-security-policy']
        const xfoVal = Array.isArray(xfo) ? xfo.join(' ') : xfo
        const cspVal = Array.isArray(csp) ? csp.join(' ') : csp
        try {
          req.abort()
        } catch {
          /* already closed */
        }
        clearTimeout(timer)
        const blocked = xfoBlocksFrames(xfoVal) || cspBlocksFrames(cspVal)
        finish({
          ok: true,
          blocked,
          reason: blocked ? (xfoVal ? 'x-frame-options' : 'csp') : 'allow',
        })
      })
      req.on('error', (err) => {
        clearTimeout(timer)
        finish({ ok: false, blocked: true, reason: err instanceof Error ? err.message : 'net-error' })
      })
      req.end()
    } catch (err) {
      clearTimeout(timer)
      finish({ ok: false, blocked: true, reason: err instanceof Error ? err.message : 'request-failed' })
    }
  })
})

// WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND — renderer reads/writes the
// per-origin Default | Allow | Block choice from the address-bar site panel.
ipcMain.handle('browse:sitePolicy:get', async (_evt, url) => {
  const host = hostOfUrl(url)
  return { ok: true, host, policy: getSitePolicy(host) }
})

ipcMain.handle('browse:sitePolicy:set', async (_evt, payload) => {
  const host = hostOfUrl(payload?.url)
  const policy = payload?.policy
  if (!host) return { ok: false, reason: 'bad-url' }
  if (policy !== 'default' && policy !== 'allow' && policy !== 'block') {
    return { ok: false, reason: 'bad-policy' }
  }
  setSitePolicy(host, policy)
  return { ok: true, host, policy: getSitePolicy(host) }
})

ipcMain.handle('browse:openExternal', async (_evt, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return { ok: false, reason: 'http(s) only' }
  }
  await shell.openExternal(url)
  return { ok: true }
})

ipcMain.handle('browse:bounds', async (evt, rect) => {
  const ctl = controllerForSender(evt.sender)
  if (!ctl?.view || !rect) return { ok: false }
  const width = Math.max(0, Math.round(rect.width))
  const height = Math.max(0, Math.round(rect.height))
  if (width < 8 || height < 8) {
    ctl.view.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    return { ok: true, hidden: true }
  }
  ctl.view.setBounds({
    x: Math.round(rect.x),
    y: Math.round(rect.y),
    width,
    height,
  })
  return { ok: true }
})

ipcMain.handle('browse:devtools', async (evt, rect) => {
  const ctl = controllerForSender(evt.sender)
  const width = Math.max(0, Math.round(rect?.width || 0))
  const height = Math.max(0, Math.round(rect?.height || 0))
  if (!rect || width < 8 || height < 8) {
    hideDevTools(ctl)
    return { ok: true, hidden: true }
  }
  ensureDevTools(ctl)
  if (!ctl?.dtView || !ctl.view) return { ok: false }
  ctl.dtView.setBounds({
    x: Math.round(rect.x),
    y: Math.round(rect.y),
    width,
    height,
  })
  if (!ctl.view.webContents.isDevToolsOpened()) {
    ctl.view.webContents.openDevTools()
  }
  return { ok: true }
})

ipcMain.handle('browse:download-open', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  const err = await shell.openPath(row.rec.path)
  return { ok: !err }
})

ipcMain.handle('browse:download-show', async (_evt, id) => {
  const row = downloads.get(String(id))
  if (!row?.rec?.path) return { ok: false }
  shell.showItemInFolder(row.rec.path)
  return { ok: true }
})

ipcMain.handle('files:save', async (_evt, payload) => {
  if (!win || !payload) return { ok: false }
  const filters = Array.isArray(payload.filters) ? payload.filters : [{ name: 'Text', extensions: ['txt'] }]
  const result = await dialog.showSaveDialog(win, {
    title: 'Save document',
    defaultPath: typeof payload.defaultPath === 'string' ? payload.defaultPath : 'document.txt',
    filters,
  })
  if (result.canceled || !result.filePath) return { ok: false, reason: 'cancelled' }
  try {
    if (Array.isArray(payload.bytes)) {
      fs.writeFileSync(result.filePath, Buffer.from(payload.bytes))
    } else {
      fs.writeFileSync(result.filePath, String(payload.text || ''), 'utf8')
    }
    return { ok: true, path: result.filePath }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'write-failed' }
  }
})

ipcMain.handle('plant:pick', async () => {
  if (!win) return { ok: false }
  const result = await dialog.showOpenDialog(win, {
    title: 'os.neu folder',
    defaultPath: path.join(app.getPath('home'), 'os.neu'),
    properties: ['openDirectory', 'createDirectory'],
  })
  if (result.canceled || !result.filePaths[0]) return { ok: false }
  return { ok: true, path: result.filePaths[0] }
})

// Resolves to the window that actually sent the IPC call, not always the
// primary `win` — every secondary "New window" instance renders its own
// StatusBar with this same resize/fullscreen button, but the handlers below
// used to always act on the primary window regardless of sender, so the
// button silently did nothing from a secondary window (reported 2026-09-02).
function windowForSender(sender) {
  const bw = BrowserWindow.fromWebContents(sender)
  return bw && !bw.isDestroyed() ? bw : win
}

ipcMain.handle('app:fullscreen', async (evt, on) => {
  const target = windowForSender(evt.sender)
  if (typeof on === 'boolean') target?.setFullScreen(on)
  return { ok: true, fullscreen: Boolean(target?.isFullScreen()), maximized: Boolean(target?.isMaximized()) }
})

ipcMain.handle('app:window', async (evt, mode) => {
  const target = windowForSender(evt.sender)
  if (mode === 'windowed') {
    target?.setFullScreen(false)
    target?.unmaximize()
    target?.setSize(1280, 800)
    target?.center()
  } else if (mode === 'maximized') {
    target?.setFullScreen(false)
    target?.maximize()
  } else if (mode === 'fullscreen') {
    target?.setFullScreen(true)
  }
  return {
    ok: true,
    fullscreen: Boolean(target?.isFullScreen()),
    maximized: Boolean(target?.isMaximized()),
  }
})

/** File→Quit / Exit Quit: close this window only. Last window → window-all-closed. */
function closeSenderWindow(target) {
  const bw = target && !target.isDestroyed() ? target : win
  if (!bw || bw.isDestroyed()) return
  const ctl = controllers.get(bw.id)
  if (ctl) {
    ctl.view?.setBounds({ x: 0, y: 0, width: 0, height: 0 })
    hideDevTools(ctl)
  }
  try {
    bw.setFullScreen(false)
  } catch {
    /* already gone */
  }
  bw.close()
}

function guestOf(bw) {
  const ctl = bw && controllers.get(bw.id)
  const guest = ctl?.view?.webContents
  return guest && !guest.isDestroyed() ? guest : null
}

function goBackContents(nav) {
  if (!nav || nav.isDestroyed()) return
  if (typeof nav.canGoBack === 'function' && nav.canGoBack()) nav.goBack()
}

function chromeMenuTemplate(ownerWin, nav) {
  return [
    {
      label: 'File',
      submenu: [
        {
          label: 'Back',
          accelerator: process.platform === 'darwin' ? 'Cmd+[' : 'Alt+Left',
          click: (_item, focused) => {
            const bw =
              (ownerWin && !ownerWin.isDestroyed() && ownerWin) ||
              (focused && !focused.isDestroyed() && focused) ||
              BrowserWindow.getFocusedWindow() ||
              win
            const clicked = nav && !nav.isDestroyed() ? nav : null
            const guest = guestOf(bw)
            goBackContents(clicked || guest || bw?.webContents || null)
          },
        },
        {
          label: 'Quit',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: (_item, focused) => {
            const target =
              (ownerWin && !ownerWin.isDestroyed() && ownerWin) ||
              (focused && !focused.isDestroyed() && focused) ||
              BrowserWindow.getFocusedWindow() ||
              win
            closeSenderWindow(target)
          },
        },
      ],
    },
    { role: 'editMenu' },
    { role: 'viewMenu' },
    { role: 'windowMenu' },
  ]
}

function popupChromeMenu(contents, params) {
  if (!contents || contents.isDestroyed()) return
  const url = String(contents.getURL?.() || '')
  if (url.startsWith('devtools:')) return
  const owner =
    BrowserWindow.fromWebContents(contents) ||
    BrowserWindow.getFocusedWindow() ||
    win
  if (!owner || owner.isDestroyed()) return
  const menu = Menu.buildFromTemplate(chromeMenuTemplate(owner, contents))
  let x = params.x
  let y = params.y
  const ctl = controllers.get(owner.id)
  const guest = ctl?.view?.webContents
  if (ctl?.view && guest && contents === guest) {
    const box = ctl.view.getBounds()
    x += box.x
    y += box.y
  }
  menu.popup({ window: owner, x, y })
}

function installAppMenu() {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate(chromeMenuTemplate(BrowserWindow.getFocusedWindow() || win, null)),
  )
}

function installChromeContextMenus() {
  app.on('web-contents-created', (_event, contents) => {
    contents.on('context-menu', (_e, params) => {
      popupChromeMenu(contents, params)
    })
  })
}

ipcMain.handle('app:quit', async (evt) => {
  closeSenderWindow(windowForSender(evt.sender))
  return { ok: true }
})

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', (_event, commandLine) => {
    const deep = findProtocolUrl(commandLine)
    if (deep) deliverOAuthDeepLink(deep)
    // Always raise the shell — even if the deep link only asks to focus.
    focusMainWindow()
  })

  app.on('open-url', (event, url) => {
    event.preventDefault()
    deliverOAuthDeepLink(url)
  })

  app.whenReady().then(() => {
    loadSitePolicy()
    installChromeContextMenus()
    installAppMenu()
    createWindow()
    const deep = findProtocolUrl(process.argv)
    if (deep) {
      win?.webContents.once('did-finish-load', () => {
        deliverOAuthDeepLink(deep)
      })
    }
  })

  app.on('window-all-closed', () => {
    app.quit()
  })
}
