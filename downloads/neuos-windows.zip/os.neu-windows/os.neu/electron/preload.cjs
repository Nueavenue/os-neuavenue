const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('neuos', {
  browse: {
    go: (url) => ipcRenderer.invoke('browse:go', url),
    hide: () => ipcRenderer.invoke('browse:hide'),
    bounds: (rect) => ipcRenderer.invoke('browse:bounds', rect),
    back: () => ipcRenderer.invoke('browse:back'),
    forward: () => ipcRenderer.invoke('browse:forward'),
    reload: () => ipcRenderer.invoke('browse:reload'),
    zoom: (delta) => ipcRenderer.invoke('browse:zoom', delta),
    nav: () => ipcRenderer.invoke('browse:nav'),
    newWindow: (url) => ipcRenderer.invoke('browse:newWindow', url),
    snapshot: () => ipcRenderer.invoke('browse:snapshot'),
    framePolicy: (url) => ipcRenderer.invoke('browse:framePolicy', url),
    openExternal: (url) => ipcRenderer.invoke('browse:openExternal', url),
    onDownload: (cb) => {
      const listen = (_event, row) => cb(row)
      ipcRenderer.on('browse:download', listen)
      return () => ipcRenderer.removeListener('browse:download', listen)
    },
    onNavigated: (cb) => {
      const listen = (_event, payload) => cb(payload)
      ipcRenderer.on('browse:navigated', listen)
      return () => ipcRenderer.removeListener('browse:navigated', listen)
    },
    onOpenTab: (cb) => {
      const listen = (_event, payload) => cb(payload)
      ipcRenderer.on('browse:open-tab', listen)
      return () => ipcRenderer.removeListener('browse:open-tab', listen)
    },
    openDownload: (id) => ipcRenderer.invoke('browse:download-open', id),
    showDownload: (id) => ipcRenderer.invoke('browse:download-show', id),
    devtools: (rect) => ipcRenderer.invoke('browse:devtools', rect),
    sitePolicy: {
      get: (url) => ipcRenderer.invoke('browse:sitePolicy:get', url),
      set: (url, policy) => ipcRenderer.invoke('browse:sitePolicy:set', { url, policy }),
    },
    onPopupBlocked: (cb) => {
      const listen = (_event, payload) => cb(payload)
      ipcRenderer.on('browse:popup-blocked', listen)
      return () => ipcRenderer.removeListener('browse:popup-blocked', listen)
    },
  },
  auth: {
    onOAuth: (cb) => {
      const listen = (_event, payload) => cb(payload)
      ipcRenderer.on('auth:oauth', listen)
      return () => ipcRenderer.removeListener('auth:oauth', listen)
    },
  },
  plant: {
    pick: () => ipcRenderer.invoke('plant:pick'),
    defaultPath: () => ipcRenderer.invoke('plant:default'),
  },
  files: {
    save: (payload) => ipcRenderer.invoke('files:save', payload),
  },
  quit: () => ipcRenderer.invoke('app:quit'),
  setFullscreen: (on) => ipcRenderer.invoke('app:fullscreen', on),
  windowState: () => ipcRenderer.invoke('app:window'),
  windowMode: () => ipcRenderer.invoke('app:window'),
  setWindowMode: (mode) => ipcRenderer.invoke('app:window', mode),
})
