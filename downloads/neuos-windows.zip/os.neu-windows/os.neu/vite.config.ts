import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig, type Plugin } from 'vite'

const rootDir = path.dirname(fileURLToPath(import.meta.url))

/** Serve public/*.html before SPA fallback (fixes /preview, /landing-samples). */
function servePublicHtml(): Plugin {
  return {
    name: 'serve-public-html',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const raw = req.url?.split('?')[0] ?? ''
        if (!raw || raw.startsWith('/@') || raw.startsWith('/src') || raw.startsWith('/node_modules')) {
          return next()
        }
        let rel = decodeURIComponent(raw)
        if (rel.endsWith('/')) rel += 'index.html'
        if (!rel.endsWith('.html')) return next()
        const abs = path.join(rootDir, 'public', rel)
        if (!abs.startsWith(path.join(rootDir, 'public'))) return next()
        if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return next()
        res.statusCode = 200
        res.setHeader('Content-Type', 'text/html; charset=utf-8')
        fs.createReadStream(abs).pipe(res)
      })
    },
  }
}

export default defineConfig({
  plugins: [react(), servePublicHtml()],
  build: {
    outDir: 'dist-web',
    emptyOutDir: true,
  },
  server: {
    host: true,
    port: 5173,
    watch: {
      usePolling: true,
      interval: 1000,
    },
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
  preview: {
    host: true,
    port: 4177,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4178',
        changeOrigin: true,
      },
    },
  },
})
