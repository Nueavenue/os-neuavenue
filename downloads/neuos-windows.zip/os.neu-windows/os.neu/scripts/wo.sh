#!/usr/bin/env bash
# Run work-order scripts from any directory.
# Usage:
#   ./scripts/wo.sh regen
#   ./scripts/wo.sh export --index-only
#   ./scripts/wo.sh export --incomplete --index-only
#   ./scripts/wo.sh export --issue-id BR-CHROME
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

cmd="${1:-help}"
shift || true

case "$cmd" in
  regen|generate)
    exec python3 "$ROOT/scripts/generate-work-orders.py" "$@"
    ;;
  export)
    exec python3 "$ROOT/scripts/export-work-orders.py" "$@"
    ;;
  registry)
    exec python3 "$ROOT/scripts/generate-doc-registry.py" "$@"
    ;;
  help|--help|-h)
    cat <<EOF
os.neu work-order CLI (repo: $ROOT)

  wo.sh regen              Regenerate docs/work-orders.md from transcript
  wo.sh export [opts]      Export CSV (same flags as export-work-orders.py)
  wo.sh registry           Feature spec + doc catalog + verification

Examples:
  $ROOT/scripts/wo.sh regen
  $ROOT/scripts/wo.sh export --index-only
  $ROOT/scripts/wo.sh export --incomplete --index-only
  $ROOT/scripts/wo.sh export --issue-id AUTH-OAUTH

Must run from repo — NOT from ~/Downloads.
Repo path: $ROOT
EOF
    ;;
  *)
    echo "Unknown command: $cmd (try: regen | export | registry | help)" >&2
    exit 1
    ;;
esac
