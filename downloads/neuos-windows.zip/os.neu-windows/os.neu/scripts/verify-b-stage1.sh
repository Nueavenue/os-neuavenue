#!/usr/bin/env bash
# Plan B stage 1 — host Ubuntu rehearsal. Does not wipe disks. Does not change GRUB.
# Does not write the USB stick. Optional: --install (apt cage+seatd only).
set -euo pipefail
if [[ "$(uname -s)" != "Linux" ]]; then
  echo "Stage 1 is Linux only." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KIOSK="$ROOT/runtime/kiosk"
INSTALL=0
if [[ "${1:-}" == "--install" ]]; then
  INSTALL=1
fi

ok=0
miss=0
fail() { echo "FAIL  $*"; miss=$((miss + 1)); }
pass() { echo "PASS  $*"; ok=$((ok + 1)); }
note() { echo "NOTE  $*"; }

echo "os.neu Plan B stage 1 (Ubuntu sandbox)"
echo "tree: $ROOT"
echo

if ((INSTALL)); then
  if [[ "$(id -u)" != "0" ]]; then
    echo " --install needs root: sudo bash $ROOT/scripts/verify-b-stage1.sh --install" >&2
    exit 1
  fi
  apt-get update -qq
  apt-get install -y cage seatd
fi

export PATH="${HOME}/.local/bin:${KIOSK}:${PATH}"
if [[ -d "$KIOSK/lib" ]]; then
  export LD_LIBRARY_PATH="${KIOSK}/lib:${KIOSK}/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
fi

if command -v cage >/dev/null; then pass "cage $(command -v cage)"
elif [[ -x "$KIOSK/cage" ]]; then pass "cage $KIOSK/cage (runtime/kiosk)"
else fail "cage missing — bash $ROOT/scripts/stage1-host.sh   or  sudo apt install -y cage seatd"; fi

if command -v seatd >/dev/null; then pass "seatd $(command -v seatd)"
elif [[ -x "$KIOSK/seatd" ]]; then pass "seatd $KIOSK/seatd (runtime/kiosk)"
else fail "seatd missing — bash $ROOT/scripts/stage1-host.sh   or  sudo apt install -y cage seatd"; fi

if [[ -x "$ROOT/node_modules/.bin/electron" ]]; then
  pass "Electron $ROOT/node_modules/.bin/electron"
elif [[ -x "$HOME/os.neu/node_modules/.bin/electron" ]]; then
  pass "Electron $HOME/os.neu/node_modules/.bin/electron"
else
  fail "Electron missing under $ROOT or ~/os.neu"
fi

if [[ -e /dev/dri/card0 || -e /dev/dri/card1 ]]; then
  pass "DRM $(ls /dev/dri/card* 2>/dev/null | tr '\n' ' ')"
else
  fail "/dev/dri/card* missing"
fi

fw=$(ls /lib/firmware/i915 2>/dev/null | wc -l)
if [[ "$fw" -gt 0 ]]; then pass "host i915 firmware blobs=$fw"
else fail "host /lib/firmware/i915 empty"; fi

if [[ -f /usr/share/wayland-sessions/os.neu.desktop ]]; then
  pass "GDM session /usr/share/wayland-sessions/os.neu.desktop"
elif [[ -f "$HOME/.local/share/wayland-sessions/os.neu.desktop" ]]; then
  pass "user Wayland session ~/.local/share/wayland-sessions/os.neu.desktop"
  note "GDM may still need: sudo bash $ROOT/scripts/install-osneu-session.sh"
else
  fail "GDM session missing — bash $ROOT/scripts/install-osneu-session.sh"
fi

if command -v ollama >/dev/null; then
  pass "ollama $(command -v ollama)"
elif [[ -x "$HOME/.local/bin/ollama" ]]; then
  pass "ollama $HOME/.local/bin/ollama"
  export PATH="$HOME/.local/bin:$PATH"
else
  fail "ollama missing — bash $ROOT/scripts/stage1-host.sh"
fi

if curl -sS -m 2 http://127.0.0.1:11434/api/tags >/tmp/osneu-ollama-tags.json 2>/dev/null; then
  pass "Ollama HTTP 127.0.0.1:11434"
  if grep -q 'llama3.2' /tmp/osneu-ollama-tags.json; then
    pass "model llama3.2 present"
  else
    fail "llama3.2:1b not pulled — ollama pull llama3.2:1b"
  fi
else
  fail "Ollama daemon not on 11434 — ollama serve"
fi

echo
echo "score pass=$ok fail=$miss"
if ((miss)); then
  echo
  echo "Next (this Ubuntu session, not USB):"
  echo "  bash $ROOT/scripts/stage1-host.sh"
  echo "  # optional system packages:"
  echo "  sudo apt install -y cage seatd"
  echo "  sudo bash $ROOT/scripts/install-osneu-session.sh"
  echo "  Log out. GDM gear → os.neu (not Ubuntu). Do not use --autologin until cage works."
  echo
  echo "Do not edit make-usb.sh for firmware/Electron until this score is all PASS."
  exit 2
fi

echo "Stage 1 host stack is present. Log out and pick GDM session os.neu."
echo "In the os.neu window, public/local AI should hit 127.0.0.1:11434 (boot/localLlm.mjs)."
