#!/usr/bin/env bash
# Open the os.neu screen (fullscreen Electron).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

complete_tree() {
  local dir="$1"
  [[ -f "$dir/electron/main.cjs" && -f "$dir/package.json" && -f "$dir/index.html" ]]
}

if ! complete_tree "$ROOT"; then
  for cand in "${NEUOS_EXEC_ROOT:-}" "$HOME/neuOS" /opt/neuos; do
    [[ -n "${cand:-}" && -d "$cand" ]] || continue
    if complete_tree "$cand"; then
      echo "os.neu: $ROOT is missing electron/main.cjs. Opening from $cand" >&2
      ROOT="$cand"
      break
    fi
  done
fi
if ! complete_tree "$ROOT"; then
  echo "os.neu: Electron app is not in $ROOT (missing electron/main.cjs)." >&2
  echo "This folder is not a full plant. From Ubuntu: bash ~/neuOS/scripts/open-neuos.sh" >&2
  exit 1
fi

cd "$ROOT"
ulimit -n 65536 2>/dev/null || true
PORT="${PORT:-5173}"
BRIDGE_PORT="${NEUOS_BRIDGE_PORT:-4178}"
export NEUOS_DRIVER=live
export NEUOS_SCREEN=1
GO="${NEUOS_GO:-}"
if [[ -n "$GO" ]]; then
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}/?go=${GO}"
else
  export NEUOS_DEV_URL="http://127.0.0.1:${PORT}"
fi

# One screen: block a second open-neuos/autostart while this one runs.
# Deep links (osneu://) must still reach the running Electron via second-instance.
LOCK_DIR="${XDG_RUNTIME_DIR:-/tmp}/osneu-screen.lock"
PROTOCOL_URL=""
for arg in "$@"; do
  case "$arg" in
    osneu://*) PROTOCOL_URL="$arg" ;;
  esac
done
if [[ -z "$PROTOCOL_URL" && -n "${NEUOS_PROTOCOL_URL:-}" ]]; then
  PROTOCOL_URL="$NEUOS_PROTOCOL_URL"
fi
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  if [[ -d "$LOCK_DIR" ]]; then
    old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
    if [[ -n "$old_pid" ]] && kill -0 "$old_pid" 2>/dev/null; then
      if [[ -n "$PROTOCOL_URL" ]]; then
        exec bash "$ROOT/scripts/osneu-protocol.sh" "$PROTOCOL_URL"
      fi
      echo "os.neu screen already open (pid $old_pid). One window only."
      exit 0
    fi
    rm -rf "$LOCK_DIR"
    mkdir "$LOCK_DIR"
  else
    echo "os.neu screen lock busy. One window only." >&2
    exit 0
  fi
fi
echo $$ > "$LOCK_DIR/pid"

OWNED_PIDS=()
cleanup() {
  if ((${#OWNED_PIDS[@]})); then
    kill "${OWNED_PIDS[@]}" 2>/dev/null || true
  fi
  rm -rf "$LOCK_DIR" 2>/dev/null || true
}
trap cleanup EXIT

healthy() {
  curl -sf "$1" >/dev/null
}

port_listen() {
  local port="$1"
  if command -v ss >/dev/null; then
    ss -ltn "sport = :${port}" 2>/dev/null | grep -q ":${port}"
  else
    lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
  fi
}

explain_busy() {
  local port="$1"
  echo "OS-NEU-SX-001  Port ${port} is in use but not serving os.neu. Stop that process and retry:" >&2
  lsof -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || ss -ltnp "sport = :${port}" || true
}

# OS-NEU-SX-001 (foreign-port variant): a 200 OK on 5173/4178 does not prove the
# answer came from THIS os.neu tree — Door A (Life-Force) or any other app can
# also listen there and pass a plain curl health check. Only ever reuse a port
# whose owner resolves to one of our own accepted trees ($ROOT or ~/neuOS SoT).
accepted_tree() {
  local candidate="$1"
  local resolved
  resolved="$(readlink -f "$candidate" 2>/dev/null || true)"
  [[ -n "$resolved" ]] || return 1
  local tree
  for tree in "$ROOT" "$HOME/neuOS"; do
    [[ "$resolved" == "$(readlink -f "$tree" 2>/dev/null || echo "$tree")" ]] && return 0
  done
  return 1
}

pid_for_port() {
  local port="$1"
  if command -v lsof >/dev/null; then
    lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -n1
  else
    ss -ltnp "sport = :${port}" 2>/dev/null | grep -oP 'pid=\K[0-9]+' | head -n1
  fi
}

owns_ui_port() {
  local port="$1"
  local pid cwd
  pid="$(pid_for_port "$port")"
  [[ -n "$pid" ]] || return 1
  cwd="$(readlink -f "/proc/${pid}/cwd" 2>/dev/null || true)"
  [[ -n "$cwd" ]] || return 1
  accepted_tree "$cwd"
}

owns_bridge_port() {
  local url="$1"
  local root
  root="$(curl -sf "$url" 2>/dev/null | jq -r '.root // empty' 2>/dev/null || true)"
  [[ -n "$root" ]] || return 1
  accepted_tree "$root"
}

explain_foreign() {
  local port="$1"
  local owner_detail="$2"
  echo "OS-NEU-SX-001  Port ${port} answers 200 but is not this os.neu tree (\$ROOT=${ROOT}). ${owner_detail}" >&2
  echo "Refusing to reuse — NOT loading Door A / a foreign app, NOT killing the foreign process. Stop it yourself or point this launch at the right tree, then retry." >&2
  lsof -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || ss -ltnp "sport = :${port}" || true
}

start_or_reuse() {
  local url="$1"
  local port="$2"
  local kind="$3" # "bridge" (checks /api/health root) or "ui" (checks LISTEN pid cwd)
  shift 3
  if healthy "$url"; then
    if [[ "$kind" == "bridge" ]]; then
      if owns_bridge_port "$url"; then
        echo "reusing ${url}"
        return 0
      fi
      local root
      root="$(curl -sf "$url" 2>/dev/null | jq -r '.root // "unknown"' 2>/dev/null || echo unknown)"
      explain_foreign "$port" "Owner root=${root}"
    else
      if owns_ui_port "$port"; then
        echo "reusing ${url}"
        return 0
      fi
      local pid cwd
      pid="$(pid_for_port "$port")"
      cwd="$(readlink -f "/proc/${pid}/cwd" 2>/dev/null || echo unknown)"
      explain_foreign "$port" "Owner pid=${pid:-unknown} cwd=${cwd}"
    fi
    exit 1
  fi
  if port_listen "$port"; then
    explain_busy "$port"
    exit 1
  fi
  "$@" &
  OWNED_PIDS+=("$!")
}

start_or_reuse "http://127.0.0.1:${BRIDGE_PORT}/api/health" "$BRIDGE_PORT" bridge \
  npx tsx server/index.ts
start_or_reuse "http://127.0.0.1:${PORT}" "$PORT" ui \
  npx vite --host 127.0.0.1 --port "$PORT" --strictPort

for _ in $(seq 1 80); do
  if healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" && healthy "http://127.0.0.1:${PORT}"; then
    break
  fi
  sleep 0.2
done

if ! healthy "http://127.0.0.1:${BRIDGE_PORT}/api/health" || ! healthy "http://127.0.0.1:${PORT}"; then
  echo "OS-NEU-SX-002  os.neu bridge/UI did not become ready on ${BRIDGE_PORT}/${PORT}" >&2
  exit 1
fi

# Keep the window in front of the terminal that launched it.
export ELECTRON_OZONE_PLATFORM_HINT="${ELECTRON_OZONE_PLATFORM_HINT:-auto}"
# Avoid Chromium “keyring could not be identified / weaker encryption” prompts.
if [[ -z "${CHROME_PASSWORD_STORE:-}" ]]; then
  if [[ -n "${GNOME_KEYRING_CONTROL:-}" ]] || pgrep -u "$(id -u)" -x gnome-keyring-d >/dev/null 2>&1; then
    export CHROME_PASSWORD_STORE=gnome-libsecret
  else
    export CHROME_PASSWORD_STORE=basic
  fi
fi
echo "Opening the os.neu window. This terminal waits until you close that window (×)."
LOG=/tmp/osneu-electron.log
started_at="$(date +%s)"
PROTOCOL_ARG=()
if [[ -n "${NEUOS_PROTOCOL_URL:-}" ]]; then
  PROTOCOL_ARG=("${NEUOS_PROTOCOL_URL}")
fi
for arg in "$@"; do
  case "$arg" in
    osneu://*) PROTOCOL_ARG=("$arg") ;;
  esac
done
set +e
npx electron . --no-sandbox --disable-gpu-sandbox --password-store="${CHROME_PASSWORD_STORE}" "${PROTOCOL_ARG[@]}" 2>"$LOG"
st=$?
set -e
elapsed=$(( $(date +%s) - started_at ))
if [[ "$st" -ne 0 ]]; then
  echo "Electron exited ${st}. Last lines from ${LOG}:" >&2
  tail -n 30 "$LOG" >&2 || true
  exit "$st"
fi
if [[ "$elapsed" -lt 3 ]]; then
  echo "The window closed in ${elapsed}s. That is not a successful screen. Log: ${LOG}" >&2
  tail -n 30 "$LOG" >&2 || true
  exit 1
fi
