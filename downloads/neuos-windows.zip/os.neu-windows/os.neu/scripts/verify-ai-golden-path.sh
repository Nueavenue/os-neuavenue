#!/usr/bin/env bash
# WO-AI-RELIABILITY-1 / G-AI-GOLDEN-1
# One Golden Path (OGP): Doc Word-skin -> select -> Ask AI rewrite -> save.
# This script proves step 3-4 only (the network+model leg): a scripted curl
# against the streaming office/assist endpoint must return non-empty text.
# G-AI-GOLDEN-2 (Leader manual Doc rewrite on Reliable tier) and save-to-disk
# are verified by hand, not by this script.
#
# Usage:
#   bash scripts/verify-ai-golden-path.sh                # auto-pick tier from bridge state
#   OGP_MODEL=gpt-4o-mini bash scripts/verify-ai-golden-path.sh   # force Reliable tier
#   OGP_MODEL=os.neu-local bash scripts/verify-ai-golden-path.sh  # force Experimental tier
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
BASE="${NEUOS_BRIDGE_URL:-http://127.0.0.1:4178}"

need() { command -v "$1" >/dev/null 2>&1 || { echo "FAIL: missing $1 on PATH"; exit 1; }; }
need curl
need jq

echo "== G-AI-GOLDEN-1: office/assist/stream curl check =="
echo "bridge: $BASE"

health="$(curl -fsS --max-time 5 "$BASE/api/health" 2>/dev/null || true)"
if [[ -z "$health" ]]; then
  echo "FAIL  OS-NEU-AI-000  bridge unreachable at $BASE/api/health"
  echo "      fix: npm run os   (or)   npm run dev"
  exit 1
fi
echo "PASS  bridge reachable"
echo "      $(echo "$health" | jq -c '{ok, llm, browse}')"

settings="$(curl -fsS --max-time 5 "$BASE/api/llm/settings" 2>/dev/null || true)"
if [[ -z "$settings" ]]; then
  echo "FAIL  OS-NEU-AI-000  /api/llm/settings unreachable"
  exit 1
fi
hasKey="$(echo "$settings" | jq -r '.hasKey // false')"
readyOk="$(echo "$settings" | jq -r '.ready.ok // false')"
readyVia="$(echo "$settings" | jq -r '.ready.via // "none"')"
echo "      hasKey=$hasKey ready.ok=$readyOk ready.via=$readyVia"

model="${OGP_MODEL:-}"
if [[ -z "$model" ]]; then
  if [[ "$hasKey" == "true" ]]; then
    model="gpt-4o-mini"
    echo "      tier: Reliable (OpenAI key present) -> model=$model"
  elif [[ "$readyOk" == "true" ]]; then
    model="os.neu-local"
    echo "      tier: Experimental (local only) -> model=$model  (expect 15-90s cold start)"
  else
    echo "FAIL  OS-NEU-AI-001  no OpenAI key and no local model — Ask AI cannot run"
    echo "      fix: open Connect AI and add a key, or run: curl -X POST $BASE/api/llm/pull"
    exit 1
  fi
fi

selection="This sentance have a typo and is not very clear, please fix it up for the reader."
payload="$(jq -n --arg model "$model" --arg sel "$selection" '{
  model: $model,
  app: "doc",
  instruction: "Make this clearer",
  content: "OGP verify\n" + $sel,
  selection: $sel,
  mode: "rewrite",
  history: []
}')"

echo "== streaming request (model=$model) =="
timeout_s=150
if [[ "$model" == "os.neu-local" ]]; then timeout_s=200; fi

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
started=$(date +%s)
if ! curl -fsS --max-time "$timeout_s" -N \
  -H 'content-type: application/json' \
  -d "$payload" \
  "$BASE/api/office/assist/stream" > "$tmp" 2>/dev/null; then
  echo "FAIL  OS-NEU-AI-300  curl to office/assist/stream failed (network/timeout/http-error)"
  exit 1
fi
elapsed=$(( $(date +%s) - started ))

full=""
sawDoneOk=""
errReason=""
while IFS= read -r line; do
  [[ -z "$line" ]] && continue
  if ! echo "$line" | jq -e . >/dev/null 2>&1; then continue; fi
  f="$(echo "$line" | jq -r '.full // empty')"
  [[ -n "$f" ]] && full="$f"
  ok="$(echo "$line" | jq -r '.ok // true')"
  done_="$(echo "$line" | jq -r '.done // false')"
  if [[ "$ok" == "false" ]]; then
    errReason="$(echo "$line" | jq -r '.reason // "assist-error"')"
  fi
  if [[ "$done_" == "true" && "$ok" != "false" ]]; then
    sawDoneOk="1"
  fi
done < "$tmp"

if [[ -n "$errReason" ]]; then
  echo "FAIL  OS-NEU-AI-300  stream reported error: $errReason (elapsed ${elapsed}s)"
  exit 1
fi
if [[ -z "$full" ]]; then
  echo "FAIL  OS-NEU-AI-300  stream returned no text (elapsed ${elapsed}s)"
  exit 1
fi

echo "PASS  received ${#full} chars in ${elapsed}s"
echo "      preview: $(echo "$full" | tr '\n' ' ' | cut -c1-140)"
echo ""
echo "G-AI-GOLDEN-1: PASS (model=$model, tier=$([[ "$model" == "os.neu-local" ]] && echo Experimental || echo Reliable))"
echo "Remaining OGP steps (manual): open Doc -> Word skin -> select -> Ask AI rewrite -> Save -> confirm file on disk (G-AI-GOLDEN-2)."
