"""Parse and export os.neu work orders from docs/work-orders.md."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

COLUMNS = [
    "코드",
    "이슈ID",
    "이슈 설명",
    "프롬프트 인풋",
    "프롬프트 아웃풋",
    "프롬프트 과정 내용",
    "작업의 페인포인트",
    "구체적인 설명",
    "작업 완료 여부",
    "미완성 ID",
    "사유",
    "시작년월일",
    "종료 날짜",
    "에이전트ID",
    "에이전트",
    "에이전트의 작업 과정 설명",
    "에이전트 사유",
    "프롬프트 내용",
]

FIELD_MAP = {
    "코드": "code",
    "이슈ID": "issue_id",
    "이슈 설명": "issue_summary",
    "프롬프트 인풋": "prompt_input",
    "프롬프트 아웃풋": "prompt_output",
    "프롬프트 과정 내용": "prompt_process",
    "작업의 페인포인트": "pain_point",
    "구체적인 설명": "detail",
    "작업 완료 여부": "status",
    "미완성 ID": "incomplete_id",
    "사유": "reason",
    "시작년월일": "started_at",
    "종료 날짜": "ended_at",
    "에이전트ID": "agent_id",
    "에이전트": "agent",
    "에이전트의 작업 과정 설명": "agent_process",
    "에이전트 사유": "agent_reason",
    "프롬프트 내용": "prompt_full",
}


@dataclass
class WorkOrder:
    code: str = ""
    issue_id: str = ""
    issue_summary: str = ""
    prompt_input: str = ""
    prompt_output: str = ""
    prompt_process: str = ""
    pain_point: str = ""
    detail: str = ""
    status: str = ""
    incomplete_id: str = ""
    reason: str = ""
    started_at: str = ""
    ended_at: str = ""
    agent_id: str = ""
    agent: str = ""
    agent_process: str = ""
    agent_reason: str = ""
    prompt_full: str = ""

    def to_row(self) -> dict[str, str]:
        return {col: getattr(self, FIELD_MAP[col]) for col in COLUMNS}


def _extract_codeblock(block: str, label: str) -> str:
    pattern = rf"<summary>{re.escape(label)}</summary>\s*```(?:text)?\s*(.*?)```"
    m = re.search(pattern, block, re.DOTALL)
    return m.group(1).strip() if m else ""


def _extract_bullet(block: str, key: str) -> str:
    m = re.search(rf"- \*\*{re.escape(key)}:\*\* (.+)", block)
    return m.group(1).strip() if m else ""


def parse_work_orders(md: str) -> list[WorkOrder]:
    detail_start = md.find("## 워크오더 상세")
    if detail_start < 0:
        raise ValueError("## 워크오더 상세 section not found")

    body = md[detail_start:]
    parts = re.split(r"^### (WO-\d{4}-\d{4}) — ", body, flags=re.MULTILINE)
    orders: list[WorkOrder] = []

    for i in range(1, len(parts), 2):
        code = parts[i]
        block = parts[i + 1]
        issue_id = block.split("\n", 1)[0].strip()
        wo = WorkOrder(
            code=code,
            issue_id=issue_id,
            issue_summary=_extract_bullet(block, "이슈 설명"),
            status=_extract_bullet(block, "작업 완료 여부"),
            incomplete_id=_extract_bullet(block, "미완성 ID"),
            reason=_extract_bullet(block, "사유"),
            started_at=_extract_bullet(block, "시작년월일"),
            ended_at=_extract_bullet(block, "종료 날짜"),
            agent_id=_extract_bullet(block, "에이전트ID"),
            agent=_extract_bullet(block, "에이전트"),
            pain_point=_extract_bullet(block, "작업의 페인포인트"),
            detail=_extract_bullet(block, "구체적인 설명"),
            prompt_process=_extract_bullet(block, "프롬프트 과정 내용"),
            agent_process=_extract_bullet(block, "에이전트의 작업 과정 설명"),
            agent_reason=_extract_bullet(block, "에이전트 사유"),
            prompt_input=_extract_codeblock(block, "프롬프트 인풋"),
            prompt_output=_extract_codeblock(block, "프롬프트 아웃풋"),
            prompt_full=_extract_codeblock(block, "프롬프트 내용 (전문)"),
        )
        orders.append(wo)

    return orders


def parse_master_index(md: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    in_table = False
    for line in md.splitlines():
        if line.startswith("## 마스터 인덱스"):
            in_table = True
            continue
        if in_table and line.startswith("## "):
            break
        if not in_table or not line.startswith("| WO-"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 5:
            continue
        rows.append(
            {
                "코드": cells[0],
                "이슈ID": cells[1],
                "작업 완료 여부": cells[2],
                "시작년월일": cells[3],
                "프롬프트 인풋(요약)": cells[4],
            }
        )
    return rows


def load_work_orders(path: Path) -> list[WorkOrder]:
    return parse_work_orders(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: Iterable[dict[str, str]], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def filter_by_issue_ids(orders: list[WorkOrder], issue_ids: list[str]) -> list[WorkOrder]:
    wanted = {x.upper() for x in issue_ids}
    return [o for o in orders if o.issue_id.upper() in wanted]


def filter_incomplete(orders: list[WorkOrder]) -> list[WorkOrder]:
    return [o for o in orders if o.status in {"미완", "진행중"}]
