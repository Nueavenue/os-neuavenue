#!/usr/bin/env bash
# Copy this tree to ~/os.neu, npm install, then plant the Linux launcher + service.
# Linux only. Does not wipe disks.
set -euo pipefail
if [[ "$(uname -s)" != "Linux" ]]; then
  echo "os.neu installer is Linux only. There is no Windows or macOS installer yet." >&2
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE"
if [[ -d "$HERE/os.neu" && -f "$HERE/os.neu/package.json" ]]; then
  SRC="$HERE/os.neu"
elif [[ -f "$HERE/../package.json" && -d "$HERE/../src" ]]; then
  SRC="$(cd "$HERE/.." && pwd)"
fi

DEST="${NEUOS_DEST:-$HOME/os.neu}"
mkdir -p "$DEST"
if [[ "$(cd "$SRC" && pwd)" != "$(cd "$DEST" && pwd)" ]]; then
  if command -v rsync >/dev/null; then
    # Exclude machine-local / root-owned runtime artifacts so plant stays user-writable.
    set +e
    rsync -a \
      --exclude node_modules \
      --exclude .git \
      --exclude dist \
      --exclude dist-web \
      --exclude runtime \
      --exclude .env \
      --exclude .env.* \
      --exclude 'data/oauth-handoff.json' \
      "$SRC/" "$DEST/"
    rs=$?
    set -e
    # 23 = partial transfer (permission on a few files) — source tree is still usable.
    if [[ "$rs" -ne 0 && "$rs" -ne 23 ]]; then
      echo "rsync failed with code $rs" >&2
      exit "$rs"
    fi
  else
    tar -C "$SRC" --exclude=node_modules --exclude=.git --exclude=dist --exclude=dist-web \
      --exclude=runtime --exclude=.env \
      -cf - . | tar -C "$DEST" -xf -
  fi
fi

chmod +x "$DEST/scripts/"*.sh 2>/dev/null || true
cd "$DEST"

if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
  echo "Need Node.js 20+ and npm on this Linux PC, then run: bash $DEST/scripts/install-linux.sh" >&2
  exit 2
fi

if [[ ! -d "$DEST/node_modules/electron" ]]; then
  npm install
fi

bash "$DEST/scripts/install-autostart.sh"

# WO-UI-NEU-USB-GDM-SESSION-121: install-autostart.sh only writes the
# user-local Wayland session — GDM reads /usr/share/wayland-sessions on the
# system, which needs root. WO-UI-NEU-GDM-PKEXEC-ASK-121: this is the first
# privilege elevation this script ever does, so ask y/N first (default N)
# instead of running pkexec unasked. No TTY (pipe/CI) → skip the prompt and
# pkexec entirely, print the manual sudo line, never hang, never block the
# rest of the install.
ASK_PKEXEC_LINUX=0
if command -v pkexec >/dev/null 2>&1; then
  if [[ -t 0 ]]; then
    ASK_PKEXEC_LINUX=1
  else
    echo "No terminal attached — skipping the system GDM session prompt."
  fi
fi

DID_REGISTER_SYSTEM_SESSION=0
if [[ "$ASK_PKEXEC_LINUX" == 1 ]]; then
  ANSWER_PKEXEC_LINUX=""
  read -r -p "Register the system GDM session (os.neu) now? Needs your password via pkexec. [y/N] " ANSWER_PKEXEC_LINUX || ANSWER_PKEXEC_LINUX=""
  case "$ANSWER_PKEXEC_LINUX" in
    y|Y|yes|YES)
      echo "Registering the system GDM session (os.neu) — you may be asked for your password…"
      if pkexec env NEUOS_TARGET_USER="$(id -un)" NEUOS_HOME="$HOME" NEUOS_EXEC_ROOT="$DEST" \
          bash "$DEST/scripts/install-osneu-session.sh"; then
        echo "GDM gear: os.neu registered (system)."
        DID_REGISTER_SYSTEM_SESSION=1
      else
        echo "GDM gear: os.neu NOT registered (pkexec declined or failed)."
      fi
      ;;
    *)
      echo "Skipped (default N)."
      ;;
  esac
fi
if [[ "$DID_REGISTER_SYSTEM_SESSION" != 1 ]]; then
  echo "GDM gear: os.neu is user-local only. For the login gear, run:"
  echo "  sudo bash $DEST/scripts/install-osneu-session.sh"
fi

# WO-UI-NEU-INSTALL-CAGE-CHAIN-121: without cage, the GDM os.neu session
# falls back to gnome-shell (still looks like Ubuntu). Stage cage+seatd into
# $DEST/runtime/kiosk on the same host install — reuses stage1-host.sh's
# own stage_kiosk_user via --kiosk-only (no second pkexec, no ollama, no
# llama pull, no --with-apt, no --autologin; fail soft, never blocks here).
# WO-UI-NEU-CAGE-DOWNLOAD-ASK-121: --kiosk-only fetches a few small Ubuntu
# archive .deb packages with no root but also no prompt — ask y/N first
# (default N), same pattern as B21. No TTY (pipe/CI) → skip the prompt and
# the download entirely, print the later command, never hang.
if [[ -x "$DEST/runtime/kiosk/cage" ]]; then
  echo "cage already staged at $DEST/runtime/kiosk (skip — USB plant already has it)."
else
  ASK_CAGE_DOWNLOAD=0
  if [[ -t 0 ]]; then
    ASK_CAGE_DOWNLOAD=1
  else
    echo "No terminal attached — skipping the cage download prompt."
  fi

  DID_STAGE_CAGE=0
  if [[ "$ASK_CAGE_DOWNLOAD" == 1 ]]; then
    ANSWER_CAGE_DOWNLOAD=""
    read -r -p "Stage cage+seatd for the os.neu GDM session now? Downloads a few small .deb packages from the Ubuntu archive (no root, no password). [y/N] " ANSWER_CAGE_DOWNLOAD || ANSWER_CAGE_DOWNLOAD=""
    case "$ANSWER_CAGE_DOWNLOAD" in
      y|Y|yes|YES)
        echo "Staging cage+seatd for the os.neu GDM session (user-local, no extra password prompt)…"
        bash "$DEST/scripts/stage1-host.sh" --kiosk-only || true
        DID_STAGE_CAGE=1
        ;;
      *)
        echo "Skipped (default N)."
        ;;
    esac
  fi
  if [[ "$DID_STAGE_CAGE" != 1 ]]; then
    echo "cage not staged. Without it the GDM os.neu session falls back to gnome-shell. Run later:"
    echo "  bash $DEST/scripts/stage1-host.sh --kiosk-only"
  fi
fi

echo
echo "os.neu is on this Linux PC."
echo "Show Apps and the Desktop now have the os.neu icon. No cd."
echo "To start now: click os.neu, or bash $DEST/scripts/open-neuos.sh"
