#!/usr/bin/env python3
"""Generate categorized doc catalog CSV + markdown index."""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path

from doc_registry_data import DOC_CATALOG_COLUMNS, DOC_CATEGORIES, DOCS, EXTRA_DOC_PATHS
from doc_registry_lib import EXPORT_DIR, ROOT, discover_extra_docs, file_mtime, write_csv


def build_catalog_rows() -> list[dict[str, str]]:
    known = {d["파일경로"] for d in DOCS}
    rows: list[dict[str, str]] = []
    for doc in DOCS:
        row = dict(doc)
        row["파일수정일"] = file_mtime(ROOT / doc["파일경로"])
        rows.append(row)
    rows.extend(discover_extra_docs(ROOT, known, EXTRA_DOC_PATHS))
    rows.sort(key=lambda r: (r["카테고리1"], r["문서ID"]))
    return rows


def render_markdown(rows: list[dict[str, str]]) -> str:
    by_cat: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_cat[row["카테고리1"]].append(row)

    lines = [
        "# os.neu 문서 카탈로그",
        "",
        "> 관리자·사내팀 질문 라우팅용. 자동 생성 — `python3 scripts/generate-doc-catalog.py`",
        f"> 문서 수: **{len(rows)}**",
        "",
        "## 카테고리 트리",
        "",
    ]
    for cat_id, (name, desc) in DOC_CATEGORIES.items():
        count = len(by_cat.get(cat_id, []))
        lines.append(f"- **{cat_id}** — {name}: {desc} ({count}편)")

    lines.extend(["", "## 질문 → 문서 빠른 찾기", "", "| 질문 유형 | 먼저 볼 카테고리 | 대표 문서 |", "|-----------|------------------|-----------|"])
    faq_routes = [
        ("기능 구현됐나? SHIP/PARTIAL?", "CAT-VERIFICATION", "service-fit-audit.md · exports/feature-spec-registry.csv"),
        ("OAuth/로그인?", "CAT-IMPLEMENTATION", "google-oauth.md · work-orders-guide.md"),
        ("브라우저/탭/줌?", "CAT-IMPLEMENTATION", "browser-electron-features.md"),
        ("문서 편집기?", "CAT-IMPLEMENTATION", "editor-feature-spec.md"),
        ("배포/도메인?", "CAT-DEPLOY", "domain-landing.md · deploy-verification-2026-08-28.md"),
        ("USB/심기?", "CAT-USER + CAT-DEPLOY", "student-usb-guide.md · osneu-session.md"),
        ("프롬프트 이력?", "CAT-OPERATIONS", "work-orders.md"),
        ("투자/사업?", "CAT-BUSINESS", "business-plan.md"),
        ("아키텍처 4층?", "CAT-ARCHITECTURE", "architecture-flow.md · overview.md"),
    ]
    for q, cat, doc in faq_routes:
        lines.append(f"| {q} | {cat} | {doc} |")

    lines.append("")
    for cat_id in DOC_CATEGORIES:
        items = by_cat.get(cat_id, [])
        if not items:
            continue
        name = DOC_CATEGORIES[cat_id][0]
        lines.extend([f"## {cat_id} — {name}", "", "| 문서ID | 문서명 | 경로 | FAQ키워드 | 수정일 |", "|--------|--------|------|-----------|--------|"])
        for row in items:
            lines.append(
                f"| {row['문서ID']} | {row['문서명']} | `{row['파일경로']}` | {row['FAQ키워드']} | {row.get('파일수정일', '—')} |"
            )
        lines.append("")

    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate doc catalog CSV and markdown")
    parser.add_argument("--csv", type=Path, default=EXPORT_DIR / "doc-catalog.csv")
    parser.add_argument("--md", type=Path, default=ROOT / "docs" / "doc-catalog.md")
    parser.add_argument("--category", help="Filter by 카테고리1 e.g. CAT-OPERATIONS")
    args = parser.parse_args()

    rows = build_catalog_rows()
    if args.category:
        rows = [r for r in rows if r["카테고리1"] == args.category]

    columns = DOC_CATALOG_COLUMNS + ["파일수정일"]
    n = write_csv(args.csv, columns, rows)
    args.md.write_text(render_markdown(rows), encoding="utf-8")
    print(f"Wrote {n} doc(s) → {args.csv}")
    print(f"Wrote markdown → {args.md}")


if __name__ == "__main__":
    main()
