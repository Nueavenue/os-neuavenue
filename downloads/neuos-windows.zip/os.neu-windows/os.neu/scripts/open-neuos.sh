#!/usr/bin/env bash
# Graphical login entry point. Used by XDG autostart and systemd --user.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# Chrome "Open os.neu" may launch this desktop entry with osneu://… — forward it.
for arg in "$@"; do
  case "$arg" in
    osneu://*)
      exec bash "$ROOT/scripts/osneu-protocol.sh" "$arg"
      ;;
  esac
done

cd "$ROOT"
export HOME="${HOME:-/home/billy-lee}"
if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.nvm/nvm.sh"
fi
export PATH="${HOME}/.local/bin:${PATH}"
ulimit -n 65536 2>/dev/null || true

# When opened from Ubuntu (not only GDM os.neu), still quiet Chromium keyring prompts
# and wake local AI if present.
if [[ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ]] && command -v dbus-launch >/dev/null; then
  # shellcheck disable=SC2046
  eval "$(dbus-launch --sh-syntax)" || true
fi
if command -v gnome-keyring-daemon >/dev/null; then
  # shellcheck disable=SC2046
  eval "$(gnome-keyring-daemon --start --daemonize --components=secrets,ssh,pkcs11 2>/dev/null)" || true
fi
if [[ -z "${CHROME_PASSWORD_STORE:-}" ]]; then
  if [[ -n "${GNOME_KEYRING_CONTROL:-}" ]] || pgrep -u "$(id -u)" -x gnome-keyring-d >/dev/null 2>&1; then
    export CHROME_PASSWORD_STORE=gnome-libsecret
  else
    export CHROME_PASSWORD_STORE=basic
  fi
fi
if command -v ollama >/dev/null; then
  if ! curl -sf -m 1 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    nohup ollama serve >/tmp/osneu-ollama-serve.log 2>&1 &
  fi
fi

# Give Ollama a moment so office/os.neu-local works on first Ask AI.
if command -v ollama >/dev/null; then
  for _ in $(seq 1 25); do
    if curl -sf -m 1 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
      break
    fi
    sleep 0.2
  done
fi

exec bash "$ROOT/scripts/screen.sh" "$@"
