#!/usr/bin/env bash
# Plant os.neu on this Linux user: launcher icon, Desktop icon, login autostart,
# and a systemd --user service. Does not wipe disks. Does not change GRUB.
# You do not need to cd into ~/os.neu after this — click the os.neu icon.
set -euo pipefail
if [[ "$(uname -s)" != "Linux" ]]; then
  echo "os.neu plant is Linux only." >&2
  exit 1
fi
ROOT="${NEUOS_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
EXEC_ROOT="${NEUOS_EXEC_ROOT:-$ROOT}"
HOME_DIR="${NEUOS_HOME:-$HOME}"
# JeOS plant bind-mounts the Ubuntu disk at /mnt/osneu-host. Desktop Icon= must
# be a path that still exists after a normal Ubuntu reboot (no that prefix).
if [[ "$HOME_DIR" == /mnt/osneu-host/* ]]; then
  HOME_DIR="${HOME_DIR#/mnt/osneu-host}"
fi
if [[ "$EXEC_ROOT" == /mnt/osneu-host/* ]]; then
  EXEC_ROOT="${EXEC_ROOT#/mnt/osneu-host}"
fi
if [[ "$ROOT" == /mnt/osneu-host/* ]]; then
  ROOT="${ROOT#/mnt/osneu-host}"
fi
ICON_NAME="os.neu"
ICON_SRC="$ROOT/public/brand/hicolor"
AUTO="$HOME_DIR/.config/autostart"
APPS="$HOME_DIR/.local/share/applications"
DESK="$HOME_DIR/Desktop"
USER_SYS="$HOME_DIR/.config/systemd/user"

mkdir -p "$AUTO" "$APPS" "$USER_SYS"
chmod +x "$ROOT/scripts/open-neuos.sh" "$ROOT/scripts/screen.sh" "$ROOT/scripts/install-linux.sh" "$ROOT/scripts/osneu-session.sh" "$ROOT/scripts/install-osneu-session.sh" "$ROOT/scripts/trust-launchers.sh" 2>/dev/null || true

for size in 48 64 128 256 512; do
  src="$ICON_SRC/${size}x${size}/apps/os.neu.png"
  if [[ -f "$src" ]]; then
    dest_dir="$HOME_DIR/.local/share/icons/hicolor/${size}x${size}/apps"
    mkdir -p "$dest_dir"
    cp -a "$src" "$dest_dir/os.neu.png"
  fi
done
if command -v gtk-update-icon-cache >/dev/null; then
  gtk-update-icon-cache -f -t "$HOME_DIR/.local/share/icons/hicolor" >/dev/null 2>&1 || true
fi

ICON_FILE="$HOME_DIR/.local/share/icons/hicolor/256x256/apps/os.neu.png"
if [[ ! -f "$ICON_FILE" ]]; then
  ICON_FILE="$HOME_DIR/.local/share/icons/hicolor/128x128/apps/os.neu.png"
fi
if [[ ! -f "$ICON_FILE" ]]; then
  ICON_FILE="$ICON_NAME"
fi
mkdir -p "$HOME_DIR/.local/share/pixmaps"
if [[ -f "$HOME_DIR/.local/share/icons/hicolor/256x256/apps/os.neu.png" ]]; then
  cp -a "$HOME_DIR/.local/share/icons/hicolor/256x256/apps/os.neu.png" "$HOME_DIR/.local/share/pixmaps/os.neu.png"
fi

chmod +x "$ROOT/scripts/trust-launchers.sh" 2>/dev/null || true

write_desktop() {
  local dest="$1"
  local autostart="${2:-0}"
  local icon_file="$3"
  # Do NOT claim x-scheme-handler/osneu here — that belongs to osneu-protocol.desktop.
  # Still accept %u so a mistaken association can forward via open-neuos.sh.
  cat > "$dest" <<EOF
[Desktop Entry]
Type=Application
Name=os.neu
GenericName=os.neu screen
Comment=os.neu screen — independent browser
Keywords=os.neu;neuos;neuOS;screen;
Exec=bash $EXEC_ROOT/scripts/open-neuos.sh %u
TryExec=bash
Path=$EXEC_ROOT
Icon=$icon_file
Terminal=false
Categories=Utility;
StartupWMClass=neuos
StartupNotify=true
EOF
  if [[ "$autostart" == "1" ]]; then
    printf 'X-GNOME-Autostart-enabled=true\n' >> "$dest"
  fi
}

# Separate handler so Chrome "Open os.neu" can focus the running window via osneu://.
write_protocol_desktop() {
  local dest="$1"
  local icon_file="$2"
  cat > "$dest" <<EOF
[Desktop Entry]
Type=Application
Name=os.neu
GenericName=os.neu OAuth return
Comment=Return from Google sign-in to os.neu
Exec=bash $EXEC_ROOT/scripts/osneu-protocol.sh %u
TryExec=bash
Path=$EXEC_ROOT
Icon=$icon_file
Terminal=false
NoDisplay=true
MimeType=x-scheme-handler/osneu;
Categories=Network;
StartupWMClass=neuos
StartupNotify=false
EOF
}

write_desktop "$AUTO/neuos.desktop" 1 "$ICON_FILE"
write_desktop "$APPS/neuos.desktop" 0 "$ICON_FILE"
write_protocol_desktop "$APPS/osneu-protocol.desktop" "$ICON_FILE"
chmod +x "$APPS/neuos.desktop" "$APPS/osneu-protocol.desktop" "$ROOT/scripts/osneu-protocol.sh" 2>/dev/null || true

if [[ -d "$DESK" ]]; then
  write_desktop "$DESK/neuos.desktop" 0 "$ICON_FILE"
  chmod +x "$DESK/neuos.desktop"
fi

bash "$ROOT/scripts/trust-launchers.sh"

if command -v update-desktop-database >/dev/null; then
  update-desktop-database "$APPS" >/dev/null 2>&1 || true
fi
if command -v xdg-mime >/dev/null; then
  xdg-mime default osneu-protocol.desktop x-scheme-handler/osneu >/dev/null 2>&1 || true
fi
# Force override: Chrome "Always allow" may have pinned neuos.desktop without %u forwarding.
MIMEAPPS="$HOME_DIR/.config/mimeapps.list"
mkdir -p "$(dirname "$MIMEAPPS")"
if [[ -f "$MIMEAPPS" ]]; then
  if grep -q '^x-scheme-handler/osneu=' "$MIMEAPPS"; then
    sed -i 's|^x-scheme-handler/osneu=.*|x-scheme-handler/osneu=osneu-protocol.desktop|' "$MIMEAPPS"
  else
    if grep -q '^\[Default Applications\]' "$MIMEAPPS"; then
      sed -i '/^\[Default Applications\]/a x-scheme-handler/osneu=osneu-protocol.desktop' "$MIMEAPPS"
    else
      printf '\n[Default Applications]\nx-scheme-handler/osneu=osneu-protocol.desktop\n' >> "$MIMEAPPS"
    fi
  fi
else
  printf '[Default Applications]\nx-scheme-handler/osneu=osneu-protocol.desktop\n' > "$MIMEAPPS"
fi
echo "protocol:  $APPS/osneu-protocol.desktop ($(xdg-mime query default x-scheme-handler/osneu 2>/dev/null || echo unset))"


cat > "$USER_SYS/neuos.service" <<EOF
[Unit]
Description=os.neu screen
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$EXEC_ROOT
ExecStart=/bin/bash $EXEC_ROOT/scripts/open-neuos.sh
Restart=on-failure
RestartSec=3
Environment=DISPLAY=:0
Environment=NEUOS_SCREEN=1

[Install]
WantedBy=graphical-session.target
EOF

# One screen only: XDG autostart opens os.neu. Do not also enable systemd --user
# (that opened a second window next to the autostart one).
if command -v systemctl >/dev/null; then
  systemctl --user disable --now neuos.service >/dev/null 2>&1 || true
  systemctl --user daemon-reload >/dev/null 2>&1 || true
  echo "systemd --user neuos.service disabled (XDG autostart alone)"
fi

if command -v update-desktop-database >/dev/null; then
  update-desktop-database "$APPS" >/dev/null 2>&1 || true
fi

SESS="$HOME_DIR/.local/share/wayland-sessions"
mkdir -p "$SESS"
cat > "$SESS/os.neu.desktop" <<EOF
[Desktop Entry]
Name=os.neu
Comment=os.neu screen on this machine — Ubuntu stays the kernel
Exec=bash $EXEC_ROOT/scripts/osneu-session.sh
TryExec=bash
Type=Application
DesktopNames=os.neu;GNOME
EOF

echo "launcher:  $APPS/neuos.desktop"
echo "desktop:   $DESK/neuos.desktop"
echo "autostart: $AUTO/neuos.desktop"
echo "unit:      $USER_SYS/neuos.service"
echo "session:   $SESS/os.neu.desktop"
echo "GDM system session: sudo bash $ROOT/scripts/install-osneu-session.sh"
echo "Click the os.neu icon. You do not need to cd $EXEC_ROOT."

if [[ -z "${NEUOS_NO_DIALOG:-}" ]] && [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]] && command -v zenity >/dev/null; then
  zenity --info --title="os.neu" --timeout=8 \
    --text="os.neu is on this Linux PC.\n\nShow Apps and the Desktop have the os.neu icon.\nClick the icon. You do not need bash." \
    >/dev/null 2>&1 || true
fi
