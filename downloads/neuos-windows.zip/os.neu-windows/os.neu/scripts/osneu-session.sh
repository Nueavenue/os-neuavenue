#!/usr/bin/env bash
# GDM/Wayland session: os.neu is the screen on THIS machine.
# Ubuntu kernel, drivers, networking stay. This is not a new kernel.
# Needs a compositor (cage preferred). GNOME shell is a fallback and still looks like Ubuntu.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KIOSK="$ROOT/runtime/kiosk"
export HOME="${HOME:-/home/billy-lee}"
export NEUOS_SCREEN=1
export NEUOS_DRIVER=live
export XDG_SESSION_TYPE=wayland
# Include GNOME so libsecret / Chromium can find a desktop keyring backend.
export XDG_CURRENT_DESKTOP="${XDG_CURRENT_DESKTOP:-os.neu:GNOME}"
case ":${XDG_CURRENT_DESKTOP}:" in
  *:GNOME:*) ;;
  *) export XDG_CURRENT_DESKTOP="os.neu:GNOME" ;;
esac
export GNOME_DESKTOP_SESSION_ID="${GNOME_DESKTOP_SESSION_ID:-this-is-deprecated}"
RT="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export XDG_RUNTIME_DIR="$RT"
mkdir -p "$RT"
chmod 700 "$RT" 2>/dev/null || true

if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.nvm/nvm.sh"
fi

export PATH="${HOME}/.local/bin:${KIOSK}:${PATH}"
if [[ -d "$KIOSK/lib" ]]; then
  export LD_LIBRARY_PATH="${KIOSK}/lib:${KIOSK}/lib/x86_64-linux-gnu:${KIOSK}/lib64:${LD_LIBRARY_PATH:-}"
fi

# Session bus + login keyring so Chrome/Electron do not show
# “OS keyring could not be identified… Use weaker encryption” on every app.
if [[ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ]] && command -v dbus-launch >/dev/null; then
  # shellcheck disable=SC2046
  eval "$(dbus-launch --sh-syntax)"
fi
if command -v gnome-keyring-daemon >/dev/null; then
  # shellcheck disable=SC2046
  eval "$(gnome-keyring-daemon --start --daemonize --components=secrets,ssh,pkcs11 2>/dev/null)" || true
fi
# Prefer libsecret when the daemon is up; otherwise basic (no interactive prompt).
if [[ -n "${GNOME_KEYRING_CONTROL:-}" ]] || pgrep -u "$(id -u)" -x gnome-keyring-d >/dev/null 2>&1; then
  export PASSWORD_STORE=gnome-libsecret
  export CHROME_PASSWORD_STORE=gnome-libsecret
else
  export PASSWORD_STORE=basic
  export CHROME_PASSWORD_STORE=basic
fi

# Free on-device AI (Ollama) for os.neu-local — best effort, non-fatal.
if command -v ollama >/dev/null; then
  if ! curl -sf -m 1 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    nohup ollama serve >/tmp/osneu-ollama-serve.log 2>&1 &
  fi
fi

SCREEN=(bash "$ROOT/scripts/open-neuos.sh")

pick_cage() {
  if command -v cage >/dev/null; then
    command -v cage
    return 0
  fi
  if [[ -x "$KIOSK/cage" ]]; then
    echo "$KIOSK/cage"
    return 0
  fi
  return 1
}

CAGE_BIN="$(pick_cage || true)"
if [[ -n "${CAGE_BIN:-}" ]]; then
  exec "$CAGE_BIN" -- "${SCREEN[@]}"
fi

wait_wayland() {
  local i=0
  while [[ "$i" -lt 40 ]]; do
    if [[ -S "$RT/wayland-0" ]]; then
      export WAYLAND_DISPLAY=wayland-0
      return 0
    fi
    if [[ -S "$RT/wayland-1" ]]; then
      export WAYLAND_DISPLAY=wayland-1
      return 0
    fi
    i=$((i + 1))
    sleep 0.25
  done
  return 1
}

if command -v gnome-shell >/dev/null; then
  dbus-run-session gnome-shell --wayland >/tmp/osneu-session-shell.log 2>&1 &
  gs=$!
  if wait_wayland; then
    "${SCREEN[@]}"
    kill "$gs" 2>/dev/null || true
    exit 0
  fi
  kill "$gs" 2>/dev/null || true
fi

echo "OS-NEU-SX-000  no compositor for the os.neu session on this machine." >&2
echo "Ubuntu path: bash $ROOT/scripts/stage1-host.sh" >&2
echo "Or: sudo apt install -y cage seatd" >&2
echo "Then at GDM pick session os.neu (not Ubuntu)." >&2
sleep 6
exit 1
