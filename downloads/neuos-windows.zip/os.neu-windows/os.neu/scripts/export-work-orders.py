#!/usr/bin/env python3
"""Export work orders from docs/work-orders.md to CSV."""

from __future__ import annotations

import argparse
from pathlib import Path

from work_orders_lib import COLUMNS, filter_by_issue_ids, filter_incomplete, load_work_orders, write_csv

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MD = ROOT / "docs" / "work-orders.md"
DEFAULT_EXPORT_DIR = ROOT / "docs" / "exports"


def main() -> None:
    parser = argparse.ArgumentParser(description="Export os.neu work orders to CSV")
    parser.add_argument("--md", type=Path, default=DEFAULT_MD, help="work-orders.md path")
    parser.add_argument(
        "--out",
        type=Path,
        help="Output CSV path (default: docs/exports/work-orders-<suffix>.csv)",
    )
    parser.add_argument(
        "--issue-id",
        action="append",
        dest="issue_ids",
        metavar="ID",
        help="Filter by issue ID (repeatable), e.g. AUTH-OAUTH",
    )
    parser.add_argument(
        "--incomplete",
        action="store_true",
        help="Export only 미완/진행중 rows",
    )
    parser.add_argument(
        "--index-only",
        action="store_true",
        help="Export master-index columns only (no long prompt bodies)",
    )
    args = parser.parse_args()

    orders = load_work_orders(args.md)

    if args.incomplete:
        orders = filter_incomplete(orders)
        suffix = "incomplete"
    elif args.issue_ids:
        orders = filter_by_issue_ids(orders, args.issue_ids)
        suffix = "-".join(args.issue_ids[0].lower().split())
    else:
        suffix = "all"

    if args.index_only:
        columns = ["코드", "이슈ID", "이슈 설명", "작업 완료 여부", "시작년월일", "종료 날짜", "미완성 ID", "사유"]
        rows = [
            {
                "코드": o.code,
                "이슈ID": o.issue_id,
                "이슈 설명": o.issue_summary,
                "작업 완료 여부": o.status,
                "시작년월일": o.started_at,
                "종료 날짜": o.ended_at,
                "미완성 ID": o.incomplete_id,
                "사유": o.reason,
            }
            for o in orders
        ]
    else:
        columns = COLUMNS
        rows = [o.to_row() for o in orders]

    out = args.out or (DEFAULT_EXPORT_DIR / f"work-orders-{suffix}.csv")
    write_csv(out, rows, columns)
    print(f"Wrote {len(rows)} row(s) → {out}")


if __name__ == "__main__":
    main()
