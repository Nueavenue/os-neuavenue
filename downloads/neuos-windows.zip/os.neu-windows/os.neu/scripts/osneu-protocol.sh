#!/usr/bin/env bash
# Handle osneu:// deep links from Chrome (OAuth return / focus).
# If os.neu is already open, start a short-lived second Electron process so the
# primary instance receives second-instance + the URL (then exits).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
URL=""
for arg in "$@"; do
  case "$arg" in
    osneu://*) URL="$arg" ;;
  esac
done
if [[ -z "$URL" ]]; then
  URL="osneu://focus"
fi

complete_tree() {
  local dir="$1"
  [[ -f "$dir/electron/main.cjs" && -f "$dir/package.json" ]]
}

# Prefer the planted tree (same app-path as the running screen) so Electron's
# single-instance lock receives the deep link.
PREFERRED=""
for cand in "$HOME/os.neu" "$ROOT" "$HOME/neuOS" /opt/neuos; do
  [[ -n "${cand:-}" && -d "$cand" ]] || continue
  if complete_tree "$cand"; then
    PREFERRED="$cand"
    break
  fi
done
if [[ -z "$PREFERRED" ]]; then
  echo "os.neu: Electron app tree not found" >&2
  exit 1
fi
ROOT="$PREFERRED"
cd "$ROOT"

ELECTRON_BIN="$ROOT/node_modules/.bin/electron"
if [[ ! -x "$ELECTRON_BIN" ]]; then
  ELECTRON_BIN="$(command -v electron || true)"
fi
if [[ -z "${ELECTRON_BIN}" ]]; then
  echo "os.neu: electron binary not found in $ROOT" >&2
  exit 1
fi

export ELECTRON_OZONE_PLATFORM_HINT="${ELECTRON_OZONE_PLATFORM_HINT:-auto}"
if [[ -z "${CHROME_PASSWORD_STORE:-}" ]]; then
  if [[ -n "${GNOME_KEYRING_CONTROL:-}" ]] || pgrep -u "$(id -u)" -x gnome-keyring-d >/dev/null 2>&1; then
    export CHROME_PASSWORD_STORE=gnome-libsecret
  else
    export CHROME_PASSWORD_STORE=basic
  fi
fi

LOCK_DIR="${XDG_RUNTIME_DIR:-/tmp}/osneu-screen.lock"
if [[ -d "$LOCK_DIR" ]]; then
  old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if [[ -n "$old_pid" ]] && kill -0 "$old_pid" 2>/dev/null; then
    # Ping the running single-instance lock with the deep link.
    exec "$ELECTRON_BIN" . --no-sandbox --disable-gpu-sandbox --password-store="${CHROME_PASSWORD_STORE}" "$URL"
  fi
fi

# No screen yet — open full os.neu and pass the URL through.
export NEUOS_PROTOCOL_URL="$URL"
exec bash "$ROOT/scripts/open-neuos.sh"
