#!/usr/bin/env python3
"""Generate feature spec registry CSV (Excel-compatible)."""

from __future__ import annotations

import argparse
from pathlib import Path

from doc_registry_data import FEATURES, FEATURE_SPEC_COLUMNS
from doc_registry_lib import EXPORT_DIR, write_csv

ROOT = Path(__file__).resolve().parents[1]


def filter_features(features: list[dict], category: str | None, status: str | None) -> list[dict]:
    out = features
    if category:
        out = [f for f in out if f.get("카테고리") == category]
    if status:
        out = [f for f in out if f.get("구현상태") == status]
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Export os.neu feature spec registry to CSV")
    parser.add_argument("--out", type=Path, default=EXPORT_DIR / "feature-spec-registry.csv")
    parser.add_argument("--category", help="Filter by 카테고리")
    parser.add_argument("--status", help="Filter by 구현상태 (SHIP/PARTIAL/PLAN)")
    args = parser.parse_args()

    rows = filter_features(FEATURES, args.category, args.status)
    n = write_csv(args.out, FEATURE_SPEC_COLUMNS, rows)
    print(f"Wrote {n} feature(s) → {args.out}")


if __name__ == "__main__":
    main()
