#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== GA4 config check =="
if [[ -f .env ]]; then
  id="$(grep -E '^VITE_GA4_MEASUREMENT_ID=' .env 2>/dev/null | cut -d= -f2- | tr -d '"' | tr -d "'" | xargs || true)"
else
  id=""
fi

if [[ -z "${id:-}" ]]; then
  echo "FAIL: VITE_GA4_MEASUREMENT_ID not set in .env"
  echo "  1. analytics.google.com → Admin → Data streams → Web → Measurement ID (G-…)"
  echo "  2. Add to .env: VITE_GA4_MEASUREMENT_ID=G-XXXXXXXXXX"
  echo "  3. Restart: npm run dev  (or npm run os)"
  exit 1
fi

if [[ ! "$id" =~ ^G-[A-Za-z0-9]{6,}$ ]]; then
  echo "FAIL: measurement ID format looks wrong: $id"
  exit 1
fi

echo "OK: VITE_GA4_MEASUREMENT_ID=$id"
npx vitest run src/engine/ga4.test.ts
echo ""
echo "Manual verify:"
echo "  1. npm run dev"
echo "  2. Open http://127.0.0.1:5173"
echo "  3. GA4 → Reports → Realtime — look for active user + page_view (screen: splash/lui/landing…)"
echo "  4. DevTools → Network → filter collect — requests to google-analytics.com"
