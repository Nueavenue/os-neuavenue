@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"

if not exist "%ROOT%\electron\main.cjs" (
  echo os.neu: missing electron\main.cjs in %ROOT%
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo Need Node.js 20+ on PATH.
  exit /b 2
)

set "PORT=5173"
set "NEUOS_BRIDGE_PORT=4178"
set "NEUOS_DRIVER=live"
set "NEUOS_SCREEN=1"
set "NEUOS_DEV_URL=http://127.0.0.1:5173"

start "os.neu-bridge" /min cmd /c "cd /d \"%ROOT%\" && npx --yes tsx server/index.ts"
timeout /t 2 /nobreak >nul
start "os.neu-vite" /min cmd /c "cd /d \"%ROOT%\" && npx --yes vite --host 127.0.0.1 --port 5173 --strictPort"

rem Electron must not load before Vite listens (ERR_CONNECTION_REFUSED / black window).
set /a NEUOS_VITE_WAIT=0
:wait_vite
timeout /t 2 /nobreak >nul
set /a NEUOS_VITE_WAIT+=2
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:5173/'; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>nul
if %ERRORLEVEL% equ 0 goto vite_ready
if %NEUOS_VITE_WAIT geq 120 (
  echo.
  echo os.neu: Vite did not start on http://127.0.0.1:5173 within 120s.
  echo Restore the minimized "os.neu-vite" window on the taskbar and read the error.
  echo Or in PowerShell: cd "%ROOT%" ^&^& npx vite --host 127.0.0.1 --port 5173 --strictPort
  pause
  exit /b 3
)
goto wait_vite
:vite_ready
cd /d "%ROOT%"
npx --yes electron .
endlocal
