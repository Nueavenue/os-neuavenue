@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"

if not exist "%ROOT%\electron\main.cjs" (
  echo os.neu: missing electron\main.cjs in %ROOT%
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo Need Node.js 20+ on PATH.
  exit /b 2
)

set "PORT=5173"
set "NEUOS_BRIDGE_PORT=4178"
set "NEUOS_DRIVER=live"
set "NEUOS_SCREEN=1"
set "NEUOS_DEV_URL=http://127.0.0.1:5173"

start "os.neu-bridge" /min cmd /c "npx --yes tsx server/index.ts"
timeout /t 2 /nobreak >nul
start "os.neu-vite" /min cmd /c "npx --yes vite --host 127.0.0.1 --port 5173 --strictPort"
timeout /t 3 /nobreak >nul
npx --yes electron .
endlocal
