#!/usr/bin/env python3
"""Regenerate docs/work-orders.md from a Cursor agent transcript JSONL."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TRANSCRIPT = (
    Path.home()
    / ".cursor/projects/home-billy-lee-neuOS/agent-transcripts"
    / "1fd732b4-9414-4ee9-9207-329f61c68ee4"
    / "1fd732b4-9414-4ee9-9207-329f61c68ee4.jsonl"
)
DEFAULT_OUT = ROOT / "docs" / "work-orders.md"
AGENT_ID = "1fd732b4-9414-4ee9-9207-329f61c68ee4"

SKIP_PATTERNS = (
    r"^<user_info>",
    r"^<open_and_recently_viewed_files>",
    r"^Note: Prefer absolute paths",
)

STATUS_OVERRIDES: dict[str, dict[str, str]] = {
    "WO-2026-0156": {
        "status": "미완",
        "incomplete_id": "WO-AUTH-WEB-001, WO-AUTH-SSO-002",
        "reason": "웹 호스팅 OAuth·Google 웹 SSO 연동은 설계 답변만 완료, 코드 미구현",
        "pain_point": "os.neu 토큰 ≠ Google 웹 쿠키, 임베디드 로그인 차단",
    },
}

ISSUE_RULES: list[tuple[str, str]] = [
    (r"work-orders|워크오더", "META-WO"),
    (r"OAuth|GA4|google analytics|Sign-in|구글 계정|Supabase", "AUTH-OAUTH"),
    (r"북마크|히스토리|다운로드|메뉴바|bookmark|history", "BR-MENU"),
    (r"새 탭|new tab|target=_blank|링크를 누르면", "BR-TAB"),
    (r"브라우저|주소창|duckduckgo|google 검색|BrowserView|neuos\.local|os\.neu\.local", "BR-CHROME"),
    (r"Information Architecture|IA document|ia\.md", "DOC-IA"),
    (r"PRD|use case|UI/UX design guide", "DOC-PRD"),
    (r"심을 수|plant|service-fit|AUDIT", "AUDIT-PLANT"),
    (r"웹 사이트|screen 말고 웹|AUDIT-WEB", "AUDIT-WEB"),
    (r"튜토리얼|tutorial|GUIDE", "GUIDE-TUT"),
    (r"종료|leave|exit|X 버튼", "UI-EXIT"),
    (r"글씨|자간|typography|letter-spacing", "UI-TYPE"),
    (r"welcome|Public install", "UI-WELCOME"),
    (r"Four layers|Speech LUI|레이어", "UI-LAYERS"),
    (r"대화|Talk|프롬프트 dock", "UI-TALK"),
    (r"프로젝트|project sidebar|카드", "UI-PROJECT"),
    (r"뒤로|next|아이콘 버튼|nav", "UI-NAV-ICON"),
    (r"하드웨어|console|hardware", "UI-HW-PANEL"),
    (r"sign in|로그인", "AUTH-SIGNIN"),
    (r"os\.neu 심기|usb|굽기", "OS-PLANT"),
]


def text_of(entry: dict) -> str:
    msg = entry.get("message", {})
    content = msg.get("content", [])
    if isinstance(content, str):
        return content
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
    return "\n".join(parts)


def extract_user_query(raw: str) -> tuple[str, str]:
    ts_m = re.search(r"<timestamp>(.*?)</timestamp>", raw, re.DOTALL)
    ts = ts_m.group(1).strip() if ts_m else ""
    q_m = re.search(r"<user_query>\s*(.*?)\s*</user_query>", raw, re.DOTALL)
    text = q_m.group(1).strip() if q_m else raw.strip()
    return text, ts


def should_skip(text: str) -> bool:
    for pat in SKIP_PATTERNS:
        if re.search(pat, text, re.IGNORECASE | re.DOTALL):
            return True
    if not text.strip():
        return True
    return False


def classify_issue(text: str, seq: int) -> str:
    for pattern, issue_id in ISSUE_RULES:
        if re.search(pattern, text, re.IGNORECASE):
            return issue_id
    return f"GEN-{seq:03d}"


def summarize(text: str, limit: int = 80) -> str:
    one = re.sub(r"\s+", " ", text).strip()
    if len(one) <= limit:
        return one
    return one[: limit - 1] + "…"


def truncate(text: str, limit: int = 6000) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def parse_pairs(path: Path) -> list[dict]:
    pairs: list[dict] = []
    pending: dict | None = None
    with path.open(encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line)
            role = entry.get("role")
            raw = text_of(entry)
            if role == "user":
                query, ts = extract_user_query(raw)
                if should_skip(query):
                    continue
                pending = {"input": query, "ts": ts}
            elif role == "assistant" and pending:
                pairs.append({**pending, "output": raw})
                pending = None
    return pairs


def issue_summary(issue_id: str, text: str) -> str:
    summaries = {
        "DOC-IA": "IA 문서 작성·갱신",
        "DOC-PRD": "PRD·유스케이스·디자인 가이드",
        "AUDIT-PLANT": "심기 가능/불가 서비스 감사",
        "AUDIT-WEB": "웹 vs Electron 기능 동등성",
        "GUIDE-TUT": "튜토리얼·가이드",
        "UI-EXIT": "종료/Leave UX",
        "UI-TYPE": "타이포그래피·자간",
        "UI-WELCOME": "Welcome/install 페이지",
        "UI-LAYERS": "Four layers 설명",
        "UI-TALK": "Talk drawer·대화창",
        "UI-PROJECT": "프로젝트 사이드바",
        "UI-NAV-ICON": "뒤로/다음 아이콘 통일",
        "UI-HW-PANEL": "하드웨어 설정 패널",
        "BR-CHROME": "인앱 브라우저·주소창",
        "BR-MENU": "브라우저 툴바 메뉴",
        "BR-TAB": "새 탭/링크 열기",
        "AUTH-OAUTH": "OAuth/GA4/단일계정",
        "AUTH-SIGNIN": "Sign-in UX",
        "OS-PLANT": "심기/USB/체험 플로우",
        "META-WO": "워크오더 문서화",
    }
    return summaries.get(issue_id, summarize(text, 40))


def render_detail(idx: int, pair: dict, issue_id: str, overrides: dict[str, str]) -> str:
    code = f"WO-2026-{idx:04d}"
    status = overrides.get("status", "완료")
    lines = [
        f"### {code} — {issue_id}",
        "",
        f"- **코드:** {code}",
        f"- **이슈ID:** {issue_id}",
        f"- **이슈 설명:** {issue_summary(issue_id, pair['input'])}",
        f"- **작업 완료 여부:** {status}",
        f"- **미완성 ID:** {overrides.get('incomplete_id', '—')}",
        f"- **사유:** {overrides.get('reason', '—')}",
        f"- **시작년월일:** {pair['ts'] or '—'}",
        f"- **종료 날짜:** {pair['ts'] or '—'}",
        f"- **에이전트ID:** {AGENT_ID}",
        "- **에이전트:** Auto (Cursor Agent)",
        f"- **작업의 페인포인트:** {overrides.get('pain_point', '사용자 UX/기능 기대와 구현 갭')}",
        f"- **구체적인 설명:** {issue_summary(issue_id, pair['input'])}",
        "- **프롬프트 과정 내용:** 사용자 요청 수신 → 코드/문서 분석 → 구현 또는 리포트 작성 → plant 동기화(해당 시)",
        "- **에이전트의 작업 과정 설명:** 코드베이스 grep/read, tsc/vitest, Electron/bridge 수정, ~/os.neu 동기화",
        "- **에이전트 사유:** 사용자 프롬프트 기반 최소 범위 구현 및 문서화",
        "",
        "<details>",
        "<summary>프롬프트 인풋</summary>",
        "",
        "```text",
        pair["input"],
        "```",
        "</details>",
        "",
        "<details>",
        "<summary>프롬프트 아웃풋</summary>",
        "",
        "```text",
        truncate(pair["output"]),
        "```",
        "</details>",
        "",
        "<details>",
        "<summary>프롬프트 내용 (전문)</summary>",
        "",
        "```text",
        pair["input"],
        "```",
        "</details>",
        "",
    ]
    return "\n".join(lines)


def render_markdown(pairs: list[dict], transcript: Path) -> str:
    orders: list[dict] = []
    for i, pair in enumerate(pairs, start=1):
        issue_id = classify_issue(pair["input"], i)
        code = f"WO-2026-{i:04d}"
        overrides = STATUS_OVERRIDES.get(code, {})
        orders.append(
            {
                "code": code,
                "issue_id": issue_id,
                "status": overrides.get("status", "완료"),
                "ts": pair["ts"],
                "summary": summarize(pair["input"]),
                "pair": pair,
                "overrides": overrides,
            }
        )

    incomplete = [o for o in orders if o["status"] in {"미완", "진행중"}]
    counts = Counter(o["issue_id"] for o in orders)
    today = datetime.now().strftime("%Y-%m-%d")

    lines: list[str] = [
        "# os.neu Work Orders",
        "",
        "> 자동 생성: agent transcript 기반 작업 이력. 검증·감사·팀 Q&A용.",
        f"> Agent transcript: `{AGENT_ID}`",
        f"> Transcript path: `{transcript}`",
        f"> 생성일: {today}",
        f"> 총 프롬프트(워크오더) 수: **{len(orders)}**",
        "> 운영 가이드: [work-orders-guide.md](./work-orders-guide.md) · 미완 목록: [work-orders-incomplete.md](./work-orders-incomplete.md)",
        "",
        "## 문서 상태",
        "",
        "| 항목 | 값 |",
        "|------|-----|",
        "| 상태 | **종료(운영)** — transcript 갱신 시 재생성 |",
        f"| 워크오더 수 | {len(orders)} |",
        f"| 완료 | {len(orders) - len(incomplete)} |",
        f"| 미완 | {len(incomplete)} |",
        "| 재생성 | `python3 scripts/generate-work-orders.py` |",
        "| CSV 추출 | `python3 scripts/export-work-orders.py --issue-id AUTH-OAUTH` |",
        "",
        "## 에픽: 웹·설치형 OAuth / GA4 / 단일 Google 계정",
        "",
        "| 코드 | 이슈ID | 상태 | 요약 |",
        "|------|--------|------|------|",
        "| WO-2026-0154 | AUTH-OAUTH | 완료(분석) | GA + os.neu Sign-in vs Google 웹 세션 분리 설명 |",
        "| WO-2026-0155 | AUTH-OAUTH | 완료(구현) | GA4 `src/engine/ga4.ts` + `scripts/verify-ga4.sh` |",
        "| WO-2026-0156 | AUTH-OAUTH | **미완** | 웹·설치형 단일 Google SSO — 설계만, 구현 대기 |",
        "| WO-2026-0157 | META-WO | 완료 | 본 `work-orders.md` 전체 transcript 문서화 |",
        "",
        "**미완성 후속 ID:** `WO-AUTH-WEB-001` (호스팅 HTTPS + Supabase 프로덕션 redirect), `WO-AUTH-SSO-002` (브라우저 파티션 Google 쿠키 SSO)",
        "",
        "**구현 가능성 (OAuth 웹):** os.neu 계정 Google 로그인 **90%** · Gmail/YouTube 자동 SSO **40%** (별도 설계)",
        "",
        "**관련 문서:** [google-oauth.md](./google-oauth.md) · [browser-electron-features.md](./browser-electron-features.md) · [ai-use-guide.md](./ai-use-guide.md)",
        "",
        "## 팀 FAQ (빠른 답변)",
        "",
        "| 질문 | 답변 | 근거 WO |",
        "|------|------|---------|",
        "| 웹에서도 Google OAuth 로그인 되나요? | **가능**. Supabase OAuth + HTTPS redirect. 설치형보다 웹이 유리. | WO-0156 |",
        "| os.neu 로그인 = Gmail 자동 로그인? | **아님**. os.neu 토큰(Supabase)과 Google 웹 쿠키는 별개. | WO-0154 |",
        "| 설치형 Google 로그인 방식? | 시스템 Chrome + deep link/handoff (`docs/google-oauth.md`) | WO-0154 |",
        "| GA4 붙었나요? | 코드 반영됨. `.env`에 `VITE_GA4_MEASUREMENT_ID` 필요, Realtime 미검증 | WO-0155 |",
        "| 인앱 브라우저 검색 엔진? | Google (`src/engine/browser.ts`) | WO-0148~0150 |",
        "| transcript 갱신 시 문서도 갱신? | `python3 scripts/generate-work-orders.py` 후 export 스크립트 실행 | 가이드 |",
        "",
        "## 검증 요약",
        "",
        "| 항목 | 값 |",
        "|------|-----|",
        f"| 총 사용자 프롬프트 → 워크오더 | {len(orders)} |",
        f"| 완료 표시 | {len(orders) - len(incomplete)} |",
        f"| 진행중/미완 | {len(incomplete)} |",
        "",
        "### 이슈 ID 분포 (상위)",
        "",
        "| 이슈ID | 건수 |",
        "|--------|------|",
    ]
    for issue_id, n in counts.most_common(20):
        lines.append(f"| {issue_id} | {n} |")

    lines.extend(
        [
            "",
            "## 컬럼 정의",
            "",
            "| 컬럼 | 설명 |",
            "|------|------|",
            "| 코드 | 워크오더 고유 코드 WO-2026-NNNN |",
            "| 이슈ID | 기능/문서 영역 분류 |",
            "| 이슈 설명 | 이슈 한줄 요약 |",
            "| 프롬프트 인풋 | 사용자 원문 질의/요청 |",
            "| 프롬프트 아웃풋 | 에이전트 응답 요약(최대 6000자) |",
            "| 프롬프트 과정 내용 | 분석→구현→검증 흐름 |",
            "| 작업의 페인포인트 | 기술/UX 병목 |",
            "| 구체적인 설명 | 작업 범위 |",
            "| 작업 완료 여부 | 완료/진행중/미완 |",
            "| 미완성 ID | 미완 시 워크오더 코드 |",
            "| 사유 | 미완 사유 |",
            "| 시작년월일 | 프롬프트 타임스탬프 |",
            "| 종료 날짜 | 동일 세션 처리일 |",
            "| 에이전트ID | Cursor transcript UUID |",
            "| 에이전트 | Auto (Cursor Agent) |",
            "| 에이전트의 작업 과정 설명 | 도구·파일 변경 패턴 |",
            "| 에이전트 사유 | 의사결정 근거 |",
            "| 프롬프트 내용 | 프롬프트 인풋 전문 |",
            "",
            "## 마스터 인덱스",
            "",
            "| 코드 | 이슈ID | 완료 | 시작 | 프롬프트 인풋(요약) |",
            "|------|--------|------|------|-------------------|",
        ]
    )

    for o in orders:
        lines.append(
            f"| {o['code']} | {o['issue_id']} | {o['status']} | {o['ts'] or '—'} | {o['summary']} |"
        )

    lines.extend(["", "---", "", "## 워크오더 상세", ""])

    for i, o in enumerate(orders, start=1):
        lines.append(
            render_detail(i, o["pair"], o["issue_id"], o["overrides"])
        )

    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Regenerate docs/work-orders.md from transcript")
    parser.add_argument("--transcript", type=Path, default=DEFAULT_TRANSCRIPT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--dry-run", action="store_true", help="Print counts only")
    args = parser.parse_args()

    if not args.transcript.exists():
        raise SystemExit(f"Transcript not found: {args.transcript}")

    pairs = parse_pairs(args.transcript)
    if args.dry_run:
        print(f"pairs={len(pairs)} transcript={args.transcript}")
        return

    md = render_markdown(pairs, args.transcript)
    args.out.write_text(md, encoding="utf-8")
    print(f"Wrote {len(pairs)} work orders → {args.out}")


if __name__ == "__main__":
    main()
