#!/usr/bin/env bash
# Stop stale os.neu dev processes (bridge 4178, vite 5173/5174, electron).
set -euo pipefail

kill_port() {
  local port="$1"
  local pids
  pids="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)"
  if [[ -n "$pids" ]]; then
    echo "Stopping port $port (pid $pids)"
    kill $pids 2>/dev/null || true
  fi
}

kill_port 4178
kill_port 5173
kill_port 5174

pkill -f 'electron \. --no-sandbox' 2>/dev/null || true
pkill -f 'tsx server/index.ts' 2>/dev/null || true

rm -rf "${XDG_RUNTIME_DIR:-/tmp}/osneu-screen.lock" 2>/dev/null || true

echo "Done. Wait 2s then: npm run screen"
