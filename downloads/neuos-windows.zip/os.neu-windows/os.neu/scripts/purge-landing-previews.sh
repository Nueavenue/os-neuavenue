#!/usr/bin/env bash
# Remove temporary landing preview pages. Run when stakeholder says "파기".
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREVIEW="$ROOT/public/preview"
DOC="$ROOT/docs/landing-proposals-2026-08-28.md"

echo "Removing landing previews..."
rm -rf "$ROOT/public/preview"
rm -rf "$ROOT/public/landing-samples"
rm -f "$ROOT/docs/landing-proposals-2026-08-28.md"
rm -f "$ROOT/src/screens/LandingPreviews.tsx"
echo "Done. Removed:"
echo "  - public/preview/"
echo "  - docs/landing-proposals-2026-08-28.md (if existed)"
echo "Redeploy os.neuavenue.com to clear CDN cache."
