#!/usr/bin/env python3
"""Generate feature spec + doc catalog + verification report."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORT_DIR = ROOT / "docs" / "exports"


def run_script(name: str, *args: str) -> None:
    script = ROOT / "scripts" / name
    subprocess.run([sys.executable, str(script), *args], check=True, cwd=ROOT)


def verify() -> dict:
    from doc_registry_data import DOCS, FEATURES, FEATURE_SPEC_COLUMNS, EXTRA_DOC_PATHS
    from doc_registry_lib import discover_extra_docs

    known = {d["파일경로"] for d in DOCS}
    catalog = []
    for doc in DOCS:
        catalog.append(doc)
    catalog.extend(discover_extra_docs(ROOT, known, EXTRA_DOC_PATHS))
    missing_docs = [d["파일경로"] for d in DOCS if not (ROOT / d["파일경로"]).exists()]

    status_counts: dict[str, int] = {}
    for f in FEATURES:
        s = f.get("구현상태", "?")
        status_counts[s] = status_counts.get(s, 0) + 1

    cat_counts: dict[str, int] = {}
    for d in catalog:
        c = d.get("카테고리1", "?")
        cat_counts[c] = cat_counts.get(c, 0) + 1

    return {
        "feature_count": len(FEATURES),
        "feature_columns": len(FEATURE_SPEC_COLUMNS),
        "doc_catalog_count": len(catalog),
        "missing_docs": missing_docs,
        "status_counts": status_counts,
        "cat_counts": cat_counts,
    }


def main() -> None:
    print("=== os.neu doc registry generation ===\n")
    run_script("generate-feature-spec.py")
    run_script("generate-doc-catalog.py")

    v = verify()
    report_lines = [
        "# Registry verification report",
        "",
        f"- Features: **{v['feature_count']}** rows × **{v['feature_columns']}** columns",
        f"- Doc catalog: **{v['doc_catalog_count']}** documents",
        "",
        "## Feature status distribution",
        "",
    ]
    for status, n in sorted(v["status_counts"].items()):
        report_lines.append(f"- {status}: {n}")
    report_lines.extend(["", "## Doc category distribution", ""])
    for cat, n in sorted(v["cat_counts"].items()):
        report_lines.append(f"- {cat}: {n}")
    if v["missing_docs"]:
        report_lines.extend(["", "## Missing files (ERROR)", ""])
        for m in v["missing_docs"]:
            report_lines.append(f"- {m}")
    else:
        report_lines.extend(["", "## Missing files", "", "None — all cataloged primary docs exist."])

    report_path = EXPORT_DIR / "registry-verification.md"
    report_path.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    print(f"\nVerification → {report_path}")
    if v["missing_docs"]:
        sys.exit(1)
    print("OK — registry generation complete.")


if __name__ == "__main__":
    main()
