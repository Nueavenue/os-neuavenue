#!/usr/bin/env bash
# Plan B stage 1 — implement host Ubuntu sandbox without wiping disks / GRUB / USB.
# Prefers user-writable runtime/kiosk + ~/.local ollama when sudo is unavailable.
# Optional: --with-apt  (sudo apt install cage seatd)
# Optional: --kiosk-only  (stage cage+seatd into $ROOT/runtime/kiosk only — no
#   session pkexec ask, no ollama, no llama pull, no verify. WO-UI-NEU-INSTALL-
#   CAGE-CHAIN-121: this is what install-linux.sh chains into, so a host
#   install can get cage without also re-asking pkexec or pulling ~1.3GB of
#   ollama. Always exits 0 — fail soft, never fails the caller's install.)
set -euo pipefail
if [[ "$(uname -s)" != "Linux" ]]; then
  echo "Stage 1 is Linux only." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KIOSK="$ROOT/runtime/kiosk"
WITH_APT=0
KIOSK_ONLY=0
case "${1:-}" in
  --with-apt) WITH_APT=1 ;;
  --kiosk-only) KIOSK_ONLY=1 ;;
esac

log() { echo "stage1: $*"; }

if ((WITH_APT)); then
  if [[ "$(id -u)" != "0" ]]; then
    echo "Need root: sudo bash $ROOT/scripts/stage1-host.sh --with-apt" >&2
    exit 1
  fi
  apt-get update -qq
  apt-get install -y cage seatd
fi

stage_kiosk_user() {
  mkdir -p "$KIOSK"
  if [[ -x "$KIOSK/cage" ]] && [[ -x "$KIOSK/seatd" ]]; then
    log "kiosk already has cage+seatd at $KIOSK"
    return 0
  fi
  if command -v cage >/dev/null && command -v seatd >/dev/null; then
    cp -a "$(command -v cage)" "$KIOSK/cage"
    cp -a "$(command -v seatd)" "$KIOSK/seatd"
    log "copied system cage/seatd into $KIOSK"
    return 0
  fi
  if ! command -v apt-get >/dev/null || ! command -v dpkg-deb >/dev/null; then
    log "cannot download debs (no apt-get/dpkg-deb)"
    return 1
  fi
  local box
  box="$(mktemp -d)"
  mkdir -p "$box/partial"
  log "downloading cage/seatd debs (no root)…"
  if !(cd "$box" && apt-get download -q cage seatd libseat1 \
      libwayland-client0 libwayland-server0 libwayland-cursor0 libxkbcommon0 \
      libinput10 libdrm2 libgbm1 libegl1 libgles2 libpixman-1-0 2>/dev/null); then
    rm -rf "$box"
    return 1
  fi
  local deb
  for deb in "$box"/*.deb; do
    [[ -f "$deb" ]] || continue
    dpkg-deb -x "$deb" "$box/x" 2>/dev/null || true
  done
  mkdir -p "$KIOSK/lib"
  if [[ -d "$box/x/usr/bin" ]]; then
    for bin in cage weston seatd; do
      if [[ -x "$box/x/usr/bin/$bin" ]]; then
        cp -a "$box/x/usr/bin/$bin" "$KIOSK/$bin"
      fi
    done
  fi
  for bin in cage weston seatd; do
    for cand in "$box/x/usr/sbin/$bin" "$box/x/sbin/$bin" "$box/x/bin/$bin"; do
      if [[ -x "$cand" ]] && [[ ! -x "$KIOSK/$bin" ]]; then
        cp -a "$cand" "$KIOSK/$bin"
      fi
    done
  done
  # Shared libs next to binaries for RPATH-less launch via LD_LIBRARY_PATH
  if [[ -d "$box/x/usr/lib" ]]; then
    rsync -a "$box/x/usr/lib/" "$KIOSK/lib/" 2>/dev/null || cp -a "$box/x/usr/lib/." "$KIOSK/lib/" 2>/dev/null || true
  fi
  if [[ -d "$box/x/lib" ]]; then
    rsync -a "$box/x/lib/" "$KIOSK/lib/" 2>/dev/null || true
  fi
  rm -rf "$box"
  if [[ -x "$KIOSK/cage" ]]; then
    log "staged $KIOSK/cage"
    return 0
  fi
  log "cage still missing under $KIOSK"
  return 1
}

stage_ollama_user() {
  export PATH="${HOME}/.local/bin:${PATH}"
  if command -v ollama >/dev/null; then
    log "ollama on PATH: $(command -v ollama)"
    return 0
  fi
  local dest="$HOME/.local"
  mkdir -p "$dest/bin"
  if [[ -x "$dest/bin/ollama" ]]; then
    log "ollama at $dest/bin/ollama"
    return 0
  fi
  log "fetching ollama-linux-amd64.tar.zst into $dest (user install, ~1.3GB)…"
  local tg
  tg="$(mktemp --suffix=.tar.zst)"
  if ! curl -fsSL "https://ollama.com/download/ollama-linux-amd64.tar.zst" -o "$tg"; then
    rm -f "$tg"
    log "ollama download failed — later: curl -fsSL https://ollama.com/install.sh | sh"
    return 1
  fi
  if tar --help 2>&1 | grep -q zstd; then
    tar --zstd -xf "$tg" -C "$dest"
  elif command -v zstd >/dev/null; then
    zstd -d -c "$tg" | tar -xf - -C "$dest"
  else
    log "need zstd to unpack ollama (sudo apt install -y zstd)"
    rm -f "$tg"
    return 1
  fi
  rm -f "$tg"
  if [[ -x "$dest/bin/ollama" ]]; then
    :
  elif [[ -x "$dest/ollama" ]]; then
    ln -sf "$dest/ollama" "$dest/bin/ollama"
  fi
  export PATH="$dest/bin:$PATH"
  if command -v ollama >/dev/null; then
    log "ollama ready: $(command -v ollama)"
    return 0
  fi
  log "ollama binary not found after extract under $dest"
  return 1
}

ensure_ollama_daemon() {
  export PATH="${HOME}/.local/bin:${PATH}"
  if curl -sS -m 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    log "ollama already serving :11434"
    return 0
  fi
  if ! command -v ollama >/dev/null; then
    return 1
  fi
  log "starting ollama serve in background…"
  nohup ollama serve >/tmp/osneu-ollama-serve.log 2>&1 &
  local i=0
  while [[ "$i" -lt 30 ]]; do
    if curl -sS -m 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
      log "ollama HTTP up"
      return 0
    fi
    i=$((i + 1))
    sleep 1
  done
  log "ollama serve did not answer — see /tmp/osneu-ollama-serve.log"
  return 1
}

pull_lima() {
  export PATH="${HOME}/.local/bin:${PATH}"
  if ! command -v ollama >/dev/null; then
    return 1
  fi
  if curl -sS -m 2 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -q 'llama3.2'; then
    log "llama3.2 already present"
    return 0
  fi
  log "pulling llama3.2:1b (Lima-class on-device model)…"
  ollama pull llama3.2:1b
}

# WO-UI-NEU-INSTALL-CAGE-CHAIN-121: --kiosk-only stages cage+seatd and stops —
# no session pkexec ask (that is B21's job, already done by the caller), no
# ollama, no llama pull, no verify-b-stage1. Never a second pkexec. Fail
# soft: no net / no debs is not a script failure, this always exits 0.
if ((KIOSK_ONLY)); then
  if stage_kiosk_user; then
    log "kiosk-only: cage/seatd ready at $KIOSK"
  else
    log "kiosk-only: cage/seatd not staged (no net or no debs available)."
    log "kiosk-only: later — bash $ROOT/scripts/stage1-host.sh --kiosk-only   or   sudo apt install -y cage seatd"
  fi
  exit 0
fi

# session registration (user copy always; system needs root separately)
if [[ -x "$ROOT/scripts/install-osneu-session.sh" ]]; then
  bash "$ROOT/scripts/install-osneu-session.sh" || true
fi
# WO-UI-NEU-USB-GDM-SESSION-121 / WO-UI-NEU-GDM-PKEXEC-ASK-121: this is the
# first privilege elevation this script ever does, so ask y/N first
# (default N) instead of running pkexec unasked. No TTY (pipe/CI) → skip
# the prompt and pkexec entirely, print the manual sudo line, never hang,
# never block the rest of stage 1.
ASK_PKEXEC_STAGE1=0
if command -v pkexec >/dev/null 2>&1; then
  if [[ -t 0 ]]; then
    ASK_PKEXEC_STAGE1=1
  else
    log "no terminal attached — skipping the system GDM session prompt"
  fi
fi

DID_REGISTER_SYSTEM_SESSION_STAGE1=0
if [[ "$ASK_PKEXEC_STAGE1" == 1 ]]; then
  ANSWER_PKEXEC_STAGE1=""
  read -r -p "Register the system GDM session (os.neu) now? Needs your password via pkexec. [y/N] " ANSWER_PKEXEC_STAGE1 || ANSWER_PKEXEC_STAGE1=""
  case "$ANSWER_PKEXEC_STAGE1" in
    y|Y|yes|YES)
      log "attempting system GDM session registration (may prompt for your password)…"
      if pkexec env NEUOS_TARGET_USER="$(id -un)" NEUOS_HOME="$HOME" NEUOS_EXEC_ROOT="$ROOT" \
          bash "$ROOT/scripts/install-osneu-session.sh"; then
        log "system GDM session os.neu registered"
        DID_REGISTER_SYSTEM_SESSION_STAGE1=1
      else
        log "system GDM session NOT registered (pkexec declined or failed)"
      fi
      ;;
    *)
      log "skipped (default N)"
      ;;
  esac
fi
if [[ "$DID_REGISTER_SYSTEM_SESSION_STAGE1" != 1 ]]; then
  log "system GDM session needs: sudo bash $ROOT/scripts/install-osneu-session.sh"
fi

stage_kiosk_user || true
stage_ollama_user || true
ensure_ollama_daemon || true
pull_lima || true

# Mirror kiosk into planted tree when writable (USB plant may leave root-owned runtime/)
if [[ -d "$HOME/os.neu" ]] && [[ -x "$KIOSK/cage" ]]; then
  if [[ -w "$HOME/os.neu/runtime" ]] || mkdir -p "$HOME/os.neu/runtime/kiosk" 2>/dev/null; then
    mkdir -p "$HOME/os.neu/runtime/kiosk"
    if cp -a "$KIOSK/." "$HOME/os.neu/runtime/kiosk/" 2>/dev/null; then
      log "synced kiosk → ~/os.neu/runtime/kiosk"
    else
      log "NOTE: ~/os.neu/runtime is root-owned — skip kiosk sync. Fix: sudo chown -R \"$USER:$USER\" \"$HOME/os.neu/runtime\""
    fi
  else
    log "NOTE: cannot write ~/os.neu/runtime (root from USB plant). sudo chown -R \"$USER:$USER\" \"$HOME/os.neu/runtime\""
  fi
  if [[ -f "$ROOT/boot/plant.mjs" ]] && [[ -w "$HOME/os.neu/boot" ]]; then
    cp -a "$ROOT/boot/plant.mjs" "$HOME/os.neu/boot/plant.mjs" 2>/dev/null || true
  fi
fi

echo
bash "$ROOT/scripts/verify-b-stage1.sh"
