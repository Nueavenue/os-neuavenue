#!/usr/bin/env bash
# Register os.neu as a GDM Wayland session on this Ubuntu machine.
# Does not wipe disks. Does not change GRUB. Does not enable autologin unless --autologin.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# WO-UI-NEU-USB-GDM-SESSION-121: pkexec (unlike sudo) does not forward $SUDO_USER
# or the caller's $USER by default, so a pkexec-elevated call must pass the
# target user explicitly (`pkexec env NEUOS_TARGET_USER=... bash ...`) or this
# would otherwise register the session under root's own home.
USER_NAME="${NEUOS_TARGET_USER:-${SUDO_USER:-${USER:-$(id -un)}}}"
HOME_DIR="$(getent passwd "$USER_NAME" 2>/dev/null | cut -d: -f6)"
HOME_DIR="${HOME_DIR:-${NEUOS_HOME:-$HOME}}"
EXEC_ROOT="${NEUOS_EXEC_ROOT:-$ROOT}"
# JeOS plant bind-mounts the Ubuntu disk at /mnt/osneu-host. Exec=/Path= in the
# written session file must be a path that still exists after a normal Ubuntu
# reboot (no that prefix). Same fix as install-autostart.sh.
if [[ "$HOME_DIR" == /mnt/osneu-host/* ]]; then
  HOME_DIR="${HOME_DIR#/mnt/osneu-host}"
fi
if [[ "$ROOT" == /mnt/osneu-host/* ]]; then
  ROOT="${ROOT#/mnt/osneu-host}"
fi
if [[ "$EXEC_ROOT" == /mnt/osneu-host/* ]]; then
  EXEC_ROOT="${EXEC_ROOT#/mnt/osneu-host}"
fi
if [[ -x "$HOME_DIR/os.neu/scripts/osneu-session.sh" ]]; then
  EXEC_ROOT="$HOME_DIR/os.neu"
fi
AUTOLOGIN=0
if [[ "${1:-}" == "--autologin" ]]; then
  AUTOLOGIN=1
fi

SESSION_BODY="[Desktop Entry]
Name=os.neu
Comment=os.neu screen on this machine — Ubuntu stays the kernel
Exec=bash $EXEC_ROOT/scripts/osneu-session.sh
TryExec=bash
Type=Application
DesktopNames=os.neu;GNOME
"

LOCAL="$HOME_DIR/.local/share/wayland-sessions"
mkdir -p "$LOCAL"
printf '%s\n' "$SESSION_BODY" > "$LOCAL/os.neu.desktop"
chmod +x "$EXEC_ROOT/scripts/osneu-session.sh" "$EXEC_ROOT/scripts/open-neuos.sh" 2>/dev/null || true

SYSTEM="/usr/share/wayland-sessions/os.neu.desktop"
if [[ "$(id -u)" == "0" ]]; then
  mkdir -p /usr/share/wayland-sessions
  printf '%s\n' "$SESSION_BODY" > "$SYSTEM"
  echo "GDM session: $SYSTEM"
else
  echo "user session copy: $LOCAL/os.neu.desktop"
  echo "GDM reads /usr/share/wayland-sessions. Install with:"
  echo "  sudo bash $ROOT/scripts/install-osneu-session.sh"
fi

if command -v cage >/dev/null || [[ -x "$EXEC_ROOT/runtime/kiosk/cage" ]]; then
  :
else
  echo "cage is not installed. Without it the session falls back to gnome-shell (Ubuntu desktop still visible)."
  echo "For a screen-only seat: bash $ROOT/scripts/stage1-host.sh   or  sudo apt install -y cage seatd"
fi

if [[ "$AUTOLOGIN" == 1 ]]; then
  if [[ "$(id -u)" != "0" ]]; then
    echo "--autologin needs root. sudo bash $ROOT/scripts/install-osneu-session.sh --autologin" >&2
    exit 1
  fi
  GDM=""
  for cand in /etc/gdm3/custom.conf /etc/gdm/custom.conf; do
    if [[ -f "$cand" ]]; then
      GDM="$cand"
      break
    fi
  done
  if [[ -z "$GDM" ]]; then
    echo "No GDM custom.conf on this machine. Skip autologin." >&2
    exit 0
  fi
  if grep -q '^AutomaticLogin=' "$GDM" 2>/dev/null; then
    sed -i "s/^AutomaticLogin=.*/AutomaticLogin=$USER_NAME/" "$GDM"
  else
    if grep -q '^\[daemon\]' "$GDM"; then
      sed -i "/^\[daemon\]/a AutomaticLoginEnable=true\nAutomaticLogin=$USER_NAME" "$GDM"
    else
      printf '\n[daemon]\nAutomaticLoginEnable=true\nAutomaticLogin=%s\n' "$USER_NAME" >> "$GDM"
    fi
  fi
  if ! grep -q '^AutomaticLoginEnable=' "$GDM"; then
    sed -i "/^\[daemon\]/a AutomaticLoginEnable=true" "$GDM"
  else
    sed -i "s/^AutomaticLoginEnable=.*/AutomaticLoginEnable=true/" "$GDM"
  fi
  ACC="/var/lib/AccountsService/users/$USER_NAME"
  if [[ -f "$ACC" ]]; then
    if grep -q '^Session=' "$ACC"; then
      sed -i 's/^Session=.*/Session=os.neu/' "$ACC"
    else
      printf '\nSession=os.neu\n' >> "$ACC"
    fi
  fi
  echo "GDM autologin: $USER_NAME session os.neu ($GDM)"
  echo "Reboot. Ubuntu remains the OS. The first graphical seat is os.neu."
fi

echo "Next: reboot or log out. At GDM, gear icon → os.neu."
echo "USB JeOS still cannot take the GPU seat (OS-NEU-SX-000). This session is the Ubuntu path."
