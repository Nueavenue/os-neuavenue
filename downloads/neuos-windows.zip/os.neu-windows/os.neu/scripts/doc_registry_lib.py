"""Shared utilities for doc/feature registry generation."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORT_DIR = ROOT / "docs" / "exports"


def write_csv(path: Path, columns: list[str], rows: list[dict[str, str]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({col: row.get(col, "") for col in columns})
    return len(rows)


def file_mtime(path: Path) -> str:
    if not path.exists():
        return "MISSING"
    ts = path.stat().st_mtime
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")


def discover_extra_docs(root: Path, known_paths: set[str], extra_paths: list[str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    seq = 100
    for rel in extra_paths:
        if rel in known_paths:
            continue
        p = root / rel
        if not p.exists():
            continue
        seq += 1
        name = p.stem.replace("-", " ").title()
        cat = "CAT-META"
        sub = "Discovered"
        if "usb" in rel.lower():
            cat, sub = "CAT-USER", "USB"
        elif "security" in rel.lower() or "dprk" in rel.lower():
            cat, sub = "CAT-SECURITY", "Watch"
        elif "architecture" in rel.lower():
            cat, sub = "CAT-ARCHITECTURE", "Implementation"
        elif "verification" in rel.lower() or "fail" in rel.lower():
            cat, sub = "CAT-VERIFICATION", "Report"
        elif "boot" in rel.lower():
            cat, sub = "CAT-DEPLOY", "Boot"
        rows.append(
            {
                "문서ID": f"DOC-{seq:03d}",
                "카테고리1": cat,
                "카테고리2": sub,
                "문서명": name,
                "파일경로": rel,
                "언어": "EN",
                "대상독자": "개발",
                "문서성격": "자동발견",
                "요약": f"README/catalog 외 경로 — {rel}",
                "관련기능ID": "—",
                "FAQ키워드": p.stem,
                "상위문서": "docs/README.md",
                "연관문서": "—",
                "파일수정일": file_mtime(p),
            }
        )
    return rows
