# Twin of uninstall-autostart.sh. No wipe. No HKLM.
#   powershell -File scripts/uninstall-windows.ps1
#   powershell -File scripts/uninstall-windows.ps1 -Files
param([switch]$Files)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $here 'install-windows.ps1') -Uninstall -Files:$Files
