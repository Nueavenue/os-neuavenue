import { describe, expect, it } from 'vitest'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { assertSafePlantDest, canLaunchGraphicalScreen, defaultPlantDir, ensureOsNeuFolder, hostVisiblePath, isHelpCommand, isOpenScreenCommand, isPlantCommand, isUninstallCommand, launchScreen, linuxDesktopFile, linuxUserService, linuxWaylandSession, printInstallInterfacesDialog, printScreenFallbackGuide, screenOpenCommand, shouldSkip, writePlantAutostart } from './plant.mjs'
import { destIsUsbStick } from './hostVolume.mjs'

describe('os.neu plant', () => {
  it('recognizes uninstall os.neu', () => {
    expect(isUninstallCommand('uninstall os.neu')).toBe(true)
    expect(isUninstallCommand('os.neu 제거')).toBe(true)
    expect(isUninstallCommand('install os.neu')).toBe(false)
  })

  it('recognizes the console install command', () => {
    expect(isPlantCommand('install os.neu')).toBe(true)
    expect(isPlantCommand('INSTALL OS.NEU')).toBe(true)
    expect(isPlantCommand('install firefox')).toBe(false)
  })

  it('recognizes open os.neu and help without treating them as install', () => {
    expect(isOpenScreenCommand('open os.neu')).toBe(true)
    expect(isOpenScreenCommand('open screen')).toBe(true)
    expect(isOpenScreenCommand('screen')).toBe(true)
    expect(isOpenScreenCommand('화면 열기')).toBe(true)
    expect(isOpenScreenCommand('open')).toBe(false)
    expect(isOpenScreenCommand('install os.neu')).toBe(false)
    expect(isHelpCommand('help')).toBe(true)
    expect(isHelpCommand('가이드')).toBe(true)
  })

  it('maps USB mount icon paths to the host home path', () => {
    expect(hostVisiblePath('/mnt/osneu-host/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png')).toBe(
      '/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png',
    )
    expect(hostVisiblePath('/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png')).toBe(
      '/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png',
    )
  })

  it('prints the USB install interfaces dialog', () => {
    const lines = []
    printInstallInterfacesDialog('~/os.neu', { kiosk: '/home/billy-lee/os.neu/runtime/kiosk' }, (line) => lines.push(line))
    const body = lines.join('\n')
    expect(body).toContain('os.neu interfaces')
    expect(body).toContain('~/.local/share/applications/neuos.desktop')
    expect(body).toContain('~/Desktop/neuos.desktop')
    expect(body).toContain('USB kiosk copied')
    expect(body).toContain('This box is the install dialog')
  })

  it('prints a fallback that runs the launcher without cd', () => {
    expect(screenOpenCommand('/home/billy-lee/os.neu')).toBe('bash ~/os.neu/scripts/open-neuos.sh')
    expect(screenOpenCommand('/mnt/osneu-host/home/billy-lee/os.neu')).toBe('bash ~/os.neu/scripts/open-neuos.sh')
    expect(screenOpenCommand('/os.neu')).toBe('bash ~/os.neu/scripts/open-neuos.sh')
    expect(screenOpenCommand('/root/os.neu')).toBe('bash ~/os.neu/scripts/open-neuos.sh')
    const lines = []
    printScreenFallbackGuide('/mnt/osneu-host/home/billy-lee/os.neu', (line) => lines.push(line))
    expect(lines.join('\n')).toContain('OS-NEU-SX-000')
    expect(lines.join('\n')).toContain('open os.neu')
    expect(lines.join('\n')).toContain('bash ~/os.neu/scripts/open-neuos.sh')
    expect(lines.join('\n')).not.toMatch(/bash \/os\.neu\//)
    expect(lines.join('\n')).not.toContain('/mnt/')
    expect(lines.join('\n')).toContain('You do not need to cd')
  })

  it('defaults to the home os.neu folder', () => {
    expect(defaultPlantDir()).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('creates os.neu under a chosen parent', () => {
    expect(ensureOsNeuFolder(os.homedir())).toBe(path.join(os.homedir(), 'os.neu'))
    expect(ensureOsNeuFolder(path.join(os.homedir(), 'os.neu'))).toBe(path.join(os.homedir(), 'os.neu'))
  })

  it('refuses block devices and system roots', () => {
    expect(() => assertSafePlantDest('/dev/sda')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/')).toThrow('unsafe-dest')
    expect(() => assertSafePlantDest('/proc/self')).toThrow('unsafe-dest')
  })

  it('does not copy secrets or builder keys onto a planted tree', () => {
    expect(shouldSkip('.env')).toBe(true)
    expect(shouldSkip('.env.local')).toBe(true)
    expect(shouldSkip('user-llm.json')).toBe(true)
    expect(shouldSkip('accounts.json')).toBe(true)
    expect(shouldSkip('kernel.mjs')).toBe(false)
  })

  it('does not launch Electron on the USB JeOS console', () => {
    const prev = process.env.NEUOS_JEOS
    process.env.NEUOS_JEOS = '1'
    expect(canLaunchGraphicalScreen()).toBe(false)
    if (prev === undefined) delete process.env.NEUOS_JEOS
    else process.env.NEUOS_JEOS = prev
  })

  it('writes a Linux launcher that does not require cd', () => {
    const body = linuxDesktopFile({
      execRoot: '/home/billy-lee/os.neu',
      icon: 'os.neu',
    })
    expect(body).toContain('Exec=bash /home/billy-lee/os.neu/scripts/open-neuos.sh')
    expect(body).toContain('Categories=Utility;')
    expect(body).toContain('Icon=os.neu')
    expect(body).toContain('Keywords=os.neu;neuos;neuOS;screen;')
    expect(
      linuxDesktopFile({
        execRoot: '/home/billy-lee/os.neu',
        icon: 'os.neu',
        iconPath: '/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png',
      }),
    ).toContain('Icon=/home/billy-lee/.local/share/icons/hicolor/256x256/apps/os.neu.png')
    expect(linuxUserService({ execRoot: '/home/billy-lee/os.neu' })).toContain('WantedBy=graphical-session.target')
    expect(linuxWaylandSession({ execRoot: '/home/billy-lee/os.neu' })).toContain('Exec=bash /home/billy-lee/os.neu/scripts/osneu-session.sh')
    expect(linuxWaylandSession({ execRoot: '/home/billy-lee/os.neu' })).toContain('DesktopNames=os.neu;GNOME')
  })

  it('USB install launches the host-chroot screen path, not a stick folder', () => {
    const prev = process.env.NEUOS_JEOS
    const dry = process.env.NEUOS_USB_SCREEN_DRY
    process.env.NEUOS_JEOS = '1'
    process.env.NEUOS_USB_SCREEN_DRY = '1'
    try {
      expect(destIsUsbStick('/os.neu')).toBe(true)
      const launched = launchScreen('/mnt/osneu-host/home/billy-lee/os.neu', 'lui', {
        host: {
          mount: '/mnt/osneu-host',
          user: 'billy-lee',
          osNeuRel: '/home/billy-lee/os.neu',
        },
      })
      expect(launched.ok).toBe(true)
      expect(launched.via).toBe('usb-host')
    } finally {
      if (prev === undefined) delete process.env.NEUOS_JEOS
      else process.env.NEUOS_JEOS = prev
      if (dry === undefined) delete process.env.NEUOS_USB_SCREEN_DRY
      else process.env.NEUOS_USB_SCREEN_DRY = dry
    }
  })

  // WO-UI-NEU-USB-GDM-SESSION-121
  describe('writePlantAutostart — system GDM session (INC-2026-005)', () => {
    it('strips /mnt/osneu-host from every Exec= even if the caller forgets to', async () => {
      const home = mkdtempSync(path.join(os.tmpdir(), 'osneu-home-'))
      try {
        const result = await writePlantAutostart('/mnt/osneu-host/home/billy-lee/os.neu', {
          homeDir: home,
          execRoot: '/mnt/osneu-host/home/billy-lee/os.neu',
        })
        const session = readFileSync(path.join(home, '.local/share/wayland-sessions/os.neu.desktop'), 'utf8')
        const launcher = readFileSync(path.join(home, '.local/share/applications/neuos.desktop'), 'utf8')
        const unit = readFileSync(path.join(home, '.config/systemd/user/neuos.service'), 'utf8')
        expect(session).not.toContain('/mnt/osneu-host')
        expect(session).toContain('Exec=bash /home/billy-lee/os.neu/scripts/osneu-session.sh')
        expect(launcher).not.toContain('/mnt/osneu-host')
        expect(unit).not.toContain('/mnt/osneu-host')
        // No hostRoot passed — system session must be reported as skipped, not silently attempted.
        expect(result.systemSession).toBe('skipped')
      } finally {
        rmSync(home, { recursive: true, force: true })
      }
    })

    it('writes the system GDM session under a writable host mount and reports it', async () => {
      const home = mkdtempSync(path.join(os.tmpdir(), 'osneu-home-'))
      const hostRoot = mkdtempSync(path.join(os.tmpdir(), 'osneu-host-'))
      try {
        mkdirSync(path.join(hostRoot, 'usr/share'), { recursive: true })
        const result = await writePlantAutostart(path.join(home, 'os.neu'), {
          homeDir: home,
          execRoot: path.join(home, 'os.neu'),
          hostRoot,
        })
        expect(result.systemSession).toBe('written')
        expect(result.systemSessionError).toBe('')
        const written = readFileSync(path.join(hostRoot, 'usr/share/wayland-sessions/os.neu.desktop'), 'utf8')
        expect(written).toContain('DesktopNames=os.neu;GNOME')
        expect(written).not.toContain('/mnt/osneu-host')
      } finally {
        rmSync(home, { recursive: true, force: true })
        rmSync(hostRoot, { recursive: true, force: true })
      }
    })

    it('does not swallow a failed/impossible host /usr write — reports it on the result', async () => {
      const home = mkdtempSync(path.join(os.tmpdir(), 'osneu-home-'))
      const hostRoot = mkdtempSync(path.join(os.tmpdir(), 'osneu-host-'))
      try {
        // No usr/share under this "host mount" at all (e.g. mount failed to
        // populate) — must be reported as failed, never silently skipped
        // without a reason, and must never throw past this function.
        const result = await writePlantAutostart(path.join(home, 'os.neu'), {
          homeDir: home,
          execRoot: path.join(home, 'os.neu'),
          hostRoot,
        })
        expect(result.systemSession).toBe('failed')
        expect(result.systemSessionError).toContain('usr/share')

        // Now simulate a real write failure: usr/share exists but
        // wayland-sessions is blocked by a same-named file, so mkdir throws.
        mkdirSync(path.join(hostRoot, 'usr/share'), { recursive: true })
        writeFileSync(path.join(hostRoot, 'usr/share/wayland-sessions'), 'not a directory')
        const result2 = await writePlantAutostart(path.join(home, 'os.neu'), {
          homeDir: home,
          execRoot: path.join(home, 'os.neu'),
          hostRoot,
        })
        expect(result2.systemSession).toBe('failed')
        expect(result2.systemSessionError).not.toBe('')
      } finally {
        rmSync(home, { recursive: true, force: true })
        rmSync(hostRoot, { recursive: true, force: true })
      }
    })
  })
})
