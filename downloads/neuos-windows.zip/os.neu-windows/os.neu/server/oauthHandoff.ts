/** Short-lived Google OAuth tokens for Electron ↔ system-browser handoff. */

import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

type Handoff = { token: string; at: number }
type Begin = { at: number }
type Verifier = { verifier: string; at: number }

const TTL_MS = 10 * 60 * 1000
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const FILE = path.join(ROOT, 'data', 'oauth-handoff.json')

type Store = {
  tokens: Record<string, Handoff>
  awaiting: Record<string, Begin>
  // PKCE code_verifier, server-side only (WO-AUTH-ELECTRON-PKCE-1). Never sent
  // to the guest callback page — generated in /oauth/google, consumed once in
  // the code-exchange route.
  verifiers: Record<string, Verifier>
}

const mem: Store = { tokens: {}, awaiting: {}, verifiers: {} }
let loaded = false

async function ensureLoaded() {
  if (loaded) return
  loaded = true
  try {
    const raw = JSON.parse(await readFile(FILE, 'utf8')) as Store
    if (raw?.tokens && typeof raw.tokens === 'object') mem.tokens = raw.tokens
    if (raw?.awaiting && typeof raw.awaiting === 'object') mem.awaiting = raw.awaiting
    if (raw?.verifiers && typeof raw.verifiers === 'object') mem.verifiers = raw.verifiers
  } catch {
    /* first run */
  }
  prune()
}

async function persist() {
  try {
    await mkdir(path.dirname(FILE), { recursive: true })
    await writeFile(FILE, JSON.stringify(mem, null, 2))
  } catch {
    /* best-effort */
  }
}

function prune(now = Date.now()) {
  for (const [id, row] of Object.entries(mem.tokens)) {
    if (now - row.at > TTL_MS) delete mem.tokens[id]
  }
  for (const [id, row] of Object.entries(mem.awaiting)) {
    if (now - row.at > TTL_MS) delete mem.awaiting[id]
  }
  for (const [id, row] of Object.entries(mem.verifiers)) {
    if (now - row.at > TTL_MS) delete mem.verifiers[id]
  }
}

export async function beginOAuthHandoff(id: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  if (!neat) return false
  prune()
  mem.awaiting[neat] = { at: Date.now() }
  await persist()
  return true
}

export async function putOAuthHandoff(id: string, token: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  const tok = String(token || '').trim()
  if (!tok) return false
  prune()
  let key = neat
  if (!key) {
    // Supabase sometimes drops redirect query params — attach to newest awaiting session.
    const newest = Object.entries(mem.awaiting).sort((a, b) => b[1].at - a[1].at)[0]
    if (!newest) return false
    key = newest[0]
  }
  mem.tokens[key] = { token: tok, at: Date.now() }
  delete mem.awaiting[key]
  await persist()
  return true
}

/** Non-destructive read so multiple pollers / resume after reopen still work. */
export async function peekOAuthHandoff(id: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  if (!neat) return null
  prune()
  return mem.tokens[neat]?.token ?? null
}

export async function takeOAuthHandoff(id: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  if (!neat) return null
  prune()
  const row = mem.tokens[neat]
  if (!row) return null
  delete mem.tokens[neat]
  await persist()
  return row.token
}

/** Store a PKCE code_verifier for this handoff id. Server-side only. */
export async function putVerifier(id: string, verifier: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  const v = String(verifier || '').trim()
  if (!neat || !v) return false
  prune()
  mem.verifiers[neat] = { verifier: v, at: Date.now() }
  await persist()
  return true
}

/** Consume (single-use) the stored code_verifier for this handoff id. */
export async function takeVerifier(id: string) {
  await ensureLoaded()
  const neat = String(id || '').trim()
  if (!neat) return null
  prune()
  const row = mem.verifiers[neat]
  if (!row) return null
  delete mem.verifiers[neat]
  await persist()
  return row.verifier
}
