import { describe, expect, it } from 'vitest'
import { pkceChallenge, pkceVerifier } from './pkce.ts'

describe('pkce', () => {
  it('verifier is url-safe and non-trivial length', () => {
    const v = pkceVerifier()
    expect(v.length).toBeGreaterThanOrEqual(43)
    expect(/^[A-Za-z0-9_-]+$/.test(v)).toBe(true)
  })

  it('two verifiers differ (random)', () => {
    expect(pkceVerifier()).not.toBe(pkceVerifier())
  })

  it('challenge is deterministic for the same verifier', () => {
    const v = pkceVerifier()
    expect(pkceChallenge(v)).toBe(pkceChallenge(v))
  })

  it('challenge is url-safe and differs from the verifier', () => {
    const v = pkceVerifier()
    const c = pkceChallenge(v)
    expect(/^[A-Za-z0-9_-]+$/.test(c)).toBe(true)
    expect(c).not.toBe(v)
  })
})
