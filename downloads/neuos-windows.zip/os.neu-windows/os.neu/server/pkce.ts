/**
 * PKCE (RFC 7636) helpers for WO-AUTH-ELECTRON-PKCE-1. The verifier is
 * generated and consumed entirely on this bridge process — it is never sent
 * to the guest callback page rendered in system Chrome.
 */
import { createHash, randomBytes } from 'node:crypto'

function base64url(input: Buffer) {
  return input.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

/** 43–128 char unreserved-charset string per RFC 7636 §4.1 (we use 64). */
export function pkceVerifier() {
  return base64url(randomBytes(48))
}

/** S256 challenge = BASE64URL(SHA256(verifier)), per RFC 7636 §4.2. */
export function pkceChallenge(verifier: string) {
  return base64url(createHash('sha256').update(verifier).digest())
}
