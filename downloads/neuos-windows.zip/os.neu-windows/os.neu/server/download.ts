import { createReadStream, existsSync } from 'node:fs'
import { mkdir, rm, writeFile, cp, readFile } from 'node:fs/promises'
import { execFile } from 'node:child_process'
import path from 'node:path'
import { promisify } from 'node:util'
import type { ServerResponse } from 'node:http'
import { fileURLToPath } from 'node:url'

const execFileAsync = promisify(execFile)
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const PACK = path.join(ROOT, 'dist', 'neuos-installer.tar.gz')
const BOOT_KIT = path.join(ROOT, 'dist', 'neuos-boot-kit.tar.gz')
const LINUX_PACK = path.join(ROOT, 'dist', 'neuos-linux.tar.gz')
const WINDOWS_PACK = path.join(ROOT, 'dist', 'neuos-windows.zip')
const WINDOWS_PREBUILT = path.join(ROOT, 'dist', 'os.neu-win-0.1.0-x64.zip')
const ISO = path.join(ROOT, 'dist', 'neuos-live.iso')

const LINUX_TREE = [
  'src',
  'electron',
  'server',
  'public',
  'boot',
  'scripts',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'tsconfig.app.json',
  'tsconfig.node.json',
  'vite.config.ts',
  'vitest.config.ts',
  'index.html',
]

export async function buildInstallerPack(): Promise<string> {
  await mkdir(path.join(ROOT, 'dist'), { recursive: true })
  await execFileAsync(
    'tar',
    [
      '-czf',
      PACK,
      '--exclude=node_modules',
      '--exclude=.git',
      '--exclude=dist',
      '--exclude=.env',
      'scripts/make-usb.sh',
      'scripts/install-autostart.sh',
      'scripts/install-linux.sh',
      'scripts/trust-launchers.sh',
      'scripts/uninstall-autostart.sh',
      'scripts/open-neuos.sh',
      'boot',
      'docs/user-guide.md',
      'docs/overview.md',
      'docs/student-usb-guide.md',
      'docs/usb-console-guide.md',
      'public/docs',
      'public/welcome',
      'public/brand',
      'package.json',
    ],
    { cwd: ROOT, timeout: 60_000 },
  )
  await execFileAsync('cp', ['-f', PACK, BOOT_KIT], { timeout: 10_000 })
  return BOOT_KIT
}

export async function buildLinuxScreenPack(): Promise<string> {
  await mkdir(path.join(ROOT, 'dist'), { recursive: true })
  const stage = path.join(ROOT, 'dist', 'neuos-linux-stage')
  const wrap = path.join(stage, 'os.neu-linux')
  const app = path.join(wrap, 'os.neu')
  await rm(stage, { recursive: true, force: true })
  await mkdir(app, { recursive: true })
  for (const item of LINUX_TREE) {
    const from = path.join(ROOT, item)
    if (!existsSync(from)) continue
    await cp(from, path.join(app, item), {
      recursive: true,
      filter: (src) => {
        const rel = src.slice(ROOT.length)
        if (rel.includes(`${path.sep}node_modules${path.sep}`) || rel.endsWith(`${path.sep}node_modules`)) return false
        if (rel.includes(`${path.sep}.git${path.sep}`) || rel.endsWith(`${path.sep}.git`)) return false
        if (rel.includes(`${path.sep}dist${path.sep}`) || rel.endsWith(`${path.sep}dist`)) return false
        if (path.basename(src) === '.env' || path.basename(src).startsWith('.env.')) return false
        return true
      },
    })
  }
  await writeFile(path.join(wrap, 'install.sh'), await readFile(path.join(ROOT, 'scripts/install-linux-root.sh'), 'utf8'), {
    mode: 0o755,
  })
  await writeFile(
    path.join(wrap, 'Install-os.neu.desktop'),
    `[Desktop Entry]
Type=Application
Name=Install os.neu
Comment=Copy os.neu to this Linux home and plant Apps + Desktop icons
Exec=bash -c 'f=%k; f=\${f#file://}; cd "$(dirname "$f")" && bash ./install.sh'
Terminal=true
Categories=Utility;
`,
    { mode: 0o755 },
  )
  await writeFile(
    path.join(wrap, 'README.txt'),
    `os.neu Linux screen
Linux only. Does not wipe disks.

  tar -xzf neuos-linux.tar.gz
  bash os.neu-linux/install.sh

Then click the os.neu icon in Applications (Show Apps) or on the Desktop.
install.sh plants those icons automatically. You do not need to cd ~/os.neu.
The window is resizable.

Need Node.js 20+ and npm on this PC.
Double-click Install-os.neu.desktop (Allow Launching) or:

  bash os.neu-linux/install.sh
`,
    'utf8',
  )
  await execFileAsync('tar', ['-czf', LINUX_PACK, '-C', stage, 'os.neu-linux'], {
    timeout: 120_000,
  })
  await rm(stage, { recursive: true, force: true })
  return LINUX_PACK
}

export async function buildWindowsScreenPack(): Promise<string> {
  await mkdir(path.join(ROOT, 'dist'), { recursive: true })
  const stage = path.join(ROOT, 'dist', 'neuos-windows-stage')
  const wrap = path.join(stage, 'os.neu-windows')
  const app = path.join(wrap, 'os.neu')
  await rm(stage, { recursive: true, force: true })
  await mkdir(app, { recursive: true })
  for (const item of LINUX_TREE) {
    const from = path.join(ROOT, item)
    if (!existsSync(from)) continue
    await cp(from, path.join(app, item), {
      recursive: true,
      filter: (src) => {
        const rel = src.slice(ROOT.length)
        if (rel.includes(`${path.sep}node_modules${path.sep}`) || rel.endsWith(`${path.sep}node_modules`)) return false
        if (rel.includes(`${path.sep}.git${path.sep}`) || rel.endsWith(`${path.sep}.git`)) return false
        if (rel.includes(`${path.sep}dist${path.sep}`) || rel.endsWith(`${path.sep}dist`)) return false
        if (path.basename(src) === '.env' || path.basename(src).startsWith('.env.')) return false
        return true
      },
    })
  }
  await writeFile(path.join(wrap, 'install-windows.ps1'), await readFile(path.join(ROOT, 'scripts/install-windows.ps1'), 'utf8'))
  await writeFile(
    path.join(wrap, 'README.txt'),
    `os.neu on Windows
Not the Linux tar. Not WSL2. USB ISO from the site is Linux JeOS (Rufus) — it does not plant Start Menu.

  Expand-Archive neuos-windows.zip
  powershell -ExecutionPolicy Bypass -File os.neu-windows\\install-windows.ps1

That copies to %USERPROFILE%\\os.neu and creates Desktop + Start Menu shortcuts named os.neu.
Logon is off unless you pass -EnableLogon (HKCU Run only, never also Startup folder).

Need Node.js 20+ and npm. install-windows.ps1 runs npm install so Electron is the Windows build.

  powershell -File os.neu-windows\\os.neu\\scripts\\uninstall-windows.ps1
`,
    'utf8',
  )
  if (existsSync(WINDOWS_PACK)) await rm(WINDOWS_PACK)
  await execFileAsync('zip', ['-r', '-q', WINDOWS_PACK, 'os.neu-windows'], {
    cwd: stage,
    timeout: 120_000,
  })
  await rm(stage, { recursive: true, force: true })
  return WINDOWS_PACK
}

export function sendFile(res: ServerResponse, file: string, name: string, type: string) {
  res.writeHead(200, {
    'content-type': type,
    'content-disposition': `attachment; filename="${name}"`,
    'cache-control': 'no-store',
  })
  createReadStream(file).pipe(res)
}

export function isoPath(): string | null {
  return existsSync(ISO) ? ISO : null
}

export function linuxPackPath(): string | null {
  return existsSync(LINUX_PACK) ? LINUX_PACK : null
}

export function windowsPackPath(): string | null {
  if (existsSync(WINDOWS_PREBUILT)) return WINDOWS_PREBUILT
  return existsSync(WINDOWS_PACK) ? WINDOWS_PACK : null
}

export { PACK, BOOT_KIT, LINUX_PACK, WINDOWS_PACK, WINDOWS_PREBUILT, ISO }
