import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { execFile } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { promisify } from 'node:util'
import { fetchPage } from './browse.ts'
import { askJeos, probeBootHealth, readBootHealth } from './boot.ts'
import { act, detectBackend } from './driver.ts'
import { buildInstallerPack, buildLinuxScreenPack, buildWindowsScreenPack, isoPath, linuxPackPath, sendFile, windowsPackPath } from './download.ts'
import { detectHost, hardwareSnapshot, parseAppIntent, planApp, searchCatalog } from '../boot/hostProfile.mjs'
import {
  defaultPlantDir,
  ensureOsNeuFolder,
  launchScreen,
  listPlantDir,
  plantStatus,
  runPlant,
} from '../boot/plant.mjs'
import {
  completeText,
  llmPullStatus,
  llmReady,
  ollamaInstallHint,
  pullPublicModel,
  readLlmSettings,
  userOpenAiKey,
  warmLocalModel,
  writeLlmSettings,
} from '../boot/localLlm.mjs'
import { appendMonitor, readMonitor, readPreference } from './monitor.ts'
import { loadLocalEnv } from './env.ts'
import { coachChat, speakReady, transcribeUtterance } from './speak.ts'
import {
  commandViewAllowed,
  isAdminEmail,
  listAccounts,
  loginAccount,
  logoutToken,
  registerAccount,
  userFromToken,
} from './auth.ts'
import { addFeedback, adminStats, appendTrack, listFeedback, type TrackEvent } from './analytics.ts'
import { officeAssist, officeAssistStream, officeReady } from './office.ts'

import { saveBrowseLedger, readBrowseLedger } from './browseLedger.ts'
import { supabaseEnabled, supabaseExchangeCodeForSession, supabaseGoogleAuthUrl } from './supabase.ts'
import {
  beginOAuthHandoff,
  peekOAuthHandoff,
  putOAuthHandoff,
  putVerifier,
  takeOAuthHandoff,
  takeVerifier,
} from './oauthHandoff.ts'
import { pkceChallenge, pkceVerifier } from './pkce.ts'
import { burnCommand, listBlockDisks, usbCandidates } from './usb.ts'
import { infer, listSamples, saveSample } from './vlm.ts'

const execFileAsync = promisify(execFile)
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
loadLocalEnv(ROOT)

const PORT = Number(process.env.NEUOS_BRIDGE_PORT ?? 4178)

/**
 * OS-NEU-SX-003 class bug (recurred 3x as of 2026-09-02): a dev stack silently
 * launched from a stale, non-git `~/os.neu` plant copy instead of `~/neuOS`,
 * so real code fixes never showed up in the running app and nobody could
 * tell why. Report which checkout is actually serving — loudly at boot, and
 * on every /api/health poll — so this is a visible fact, not a silent trap.
 */
let gitInfoCache: Promise<{ root: string; git: string | null; dirty: boolean | null }> | null = null
function gitInfo() {
  if (!gitInfoCache) {
    gitInfoCache = new Promise((resolve) => {
      execFile('git', ['rev-parse', '--short', 'HEAD'], { cwd: ROOT, timeout: 2000 }, (err, stdout) => {
        if (err) {
          resolve({ root: ROOT, git: null, dirty: null })
          return
        }
        execFile('git', ['status', '--porcelain'], { cwd: ROOT, timeout: 2000 }, (err2, dirty) => {
          resolve({ root: ROOT, git: stdout.trim(), dirty: err2 ? null : Boolean(dirty.trim()) })
        })
      })
    })
  }
  return gitInfoCache
}

function reportServingRoot() {
  void gitInfo().then((info) => {
    const line = (s: string) => process.stdout.write(`${s}\n`)
    line('----------------------------------------------------------------')
    line(`os.neu bridge serving from: ${info.root}`)
    if (info.git === null) {
      line('git: NOT a git checkout — if you are developing, this is likely a')
      line('     stale planted copy (e.g. ~/os.neu). Run from ~/neuOS instead.')
    } else {
      line(`git: HEAD ${info.git} (${info.dirty ? 'dirty (uncommitted changes)' : 'clean'})`)
    }
    line('----------------------------------------------------------------')
  })
}

function json(res: ServerResponse, status: number, body: unknown) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

async function readRaw(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  return Buffer.concat(chunks)
}

async function readBody(req: IncomingMessage): Promise<string> {
  return (await readRaw(req)).toString('utf8')
}

export async function route(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const host = req.headers.host ?? '127.0.0.1'
  const url = new URL(req.url ?? '/', `http://${host}`)
  res.setHeader('access-control-allow-origin', '*')
  res.setHeader('access-control-allow-headers', 'content-type, x-osneu-token')
  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }

  if (url.pathname === '/api/health' && req.method === 'GET') {
    const driver = await detectBackend()
    json(res, 200, {
      ok: true,
      driver: driver.backend,
      live: driver.live,
      vlm: process.env.NEUOS_VLM_URL ? 'remote' : 'graph',
      browse: process.env.NEUOS_ELECTRON === '1' ? 'electron' : 'proxy',
      supabase: supabaseEnabled(),
      speak: speakReady() ? 'openai' : 'off',
      llm: (await llmReady()).via,
      display: process.env.DISPLAY,
      detail: driver.detail,
      samples: await listSamples(),
      // OS-NEU-SX-003: which checkout is actually serving this response — a stale
      // planted copy (git: null) looks fine in every other field, so surface it here.
      ...(await gitInfo()),
    })
    return
  }

  if (url.pathname === '/api/demo' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'x-frame-options': 'DENY' })
    res.end(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>OS.neu v1.0 demo</title></head>
<body style="font-family:sans-serif;padding:40px;background:#fff;color:#111">
<h1>NEUOS_BROWSER_OK</h1>
<p>The address-bar proxy passed an iframe block.</p>
</body></html>`)
    return
  }

  if (url.pathname === '/api/browse' && req.method === 'GET') {
    const target = url.searchParams.get('url') ?? ''
    const page = await fetchPage(target)
    res.writeHead(page.status, {
      'content-type': page.contentType,
      'x-frame-options': 'SAMEORIGIN',
      'content-security-policy': "frame-ancestors 'self'",
      'cache-control': 'no-store',
      'x-neuos-final-url': page.finalUrl,
    })
    res.end(page.body)
    return
  }

  if (url.pathname === '/api/driver/act' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const result = await act(payload)
    json(res, result.ok ? 200 : 400, result)
    return
  }

  if (url.pathname === '/api/vlm/infer' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const result = await infer(payload)
    json(res, 200, result)
    return
  }

  if (url.pathname === '/api/vlm/sample' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}')
    const saved = await saveSample(payload)
    json(res, 200, { ok: true, ...saved })
    return
  }

  if (url.pathname === '/api/speak/status' && req.method === 'GET') {
    json(res, 200, { ok: true, ready: speakReady() })
    return
  }

  if (url.pathname === '/api/speak/chat' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      message?: string
      history?: Array<{ role?: string; content?: string }>
      audio?: boolean
    }
    try {
      const history = (payload.history ?? [])
        .filter((turn) => turn.role === 'user' || turn.role === 'assistant')
        .map((turn) => ({ role: turn.role as 'user' | 'assistant', content: String(turn.content ?? '') }))
      const result = await coachChat(String(payload.message ?? ''), history, {
        audio: payload.audio === true,
      })
      json(res, 200, { ok: true, ...result })
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'coach-error'
      json(res, reason === 'openai-unconfigured' ? 503 : 502, { ok: false, reason: 'coach-unavailable' })
    }
    return
  }

  if (url.pathname === '/api/speak/asr' && req.method === 'POST') {
    const type = String(req.headers['content-type'] ?? 'audio/webm')
    const buf = await readRaw(req)
    try {
      const transcript = await transcribeUtterance(buf, type)
      json(res, transcript ? 200 : 422, { ok: Boolean(transcript), transcript, reason: transcript ? undefined : 'empty-transcript' })
    } catch {
      json(res, 502, { ok: false, reason: 'asr-unavailable' })
    }
    return
  }

  if (url.pathname === '/api/boot-health' && req.method === 'GET') {
    const refresh = url.searchParams.get('refresh') === '1'
    const health = refresh ? await probeBootHealth() : await readBootHealth()
    json(res, 200, health)
    return
  }

  if (url.pathname === '/api/jeos/ask' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { text?: string }
    const result = await askJeos(String(payload.text ?? ''))
    if (result.act === 'app' && result.plan) {
      const plan = result.plan
      await appendMonitor({
        t: Date.now(),
        source: 'prompt',
        kind: plan.kind === 'remove' ? 'remove' : 'install',
        app: plan.app,
        hostOs: plan.host?.pretty,
        pkg: plan.host?.pkg,
        remembered: 'prompt',
        note: plan.command,
      })
    }
    json(res, 200, result)
    return
  }

  if (url.pathname === '/api/usb/disks' && req.method === 'GET') {
    const disks = await listBlockDisks()
    json(res, 200, {
      ok: true,
      disks,
      usb: usbCandidates(disks),
      iso: 'dist/neuos-live.iso',
      command: 'bash scripts/make-usb.sh',
    })
    return
  }

  if (url.pathname === '/api/usb/plan' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { device?: string }
    const device = String(payload.device ?? '')
    if (!device.startsWith('/dev/')) {
      json(res, 400, { ok: false, reason: 'device path required' })
      return
    }
    json(res, 200, {
      ok: true,
      device,
      command: burnCommand(device),
      allow: process.env.NEUOS_USB_ALLOW === '1',
    })
    return
  }

  if (url.pathname === '/api/launchers' && req.method === 'GET') {
    const home = process.env.HOME || ''
    json(res, 200, {
      ok: true,
      apps: existsSync(path.join(home, '.local/share/applications/neuos.desktop')),
      desktop: existsSync(path.join(home, 'Desktop/neuos.desktop')),
      autostart: existsSync(path.join(home, '.config/autostart/neuos.desktop')),
    })
    return
  }

  if (url.pathname === '/api/install/host' && req.method === 'POST') {
    const script = path.join(ROOT, 'scripts', 'install-autostart.sh')
    const { stdout, stderr } = await execFileAsync('bash', [script], { timeout: 20_000 })
    json(res, 200, { ok: true, stdout, stderr })
    return
  }

  if (url.pathname === '/api/uninstall/status' && req.method === 'GET') {
    const home = process.env.HOME || ''
    const autostart = existsSync(path.join(home, '.config/autostart/neuos.desktop'))
    const unit = existsSync(path.join(home, '.config/systemd/user/neuos.service'))
    const planted = existsSync(path.join(home, 'os.neu'))
    json(res, 200, { ok: true, autostart, unit, planted, forced: autostart || unit })
    return
  }

  if (url.pathname === '/api/uninstall' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { files?: boolean }
    const script = path.join(ROOT, 'scripts', 'uninstall-autostart.sh')
    const args = payload.files ? [script, '--files'] : [script]
    const { stdout, stderr } = await execFileAsync('bash', args, { timeout: 20_000 })
    await appendMonitor({
      t: Date.now(),
      source: 'wizard',
      kind: 'remove',
      app: 'os.neu',
      note: payload.files ? 'uninstall-autostart+files' : 'uninstall-autostart',
    })
    json(res, 200, { ok: true, stdout, stderr, files: Boolean(payload.files) })
    return
  }

  if (url.pathname === '/api/plant/default' && req.method === 'GET') {
    json(res, 200, { ok: true, dest: defaultPlantDir() })
    return
  }

  if (url.pathname === '/api/plant/list' && req.method === 'GET') {
    const dir = url.searchParams.get('dir') || defaultPlantDir()
    json(res, 200, await listPlantDir(dir))
    return
  }

  if (url.pathname === '/api/plant/mkdir' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dir?: string }
    const dest = ensureOsNeuFolder(payload.dir || defaultPlantDir())
    const { mkdir } = await import('node:fs/promises')
    await mkdir(dest, { recursive: true })
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/plant/start' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string }
    const dest = payload.dest || defaultPlantDir()
    void runPlant(ROOT, dest).catch(() => undefined)
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/plant/status' && req.method === 'GET') {
    json(res, 200, { ok: true, ...plantStatus() })
    return
  }

  if (url.pathname === '/api/plant/launch' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string; go?: string }
    const dest = payload.dest || plantStatus().dest || defaultPlantDir()
    json(res, 200, launchScreen(dest, payload.go || 'lui'))
    return
  }

  if ((url.pathname === '/api/guide' || url.pathname === '/guide') && req.method === 'GET') {
    const file = path.join(ROOT, 'boot/guide-ui.html')
    if (existsSync(file)) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
      res.end(await readFile(file, 'utf8'))
      return
    }
  }

  if ((url.pathname === '/api/guide.md' || url.pathname === '/guide.md') && req.method === 'GET') {
    const file = path.join(ROOT, 'docs/student-usb-guide.md')
    res.writeHead(200, { 'content-type': 'text/markdown; charset=utf-8' })
    res.end(existsSync(file) ? await readFile(file, 'utf8') : '# os.neu\n')
    return
  }

  if (url.pathname === '/api/catalog' && req.method === 'GET') {
    json(res, 200, { ok: true, apps: searchCatalog(url.searchParams.get('q') || '', detectHost()) })
    return
  }

  if (url.pathname === '/api/llm/settings' && req.method === 'GET') {
    const settings = readLlmSettings()
    const key = userOpenAiKey()
    const ready = await llmReady()
    json(res, 200, {
      ok: true,
      provider: settings.provider,
      localModel: settings.localModel,
      hasKey: Boolean(key),
      keyHint: key ? `…${key.slice(-4)}` : '',
      ready,
    })
    return
  }

  if (url.pathname === '/api/llm/settings' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      dest?: string
      openaiKey?: string
      provider?: 'auto' | 'local' | 'openai'
      clearKey?: boolean
    }
    const dest = payload.dest || plantStatus().dest || ROOT
    const root = existsSync(dest) ? dest : ROOT
    const patch: Record<string, unknown> = {}
    if (payload.provider === 'auto' || payload.provider === 'local' || payload.provider === 'openai') {
      patch.provider = payload.provider
    }
    if (payload.clearKey) patch.openaiKey = ''
    else if (typeof payload.openaiKey === 'string' && payload.openaiKey.trim()) {
      patch.openaiKey = payload.openaiKey.trim()
    }
    const next = writeLlmSettings(patch, root)
    json(res, 200, {
      ok: true,
      dest: root,
      hasKey: Boolean(String(next.openaiKey || '').trim()),
      provider: next.provider,
    })
    return
  }

  if (url.pathname === '/api/llm/ping' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { model?: string }
    const started = Date.now()
    try {
      const result = await completeText({
        model: String(payload.model || 'os.neu-local'),
        messages: [
          { role: 'system', content: 'Reply with exactly: OK' },
          { role: 'user', content: 'ping' },
        ],
      })
      json(res, 200, {
        ok: true,
        text: String(result.text || '').slice(0, 80),
        model: result.model,
        provider: result.provider,
        ms: Date.now() - started,
      })
    } catch (err) {
      json(res, 502, {
        ok: false,
        reason: err instanceof Error ? err.message : 'ping-failed',
        ms: Date.now() - started,
      })
    }
    return
  }

  if (url.pathname === '/api/llm/warm' && req.method === 'POST') {
    void warmLocalModel().catch(() => undefined)
    json(res, 200, { ok: true })
    return
  }

  if (url.pathname === '/api/llm/pull' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { dest?: string }
    const dest = payload.dest || plantStatus().dest || ROOT
    void pullPublicModel(existsSync(dest) ? dest : ROOT).catch(() => undefined)
    json(res, 200, { ok: true, dest })
    return
  }

  if (url.pathname === '/api/llm/status' && req.method === 'GET') {
    const st = llmPullStatus()
    json(res, 200, {
      ok: true,
      ...st,
      ...(st.error === 'ollama-missing' ? ollamaInstallHint() : {}),
    })
    return
  }

  if (url.pathname === '/api/llm/ready' && req.method === 'GET') {
    json(res, 200, await llmReady())
    return
  }

  if (url.pathname === '/api/host-profile' && req.method === 'GET') {
    json(res, 200, { ok: true, ...hardwareSnapshot() })
    return
  }

  if (url.pathname === '/api/apps/plan' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { text?: string; source?: 'prompt' | 'lui' | 'wizard' }
    const intent = parseAppIntent(String(payload.text ?? ''))
    if (!intent) {
      json(res, 400, { ok: false, reason: 'not-an-app-intent' })
      return
    }
    const host = detectHost()
    const plan = planApp(host, intent)
    const source = payload.source === 'prompt' || payload.source === 'wizard' ? payload.source : 'lui'
    await appendMonitor({
      t: Date.now(),
      source,
      kind: intent.kind,
      app: intent.app,
      hostOs: host.pretty,
      pkg: host.pkg,
      remembered: source === 'prompt' ? 'prompt' : 'neuos',
      note: plan.command,
    })
    json(res, 200, { ok: true, plan, preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/monitor' && req.method === 'GET') {
    json(res, 200, { ok: true, events: await readMonitor(), preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/monitor' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      source?: 'prompt' | 'lui' | 'wizard'
      kind?: 'install' | 'remove' | 'choice' | 'start'
      app?: string
      note?: string
    }
    const host = detectHost()
    const events = await appendMonitor({
      t: Date.now(),
      source: payload.source ?? 'wizard',
      kind: payload.kind ?? 'start',
      app: payload.app,
      hostOs: host.pretty,
      pkg: host.pkg,
      note: payload.note,
    })
    json(res, 200, { ok: true, events, preference: await readPreference() })
    return
  }

  if (url.pathname === '/api/install/run' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      mode?: 'host' | 'usb'
      device?: string
      test?: boolean
    }
    const test = payload.test !== false
    const host = detectHost()
    const steps: string[] = [`host ${host.pretty} ${host.pkg}`]
    if (payload.mode === 'host') {
      const script = path.join(ROOT, 'scripts', 'install-autostart.sh')
      const { stdout } = await execFileAsync('bash', [script], { timeout: 20_000 })
      steps.push(stdout.trim() || 'autostart written')
      await appendMonitor({
        t: Date.now(),
        source: 'wizard',
        kind: 'choice',
        hostOs: host.pretty,
        note: 'plant-host',
      })
      json(res, 200, { ok: true, percent: 100, test, steps, wiped: false, host })
      return
    }
    if (payload.mode === 'usb') {
      const args = test ? ['scripts/make-usb.sh', '--test'] : ['scripts/make-usb.sh']
      if (!test && payload.device) {
        json(res, 200, {
          ok: true,
          percent: 40,
          test: false,
          steps: [...steps, 'live burn is sudo-only'],
          command: burnCommand(String(payload.device)),
          wiped: false,
          host,
        })
        return
      }
      const { stdout } = await execFileAsync('bash', args, { timeout: 120_000, cwd: ROOT })
      steps.push(stdout.trim().slice(-400) || 'usb staged')
      await appendMonitor({
        t: Date.now(),
        source: 'wizard',
        kind: 'choice',
        hostOs: host.pretty,
        note: test ? 'usb-test' : 'usb-iso',
      })
      json(res, 200, {
        ok: true,
        percent: 100,
        test: true,
        steps,
        wiped: false,
        host,
        command: payload.device ? burnCommand(payload.device) : 'bash scripts/make-usb.sh',
      })
      return
    }
    json(res, 400, { ok: false, reason: 'mode host|usb' })
    return
  }

  if (url.pathname === '/api/download/pack' && req.method === 'GET') {
    const file = await buildInstallerPack()
    sendFile(res, file, 'neuos-boot-kit.tar.gz', 'application/gzip')
    return
  }

  if ((url.pathname === '/api/download/linux' || url.pathname === '/downloads/neuos-linux.tar.gz') && req.method === 'GET') {
    const existing = linuxPackPath()
    const file = existing || (await buildLinuxScreenPack())
    sendFile(res, file, 'neuos-linux.tar.gz', 'application/gzip')
    return
  }

  if ((url.pathname === '/api/download/windows' || url.pathname === '/downloads/neuos-windows.zip') && req.method === 'GET') {
    const existing = windowsPackPath()
    const file = existing || (await buildWindowsScreenPack())
    sendFile(res, file, 'neuos-windows.zip', 'application/zip')
    return
  }

  if (url.pathname === '/api/download/iso' && req.method === 'GET') {
    const file = isoPath()
    if (!file) {
      json(res, 404, { ok: false, reason: 'run npm run usb first', pack: '/api/download/pack' })
      return
    }
    sendFile(res, file, 'neuos-live.iso', 'application/octet-stream')
    return
  }

  const token = String(req.headers['x-osneu-token'] ?? '')
  const authed = token ? await userFromToken(token) : null

  if (url.pathname === '/api/auth/register' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { name?: string; email?: string; password?: string }
    try {
      const result = await registerAccount(String(payload.name ?? ''), String(payload.email ?? ''), String(payload.password ?? ''))
      json(res, 200, { ok: true, ...result })
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'register-error'
      json(res, reason === 'email-taken' ? 409 : 400, { ok: false, reason })
    }
    return
  }

  if (url.pathname === '/api/auth/login' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { email?: string; password?: string }
    try {
      const result = await loginAccount(String(payload.email ?? ''), String(payload.password ?? ''))
      json(res, 200, { ok: true, ...result, via: supabaseEnabled() ? 'supabase' : 'local' })
    } catch {
      json(res, 401, { ok: false, reason: 'bad-credentials' })
    }
    return
  }

  if (url.pathname === '/api/auth/oauth/google' && req.method === 'GET') {
    if (!supabaseEnabled()) {
      json(res, 503, { ok: false, reason: 'supabase-off' })
      return
    }
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    if (handoff) await beginOAuthHandoff(handoff)
    const base =
      String(url.searchParams.get('redirect') || '').trim() ||
      `http://127.0.0.1:${PORT}/api/auth/callback`
    const redirectUrl = new URL(base)
    if (handoff) redirectUrl.searchParams.set('handoff', handoff)
    const redirect = redirectUrl.toString()
    // PKCE (WO-AUTH-ELECTRON-PKCE-1): verifier stored server-side only, keyed
    // by handoff, consumed once in /api/auth/oauth/exchange. Guest callback
    // page never sees it — only the authorization code passes through Chrome.
    let challenge: string | undefined
    if (handoff) {
      const verifier = pkceVerifier()
      await putVerifier(handoff, verifier)
      challenge = pkceChallenge(verifier)
    }
    const href = supabaseGoogleAuthUrl(redirect, challenge)
    if (!href) {
      json(res, 503, { ok: false, reason: 'supabase-off' })
      return
    }
    json(res, 200, { ok: true, url: href, redirect, handoff: handoff || null })
    return
  }

  if (url.pathname === '/api/auth/oauth/exchange' && req.method === 'POST') {
    // Server-side PKCE code exchange (WO-AUTH-ELECTRON-PKCE-1). Called by the
    // guest callback page with only the authorization code + handoff id —
    // never the verifier or the resulting session token.
    const payload = JSON.parse((await readBody(req)) || '{}') as { code?: string; handoff?: string }
    const code = String(payload.code || '').trim()
    const handoff = String(payload.handoff || '').trim()
    const verifier = handoff ? await takeVerifier(handoff) : null
    if (!code || !verifier) {
      json(res, 400, { ok: false, reason: 'no-pkce-verifier' })
      return
    }
    try {
      const session = await supabaseExchangeCodeForSession(code, verifier)
      if (!session?.token) {
        json(res, 400, { ok: false, reason: 'exchange-failed' })
        return
      }
      await putOAuthHandoff(handoff, session.token)
      json(res, 200, { ok: true })
    } catch (err) {
      json(res, 400, { ok: false, reason: err instanceof Error ? err.message : 'exchange-failed' })
    }
    return
  }

  if (url.pathname === '/api/auth/oauth/handoff' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { handoff?: string; token?: string }
    const ok = await putOAuthHandoff(String(payload.handoff || ''), String(payload.token || ''))
    json(res, ok ? 200 : 400, { ok })
    return
  }

  if (url.pathname === '/api/auth/oauth/handoff' && req.method === 'GET') {
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    const peek = String(url.searchParams.get('peek') || '') === '1'
    const token = peek ? await peekOAuthHandoff(handoff) : await takeOAuthHandoff(handoff)
    if (!token) {
      json(res, 200, { ok: false, pending: true })
      return
    }
    json(res, 200, { ok: true, token })
    return
  }

  if (url.pathname === '/api/auth/callback' && req.method === 'GET') {
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' })
    res.end(`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>os.neu sign-in</title>
<style>body{font-family:system-ui,sans-serif;background:#0b0c0a;color:#f4efe6;display:grid;place-items:center;min-height:100vh;margin:0}
main{max-width:28rem;padding:1.5rem;border:1px solid rgba(244,239,230,.15);border-radius:1rem}
code{color:#9be7c8}</style></head>
<body><main>
<h1>os.neu</h1>
<p id="msg">Finishing Google sign-in…</p>
</main>
<script>
(function () {
  // WO-AUTH-PKCE-STRIP-AFTER-A05-121: A05/A07 passed live 2026-09-11 (see
  // docs/handoff/control-tower/ACK-CONTROL-PATH-A-A05-A07-LIVE-PASS-2026-09-11.md
  // in the Life-Force repo). This page now accepts only an authorization
  // ?code= (PKCE) — it never sees the code_verifier or the resulting
  // session, only posts the single-use code to our own bridge, which does
  // the exchange. The legacy implicit access_token fallback is removed.
  var handoff = ${JSON.stringify(handoff)};
  var query = new URLSearchParams(location.search);
  var code = query.get('code') || '';
  var err = query.get('error_description') || query.get('error') || '';
  var msg = document.getElementById('msg');
  if (err) {
    msg.textContent = 'Sign-in failed: ' + err;
    return;
  }
  if (!code) {
    msg.innerHTML = 'No code in redirect. Add this callback URL in Supabase Auth redirect allow-list:<br><code>http://127.0.0.1:${PORT}/api/auth/callback</code>';
    return;
  }
  function done(ok) {
    if (!ok) {
      msg.textContent = 'Sign-in did not complete. Close this tab and try again in os.neu.';
      return;
    }
    msg.innerHTML = 'Signed in. <b>os.neu already has your session</b> — you can close this Chrome tab (Cancel is fine).';
    try {
      // Opaque wake only — never the token/code. Renderer fetches the
      // session itself via the existing handoff-poll endpoint.
      var deep = handoff ? 'osneu://oauth?status=success&handoff=' + encodeURIComponent(handoff) : 'osneu://focus';
      var link = document.createElement('a');
      link.href = deep;
      link.textContent = 'Open / focus os.neu';
      link.style.color = '#9be7c8';
      msg.appendChild(document.createElement('br'));
      msg.appendChild(document.createElement('br'));
      msg.appendChild(link);
      // Do not auto-navigate to osneu:// — that forces a Chrome prompt; handoff already signed you in.
    } catch (e) {}
  }
  fetch('/api/auth/oauth/exchange', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ code: code, handoff: handoff }),
  }).then(function (r) { return r.json(); }).then(function (body) { done(Boolean(body && body.ok)); }).catch(function () { done(false); });
})();
</script></body></html>`)
    return
  }

  if (url.pathname === '/api/auth/logout' && req.method === 'POST') {
    if (token) await logoutToken(token)
    json(res, 200, { ok: true })
    return
  }

  if (url.pathname === '/api/auth/me' && req.method === 'GET') {
    json(res, 200, { ok: true, user: authed })
    return
  }

  if (url.pathname === '/api/auth/command-view' && req.method === 'GET') {
    // WO-UI-NEU-COMMAND-VIEW-ICON-121 (UI-B27): server-side gate so the
    // client never has to hardcode/trust the role list — see
    // commandViewAllowed() (current_site_role() RPC, not the admin mailbox
    // heuristic, not has_org_registry_access()).
    const allowed = await commandViewAllowed(token)
    json(res, 200, { ok: true, allowed })
    return
  }

  if (url.pathname === '/api/track' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      session?: string
      kind?: TrackEvent['kind']
      screen?: string
      label?: string
    }
    const event = await appendTrack({
      t: Date.now(),
      session: String(payload.session || 'anon'),
      email: authed?.email,
      kind: payload.kind === 'click' || payload.kind === 'login' || payload.kind === 'logout' || payload.kind === 'open-app' || payload.kind === 'feedback' ? payload.kind : 'view',
      screen: String(payload.screen || 'unknown'),
      label: payload.label,
    })
    json(res, 200, { ok: true, event })
    return
  }

  if (url.pathname === '/api/feedback' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as { title?: string; body?: string }
    try {
      const post = await addFeedback({
        email: authed?.email,
        name: authed?.name,
        title: String(payload.title ?? ''),
        body: String(payload.body ?? ''),
      })
      await appendTrack({
        t: Date.now(),
        session: 'feedback',
        email: authed?.email,
        kind: 'feedback',
        screen: 'feedback',
        label: post.title,
      })
      json(res, 200, { ok: true, post, cloud: Boolean(post.cloud) })
    } catch {
      json(res, 400, { ok: false, reason: 'empty-feedback' })
    }
    return
  }

  if (url.pathname === '/api/feedback' && req.method === 'GET') {
    json(res, 200, { ok: true, posts: await listFeedback() })
    return
  }

  if (url.pathname === '/api/browse/ledger' && req.method === 'POST') {
    if (!authed?.email) {
      json(res, 401, { ok: false, reason: 'sign-in' })
      return
    }
    const payload = JSON.parse(await readBody(req) || '{}')
    const saved = await saveBrowseLedger(authed.email, payload)
    json(res, 200, { ok: true, saved: Boolean(saved) })
    return
  }

  if (url.pathname === '/api/browse/ledger' && req.method === 'GET') {
    if (!authed?.email) {
      json(res, 401, { ok: false, reason: 'sign-in' })
      return
    }
    json(res, 200, { ok: true, row: await readBrowseLedger(authed.email) })
    return
  }

  if (url.pathname === '/api/office/assist' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      model?: string
      app?: 'sheet' | 'doc' | 'slides'
      instruction?: string
      content?: string
      selection?: string
      mode?: 'write' | 'rewrite'
      history?: Array<{ role: 'user' | 'assistant'; content: string }>
    }
    if (!(await officeReady())) {
      json(res, 503, { ok: false, reason: 'no-llm' })
      return
    }
    const app = payload.app === 'doc' || payload.app === 'slides' ? payload.app : 'sheet'
    try {
      const result = await officeAssist({
        model: payload.model,
        app,
        instruction: String(payload.instruction ?? ''),
        content: payload.content,
        selection: payload.selection,
        mode: payload.mode,
        history: payload.history,
      })
      json(res, 200, result)
    } catch (err) {
      json(res, 502, { ok: false, reason: err instanceof Error ? err.message : 'assist-error' })
    }
    return
  }

  if (url.pathname === '/api/office/assist/stream' && req.method === 'POST') {
    const payload = JSON.parse(await readBody(req) || '{}') as {
      model?: string
      app?: 'sheet' | 'doc' | 'slides'
      instruction?: string
      content?: string
      selection?: string
      mode?: 'write' | 'rewrite'
      history?: Array<{ role: 'user' | 'assistant'; content: string }>
    }
    if (!(await officeReady())) {
      json(res, 503, { ok: false, reason: 'no-llm' })
      return
    }
    const app = payload.app === 'doc' || payload.app === 'slides' ? payload.app : 'sheet'
    res.writeHead(200, {
      'content-type': 'application/x-ndjson; charset=utf-8',
      'cache-control': 'no-cache',
      connection: 'keep-alive',
    })
    try {
      for await (const chunk of officeAssistStream({
        model: payload.model,
        app,
        instruction: String(payload.instruction ?? ''),
        content: payload.content,
        selection: payload.selection,
        mode: payload.mode,
        history: payload.history,
      })) {
        res.write(`${JSON.stringify({ ok: true, ...chunk })}\n`)
      }
      res.write(`${JSON.stringify({ ok: true, done: true })}\n`)
    } catch (err) {
      res.write(
        `${JSON.stringify({
          ok: false,
          reason: err instanceof Error ? err.message : 'assist-error',
          done: true,
        })}\n`,
      )
    }
    res.end()
    return
  }

  if (url.pathname === '/api/admin/stats' && req.method === 'GET') {
    if (!authed || !isAdminEmail(authed.email)) {
      json(res, 403, { ok: false, reason: 'admin-only' })
      return
    }
    const stats = await adminStats()
    json(res, 200, { ...stats, accounts: await listAccounts() })
    return
  }

  json(res, 404, { ok: false, reason: 'not-found' })
}

const server = createServer((req, res) => {
  void route(req, res).catch((err: unknown) => {
    json(res, 500, { ok: false, reason: err instanceof Error ? err.message : 'bridge-error' })
  })
})

reportServingRoot()

server.listen(PORT, '127.0.0.1', () => {
      process.stdout.write(`os.neu v1.0 bridge http://127.0.0.1:${PORT}\n`)
})
