import {
  completeText,
  llmReady,
  streamChatLocal,
  wantsLocalModel,
  LOCAL_MODEL,
  ollamaStatus,
  readLlmSettings,
  userOpenAiKey,
} from '../boot/localLlm.mjs'

export const OFFICE_MODELS = ['os.neu-local', 'gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1'] as const
export type OfficeModel = (typeof OFFICE_MODELS)[number]

export async function officeReady() {
  const ready = await llmReady()
  return ready.ok
}

function pickModel(raw: string): string {
  return OFFICE_MODELS.includes(raw as OfficeModel) ? raw : 'os.neu-local'
}

function systemFor(app: 'sheet' | 'doc' | 'slides', local: boolean, mode: 'write' | 'rewrite' = 'write') {
  if (mode === 'rewrite') {
    return local
      ? 'Rewrite only the selected text. Return the replacement only. Keep length similar unless asked.'
      : 'Rewrite the selected passage. Return only the replacement text, no preamble.'
  }
  if (local) {
    if (app === 'sheet') return 'Spreadsheet helper. Reply only as short TSV: one header row, up to 5 data rows. No markdown.'
    if (app === 'slides')
      return 'Slide helper. Max 4 slides. Each slide starts with # or ## or ### or #### then a short title, then 2 bullets. Keep it short.'
    return 'Document helper. Line 1 = short title. Then 1-3 short sentences. No fluff.'
  }
  if (app === 'sheet') {
    return 'You write spreadsheet content. Reply as TSV (tab-separated) with a header row, then up to 8 data rows. No markdown.'
  }
  if (app === 'slides') {
    return (
      'You write a slide deck as JSON only — no markdown, no code fences, no commentary. ' +
      'Schema: {"version":1,"title":"optional deck title","slides":[...]} max 8 slides. ' +
      'Each slide is one of: ' +
      '{"layout":"title","title":"string","body":"optional subtitle"}; ' +
      '{"layout":"bullets","title":"string","bullets":["max 6 short lines"]}; ' +
      '{"layout":"table","title":"string","table":{"headers":["max 5"],"rows":[["max 5 cols"], "max 8 rows"]}}. ' +
      'Only use numbers the user gave you in the instruction or current content — never invent NeuAvenue revenue, ARR, or KPI figures; ' +
      'if you must illustrate with made-up numbers, label the slide title or a cell "EXAMPLE". Reply with the JSON object only.'
    )
  }
  return 'You write a document. Reply with a title on the first line, then the body. Keep it useful and concise.'
}

export function buildOfficeMessages(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
}) {
  const model = pickModel(String(input.model || ''))
  const local = wantsLocalModel(model)
  const mode = input.mode === 'rewrite' ? 'rewrite' : 'write'
  const system = systemFor(input.app, local, mode)
  const user =
    mode === 'rewrite'
      ? `Instruction: ${input.instruction.trim()}\nSelected text:\n${(input.selection || '').slice(0, 2000)}`
      : `Instruction: ${input.instruction.trim()}\nCurrent content:\n${(input.content || '').slice(0, local ? 1200 : 6000)}`
  return {
    model: local ? 'os.neu-local' : model,
    local,
    messages: [
      { role: 'system' as const, content: system },
      { role: 'user' as const, content: user },
    ],
  }
}

export async function officeAssist(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
}): Promise<{ ok: boolean; text: string; model: string; provider?: string }> {
  const built = buildOfficeMessages(input)
  const history = (input.history || []).slice(-8).map((row) => ({
    role: row.role,
    content: row.content.slice(0, 1500),
  }))
  const messages = [built.messages[0], ...history, built.messages[1]]
  const result = await completeText({
    model: built.model,
    messages,
  })
  return { ok: true, text: result.text, model: result.model, provider: result.provider }
}

export async function* officeAssistStream(input: {
  model?: string
  app: 'sheet' | 'doc' | 'slides'
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
}) {
  const built = buildOfficeMessages(input)
  const history = (input.history || []).slice(-4).map((row) => ({
    role: row.role,
    content: row.content.slice(0, built.local ? 600 : 1500),
  }))
  const messages = [built.messages[0], ...history, built.messages[1]]

  if (built.local) {
    const status = await ollamaStatus()
    if (!status.ok) throw new Error('local-unavailable')
    const settings = readLlmSettings()
    const name =
      status.models.includes(settings.localModel || LOCAL_MODEL)
        ? settings.localModel || LOCAL_MODEL
        : status.models[0] || LOCAL_MODEL
    for await (const chunk of streamChatLocal(messages, name)) {
      yield chunk
    }
    return
  }

  const key = userOpenAiKey()
  if (!key) throw new Error('no-llm')
  // Cloud path: one-shot then fake stream for typing UX
  const result = await completeText({ model: built.model, messages })
  const text = result.text
  const step = Math.max(1, Math.floor(text.length / 48))
  let full = ''
  for (let i = 0; i < text.length; i += step) {
    const piece = text.slice(i, i + step)
    full += piece
    yield { piece, full, model: result.model, provider: result.provider || 'openai', done: i + step >= text.length }
  }
}
