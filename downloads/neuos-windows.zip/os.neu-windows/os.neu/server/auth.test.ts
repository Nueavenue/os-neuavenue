import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { commandViewAllowed, isAdminEmail } from './auth.ts'

describe('admin email', () => {
  it('only treats the configured mailbox as admin', () => {
    expect(isAdminEmail('billylee96312@gmail.com')).toBe(true)
    expect(isAdminEmail('BillyLee96312@gmail.com')).toBe(true)
    expect(isAdminEmail('someone@gmail.com')).toBe(false)
  })
})

// WO-UI-NEU-COMMAND-VIEW-ICON-121 (UI-B27): the os.neu Command View chrome
// icon gates on this. Must fail closed everywhere except the four roles
// the Leader named — never the AuthUser.admin mailbox heuristic, never
// has_org_registry_access() (which also passes officer / pmo_viewer).
describe('commandViewAllowed (UI-B27 Command View icon gate)', () => {
  const JWT = 'aa.bb.cc'
  let fetchSpy: ReturnType<typeof vi.spyOn>

  beforeEach(() => {
    vi.stubEnv('PUBLIC_SUPABASE_URL', 'https://example.supabase.co')
    vi.stubEnv('PUBLIC_SUPABASE_ANON_KEY', 'anon-key')
    fetchSpy = vi.spyOn(globalThis, 'fetch')
  })

  afterEach(() => {
    vi.unstubAllEnvs()
    fetchSpy.mockRestore()
  })

  function mockRole(role: string | null, ok = true) {
    fetchSpy.mockResolvedValue({
      ok,
      text: async () => (role === null ? 'null' : JSON.stringify(role)),
    } as Response)
  }

  it('allows ceo / leader / shareholder / admin', async () => {
    for (const role of ['ceo', 'leader', 'shareholder', 'admin']) {
      mockRole(role)
      expect(await commandViewAllowed(JWT)).toBe(true)
    }
  })

  it('hides for officer and pmo_viewer even though has_org_registry_access() would pass them', async () => {
    for (const role of ['officer', 'pmo_viewer']) {
      mockRole(role)
      expect(await commandViewAllowed(JWT)).toBe(false)
    }
  })

  it('hides on null role, RPC error, and RPC HTTP failure', async () => {
    mockRole(null)
    expect(await commandViewAllowed(JWT)).toBe(false)

    mockRole('ceo', false) // res.ok === false
    expect(await commandViewAllowed(JWT)).toBe(false)

    fetchSpy.mockRejectedValue(new Error('network down'))
    expect(await commandViewAllowed(JWT)).toBe(false)
  })

  it('fails closed with no network call for empty/local (non-JWT) tokens', async () => {
    expect(await commandViewAllowed('')).toBe(false)
    expect(await commandViewAllowed('local-device-hex-token')).toBe(false)
    expect(fetchSpy).not.toHaveBeenCalled()
  })

  it('fails closed when Supabase is off, even with a JWT-shaped token', async () => {
    vi.unstubAllEnvs()
    expect(await commandViewAllowed(JWT)).toBe(false)
    expect(fetchSpy).not.toHaveBeenCalled()
  })

  it('sends the caller JWT (not the anon key) as the RPC bearer, so auth.uid() resolves', async () => {
    mockRole('ceo')
    await commandViewAllowed(JWT)
    const [url, init] = fetchSpy.mock.calls[0] as [string, RequestInit]
    expect(url).toBe('https://example.supabase.co/rest/v1/rpc/current_site_role')
    const headers = init.headers as Record<string, string>
    expect(headers.authorization).toBe(`Bearer ${JWT}`)
    expect(headers.apikey).toBe('anon-key')
  })
})
