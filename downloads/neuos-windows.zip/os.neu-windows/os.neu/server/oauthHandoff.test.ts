import { describe, expect, it } from 'vitest'
import { beginOAuthHandoff, peekOAuthHandoff, putOAuthHandoff, takeOAuthHandoff } from './oauthHandoff.ts'

describe('oauth handoff', () => {
  it('stores and peeks a token, then consumes once', async () => {
    expect(await beginOAuthHandoff('s-test')).toBe(true)
    expect(await putOAuthHandoff('s-test', 'tok-1')).toBe(true)
    expect(await peekOAuthHandoff('s-test')).toBe('tok-1')
    expect(await peekOAuthHandoff('s-test')).toBe('tok-1')
    expect(await takeOAuthHandoff('s-test')).toBe('tok-1')
    expect(await takeOAuthHandoff('s-test')).toBe(null)
  })

  it('attaches token to newest awaiting when id missing', async () => {
    expect(await beginOAuthHandoff('s-orphan')).toBe(true)
    expect(await putOAuthHandoff('', 'tok-orphan')).toBe(true)
    expect(await peekOAuthHandoff('s-orphan')).toBe('tok-orphan')
  })

  it('rejects empty token', async () => {
    expect(await putOAuthHandoff('s-x', '')).toBe(false)
  })
})
