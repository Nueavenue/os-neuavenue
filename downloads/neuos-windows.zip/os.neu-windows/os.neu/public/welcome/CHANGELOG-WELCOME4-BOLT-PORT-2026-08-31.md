# CHANGELOG — WELCOME-4 Bolt UI port (2026-08-31)

> **Agent:** Control-assisted Impl port (Bolt exploration → static)  
> **Backup:** `~/neuOS/public/welcome.pre-welcome4-bolt-20250831/`  
> **Rollback:** `bash ~/neuOS/public/welcome/restore-pre-welcome4-bolt.sh`

---

## Preserved (neuOS — required)

| Item | Value |
|------|-------|
| Boot kit | `/downloads/neuos-boot-kit.tar.gz` |
| USB ISO | `/downloads/neuos-live.iso` (302 → GitHub Release) |
| Linux pack | `/downloads/neuos-linux.tar.gz` |
| Practice install | `/?test=1` |
| Favicon | `/brand/neuos-mark.png` |
| Neu OS | `/` |
| Neu-Vitality | `https://app.neuavenue.com` |
| Mobile menu | `site.js` + `data-menu-toggle` |
| AUTH-UNIFY U4=L | No Log in on welcome; `/` Sign In unchanged |

---

## Changed (Bolt UI ported)

| Area | Before | After |
|------|--------|-------|
| **Background** | Flat `#030712` + hero orbs | Aurora glow + grid texture (Bolt) |
| **Nav** | Always blurred gray bar | Transparent → blur on scroll (`.nav.scrolled`) |
| **Log in** | Desktop + mobile buttons | **Removed** |
| **Disclaimer** | Top `.door-disclaimer` banner | **Removed from hero** → quiet footer line |
| **Hero** | Glass score-bar panel | Waveform visual + download chips row |
| **Hero downloads** | Only primary CTA | Chips: boot kit · ISO · linux pack + ISO redirect note |
| **How-it-works footer** | ISO + linux buttons | **Restored** — `/downloads/neuos-live.iso` · `/downloads/neuos-linux.tar.gz` |
| **#practice-install** | Not present | **Added** — Bolt-style terminal + `curl boot.sh` + tarball copy |
| **#download platform cards** | Not present | **Added** — macOS/Linux/Windows cards + ISO + Linux screen pack row |
| **Typography/colors** | Gray indigo tokens | Bolt ink `#07070c` + violet accent `#7c6cff` |
| **Brand mark** | Static gradient box | Pulse ring animation on mark |
| **Section cards** | Heavy gradients | Bolt glass `.card-surface` hover |
| **Steps** | Number circles | 01/02/03 + icon boxes |
| **Footer** | Centered stats grid | 4-column links + vitality blurb (Bolt layout) |
| **Footer stats** | 3 Life Dimensions stats | **Removed** (Bolt-style simplification) |

---

## Not ported (conflict — kept neuOS behavior)

| Bolt had | neuOS kept | Reason |
|----------|------------|--------|
| `curl boot.sh` terminal block | **Added** `#practice-install` section · also keep `/?test=1` | Both shown; boot.sh is prod URL when live |
| macOS/Linux/Windows download cards | **Added** `#download` section | Cards map to real `/downloads/*` URLs |
| `#how` / `#paths` anchors | `#how-it-works` / `#os-paths` | Existing nav + bookmarks |
| Brand `href="/"` | Brand → `neuavenue.com` | Two-doors policy |
| React + Lucide + Tailwind build | Static HTML/CSS/JS | Cloudflare static deploy |
| Bolt `#download` hash CTA | Direct `/downloads/*` hrefs | Must download real files |

---

## Files touched

| File | Action |
|------|--------|
| `public/welcome/index.html` | Rewritten |
| `public/welcome/welcome.css` | Rewritten |
| `public/welcome/site.js` | Added nav scroll listener |
| `public/welcome/restore-pre-welcome4-bolt.sh` | **New** rollback script |
| `public/welcome.pre-welcome4-bolt-20250831/` | **New** backup dir |

**Not touched:** `landing-templates.html`, `~/os-neuavenue/welcome/` (deploy pending), `/` SPA AuthBar

---

## Deploy + verify

```bash
rsync -av ~/neuOS/public/welcome/index.html ~/neuOS/public/welcome/welcome.css ~/neuOS/public/welcome/site.js ~/os-neuavenue/welcome/
# Leader deploy Door B: yes
curl -sL https://os.neuavenue.com/welcome/ | grep -c 'Log in'   # expect 0
```

Analyst: `VERIFICATION-WO-UI-NEU-WELCOME-4.md` after prod deploy.
