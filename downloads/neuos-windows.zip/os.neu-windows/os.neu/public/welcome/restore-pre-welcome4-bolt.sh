#!/usr/bin/env bash
# Rollback WELCOME-4 Bolt port — restores pre-port static welcome
set -euo pipefail
BACKUP="${1:-/home/billy-lee/neuOS/public/welcome.pre-welcome4-bolt-20250831}"
TARGET="/home/billy-lee/neuOS/public/welcome"
if [[ ! -d "$BACKUP" ]]; then
  echo "Backup not found: $BACKUP" >&2
  exit 1
fi
cp -a "$BACKUP/index.html" "$BACKUP/welcome.css" "$BACKUP/site.js" "$TARGET/"
echo "Restored from $BACKUP"
echo "Deploy: rsync to ~/os-neuavenue/welcome/ then push Door B"
