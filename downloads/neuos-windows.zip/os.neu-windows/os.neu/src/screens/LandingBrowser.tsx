import { useEffect, useRef, useState } from 'react'
import { normalizeAddress, proxySrc, isAuthHost, isLoopbackHost, isOllamaApiUrl, HOME_HOST, WEB_HOME, GOOGLE_SIGNIN } from '../engine/browser'
import {
  deleteVisit,
  editVisit,
  hostOf,
  loadLedger,
  recordTool,
  saveLedger,
  suggestTools,
  upsertDownload,
  upsertVisit,
  type DownloadRecord,
} from '../engine/browseLedger'
import { BrowserChrome, type BrowserTab, type ChromeMenu } from '../components/BrowserChrome'
import { SitePolicyPanel } from '../components/SitePolicyPanel'
import {
  addBookmarkItem,
  addFolder,
  deleteBookmarkItem,
  deleteFolder,
  editBookmarkItem,
  loadBookmarkStore,
  moveBookmarkItem,
  renameFolder,
  saveBookmarkStore,
  toggleFolderCollapsed,
  type BookmarkStore,
} from '../engine/bookmarks'
import { BookmarksManagerDialog } from '../components/BookmarksManagerDialog'
import { LayerRail } from '../components/LayerRail'
import { PhoneHome } from '../components/PhoneHome'
import { SiteIdentity } from '../components/SiteIdentity'
import { StatusBar } from '../components/StatusBar'
import { TalkDrawer } from '../components/TalkDrawer'
import { logoutRequest, trackEvent } from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

const HOME = HOME_HOST
export type DevtoolsDock = 'hidden' | 'left' | 'top'

type TabSession = { url: string; href: string | null; status: 'home' | 'loading' | 'ready' | 'error'; error: string }

// Module-level (not component state) so open tabs survive LandingBrowser
// unmount/remount within the same app session — e.g. leaving to LUI/PhoneHome
// and returning (WO-BROWSER-SESSION-1). Resets on full app restart by design.
const browseSessionStore: { current: { tabs: BrowserTab[]; activeId: string; sessions: Record<string, TabSession> } | null } = {
  current: null,
}

function isLoopback(href: string) {
  return isLoopbackHost(href)
}

export function LandingBrowser() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const email = neu.account?.email || null
  const restored = browseSessionStore.current
  const restoredActive = restored?.sessions[restored.activeId]
  const [tabs, setTabs] = useState<BrowserTab[]>(restored?.tabs ?? [{ id: 't1', title: 'Home', url: HOME }])
  const [activeId, setActiveId] = useState(restored?.activeId ?? 't1')
  const [url, setUrl] = useState(restoredActive?.url ?? HOME)
  const [href, setHref] = useState<string | null>(restoredActive?.href ?? null)
  const [status, setStatus] = useState<'home' | 'loading' | 'ready' | 'error'>(restoredActive?.status ?? 'home')
  const [error, setError] = useState(restoredActive?.error ?? '')
  const [ledger, setLedger] = useState(() => loadLedger(email))
  const [bookmarkStore, setBookmarkStore] = useState<BookmarkStore>(() => loadBookmarkStore(email))
  const [bookmarksManagerOpen, setBookmarksManagerOpen] = useState(false)
  const [dock, setDock] = useState<DevtoolsDock>('hidden')
  const [forcedMenu, setForcedMenu] = useState<ChromeMenu>('none')
  const [chromeMenu, setChromeMenu] = useState<ChromeMenu>('none')
  const [flyoutBounds, setFlyoutBounds] = useState<{
    x: number
    y: number
    width: number
    height: number
  } | null>(null)
  const [identityOpen, setIdentityOpen] = useState(false)
  const [pageSnap, setPageSnap] = useState<string | null>(null)
  // WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND: address-bar click/focus, or
  // a main-process "this site is Blocked" notice, opens the per-site
  // Default/Allow/Block panel — reusing/extending `.browse-error`'s spot
  // (hides the live BrowserView the same way an error page does).
  const [sitePanelOpen, setSitePanelOpen] = useState(false)
  const paneRef = useRef<HTMLDivElement>(null)
  const toolsRef = useRef<HTMLDivElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const dragRef = useRef<{ x: number; y: number } | null>(null)
  const newWindowLockRef = useRef(0)
  const prevRef = useRef<{ url: string; href: string | null }>({ url: HOME, href: null })
  const activeIdRef = useRef(activeId)
  const browsingRef = useRef(false)
  const lastNavRef = useRef('')
  const sessionsRef = useRef<Record<string, TabSession>>(
    restored?.sessions ?? { t1: { url: HOME, href: null, status: 'home', error: '' } },
  )
  const electron = typeof window !== 'undefined' && Boolean(window.neuos?.browse)
  const goUrlRef = useRef<(next: string) => Promise<void>>(async () => {})
  const menuOpen = chromeMenu !== 'none' && chromeMenu !== 'account'

  activeIdRef.current = activeId
  browsingRef.current = Boolean(href) && status !== 'home'
  // Latest-render mirrors, read only at unmount time to snapshot session state
  // without setState-after-unmount (WO-BROWSER-SESSION-1).
  const tabsRef = useRef(tabs)
  tabsRef.current = tabs
  const liveRef = useRef({ url, href, status, error })
  liveRef.current = { url, href, status, error }

  const saveActiveSession = () => {
    const id = activeIdRef.current
    sessionsRef.current[id] = { url, href, status, error }
    if (href) {
      setTabs((rows) =>
        rows.map((tab) =>
          tab.id === id ? { ...tab, url: href, title: tab.title === 'New tab' || tab.title === 'Home' ? hostOf(href) : tab.title } : tab,
        ),
      )
    }
  }

  const showSession = (id: string) => {
    const session = sessionsRef.current[id] || { url: HOME, href: null, status: 'home' as const, error: '' }
    setActiveId(id)
    setUrl(session.url)
    setHref(session.href)
    setStatus(session.status)
    setError(session.error)
    if (session.href) {
      void window.neuos?.browse.go?.(session.href).then((result) => {
        if (!result?.ok) return
        const finalHref = result.href || session.href
        if (!finalHref) return
        setUrl(finalHref)
        setHref(finalHref)
        setStatus('ready')
        lastNavRef.current = finalHref
        sessionsRef.current[id] = { url: finalHref, href: finalHref, status: 'ready', error: '' }
      })
    } else {
      void window.neuos?.browse.hide()
    }
  }

  const openInNewTab = (target?: string) => {
    saveActiveSession()
    const id = `t-${Date.now()}`
    const next = target?.trim() || ''
    setTabs((rows) => {
      const stamped = rows.map((tab) =>
        tab.id === activeIdRef.current
          ? {
              ...tab,
              url: href || url,
              title: href ? (tab.title === 'New tab' || tab.title === 'Home' ? hostOf(href) : tab.title) : tab.title,
            }
          : tab,
      )
      if (next && /^https?:\/\//i.test(next)) {
        return [...stamped, { id, title: hostOf(next), url: next }]
      }
      return [...stamped, { id, title: 'New tab', url: HOME }]
    })
    setActiveId(id)
    activeIdRef.current = id
    if (next && /^https?:\/\//i.test(next)) {
      sessionsRef.current[id] = { url: next, href: next, status: 'loading', error: '' }
      setUrl(next)
      setHref(next)
      setStatus('loading')
      setError('')
      lastNavRef.current = next
      browsingRef.current = true
      void window.neuos?.browse.go?.(next).then((result) => {
        if (!result?.ok) {
          // Superseded by a newer navigation on the shared view — that call
          // owns the UI update now (WO-BROWSER-SESSION-1 fix).
          if (result?.reason === 'superseded') return
          setStatus('error')
          setError(result?.reason || 'Could not open that page.')
          return
        }
        const finalHref = result.href || next
        setUrl(finalHref)
        setHref(finalHref)
        setStatus('ready')
        lastNavRef.current = finalHref
        remember(finalHref, hostOf(finalHref))
        patchTab(id, { url: finalHref, title: hostOf(finalHref) })
        sessionsRef.current[id] = { url: finalHref, href: finalHref, status: 'ready', error: '' }
      })
      return
    }
    sessionsRef.current[id] = { url: HOME, href: null, status: 'home', error: '' }
    setUrl(HOME)
    setHref(null)
    setStatus('home')
    setError('')
    void window.neuos?.browse.hide()
    void window.neuos?.browse.devtools?.(null)
  }
  const openInNewTabRef = useRef(openInNewTab)
  openInNewTabRef.current = openInNewTab
  const saveActiveSessionRef = useRef(saveActiveSession)
  saveActiveSessionRef.current = saveActiveSession
  const showSessionRef = useRef(showSession)
  showSessionRef.current = showSession

  useEffect(() => {
    setLedger(loadLedger(email))
    setBookmarkStore(loadBookmarkStore(email))
  }, [email])

  useEffect(() => {
    return () => {
      const id = activeIdRef.current
      const live = liveRef.current
      const sessions = {
        ...sessionsRef.current,
        [id]: { url: live.url, href: live.href, status: live.status, error: live.error },
      }
      const finalTabs = tabsRef.current.map((tab) =>
        tab.id === id && live.href
          ? { ...tab, url: live.href, title: tab.title === 'New tab' || tab.title === 'Home' ? hostOf(live.href) : tab.title }
          : tab,
      )
      browseSessionStore.current = { tabs: finalTabs, activeId: id, sessions }
    }
  }, [])

  useEffect(() => {
    saveLedger(email, ledger)
    if (!email) return
    const timer = window.setTimeout(() => {
      void fetch('/api/browse/ledger', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-osneu-token': localStorage.getItem('os.neu.token') || '' },
        body: JSON.stringify(ledger),
      }).catch(() => {})
    }, 800)
    return () => window.clearTimeout(timer)
  }, [email, ledger])

  const patchTab = (id: string, patch: Partial<BrowserTab>) => {
    setTabs((rows) => rows.map((tab) => (tab.id === id ? { ...tab, ...patch } : tab)))
  }

  const remember = (next: string, title?: string) => {
    setLedger((cur) =>
      recordTool(
        upsertVisit(cur, { url: next, title: title || hostOf(next) }),
        'visit',
        next,
      ),
    )
    void trackEvent('view', 'landing', next)
  }

  useEffect(() => {
    const off = window.neuos?.browse.onDownload?.((rec: DownloadRecord) => {
      setLedger((cur) => recordTool(upsertDownload(cur, rec), 'download', rec.filename))
    })
    return () => off?.()
  }, [])

  useEffect(() => {
    const off = window.neuos?.browse.onNavigated?.((payload) => {
      if (!payload?.href || !browsingRef.current) return
      const title = payload.title?.trim() || hostOf(payload.href)
      setUrl(payload.href)
      setHref(payload.href)
      setStatus('ready')
      setError('')
      patchTab(activeIdRef.current, { url: payload.href, title })
      sessionsRef.current[activeIdRef.current] = {
        url: payload.href,
        href: payload.href,
        status: 'ready',
        error: '',
      }
      if (lastNavRef.current !== payload.href) {
        lastNavRef.current = payload.href
        remember(payload.href, title)
      }
    })
    return () => off?.()
  }, [])

  useEffect(() => {
    const off = window.neuos?.browse.onOpenTab?.((payload) => {
      if (payload?.href) openInNewTabRef.current(payload.href)
    })
    return () => off?.()
  }, [])

  useEffect(() => {
    // WO-UI-NEU-DAF-BLANK-POPUP-121: the main process denies a window.open
    // because this origin is set to Block, and asks for os.neu's own panel
    // (not the site's silent/alert-style blocker message) instead of a
    // no-op deny.
    const off = window.neuos?.browse.onPopupBlocked?.(() => {
      setSitePanelOpen(true)
    })
    return () => off?.()
  }, [])

  useEffect(() => {
    const pane = paneRef.current
    if (!electron || !pane || !window.neuos) return
    if (
      neu.exitOpen ||
      neu.manualOpen ||
      neu.downloadOpen ||
      neu.chromeMenuOpen ||
      chromeMenu === 'bar-folder' ||
      neu.authPanel !== 'none' ||
      identityOpen ||
      bookmarksManagerOpen ||
      sitePanelOpen ||
      status === 'home' ||
      status === 'error' ||
      !href
    ) {
      void window.neuos.browse.hide()
      void window.neuos.browse.devtools?.(null)
      return
    }
    const send = () => {
      const box = pane.getBoundingClientRect()
      const full = {
        x: Math.round(box.left),
        y: Math.round(box.top),
        width: Math.round(box.width),
        height: Math.round(box.height),
      }
      // The chrome menu flyout (tools/bookmarks/history/downloads/bar-folder)
      // is an HTML overlay that the native BrowserView would otherwise cover,
      // since a BrowserView always composites above this window's own page.
      // chromeMenu === 'bar-folder' already returned above (browse view hidden), so
      // reaching here means chromeMenu can't be 'bar-folder' -- no redundant check needed.
      const overlay = menuOpen ? flyoutBounds : null
      if (overlay && overlay.width > 8 && overlay.height > 8) {
        const gap = 8
        // Free only the side strip behind the card so the live page stays and sizes match.
        const leftWidth = Math.round(overlay.x - gap - full.x)
        if (leftWidth >= 96) {
          void window.neuos?.browse.bounds({
            x: full.x,
            y: full.y,
            width: leftWidth,
            height: full.height,
          })
        } else {
          const belowTop = Math.round(overlay.y + gap)
          void window.neuos?.browse.bounds({
            x: full.x,
            y: belowTop,
            width: full.width,
            height: Math.max(0, full.y + full.height - belowTop),
          })
        }
      } else {
        void window.neuos?.browse.bounds(full)
      }
      const tools = toolsRef.current?.getBoundingClientRect()
      if (dock === 'hidden' || !tools || tools.width < 8 || tools.height < 8) {
        void window.neuos?.browse.devtools?.(null)
        return
      }
      void window.neuos?.browse.devtools?.({
        x: Math.round(tools.left),
        y: Math.round(tools.top),
        width: Math.round(tools.width),
        height: Math.round(tools.height),
      })
    }
    const ro = new ResizeObserver(send)
    ro.observe(pane)
    if (bodyRef.current) ro.observe(bodyRef.current)
    if (toolsRef.current) ro.observe(toolsRef.current)
    window.addEventListener('resize', send)
    send()
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', send)
    }
  }, [
    electron,
    href,
    neu.exitOpen,
    neu.manualOpen,
    neu.downloadOpen,
    neu.chromeMenuOpen,
    chromeMenu,
    neu.authPanel,
    identityOpen,
    bookmarksManagerOpen,
    sitePanelOpen,
    status,
    dock,
    menuOpen,
    flyoutBounds,
  ])

  useEffect(() => {
    return () => {
      void window.neuos?.browse.hide()
      void window.neuos?.browse.devtools?.(null)
    }
  }, [])

  const goHome = () => {
    setSitePanelOpen(false)
    prevRef.current = { url, href }
    setHref(null)
    setUrl(HOME)
    setStatus('home')
    setError('')
    patchTab(activeId, { title: 'Home', url: HOME })
    sessionsRef.current[activeId] = { url: HOME, href: null, status: 'home', error: '' }
    void window.neuos?.browse.hide()
    void window.neuos?.browse.devtools?.(null)
  }

  const restorePrev = () => {
    const prev = prevRef.current
    setUrl(prev.url)
    setHref(prev.href)
    setStatus(prev.href ? 'ready' : 'home')
    setError('')
    if (!prev.href) void window.neuos?.browse.hide()
  }

  const openIdentityWindow = async (target: string) => {
    // Auth hosts (Google/Microsoft/Apple/GitHub) must always hand off to the
    // OS system browser — never an embedded Electron window/tab — per Google's
    // OAuth policy (WO-BROWSER-WINDOW-1). No `browse.newWindow` fallback here.
    if (window.neuos?.browse?.openExternal) {
      await window.neuos.browse.openExternal(target)
      return
    }
    window.open(target, 'osneu-id', 'popup=yes,width=480,height=740')
  }

  const openNewWindow = (target?: string) => {
    // Guard against a single click landing here twice in quick succession
    // (mirrors the main-process debounce in browse:newWindow) — reported as
    // "two windows open from one click" during Leader verify, 2026-09-02.
    const now = Date.now()
    if (now - newWindowLockRef.current < 800) return
    newWindowLockRef.current = now
    const candidate = target?.trim() || href || ''
    if (candidate && isAuthHost(candidate)) {
      setIdentityOpen(true)
      void openIdentityWindow(candidate)
      return
    }
    if (electron && window.neuos?.browse?.newWindow) {
      void window.neuos.browse.newWindow(candidate || WEB_HOME)
      return
    }
    // Hosted web (WO-UI-NEU-DAF-FRONT-WINDOW-121 / UI-B17 AMEND): match the
    // Electron face above — a real browser window/tab via openDaf(), not a
    // silent in-app-tab-only fallback. openDaf() shows a daf.neu-titled
    // overlay if the browser's popup blocker ate the window.open.
    neu.openDaf(candidate || WEB_HOME)
  }

  const goUrl = async (next: string) => {
    setSitePanelOpen(false)
    const parsed = normalizeAddress(next)
    if (parsed.kind === 'home') {
      goHome()
      return
    }
    if (parsed.kind === 'invalid') {
      setStatus('error')
      setError(parsed.reason)
      return
    }
    if (isOllamaApiUrl(parsed.href)) {
      setUrl(parsed.href)
      setHref(null)
      setStatus('error')
      setError(
        ko
          ? '127.0.0.1:11434 은 웹사이트가 아니라 이 PC의 무료 AI(Ollama) API입니다. Doc/Sheet를 열고 모델을 os.neu-local(llama3.2:1b)로 둔 뒤 Ask AI를 쓰세요. 터미널: ollama serve'
          : '127.0.0.1:11434 is the local free AI (Ollama) API — not a website. Open Doc/Sheet, keep model os.neu-local (llama3.2:1b), then Ask AI. Terminal: ollama serve',
      )
      void window.neuos?.browse.hide()
      return
    }
    // WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND) fix: a freshly-opened
    // `?go=landing&openTarget=` window (the daf.neu front window / New
    // window) fires this same-tick, before the async probeNetwork() in
    // App.tsx has resolved — `neu.network.online` is still its untouched
    // `false` default. Bouncing that first navigation back to Home here
    // made the brand-new daf.neu window silently open on Home instead of
    // the requested site even though the machine was online the whole
    // time. Only refuse once we have a *confirmed* offline probe result.
    if (neu.network.probed && !neu.network.online && !isLoopback(parsed.href)) {
      setStatus('error')
      setError(copy.offlineHint)
      restorePrev()
      return
    }
    if (isAuthHost(parsed.href)) {
      setIdentityOpen(true)
      await openIdentityWindow(parsed.href)
      return
    }
    prevRef.current = { url, href }
    setUrl(parsed.href)
    setHref(parsed.href)
    setStatus('loading')
    setError('')
    patchTab(activeId, { url: parsed.href, title: hostOf(parsed.href) })
    if (window.neuos?.browse) {
      const result = await window.neuos.browse.go(parsed.href)
      if (result.restored && result.href) {
        setUrl(result.href)
        setHref(result.href)
        setStatus('ready')
        patchTab(activeId, { url: result.href, title: hostOf(result.href) })
        return
      }
      if (!result.ok) {
        // A newer navigation (another tab, or the user re-typing) superseded
        // this one on the shared BrowserView — that newer call owns the UI
        // update now, so leave this tab's state alone instead of bouncing it
        // back to the previous page (WO-BROWSER-SESSION-1 fix).
        if (result.reason === 'superseded') return
        if (isLoopback(parsed.href)) {
          setStatus('error')
          setError(
            ko
              ? `이 기기 주소(${parsed.href})를 열 수 없습니다. 서비스가 켜져 있는지 확인하세요.`
              : `Could not open ${parsed.href} on this PC. Is that service running?`,
          )
          setHref(null)
          void window.neuos?.browse.hide()
          return
        }
        restorePrev()
        return
      }
      const finalHref = result.href || parsed.href
      setStatus('ready')
      setUrl(finalHref)
      setHref(finalHref)
      lastNavRef.current = finalHref
      remember(finalHref, hostOf(finalHref))
      patchTab(activeId, { url: finalHref, title: hostOf(finalHref) })
      sessionsRef.current[activeId] = { url: finalHref, href: finalHref, status: 'ready', error: '' }
    }
  }
  useEffect(() => {
    goUrlRef.current = goUrl
  })

  useEffect(() => {
    if (!neu.browseTarget) return
    const target = neu.browseTarget
    neu.clearBrowseTarget()
    // "Web"/"Vitality" shortcuts always stamp a fresh browseTarget, even when
    // returning to an already-open session (WO-BROWSER-SESSION-1 follow-up,
    // issue A1). Blindly navigating the active tab here clobbered whatever
    // the user had restored ("everything disappears"). If a session with
    // real content already exists, route the shortcut to a tab instead of
    // hijacking the current one — reusing a matching tab if one is already
    // open, so repeat toggling doesn't pile up duplicates.
    const alreadyBrowsing = tabsRef.current.length > 1 || Boolean(liveRef.current.href)
    if (alreadyBrowsing) {
      const existing = tabsRef.current.find((tab) => tab.url === target)
      if (existing && existing.id !== activeIdRef.current) {
        saveActiveSessionRef.current()
        showSessionRef.current(existing.id)
        return
      }
      if (existing && existing.id === activeIdRef.current) return
      openInNewTabRef.current(target)
      return
    }
    void goUrlRef.current(target)
  }, [neu.browseTarget, neu.clearBrowseTarget])

  const openDevtools = (next: DevtoolsDock) => {
    setDock(next)
    if (next !== 'hidden') {
      setLedger((cur) => recordTool(cur, 'devtools', next))
      void trackEvent('click', 'landing', `devtools-${next}`)
    }
  }

  const showProxy = Boolean(href) && !electron && status !== 'error' && status !== 'home'
  const assigned = suggestTools(ledger, ko)

  return (
    <section className="screen lui">
      <StatusBar />
      <LayerRail active={['lui', 'driver']} onOpen={() => neu.go('studio')} />
      <BrowserChrome
        tabs={tabs}
        activeId={activeId}
        url={url}
        visits={ledger.visits}
        bookmarkFolders={bookmarkStore.folders}
        bookmarkItems={bookmarkStore.items}
        downloads={ledger.downloads}
        tools={assigned}
        account={neu.account}
        ko={ko}
        locale={locale}
        electron={electron}
        onSelectTab={(id) => {
          if (id === activeId) return
          setSitePanelOpen(false)
          saveActiveSession()
          showSession(id)
        }}
        onNewTab={() => openInNewTab()}
        onCloseTab={(id) => {
          const next = tabs.filter((tab) => tab.id !== id)
          if (!next.length) return
          delete sessionsRef.current[id]
          setTabs(next)
          if (id === activeId) showSession(next[next.length - 1].id)
        }}
        onNewWindow={() => openNewWindow(href || undefined)}
        onUrl={(value) => void goUrl(value)}
        onAddressPanel={() => {
          if (href) setSitePanelOpen(true)
        }}
        onHome={goHome}
        onBack={() => {
          if (window.neuos?.browse.back) {
            void window.neuos.browse.back().then((result) => {
              if (result.ok && result.href) {
                setUrl(result.href)
                setHref(result.href)
                setStatus('ready')
                remember(result.href, hostOf(result.href))
                return
              }
              restorePrev()
            })
            return
          }
          restorePrev()
        }}
        onForward={
          electron
            ? () => {
                void window.neuos?.browse.forward?.().then((result) => {
                  if (result.ok && result.href) {
                    setUrl(result.href)
                    setHref(result.href)
                    setStatus('ready')
                    remember(result.href, hostOf(result.href))
                  }
                })
              }
            : undefined
        }
        onReload={
          electron
            ? () => {
                void window.neuos?.browse.reload?.().then((result) => {
                  if (result.ok && result.href) {
                    setUrl(result.href)
                    setHref(result.href)
                    setStatus('ready')
                  }
                })
              }
            : undefined
        }
        onZoom={
          electron
            ? async (delta) => {
                const result = await window.neuos?.browse.zoom?.(delta)
                return result
              }
            : undefined
        }
        onBookmark={(folderId) => {
          if (!href) return
          setBookmarkStore((store) => {
            const next = addBookmarkItem(store, href, hostOf(href), folderId ?? null)
            saveBookmarkStore(email, next)
            return next
          })
          setLedger((cur) => recordTool(cur, 'bookmark', href))
        }}
        onAddBookmark={(next, title, folderId) => {
          const parsed = normalizeAddress(next)
          const neat = parsed.kind === 'url' ? parsed.href : next
          setBookmarkStore((store) => {
            const nextStore = addBookmarkItem(store, neat, title || hostOf(neat), folderId ?? null)
            saveBookmarkStore(email, nextStore)
            return nextStore
          })
          setLedger((cur) => recordTool(cur, 'bookmark', neat))
        }}
        onEditBookmark={(id, patch) => {
          setBookmarkStore((store) => {
            const next = editBookmarkItem(store, id, patch)
            saveBookmarkStore(email, next)
            return next
          })
        }}
        onDeleteBookmark={(id) => {
          setBookmarkStore((store) => {
            const next = deleteBookmarkItem(store, id)
            saveBookmarkStore(email, next)
            return next
          })
        }}
        onAddFolder={(title) => {
          setBookmarkStore((store) => {
            const next = addFolder(store, title)
            saveBookmarkStore(email, next)
            return next
          })
        }}
        onToggleFolderCollapsed={(id) => {
          setBookmarkStore((store) => {
            const next = toggleFolderCollapsed(store, id)
            saveBookmarkStore(email, next)
            return next
          })
        }}
        onOpenBookmarksManager={() => setBookmarksManagerOpen(true)}
        onOpenSaved={(saved) => void goUrl(saved)}
        onAddVisit={(next, title) => {
          const parsed = normalizeAddress(next)
          const href = parsed.kind === 'url' ? parsed.href : next
          setLedger((cur) => recordTool(upsertVisit(cur, { url: href, title }), 'history-add', href))
        }}
        onEditVisit={(id, patch) => {
          setLedger((cur) => recordTool(editVisit(cur, id, patch), 'history-edit', patch.url))
        }}
        onDeleteVisit={(id) => {
          setLedger((cur) => recordTool(deleteVisit(cur, id), 'history-delete', id))
        }}
        onOpenDownload={(id) => {
          void window.neuos?.browse.openDownload?.(id)
        }}
        onShowDownload={(id) => {
          void window.neuos?.browse.showDownload?.(id)
        }}
        onRunTool={(tool) => {
          setLedger((cur) => recordTool(cur, tool.id, tool.label))
          void trackEvent('open-app', 'landing', tool.id)
          if (tool.run === 'devtools') openDevtools(dock === 'hidden' ? 'left' : dock)
          else if (tool.run === 'office-doc') neu.openOffice('doc')
          else if (tool.run === 'office-sheet') neu.openOffice('sheet')
          else if (tool.run === 'downloads') {
            setForcedMenu('downloads')
            window.setTimeout(() => setForcedMenu('none'), 0)
          }
          else if (tool.href) void goUrl(tool.href)
        }}
        onRequestSignIn={() => neu.setAuthPanel('login')}
        onAskIdentity={() => setIdentityOpen(true)}
        onSignOut={() => {
          void logoutRequest()
          neu.setAccount(null)
          // Sign-out resets the tab strip to a single Home tab — the device
          // session is device-local (accounts.json / device auth are not a
          // unified identity), so the next person at this machine shouldn't
          // land back on the signed-out user's open tabs (issue A2).
          sessionsRef.current = { t1: { url: HOME, href: null, status: 'home', error: '' } }
          setTabs([{ id: 't1', title: 'Home', url: HOME }])
          setActiveId('t1')
          setUrl(HOME)
          setHref(null)
          setStatus('home')
          setError('')
          void window.neuos?.browse.hide()
        }}
        openMenu={forcedMenu}
        onMenuChange={(next) => {
          setChromeMenu(next)
          if (next !== 'bar-folder') setPageSnap(null)
        }}
        onFlyoutBounds={setFlyoutBounds}
        onPrepareOverlay={async () => {
          if (!electron) return
          try {
            const snap = await window.neuos?.browse?.snapshot?.()
            if (snap?.ok && snap.dataUrl) setPageSnap(snap.dataUrl)
          } catch {
            /* keep last frame if capture fails */
          }
        }}
      >
        <div className={`browse-body dock-${dock}`} ref={bodyRef}>
          <button
            type="button"
            className="devtools-hidebar"
            aria-label={ko ? '개발툴' : 'DevTools'}
            title={ko ? '끌어 위나 왼쪽에 붙이거나, 눌러서 엽니다.' : 'Drag to the top or left, or click to open.'}
            onPointerDown={(event) => {
              dragRef.current = { x: event.clientX, y: event.clientY }
              event.currentTarget.setPointerCapture(event.pointerId)
            }}
            onPointerMove={(event) => {
              const start = dragRef.current
              if (!start) return
              const dx = event.clientX - start.x
              const dy = event.clientY - start.y
              if (dy < -40 && Math.abs(dy) > Math.abs(dx)) openDevtools('top')
              else if (dx > 36) openDevtools('left')
            }}
            onPointerUp={(event) => {
              const start = dragRef.current
              dragRef.current = null
              if (!start) return
              if (Math.hypot(event.clientX - start.x, event.clientY - start.y) < 8) {
                openDevtools(dock === 'hidden' ? 'left' : 'hidden')
              }
            }}
          >
            <i />
          </button>
          {dock === 'left' ? <div className="devtools-slot" ref={toolsRef} /> : null}
          <div className="browse-column">
            {dock === 'top' ? <div className="devtools-slot top" ref={toolsRef} /> : null}
            <div className={`browse-stage${showProxy ? ' has-frame' : ''}`} ref={paneRef}>
              {chromeMenu === 'bar-folder' && pageSnap ? (
                <img className="browse-veil" src={pageSnap} alt="" />
              ) : null}
              {status === 'home' || !href ? <PhoneHome /> : null}
              {showProxy ? (
                <iframe
                  className="browse-frame"
                  title="Guest page"
                  src={proxySrc(href as string)}
                  sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-modals"
                  onLoad={() => setStatus('ready')}
                  onError={() => {
                    setStatus('ready')
                    setIdentityOpen(true)
                  }}
                />
              ) : null}
              {status === 'loading' && !showProxy ? <div className="browse-loading">{copy.opening}</div> : null}
              {sitePanelOpen && href ? (
                <div className="browse-error browse-site-panel">
                  <SitePolicyPanel host={hostOf(href)} ko={ko} onClose={() => setSitePanelOpen(false)} />
                </div>
              ) : status === 'error' ? (
                <div className="browse-error">
                  <b>{copy.browseFail}</b>
                  <p>{error}</p>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </BrowserChrome>
      <BookmarksManagerDialog
        open={bookmarksManagerOpen}
        folders={bookmarkStore.folders}
        items={bookmarkStore.items}
        ko={ko}
        onClose={() => setBookmarksManagerOpen(false)}
        onOpen={(saved) => {
          setBookmarksManagerOpen(false)
          void goUrl(saved)
        }}
        onAddFolder={(title) =>
          setBookmarkStore((store) => {
            const next = addFolder(store, title)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onRenameFolder={(id, title) =>
          setBookmarkStore((store) => {
            const next = renameFolder(store, id, title)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onDeleteFolder={(id) =>
          setBookmarkStore((store) => {
            const next = deleteFolder(store, id)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onEditBookmark={(id, patch) =>
          setBookmarkStore((store) => {
            const next = editBookmarkItem(store, id, patch)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onDeleteBookmark={(id) =>
          setBookmarkStore((store) => {
            const next = deleteBookmarkItem(store, id)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onMoveBookmark={(id, folderId) =>
          setBookmarkStore((store) => {
            const next = moveBookmarkItem(store, id, folderId)
            saveBookmarkStore(email, next)
            return next
          })
        }
        onAddBookmark={(url, title, folderId) => {
          const parsed = normalizeAddress(url)
          const neat = parsed.kind === 'url' ? parsed.href : url
          setBookmarkStore((store) => {
            const next = addBookmarkItem(store, neat, title || hostOf(neat), folderId ?? null)
            saveBookmarkStore(email, next)
            return next
          })
          setLedger((cur) => recordTool(cur, 'bookmark', neat))
        }}
      />
      <SiteIdentity
        open={identityOpen}
        site={href || WEB_HOME}
        account={neu.account}
        electron={electron}
        ko={ko}
        onClose={() => setIdentityOpen(false)}
        onGoogle={() => {
          setIdentityOpen(false)
          void openIdentityWindow(GOOGLE_SIGNIN)
        }}
        onOsNeu={() => {
          setIdentityOpen(false)
          neu.setAuthPanel('login')
        }}
      />
      <TalkDrawer />
    </section>
  )
}
