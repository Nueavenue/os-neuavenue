/** Temporary landing layout previews — purge with scripts/purge-landing-previews.sh */

import { useEffect } from 'react'

type PreviewLink = { id: string; label: string; desc: string; href: string; accent: string }

const LINKS: PreviewLink[] = [
  {
    id: 'a',
    label: '안 A · 페인포인트',
    desc: '3가지 고통 카드가 먼저 — 이탈 방지형',
    href: '/landing-samples/a.html',
    accent: '#f59e0b',
  },
  {
    id: 'b',
    label: '안 B · 구글형',
    desc: '밝은 배경 · 중앙 로고 · 검색창 — 지금 홈 톤',
    href: '/landing-samples/b.html',
    accent: '#4285f4',
  },
  {
    id: 'c',
    label: '안 C · 스토리',
    desc: '왼쪽 긴 글 + 오른쪽 고정 패널',
    href: '/landing-samples/c.html',
    accent: '#a855f7',
  },
]

function PreviewRibbon({ label, accent }: { label: string; accent: string }) {
  return (
    <div className="lp-ribbon" style={{ background: accent }}>
      {label} · 임시 시안 · <a href="/landing-samples/">3안 비교</a>
    </div>
  )
}

export function LandingPreviewHub() {
  return (
    <div className="lp lp-hub">
      <PreviewRibbon label="랜딩 시안 허브" accent="#4f46e5" />
      <div className="lp-hub-inner">
        <h1>os.neuavenue.com<br />랜딩 3안</h1>
        <p className="lp-lead">각 버튼을 누르면 <strong>완전히 다른 레이아웃</strong>이 열립니다.</p>
        <div className="lp-hub-grid">
          {LINKS.map((item) => (
            <a
              key={item.id}
              className="lp-hub-card"
              href={item.href}
              style={{ borderColor: item.accent }}
            >
              <span className="lp-tag" style={{ background: item.accent }}>
                {item.label}
              </span>
              <p>{item.desc}</p>
              <span className="lp-cta">미리보기 →</span>
            </a>
          ))}
        </div>
        <p className="lp-note">
          정적 HTML (권장): <a href="/landing-samples/">/landing-samples/</a> · SPA: <code>/?go=preview-a</code>
        </p>
      </div>
    </div>
  )
}

export function LandingPreviewA() {
  const pains = [
    { n: '01', title: '폴더·시작 메뉴를 못 읽는다', body: '성인 4명 중 1명은 디지털 문해가 낮습니다.' },
    { n: '02', title: 'AI까지 가는 길이 너무 깁니다', body: '부팅 → 바탕화면 → 브라우저 → 다시 AI.' },
    { n: '03', title: '전원 직후가 공포 화면이다', body: 'BIOS·영문 오류는 “고장”으로 느껴집니다.' },
  ]
  const products = [
    { t: 'os.neu 스크린', d: '말하기·문서·브라우저' },
    { t: '이 기기에 심기', d: '디스크 유지 · Linux' },
    { t: 'USB 굽기', d: '다른 PC 부팅' },
    { t: '웹 체험', d: '설치 없이 시작' },
  ]
  return (
    <div className="lp lp-a">
      <PreviewRibbon label="안 A · 페인포인트 퍼스트" accent="#f59e0b" />
      <header className="lp-a-hero">
        <h1>
          PC는 있는데,
          <br />
          <em>쓸 줄 모르는</em> 사람이 많습니다
        </h1>
        <p>새 OS 설치가 아닙니다. 전원 다음 화면을 바꿉니다.</p>
      </header>
      <div className="lp-a-pains">
        {pains.map((p) => (
          <article key={p.n} className="lp-a-pain">
            <span className="lp-a-num">{p.n}</span>
            <div>
              <h2>{p.title}</h2>
              <p>{p.body}</p>
            </div>
          </article>
        ))}
      </div>
      <section className="lp-a-products">
        <h3>지금 쓸 수 있는 것</h3>
        <div className="lp-a-grid">
          {products.map((p) => (
            <div key={p.t} className="lp-a-chip">
              <strong>{p.t}</strong>
              <span>{p.d}</span>
            </div>
          ))}
        </div>
        <div className="lp-a-road">
          <span>Y1 기기 면</span>
          <span>Y2 워크스페이스</span>
          <span>Y3 교육·기관</span>
        </div>
        <a className="lp-btn lp-btn-amber" href="/?test=1&go=install">
          30초 체험
        </a>
      </section>
    </div>
  )
}

export function LandingPreviewB() {
  useEffect(() => {
    document.body.style.background = '#ffffff'
    document.body.style.color = '#202124'
    return () => {
      document.body.style.background = ''
      document.body.style.color = ''
    }
  }, [])
  return (
    <div className="lp lp-b">
      <PreviewRibbon label="안 B · 구글형 미니멀" accent="#4285f4" />
      <main className="lp-b-center">
        <img className="lp-b-logo" src="/brand/neuos-logo-transparent.png" alt="OS.neu" />
        <p className="lp-b-q">
          전원을 켰는데 <strong>뭘 눌러야 할지</strong> 모르시나요?
        </p>
        <div className="lp-b-search">
          <span className="lp-b-mag">⌕</span>
          <span>말로 문서 쓰기, 웹 열기, 하드웨어 점검…</span>
        </div>
        <div className="lp-b-btns">
          <a className="lp-b-primary" href="/?test=1&go=install">
            OS.neu 체험
          </a>
          <a className="lp-b-secondary" href="/welcome/">
            설치 안내
          </a>
        </div>
      </main>
      <section className="lp-b-fold">
        <h2>스크롤 한 번 — 한눈에</h2>
        <div className="lp-b-cols">
          <article>
            <h3>무슨 일을 하나요</h3>
            <p>숨은 PC 위 AI 네이티브 화면. 말 한 줄로 시작.</p>
          </article>
          <article>
            <h3>무슨 상품이 있나요</h3>
            <p>Doc·Sheet·Slides·브라우저·심기·USB·웹.</p>
          </article>
          <article>
            <h3>무엇을 계획하나요</h3>
            <p>Y1 파일럿 → Y2 팀 구독 → Y3 교육 기관.</p>
          </article>
        </div>
      </section>
    </div>
  )
}

export function LandingPreviewC() {
  return (
    <div className="lp lp-c">
      <PreviewRibbon label="안 C · 스토리 + 고정 패널" accent="#a855f7" />
      <div className="lp-c-layout">
        <div className="lp-c-story">
          <h1>왜 이 사이트를 만들었나요</h1>
          <p>
            Copilot과 ChatGPT는 이미 데스크톱을 아는 사람을 전제합니다. 현장에는 PC는 있는데
            탐색기를 열지 못하는 사람이 더 많습니다.
          </p>
          <h2>세 가지 고통</h2>
          <ul className="lp-c-list">
            <li>
              <span className="lp-c-dot amber" /> 문해 — 버튼이 벽이다
            </li>
            <li>
              <span className="lp-c-dot indigo" /> 경로 — AI까지 너무 멀다
            </li>
            <li>
              <span className="lp-c-dot mint" /> 전원 — 첫 화면이 공포다
            </li>
          </ul>
          <h2>지금 하고 있는 일</h2>
          <p>
            Electron 브라우저, 문서·시트·슬라이드, Google 로그인, Linux 심기·USB — v1.0 코드에
            있습니다.
          </p>
          <h2>앞으로</h2>
          <p>웹 OAuth, Y2 워크스페이스, Y3 교육 콘솔. 좌석 단위 사업.</p>
        </div>
        <aside className="lp-c-panel">
          <h3>한눈에</h3>
          <dl>
            <dt>제품</dt>
            <dd>OS.neu v1.0 AI 셸</dd>
            <dt>상품</dt>
            <dd>스크린 · 심기 · USB · 웹</dd>
            <dt>앱</dt>
            <dd>Doc · Sheet · Slides · LUI</dd>
            <dt>수익</dt>
            <dd>Y2 좌석 · Y3 기관</dd>
          </dl>
          <a className="lp-btn lp-btn-purple" href="/?test=1&go=install">
            체험 시작
          </a>
        </aside>
      </div>
    </div>
  )
}
