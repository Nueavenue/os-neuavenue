import { BrandTitle } from '../components/BrandTitle'
import { ChatThread } from '../components/ChatThread'
import { LayerRail } from '../components/LayerRail'
import { BrowserGlyph } from '../components/PathGlyphs'
import { PromptDock } from '../components/PromptDock'
import { StatusBar } from '../components/StatusBar'
import { StepNav } from '../components/StepNav'
import { WEB_HOME } from '../engine/browser'
import { trackEvent } from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'
import type { ReactNode } from 'react'

export function LuiShell({ embedded = false }: { embedded?: boolean } = {}) {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const active = neu.busy
    ? (['lui', 'vlm', 'orchestrator', 'driver'] as const)
    : (['lui'] as const)
  const apps: Array<{ id: string; label: string; icon: ReactNode; run: () => void }> = [
    { id: 'doc', label: locale === 'ko' ? '문서' : 'Docs', icon: null, run: () => neu.openOffice('doc') },
    { id: 'sheet', label: locale === 'ko' ? '시트' : 'Sheets', icon: null, run: () => neu.openOffice('sheet') },
    { id: 'slides', label: locale === 'ko' ? '슬라이드' : 'Slides', icon: null, run: () => neu.openOffice('slides') },
    {
      id: 'web',
      label: 'daf.neu',
      icon: <BrowserGlyph />,
      // WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): a real front window
      // (Electron child / hosted-web window.open), not an in-place phase
      // flip — see openDaf() in state/store.tsx.
      run: () => neu.openDaf(WEB_HOME),
    },
  ]

  return (
    <section className={`screen lui google-home${embedded ? ' embedded' : ''}`}>
      {embedded ? null : <StatusBar />}
      <LayerRail active={[...active]} onOpen={() => neu.go('studio')} />
      <div className="lui-main google bolt-spacing">
        <div className="lui-copy">
          <BrandTitle as="h2" wave />
          <p>{copy.askHint}</p>
        </div>
        <ChatThread
          turns={neu.chats.slice(-12)}
          empty={
            locale === 'ko'
              ? '가운데 칸에 적거나, 오른쪽 마이크로 말하면 내 말이 오른쪽에 나타납니다.'
              : 'Type in the box, or tap the mic. Your line appears on the right.'
          }
        />
        <PromptDock onSubmit={(text, opts) => void neu.submit(text, opts)} hideThread />
        <div className="office-shortcuts">
          {apps.map((app) => (
            <button
              key={app.id}
              type="button"
              className={`office-shortcut${app.id === 'web' ? ' is-browser' : ''}`}
              onClick={() => {
                void trackEvent('click', 'lui', app.id)
                app.run()
              }}
            >
              {app.icon ? <span className="office-shortcut-icon">{app.icon}</span> : null}
              {app.label}
            </button>
          ))}
        </div>
        <div className="chips">
          {copy.chips.map((item) => (
            <button
              key={item}
              type="button"
              className="chip"
              onClick={() => {
                void trackEvent('click', 'lui', item)
                void neu.submit(item)
              }}
            >
              {item}
            </button>
          ))}
        </div>
        {embedded ? null : <StepNav onBack={() => neu.go('announce')} />}
      </div>
    </section>
  )
}
