import { StatusBar } from '../components/StatusBar'
import { HardwarePost } from './HardwarePost'
import { InstallGate } from './InstallGate'
import { LuiShell } from './LuiShell'

/**
 * WO-UI-NEU-ONE-PAGE-LANDING-121 — one scroll landing.
 *
 * Same face on hosted web, desktop plant, and the os.neu app: stacks the
 * four blocks Leader named instead of gating them behind splash→install→
 * post→lui as separate Next-only screens. Blocks 2–4 reuse the existing
 * `InstallGate` / `HardwarePost` / `LuiShell` screens verbatim via their
 * `embedded` prop (suppresses each screen's own StatusBar + StepNav only —
 * no other markup, copy, or logic changed) so their card actions (Plant /
 * USB / hardware check / the one-box + mic) keep running the same code.
 *
 * WO-UI-NEU-LANDING-FIRST-PAINT-121: Block 1 is Leader's Korean head+sub
 * in every locale (Q2 BLOCK1-KO-UNTIL-EN) — no invented English fallback.
 */
export function OnePageLanding() {
  return (
    <section className="screen one-page-landing">
      <StatusBar />
      <div className="one-page-scroll">
        <div className="install-copy landing-hero">
          <h2>OS의 한계를 넘어, 당신의 PC에 장착되는 단 하나의 AI 브라우저 운영체제</h2>
          <p>
            운영체제에 종속되지 않는 독립적인 메타 환경 os.neu 그 위에서 구동되는 daf.neu 브라우저로 오피스
            환경(워드, PPT, 엑셀 문서 호환)되는 환경에서 편집하고 당신이 원하는 LLM을 자유롭게 연결해 완벽한
            온/오프라인 AI 워크스페이스를 완성하세요
          </p>
        </div>
        <InstallGate embedded />
        <HardwarePost embedded onDone={() => undefined} />
        <LuiShell embedded />
      </div>
    </section>
  )
}
