import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { initGa4 } from './engine/ga4'

void initGa4()

const root = document.getElementById('root')
if (!root) throw new Error('os.neu root missing')

createRoot(root).render(<App />)
