import { useEffect, useRef } from 'react'
import { NeuralField } from './components/NeuralField'
import { probeNetwork } from './engine/network'
import { bootAfterSplash, phaseFromQuery, shouldRunBootTimer } from './engine/bootRoute'
import { ga4PageView, ga4SetUserId, initGa4 } from './engine/ga4'
import { useScreen } from './hooks/useScreen'
import { AdminDashboard } from './screens/AdminDashboard'
import { AnnounceScreen } from './screens/AnnounceScreen'
import { BootSplash } from './screens/BootSplash'
import { ExitDialog } from './components/ExitDialog'
import { ManualDialog } from './components/ManualDialog'
import { DownloadDialog } from './components/DownloadDialog'
import { DafPopupDialog } from './components/DafPopupDialog'
import { HardwarePost } from './screens/HardwarePost'
import { InstallGate } from './screens/InstallGate'
import { JeosLoop } from './screens/JeosLoop'
import { LandingBrowser } from './screens/LandingBrowser'
import { LayerStudio } from './screens/LayerStudio'
import { LuiShell } from './screens/LuiShell'
import { NetworkGate } from './screens/NetworkGate'
import { OnePageLanding } from './screens/OnePageLanding'
import { PlantInstall } from './screens/PlantInstall'
import { Workspace } from './screens/Workspace'
import {
  LandingPreviewA,
  LandingPreviewB,
  LandingPreviewC,
  LandingPreviewHub,
} from './screens/LandingPreviews'
import { LocaleProvider } from './i18n/LocaleContext'
import { NeuProvider, useNeu } from './state/store'

function Shell() {
  const neu = useNeu()
  const phaseRef = useRef(neu.phase)
  phaseRef.current = neu.phase
  useScreen()

  useEffect(() => {
    let cancelled = false
    void probeNetwork().then((network) => {
      if (!cancelled) neu.setNetwork(network)
    })
    const params = new URLSearchParams(window.location.search)
    if (params.get('test') === '1') {
      sessionStorage.setItem('neuos.test', '1')
    }
    const routed = phaseFromQuery(params.get('go'))
    if (routed) {
      // Secondary "new window" instances (WO-BROWSER-WINDOW-1 follow-up,
      // issue B1) route straight here with `?go=landing&openTarget=<url>` —
      // openWeb() both sets the phase and stamps a browseTarget so the
      // window opens with its requested page already loading, instead of
      // landing on a blank Home tab.
      const openTarget = params.get('openTarget')
      if (routed === 'landing' && openTarget) neu.openWeb(openTarget)
      else neu.go(routed)
      return () => {
        cancelled = true
      }
    }
    const planted = Boolean(sessionStorage.getItem('neuos.install'))
    const timer = window.setTimeout(() => {
      if (cancelled || !shouldRunBootTimer(phaseRef.current)) return
      neu.go(bootAfterSplash(planted))
    }, 1800)
    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [neu.go, neu.setNetwork])

  useEffect(() => {
    if (neu.phase !== 'landing') {
      void window.neuos?.browse?.hide()
      void window.neuos?.browse?.devtools?.(null)
    }
  }, [neu.phase])

  useEffect(() => {
    void initGa4().then(() => {
      ga4PageView(neu.phase)
    })
  }, [neu.phase])

  useEffect(() => {
    void initGa4().then(() => {
      ga4SetUserId(neu.account?.email || null)
    })
  }, [neu.account?.email])

  if (neu.screenGone) {
    return <div className="os-screen os-gone" aria-hidden />
  }

  const isPreview = neu.phase.startsWith('preview')
  const lpRoot =
    neu.phase === 'preview-a'
      ? ' lp-root-a'
      : neu.phase === 'preview-b'
        ? ' lp-root-b'
        : neu.phase === 'preview-c'
          ? ' lp-root-c'
          : neu.phase === 'preview-hub'
            ? ' lp-root-hub'
            : ''

  return (
    <div className={`os-screen${isPreview ? ` lp-root${lpRoot}` : ''}`}>
      {isPreview ? null : <NeuralField />}
      {neu.phase === 'splash' ? <BootSplash /> : null}
      {neu.phase === 'home' ? <OnePageLanding /> : null}
      {neu.phase === 'install' ? <InstallGate /> : null}
      {neu.phase === 'post' ? <HardwarePost onDone={() => neu.go('announce')} /> : null}
      {neu.phase === 'announce' ? <AnnounceScreen /> : null}
      {neu.phase === 'network' ? <NetworkGate /> : null}
      {neu.phase === 'lui' ? <LuiShell /> : null}
      {neu.phase === 'landing' ? <LandingBrowser /> : null}
      {neu.phase === 'workspace' ? <Workspace /> : null}
      {neu.phase === 'studio' ? <LayerStudio /> : null}
      {neu.phase === 'admin' ? <AdminDashboard /> : null}
      {neu.phase === 'plant' ? <PlantInstall /> : null}
      {neu.phase === 'jeos' ? <JeosLoop /> : null}
      {neu.phase === 'preview-hub' ? <LandingPreviewHub /> : null}
      {neu.phase === 'preview-a' ? <LandingPreviewA /> : null}
      {neu.phase === 'preview-b' ? <LandingPreviewB /> : null}
      {neu.phase === 'preview-c' ? <LandingPreviewC /> : null}
      {isPreview ? null : (
        <>
          <ExitDialog />
          <ManualDialog />
          <DownloadDialog />
          <DafPopupDialog />
        </>
      )}
    </div>
  )
}

export default function App() {
  return (
    <LocaleProvider>
      <NeuProvider>
        <Shell />
      </NeuProvider>
    </LocaleProvider>
  )
}
