export type BrowseRect = { x: number; y: number; width: number; height: number }

export type BrowseDownload = {
  id: string
  filename: string
  url: string
  path?: string
  mime?: string
  bytes?: number
  received?: number
  state: 'progress' | 'done' | 'failed' | 'cancelled'
  t: number
}

export type SitePopupPolicy = 'default' | 'allow' | 'block'

export type NeuosBrowse = {
  go: (url: string) => Promise<{ ok: boolean; href?: string; reason?: string; restored?: boolean }>
  hide: () => Promise<{ ok: boolean }>
  bounds: (rect: BrowseRect) => Promise<{ ok: boolean }>
  back?: () => Promise<{ ok: boolean; href?: string }>
  forward?: () => Promise<{ ok: boolean; href?: string; reason?: string }>
  reload?: () => Promise<{ ok: boolean; href?: string }>
  zoom?: (delta: 'in' | 'out' | 'reset' | number) => Promise<{ ok: boolean; zoom?: number }>
  nav?: () => Promise<{
    ok: boolean
    href?: string
    canGoBack?: boolean
    canGoForward?: boolean
    zoom?: number
  }>
  newWindow?: (url?: string) => Promise<{ ok: boolean }>
  snapshot?: () => Promise<{ ok: boolean; dataUrl?: string; href?: string; reason?: string }>
  framePolicy?: (url: string) => Promise<{ ok: boolean; blocked: boolean; reason?: string }>
  openExternal?: (url: string) => Promise<{ ok: boolean; reason?: string }>
  onDownload?: (cb: (row: BrowseDownload) => void) => () => void
  onNavigated?: (cb: (payload: { href: string; title?: string }) => void) => () => void
  onOpenTab?: (cb: (payload: { href: string }) => void) => () => void
  openDownload?: (id: string) => Promise<{ ok: boolean }>
  showDownload?: (id: string) => Promise<{ ok: boolean }>
  devtools?: (rect: BrowseRect | null) => Promise<{ ok: boolean }>
  sitePolicy?: {
    get: (url: string) => Promise<{ ok: boolean; host?: string; policy?: SitePopupPolicy }>
    set: (url: string, policy: SitePopupPolicy) => Promise<{ ok: boolean; host?: string; policy?: SitePopupPolicy }>
  }
  onPopupBlocked?: (cb: (payload: { host: string }) => void) => () => void
}

export type NeuosPlant = {
  pick: () => Promise<{ ok: boolean; path?: string }>
  defaultPath: () => Promise<{ ok: boolean; path?: string }>
}

export type NeuosFiles = {
  save: (payload: {
    defaultPath?: string
    text?: string
    bytes?: number[]
    mime?: string
    filters?: Array<{ name: string; extensions: string[] }>
  }) => Promise<{ ok: boolean; path?: string; reason?: string }>
}

export type NeuosAuth = {
  onOAuth?: (cb: (payload: { token: string; handoff?: string }) => void) => () => void
}

declare global {
  interface Window {
    neuos?: {
      browse: NeuosBrowse
      auth?: NeuosAuth
      plant?: NeuosPlant
      files?: NeuosFiles
      quit?: () => Promise<{ ok: boolean }>
      setFullscreen?: (on: boolean) => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      windowState?: () => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      windowMode?: () => Promise<{ ok: boolean; fullscreen?: boolean; maximized?: boolean }>
      setWindowMode?: (mode: 'windowed' | 'maximized' | 'fullscreen') => Promise<{
        ok: boolean
        fullscreen?: boolean
        maximized?: boolean
      }>
    }
  }
}

export {}
