import { useEffect, useState } from 'react'
import type { SitePopupPolicy } from '../neuos'

// WO-UI-NEU-DAF-BLANK-POPUP-121 / UI-B26 AMEND: the per-site pop-up service
// (Default / Allow this site / Block this site). Opened from the
// address-bar click/focus, and reused (auto-opened) when a Block choice
// actually denies a `window.open`. Default already lets identity pop-ups
// through in the main process (see `electron/main.cjs` `isIdpHost`) — this
// panel never offers a global "allow all pop-ups" switch (GUIDE-DAF-POPUP-
// SITE-POLICY-2026-09-16).
type SitePolicyPanelProps = {
  host: string
  ko: boolean
  onClose: () => void
}

const ORIGIN_FOR = (host: string) => `https://${host}/`

export function SitePolicyPanel({ host, ko, onClose }: SitePolicyPanelProps) {
  const [policy, setPolicyState] = useState<SitePopupPolicy>('default')
  const [busy, setBusy] = useState(true)

  useEffect(() => {
    let cancelled = false
    setBusy(true)
    const get = window.neuos?.browse?.sitePolicy?.get
    if (!get || !host) {
      setBusy(false)
      return
    }
    void get(ORIGIN_FOR(host))
      .then((res) => {
        if (cancelled) return
        setPolicyState(res?.ok && res.policy ? res.policy : 'default')
      })
      .catch(() => {
        if (!cancelled) setPolicyState('default')
      })
      .finally(() => {
        if (!cancelled) setBusy(false)
      })
    return () => {
      cancelled = true
    }
  }, [host])

  const choose = (next: SitePopupPolicy) => {
    setPolicyState(next)
    void window.neuos?.browse?.sitePolicy?.set?.(ORIGIN_FOR(host), next)
  }

  return (
    <div className="site-policy-panel">
      <div className="site-policy-head">
        <b>{host}</b>
        <button type="button" className="icon-btn" aria-label="Close" onClick={onClose}>
          ×
        </button>
      </div>
      <p className="site-policy-label">{ko ? '팝업' : 'Pop-ups'}</p>
      <div className="site-policy-choices" role="radiogroup" aria-label={ko ? '팝업 정책' : 'Pop-up policy'}>
        <button
          type="button"
          role="radio"
          aria-checked={policy === 'default'}
          className={`site-policy-choice${policy === 'default' ? ' on' : ''}`}
          disabled={busy}
          onClick={() => choose('default')}
        >
          Default
        </button>
        <button
          type="button"
          role="radio"
          aria-checked={policy === 'allow'}
          className={`site-policy-choice${policy === 'allow' ? ' on' : ''}`}
          disabled={busy}
          onClick={() => choose('allow')}
        >
          {ko ? '이 사이트 허용' : 'Allow this site'}
        </button>
        <button
          type="button"
          role="radio"
          aria-checked={policy === 'block'}
          className={`site-policy-choice${policy === 'block' ? ' on' : ''}`}
          disabled={busy}
          onClick={() => choose('block')}
        >
          {ko ? '이 사이트 차단' : 'Block this site'}
        </button>
      </div>
      <p className="site-policy-guide">
        {ko
          ? 'Default는 이미 본인인증 팝업을 허용합니다. Block은 이 사이트만 막습니다.'
          : 'Default already allows identity popups; Block stops this site only.'}
      </p>
    </div>
  )
}
