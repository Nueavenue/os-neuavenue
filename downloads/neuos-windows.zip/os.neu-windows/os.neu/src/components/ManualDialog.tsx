import { useEffect, useState, type MouseEvent } from 'react'
import { HostGlyph, UsbGlyph, GuestGlyph } from './PathGlyphs'
import { DOCS_HOME, fetchManualMarkdown, markdownToHtml } from '../engine/manualMd'
import { frameForDocsDest, resolveDocsLink } from '../engine/docsLinks'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

type ManualPane = 'intro' | 'manual' | 'frame'

export function ManualDialog() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const ko = locale === 'ko'
  const [pane, setPane] = useState<ManualPane>('intro')
  const [frameHref, setFrameHref] = useState('')
  const [frameTitle, setFrameTitle] = useState('')
  const [docHtml, setDocHtml] = useState('')
  const [docError, setDocError] = useState(false)
  const [docLoading, setDocLoading] = useState(false)

  useEffect(() => {
    if (!neu.manualOpen) {
      setPane('intro')
      setFrameHref('')
      setFrameTitle('')
      setDocHtml('')
      setDocError(false)
      setDocLoading(false)
    }
  }, [neu.manualOpen])

  useEffect(() => {
    if (!neu.manualOpen || pane !== 'manual') return
    let cancelled = false
    setDocLoading(true)
    setDocError(false)
    void fetchManualMarkdown('en').then((text) => {
      if (cancelled) return
      setDocLoading(false)
      if (!text) {
        setDocError(true)
        setDocHtml('')
        return
      }
      setDocHtml(markdownToHtml(text))
    })
    return () => {
      cancelled = true
    }
  }, [neu.manualOpen, pane])

  if (!neu.manualOpen) return null

  const goBack = () => {
    if (pane === 'frame') {
      setPane('manual')
      setFrameHref('')
      return
    }
    if (pane === 'manual') {
      setPane('intro')
      return
    }
    neu.closeManual()
  }

  const openResolved = (href: string) => {
    const dest = resolveDocsLink(href, window.location.origin)
    if (!dest) {
      window.open(href, '_blank', 'noopener,noreferrer')
      return
    }
    if (dest.kind === 'download') {
      window.open(dest.href, '_blank', 'noopener,noreferrer')
      return
    }
    if (dest.kind === 'manual') {
      setPane('manual')
      return
    }
    const titles: Record<string, { ko: string; en: string }> = {
      'docs-home': { ko: '문서 홈', en: 'Docs home' },
      tutorial: { ko: 'USB 복구', en: 'USB recovery' },
      'public-home': { ko: '공개 홈', en: 'Public home' },
    }
    const label = titles[dest.kind]
    setFrameTitle(label ? (ko ? label.ko : label.en) : dest.kind)
    setFrameHref(frameForDocsDest(dest, locale))
    setPane('frame')
  }

  const onDocClick = (event: MouseEvent<HTMLDivElement>) => {
    const a = (event.target as HTMLElement | null)?.closest?.('a')
    if (!a) return
    const href = a.getAttribute('href') || a.href
    if (!href) return
    const dest = resolveDocsLink(href, window.location.origin)
    if (!dest) return
    event.preventDefault()
    openResolved(href)
  }

  const title =
    pane === 'manual'
      ? 'OS.neu tutorial'
      : pane === 'frame'
        ? frameTitle
        : ko
          ? 'os.neu 매뉴얼'
          : 'os.neu manual'

  const backLabel = pane === 'intro' ? (ko ? '닫기' : 'Close') : ko ? '뒤로' : 'Back'

  return (
    <div
      className="manual-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="manual-title"
      onClick={goBack}
    >
      <div className={`manual-card${pane !== 'intro' ? ' manual-doc' : ''}`} onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="manual-title">{title}</h2>
          <div className="manual-head-actions">
            {pane !== 'intro' ? (
              <button type="button" className="docs-back" onClick={goBack} aria-label={backLabel} title={backLabel}>
                {ko ? '← 뒤로' : '← Back'}
              </button>
            ) : null}
            <button
              type="button"
              className="exit-x"
              onClick={pane === 'intro' ? () => neu.closeManual() : goBack}
              aria-label={pane === 'intro' ? (ko ? '닫기' : 'Close') : backLabel}
              title={pane === 'intro' ? (ko ? '닫기' : 'Close') : backLabel}
            >
              ×
            </button>
          </div>
        </div>
        {pane === 'manual' ? (
          <div className="manual-doc-body">
            {docLoading ? <p>{ko ? '문서를 불러오는 중…' : 'Loading…'}</p> : null}
            {docError ? (
              <p>
                {ko ? '문서를 열 수 없습니다. ' : 'Could not load the document. '}
                <a href={DOCS_HOME} onClick={(event) => {
                  event.preventDefault()
                  openResolved(DOCS_HOME)
                }}>
                  {DOCS_HOME.replace('https://', '')}
                </a>
              </p>
            ) : null}
            {docHtml ? (
              <div className="manual-md" dangerouslySetInnerHTML={{ __html: docHtml }} onClick={onDocClick} />
            ) : null}
          </div>
        ) : pane === 'frame' ? (
          <div className="manual-doc-body manual-frame-wrap">
            <iframe className="manual-frame" title={frameTitle} src={frameHref} />
          </div>
        ) : (
          <>
            <p>
              {ko
                ? '받은 뒤 Linux에서 세 길 중 하나로 설치하고, 한 줄로 말합니다. 디스크는 지우지 않습니다. Windows·macOS 설치 파일은 아직 없습니다.'
                : 'Download, then install on Linux — one of three paths — and speak one line. The disk is not wiped. There is no Windows or macOS installer yet.'}
            </p>
            <ul className="manual-list">
              <li>
                <span className="path-glyph">
                  <HostGlyph />
                </span>
                <div>
                  <b>{copy.installHost}</b>
                  <span>
                    {ko
                      ? 'Linux에서 이 길을 고르거나, 상단 다운로드로 Linux 팩을 받습니다. 설치 후 앱·바탕화면 아이콘으로 엽니다. 포맷 없음.'
                      : 'On Linux, pick this path, or use the top Download for the Linux pack. After install, click the os.neu icon. No format.'}
                  </span>
                </div>
              </li>
              <li>
                <span className="path-glyph">
                  <UsbGlyph />
                </span>
                <div>
                  <b>{copy.installUsb}</b>
                  <span>
                    {ko
                      ? 'Linux에서 키트를 받아 확인한 명령으로만 굽습니다. 재시작 후 F8(ASUS)에서 UEFI USB.'
                      : 'On Linux, download the kit and burn only after you confirm. Reboot, F8 (ASUS), UEFI USB.'}
                  </span>
                </div>
              </li>
              <li>
                <span className="path-glyph">
                  <GuestGlyph />
                </span>
                <div>
                  <b>{copy.installGuest}</b>
                  <span>
                    {ko
                      ? '설치 없이 이 세션만 봅니다. 이 PC에 남기려면 Linux가 필요합니다.'
                      : 'Look at this session without installing. To keep it on this PC you need Linux.'}
                  </span>
                </div>
              </li>
            </ul>
            <p>
              {ko
                ? '말한 뒤 마이크를 다시 누르거나, 한 줄을 적고 스피커로 보냅니다. 랜딩에서 오른쪽 위 × 는 Ubuntu로 종료입니다.'
                : 'Tap the mic, speak, tap again — or type one line and send with the speaker. On the landing, top-right × quits to Ubuntu.'}
            </p>
            <p className="manual-foot">
              <button type="button" className="manual-docs-link" onClick={() => setPane('manual')}>
                docs.neuavenue.com
              </button>
            </p>
          </>
        )}
      </div>
    </div>
  )
}
