import { useState } from 'react'
import type { BookmarkFolder, BookmarkItem } from '../engine/bookmarks'

type BookmarksManagerDialogProps = {
  open: boolean
  folders: BookmarkFolder[]
  items: BookmarkItem[]
  ko: boolean
  onClose: () => void
  onOpen: (url: string) => void
  onAddFolder: (title: string) => void
  onRenameFolder: (id: string, title: string) => void
  onDeleteFolder: (id: string) => void
  onEditBookmark: (id: string, patch: { title: string; url: string }) => void
  onDeleteBookmark: (id: string) => void
  onMoveBookmark: (id: string, folderId: string | null) => void
  onAddBookmark: (url: string, title: string, folderId: string | null) => void
}

/**
 * Dedicated bookmarks manager (Leader ask, WO-BROWSER-SESSION-1 follow-up):
 * a Windows-Explorer-style tree of folders + bookmarks, with rename/delete
 * for folders and edit/delete/move-to-folder for bookmarks, plus the
 * "New folder" affordance the small ★ flyout has no room for.
 */
export function BookmarksManagerDialog(props: BookmarksManagerDialogProps) {
  const {
    open,
    folders,
    items,
    ko,
    onClose,
    onOpen,
    onAddFolder,
    onRenameFolder,
    onDeleteFolder,
    onEditBookmark,
    onDeleteBookmark,
    onMoveBookmark,
    onAddBookmark,
  } = props
  const [newFolderTitle, setNewFolderTitle] = useState('')
  const [renameId, setRenameId] = useState<string | null>(null)
  const [renameDraft, setRenameDraft] = useState('')
  const [editId, setEditId] = useState<string | null>(null)
  const [editDraft, setEditDraft] = useState({ title: '', url: '' })
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [addTitle, setAddTitle] = useState('')
  const [addUrl, setAddUrl] = useState('')
  const [addFolderId, setAddFolderId] = useState('')

  if (!open) return null

  const sortedFolders = [...folders].sort((a, b) => a.order - b.order)
  const rootItems = items.filter((it) => !it.folderId)
  const itemsIn = (folderId: string) => items.filter((it) => it.folderId === folderId)
  const allIds = items.map((it) => it.id)

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const toggleAll = () => {
    setSelected((prev) => (prev.size === allIds.length ? new Set() : new Set(allIds)))
  }

  const deleteSelected = () => {
    selected.forEach((id) => onDeleteBookmark(id))
    setSelected(new Set())
  }

  const renderItemRow = (item: BookmarkItem) =>
    editId === item.id ? (
      <form
        key={item.id}
        className="browser-edit bm-manager-edit"
        onSubmit={(event) => {
          event.preventDefault()
          onEditBookmark(item.id, editDraft)
          setEditId(null)
        }}
      >
        <input value={editDraft.title} onChange={(e) => setEditDraft({ ...editDraft, title: e.target.value })} />
        <input value={editDraft.url} onChange={(e) => setEditDraft({ ...editDraft, url: e.target.value })} />
        <button type="submit" className="btn">
          {ko ? '저장' : 'Save'}
        </button>
        <button type="button" className="btn ghost" onClick={() => setEditId(null)}>
          {ko ? '취소' : 'Cancel'}
        </button>
      </form>
    ) : (
      <div key={item.id} className="browser-row bm-manager-row">
        <input
          type="checkbox"
          className="browser-row-check"
          aria-label={ko ? '선택' : 'Select'}
          checked={selected.has(item.id)}
          onChange={() => toggleOne(item.id)}
        />
        <button type="button" className="browser-row-main" onClick={() => onOpen(item.url)}>
          <strong>{item.title}</strong>
          <span>{item.url}</span>
        </button>
        <select
          aria-label={ko ? '폴더로 이동' : 'Move to folder'}
          value={item.folderId ?? ''}
          onChange={(e) => onMoveBookmark(item.id, e.target.value || null)}
          className="bm-manager-move"
        >
          <option value="">{ko ? '(폴더 없음)' : '(No folder)'}</option>
          {sortedFolders.map((f) => (
            <option key={f.id} value={f.id}>
              {f.title}
            </option>
          ))}
        </select>
        <button
          type="button"
          className="icon-btn"
          aria-label={ko ? '수정' : 'Edit'}
          title={ko ? '수정' : 'Edit'}
          onClick={() => {
            setEditId(item.id)
            setEditDraft({ title: item.title, url: item.url })
          }}
        >
          ✎
        </button>
        <button
          type="button"
          className="icon-btn"
          aria-label={ko ? '삭제' : 'Delete'}
          title={ko ? '삭제' : 'Delete'}
          onClick={() => onDeleteBookmark(item.id)}
        >
          ×
        </button>
      </div>
    )

  return (
    <div className="manual-overlay" role="dialog" aria-modal="true" aria-labelledby="bm-manager-title" onClick={onClose}>
      <div className="manual-card manual-doc bm-manager-card" onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="bm-manager-title">{ko ? '북마크 관리자' : 'Bookmarks manager'}</h2>
          <button type="button" className="exit-x" onClick={onClose} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </div>
        <form
          className="bm-manager-add-bookmark"
          onSubmit={(event) => {
            event.preventDefault()
            const url = addUrl.trim()
            if (!url) return
            onAddBookmark(url, addTitle.trim() || url, addFolderId || null)
            setAddTitle('')
            setAddUrl('')
          }}
        >
          <input value={addTitle} onChange={(e) => setAddTitle(e.target.value)} placeholder={ko ? '이름' : 'Name'} />
          <input value={addUrl} onChange={(e) => setAddUrl(e.target.value)} placeholder={ko ? '주소' : 'URL'} />
          <select
            aria-label={ko ? '폴더 선택' : 'Folder'}
            value={addFolderId}
            onChange={(e) => setAddFolderId(e.target.value)}
            className="bm-folder-select"
          >
            <option value="">{ko ? '(폴더 없음)' : '(No folder)'}</option>
            {sortedFolders.map((f) => (
              <option key={f.id} value={f.id}>
                {f.title}
              </option>
            ))}
          </select>
          <button type="submit" className="btn">
            {ko ? '추가' : 'Add'}
          </button>
        </form>
        <form
          className="bm-manager-new-folder"
          onSubmit={(event) => {
            event.preventDefault()
            const title = newFolderTitle.trim()
            if (!title) return
            onAddFolder(title)
            setNewFolderTitle('')
          }}
        >
          <input
            value={newFolderTitle}
            onChange={(e) => setNewFolderTitle(e.target.value)}
            placeholder={ko ? '새 폴더 이름' : 'New folder name'}
          />
          <button type="submit" className="btn">
            {ko ? '폴더 추가' : 'Add folder'}
          </button>
        </form>
        {allIds.length ? (
          <div className="browser-bulk-bar">
            <label className="browser-bulk-all">
              <input
                type="checkbox"
                checked={selected.size > 0 && selected.size === allIds.length}
                onChange={toggleAll}
              />
              {ko ? '전체 선택' : 'Select all'}
            </label>
            <button type="button" className="btn ghost browser-bulk-delete" disabled={!selected.size} onClick={deleteSelected}>
              {ko ? `선택 삭제 (${selected.size})` : `Delete selected (${selected.size})`}
            </button>
          </div>
        ) : null}
        <div className="manual-doc-body bm-manager-body">
          {sortedFolders.map((folder) => (
            <div key={folder.id} className="bm-manager-folder">
              <div className="bm-manager-folder-head">
                {renameId === folder.id ? (
                  <form
                    className="bm-manager-rename"
                    onSubmit={(event) => {
                      event.preventDefault()
                      const title = renameDraft.trim()
                      if (title) onRenameFolder(folder.id, title)
                      setRenameId(null)
                    }}
                  >
                    <input value={renameDraft} onChange={(e) => setRenameDraft(e.target.value)} autoFocus />
                    <button type="submit" className="btn">
                      {ko ? '저장' : 'Save'}
                    </button>
                  </form>
                ) : (
                  <>
                    <span className="bm-manager-folder-icon" aria-hidden>
                      📁
                    </span>
                    <b>{folder.title}</b>
                    <span className="dock-hint">({itemsIn(folder.id).length})</span>
                    <span className="bm-manager-folder-actions">
                      <button
                        type="button"
                        className="icon-btn"
                        aria-label={ko ? '이름 바꾸기' : 'Rename'}
                        title={ko ? '이름 바꾸기' : 'Rename'}
                        onClick={() => {
                          setRenameId(folder.id)
                          setRenameDraft(folder.title)
                        }}
                      >
                        ✎
                      </button>
                      <button
                        type="button"
                        className="icon-btn"
                        aria-label={ko ? '폴더 삭제' : 'Delete folder'}
                        title={ko ? '폴더 삭제 (북마크는 유지됨)' : 'Delete folder (keeps bookmarks)'}
                        onClick={() => onDeleteFolder(folder.id)}
                      >
                        ×
                      </button>
                    </span>
                  </>
                )}
              </div>
              <div className="bm-manager-folder-body">
                {itemsIn(folder.id).length ? (
                  itemsIn(folder.id).map(renderItemRow)
                ) : (
                  <p className="dock-hint">{ko ? '이 폴더는 비어 있습니다.' : 'This folder is empty.'}</p>
                )}
              </div>
            </div>
          ))}

          <div className="bm-manager-folder bm-manager-root">
            <div className="bm-manager-folder-head">
              <span className="bm-manager-folder-icon" aria-hidden>
                ★
              </span>
              <b>{ko ? '폴더 없음' : 'No folder'}</b>
              <span className="dock-hint">({rootItems.length})</span>
            </div>
            <div className="bm-manager-folder-body">
              {rootItems.length ? (
                rootItems.map(renderItemRow)
              ) : (
                <p className="dock-hint">{ko ? '북마크가 없습니다.' : 'No bookmarks yet.'}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
