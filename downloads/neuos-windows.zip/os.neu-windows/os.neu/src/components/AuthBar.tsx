import { createPortal } from 'react-dom'
import { useEffect, useState, type ReactNode } from 'react'
import {
  loginRequest,
  logoutRequest,
  registerRequest,
  sendFeedback,
  startGoogleOAuth,
  waitForGoogleHandoff,
  trackEvent,
  type AuthUser,
} from '../engine/auth'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function AuthBar() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const open = neu.authPanel
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [hint, setHint] = useState('')
  const [mode, setMode] = useState<'login' | 'create'>('login')
  const [supabaseOn, setSupabaseOn] = useState(false)

  useEffect(() => {
    void fetch('/api/health')
      .then((r) => r.json())
      .then((row: { supabase?: boolean }) => setSupabaseOn(Boolean(row.supabase)))
      .catch(() => setSupabaseOn(false))
  }, [open])

  const resetForm = () => {
    setName('')
    setEmail('')
    setPassword('')
    setTitle('')
    setBody('')
    setHint('')
    setMode('login')
  }

  const closePanel = () => {
    resetForm()
    neu.setAuthPanel('none')
  }

  const cancel = () => {
    closePanel()
  }

  const finishAuth = (user: AuthUser) => {
    neu.setAccount(user)
    void trackEvent('login', neu.phase, user.email)
    resetForm()
    neu.setAuthPanel('none')
  }

  const login = async () => {
    const result = await loginRequest(email, password)
    if (result.ok && result.user) finishAuth(result.user)
    else
      setHint(
        ko
          ? 'os.neu 이메일/비밀번호가 맞지 않습니다. (Gmail 비밀번호를 여기에 넣어도 Google 로그인이 되지 않습니다.)'
          : 'os.neu email/password is wrong. (A Gmail password here does not sign you into Google.)',
      )
  }

  const create = async () => {
    const result = await registerRequest(name, email, password)
    if (result.needsConfirm) {
      setHint(ko ? '메일함에서 계정을 확인해 주세요.' : 'Check your email to confirm the account.')
      return
    }
    if (result.ok && result.user) finishAuth(result.user)
    else if (result.reason === 'email-taken') setHint(ko ? '이미 있는 이메일입니다.' : 'Email already used.')
    else if (result.reason === 'weak-password') setHint(ko ? '비밀번호는 6자 이상이어야 합니다.' : 'Password must be 6 or more characters.')
    else setHint(ko ? '이름, 이메일, 비밀번호를 적어 주세요.' : 'Name, email, and password are required.')
  }

  const logout = async () => {
    void trackEvent('logout', neu.phase, neu.account?.email)
    await logoutRequest()
    neu.setAccount(null)
  }

  const continueWithGoogle = async () => {
    if (!supabaseOn) {
      setHint(
        ko
          ? 'Google OAuth는 Supabase 설정이 필요합니다. %USERPROFILE%\\os.neu\\.env 에 PUBLIC_SUPABASE_URL 과 PUBLIC_SUPABASE_ANON_KEY 를 넣고 os.neu 를 완전히 종료한 뒤 바로가기로 다시 실행하세요.'
          : 'Google OAuth needs Supabase. Add PUBLIC_SUPABASE_URL and PUBLIC_SUPABASE_ANON_KEY to %USERPROFILE%\\os.neu\\.env, fully quit os.neu, then launch again from the shortcut.',
      )
      return
    }
    setHint(
      ko
        ? '시스템 Chrome에서 Google 로그인을 엽니다. os.neu 창은 그대로 둡니다…'
        : 'Opening Google in system Chrome. The os.neu window stays open…',
    )
    const result = await startGoogleOAuth()
    if (!result.ok) {
      setHint(
        result.reason === 'supabase-off'
          ? ko
            ? 'Supabase가 꺼져 있습니다. 브리지 .env 의 PUBLIC_SUPABASE_* 를 확인하세요.'
            : 'Supabase is off. Check PUBLIC_SUPABASE_* in the bridge .env.'
          : result.reason === 'popup-blocked'
            ? ko
              ? '팝업이 막혔습니다. 브라우저에서 팝업을 허용한 뒤 다시 시도하세요.'
              : 'Popup blocked. Allow popups for this site, then try again.'
            : ko
              ? 'Google 연결을 시작하지 못했습니다.'
              : 'Could not start Google sign-in.',
      )
      return
    }
    setHint(
      ko
        ? 'Chrome에서 Google 로그인을 마치면 이 os.neu 창이 자동으로 로그인됩니다. Chrome 탭은 닫아도 됩니다. (os.neu 창의 X는 누르지 마세요.)'
        : 'Finish Google in Chrome — this os.neu window signs in automatically. You may close the Chrome tab. Do not close the os.neu window.',
    )
    const handoff = 'handoff' in result ? result.handoff : ''
    const user = handoff ? await waitForGoogleHandoff(handoff) : null
    if (user) {
      finishAuth(user)
      return
    }
    setHint(
      ko
        ? '아직 로그인되지 않았습니다. Chrome에서 Google 로그인을 마친 뒤 다시 시도하세요.'
        : 'Still signed out. Finish Google in Chrome, then try again.',
    )
  }

  const layer = (children: ReactNode) => (
    <div className="auth-layer" onClick={closePanel}>
      {neu.authBackdrop ? (
        <div
          className="auth-backdrop"
          style={{ backgroundImage: `url(${neu.authBackdrop})` }}
          aria-hidden
        />
      ) : null}
      <div className="auth-scrim" aria-hidden />
      {children}
    </div>
  )

  const panel =
    open === 'login' ? (
      layer(
        <div
          className="auth-modal"
          role="dialog"
          aria-labelledby="auth-title"
          onClick={(event) => event.stopPropagation()}
        >
          <h3 id="auth-title">{mode === 'login' ? (ko ? '로그인' : 'Sign in') : ko ? '계정 만들기' : 'Create account'}</h3>
          <p className="auth-lead">
            {ko
              ? '이 기기의 os.neu에 로그인합니다. Neu-Vitality 웹 계정(app.neuavenue.com)과는 별개의 로그인입니다.'
              : 'Signs into os.neu on this device — separate from your Neu-Vitality web account (app.neuavenue.com) unless Product later shares sessions.'}
          </p>
          <p className="auth-lead">
            {supabaseOn
              ? ko
                ? 'os.neu 계정은 Supabase에 연결됩니다. 아래 이메일/비밀번호는 os.neu용입니다.'
                : 'os.neu accounts use Supabase. Email/password below is for your os.neu account.'
              : ko
                ? '지금 브리지는 이 기기에만 저장되는 로컬 계정입니다(통합 계정 아님). Supabase .env 가 있으면 재시작 후 클라우드 로그인됩니다.'
                : 'Bridge is on a device-local account (not a unified identity). With Supabase .env, restart to enable cloud sign-in.'}
          </p>
          {mode === 'create' ? <input value={name} onChange={(e) => setName(e.target.value)} placeholder={ko ? '이름' : 'Name'} /> : null}
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder={ko ? '비밀번호' : 'Password'} type="password" />
          {hint ? <p className="dock-hint">{hint}</p> : null}
          {mode === 'login' ? (
            <button type="button" className="install-card auth-id" onClick={() => void continueWithGoogle()}>
              <b>{ko ? 'Google로 계속 (OAuth)' : 'Continue with Google (OAuth)'}</b>
              <span>
                {ko
                  ? 'Google 정책상 os.neu 안(임베디드)에서는 로그인할 수 없습니다. 시스템 Chrome에서 연 뒤 osneu:// 딥링크·핸드오프로 이 창에 토큰만 가져옵니다. 일상 웹 탐색은 os.neu 브라우저를 쓰세요.'
                  : 'Google blocks login inside os.neu. System Chrome signs you in; osneu:// deep link / handoff returns only the token here. Keep using the os.neu browser for everyday browsing.'}
              </span>
            </button>
          ) : null}
          <div className="row-actions">
            <button type="button" className="btn ghost" onClick={cancel}>
              {ko ? '취소' : 'Cancel'}
            </button>
            <button type="button" className="btn" onClick={() => void (mode === 'login' ? login() : create())}>
              {mode === 'login' ? (ko ? '로그인' : 'Sign in') : ko ? '만들기' : 'Create'}
            </button>
          </div>
          <button
            type="button"
            className="text-link"
            onClick={() => {
              setHint('')
              setMode(mode === 'login' ? 'create' : 'login')
            }}
          >
            {mode === 'login' ? (ko ? '새 계정 만들기' : 'Create an account') : ko ? '이미 계정이 있습니다' : 'I already have an account'}
          </button>
        </div>,
      )
    ) : open === 'feedback' ? (
      layer(
        <div
          className="auth-modal"
          role="dialog"
          aria-labelledby="feedback-title"
          onClick={(event) => event.stopPropagation()}
        >
          <h3 id="feedback-title">{ko ? '피드백 남기기' : 'Leave feedback'}</h3>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={ko ? '제목' : 'Title'} />
          <textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={ko ? '내용' : 'Message'} rows={5} />
          {hint ? <p className="dock-hint">{hint}</p> : null}
          <div className="row-actions">
            <button type="button" className="btn ghost" onClick={closePanel}>
              {ko ? '취소' : 'Cancel'}
            </button>
            <button
              type="button"
              className="btn"
              onClick={async () => {
                try {
                  const result = await sendFeedback(title, body)
                  if (!result.ok) {
                    setHint(ko ? '제목 또는 내용을 적어 주세요.' : 'Write a title or a message.')
                    return
                  }
                  setTitle('')
                  setBody('')
                  setHint(
                    result.cloud === false
                      ? ko
                        ? '이 기기에 저장했습니다.'
                        : 'Saved on this device.'
                      : ko
                        ? '저장했습니다.'
                        : 'Saved.',
                  )
                  window.setTimeout(() => {
                    resetForm()
                    neu.setAuthPanel('none')
                  }, 700)
                } catch {
                  setHint(ko ? '저장하지 못했습니다. 다시 시도해 주세요.' : 'Could not save. Try again.')
                }
              }}
            >
              {ko ? '저장' : 'Save'}
            </button>
          </div>
        </div>,
      )
    ) : null

  return (
    <div className="auth-bar">
      {neu.account ? (
        <button type="button" className="pill" onClick={() => void logout()}>
          {neu.account.name} · {ko ? '로그아웃' : 'Sign out'}
        </button>
      ) : (
        <button
          type="button"
          className="pill"
          onClick={() => {
            resetForm()
            neu.setAuthPanel('login')
          }}
        >
          {ko ? '로그인' : 'Sign in'}
        </button>
      )}
      <button
        type="button"
        className="pill"
        onClick={() => {
          void trackEvent('click', neu.phase, 'feedback')
          resetForm()
          neu.setAuthPanel('feedback')
        }}
      >
        {ko ? '피드백' : 'Feedback'}
      </button>
      {neu.account?.admin ? (
        <button
          type="button"
          className="pill admin-pill"
          onClick={() => {
            void trackEvent('click', neu.phase, 'admin')
            neu.setAuthPanel('none')
            neu.go('admin')
          }}
        >
          Admin
        </button>
      ) : null}
      {panel ? createPortal(panel, document.body) : null}
    </div>
  )
}
