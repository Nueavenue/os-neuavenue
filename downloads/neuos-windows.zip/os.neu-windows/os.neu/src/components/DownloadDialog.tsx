import { HostGlyph } from './PathGlyphs'
import { usbKitHref } from '../engine/linuxPack'
import { detectGuestOsNow, packForGuestOs } from '../engine/detectOs'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

export function DownloadDialog() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  if (!neu.downloadOpen) return null

  const host = typeof window !== 'undefined' ? window.location.hostname : ''
  const guest = detectGuestOsNow()
  const pack = packForGuestOs(guest, host)
  const usbHref = usbKitHref(host)
  const label = { linux: 'Linux', windows: 'Windows', macos: 'macOS', chromeos: 'ChromeOS', unknown: ko ? '이 PC' : 'this PC' }[guest]
  const win = guest === 'windows'
  const primary = win
    ? ko
      ? 'Windows에서 os.neu 받기'
      : 'Download os.neu on Windows'
    : ko
      ? 'Linux 스크린 받기'
      : 'Get Linux screen'

  return (
    <div
      className="manual-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="download-title"
      onClick={neu.closeDownload}
    >
      <div className="manual-card" onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="download-title">{ko ? 'os.neu 스크린 받기' : 'Get the os.neu screen'}</h2>
          <button type="button" className="exit-x" onClick={neu.closeDownload} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </div>
        <p>
          {ko
            ? `이 브라우저는 ${label} 로 보입니다. 웹 사이트는 CPU·RAM을 읽지 않습니다. 설치 파일만 OS에 맞춰 고릅니다.`
            : `This browser looks like ${label}. The public site does not read CPU or RAM. It only picks the pack for the OS.`}
        </p>
        {pack.available ? (
          <>
            <ol className="download-steps">
              <li>
                <b>{ko ? '받기' : 'Download'}</b>
                <span>{ko ? `${pack.file} 를 이 PC에 저장합니다.` : `Save ${pack.file} on this PC.`}</span>
              </li>
              <li>
                <b>{ko ? '설치' : 'Install'}</b>
                <span>
                  {win
                    ? ko
                      ? '압축을 풀고 powershell -ExecutionPolicy Bypass -File os.neu-windows\\install-windows.ps1. %USERPROFILE%\\os.neu 와 바탕화면·시작 메뉴에 os.neu 가 생깁니다. 로그온은 -EnableLogon 일 때만.'
                      : 'Unzip, then powershell -ExecutionPolicy Bypass -File os.neu-windows\\install-windows.ps1. That plants %USERPROFILE%\\os.neu and Desktop + Start Menu os.neu. Logon only with -EnableLogon.'
                    : ko
                      ? '터미널에서 tar -xzf neuos-linux.tar.gz 다음 bash os.neu-linux/install.sh (또는 Install-os.neu.desktop). 앱 보기와 바탕화면에 os.neu 아이콘이 자동으로 심깁니다.'
                      : 'In a terminal: tar -xzf neuos-linux.tar.gz then bash os.neu-linux/install.sh (or Install-os.neu.desktop). That plants os.neu in Show Apps and on the Desktop.'}
                </span>
              </li>
              <li>
                <b>{ko ? '실행' : 'Open'}</b>
                <span>
                  {win
                    ? ko
                      ? '바탕화면 또는 시작 메뉴의 os.neu. WSL2가 아닙니다.'
                      : 'Click os.neu on the Desktop or Start Menu. That is not WSL2.'
                    : ko
                      ? '앱 보기(Show Apps) 또는 바탕화면의 os.neu 아이콘. 별도 브라우저가 아닙니다.'
                      : 'Click os.neu in Show Apps or on the Desktop. That is the app, not another browser window.'}
                </span>
              </li>
            </ol>
            <div className="download-actions">
              <a className="download-primary" href={pack.href} target="_blank" rel="noreferrer">
                <HostGlyph />
                {primary}
              </a>
              <a className="download-secondary" href={usbHref}>
                {ko ? 'USB 키트 (Linux JeOS)' : 'USB kit (Linux JeOS)'}
              </a>
            </div>
          </>
        ) : (
          <>
            <p className="install-linux-note">
              {ko
                ? `${label} 용 설치 파일은 아직 없습니다. 심기는 Linux 또는 Windows zip 입니다. macOS·ChromeOS 팩은 별도입니다. USB 키트는 Linux JeOS 입니다.`
                : `No ${label} installer ships yet. Plant packs are Linux or the Windows zip. macOS and ChromeOS need their own builds. The USB kit is Linux JeOS.`}
            </p>
            <div className="download-actions">
              <a className="download-secondary" href={usbHref}>
                {ko ? 'USB 키트 (Linux JeOS, Windows에서 굽기 가능)' : 'USB kit (Linux JeOS; burn on Windows with Rufus)'}
              </a>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
