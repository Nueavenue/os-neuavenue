import { useCallback, useEffect, useState, type CSSProperties } from 'react'
import { AppToolbar } from '../AppToolbar'
import { assistOffice } from '../../engine/office'
import { useNeu } from '../../state/store'
import { useI18n } from '../../i18n/LocaleContext'
import {
  applyAssistResult,
  bulletsFromBody,
  defaultSlide,
  parseAssistText,
  serializeRecipe,
  type RecipeSlide,
  type SlideLayout,
} from '../../engine/slidesRecipe'
import { exportSlidesToPptx, savePptxFile } from '../../engine/pptxExport'
import { PRESENTATION_TEMPLATES, getTemplateById, type PresentationTemplate } from '../../engine/presentationTemplates'
import { defaultSlideCount, planSlidesFromTemplate, parseRequestedSlideCount } from '../../engine/generationPlanner'
import {
  phaseAfterEditorExport,
  phaseAfterExportBack,
  phaseAfterGalleryCardUse,
  phaseAfterPreviewPrompt,
  phaseAfterPromptContinue,
  phaseAfterStoryboardConfirm,
  type StudioPhase,
} from '../../engine/studioPhase'
import { pushRecentTemplate } from '../../engine/pptStudioStorage'
import { themeForTemplate, themeToCssVars, themeToPptxHints } from '../../engine/presentationThemes'
import { recommendTemplates } from '../../engine/templateRecommend'
import { setTemplateLocation, templateIdFromLocation } from '../../engine/slidesStudioRoute'
import { TemplateGalleryHome, type GalleryView } from './ppt-studio/TemplateGalleryHome'
import { TemplatePreviewScreen } from './ppt-studio/TemplatePreviewScreen'
import { TemplatePromptSettings } from './ppt-studio/TemplatePromptStub'
import { TemplateStoryboardScreen } from './ppt-studio/TemplateStoryboardScreen'
import { ExportHubScreen } from './ppt-studio/ExportHubScreen'
import { OverflowWarning } from './ppt-studio/OverflowWarning'
import { fitSlide } from '../../engine/contentFitter'

const LAYOUTS: { id: SlideLayout; en: string; ko: string }[] = [
  { id: 'title', en: 'Title', ko: '제목' },
  { id: 'bullets', en: 'Bullets', ko: '목록' },
  { id: 'table', en: 'Table', ko: '표' },
]

function emptyTable() {
  return { headers: ['', ''], rows: [['', '']] }
}

export function SlidesApp() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [slides, setSlides] = useState<RecipeSlide[]>([{ layout: 'title', title: 'Title slide', body: 'Click to add notes', bullets: [], table: null }])
  const [index, setIndex] = useState(0)
  const [saved, setSaved] = useState(false)
  const [exportHint, setExportHint] = useState('')
  const [studio, setStudio] = useState<StudioPhase>('gallery')
  const [galleryView, setGalleryView] = useState<GalleryView>('home')
  const [activeTemplateId, setActiveTemplateId] = useState<string | null>(null)
  const [promptDraft, setPromptDraft] = useState('')
  const [audience, setAudience] = useState('')
  const [slideCount, setSlideCount] = useState(10)
  const [orderedTemplates, setOrderedTemplates] = useState(PRESENTATION_TEMPLATES)
  const [assistDraft, setAssistDraft] = useState('')
  const [assistBusy, setAssistBusy] = useState(false)
  const current = slides[index] || slides[0]
  const currentFit = fitSlide(current)
  const activeTemplate = activeTemplateId ? getTemplateById(activeTemplateId) : undefined
  const editorTheme = activeTemplate ? themeForTemplate(activeTemplate) : null
  const editorThemeStyle = editorTheme ? (themeToCssVars(editorTheme) as CSSProperties) : undefined

  const update = (patch: Partial<RecipeSlide>) => {
    setSlides((rows) => rows.map((slide, i) => (i === index ? { ...slide, ...patch } : slide)))
    setSaved(false)
  }

  const setLayout = (layout: SlideLayout) => {
    if (layout === 'table' && !current.table) update({ layout, table: emptyTable() })
    else update({ layout })
  }

  const openEditorWithTemplate = useCallback(
    (template: PresentationTemplate, slideCount?: number) => {
      const fromPrompt = parseRequestedSlideCount(promptDraft, template)
      setSlides(planSlidesFromTemplate(template, slideCount ?? fromPrompt))
      setIndex(0)
      setSaved(false)
      setActiveTemplateId(template.id)
      pushRecentTemplate(template.id)
      setStudio('editor')
      setTemplateLocation(template.id, 'editor')
    },
    [promptDraft],
  )

  const openTemplateDirect = (template: PresentationTemplate) => {
    setStudio(phaseAfterGalleryCardUse())
    openEditorWithTemplate(template)
  }

  const openPreview = (template: PresentationTemplate) => {
    setActiveTemplateId(template.id)
    setStudio('preview')
    setTemplateLocation(template.id, 'preview')
  }

  useEffect(() => {
    const id = templateIdFromLocation()
    if (!id) return
    const t = getTemplateById(id)
    if (!t) return
    setActiveTemplateId(id)
    setStudio('preview')
  }, [])

  const runAssist = async (instruction: string) => {
    const result = await assistOffice({
      model: neu.officeModel,
      app: 'slides',
      instruction,
      content: JSON.stringify(serializeRecipe(undefined, slides)),
    })
    if (result.ok && result.text) {
      const recipe = parseAssistText(result.text)
      const next = applyAssistResult(slides, index, instruction, recipe.slides)
      setSlides(next.slides)
      setIndex(next.index)
    }
  }

  const downloadPptx = async () => {
    const recipe = serializeRecipe(current.title || undefined, slides)
    const bytes = exportSlidesToPptx(recipe, new Date(), editorTheme ? themeToPptxHints(editorTheme) : undefined)
    const result = await savePptxFile(bytes, recipe.title || slides[0]?.title || 'slides')
    setExportHint(result.ok ? (ko ? 'PPTX 내보냈습니다.' : 'Exported PPTX.') : ko ? '내보내기를 취소했습니다.' : 'Export cancelled.')
    window.setTimeout(() => setExportHint(''), 3000)
  }

  const handleDiscover = async (query: string) => {
    setPromptDraft(query)
    const ranked = await recommendTemplates(query, neu.officeModel)
    setOrderedTemplates(ranked)
  }

  const handleNav = (id: 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant') => {
    if (id === 'my-templates') setGalleryView('my-templates')
    else if (id === 'recent') setGalleryView('recent')
    else setGalleryView('home')
    setStudio('gallery')
    setTemplateLocation(null, 'gallery')
  }

  if (studio === 'gallery') {
    return (
      <TemplateGalleryHome
        ko={ko}
        galleryView={galleryView}
        onGalleryView={setGalleryView}
        onNav={handleNav}
        orderedTemplates={orderedTemplates}
        onDiscover={handleDiscover}
        onSelectTemplate={openTemplateDirect}
        onPreviewTemplate={openPreview}
      />
    )
  }

  if (studio === 'preview' && activeTemplate) {
    return (
      <TemplatePreviewScreen
        template={activeTemplate}
        ko={ko}
        onBack={() => {
          setStudio('gallery')
          setTemplateLocation(null, 'gallery')
        }}
        onUse={() => openEditorWithTemplate(activeTemplate)}
        onPromptStep={() => {
          setSlideCount(defaultSlideCount(activeTemplate))
          setStudio(phaseAfterPreviewPrompt())
        }}
      />
    )
  }

  if (studio === 'prompt' && activeTemplate) {
    return (
      <TemplatePromptSettings
        template={activeTemplate}
        ko={ko}
        audience={audience}
        onAudience={setAudience}
        slideCount={slideCount}
        onSlideCount={setSlideCount}
        prompt={promptDraft}
        onPrompt={setPromptDraft}
        onBack={() => setStudio('preview')}
        onContinue={() => setStudio(phaseAfterPromptContinue())}
      />
    )
  }

  if (studio === 'storyboard' && activeTemplate) {
    return (
      <TemplateStoryboardScreen
        template={activeTemplate}
        ko={ko}
        slideCount={slideCount}
        audience={audience}
        prompt={promptDraft}
        onBack={() => setStudio('prompt')}
        onConfirm={() => {
          setStudio(phaseAfterStoryboardConfirm())
          openEditorWithTemplate(activeTemplate, slideCount)
        }}
      />
    )
  }

  if (studio === 'export') {
    return (
      <ExportHubScreen
        template={activeTemplate}
        slides={slides}
        ko={ko}
        exportHint={exportHint}
        onBack={() => setStudio(phaseAfterExportBack())}
        onDownload={downloadPptx}
      />
    )
  }

  const editor = (
    <div className="slides-app ppt-s5-shell" data-ui="s5-editor-shell">
      <div className="ppt-s5-template-bar" data-ui="template-dialog">
        <button
          type="button"
          onClick={() => {
            setStudio('gallery')
            setTemplateLocation(null, 'gallery')
          }}
        >
          {ko ? '템플릿' : 'Templates'}
        </button>
        <strong>
          {activeTemplate ? (ko ? activeTemplate.nameKo : activeTemplate.name) : ko ? '이름 없는 덱' : 'Untitled deck'}
        </strong>
        <span>
          {slides.length} {ko ? '장' : 'slides'}
          {activeTemplate ? ` · ${activeTemplate.category}` : ''}
        </span>
      </div>
      <AppToolbar
        title={current.title || 'Slides'}
        saved={saved}
        onSave={() => setSaved(true)}
        onAssist={runAssist}
        extra={
          <>
            <button
              type="button"
              className="icon-btn"
              onClick={() => {
                setSlides((rows) => [...rows, defaultSlide(rows.length)])
                setIndex(slides.length)
              }}
              aria-label={ko ? '슬라이드 추가' : 'Add slide'}
              title={ko ? '슬라이드 추가' : 'Add slide'}
            >
              +
            </button>
            <button
              type="button"
              className="icon-btn"
              data-ui="export-hub"
              onClick={() => setStudio(phaseAfterEditorExport())}
              title={ko ? '내보내기 허브' : 'Export hub'}
            >
              {ko ? '내보내기' : 'Export'}
            </button>
            <button
              type="button"
              className="icon-btn"
              data-ui="export-pptx"
              onClick={downloadPptx}
              title={ko ? 'PPTX보내기' : 'Export PPTX'}
            >
              {ko ? 'PPTX보내기' : 'Export PPTX'}
            </button>
          </>
        }
      />
      {exportHint ? <div className="slides-export-hint">{exportHint}</div> : null}
      <OverflowWarning result={currentFit} ko={ko} />
      <div className="slides-stage ppt-s5-body">
        <aside className="slides-rail ppt-s5-filmstrip" data-ui="s5-filmstrip">
          {slides.map((slide, i) => {
            const overflow = fitSlide(slide).overflow
            return (
              <button
                key={i}
                type="button"
                className={i === index ? 'on' : ''}
                data-overflow={overflow ? 'true' : undefined}
                onClick={() => setIndex(i)}
              >
                {i + 1}. {slide.title || 'Slide'}
                {overflow ? ' · !' : ''}
              </button>
            )
          })}
        </aside>
        <div className="slide-canvas ppt-editor-themed" style={editorThemeStyle}>
          <div className="slide-layout-row">
            {LAYOUTS.map((l) => (
              <button
                key={l.id}
                type="button"
                className={`layout-pick${current.layout === l.id ? ' on' : ''}`}
                onClick={() => setLayout(l.id)}
              >
                {ko ? l.ko : l.en}
              </button>
            ))}
          </div>
          <input value={current.title} onChange={(e) => update({ title: e.target.value })} aria-label="Slide title" />

          {current.layout === 'table' ? (
            <div className="slide-table-editor">
              <table>
                <thead>
                  <tr>
                    {current.table?.headers.map((h, ci) => (
                      <th key={ci}>
                        <input
                          value={h}
                          onChange={(e) => {
                            const headers = [...(current.table?.headers || [])]
                            headers[ci] = e.target.value
                            update({ table: { headers, rows: current.table?.rows || [] } })
                          }}
                          aria-label={`Header ${ci + 1}`}
                        />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(current.table?.rows || []).map((row, ri) => (
                    <tr key={ri}>
                      {(current.table?.headers || []).map((_, ci) => (
                        <td key={ci}>
                          <input
                            value={row[ci] || ''}
                            onChange={(e) => {
                              const rows = (current.table?.rows || []).map((r) => [...r])
                              rows[ri][ci] = e.target.value
                              update({ table: { headers: current.table?.headers || [], rows } })
                            }}
                            aria-label={`Row ${ri + 1} col ${ci + 1}`}
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="slide-table-controls">
                <button
                  type="button"
                  className="icon-btn"
                  disabled={(current.table?.headers.length || 0) >= 5}
                  onClick={() => {
                    const headers = [...(current.table?.headers || []), '']
                    const rows = (current.table?.rows || []).map((r) => [...r, ''])
                    update({ table: { headers, rows } })
                  }}
                >
                  {ko ? '열 추가' : '+ Column'}
                </button>
                <button
                  type="button"
                  className="icon-btn"
                  disabled={(current.table?.rows.length || 0) >= 8}
                  onClick={() => {
                    const cols = current.table?.headers.length || 2
                    const rows = [...(current.table?.rows || []), Array.from({ length: cols }, () => '')]
                    update({ table: { headers: current.table?.headers || [], rows } })
                  }}
                >
                  {ko ? '행 추가' : '+ Row'}
                </button>
              </div>
            </div>
          ) : current.layout === 'bullets' ? (
            <textarea
              value={current.body}
              onChange={(e) => {
                const body = e.target.value
                update({ body, bullets: bulletsFromBody(body) })
              }}
              placeholder={ko ? '한 줄에 하나씩 항목 입력 (최대 6개)' : 'One bullet per line (max 6)'}
              aria-label="Slide bullets"
            />
          ) : (
            <textarea
              value={current.body}
              onChange={(e) => update({ body: e.target.value })}
              placeholder={ko ? '부제목' : 'Subtitle'}
              aria-label="Slide body"
            />
          )}
        </div>
        <aside className="ppt-s5-assist" data-ui="s5-assist">
          <h2>{ko ? 'AI 도우미' : 'AI Assistant'}</h2>
          <p>{ko ? '현재 슬라이드나 덱을 다듬습니다.' : 'Refine this slide or the deck.'}</p>
          <textarea
            value={assistDraft}
            onChange={(e) => setAssistDraft(e.target.value)}
            placeholder={ko ? '이 슬라이드를 더 짧게' : 'Make this slide shorter'}
            aria-label={ko ? 'AI 지시' : 'Ask AI'}
          />
          <button
            type="button"
            className="ppt-tmpl-card-action primary"
            disabled={assistBusy || !assistDraft.trim()}
            onClick={() => {
              const line = assistDraft.trim()
              if (!line || assistBusy) return
              setAssistBusy(true)
              void runAssist(line).finally(() => {
                setAssistBusy(false)
                setAssistDraft('')
              })
            }}
          >
            {assistBusy ? (ko ? '적용 중…' : 'Working…') : ko ? '적용' : 'Apply'}
          </button>
        </aside>
      </div>
    </div>
  )
  return editor
}
