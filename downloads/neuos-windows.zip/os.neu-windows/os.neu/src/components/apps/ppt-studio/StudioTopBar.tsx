type Props = {
  ko: boolean
}

export function StudioTopBar({ ko }: Props) {
  return (
    <header className="ppt-tmpl-top">
      <span className="ppt-tmpl-top-title">os.neu PPT Studio</span>
      <div className="ppt-tmpl-top-actions">
        <button type="button" className="ppt-tmpl-upgrade">
          {ko ? '업그레이드' : 'Upgrade'}
        </button>
        <button type="button" className="ppt-tmpl-user-chip" aria-label={ko ? '사용자' : 'User'}>
          JD
        </button>
      </div>
    </header>
  )
}
