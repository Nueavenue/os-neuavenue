import { useState } from 'react'
import { AiConnectDialog } from '../../AiConnectDialog'
import { useNeu } from '../../../state/store'

type NavId = 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant'

type Props = {
  ko: boolean
  active: NavId
  onNav?: (id: NavId) => void
  promptFocusRef?: React.RefObject<HTMLFormElement | null>
}

const NAV: { id: NavId; en: string; ko: string; icon: string }[] = [
  { id: 'home', en: 'Home', ko: '홈', icon: '⌂' },
  { id: 'templates', en: 'Templates', ko: '템플릿', icon: '▣' },
  { id: 'my-templates', en: 'My Templates', ko: '내 템플릿', icon: '□' },
  { id: 'recent', en: 'Recent', ko: '최근', icon: '◷' },
  { id: 'ai-assistant', en: 'AI Assistant', ko: 'AI 어시스턴트', icon: '✦' },
]

export function StudioSidebar({ ko, active, onNav, promptFocusRef }: Props) {
  const neu = useNeu()
  const [connectOpen, setConnectOpen] = useState(false)

  return (
    <aside className="ppt-tmpl-side">
      <div className="ppt-tmpl-brand">
        <strong>os.neu</strong>
        <span>PPT Studio</span>
      </div>
      <nav className="ppt-tmpl-nav">
        {NAV.map((item) => (
          <button
            key={item.id}
            type="button"
            className={active === item.id || (item.id === 'home' && active === 'templates') ? 'on' : ''}
            onClick={() => {
              if (item.id === 'ai-assistant') promptFocusRef?.current?.querySelector('input')?.focus()
              onNav?.(item.id)
            }}
          >
            <span className="ppt-tmpl-nav-icon">{item.icon}</span>
            {ko ? item.ko : item.en}
          </button>
        ))}
      </nav>
      <div className="ppt-tmpl-side-foot">
        <p className="ppt-tmpl-connect-label">{ko ? 'AI 연결' : 'Connect AI'}</p>
        <div className="ppt-tmpl-providers">
          {['OpenAI', 'Anthropic', 'Google', ko ? '기타' : 'Other'].map((label) => (
            <button key={label} type="button" className="ppt-tmpl-provider" onClick={() => setConnectOpen(true)}>
              ○ {label}
            </button>
          ))}
        </div>
        <div className="ppt-tmpl-user">
          <span className="ppt-tmpl-user-dot" />
          <div>
            <strong>Jane Doe</strong>
            <span>{ko ? 'Pro 요금제' : 'Pro Plan'}</span>
          </div>
        </div>
      </div>
      <AiConnectDialog open={connectOpen} preferModel={neu.officeModel} onClose={() => setConnectOpen(false)} />
    </aside>
  )
}
