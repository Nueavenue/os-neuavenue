import type { PresentationTemplate } from '../../../engine/presentationTemplates'

export function LicenseAttribution({ template, ko }: { template?: PresentationTemplate; ko: boolean }) {
  const lic = template?.license
  if (!lic?.attributionRequired) return null
  return (
    <p className="ppt-license-attr" data-ui="license-attribution">
      {lic.attributionText}
      {' · '}
      <a href={lic.licenseUrl} target="_blank" rel="noreferrer">
        {lic.license}
      </a>
      {ko ? ' · 출처 표기 필요' : ' · attribution required'}
    </p>
  )
}
