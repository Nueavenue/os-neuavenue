type Props = {
  ko: boolean
}

export function HeroHeader({ ko }: Props) {
  return (
    <header className="ppt-tmpl-hero">
      <h1>
        {ko ? (
          <>
            AI로 만드는
            <span className="ppt-tmpl-hero-accent"> 멋진 프레젠테이션</span>
          </>
        ) : (
          <>
            Create Stunning
            <br />
            <span className="ppt-tmpl-hero-accent">Presentations with AI</span>
          </>
        )}
      </h1>
      <p className="ppt-tmpl-hero-lead">
        {ko
          ? '템플릿을 고르고 아이디어를 설명하면 os.neu가 몇 초 만에 전문 프레젠테이션으로 바꿉니다.'
          : 'Choose a template, describe your idea, and let os.neu turn it into a professional presentation in seconds.'}
      </p>
    </header>
  )
}
