import { fitSlide, slideFromOutline } from '../../../engine/contentFitter'
import { structureBlurb, structureLabel } from '../../../engine/designLanguage'
import { storyboardRows } from '../../../engine/generationPlanner'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { PresentationStudioLayout } from './PresentationStudioLayout'

type Props = {
  template: PresentationTemplate
  ko: boolean
  slideCount: number
  audience: string
  prompt: string
  onBack: () => void
  onConfirm: () => void
}

const STEPS = [
  { en: 'Analyze', ko: '분석' },
  { en: 'Storyboard', ko: '스토리보드' },
  { en: 'Generate', ko: '생성' },
  { en: 'Polish', ko: '다듬기' },
]

/** 125C — Screen 4 grid + progress chrome. Confirm still plans via parent. */
export function TemplateStoryboardScreen({ template, ko, slideCount, audience, prompt, onBack, onConfirm }: Props) {
  const rows = storyboardRows(template, slideCount)
  const name = ko ? template.nameKo : template.name

  return (
    <PresentationStudioLayout ko={ko} sidebarActive="templates">
      <button type="button" className="ppt-tmpl-back-link" onClick={onBack}>
        {ko ? '← 설정' : '← Settings'}
      </button>
      <section className="ppt-tmpl-storyboard ppt-s4-board" data-ui="s4-storyboard-grid">
        <h1>{ko ? '프레젠테이션 만드는 중' : 'Creating your presentation'}</h1>
        <p className="ppt-tmpl-hero-lead">
          {name} · {rows.length} {ko ? '장. 제목은 템플릿 구조입니다.' : 'slides. Titles come from the template structure.'}
        </p>
        <ol className="ppt-s4-progress" data-ui="s4-progress">
          {STEPS.map((step, i) => (
            <li key={step.en} className={i === 1 ? 'on' : i < 1 ? 'done' : ''}>
              {ko ? step.ko : step.en}
            </li>
          ))}
        </ol>
        {audience.trim() ? (
          <p className="ppt-tmpl-preview-meta">
            {ko ? '청중' : 'Audience'}: {audience.trim()}
          </p>
        ) : null}
        {prompt.trim() ? (
          <p className="ppt-tmpl-preview-meta">{prompt.trim().slice(0, 180)}</p>
        ) : null}
        <p className="ppt-s4-count">
          {ko ? '슬라이드 스토리보드' : 'Slide Storyboard'} · {rows.length} {ko ? '장' : 'slides'}
        </p>
        <ol className="ppt-s4-grid">
          {rows.map((row, i) => {
            const overflow = fitSlide(slideFromOutline(row.title, row.layout)).overflow
            return (
              <li key={`${row.key}-${i}`} data-overflow={overflow ? 'true' : undefined}>
                <span className="ppt-s4-badge">{String(i + 1).padStart(2, '0')}</span>
                <strong>{row.title}</strong>
                <em>{structureLabel(row.key, i, ko)}</em>
                <p>{structureBlurb(row.key, ko)}</p>
                {overflow ? <span className="ppt-overflow-mark">{ko ? '넘침' : 'Overflow'}</span> : null}
              </li>
            )
          })}
        </ol>
        <button type="button" className="ppt-tmpl-card-action primary" onClick={onConfirm}>
          {ko ? '이 개요로 편집' : 'Open in editor'}
        </button>
      </section>
    </PresentationStudioLayout>
  )
}
