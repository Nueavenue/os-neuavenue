import { forwardRef } from 'react'

type Props = {
  value: string
  ko: boolean
  onChange: (value: string) => void
  onSubmit: () => void
}

export const PromptDiscoveryBar = forwardRef<HTMLFormElement, Props>(function PromptDiscoveryBar(
  { value, ko, onChange, onSubmit },
  ref,
) {
  return (
    <form
      ref={ref}
      className="ppt-tmpl-prompt"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit()
      }}
    >
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={
          ko
            ? '예: os.neu 투자 덱, 10장, AI와 보안 중심…'
            : 'e.g. Investor deck for os.neu, 10 slides, focus on AI and security…'
        }
        aria-label={ko ? '무엇을 만들까요?' : 'What do you want to create?'}
      />
      <button type="submit" className="ppt-tmpl-prompt-go" aria-label={ko ? '찾기' : 'Discover'}>
        →
      </button>
    </form>
  )
})
