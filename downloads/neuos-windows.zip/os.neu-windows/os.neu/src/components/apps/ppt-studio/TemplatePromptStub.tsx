import { allowedSlideCounts, defaultSlideCount } from '../../../engine/generationPlanner'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { PresentationStudioLayout } from './PresentationStudioLayout'

type Props = {
  template: PresentationTemplate
  ko: boolean
  audience: string
  onAudience: (v: string) => void
  slideCount: number
  onSlideCount: (n: number) => void
  prompt: string
  onPrompt: (v: string) => void
  onBack: () => void
  onContinue: () => void
}

/** S3 Prompt & Settings — replaces the textarea-only stub. */
export function TemplatePromptSettings({
  template,
  ko,
  audience,
  onAudience,
  slideCount,
  onSlideCount,
  prompt,
  onPrompt,
  onBack,
  onContinue,
}: Props) {
  const name = ko ? template.nameKo : template.name
  const counts = allowedSlideCounts(template)
  const count = counts.includes(slideCount) ? slideCount : defaultSlideCount(template)

  return (
    <PresentationStudioLayout ko={ko} sidebarActive="templates">
      <button type="button" className="ppt-tmpl-back-link" onClick={onBack}>
        {ko ? '← 미리보기' : '← Preview'}
      </button>
      <section className="ppt-tmpl-prompt-step">
        <h1>{ko ? '프롬프트 · 설정' : 'Prompt & settings'}</h1>
        <p className="ppt-tmpl-hero-lead">
          {ko ? `템플릿: ${name}. 청중과 장 수를 정한 뒤 스토리보드로 갑니다.` : `Template: ${name}. Set audience and slide count, then review the storyboard.`}
        </p>
        <label className="ppt-s3-field">
          <span>{ko ? '청중' : 'Audience'}</span>
          <input
            value={audience}
            onChange={(e) => onAudience(e.target.value)}
            placeholder={ko ? '예: 팀, 파트너, 수업' : 'e.g. team, partners, class'}
          />
        </label>
        <label className="ppt-s3-field">
          <span>{ko ? '슬라이드 수' : 'Slide count'}</span>
          <select
            value={count}
            onChange={(e) => onSlideCount(Number(e.target.value))}
            aria-label={ko ? '슬라이드 수' : 'Slide count'}
          >
            {counts.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        <label className="ppt-s3-field">
          <span>{ko ? '프롬프트' : 'Prompt'}</span>
          <textarea
            className="ppt-tmpl-prompt-area"
            value={prompt}
            onChange={(e) => onPrompt(e.target.value)}
            rows={5}
            placeholder={ko ? '핵심 메시지, 꼭 넣을 제목…' : 'Key message, titles to keep…'}
          />
        </label>
        <button type="button" className="ppt-tmpl-card-action primary" onClick={onContinue}>
          {ko ? '스토리보드 보기' : 'Review storyboard'}
        </button>
      </section>
    </PresentationStudioLayout>
  )
}

export const TemplatePromptStub = TemplatePromptSettings
