import { fitDeck } from '../../../engine/contentFitter'
import { listLicensedPilots } from '../../../engine/licenseImport'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import type { RecipeSlide } from '../../../engine/slidesRecipe'
import { LicenseAttribution } from './LicenseAttribution'
import { PresentationStudioLayout } from './PresentationStudioLayout'

type Props = {
  template?: PresentationTemplate
  slides: RecipeSlide[]
  ko: boolean
  exportHint: string
  onBack: () => void
  onDownload: () => void
}

function layoutLabel(slide: RecipeSlide, ko: boolean): string {
  const id = slide.primitive || slide.layout
  const koMap: Record<string, string> = {
    title: '제목',
    bullets: '목록',
    table: '표',
    'two-column': '두 단',
    metric: '지표',
    'section-divider': '구분',
  }
  const enMap: Record<string, string> = {
    title: 'Title',
    bullets: 'Bullets',
    table: 'Table',
    'two-column': 'Two column',
    metric: 'Metric',
    'section-divider': 'Section',
  }
  return (ko ? koMap[id] : enMap[id]) || id
}

/** S6 export hub — recap + PPTX download. Toolbar PPTX보내기 stays on the editor. */
export function ExportHubScreen({ template, slides, ko, exportHint, onBack, onDownload }: Props) {
  const name = template ? (ko ? template.nameKo : template.name) : ko ? '현재 덱' : 'Current deck'
  const pilots = listLicensedPilots()
  const deckFit = fitDeck(slides)

  return (
    <PresentationStudioLayout ko={ko} sidebarActive="templates">
      <button type="button" className="ppt-tmpl-back-link" onClick={onBack}>
        {ko ? '← 편집기' : '← Editor'}
      </button>
      <section className="ppt-export-hub" data-ui="export-hub">
        <h1>{ko ? '내보내기' : 'Export'}</h1>
        <p className="ppt-tmpl-hero-lead">
          {name} · {slides.length} {ko ? '장 · PPTX' : 'slides · PPTX'}
        </p>
        <LicenseAttribution template={template} ko={ko} />
        {deckFit.overflowCount ? (
          <p className="ppt-overflow-warn" data-ui="overflow-warn" data-severity="warn">
            {ko
              ? `${deckFit.overflowCount}장이 넘칠 수 있습니다. PPTX 다운로드는 막지 않습니다.`
              : `${deckFit.overflowCount} slide(s) may overflow. PPTX download is not blocked.`}
          </p>
        ) : null}
        <ol className="ppt-export-recap">
          {slides.map((slide, i) => (
            <li key={`${slide.title}-${i}`} data-overflow={deckFit.results[i]?.overflow ? 'true' : undefined}>
              <strong>
                {i + 1}. {slide.title || (ko ? '슬라이드' : 'Slide')}
              </strong>
              <span>
                {layoutLabel(slide, ko)}
                {deckFit.results[i]?.overflow ? (ko ? ' · 넘침' : ' · overflow') : ''}
              </span>
            </li>
          ))}
        </ol>
        <button type="button" className="ppt-tmpl-card-action primary" data-ui="export-hub-pptx" onClick={onDownload}>
          {ko ? 'PPTX 다운로드' : 'Download PPTX'}
        </button>
        {exportHint ? <p className="slides-export-hint">{exportHint}</p> : null}
        <aside className="ppt-export-pilots">
          <h2>{ko ? '라이선스 파일럿 (갤러리 아님)' : 'License pilots (not gallery)'}</h2>
          <ul>
            {pilots.map((p) => (
              <li key={p.id}>
                {ko ? p.nameKo : p.name} · {p.license?.license}
              </li>
            ))}
          </ul>
        </aside>
      </section>
    </PresentationStudioLayout>
  )
}
