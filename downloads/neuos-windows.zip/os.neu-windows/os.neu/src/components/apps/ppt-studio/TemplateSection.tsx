import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { TemplateCard } from './TemplateCard'

type Props = {
  title: string
  viewAllLabel?: string
  templates: PresentationTemplate[]
  ko: boolean
  onUse: (template: PresentationTemplate) => void
  onPreview: (template: PresentationTemplate) => void
  onViewAll?: () => void
}

export function TemplateSection({ title, viewAllLabel, templates, ko, onUse, onPreview, onViewAll }: Props) {
  if (!templates.length) return null
  return (
    <section className="ppt-tmpl-section">
      <div className="ppt-tmpl-section-head">
        <h2>{title}</h2>
        {viewAllLabel ? (
          <button type="button" className="ppt-tmpl-view-all" onClick={onViewAll}>
            {viewAllLabel}
          </button>
        ) : null}
      </div>
      <div className="ppt-tmpl-row">
        {templates.map((t) => (
          <TemplateCard key={t.id} template={t} ko={ko} onUse={() => onUse(t)} onPreview={() => onPreview(t)} />
        ))}
      </div>
    </section>
  )
}
