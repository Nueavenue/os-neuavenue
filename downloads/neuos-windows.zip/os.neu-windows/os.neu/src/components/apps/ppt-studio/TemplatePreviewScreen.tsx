import { useState } from 'react'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { defaultSlideCount } from '../../../engine/generationPlanner'
import { designLanguageFor, structureLabel } from '../../../engine/designLanguage'
import { isFavoriteTemplate, toggleFavoriteTemplate } from '../../../engine/pptStudioStorage'
import { LicenseAttribution } from './LicenseAttribution'
import { PresentationStudioLayout } from './PresentationStudioLayout'
import { SchemaPreviewDeck } from './SchemaPreviewDeck'

type Props = {
  template: PresentationTemplate
  ko: boolean
  onBack: () => void
  onUse: () => void
  onPromptStep: () => void
}

/** 125B — Screen 2 chrome: structure · hero SchemaPreviewDeck · Design Style. */
export function TemplatePreviewScreen({ template, ko, onBack, onUse, onPromptStep }: Props) {
  const [fav, setFav] = useState(() => isFavoriteTemplate(template.id))
  const [previewCount, setPreviewCount] = useState(() => defaultSlideCount(template))
  const name = ko ? template.nameKo : template.name
  const desc = ko ? template.descriptionKo : template.description
  const lang = designLanguageFor(template)
  const keys = template.structure.slice(0, previewCount)

  return (
    <PresentationStudioLayout ko={ko} sidebarActive="templates">
      <button type="button" className="ppt-tmpl-back-link" onClick={onBack}>
        {ko ? '← 갤러리' : '← Gallery'}
      </button>
      <div className="ppt-s2-chrome" data-ui="s2-preview-chrome">
        <header className="ppt-s2-head">
          <h1>{name}</h1>
          <p className="ppt-s2-tags">
            {template.category} · {template.style.theme} · {previewCount} {ko ? '장' : 'Slides'}
          </p>
          <p className="ppt-s2-desc">{desc}</p>
          <LicenseAttribution template={template} ko={ko} />
          <div className="ppt-tmpl-preview-actions">
            <button type="button" className="ppt-tmpl-upgrade" onClick={() => setFav(toggleFavoriteTemplate(template.id))}>
              {fav ? (ko ? '★ 내 템플릿' : '★ My template') : ko ? '☆ 저장' : '☆ Save'}
            </button>
            <button type="button" className="ppt-tmpl-card-action" onClick={onPromptStep}>
              {ko ? 'AI 프롬프트 (Step 3)' : 'AI prompt (Step 3)'}
            </button>
            <button type="button" className="ppt-tmpl-card-action primary" onClick={onUse}>
              {ko ? '이 템플릿 사용' : 'Use this template'}
            </button>
          </div>
        </header>
        <div className="ppt-s2-cols">
          <section className="ppt-s2-structure" data-ui="slide-structure">
            <h2>{ko ? '슬라이드 구조' : 'Slide Structure'}</h2>
            <ol>
              {keys.map((key, i) => (
                <li key={`${key}-${i}`}>{structureLabel(key, i, ko)}</li>
              ))}
            </ol>
          </section>
          <section className="ppt-s2-hero">
            <SchemaPreviewDeck template={template} count={previewCount} onCount={setPreviewCount} ko={ko} hero />
          </section>
          <section className="ppt-s2-design" data-ui="design-style">
            <h2>{ko ? '디자인 스타일' : 'Design Style'}</h2>
            <dl>
              <div>
                <dt>{ko ? '타이포그래피' : 'Typography'}</dt>
                <dd>{ko ? lang.typography.ko : lang.typography.en}</dd>
              </div>
              <div>
                <dt>{ko ? '레이아웃' : 'Layout'}</dt>
                <dd>{ko ? lang.layout.ko : lang.layout.en}</dd>
              </div>
              <div>
                <dt>{ko ? '비주얼 스타일' : 'Visual Style'}</dt>
                <dd>{ko ? lang.visualStyle.ko : lang.visualStyle.en}</dd>
              </div>
            </dl>
          </section>
        </div>
      </div>
    </PresentationStudioLayout>
  )
}
