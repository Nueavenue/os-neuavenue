import type { CSSProperties } from 'react'
import { allowedSlideCounts } from '../../../engine/generationPlanner'
import type { LayoutPrimitiveId } from '../../../engine/layoutContract'
import type { PreviewSlide } from '../../../engine/previewSchema'
import { previewSlidesFromTemplate } from '../../../engine/previewSchema'
import { themeForTemplate, themeToCssVars } from '../../../engine/presentationThemes'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { fitSlide, slideFromOutline } from '../../../engine/contentFitter'

type Props = {
  template: PresentationTemplate
  count: number
  onCount: (n: number) => void
  ko: boolean
  /** 125B — mock Screen 2 hero shows the first schema slide large. */
  hero?: boolean
}

function LayoutRegions({ slide, ko }: { slide: PreviewSlide; ko: boolean }) {
  const layout: LayoutPrimitiveId = slide.layout
  if (layout === 'title' || layout === 'section-divider') {
    return (
      <div className={`ppt-schema-slide ppt-schema-${layout}`}>
        <span className="ppt-schema-kicker">os.neu</span>
        <strong>{slide.title}</strong>
      </div>
    )
  }
  if (layout === 'table' || layout === 'metric') {
    return (
      <div className={`ppt-schema-slide ppt-schema-${layout}`}>
        <strong>{slide.title}</strong>
        <div className="ppt-schema-metric-row">
          <em>{ko ? '지표' : 'Metric'}</em>
          <span>{ko ? '개요' : 'Outline'}</span>
        </div>
      </div>
    )
  }
  if (layout === 'two-column') {
    return (
      <div className="ppt-schema-slide ppt-schema-two-column">
        <strong>{slide.title}</strong>
        <div className="ppt-schema-cols">
          <aside>{ko ? '왼쪽' : 'Left'}</aside>
          <aside>{ko ? '오른쪽' : 'Right'}</aside>
        </div>
      </div>
    )
  }
  return (
    <div className="ppt-schema-slide ppt-schema-bullets">
      <strong>{slide.title}</strong>
      <ul>
        <li>{ko ? '항목 하나' : 'Point one'}</li>
        <li>{ko ? '항목 둘' : 'Point two'}</li>
      </ul>
    </div>
  )
}

export function SchemaPreviewThumb({ template, ko }: { template: PresentationTemplate; ko: boolean }) {
  const theme = themeForTemplate(template)
  const slide = previewSlidesFromTemplate(template)[0]
  if (!slide) return null
  return (
    <div className="ppt-schema-thumb" style={themeToCssVars(theme) as CSSProperties} data-ui="schema-thumb">
      <LayoutRegions slide={slide} ko={ko} />
    </div>
  )
}

/** S2 schema Preview — contract → DOM. CSS mock is not the truth path. */
export function SchemaPreviewDeck({ template, count, onCount, ko, hero }: Props) {
  const theme = themeForTemplate(template)
  const slides = previewSlidesFromTemplate(template, count)
  const shown = hero ? slides.slice(0, 1) : slides
  const counts = allowedSlideCounts(template)

  return (
    <div className={`ppt-schema-deck${hero ? ' ppt-schema-deck--hero' : ''}`} style={themeToCssVars(theme) as CSSProperties} data-ui="schema-preview">
      <label className="ppt-schema-count">
        <span>{ko ? '미리보기 장 수' : 'Preview count'}</span>
        <select value={count} onChange={(e) => onCount(Number(e.target.value))} aria-label={ko ? '미리보기 장 수' : 'Preview count'}>
          {counts.map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </label>
      <ol className="ppt-schema-list">
        {shown.map((slide, i) => {
          const overflow = fitSlide(slideFromOutline(slide.title, slide.layout)).overflow
          return (
            <li key={`${slide.key}-${i}`} data-layout={slide.layout} data-key={slide.key} data-overflow={overflow ? 'true' : undefined}>
              <LayoutRegions slide={slide} ko={ko} />
              {overflow ? <em className="ppt-overflow-mark">{ko ? '넘침' : 'Overflow'}</em> : null}
            </li>
          )
        })}
      </ol>
    </div>
  )
}
