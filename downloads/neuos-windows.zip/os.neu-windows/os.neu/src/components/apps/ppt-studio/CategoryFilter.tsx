import { CATEGORY_FILTERS } from '../../../engine/presentationTemplates'

type Props = {
  active: string
  ko: boolean
  onChange: (id: string) => void
}

export function CategoryFilter({ active, ko, onChange }: Props) {
  return (
    <div className="ppt-tmpl-categories">
      {CATEGORY_FILTERS.map((item) => (
        <button
          key={item.id}
          type="button"
          className={active === item.id ? 'on' : ''}
          onClick={() => onChange(item.id)}
        >
          {ko ? item.ko : item.en}
        </button>
      ))}
    </div>
  )
}
