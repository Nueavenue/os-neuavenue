import { useMemo, useRef, useState } from 'react'
import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { getTemplateById } from '../../../engine/presentationTemplates'
import { favoriteTemplateIds, recentTemplateIds } from '../../../engine/pptStudioStorage'
import { CategoryFilter } from './CategoryFilter'
import { HeroHeader } from './HeroHeader'
import { PresentationStudioLayout } from './PresentationStudioLayout'
import { PromptDiscoveryBar } from './PromptDiscoveryBar'
import { TemplateSection } from './TemplateSection'

export type GalleryView = 'home' | 'my-templates' | 'recent' | 'all'

type Props = {
  ko: boolean
  galleryView: GalleryView
  onGalleryView: (view: GalleryView) => void
  onNav: (id: 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant') => void
  orderedTemplates: PresentationTemplate[]
  onDiscover: (query: string) => void
  onSelectTemplate: (template: PresentationTemplate) => void
  onPreviewTemplate: (template: PresentationTemplate) => void
}

export function TemplateGalleryHome({
  ko,
  galleryView,
  onGalleryView,
  onNav,
  orderedTemplates,
  onDiscover,
  onSelectTemplate,
  onPreviewTemplate,
}: Props) {
  const [category, setCategory] = useState('all')
  const [query, setQuery] = useState('')
  const promptRef = useRef<HTMLFormElement>(null)
  const allRef = useRef<HTMLDivElement>(null)

  const pool = useMemo(() => {
    if (galleryView === 'my-templates') {
      const ids = new Set(favoriteTemplateIds())
      return orderedTemplates.filter((t) => ids.has(t.id))
    }
    if (galleryView === 'recent') {
      const ids = recentTemplateIds()
      return ids.map((id) => getTemplateById(id)).filter(Boolean) as PresentationTemplate[]
    }
    return orderedTemplates
  }, [galleryView, orderedTemplates])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return pool.filter((t) => {
      if (category !== 'all') {
        if (category === 'custom' && t.category !== 'Custom') return false
        if (category === 'product' && t.pack !== 'product' && t.categoryFilter !== 'product') return false
        if (category !== 'custom' && category !== 'product' && t.categoryFilter !== category) return false
      }
      if (!q) return true
      const blob = `${t.name} ${t.nameKo} ${t.description}`.toLowerCase()
      return blob.includes(q)
    })
  }, [pool, category, query])

  const featured = filtered.filter((t) => t.group === 'featured')
  const popular = filtered.filter((t) => t.group === 'popular')
  const showAllList = galleryView === 'all'

  const sidebarActive =
    galleryView === 'my-templates' ? 'my-templates' : galleryView === 'recent' ? 'recent' : 'templates'

  return (
    <PresentationStudioLayout ko={ko} sidebarActive={sidebarActive} onNav={onNav} promptFocusRef={promptRef}>
      <HeroHeader ko={ko} />
      <PromptDiscoveryBar
        ref={promptRef}
        value={query}
        ko={ko}
        onChange={setQuery}
        onSubmit={() => onDiscover(query)}
      />
      <CategoryFilter active={category} ko={ko} onChange={setCategory} />
      {showAllList ? (
        <div ref={allRef}>
          <TemplateSection
            title={ko ? '전체 템플릿' : 'All templates'}
            templates={filtered}
            ko={ko}
            onUse={onSelectTemplate}
            onPreview={onPreviewTemplate}
          />
        </div>
      ) : (
        <>
          <TemplateSection
            title={ko ? '추천 템플릿' : 'Featured Templates'}
            viewAllLabel={ko ? '전체 보기 →' : 'View all →'}
            templates={featured}
            ko={ko}
            onUse={onSelectTemplate}
            onPreview={onPreviewTemplate}
            onViewAll={() => {
              onGalleryView('all')
              allRef.current?.scrollIntoView({ behavior: 'smooth' })
            }}
          />
          <TemplateSection
            title={ko ? '인기 템플릿' : 'Popular Templates'}
            templates={popular}
            ko={ko}
            onUse={onSelectTemplate}
            onPreview={onPreviewTemplate}
          />
        </>
      )}
    </PresentationStudioLayout>
  )
}
