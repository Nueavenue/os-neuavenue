import type { PresentationTemplate } from '../../../engine/presentationTemplates'
import { cardArtModifier } from '../../../engine/designLanguage'
import { SchemaPreviewThumb } from './SchemaPreviewDeck'

type Props = {
  template: PresentationTemplate
  ko: boolean
  onUse: () => void
  onPreview: () => void
}

/** 125A — per-template card background identity; schema thumb inset. */
export function TemplateCard({ template, ko, onUse, onPreview }: Props) {
  const name = ko ? template.nameKo : template.name
  const meta = ko ? `${template.category} · ${template.cardSubtitleKo}` : `${template.category} · ${template.cardSubtitle}`

  return (
    <article className="ppt-tmpl-card" onClick={onUse} onKeyDown={(e) => e.key === 'Enter' && onUse()} role="button" tabIndex={0}>
      <div className={`ppt-tmpl-card-thumb ppt-card-art ${cardArtModifier(template.previewTheme)}`} data-ui="card-art" data-theme={template.previewTheme}>
        <span className="ppt-card-art-kicker">os.neu</span>
        <strong className="ppt-card-art-title">{name}</strong>
        <div className="ppt-card-art-inset">
          <SchemaPreviewThumb template={template} ko={ko} />
        </div>
        <div className="ppt-tmpl-card-overlay">
          <button
            type="button"
            className="ppt-tmpl-card-action"
            onClick={(e) => {
              e.stopPropagation()
              onPreview()
            }}
          >
            {ko ? '미리보기' : 'Preview'}
          </button>
          <button
            type="button"
            className="ppt-tmpl-card-action primary"
            onClick={(e) => {
              e.stopPropagation()
              onUse()
            }}
          >
            {ko ? '템플릿 사용' : 'Use template'}
          </button>
        </div>
      </div>
      <div className="ppt-tmpl-card-meta">
        <strong>{name}</strong>
        <span>{meta}</span>
      </div>
    </article>
  )
}
