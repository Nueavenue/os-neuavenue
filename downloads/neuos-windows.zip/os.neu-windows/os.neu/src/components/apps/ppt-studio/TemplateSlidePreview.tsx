import type { TemplatePreviewTheme } from '../../../engine/presentationTemplates'

type Props = {
  theme: TemplatePreviewTheme
  title: string
}

export function TemplateSlidePreview({ theme, title }: Props) {
  return (
    <div className={`ppt-tmpl-preview ppt-tmpl-preview--${theme}`} aria-hidden>
      <div className="ppt-tmpl-preview-slide">
        <span className="ppt-tmpl-preview-kicker">os.neu</span>
        <span className="ppt-tmpl-preview-title">{title}</span>
      </div>
    </div>
  )
}
