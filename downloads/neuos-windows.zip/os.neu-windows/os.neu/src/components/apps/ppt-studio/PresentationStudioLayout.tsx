import type { ReactNode } from 'react'
import { StudioSidebar } from './StudioSidebar'
import { StudioTopBar } from './StudioTopBar'

type Props = {
  ko: boolean
  children: ReactNode
  sidebarActive?: 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant'
  onNav?: (id: 'home' | 'templates' | 'my-templates' | 'recent' | 'ai-assistant') => void
  promptFocusRef?: React.RefObject<HTMLFormElement | null>
}

export function PresentationStudioLayout({ ko, children, sidebarActive = 'templates', onNav, promptFocusRef }: Props) {
  return (
    <div className="slides-app ppt-tmpl-studio">
      <StudioSidebar ko={ko} active={sidebarActive} onNav={onNav} promptFocusRef={promptFocusRef} />
      <div className="ppt-tmpl-shell">
        <StudioTopBar ko={ko} />
        <main className="ppt-tmpl-main">{children}</main>
      </div>
    </div>
  )
}
