import type { FitResult, OverflowMessageKey } from '../../../engine/contentFitter'

const EN: Record<OverflowMessageKey, string> = {
  'title-long': 'Title may overflow this layout.',
  'body-long': 'Body text may overflow this layout.',
  'too-many-bullets': 'Too many bullets for this layout.',
  'bullet-long': 'A bullet is too long for this layout.',
  'metric-long': 'Metric value may overflow.',
  'table-wide': 'Table cells may overflow.',
  'divider-long': 'Section title may overflow.',
}

const KO: Record<OverflowMessageKey, string> = {
  'title-long': '제목이 이 레이아웃을 넘칠 수 있습니다.',
  'body-long': '본문이 이 레이아웃을 넘칠 수 있습니다.',
  'too-many-bullets': '이 레이아웃에 항목이 너무 많습니다.',
  'bullet-long': '항목 한 줄이 너무 깁니다.',
  'metric-long': '지표 값이 넘칠 수 있습니다.',
  'table-wide': '표 칸이 넘칠 수 있습니다.',
  'divider-long': '구분 제목이 넘칠 수 있습니다.',
}

export function OverflowWarning({ result, ko }: { result: FitResult; ko: boolean }) {
  if (!result.overflow || !result.messageKey) return null
  const text = (ko ? KO : EN)[result.messageKey]
  return (
    <div className="ppt-overflow-warn" data-ui="overflow-warn" data-severity={result.severity}>
      {ko ? '넘침 경고' : 'Overflow'} · {text} {ko ? '(내보내기는 막지 않습니다)' : '(export is not blocked)'}
    </div>
  )
}
