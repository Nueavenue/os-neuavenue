import { useEffect, useRef, useState, type DragEvent, type KeyboardEvent } from 'react'
import { OFFICE_MODELS, assistOfficeStream } from '../../engine/office'
import {
  addDocProject,
  addFolderProject,
  canReparent,
  firstDoc,
  flattenDocTree,
  loadDocProjects,
  moveDocProject,
  removeDocProject,
  upsertDocProject,
  type DocProject,
} from '../../engine/docProjects'
import { saveDocumentFile, type DocSaveFormat } from '../../engine/docExport'
import { htmlToMarkdown, markdownToHtml } from '../../engine/manualMd'
import { deriveAiHealth, fetchLlmSettings, warmLocalLlm, type AiHealth } from '../../engine/llmConnect'
import { AiConnectDialog } from '../AiConnectDialog'
import { AiHealthBadge, AiHealthBanner } from '../AiHealthBadge'
import { useI18n } from '../../i18n/LocaleContext'
import { useNeu } from '../../state/store'

type ChatBubble = { id: string; role: 'user' | 'assistant'; text: string }
type CtxMenu = { x: number; y: number; selected: string } | null
type DocSurface = 'markdown' | 'preview' | 'word' | 'gdocs'

const FORMAT_TOOLS = [
  { id: 'bold', label: 'B', title: 'Bold' },
  { id: 'italic', label: 'I', title: 'Italic' },
  { id: 'underline', label: 'U', title: 'Underline' },
  { id: 'h1', label: 'H1', title: 'Heading' },
  { id: 'list', label: '•', title: 'Bullets' },
  { id: 'num', label: '1.', title: 'Numbered' },
  { id: 'quote', label: '“', title: 'Quote' },
  { id: 'code', label: '</>', title: 'Code' },
  { id: 'table', label: '▦', title: 'Table' },
  { id: 'clear', label: 'Tx', title: 'Clear marks' },
] as const

export function DocApp({ text = '' }: { text?: string }) {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const editorRef = useRef<HTMLTextAreaElement>(null)
  const richRef = useRef<HTMLDivElement>(null)
  /** When true, next rich paint is skipped (body came from the rich editor itself). */
  const skipRichSync = useRef(false)
  /** Last markdown string painted into the rich surface. */
  const paintedBodyRef = useRef('')
  /** Skip autosave after loading another project (prevents overwriting empty docs). */
  const skipPersistRef = useRef(false)
  /** Bumped on every project load so delayed autosaves from a previous doc cannot write into the next. */
  const loadEpochRef = useRef(0)
  const projectsRef = useRef<DocProject[]>([])
  const activeIdRef = useRef('')

  const [projects, setProjects] = useState<DocProject[]>(() => loadDocProjects())
  const [activeId, setActiveId] = useState(() => firstDoc(loadDocProjects()).id)
  const seed = projects.find((p) => p.id === activeId && p.kind === 'doc') || firstDoc(projects)
  const [title, setTitle] = useState(seed?.title || 'Untitled document')
  const [body, setBody] = useState(seed?.body || text)
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set())
  const [railFocusId, setRailFocusId] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const renameInputRef = useRef<HTMLInputElement>(null)
  const [dragId, setDragId] = useState<string | null>(null)
  const [dropTarget, setDropTarget] = useState<string | 'root' | null>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const [railOpen, setRailOpen] = useState(true)
  const [formatOpen, setFormatOpen] = useState(true)
  const [surface, setSurface] = useState<DocSurface>('markdown')
  const [ask, setAsk] = useState('')
  const [slashAsk, setSlashAsk] = useState('')
  const [busy, setBusy] = useState(false)
  const [hint, setHint] = useState('')
  const [saved, setSaved] = useState(false)
  const [chats, setChats] = useState<ChatBubble[]>([])
  const [slashOpen, setSlashOpen] = useState(false)
  const [slashAt, setSlashAt] = useState(0)
  const [ctx, setCtx] = useState<CtxMenu>(null)
  const [saveMenu, setSaveMenu] = useState(false)
  const [connectOpen, setConnectOpen] = useState(false)
  const [connectPrefer, setConnectPrefer] = useState<string | undefined>()
  const [waitSec, setWaitSec] = useState(0)
  const [firstToken, setFirstToken] = useState(false)
  const firstTokenRef = useRef(false)
  const [health, setHealth] = useState<AiHealth | null>(null)

  const richMode = surface !== 'markdown'
  projectsRef.current = projects
  activeIdRef.current = activeId

  const paintRich = (md: string) => {
    const el = richRef.current
    if (!el) return
    paintedBodyRef.current = md
    el.innerHTML = md.trim() ? markdownToHtml(md) : '<p><br></p>'
  }

  const currentEditorBody = () => {
    if (richMode && richRef.current) return htmlToMarkdown(richRef.current.innerHTML)
    return body
  }

  const flushRichToBody = () => {
    const el = richRef.current
    if (!el) return body
    const next = htmlToMarkdown(el.innerHTML)
    paintedBodyRef.current = next
    skipRichSync.current = true
    setBody(next)
    setSaved(false)
    return next
  }

  const commitProject = (id: string, nextTitle: string, nextBody: string) => {
    const rows = projectsRef.current
    const cur = rows.find((p) => p.id === id)
    if (!cur) return rows
    if (cur.title === nextTitle && cur.body === nextBody) return rows
    const list = upsertDocProject(rows, {
      ...cur,
      title: nextTitle,
      body: nextBody,
      updated: Date.now(),
    })
    projectsRef.current = list
    setProjects(list)
    return list
  }

  const applyProjectToEditor = (row: DocProject) => {
    if (row.kind !== 'doc') return
    loadEpochRef.current += 1
    skipPersistRef.current = true
    skipRichSync.current = false
    paintedBodyRef.current = ''
    setActiveId(row.id)
    activeIdRef.current = row.id
    setRailFocusId(row.id)
    setTitle(row.title)
    setBody(row.body)
    setChats([])
    setAsk('')
    setSlashAsk('')
    setSlashOpen(false)
    setCtx(null)
    setSaved(true)
    setHint('')
  }

  /** Save the open doc, then show another project's own title/body (empty stays empty). */
  const selectProject = (nextId: string) => {
    const target = projectsRef.current.find((p) => p.id === nextId)
    if (!target) return
    if (target.kind === 'folder') {
      setRailFocusId(target.id)
      setExpanded((prev) => {
        const next = new Set(prev)
        if (next.has(target.id)) next.delete(target.id)
        else next.add(target.id)
        return next
      })
      return
    }
    if (nextId === activeIdRef.current) return
    const fromId = activeIdRef.current
    const liveBody = currentEditorBody()
    commitProject(fromId, title, liveBody)
    applyProjectToEditor(target)
  }

  const switchSurface = (next: DocSurface) => {
    if (next === surface) return
    if (richMode) flushRichToBody()
    skipRichSync.current = false
    if (next === 'markdown') paintedBodyRef.current = ''
    setSurface(next)
  }

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ block: 'end' })
  }, [chats, busy])

  useEffect(() => {
    warmLocalLlm()
  }, [])

  const refreshHealth = async () => {
    const view = await fetchLlmSettings()
    setHealth(deriveAiHealth(view))
  }

  useEffect(() => {
    void refreshHealth()
    // AI Health Contract: re-check periodically so a RED badge can recover to GREEN/YELLOW
    // without the user having to reopen the Doc app.
    const tick = window.setInterval(() => void refreshHealth(), 30_000)
    return () => window.clearInterval(tick)
  }, [])

  const fixHealth = () => {
    if (health?.fix === 'retry') {
      void refreshHealth()
      return
    }
    setConnectPrefer(neu.officeModel)
    setConnectOpen(true)
  }

  useEffect(() => {
    if (!busy) {
      setWaitSec(0)
      return
    }
    setWaitSec(0)
    setFirstToken(false)
    const tick = window.setInterval(() => setWaitSec((n) => n + 1), 1000)
    return () => window.clearInterval(tick)
  }, [busy])

  useEffect(() => {
    if (skipPersistRef.current) {
      skipPersistRef.current = false
      return
    }
    const id = activeId
    const epoch = loadEpochRef.current
    const snapshotTitle = title
    const snapshotBody = body
    const timer = window.setTimeout(() => {
      if (loadEpochRef.current !== epoch) return
      if (activeIdRef.current !== id) return
      commitProject(id, snapshotTitle, snapshotBody)
    }, 400)
    return () => window.clearTimeout(timer)
  }, [title, body, activeId])

  useEffect(() => {
    if (!richMode) {
      skipRichSync.current = false
      return
    }
    const id = window.requestAnimationFrame(() => {
      const el = richRef.current
      if (!el) return
      if (skipRichSync.current) {
        skipRichSync.current = false
        paintedBodyRef.current = body
        return
      }
      if (paintedBodyRef.current === body && el.childNodes.length > 0) return
      paintRich(body)
    })
    return () => window.cancelAnimationFrame(id)
  }, [body, richMode, surface, activeId])

  const pullRichToBody = () => {
    flushRichToBody()
  }

  const runAi = async (
    instruction: string,
    opts?: { mode?: 'write' | 'rewrite'; selection?: string; insertAt?: number },
  ) => {
    const line = instruction.trim()
    if (!line || busy) return
    if (health?.state === 'red') {
      setHint(
        ko
          ? 'AI를 사용할 수 없습니다. 위의 AI 상태 배지에서 고치세요.'
          : 'AI is unavailable. Use the AI status badge above to fix it.',
      )
      fixHealth()
      return
    }
    setBusy(true)
    setSlashOpen(false)
    setCtx(null)
    setFirstToken(false)
    firstTokenRef.current = false
    const local = neu.officeModel === 'os.neu-local' || neu.officeModel.startsWith('local:')
    setHint(
      local
        ? ko
          ? '로컬 AI 로딩 중… CPU에서는 15–90초 걸릴 수 있습니다.'
          : 'Loading local AI… CPU may take 15–90s.'
        : ko
          ? 'AI 응답 대기 중…'
          : 'Waiting for AI…',
    )
    const userId = `u-${Date.now()}`
    const aiId = `a-${Date.now()}`
    const history = chats
      .filter((c) => c.text.trim())
      .slice(-6)
      .map((c) => ({ role: c.role, content: c.text }))
    setChats((rows) => [...rows, { id: userId, role: 'user', text: line }, { id: aiId, role: 'assistant', text: '' }])

    const baseBody = body
    const insertAt = typeof opts?.insertAt === 'number' ? opts.insertAt : null
    const selection = opts?.selection

    try {
      const result = await assistOfficeStream(
        {
            model: neu.officeModel,
            app: 'doc',
          instruction: line,
            content: `${title}\n${body}`,
          selection,
          mode: opts?.mode || 'write',
          history,
        },
        (chunk) => {
          if (!chunk.ok && chunk.done) {
            setHint(chunk.reason || 'AI failed')
            return
          }
          const streamed = chunk.full || ''
          if (streamed && !firstTokenRef.current) {
            firstTokenRef.current = true
            setFirstToken(true)
          }
          setChats((rows) => rows.map((row) => (row.id === aiId ? { ...row, text: streamed } : row)))
          if (!streamed) return
          setHint(ko ? 'AI가 타이핑 중…' : 'AI is typing…')

          if (opts?.mode === 'rewrite' && selection) {
            const idx = baseBody.indexOf(selection)
            if (idx >= 0) {
              setBody(`${baseBody.slice(0, idx)}${streamed}${baseBody.slice(idx + selection.length)}`)
            }
          } else if (insertAt != null) {
            setBody(`${baseBody.slice(0, insertAt)}${streamed}${baseBody.slice(insertAt)}`)
          } else {
            const [first, ...rest] = streamed.split('\n')
            const maybeTitle = first?.replace(/^#+\s*/, '').trim() || ''
            if (maybeTitle && rest.length) {
              setTitle(maybeTitle)
              setBody(rest.join('\n').replace(/^\n+/, ''))
            } else {
              setBody(streamed)
            }
          }
          setSaved(false)
        },
      )
      if (!result.ok) {
        if (result.reason === 'no-llm') {
          setHint(ko ? '클라우드 모델에는 API 키가 필요합니다. 연결 창을 열어 주세요.' : 'Cloud models need an API key. Open Connect AI.')
          setConnectPrefer(neu.officeModel.startsWith('gpt-') ? neu.officeModel : 'gpt-4o-mini')
          setConnectOpen(true)
        } else if (result.reason === 'local-unavailable') {
          setHint(
            ko
              ? '로컬 AI가 준비되지 않았습니다. 연결 창에서 상태를 확인하거나 OpenAI 키를 연결하세요.'
              : 'Local AI is not ready. Check Connect AI or add an OpenAI key.',
          )
          setConnectOpen(true)
        } else if (result.reason === 'timeout') {
          setHint(ko ? '응답이 너무 오래 걸렸습니다. 다시 시도해 주세요.' : 'Timed out waiting for AI. Try again.')
        } else if (result.reason === 'not-found') {
          setHint(ko ? 'AI 브리지를 재시작하는 중… 다시 시도해 주세요.' : 'AI bridge needs a restart. Try again in a moment.')
        } else {
          setHint(result.reason || 'AI failed')
        }
      } else {
        setHint('')
      }
    } catch (err) {
      setHint(err instanceof Error ? err.message : 'AI failed')
    } finally {
      setBusy(false)
    }
  }

  const wrapSelection = (before: string, after = before) => {
    const el = editorRef.current
    if (!el) return
    const start = el.selectionStart
    const end = el.selectionEnd
    const selected = body.slice(start, end)
    const next = `${body.slice(0, start)}${before}${selected || 'text'}${after}${body.slice(end)}`
    setBody(next)
    setSaved(false)
    setCtx(null)
    window.requestAnimationFrame(() => {
      el.focus()
      const caret = start + before.length + (selected || 'text').length + after.length
      el.setSelectionRange(caret, caret)
    })
  }

  const applyRichFormat = (id: string) => {
    const el = richRef.current
    if (!el) return
    el.focus()
    if (id === 'bold') document.execCommand('bold')
    else if (id === 'italic') document.execCommand('italic')
    else if (id === 'underline') document.execCommand('underline')
    else if (id === 'h1') document.execCommand('formatBlock', false, 'h1')
    else if (id === 'list') document.execCommand('insertUnorderedList')
    else if (id === 'num') document.execCommand('insertOrderedList')
    else if (id === 'quote') document.execCommand('formatBlock', false, 'blockquote')
    else if (id === 'code') document.execCommand('insertHTML', false, '<code>code</code>')
    else if (id === 'table') {
      document.execCommand(
        'insertHTML',
        false,
        '<table><tr><th>Column</th><th>Column</th></tr><tr><td>cell</td><td>cell</td></tr></table><p></p>',
      )
    } else if (id === 'clear') document.execCommand('removeFormat')
    pullRichToBody()
  }

  const applyFormat = (id: string) => {
    if (richMode) {
      applyRichFormat(id)
      return
    }
    if (id === 'bold') wrapSelection('**', '**')
    else if (id === 'italic') wrapSelection('_', '_')
    else if (id === 'underline') wrapSelection('<u>', '</u>')
    else if (id === 'h1') wrapSelection('\n# ', '\n')
    else if (id === 'list') wrapSelection('\n- ', '\n')
    else if (id === 'num') wrapSelection('\n1. ', '\n')
    else if (id === 'quote') wrapSelection('\n> ', '\n')
    else if (id === 'code') wrapSelection('`', '`')
    else if (id === 'table') {
      const table = '\n| Column | Column |\n| --- | --- |\n| cell | cell |\n'
      const el = editorRef.current
      const at = el?.selectionStart ?? body.length
      setBody(`${body.slice(0, at)}${table}${body.slice(at)}`)
      setSaved(false)
    } else if (id === 'clear') {
      setBody(body.replace(/\*\*|__|<u>|<\/u>|`/g, ''))
      setSaved(false)
    }
  }

  const onEditorKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === '/' && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const el = e.currentTarget
      const before = body.slice(0, el.selectionStart)
      const atBoundary = before.length === 0 || /[\s\n]$/.test(before)
      if (atBoundary) {
        e.preventDefault()
        setSlashAt(el.selectionStart)
        setSlashAsk('')
        setSlashOpen(true)
      }
    }
    if (e.key === 'Escape') setSlashOpen(false)
  }

  const selectedFromRich = () => window.getSelection()?.toString() || ''

  const saveAs = async (format: DocSaveFormat) => {
    setSaveMenu(false)
    const content = richMode ? flushRichToBody() : body
    const result = await saveDocumentFile({ title, body: content, format })
    if (result.ok) {
      setSaved(true)
      setHint(ko ? `저장했습니다 (${format}).` : `Saved as ${format}.`)
    } else {
      setHint(ko ? '저장을 취소했거나 실패했습니다.' : 'Save cancelled or failed.')
    }
  }

  const parentContextId = () => {
    const focus = projectsRef.current.find((p) => p.id === (railFocusId || activeIdRef.current))
    if (!focus) return null
    if (focus.kind === 'folder') return focus.id
    return focus.parentId
  }

  const addProject = () => {
    const liveBody = currentEditorBody()
    commitProject(activeIdRef.current, title, liveBody)
    const parentId = parentContextId()
    const { rows, node } = addDocProject(projectsRef.current, {
      parentId,
      name: ko ? '새 문서' : 'New doc',
      title: ko ? '새 문서' : 'New document',
    })
    projectsRef.current = rows
    setProjects(rows)
    if (parentId) {
      setExpanded((prev) => new Set(prev).add(parentId))
    }
    applyProjectToEditor(node)
  }

  const addFolder = () => {
    const parentId = parentContextId()
    const { rows, node } = addFolderProject(projectsRef.current, {
      parentId,
      name: ko ? '새 폴더' : 'New folder',
    })
    projectsRef.current = rows
    setProjects(rows)
    setRailFocusId(node.id)
    if (parentId) setExpanded((prev) => new Set(prev).add(parentId))
    setExpanded((prev) => new Set(prev).add(node.id))
  }

  const commitRename = (id: string) => {
    const next = editName.trim()
    setEditingId(null)
    if (!next) return
    setProjects((rows) => {
      const cur = rows.find((r) => r.id === id)
      if (!cur || cur.name === next) return rows
      const list = upsertDocProject(rows, {
        ...cur,
        name: next,
        title: cur.kind === 'folder' ? next : cur.title,
        updated: Date.now(),
      })
      projectsRef.current = list
      return list
    })
  }

  const startRename = (id: string) => {
    const cur = projectsRef.current.find((r) => r.id === id)
    if (!cur) return
    setRailFocusId(id)
    setEditingId(id)
    setEditName(cur.name)
    window.requestAnimationFrame(() => renameInputRef.current?.focus())
  }

  const deleteProject = (id: string) => {
    const target = projectsRef.current.find((r) => r.id === id)
    if (!target) return
    if (target.kind === 'doc' && id === activeIdRef.current) {
      commitProject(id, title, currentEditorBody())
    }
    const list = removeDocProject(projectsRef.current, id)
    projectsRef.current = list
    setProjects(list)
    if (target.kind === 'doc' && id === activeIdRef.current) {
      applyProjectToEditor(firstDoc(list))
    } else if (target.kind === 'folder') {
      const stillOpen = list.some((r) => r.id === activeIdRef.current && r.kind === 'doc')
      if (!stillOpen) applyProjectToEditor(firstDoc(list))
    }
  }

  const relocateNode = (id: string, newParentId: string | null) => {
    const cur = projectsRef.current.find((r) => r.id === id)
    if (!cur) return
    if (cur.parentId === newParentId) return
    if (!canReparent(projectsRef.current, id, newParentId)) return
    if (cur.kind === 'doc' && id === activeIdRef.current) {
      commitProject(id, title, currentEditorBody())
    }
    const list = moveDocProject(projectsRef.current, id, newParentId)
    projectsRef.current = list
    setProjects(list)
    if (newParentId) {
      setExpanded((prev) => new Set(prev).add(newParentId))
    }
    setHint(ko ? '문서를 폴더로 옮겼습니다.' : 'Moved into the folder.')
  }

  const onRailDragStart = (e: DragEvent, id: string) => {
    if (editingId === id) {
      e.preventDefault()
      return
    }
    e.dataTransfer.setData('text/osneu-doc-id', id)
    e.dataTransfer.setData('text/plain', id)
    e.dataTransfer.effectAllowed = 'move'
    setDragId(id)
  }

  const onRailDragEnd = () => {
    setDragId(null)
    setDropTarget(null)
  }

  const resolveDropParent = (overId: string | 'root'): string | null => {
    if (overId === 'root') return null
    const over = projectsRef.current.find((r) => r.id === overId)
    if (!over) return null
    if (over.kind === 'folder') return over.id
    return over.parentId
  }

  const onRailDragOver = (e: DragEvent, overId: string | 'root') => {
    if (!dragId) return
    const parentId = resolveDropParent(overId)
    if (!canReparent(projectsRef.current, dragId, parentId)) return
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
    setDropTarget(overId)
    if (parentId) {
      setExpanded((prev) => (prev.has(parentId) ? prev : new Set(prev).add(parentId)))
    }
  }

  const onRailDrop = (e: DragEvent, overId: string | 'root') => {
    e.preventDefault()
    const id = e.dataTransfer.getData('text/osneu-doc-id') || e.dataTransfer.getData('text/plain') || dragId
    setDragId(null)
    setDropTarget(null)
    if (!id) return
    const parentId = resolveDropParent(overId)
    if (id === overId) return
    relocateNode(id, parentId)
  }

  const treeRows = flattenDocTree(projects, expanded)

  return (
    <div className={`doc-shell surface-${surface}${railOpen ? '' : ' rail-collapsed'}`}>
      <aside className="doc-rail" aria-label={ko ? '문서 프로젝트' : 'Document projects'}>
        <div className="doc-rail-head">
          <button type="button" className="icon-btn" onClick={() => setRailOpen((v) => !v)} title={railOpen ? 'Collapse' : 'Expand'}>
            {railOpen ? '‹' : '›'}
          </button>
          {railOpen ? <b>{ko ? '프로젝트' : 'Projects'}</b> : null}
          {railOpen ? (
            <div className="doc-rail-adds">
              <button type="button" className="doc-rail-add" onClick={addFolder} title={ko ? '폴더 추가' : 'Add folder'}>
                ⌂+
              </button>
              <button type="button" className="doc-rail-add" onClick={addProject} title={ko ? '문서 추가' : 'Add doc'}>
                +
              </button>
            </div>
          ) : null}
        </div>
        {railOpen ? (
          <ul
            className="doc-rail-list"
            onDragOver={(e) => onRailDragOver(e, 'root')}
            onDrop={(e) => onRailDrop(e, 'root')}
          >
            <li
              className={`doc-rail-root-drop${dropTarget === 'root' ? ' drop-on' : ''}`}
              onDragOver={(e) => {
                e.stopPropagation()
                onRailDragOver(e, 'root')
              }}
              onDrop={(e) => {
                e.stopPropagation()
                onRailDrop(e, 'root')
              }}
            >
              {ko ? '여기로 놓으면 최상위' : 'Drop here for top level'}
            </li>
            {treeRows.map((row) => (
              <li
                key={row.id}
                draggable={editingId !== row.id}
                className={`${row.id === activeId && row.kind === 'doc' ? 'on' : ''}${row.id === railFocusId ? ' focus' : ''}${row.kind === 'folder' ? ' is-folder' : ''}${dragId === row.id ? ' dragging' : ''}${dropTarget === row.id ? ' drop-on' : ''}`}
                style={{ paddingLeft: 4 + row.depth * 14 }}
                onDragStart={(e) => onRailDragStart(e, row.id)}
                onDragEnd={onRailDragEnd}
                onDragOver={(e) => {
                  e.stopPropagation()
                  onRailDragOver(e, row.id)
                }}
                onDrop={(e) => {
                  e.stopPropagation()
                  onRailDrop(e, row.id)
                }}
                title={ko ? '끌어서 다른 폴더로 이동' : 'Drag to another folder'}
              >
                <button
                  type="button"
                  className="doc-rail-item"
                  onClick={() => {
                    if (editingId === row.id) return
                    selectProject(row.id)
                  }}
                >
                  <span className="doc-rail-folder" aria-hidden>
                    {row.kind === 'folder' ? (expanded.has(row.id) ? '▾' : '▸') : '·'}
                  </span>
                  {editingId === row.id ? (
                    <input
                      ref={renameInputRef}
                      className="doc-rail-rename"
                      value={editName}
                      aria-label={ko ? '이름 수정' : 'Rename'}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setEditName(e.target.value)}
                      onBlur={() => commitRename(row.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          commitRename(row.id)
                        }
                        if (e.key === 'Escape') {
                          e.preventDefault()
                          setEditingId(null)
          }
        }}
      />
                  ) : (
                    <span>{row.name}</span>
                  )}
                </button>
                <div className="doc-rail-actions">
                  {row.kind === 'folder' ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        setRailFocusId(row.id)
                        setExpanded((prev) => new Set(prev).add(row.id))
                        const { rows, node } = addDocProject(projectsRef.current, {
                          parentId: row.id,
                          name: ko ? '새 문서' : 'New doc',
                          title: ko ? '새 문서' : 'New document',
                        })
                        commitProject(activeIdRef.current, title, currentEditorBody())
                        projectsRef.current = rows
                        setProjects(rows)
                        applyProjectToEditor(node)
                      }}
                      title={ko ? '안에 문서' : 'Doc inside'}
                    >
                      +
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      startRename(row.id)
                    }}
                    title={ko ? '이름' : 'Rename'}
                  >
                    ✎
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteProject(row.id)
                    }}
                    title={ko ? '삭제' : 'Delete'}
                  >
                    ×
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : null}
      </aside>

      <div className="doc-main">
        <header className="doc-chrome">
          <div className="doc-chrome-left">
            <button type="button" className="icon-btn" onClick={neu.goBack} aria-label="Back">
              ←
            </button>
            <button type="button" className="icon-btn" onClick={neu.goHome} aria-label="Home">
              ⌂
            </button>
      <input
              className="doc-title-input"
        value={title}
        onChange={(e) => {
          setTitle(e.target.value)
          setSaved(false)
        }}
        aria-label="Document title"
            />
            <div className="doc-view-toggle" role="group" aria-label="Editor view">
              <button
                type="button"
                className={surface === 'markdown' ? 'on' : ''}
                onClick={() => switchSurface('markdown')}
              >
                Markdown
              </button>
              <button
                type="button"
                className={surface === 'preview' ? 'on' : ''}
                onClick={() => switchSurface('preview')}
              >
                Preview
              </button>
            </div>
          </div>
          <div className="doc-chrome-right">
            <button
              type="button"
              className={`doc-skin-btn${surface === 'word' ? ' on' : ''}`}
              onClick={() => switchSurface('word')}
              title={ko ? 'MS Word 형식 편집기' : 'MS Word-style editor'}
            >
              Word
            </button>
            <button
              type="button"
              className={`doc-skin-btn${surface === 'gdocs' ? ' on' : ''}`}
              onClick={() => switchSurface('gdocs')}
              title={ko ? 'Google Docs 형식 편집기' : 'Google Docs-style editor'}
            >
              Docs
            </button>
            <select
              className="model-select"
              value={neu.officeModel}
              onChange={(e) => {
                const next = e.target.value
                neu.setOfficeModel(next)
                if (next.startsWith('gpt-')) {
                  setConnectPrefer(next)
                  setConnectOpen(true)
                }
              }}
              aria-label="AI model"
            >
              {OFFICE_MODELS.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.label}
                </option>
              ))}
            </select>
            <AiHealthBadge health={health} ko={ko} onFix={fixHealth} />
            <button
              type="button"
              className="doc-skin-btn"
              onClick={() => {
                setConnectPrefer(neu.officeModel)
                setConnectOpen(true)
              }}
            >
              {ko ? 'AI 연결' : 'Connect AI'}
            </button>
            <div className="doc-save-wrap">
              <button type="button" className="save-btn" data-ui="save" onClick={() => setSaveMenu((v) => !v)}>
                {saved ? (ko ? '저장됨' : 'Saved') : ko ? '저장' : 'Save'}
              </button>
              {saveMenu ? (
                <div className="doc-save-menu" role="menu">
                  <button type="button" onClick={() => void saveAs('md')}>
                    Markdown (.md)
                  </button>
                  <button type="button" onClick={() => void saveAs('txt')}>
                    Text (.txt)
                  </button>
                  <button type="button" onClick={() => void saveAs('rtf')}>
                    Word (.rtf)
                  </button>
                  <button type="button" onClick={() => void saveAs('pdf')}>
                    PDF (.pdf)
                  </button>
                </div>
              ) : null}
            </div>
          </div>
        </header>

        <div className="doc-format-bar">
          <button type="button" className="doc-format-toggle" onClick={() => setFormatOpen((v) => !v)}>
            {formatOpen ? '▾' : '▸'} {ko ? '서식' : 'Format'}
          </button>
          {formatOpen ? (
            <div className="doc-format-tools">
              {FORMAT_TOOLS.map((tool) => (
                <button key={tool.id} type="button" title={tool.title} onClick={() => applyFormat(tool.id)}>
                  {tool.label}
                </button>
              ))}
            </div>
          ) : null}
        </div>

        <div className="doc-work">
          <div className="doc-editor-pane">
            {surface === 'markdown' ? (
      <textarea
                ref={editorRef}
        className="doc-editor"
        data-ui="editor"
                aria-label="Markdown editor"
        value={body}
                placeholder={ko ? '쓰기 시작…  ( / 로 Ask AI )' : 'Start writing…  (type / for Ask AI)'}
        onChange={(e) => {
          setBody(e.target.value)
          setSaved(false)
        }}
                onKeyDown={onEditorKeyDown}
                onContextMenu={(e) => {
                  const selected = body.slice(e.currentTarget.selectionStart, e.currentTarget.selectionEnd)
                  if (!selected.trim()) return
                  e.preventDefault()
                  setCtx({ x: e.clientX, y: e.clientY, selected })
                }}
              />
            ) : (
              <div className={`doc-paper doc-paper-${surface}`}>
                <div
                  ref={richRef}
                  className="doc-rich"
                  data-ui="editor"
                  contentEditable
                  suppressContentEditableWarning
                  role="textbox"
                  aria-multiline
                  aria-label={surface === 'word' ? 'Word editor' : surface === 'gdocs' ? 'Docs editor' : 'Preview editor'}
                  onInput={() => pullRichToBody()}
                  onContextMenu={(e) => {
                    const selected = selectedFromRich()
                    if (!selected.trim()) return
                    e.preventDefault()
                    setCtx({ x: e.clientX, y: e.clientY, selected })
                  }}
                  onKeyDown={(e) => {
                    if (e.key === '/' && !e.ctrlKey && !e.metaKey) {
                      const sel = window.getSelection()
                      const atStart =
                        !sel ||
                        sel.anchorOffset === 0 ||
                        (sel.anchorNode?.textContent || '').slice(0, sel.anchorOffset).endsWith(' ')
                      if (atStart) {
                        e.preventDefault()
                        setSlashAt(body.length)
                        setSlashAsk('')
                        setSlashOpen(true)
                      }
                    }
                    if (e.key === 'Escape') setSlashOpen(false)
                  }}
                />
              </div>
            )}
            {slashOpen ? (
              <div className="doc-slash">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const cleaned = slashAsk.trim()
                    if (!cleaned) return
                    void runAi(cleaned, { insertAt: slashAt })
                    setSlashAsk('')
                  }}
                >
                  <span>/</span>
                  <input
                    autoFocus
                    value={slashAsk}
                    onChange={(e) => setSlashAsk(e.target.value)}
                    placeholder={ko ? '커서 위치에 AI 답변 삽입' : 'Insert AI reply at caret'}
                    disabled={busy || health?.state === 'red'}
                  />
                  <button type="submit" className="save-btn" disabled={busy || !slashAsk.trim() || health?.state === 'red'}>
                    {busy ? '…' : 'AI'}
                  </button>
                  <button type="button" className="btn ghost" onClick={() => setSlashOpen(false)}>
                    Esc
                  </button>
                </form>
              </div>
            ) : null}
          </div>

          <aside className="doc-chat" aria-label="Ask AI thread">
            <AiHealthBanner health={health} ko={ko} onFix={fixHealth} />
            {busy ? (
              <div className="doc-ai-loading" role="status" aria-live="polite">
                <span className="doc-ai-spinner" aria-hidden />
                <div>
                  <strong>
                    {firstToken
                      ? ko
                        ? 'AI가 타이핑 중…'
                        : 'AI is typing…'
                      : ko
                        ? 'AI 로딩 중…'
                        : 'AI loading…'}
                  </strong>
                  <p>
                    {ko
                      ? `경과 ${waitSec}초 · 로컬 llama는 CPU에서 첫 글자까지 오래 걸릴 수 있습니다. 빠른 응답은 「AI 연결」에서 OpenAI 키를 넣으세요.`
                      : `${waitSec}s elapsed · local llama can wait a long time for the first token on CPU. For speed, open Connect AI and add an OpenAI key.`}
                  </p>
                </div>
              </div>
            ) : null}
            <div className="doc-chat-thread">
              {chats.length === 0 ? (
                <p className="doc-chat-empty">{ko ? 'Ask AI 대화가 여기에 이어집니다.' : 'Ask AI turns continue here.'}</p>
              ) : (
                chats.map((turn) => (
                  <div key={turn.id} className={`doc-bubble ${turn.role}`}>
                    <small>{turn.role === 'user' ? 'You' : 'os.neu'}</small>
                    <p>
                      {turn.text ||
                        (busy && turn.role === 'assistant'
                          ? ko
                            ? `로딩 중… ${waitSec}s`
                            : `Loading… ${waitSec}s`
                          : '')}
                    </p>
                  </div>
                ))
              )}
              <div ref={chatEndRef} />
            </div>
            <form
              className="doc-chat-ask"
              onSubmit={(e) => {
                e.preventDefault()
                const line = ask.trim()
                if (!line) return
                void runAi(line)
                setAsk('')
              }}
            >
              <input
                value={ask}
                onChange={(e) => setAsk(e.target.value)}
                placeholder={ko ? 'Ask AI… (이어 질문 가능)' : 'Ask AI… (follow-ups OK)'}
                disabled={busy || health?.state === 'red'}
              />
              <button type="submit" className="save-btn" disabled={busy || !ask.trim() || health?.state === 'red'}>
                {busy ? '…' : 'AI'}
              </button>
            </form>
            {hint ? <p className="dock-hint">{hint}</p> : null}
          </aside>
        </div>
      </div>

      {ctx ? (
        <div className="doc-ctx-layer" onClick={() => setCtx(null)}>
          <div
            className="doc-ctx-menu"
            style={{ left: Math.min(ctx.x, window.innerWidth - 220), top: Math.min(ctx.y, window.innerHeight - 220) }}
            onClick={(e) => e.stopPropagation()}
            role="menu"
          >
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                void runAi(ko ? '더 멋진 글로 다시 써 주세요' : 'Rewrite this more polished', {
                  mode: 'rewrite',
                  selection: ctx.selected,
                })
              }
            >
              {ko ? '더 멋지게' : 'Make polished'}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                void runAi(ko ? '문체를 부드럽게 바꿔 주세요' : 'Rewrite in a softer tone', {
                  mode: 'rewrite',
                  selection: ctx.selected,
                })
              }
            >
              {ko ? '문체 변경' : 'Change tone'}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                void runAi(ko ? '마크다운 표로 바꿔 주세요' : 'Turn into a markdown table', {
                  mode: 'rewrite',
                  selection: ctx.selected,
                })
              }
            >
              {ko ? '표로' : 'As table'}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                void runAi(ko ? '짧게 요약해 주세요' : 'Summarize briefly', {
                  mode: 'rewrite',
                  selection: ctx.selected,
                })
              }
            >
              {ko ? '요약' : 'Summarize'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (richMode) {
                  document.execCommand('bold')
                  pullRichToBody()
                  setCtx(null)
                } else wrapSelection('**', '**')
              }}
            >
              {ko ? '굵게' : 'Bold'}
            </button>
          </div>
        </div>
      ) : null}

      <AiConnectDialog
        open={connectOpen}
        preferModel={connectPrefer}
        onClose={() => {
          setConnectOpen(false)
          void refreshHealth()
        }}
      />
    </div>
  )
}
