import type { AiHealth } from '../engine/llmConnect'

type Props = {
  health: AiHealth | null
  ko: boolean
  onFix: () => void
}

/** Small persistent GREEN/YELLOW/RED pill — the AI Health Contract must never fail silently. */
export function AiHealthBadge({ health, ko, onFix }: Props) {
  if (!health) return null
  return (
    <button
      type="button"
      className={`ai-health-pill ai-health-${health.state}`}
      onClick={onFix}
      title={ko ? health.detailKo : health.detail}
      data-ui="ai-health-badge"
      data-health={health.state}
    >
      <span className="ai-health-dot" aria-hidden />
      {ko ? health.labelKo : health.label}
    </button>
  )
}

/** Banner shown above the Ask AI thread when the contract is not GREEN. Silence is not allowed here. */
export function AiHealthBanner({ health, ko, onFix }: Props) {
  if (!health || health.state === 'green') return null
  return (
    <div
      className={`ai-health-banner ai-health-${health.state}`}
      role={health.state === 'red' ? 'alert' : 'status'}
      data-ui="ai-health-banner"
      data-health={health.state}
    >
      <p>
        <code>{health.code}</code> {ko ? health.detailKo : health.detail}
      </p>
      {health.fix ? (
        <button type="button" className="btn ghost ai-health-fix" onClick={onFix}>
          {health.fix === 'retry' ? (ko ? '다시 시도' : 'Retry') : ko ? 'AI 연결' : 'Connect AI'}
        </button>
      ) : null}
    </div>
  )
}
