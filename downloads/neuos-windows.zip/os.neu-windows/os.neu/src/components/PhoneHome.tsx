import { WEB_HOME } from '../engine/browser'
import { useNeu } from '../state/store'
import { useI18n } from '../i18n/LocaleContext'
import { trackEvent } from '../engine/auth'
import { BrandTitle } from './BrandTitle'
import { BrowserGlyph } from './PathGlyphs'
import { StepNav } from './StepNav'
import type { ReactNode } from 'react'

export function PhoneHome() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const apps: Array<{
    id: string
    glyph: string
    icon: ReactNode
    label: string
    run: () => void
  }> = [
    { id: 'doc', glyph: 'W', icon: null, label: locale === 'ko' ? '문서' : 'Docs', run: () => neu.openOffice('doc') },
    { id: 'sheet', glyph: 'X', icon: null, label: locale === 'ko' ? '시트' : 'Sheets', run: () => neu.openOffice('sheet') },
    { id: 'slides', glyph: 'P', icon: null, label: locale === 'ko' ? '슬라이드' : 'Slides', run: () => neu.openOffice('slides') },
    {
      id: 'web',
      glyph: '',
      icon: <BrowserGlyph />,
      label: 'daf.neu',
      // WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): real front window
      // (Electron child / hosted-web window.open) — see openDaf() in
      // state/store.tsx.
      run: () => neu.openDaf(WEB_HOME),
    },
    { id: 'health', glyph: '○', icon: null, label: copy.health, run: () => neu.go('post') },
    { id: 'layers', glyph: '▣', icon: null, label: copy.layers, run: () => neu.go('studio') },
  ]

  return (
    <div className="landing">
      <div className="hero-block">
        <BrandTitle />
        <p>{copy.homeIntro}</p>
      </div>
      <div className="app-grid">
        {apps.map((app) => (
          <button
            key={app.id}
            type="button"
            className={`app-tile${app.id === 'web' ? ' is-browser' : ''}`}
            onClick={() => {
              void trackEvent('click', 'landing', app.id)
              app.run()
            }}
          >
            <span className="glyph">{app.icon || app.glyph}</span>
            {app.label}
          </button>
        ))}
      </div>
      {!neu.network.online ? (
        <p className="offline-note">{copy.offlineHint}</p>
      ) : (
        <p className="offline-note" style={{ color: 'var(--mint)', borderColor: 'var(--mint)' }}>
          {copy.onlineHint}
        </p>
      )}
      <StepNav onBack={() => neu.go('announce')} />
    </div>
  )
}
