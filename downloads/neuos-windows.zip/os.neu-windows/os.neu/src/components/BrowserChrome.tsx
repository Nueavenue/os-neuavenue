import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { BrowseDownloadPanel } from './BrowseDownloadPanel'
import { BrowseHistoryPanel } from './BrowseHistoryPanel'
import { BrowseToolsPanel } from './BrowseToolsPanel'
import type { AssignedTool, DownloadRecord, VisitRecord } from '../engine/browseLedger'
import type { BookmarkFolder, BookmarkItem } from '../engine/bookmarks'
import { faviconForHost, framePreview, type FramePreview } from '../engine/framePreview'

export type BrowserTab = {
  id: string
  title: string
  url: string
}

export type BrowserAccount = {
  name: string
  email: string
}

export type ChromeMenu = 'none' | 'history' | 'bookmarks' | 'account' | 'downloads' | 'tools' | 'bar-folder'

function BookmarkMegaPreview({ url, title, ko }: { url: string; title: string; ko: boolean }) {
  const staticPreview = framePreview(url)
  const skipProbe =
    staticPreview.kind === 'card' ||
    (staticPreview.kind === 'iframe' && staticPreview.src.includes('youtube-nocookie.com'))
  const [shown, setShown] = useState<FramePreview | { kind: 'checking'; host: string }>(() =>
    skipProbe ? staticPreview : { kind: 'checking', host: staticPreview.host },
  )

  useEffect(() => {
    const next = framePreview(url)
    if (next.kind === 'card' || (next.kind === 'iframe' && next.src.includes('youtube-nocookie.com'))) {
      setShown(next)
      return
    }
    const probe = window.neuos?.browse?.framePolicy
    if (!probe) {
      setShown(next)
      return
    }
    setShown({ kind: 'checking', host: next.host })
    let cancelled = false
    void probe(url)
      .then((res) => {
        if (cancelled) return
        if (res?.blocked) setShown({ kind: 'card', host: next.host })
        else setShown(next)
      })
      .catch(() => {
        if (!cancelled) setShown({ kind: 'card', host: next.host })
      })
    return () => {
      cancelled = true
    }
  }, [url])

  return (
    <>
      <strong>{title}</strong>
      <span>{shown.host}</span>
      <em>{url}</em>
      {shown.kind === 'iframe' && shown.src ? (
        <iframe
          className="bookmark-mega-frame"
          title={title}
          src={shown.src}
          sandbox="allow-scripts allow-same-origin"
          tabIndex={-1}
        />
      ) : (
        <div className="bookmark-mega-fallback">
          <img src={faviconForHost(shown.host)} alt="" width={32} height={32} />
          <b>{title}</b>
          <p>
            {shown.kind === 'checking'
              ? ko
                ? '미리보기 가능 여부 확인 중…'
                : 'Checking whether preview is allowed…'
              : ko
                ? '미리보기 없음 — 이 사이트는 iframe을 막습니다.'
                : 'No preview — this site blocks iframes.'}
          </p>
        </div>
      )}
    </>
  )
}

type BrowserChromeProps = {
  tabs: BrowserTab[]
  activeId: string
  url: string
  visits: VisitRecord[]
  bookmarkFolders: BookmarkFolder[]
  bookmarkItems: BookmarkItem[]
  downloads: DownloadRecord[]
  tools: AssignedTool[]
  account: BrowserAccount | null
  ko: boolean
  locale: string
  electron: boolean
  onSelectTab: (id: string) => void
  onNewTab: () => void
  onCloseTab: (id: string) => void
  onNewWindow: () => void
  onUrl: (url: string) => void
  onAddressPanel?: () => void
  onHome: () => void
  onBack: () => void
  onForward?: () => void
  onReload?: () => void
  onZoom?: (delta: 'in' | 'out' | 'reset') => void | Promise<{ ok?: boolean; zoom?: number } | void>
  onBookmark: (folderId?: string | null) => void
  onAddBookmark: (url: string, title: string, folderId?: string | null) => void
  onEditBookmark: (id: string, patch: { url: string; title: string }) => void
  onDeleteBookmark: (id: string) => void
  onAddFolder: (title: string) => void
  onToggleFolderCollapsed: (id: string) => void
  onOpenBookmarksManager: () => void
  onOpenSaved: (url: string) => void
  onAddVisit: (url: string, title: string) => void
  onEditVisit: (id: string, patch: { url: string; title: string }) => void
  onDeleteVisit: (id: string) => void
  onOpenDownload: (id: string) => void
  onShowDownload: (id: string) => void
  onRunTool: (tool: AssignedTool) => void
  onRequestSignIn: () => void
  onAskIdentity?: () => void
  onSignOut: () => void
  openMenu?: ChromeMenu
  onMenuChange?: (menu: ChromeMenu) => void
  onFlyoutBounds?: (rect: { x: number; y: number; width: number; height: number } | null) => void
  onPrepareOverlay?: () => Promise<void>
  children: ReactNode
}

export function BrowserChrome(props: BrowserChromeProps) {
  const {
    tabs,
    activeId,
    url,
    visits,
    bookmarkFolders,
    bookmarkItems,
    downloads,
    tools,
    account,
    ko,
    locale,
    electron,
    onSelectTab,
    onNewTab,
    onCloseTab,
    onNewWindow,
    onUrl,
    onAddressPanel,
    onHome,
    onBack,
    onForward,
    onReload,
    onZoom,
    onBookmark,
    onAddBookmark,
    onEditBookmark,
    onDeleteBookmark,
    onAddFolder,
    onToggleFolderCollapsed,
    onOpenBookmarksManager,
    onOpenSaved,
    onAddVisit,
    onEditVisit,
    onDeleteVisit,
    onOpenDownload,
    onShowDownload,
    onRunTool,
    onRequestSignIn,
    onAskIdentity,
    onSignOut,
    openMenu,
    onMenuChange,
    onFlyoutBounds,
    onPrepareOverlay,
    children,
  } = props

  const [menu, setMenu] = useState<ChromeMenu>('none')
  const [zoomPct, setZoomPct] = useState(100)
  const [bmTitle, setBmTitle] = useState('')
  const [bmUrl, setBmUrl] = useState('')
  const [bmEditId, setBmEditId] = useState<string | null>(null)
  const [bmDraft, setBmDraft] = useState({ title: '', url: '' })
  const [bmNewFolder, setBmNewFolder] = useState('')
  const [bmFolderId, setBmFolderId] = useState('')
  const [bmSelected, setBmSelected] = useState<Set<string>>(new Set())
  const [barOpenFolder, setBarOpenFolder] = useState<string | null>(null)
  const [barHoverId, setBarHoverId] = useState<string | null>(null)
  const [caretX, setCaretX] = useState(24)
  const [flyoutLeft, setFlyoutLeft] = useState(10)
  const [flyoutTop, setFlyoutTop] = useState(80)
  const [flyoutWidth, setFlyoutWidth] = useState(260)
  const [flyoutHeight, setFlyoutHeight] = useState(420)
  const dropRef = useRef<HTMLDivElement>(null)
  const flyoutRef = useRef<HTMLDivElement>(null)
  const flyoutAnchorRef = useRef<HTMLElement | null>(null)
  const flyoutVariantRef = useRef<'toolbar' | 'bar-folder'>('toolbar')

  const placeFlyout = (anchor: HTMLElement | null) => {
    if (!anchor) return
    const btn = anchor.getBoundingClientRect()
    const pane = document.querySelector('.browse-stage')?.getBoundingClientRect()
    const shell = dropRef.current?.getBoundingClientRect()
    const area = pane ?? shell ?? new DOMRect(0, 0, window.innerWidth, window.innerHeight)
    // Slightly longer than the old ~1/6 card; fill the freed side strip.
    const width = Math.round(Math.min(340, Math.max(250, area.width / 5)))
    const left = Math.round(area.right - width - 8)
    const top = Math.round(Math.min(btn.bottom + 6, area.top + 8))
    const height = Math.round(Math.max(280, area.bottom - top - 8))
    const center = btn.left + btn.width / 2
    setFlyoutWidth(width)
    setFlyoutLeft(Math.max(8, left))
    setFlyoutTop(top)
    setFlyoutHeight(height)
    setCaretX(Math.round(Math.min(width - 16, Math.max(16, center - left))))
  }

  // The bookmarks-bar folder popover anchors directly under the clicked
  // folder chip (left-aligned to it), not pinned to the browser's right edge
  // like the toolbar flyouts — it's a small card, not a full panel — and it
  // reuses the exact same portal/positioning/z-order mechanism as those
  // flyouts instead of a bespoke absolutely-positioned <div> (which kept
  // failing to actually show its list under Electron's BrowserView, reported
  // repeatedly on 2026-09-02).
  const placeBarFolderFlyout = (anchor: HTMLElement | null) => {
    if (!anchor) return
    const btn = anchor.getBoundingClientRect()
    const pane = document.querySelector('.browse-stage')?.getBoundingClientRect()
    const shell = dropRef.current?.getBoundingClientRect()
    const area = pane ?? shell ?? new DOMRect(0, 0, window.innerWidth, window.innerHeight)
    const width = Math.round(
      Math.min(640, area.width - 16, Math.max(Math.min(480, area.width - 16), area.width * 0.46)),
    )
    const left = Math.round(Math.min(Math.max(btn.left, area.left + 8), area.right - width - 8))
    const top = Math.round(btn.bottom + 6)
    const height = Math.round(Math.max(280, Math.min(420, area.bottom - top - 12)))
    const center = btn.left + btn.width / 2
    setFlyoutWidth(width)
    setFlyoutLeft(Math.max(8, left))
    setFlyoutTop(top)
    setFlyoutHeight(height)
    setCaretX(Math.round(Math.min(width - 16, Math.max(16, center - left))))
  }

  const openMenuAt = (next: ChromeMenu, anchor: HTMLElement | null) => {
    setMenu((cur) => (cur === next ? 'none' : next))
    flyoutAnchorRef.current = anchor
    flyoutVariantRef.current = 'toolbar'
    if (anchor) placeFlyout(anchor)
  }

  const openBarFolder = (folderId: string, anchor: HTMLElement | null) => {
    const closing = menu === 'bar-folder' && barOpenFolder === folderId
    const go = () => {
      setMenu(closing ? 'none' : 'bar-folder')
      setBarOpenFolder(closing ? null : folderId)
      setBarHoverId(null)
      flyoutAnchorRef.current = anchor
      flyoutVariantRef.current = 'bar-folder'
      if (!closing && anchor) placeBarFolderFlyout(anchor)
    }
    if (!closing && onPrepareOverlay) {
      void onPrepareOverlay().finally(go)
      return
    }
    go()
  }

  useEffect(() => {
    if (openMenu && openMenu !== 'none') setMenu(openMenu)
  }, [openMenu])

  // Flyout cards (tools/bookmarks/history/downloads) are placed once, from
  // the anchor button's position, when opened. Left alone, a card stayed
  // pinned to that first spot instead of tracking the browser's right edge
  // when the window was resized while it was open — it should behave like a
  // child of the browser chrome, not a fixed page element (Leader verify,
  // 2026-09-02). Re-run placement on window resize and on the browsing pane's
  // own size changes (covers devtools docking too) while a card is open.
  useEffect(() => {
    if (menu === 'none' || menu === 'account') return
    const reposition = () => {
      if (!flyoutAnchorRef.current) return
      if (flyoutVariantRef.current === 'bar-folder') placeBarFolderFlyout(flyoutAnchorRef.current)
      else placeFlyout(flyoutAnchorRef.current)
    }
    window.addEventListener('resize', reposition)
    const pane = document.querySelector('.browse-stage')
    const ro = pane ? new ResizeObserver(reposition) : null
    if (pane && ro) ro.observe(pane)
    return () => {
      window.removeEventListener('resize', reposition)
      ro?.disconnect()
    }
  }, [menu])

  useEffect(() => {
    onMenuChange?.(menu)
  }, [menu, onMenuChange])

  useLayoutEffect(() => {
    if (menu === 'none' || menu === 'account' || menu === 'bar-folder') {
      onFlyoutBounds?.(null)
      return
    }
    const node = flyoutRef.current
    if (!node) {
      onFlyoutBounds?.(null)
      return
    }
    const sync = () => {
      const box = node.getBoundingClientRect()
      onFlyoutBounds?.({
        x: Math.round(box.left),
        y: Math.round(box.top),
        width: Math.round(box.width),
        height: Math.round(box.height),
      })
    }
    sync()
    const ro = new ResizeObserver(sync)
    ro.observe(node)
    return () => {
      ro.disconnect()
      onFlyoutBounds?.(null)
    }
  }, [
    menu,
    flyoutLeft,
    flyoutTop,
    flyoutWidth,
    flyoutHeight,
    bookmarkItems.length,
    bookmarkFolders.length,
    visits.length,
    downloads.length,
    tools.length,
    onFlyoutBounds,
  ])

  useEffect(() => {
    if (menu === 'none' || menu === 'account') return
    const onDoc = (event: MouseEvent) => {
      const target = event.target as Node
      if (dropRef.current?.contains(target)) return
      if (flyoutRef.current?.contains(target)) return
      setMenu('none')
      setBarOpenFolder(null)
    }
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenu('none')
    }
    const timer = window.setTimeout(() => {
      document.addEventListener('mousedown', onDoc)
    }, 0)
    document.addEventListener('keydown', onKey)
    return () => {
      window.clearTimeout(timer)
      document.removeEventListener('mousedown', onDoc)
      document.removeEventListener('keydown', onKey)
    }
  }, [menu])

  const applyZoom = async (delta: 'in' | 'out' | 'reset') => {
    if (!onZoom) return
    const result = await onZoom(delta)
    if (result && typeof result === 'object' && typeof result.zoom === 'number') {
      setZoomPct(Math.round(result.zoom * 100))
      return
    }
    setZoomPct((cur) => {
      if (delta === 'in') return Math.min(300, cur + 10)
      if (delta === 'out') return Math.max(50, cur - 10)
      return 100
    })
  }

  const flyoutBody =
    menu === 'history' ? (
      <BrowseHistoryPanel
        visits={visits}
        ko={ko}
        locale={locale}
        onOpen={(href) => {
          setMenu('none')
          onOpenSaved(href)
        }}
        onAdd={onAddVisit}
        onEdit={onEditVisit}
        onDelete={onDeleteVisit}
      />
    ) : menu === 'downloads' ? (
      <BrowseDownloadPanel
        downloads={downloads}
        ko={ko}
        locale={locale}
        electron={electron}
        onOpenFile={onOpenDownload}
        onShowFile={onShowDownload}
        onOpenUrl={(href) => {
          setMenu('none')
          onOpenSaved(href)
        }}
      />
    ) : menu === 'tools' ? (
      <BrowseToolsPanel
        tools={tools}
        ko={ko}
        signedIn={Boolean(account)}
        onRun={(tool) => {
          setMenu('none')
          onRunTool(tool)
        }}
      />
    ) : menu === 'bookmarks' ? (
      <div className="browser-panel browser-panel-float">
        <div className="browser-panel-head">
          <b>{ko ? '북마크' : 'Bookmarks'}</b>
          <button type="button" className="icon-btn" aria-label="Close" onClick={() => setMenu('none')}>
            ×
          </button>
        </div>
        <button
          type="button"
          className="btn ghost bm-flyout-manage"
          onClick={() => {
            setMenu('none')
            onOpenBookmarksManager()
          }}
        >
          {ko ? '북마크 관리자 열기…' : 'Open bookmarks manager…'}
        </button>
        <form
          className="browser-panel-add"
          onSubmit={(event) => {
            event.preventDefault()
            const nextUrl = bmUrl.trim() || url
            if (!nextUrl) return
            onAddBookmark(nextUrl, bmTitle.trim() || nextUrl, bmFolderId || null)
            setBmTitle('')
            setBmUrl('')
          }}
        >
          <input value={bmTitle} onChange={(e) => setBmTitle(e.target.value)} placeholder={ko ? '이름' : 'Name'} />
          <input
            value={bmUrl}
            onChange={(e) => setBmUrl(e.target.value)}
            placeholder={ko ? '주소 (비우면 현재 페이지)' : 'URL (blank = this page)'}
          />
          {bookmarkFolders.length ? (
            <select
              aria-label={ko ? '폴더 선택' : 'Folder'}
              value={bmFolderId}
              onChange={(e) => setBmFolderId(e.target.value)}
              className="bm-folder-select"
            >
              <option value="">{ko ? '(폴더 없음)' : '(No folder)'}</option>
              {bookmarkFolders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.title}
                </option>
              ))}
            </select>
          ) : null}
          <button type="submit" className="btn">
            {ko ? '추가' : 'Add'}
          </button>
          <button type="button" className="btn ghost" onClick={() => onBookmark(bmFolderId || null)}>
            {ko ? '현재 페이지 ★' : 'This page ★'}
          </button>
        </form>
        <form
          className="browser-panel-add bm-flyout-new-folder"
          onSubmit={(event) => {
            event.preventDefault()
            const title = bmNewFolder.trim()
            if (!title) return
            onAddFolder(title)
            setBmNewFolder('')
          }}
        >
          <input
            value={bmNewFolder}
            onChange={(e) => setBmNewFolder(e.target.value)}
            placeholder={ko ? '새 폴더' : 'New folder'}
          />
          <button type="submit" className="btn ghost">
            {ko ? '＋ 폴더' : '+ Folder'}
          </button>
        </form>
        {bookmarkItems.length ? (
          <div className="browser-bulk-bar">
            <label className="browser-bulk-all">
              <input
                type="checkbox"
                checked={bmSelected.size > 0 && bmSelected.size === bookmarkItems.length}
                onChange={() =>
                  setBmSelected((prev) =>
                    prev.size === bookmarkItems.length ? new Set() : new Set(bookmarkItems.map((it) => it.id)),
                  )
                }
              />
              {ko ? '전체 선택' : 'Select all'}
            </label>
            <button
              type="button"
              className="btn ghost browser-bulk-delete"
              disabled={!bmSelected.size}
              onClick={() => {
                bmSelected.forEach((id) => onDeleteBookmark(id))
                setBmSelected(new Set())
              }}
            >
              {ko ? `선택 삭제 (${bmSelected.size})` : `Delete selected (${bmSelected.size})`}
            </button>
          </div>
        ) : null}
        {bookmarkFolders.map((folder) => {
          const kids = bookmarkItems.filter((it) => it.folderId === folder.id)
          return (
            <div key={folder.id} className="browser-folder">
              <button type="button" className="browser-folder-head" onClick={() => onToggleFolderCollapsed(folder.id)}>
                <span className="browser-folder-caret">{folder.collapsed ? '▸' : '▾'}</span>
                <span className="browser-folder-icon" aria-hidden>
                  📁
                </span>
                <span className="browser-folder-title">{folder.title}</span>
                <span className="dock-hint">({kids.length})</span>
              </button>
              {folder.collapsed ? null : kids.length ? (
                <div className="browser-folder-body">
                  {kids.map((item) =>
                    bmEditId === item.id ? (
                      <form
                        key={item.id}
                        className="browser-edit"
                        onSubmit={(event) => {
                          event.preventDefault()
                          onEditBookmark(item.id, bmDraft)
                          setBmEditId(null)
                        }}
                      >
                        <input value={bmDraft.title} onChange={(e) => setBmDraft({ ...bmDraft, title: e.target.value })} />
                        <input value={bmDraft.url} onChange={(e) => setBmDraft({ ...bmDraft, url: e.target.value })} />
                        <button type="submit" className="btn">
                          {ko ? '저장' : 'Save'}
                        </button>
                        <button type="button" className="btn ghost" onClick={() => setBmEditId(null)}>
                          {ko ? '취소' : 'Cancel'}
                        </button>
                      </form>
                    ) : (
                      <div key={item.id} className="browser-row">
                        <input
                          type="checkbox"
                          className="browser-row-check"
                          aria-label={ko ? '선택' : 'Select'}
                          checked={bmSelected.has(item.id)}
                          onChange={() =>
                            setBmSelected((prev) => {
                              const next = new Set(prev)
                              if (next.has(item.id)) next.delete(item.id)
                              else next.add(item.id)
                              return next
                            })
                          }
                        />
                        <button
                          type="button"
                          className="browser-row-main"
                          onClick={() => {
                            setMenu('none')
                            onOpenSaved(item.url)
                          }}
                        >
                          <strong>{item.title}</strong>
                          <span>{item.url}</span>
                        </button>
                        <button
                          type="button"
                          className="icon-btn"
                          aria-label={ko ? '수정' : 'Edit'}
                          title={ko ? '수정' : 'Edit'}
                          onClick={() => {
                            setBmEditId(item.id)
                            setBmDraft({ title: item.title, url: item.url })
                          }}
                        >
                          ✎
                        </button>
                        <button
                          type="button"
                          className="icon-btn"
                          aria-label={ko ? '삭제' : 'Delete'}
                          title={ko ? '삭제' : 'Delete'}
                          onClick={() => onDeleteBookmark(item.id)}
                        >
                          ×
                        </button>
                      </div>
                    ),
                  )}
                </div>
              ) : (
                <p className="dock-hint browser-folder-empty">{ko ? '비어 있음' : 'Empty'}</p>
              )}
            </div>
          )
        })}
        {bookmarkItems.filter((it) => !it.folderId).length ? (
          bookmarkItems
            .filter((it) => !it.folderId)
            .map((item) =>
              bmEditId === item.id ? (
                <form
                  key={item.id}
                  className="browser-edit"
                  onSubmit={(event) => {
                    event.preventDefault()
                    onEditBookmark(item.id, bmDraft)
                    setBmEditId(null)
                  }}
                >
                  <input value={bmDraft.title} onChange={(e) => setBmDraft({ ...bmDraft, title: e.target.value })} />
                  <input value={bmDraft.url} onChange={(e) => setBmDraft({ ...bmDraft, url: e.target.value })} />
                  <button type="submit" className="btn">
                    {ko ? '저장' : 'Save'}
                  </button>
                  <button type="button" className="btn ghost" onClick={() => setBmEditId(null)}>
                    {ko ? '취소' : 'Cancel'}
                  </button>
                </form>
              ) : (
                <div key={item.id} className="browser-row">
                  <input
                    type="checkbox"
                    className="browser-row-check"
                    aria-label={ko ? '선택' : 'Select'}
                    checked={bmSelected.has(item.id)}
                    onChange={() =>
                      setBmSelected((prev) => {
                        const next = new Set(prev)
                        if (next.has(item.id)) next.delete(item.id)
                        else next.add(item.id)
                        return next
                      })
                    }
                  />
                  <button
                    type="button"
                    className="browser-row-main"
                    onClick={() => {
                      setMenu('none')
                      onOpenSaved(item.url)
                    }}
                  >
                    <strong>{item.title}</strong>
                    <span>{item.url}</span>
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    aria-label={ko ? '수정' : 'Edit'}
                    title={ko ? '수정' : 'Edit'}
                    onClick={() => {
                      setBmEditId(item.id)
                      setBmDraft({ title: item.title, url: item.url })
                    }}
                  >
                    ✎
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    aria-label={ko ? '삭제' : 'Delete'}
                    title={ko ? '삭제' : 'Delete'}
                    onClick={() => onDeleteBookmark(item.id)}
                  >
                    ×
                  </button>
                </div>
              ),
            )
        ) : bookmarkFolders.length ? null : (
          <p className="dock-hint">
            {ko ? '추가하거나 ★로 현재 페이지를 저장하세요.' : 'Add a bookmark or star this page.'}
          </p>
        )}
      </div>
    ) : menu === 'bar-folder' && barOpenFolder ? (
      <div className="browser-panel browser-panel-float bar-folder-flyout bookmark-mega">
        <div className="browser-panel-head">
          <b>{bookmarkFolders.find((f) => f.id === barOpenFolder)?.title ?? (ko ? '폴더' : 'Folder')}</b>
          <button
            type="button"
            className="icon-btn"
            aria-label="Close"
            onClick={() => {
              setMenu('none')
              setBarOpenFolder(null)
              setBarHoverId(null)
            }}
          >
            ×
          </button>
        </div>
        {bookmarkItems.filter((it) => it.folderId === barOpenFolder).length ? (
          <div className="bookmark-mega-body">
            <div className="bookmark-mega-list">
              {bookmarkItems
                .filter((it) => it.folderId === barOpenFolder)
                .map((item) => (
                  <div
                    key={item.id}
                    className={`browser-row${barHoverId === item.id ? ' on' : ''}`}
                    onMouseEnter={() => setBarHoverId(item.id)}
                  >
                    <button
                      type="button"
                      className="browser-row-main"
                      onClick={() => {
                        setMenu('none')
                        setBarOpenFolder(null)
                        setBarHoverId(null)
                        onOpenSaved(item.url)
                      }}
                    >
                      <strong>{item.title}</strong>
                      <span>{item.url}</span>
                    </button>
                  </div>
                ))}
            </div>
            <button
              type="button"
              className="bookmark-mega-preview"
              onClick={() => {
                const kids = bookmarkItems.filter((it) => it.folderId === barOpenFolder)
                const shown = kids.find((it) => it.id === barHoverId) ?? kids[0]
                if (!shown) return
                setMenu('none')
                setBarOpenFolder(null)
                setBarHoverId(null)
                onOpenSaved(shown.url)
              }}
            >
              {(() => {
                const kids = bookmarkItems.filter((it) => it.folderId === barOpenFolder)
                const shown = kids.find((it) => it.id === barHoverId) ?? kids[0]
                if (!shown) return null
                return <BookmarkMegaPreview url={shown.url} title={shown.title} ko={ko} />
              })()}
            </button>
          </div>
        ) : (
          <p className="dock-hint">{ko ? '비어 있음' : 'Empty'}</p>
        )}
      </div>
    ) : null

  return (
    <section className="browser">
      <div className="browser-chrome-shell" ref={dropRef}>
        <div className="browser-tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              className={`browser-tab${tab.id === activeId ? ' on' : ''}`}
              onClick={() => onSelectTab(tab.id)}
            >
              <span>{tab.title || 'New tab'}</span>
              {tabs.length > 1 ? (
                <i
                  role="presentation"
                  onClick={(e) => {
                    e.stopPropagation()
                    onCloseTab(tab.id)
                  }}
                >
                  ×
                </i>
              ) : null}
            </button>
          ))}
          <button type="button" className="icon-btn" aria-label="New tab" onClick={onNewTab}>
            +
          </button>
          <span className="browser-tabs-spacer" />
          <button
            type="button"
            className={`icon-btn${menu === 'downloads' ? ' on' : ''}`}
            aria-label={ko ? '다운로드' : 'Downloads'}
            title={ko ? '다운로드' : 'Downloads'}
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              openMenuAt('downloads', e.currentTarget)
            }}
          >
            ↓
          </button>
        </div>
        <form
          className="browser-bar"
          onSubmit={(e) => {
            e.preventDefault()
            const data = new FormData(e.currentTarget)
            onUrl(String(data.get('url') ?? ''))
          }}
        >
          <button type="button" className="icon-btn" aria-label="Back" onClick={onBack}>
            ←
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Forward"
            title={ko ? '앞으로' : 'Forward'}
            onClick={() => onForward?.()}
            disabled={!onForward}
          >
            →
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Reload"
            title={ko ? '새로고침' : 'Reload'}
            onClick={() => onReload?.()}
            disabled={!onReload}
          >
            ↻
          </button>
          <button type="button" className="icon-btn" aria-label="Home" onClick={onHome}>
            ⌂
          </button>
          <input
            name="url"
            data-ui="url"
            aria-label="Address bar"
            defaultValue={url}
            key={url}
            placeholder="Address or what you want to do"
            onFocus={() => onAddressPanel?.()}
            onClick={() => onAddressPanel?.()}
          />
          <button type="submit" className="icon-btn" aria-label="Go">
            Go
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Zoom out"
            title={ko ? '축소' : 'Zoom out'}
            onClick={() => void applyZoom('out')}
            disabled={!onZoom}
          >
            −
          </button>
          <button
            type="button"
            className="icon-btn zoom-pct"
            aria-label="Zoom reset"
            title={ko ? '배율 원래대로' : 'Reset zoom'}
            onClick={() => void applyZoom('reset')}
            disabled={!onZoom}
          >
            {zoomPct}%
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Zoom in"
            title={ko ? '확대' : 'Zoom in'}
            onClick={() => void applyZoom('in')}
            disabled={!onZoom}
          >
            +
          </button>
          <button
            type="button"
            className={`icon-btn${menu === 'bookmarks' ? ' on' : ''}`}
            aria-label={ko ? '북마크' : 'Bookmarks'}
            title={ko ? '북마크' : 'Bookmarks'}
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              openMenuAt('bookmarks', e.currentTarget)
            }}
          >
            ★
          </button>
          <button
            type="button"
            className={`icon-btn${menu === 'history' ? ' on' : ''}`}
            aria-label="History"
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              openMenuAt('history', e.currentTarget)
            }}
          >
            ⟳
          </button>
          <button
            type="button"
            className={`icon-btn${menu === 'tools' ? ' on' : ''}`}
            aria-label={ko ? '도구' : 'Tools'}
            title={ko ? '배정된 도구' : 'Assigned tools'}
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              openMenuAt('tools', e.currentTarget)
            }}
          >
            ⌗
          </button>
          <button type="button" className="icon-btn" aria-label="New window" onClick={onNewWindow} title="New window">
            ▭
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label={ko ? '아이디로 들어가기' : 'Enter with an id'}
            title={ko ? '아이디로 들어가기' : 'Enter with an id'}
            onClick={() => onAskIdentity?.()}
          >
            ID
          </button>
          <button
            type="button"
            className="icon-btn account-btn"
            onClick={() => {
              if (account) openMenuAt('account', null)
              else onRequestSignIn()
            }}
          >
            {account ? account.name.slice(0, 1).toUpperCase() : '👤'}
          </button>
        </form>
        {bookmarkFolders.length || bookmarkItems.length ? (
          <div className="bookmarks-bar">
            {bookmarkItems
              .filter((it) => !it.folderId)
              .map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="bookmarks-bar-item"
                  title={item.url}
                  onClick={() => onOpenSaved(item.url)}
                >
                  <span className="bookmarks-bar-star" aria-hidden>
                    ★
                  </span>
                  {item.title}
                </button>
              ))}
            {bookmarkFolders.map((folder) => (
              <button
                key={folder.id}
                type="button"
                className={`bookmarks-bar-item bookmarks-bar-folder${menu === 'bar-folder' && barOpenFolder === folder.id ? ' on' : ''}`}
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  openBarFolder(folder.id, e.currentTarget)
                }}
              >
                <span aria-hidden>📁</span>
                {folder.title}
                <span className="bookmarks-bar-caret" aria-hidden>
                  ▾
                </span>
              </button>
            ))}
          </div>
        ) : null}
      </div>
      {flyoutBody
        ? createPortal(
            <div
              ref={flyoutRef}
              className={`browser-flyout${menu === 'bar-folder' ? ' bookmark-mega-flyout' : ''}`}
              style={{
                top: flyoutTop,
                left: flyoutLeft,
                width: flyoutWidth,
                height: flyoutHeight,
                ['--caret-x' as string]: `${caretX}px`,
              }}
            >
              <span className="browser-flyout-caret" aria-hidden />
              {flyoutBody}
            </div>,
            document.body,
          )
        : null}
      {menu === 'account' && account
        ? createPortal(
            <div className="auth-layer" onClick={() => setMenu('none')}>
              <div className="auth-modal" role="dialog" onClick={(event) => event.stopPropagation()}>
                <h3>Signed in</h3>
                <p className="dock-hint">
                  {account.name}
                  <br />
                  {account.email}
                </p>
                <div className="row-actions">
                  <button type="button" className="btn ghost" onClick={() => setMenu('none')}>
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn"
                    onClick={() => {
                      setMenu('none')
                      onSignOut()
                    }}
                  >
                    Sign out
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
      {children}
    </section>
  )
}
