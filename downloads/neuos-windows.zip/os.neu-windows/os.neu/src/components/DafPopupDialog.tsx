import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

/**
 * WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND).
 *
 * Hosted web has no Electron IPC window, so the daf.neu tile opens a real
 * browser tab with `window.open` (user gesture, see `openDaf()` in
 * state/store.tsx). If the browser's own popup blocker ate that call, we do
 * not silently fall back to same-page navigation — that is exactly the
 * "GAP" Control verified (Leader: daf.neu new-window felt gone). Instead
 * this shows a second surface, titled daf.neu, with a manual link. Clicking
 * an `<a target="_blank">` is its own user gesture, so it opens even when
 * the automatic `window.open` from the tile click was blocked.
 */
export function DafPopupDialog() {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const href = neu.dafPopupBlocked
  if (!href) return null

  const target = `${window.location.origin}${window.location.pathname}?go=landing&openTarget=${encodeURIComponent(href)}`

  return (
    <div
      className="manual-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="daf-popup-title"
      onClick={neu.dismissDafPopup}
    >
      <div className="manual-card" onClick={(event) => event.stopPropagation()}>
        <div className="exit-card-head">
          <h2 id="daf-popup-title">daf.neu</h2>
          <button type="button" className="exit-x" onClick={neu.dismissDafPopup} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </div>
        <p>
          {ko
            ? '이 브라우저가 daf.neu 새 창을 막았습니다. 아래를 눌러 daf.neu를 새 탭으로 엽니다. 주소는 daf.neu 창의 주소창에만 입력하세요.'
            : 'This browser blocked the daf.neu pop-up window. Click below to open daf.neu in a new tab. Type site addresses only in the daf.neu address bar.'}
        </p>
        <div className="download-actions">
          <a
            className="download-primary"
            href={target}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => neu.dismissDafPopup()}
          >
            {ko ? 'daf.neu 열기' : 'Open daf.neu'}
          </a>
        </div>
      </div>
    </div>
  )
}
