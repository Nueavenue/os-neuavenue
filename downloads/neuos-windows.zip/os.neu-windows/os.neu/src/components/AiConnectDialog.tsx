import { useEffect, useState } from 'react'
import { OFFICE_MODELS } from '../engine/office'
import { fetchLlmSettings, pingLlm, saveLlmSettings, type LlmSettingsView } from '../engine/llmConnect'
import { useI18n } from '../i18n/LocaleContext'
import { useNeu } from '../state/store'

type Props = {
  open: boolean
  onClose: () => void
  /** Prefill / focus a cloud model when opened because Ask AI needs a key. */
  preferModel?: string
}

export function AiConnectDialog({ open, onClose, preferModel }: Props) {
  const neu = useNeu()
  const { locale } = useI18n()
  const ko = locale === 'ko'
  const [view, setView] = useState<LlmSettingsView | null>(null)
  const [key, setKey] = useState('')
  const [provider, setProvider] = useState<'auto' | 'local' | 'openai'>('auto')
  const [model, setModel] = useState(preferModel || neu.officeModel)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    if (!open) return
    setMsg('')
    setModel(preferModel || neu.officeModel)
    void fetchLlmSettings().then((row) => {
      setView(row)
      if (row.provider === 'local' || row.provider === 'openai' || row.provider === 'auto') {
        setProvider(row.provider)
      }
    })
  }, [open, preferModel, neu.officeModel])

  if (!open) return null

  const localOk = Boolean(view?.ready?.ok && view.ready.via === 'local')
  const hasKey = Boolean(view?.hasKey)

    const save = async () => {
    setBusy(true)
    setMsg(ko ? '저장 중…' : 'Saving…')
    const result = await saveLlmSettings({
      provider,
      openaiKey: key.trim() || undefined,
    })
    setBusy(false)
    if (!result.ok) {
      setMsg(result.reason || (ko ? '저장 실패' : 'Save failed'))
      return
    }
    neu.setOfficeModel(model)
    setMsg(ko ? '연결 설정을 저장했습니다.' : 'Connection settings saved.')
    const refreshed = await fetchLlmSettings()
    setView(refreshed)
    setKey('')
  }

  const clearKey = async () => {
    setBusy(true)
    const result = await saveLlmSettings({ clearKey: true, provider })
    setBusy(false)
    setKey('')
    setMsg(result.ok ? (ko ? '키를 삭제했습니다.' : 'Key removed.') : result.reason || 'failed')
    setView(await fetchLlmSettings())
  }

  const test = async () => {
    setBusy(true)
    setMsg(ko ? '테스트 중… (로컬은 최대 1분)' : 'Testing… (local may take up to 1 min)')
    await saveLlmSettings({
      provider,
      openaiKey: key.trim() || undefined,
    })
    neu.setOfficeModel(model)
    const result = await pingLlm(model)
    setBusy(false)
    if (!result.ok) {
      setMsg(
        result.reason === 'no-llm'
          ? ko
            ? 'OpenAI 키가 없거나 로컬 AI가 꺼져 있습니다.'
            : 'No OpenAI key, or local AI is offline.'
          : result.reason || (ko ? '테스트 실패' : 'Test failed'),
      )
      return
    }
    setMsg(
      ko
        ? `연결됨 · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`
        : `Connected · ${result.provider} · ${result.model} · ${result.ms ?? '?'}ms`,
    )
    const refreshed = await fetchLlmSettings()
    setView(refreshed)
  }

  return (
    <div className="ai-connect-overlay" role="presentation" onClick={onClose}>
      <div
        className="ai-connect-dialog"
        role="dialog"
        aria-modal
        aria-label={ko ? 'AI 모델 연결' : 'Connect AI model'}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="ai-connect-head">
          <h2>{ko ? 'AI 모델 연결' : 'Connect AI model'}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label={ko ? '닫기' : 'Close'}>
            ×
          </button>
        </header>

        <p className="ai-connect-lead">
          {ko
            ? '무료 로컬(llama)은 CPU에서 15–90초 걸릴 수 있습니다. 빠른 응답은 OpenAI 키를 연결하세요.'
            : 'Free local llama can take 15–90s on CPU. For faster answers, connect your OpenAI key.'}
        </p>

        <div className="ai-connect-status">
          <div className={`ai-pill${localOk ? ' ok' : ''}`}>
            {localOk
              ? ko
                ? '로컬 AI 준비됨 (느릴 수 있음)'
                : 'Local AI ready (may be slow)'
              : ko
                ? '로컬 AI 없음 / 꺼짐'
                : 'Local AI offline'}
          </div>
          <div className={`ai-pill${hasKey ? ' ok' : ''}`}>
            {hasKey
              ? ko
                ? `OpenAI 키 저장됨 ${view?.keyHint || ''}`
                : `OpenAI key saved ${view?.keyHint || ''}`
              : ko
                ? 'OpenAI 키 없음'
                : 'No OpenAI key'}
          </div>
        </div>

        <label className="ai-connect-label">
          {ko ? '사용할 모델' : 'Model to use'}
          <select value={model} onChange={(e) => setModel(e.target.value)} disabled={busy}>
            {OFFICE_MODELS.map((row) => (
              <option key={row.id} value={row.id}>
                {row.label}
              </option>
            ))}
          </select>
        </label>

        <label className="ai-connect-label">
          {ko ? '우선 경로' : 'Prefer'}
          <select
            value={provider}
            onChange={(e) => setProvider(e.target.value as 'auto' | 'local' | 'openai')}
            disabled={busy}
          >
            <option value="auto">{ko ? '자동 (로컬 있으면 로컬)' : 'Auto (local if available)'}</option>
            <option value="local">{ko ? '항상 로컬 (무료·느림)' : 'Always local (free · slow)'}</option>
            <option value="openai">{ko ? '항상 OpenAI (키 필요·빠름)' : 'Always OpenAI (key · fast)'}</option>
          </select>
        </label>

        <label className="ai-connect-label">
          {ko ? 'OpenAI API 키' : 'OpenAI API key'}
          <input
            type="password"
            autoComplete="off"
            placeholder={hasKey ? (ko ? '새 키로 바꾸려면 입력' : 'Paste a new key to replace') : 'sk-…'}
            value={key}
            onChange={(e) => setKey(e.target.value)}
            disabled={busy}
          />
        </label>
        <p className="ai-connect-hint">
          {typeof location !== 'undefined' && location.hostname === 'os.neuavenue.com'
            ? ko
              ? '이 사이트(os.neuavenue.com)에는 로컬 llama가 없습니다. OpenAI 키는 이 탭 session에만 둡니다. 키 없이 Ask AI가 되려면 사이트 시크릿이 있어야 합니다.'
              : 'This site has no local llama. Your OpenAI key stays in this tab session. Site secret can serve Ask AI if set.'
            : ko
              ? '키는 이 PC의 ~/os.neu/data/user-llm.json 에만 저장됩니다. Neuavenue 공유 키는 없습니다.'
              : 'Key stays on this PC in ~/os.neu/data/user-llm.json. No shared Neuavenue key.'}
        </p>

        {msg ? <p className="ai-connect-msg">{msg}</p> : null}

        <div className="ai-connect-actions">
          <button type="button" className="btn ghost" onClick={onClose} disabled={busy}>
            {ko ? '닫기' : 'Close'}
          </button>
          {hasKey ? (
            <button type="button" className="btn ghost" onClick={() => void clearKey()} disabled={busy}>
              {ko ? '키 삭제' : 'Remove key'}
            </button>
          ) : null}
          <button type="button" className="btn ghost" onClick={() => void test()} disabled={busy}>
            {busy ? (ko ? '대기…' : 'Wait…') : ko ? '연결 테스트' : 'Test'}
          </button>
          <button type="button" className="save-btn" onClick={() => void save()} disabled={busy}>
            {ko ? '저장 후 사용' : 'Save & use'}
          </button>
        </div>
      </div>
    </div>
  )
}
