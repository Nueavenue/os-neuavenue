import { useEffect, useState } from 'react'
import { AuthBar } from './AuthBar'
import { BrandMark } from './BrandMark'
import { LangPicker } from './LangPicker'
import { CommandViewGlyph, DownloadGlyph, ManualGlyph, VitalityGlyph, WindowGlyph } from './PathGlyphs'
import { PathRail } from './PathRail'
import { useI18n } from '../i18n/LocaleContext'
import { isHomePhase } from '../engine/chromeX'
import { COMMAND_VIEW_URL } from '../engine/browser'
import { useNeu } from '../state/store'

/** REQ 3.1 — collapse pills at this inner width. Electron minWidth must be below this. */
export const CHROME_NARROW_PX = 860

function useClock(locale: string) {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000)
    return () => window.clearInterval(id)
  }, [])
  return now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })
}

function useFullscreen() {
  const [full, setFull] = useState(() => Boolean(document.fullscreenElement))
  useEffect(() => {
    const sync = () => setFull(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', sync)
    return () => document.removeEventListener('fullscreenchange', sync)
  }, [])
  return full
}

function useNarrowChrome(node: HTMLElement | null, maxPx = CHROME_NARROW_PX) {
  const [narrow, setNarrow] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth <= maxPx : false,
  )
  useEffect(() => {
    const measure = () => {
      const view = window.innerWidth
      const bar = node?.getBoundingClientRect().width ?? view
      setNarrow(Math.min(view, bar) <= maxPx)
    }
    measure()
    const ro = node ? new ResizeObserver(measure) : null
    if (node && ro) ro.observe(node)
    window.addEventListener('resize', measure)
    return () => {
      ro?.disconnect()
      window.removeEventListener('resize', measure)
    }
  }, [node, maxPx])
  return narrow
}

export function StatusBar() {
  const neu = useNeu()
  const { copy, locale } = useI18n()
  const time = useClock(locale)
  const full = useFullscreen()
  const [barNode, setBarNode] = useState<HTMLElement | null>(null)
  const narrow = useNarrowChrome(barNode)
  const ko = locale === 'ko'
  const electron = Boolean(typeof window !== 'undefined' && window.neuos?.quit)
  const netClass = !neu.network.probed ? '' : neu.network.online ? 'ok' : 'off'
  const health = neu.hardware ? (neu.hardware.healthy ? 'ok' : 'warn') : ''
  const xLabel = isHomePhase(neu.phase)
    ? ko
      ? '종료'
      : 'Quit'
    : full
      ? ko
        ? '화면 축소'
        : 'Shrink screen'
      : ko
        ? '이전 화면'
        : 'Back'

  useEffect(() => {
    if (!narrow && neu.chromeMenuOpen) neu.setChromeMenuOpen(false)
  }, [narrow, neu.chromeMenuOpen, neu.setChromeMenuOpen])

  useEffect(() => {
    if (!neu.chromeMenuOpen) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') neu.setChromeMenuOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [neu.chromeMenuOpen, neu.setChromeMenuOpen])

  const pills = (
    <>
      <div className="chrome-status-row">
        <span className={`pill ${netClass}`}>{neu.network.probed ? neu.network.label : copy.wait}</span>
        {neu.hardware ? (
          <span className={`pill ${health}`}>{neu.hardware.healthy ? copy.deviceOk : copy.deviceWarn}</span>
        ) : null}
        {neu.bridge && neu.bridge.driver !== 'dry-run' ? (
          <span className={`pill ${neu.bridge.live ? 'ok' : ''}`}>
            {neu.bridge.driver}
            {neu.bridge.live ? ` ${copy.liveClick}` : ''}
          </span>
        ) : null}
      </div>
      <div className="chrome-icon-row">
        <PathRail />
        <button
          type="button"
          className={`path-icon vitality-icon${neu.vitalityOpen ? ' on' : ''}`}
          onClick={() => {
            neu.setChromeMenuOpen(false)
            neu.toggleVitality()
          }}
          aria-label="NEU VITALITY"
          aria-pressed={neu.vitalityOpen}
          title={
            neu.vitalityOpen
              ? ko
                ? 'NEU VITALITY 닫고 이전 화면'
                : 'Close NEU VITALITY · back'
              : 'NEU VITALITY · neuavenue.com/vitality'
          }
        >
          <VitalityGlyph />
        </button>
        <button
          type="button"
          className="path-icon"
          onClick={() => {
            neu.setChromeMenuOpen(false)
            neu.openDownload()
          }}
          aria-label={ko ? '다운로드' : 'Download'}
          title={ko ? 'Linux 스크린 받기' : 'Get Linux screen'}
        >
          <DownloadGlyph />
        </button>
        <button
          type="button"
          className="path-icon"
          onClick={() => {
            neu.setChromeMenuOpen(false)
            neu.openManual()
          }}
          aria-label={ko ? '매뉴얼' : 'Manual'}
          title={ko ? '매뉴얼' : 'Manual'}
        >
          <ManualGlyph />
        </button>
        {electron ? (
          <button
            type="button"
            className="path-icon"
            onClick={() => {
              void window.neuos?.windowMode?.().then((state) => {
                if (state?.maximized || state?.fullscreen) void window.neuos?.setWindowMode?.('windowed')
                else void window.neuos?.setWindowMode?.('maximized')
              })
            }}
            aria-label={ko ? '화면 크기' : 'Window size'}
            title={ko ? '창 크기 조절' : 'Resize window'}
          >
            <WindowGlyph />
          </button>
        ) : null}
      </div>
      <div className="chrome-meta-row">
        <LangPicker />
        <span className="pill">{time}</span>
      </div>
    </>
  )

  return (
    <header
      ref={setBarNode}
      className={`status-bar${neu.chromeMenuOpen ? ' chrome-open' : ''}${narrow ? ' is-narrow' : ''}`}
    >
      {neu.chromeMenuOpen ? (
        <button
          type="button"
          className="chrome-scrim"
          aria-label={ko ? '메뉴 닫기' : 'Close menu'}
          onClick={() => neu.setChromeMenuOpen(false)}
        />
      ) : null}
      <div className="status-left">
        {neu.commandViewAllowed ? (
          <button
            type="button"
            className="path-icon command-view-icon"
            onClick={() => {
              neu.setChromeMenuOpen(false)
              neu.openDaf(COMMAND_VIEW_URL)
            }}
            aria-label={ko ? '현황판' : 'Command View'}
            title={ko ? '현황판 · neuavenue.com' : 'Command View · neuavenue.com'}
          >
            <CommandViewGlyph />
          </button>
        ) : null}
        <AuthBar />
        <BrandMark onClick={neu.phase === 'install' ? undefined : neu.goHome} />
      </div>
      <div className="status-end">
        <button
          type="button"
          className={`chrome-burger${neu.chromeMenuOpen ? ' on' : ''}`}
          aria-label={ko ? '메뉴' : 'Menu'}
          aria-expanded={neu.chromeMenuOpen}
          title={ko ? '메뉴' : 'Menu'}
          onClick={neu.toggleChromeMenu}
        >
          ☰
        </button>
        <div className={`status-pills${neu.chromeMenuOpen ? ' open' : ''}`}>{pills}</div>
        <button
          type="button"
          className="pill exit-btn exit-x"
          onClick={neu.chromeX}
          aria-label={xLabel}
          title={xLabel}
        >
          ×
        </button>
      </div>
    </header>
  )
}
