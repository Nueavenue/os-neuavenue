import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  type ReactNode,
} from 'react'
import { decideChromeX } from '../engine/chromeX'
import { initialPhaseFromWindow } from '../engine/bootRoute'
import { actDriver, coachChat, fetchBootHealth, fetchBridgeStatus, planAppInstall, recordVisionSample, sandboxRect, uninstallHost, type BootHealth, type BridgeStatus } from '../engine/bridge'
import { playCoachAudio, rememberCoach, speakBrowser } from '../engine/coachAudio'
import { idleDriver, isolate, moveCursor, pushEvent } from '../engine/drivers'
import { searchUrl, VITALITY_URL, WEB_HOME } from '../engine/browser'
import { isAffirmative, isNegative, parseGuide, type PendingGuide } from '../engine/guide'
import { classifyIntent, replyToTalk } from '../engine/intents'
import { probeNetwork } from '../engine/network'
import { withStep } from '../engine/orchestrator'
import { centerOf, harvestUiGraph, pick } from '../engine/vlm'
import {
  acceptSessionToken,
  consumeAuthRedirect,
  fetchCommandViewEntitlement,
  fetchMe,
  readRememberedOAuthHandoff,
  trackEvent,
  waitForGoogleHandoff,
  type AuthUser,
} from '../engine/auth'
import type {
  ChatTurn,
  DriverState,
  HardwareReport,
  NetworkState,
  Phase,
  Pipeline,
  SandboxApp,
  VisionFrame,
} from '../types'

/** Last guest-page capture for auth modal backdrop (persists across opens). */
let lastBrowseBackdrop: string | null = null

export type NeuState = {
  phase: Phase
  hardware: HardwareReport | null
  network: NetworkState
  chats: ChatTurn[]
  pipeline: Pipeline | null
  vision: VisionFrame | null
  driver: DriverState
  sandbox: SandboxApp
  busy: boolean
  savedSheet: boolean
  savedDoc: boolean
  bridge: BridgeStatus | null
  exitOpen: boolean
  bootHealth: BootHealth | null
  pendingGuide: PendingGuide | null
  browseTarget: string | null
  previousPhase: Phase | null
  vitalityOpen: boolean
  officeModel: string
  account: AuthUser | null
  // WO-UI-NEU-COMMAND-VIEW-ICON-121 (UI-B27): server-checked
  // current_site_role() ∈ {ceo, leader, shareholder, admin}. Fails closed
  // (false) on signed-out / local-only / supabase-off / RPC error — see
  // fetchCommandViewEntitlement(). Never derived from AuthUser.admin.
  commandViewAllowed: boolean
  authPanel: 'none' | 'login' | 'feedback'
  authBackdrop: string | null
  screenGone: boolean
  installIntent: 'none' | 'host' | 'usb'
  manualOpen: boolean
  downloadOpen: boolean
  chromeMenuOpen: boolean
  // WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): hosted web has no
  // Electron IPC window, so opening daf.neu as a real tab/window uses
  // `window.open` — the href it tried to open when the browser blocked
  // that popup, so a `daf.neu`-titled overlay can offer a manual retry
  // instead of silently falling back to same-page navigation.
  dafPopupBlocked: string | null
  // English study app: when on, free-text lines go to the NeuSpeak coach.
  // Off by default so the first screen is a productivity router
  // (web search / document / app) — not an always-on English tutor.
  englishMode: boolean
}

type Action =
  | { type: 'phase'; phase: Phase }
  | { type: 'hardware'; report: HardwareReport }
  | { type: 'network'; network: NetworkState }
  | { type: 'chat'; turn: ChatTurn }
  | { type: 'patch-chat'; id: string; patch: Partial<ChatTurn> }
  | { type: 'drop-chat'; id: string }
  | { type: 'pipeline'; pipeline: Pipeline | null }
  | { type: 'vision'; vision: VisionFrame | null }
  | { type: 'driver'; driver: DriverState }
  | { type: 'sandbox'; sandbox: SandboxApp }
  | { type: 'busy'; busy: boolean }
  | { type: 'saved-sheet'; value: boolean }
  | { type: 'saved-doc'; value: boolean }
  | { type: 'bridge'; bridge: BridgeStatus | null }
  | { type: 'exit'; open: boolean }
  | { type: 'boot-health'; health: BootHealth | null }
  | { type: 'pending-guide'; guide: PendingGuide | null }
  | { type: 'browse-target'; href: string | null }
  | { type: 'previous-phase'; phase: Phase | null }
  | { type: 'vitality-open'; open: boolean }
  | { type: 'office-model'; model: string }
  | { type: 'account'; account: AuthUser | null }
  | { type: 'command-view-allowed'; allowed: boolean }
  | { type: 'auth-panel'; panel: 'none' | 'login' | 'feedback'; backdrop?: string | null }
  | { type: 'screen-gone'; value: boolean }
  | { type: 'install-intent'; intent: 'none' | 'host' | 'usb' }
  | { type: 'manual'; open: boolean }
  | { type: 'download'; open: boolean }
  | { type: 'chrome-menu'; open: boolean }
  | { type: 'daf-popup-blocked'; href: string | null }
  | { type: 'english-mode'; on: boolean }

const initial: NeuState = {
  phase: initialPhaseFromWindow(),
  hardware: null,
  network: { online: false, probed: false, label: 'Checking' },
  chats: [],
  pipeline: null,
  vision: null,
  driver: idleDriver(),
  sandbox: 'none',
  busy: false,
  savedSheet: false,
  savedDoc: false,
  bridge: null,
  exitOpen: false,
  bootHealth: null,
  pendingGuide: null,
  browseTarget: null,
  previousPhase: null,
  vitalityOpen: false,
  officeModel: 'os.neu-local',
  account: null,
  commandViewAllowed: false,
  authPanel: 'none',
  authBackdrop: null,
  screenGone: false,
  installIntent: 'none',
  manualOpen: false,
  downloadOpen: false,
  chromeMenuOpen: false,
  dafPopupBlocked: null,
  englishMode: false,
}

function reducer(state: NeuState, action: Action): NeuState {
  switch (action.type) {
    case 'phase':
      if (action.phase === state.phase) return state
      return { ...state, previousPhase: state.phase, phase: action.phase, chromeMenuOpen: false }
    case 'hardware':
      return { ...state, hardware: action.report }
    case 'network':
      return { ...state, network: action.network }
    case 'chat':
      return { ...state, chats: [...state.chats.slice(-18), action.turn] }
    case 'patch-chat':
      return {
        ...state,
        chats: state.chats.map((turn) => (turn.id === action.id ? { ...turn, ...action.patch } : turn)),
      }
    case 'drop-chat':
      return { ...state, chats: state.chats.filter((turn) => turn.id !== action.id) }
    case 'pipeline':
      return { ...state, pipeline: action.pipeline }
    case 'vision':
      return { ...state, vision: action.vision }
    case 'driver':
      return { ...state, driver: action.driver }
    case 'sandbox':
      return { ...state, sandbox: action.sandbox }
    case 'busy':
      return { ...state, busy: action.busy }
    case 'saved-sheet':
      return { ...state, savedSheet: action.value }
    case 'saved-doc':
      return { ...state, savedDoc: action.value }
    case 'bridge':
      return { ...state, bridge: action.bridge }
    case 'exit':
      return { ...state, exitOpen: action.open }
    case 'boot-health':
      return { ...state, bootHealth: action.health }
    case 'pending-guide':
      return { ...state, pendingGuide: action.guide }
    case 'browse-target':
      return { ...state, browseTarget: action.href }
    case 'previous-phase':
      return { ...state, previousPhase: action.phase }
    case 'vitality-open':
      return { ...state, vitalityOpen: action.open }
    case 'office-model':
      return { ...state, officeModel: action.model }
    case 'account':
      return { ...state, account: action.account }
    case 'command-view-allowed':
      return { ...state, commandViewAllowed: action.allowed }
    case 'auth-panel':
      return {
        ...state,
        authPanel: action.panel,
        authBackdrop:
          action.panel === 'none'
            ? null
            : action.backdrop !== undefined
              ? action.backdrop
              : state.authBackdrop,
      }
    case 'screen-gone':
      return { ...state, screenGone: action.value, exitOpen: false }
    case 'install-intent':
      return { ...state, installIntent: action.intent }
    case 'manual':
      return {
        ...state,
        manualOpen: action.open,
        downloadOpen: action.open ? false : state.downloadOpen,
        chromeMenuOpen: action.open ? false : state.chromeMenuOpen,
      }
    case 'download':
      return {
        ...state,
        downloadOpen: action.open,
        manualOpen: action.open ? false : state.manualOpen,
        chromeMenuOpen: action.open ? false : state.chromeMenuOpen,
      }
    case 'chrome-menu':
      return {
        ...state,
        chromeMenuOpen: action.open,
        ...(action.open ? { manualOpen: false, downloadOpen: false } : {}),
      }
    case 'daf-popup-blocked':
      return { ...state, dafPopupBlocked: action.href }
    case 'english-mode':
      return { ...state, englishMode: action.on }
    default:
      return state
  }
}

type NeuApi = NeuState & {
  go: (phase: Phase) => void
  setHardware: (report: HardwareReport) => void
  setNetwork: (network: NetworkState) => void
  submit: (text: string, opts?: { userId?: string }) => Promise<void>
  runPipelineOn: (root: HTMLElement) => Promise<void>
  goHome: () => void
  openExit: () => Promise<void>
  closeExit: () => void
  chooseJeos: () => void
  chooseLoop: () => void
  quitApp: () => Promise<void>
  uninstallAndLeave: (files?: boolean) => Promise<void>
  goBack: () => void
  openOffice: (app: 'sheet' | 'doc' | 'slides') => void
  setOfficeModel: (model: string) => void
  setAccount: (account: AuthUser | null) => void
  setAuthPanel: (panel: 'none' | 'login' | 'feedback') => void
  clearBrowseTarget: () => void
  openWeb: (href?: string) => void
  openDaf: (href?: string) => void
  dismissDafPopup: () => void
  toggleVitality: () => void
  appendNeu: (text: string) => void
  beginChat: (role: 'user' | 'neu') => string
  patchChat: (id: string, patch: Partial<ChatTurn>) => void
  dropChat: (id: string) => void
  openPath: (kind: 'host' | 'usb' | 'guest') => void
  clearInstallIntent: () => void
  openManual: () => void
  closeManual: () => void
  openDownload: () => void
  closeDownload: () => void
  setChromeMenuOpen: (open: boolean) => void
  toggleChromeMenu: () => void
  chromeX: () => void
}

const Ctx = createContext<NeuApi | null>(null)

function wait(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms))
}

type Dispatch = (action: Action) => void

function coachHistory(chats: ChatTurn[]) {
  return chats
    .filter((turn) => turn.text.trim() && !turn.pending)
    .slice(-8)
    .map((turn) => ({
      role: turn.role === 'user' ? ('user' as const) : ('assistant' as const),
      content: turn.text,
    }))
}

/**
 * Default reply for a line we could not route to search / document / app /
 * English. Steers the user to one of the real lanes instead of silently
 * turning every line into an English lesson.
 */
function routerHint(raw: string): string {
  const ko = /[가-힣]/.test(raw)
  if (ko) {
    return `무엇을 할까요? 세 가지로 안내해 드려요:
· 웹 검색 — 예: “${raw.slice(0, 20)} 조사해줘”, “강릉 날씨 알려줘”
· 문서 작업 — 예: “보고서 만들어줘”, “엑셀 표 만들어줘”, “슬라이드 만들어줘”
· 앱 실행/설치 — 예: “크롬 설치해줘”, “인터넷 열어줘”
영어 회화를 원하시면 “영어 연습”이라고 말씀하세요.`
  }
  return `What should I do? Three lanes:
· Web search — e.g. "look up ${raw.slice(0, 24)}"
· Documents — e.g. "make a report", "new slides", "a spreadsheet"
· Apps — e.g. "install chrome", "open the web"
For English practice, say "practice English".`
}

async function pushCoach(
  dispatch: Dispatch,
  message: string,
  fallback?: string,
  history: ChatTurn[] = [],
) {
  const prior = coachHistory(history)
  const id = `n-${Date.now()}`
  dispatch({
    type: 'chat',
    turn: { id, role: 'neu', text: '', pending: true },
  })
  try {
    const coach = await coachChat(message, prior, { audio: true })
    const text = coach.ok && coach.reply ? coach.reply : fallback ?? message
    rememberCoach(text, coach.audio)
    dispatch({
      type: 'patch-chat',
      id,
      patch: { text, pending: false, typing: true },
    })
    const played = await playCoachAudio()
    if (!played) await speakBrowser(text)
  } catch {
    const text = fallback ?? message
    rememberCoach(text)
    dispatch({
      type: 'patch-chat',
      id,
      patch: { text, pending: false, typing: true },
    })
    await speakBrowser(text)
  }
}

export function NeuProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial)

  useEffect(() => {
    void fetchBridgeStatus().then((bridge) => {
      if (bridge) dispatch({ type: 'bridge', bridge })
    })
    void consumeAuthRedirect()
      .then((user) => {
        if (user) {
          dispatch({ type: 'account', account: user })
          return user
        }
        return fetchMe()
      })
      .then((user) => {
        if (user) dispatch({ type: 'account', account: user })
      })

    const stop = window.neuos?.auth?.onOAuth?.((payload) => {
      // Preferred (WO-AUTH-ELECTRON-PKCE-1): opaque wake, no token in the
      // deep link — fetch the session ourselves via the existing handoff
      // poll. Legacy fallback: token arrived directly on the deep link.
      const accepted = payload.token ? acceptSessionToken(payload.token) : waitForGoogleHandoff(payload.handoff || '', 20_000)
      void accepted.then((user) => {
        if (user) {
          dispatch({ type: 'account', account: user })
          try {
            sessionStorage.removeItem('os.neu.oauth.handoff')
          } catch {
            /* ignore */
          }
        }
      })
    })

    const pending = readRememberedOAuthHandoff()
    let cancelled = false
    if (pending) {
      void waitForGoogleHandoff(pending).then((user) => {
        if (!cancelled && user) dispatch({ type: 'account', account: user })
      })
    }

    return () => {
      cancelled = true
      stop?.()
    }
  }, [])

  // WO-UI-NEU-COMMAND-VIEW-ICON-121 (UI-B27): re-check the Command View
  // icon gate whenever the signed-in account changes (sign-in, sign-out,
  // account switch). Signing out clears it immediately (fail closed) with
  // no network round-trip.
  useEffect(() => {
    if (!state.account) {
      dispatch({ type: 'command-view-allowed', allowed: false })
      return
    }
    let cancelled = false
    void fetchCommandViewEntitlement().then((allowed) => {
      if (!cancelled) dispatch({ type: 'command-view-allowed', allowed })
    })
    return () => {
      cancelled = true
    }
  }, [state.account])

  const accountRef = useRef(state.account)
  accountRef.current = state.account
  const phaseRef = useRef(state.phase)
  phaseRef.current = state.phase

  const go = useCallback((phase: Phase) => {
    if (phase === 'admin' && !accountRef.current?.admin) return
    const from = phaseRef.current
    if (from !== phase) dispatch({ type: 'previous-phase', phase: from })
    dispatch({ type: 'phase', phase })
    void trackEvent('view', phase)
  }, [])

  const setHardware = useCallback((report: HardwareReport) => {
    dispatch({ type: 'hardware', report })
  }, [])

  const setNetwork = useCallback((network: NetworkState) => {
    dispatch({ type: 'network', network })
  }, [])

  const goHome = useCallback(() => {
    dispatch({ type: 'pipeline', pipeline: null })
    dispatch({ type: 'vision', vision: null })
    dispatch({ type: 'sandbox', sandbox: 'none' })
    dispatch({ type: 'vitality-open', open: false })
    dispatch({ type: 'driver', driver: idleDriver() })
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'auth-panel', panel: 'none' })
    dispatch({ type: 'chrome-menu', open: false })
    dispatch({
      type: 'phase',
      phase: state.network.online ? 'lui' : 'landing',
    })
  }, [state.network.online])

  const closeExit = useCallback(() => {
    dispatch({ type: 'exit', open: false })
  }, [])

  const openExit = useCallback(async () => {
    dispatch({ type: 'exit', open: true })
    dispatch({ type: 'boot-health', health: null })
    try {
      const health = await fetchBootHealth(true)
      dispatch({ type: 'boot-health', health })
    } catch {
      dispatch({
        type: 'boot-health',
        health: { ok: false, t: 0, missing: true, stale: true, ageMs: 0 },
      })
    }
  }, [])

  const chooseJeos = useCallback(() => {
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'phase', phase: 'jeos' })
  }, [])

  const chooseLoop = useCallback(() => {
    dispatch({ type: 'exit', open: false })
    dispatch({
      type: 'phase',
      phase: state.network.online ? 'lui' : 'landing',
    })
  }, [state.network.online])

  const quitApp = useCallback(async () => {
    void trackEvent('logout', state.phase, 'quit')
    void window.neuos?.browse?.hide()
    dispatch({ type: 'exit', open: false })
    dispatch({ type: 'screen-gone', value: true })
    if (window.neuos?.quit) {
      try {
        await window.neuos.quit()
        return
      } catch {
        /* still try to close */
      }
    }
    window.close()
  }, [state.phase])

  const setOfficeModel = useCallback((model: string) => {
    dispatch({ type: 'office-model', model })
  }, [])

  const setAccount = useCallback((account: AuthUser | null) => {
    dispatch({ type: 'account', account })
  }, [])

  const setAuthPanel = useCallback((panel: 'none' | 'login' | 'feedback') => {
    if (panel === 'none') {
      dispatch({ type: 'auth-panel', panel, backdrop: null })
      return
    }
    void (async () => {
      let backdrop: string | null = lastBrowseBackdrop
      try {
        const snap = await window.neuos?.browse?.snapshot?.()
        if (snap?.ok && snap.dataUrl) {
          lastBrowseBackdrop = snap.dataUrl
          backdrop = snap.dataUrl
        }
      } catch {
        /* keep last recent page */
      }
      dispatch({ type: 'auth-panel', panel, backdrop })
    })()
  }, [])

  const openOffice = useCallback((app: 'sheet' | 'doc' | 'slides') => {
    dispatch({ type: 'previous-phase', phase: state.phase })
    dispatch({ type: 'pipeline', pipeline: null })
    dispatch({ type: 'sandbox', sandbox: app })
    dispatch({ type: 'phase', phase: 'workspace' })
    void trackEvent('open-app', 'workspace', app)
  }, [state.phase])

  const goBack = useCallback(() => {
    const prev = state.previousPhase
    if (prev && prev !== state.phase && prev !== 'splash') {
      dispatch({ type: 'phase', phase: prev })
      void trackEvent('view', prev, 'back')
      return
    }
    goHome()
  }, [state.previousPhase, state.phase, goHome])

  const openPath = useCallback(
    (kind: 'host' | 'usb' | 'guest') => {
      sessionStorage.setItem('neuos.install', kind)
      void trackEvent('click', phaseRef.current, `path-${kind}`)
      if (kind === 'guest') {
        const boot = ['splash', 'install', 'post', 'announce', 'network']
        if (boot.includes(phaseRef.current)) go('post')
        else goHome()
        return
      }
      dispatch({ type: 'install-intent', intent: kind })
      go('install')
    },
    [go, goHome],
  )

  const clearInstallIntent = useCallback(() => {
    dispatch({ type: 'install-intent', intent: 'none' })
  }, [])

  const openManual = useCallback(() => {
    dispatch({ type: 'manual', open: true })
  }, [])

  const closeManual = useCallback(() => {
    dispatch({ type: 'manual', open: false })
  }, [])

  const openDownload = useCallback(() => {
    dispatch({ type: 'download', open: true })
  }, [])

  const closeDownload = useCallback(() => {
    dispatch({ type: 'download', open: false })
  }, [])

  const setChromeMenuOpen = useCallback((open: boolean) => {
    dispatch({ type: 'chrome-menu', open })
  }, [])

  const toggleChromeMenu = useCallback(() => {
    dispatch({ type: 'chrome-menu', open: !state.chromeMenuOpen })
  }, [state.chromeMenuOpen])

  const chromeX = useCallback(() => {
    const action = decideChromeX({
      phase: state.phase,
      previousPhase: state.previousPhase,
      windowFullscreen: false,
      domFullscreen: Boolean(document.fullscreenElement),
    })
    if (action === 'quit') {
      void quitApp()
      return
    }
    if (action === 'leave-fullscreen') {
      if (document.fullscreenElement) void document.exitFullscreen()
      void window.neuos?.setFullscreen?.(false)
      return
    }
    if (action === 'back') {
      const prev = state.previousPhase
      if (prev && prev !== state.phase) {
        dispatch({ type: 'phase', phase: prev })
        void trackEvent('view', prev, 'chrome-x')
      }
      return
    }
    goHome()
  }, [state.previousPhase, state.phase, quitApp, goHome])

  const uninstallAndLeave = useCallback(async (files = false) => {
    try {
      await uninstallHost(files)
    } catch {
      /* still leave Ubuntu usable even if the bridge is down */
    }
    sessionStorage.removeItem('neuos.install')
    await quitApp()
  }, [quitApp])

  const clearBrowseTarget = useCallback(() => {
    dispatch({ type: 'browse-target', href: null })
  }, [])

  const openWeb = useCallback((href = 'https://www.neuavenue.com') => {
    dispatch({ type: 'vitality-open', open: false })
    dispatch({ type: 'browse-target', href })
    dispatch({ type: 'sandbox', sandbox: 'web' })
    dispatch({ type: 'phase', phase: 'landing' })
  }, [])

  // WO-UI-NEU-DAF-FRONT-WINDOW-121 (UI-B17 AMEND): the daf.neu tile
  // (Lui / PhoneHome / one-page Block 4) must open a real front-most
  // *window*, not flip this window's own phase in place — that in-place
  // flip is the "GAP" Control verified as felt-gone on the hosted site.
  // Electron: reuse browse:newWindow (createBrowserAppWindow) for a real
  // child BrowserWindow titled daf.neu. Hosted web: a real `window.open`
  // (user-gesture, called synchronously from the click handler) straight
  // to `?go=landing&openTarget=<href>`, which the *new* window/tab routes
  // through `openWeb()` above via App.tsx's existing boot-query handling.
  // This window's own phase (Lui/PhoneHome/one-page) is left untouched.
  const openDaf = useCallback((href = WEB_HOME) => {
    if (typeof window === 'undefined') return
    if (window.neuos?.browse?.newWindow) {
      void window.neuos.browse.newWindow(href)
      return
    }
    const target = `${window.location.origin}${window.location.pathname}?go=landing&openTarget=${encodeURIComponent(href)}`
    const popup = window.open(target, '_blank')
    if (!popup || popup.closed || typeof popup.closed === 'undefined') {
      dispatch({ type: 'daf-popup-blocked', href })
    }
  }, [])

  const dismissDafPopup = useCallback(() => {
    dispatch({ type: 'daf-popup-blocked', href: null })
  }, [])

  const toggleVitality = useCallback(() => {
    if (state.vitalityOpen && state.phase === 'landing') {
      dispatch({ type: 'vitality-open', open: false })
      void window.neuos?.browse?.hide()
      const prev = state.previousPhase
      if (prev && prev !== 'landing') {
        dispatch({ type: 'phase', phase: prev })
        void trackEvent('view', prev, 'vitality-back')
      } else {
        dispatch({ type: 'phase', phase: 'lui' })
        void trackEvent('view', 'lui', 'vitality-back')
      }
      return
    }
    dispatch({ type: 'vitality-open', open: true })
    dispatch({ type: 'browse-target', href: VITALITY_URL })
    dispatch({ type: 'sandbox', sandbox: 'web' })
    dispatch({ type: 'phase', phase: 'landing' })
    void trackEvent('click', state.phase, 'vitality')
  }, [state.vitalityOpen, state.phase, state.previousPhase])

  const appendNeu = useCallback((text: string) => {
    const line = text.trim()
    if (!line) return
    dispatch({
      type: 'chat',
      turn: { id: `n-${Date.now()}`, role: 'neu', text: line, typing: true },
    })
  }, [])

  const beginChat = useCallback((role: 'user' | 'neu') => {
    const id = `${role === 'user' ? 'u' : 'n'}-${Date.now()}`
    dispatch({
      type: 'chat',
      turn: { id, role, text: '', pending: true },
    })
    return id
  }, [])

  const patchChat = useCallback((id: string, patch: Partial<ChatTurn>) => {
    dispatch({ type: 'patch-chat', id, patch })
  }, [])

  const dropChat = useCallback((id: string) => {
    dispatch({ type: 'drop-chat', id })
  }, [])

  const submit = useCallback(
    async (text: string, opts?: { userId?: string }) => {
      const raw = text.trim()
      if (!raw) return

      if (opts?.userId) {
        dispatch({
          type: 'patch-chat',
          id: opts.userId,
          patch: { text: raw, pending: false, typing: false },
        })
      } else {
        dispatch({
          type: 'chat',
          turn: { id: `u-${Date.now()}`, role: 'user', text: raw, typing: true },
        })
      }

      const pending = state.pendingGuide
      const prior = state.chats
      if (pending && isNegative(raw)) {
        dispatch({ type: 'pending-guide', guide: null })
        dispatch({ type: 'busy', busy: true })
        await pushCoach(dispatch, 'The learner said no. Cancel the computer task and ask what they want instead.', 'Okay. What should we do instead?', prior)
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (pending && isAffirmative(raw)) {
        dispatch({ type: 'busy', busy: true })
        if (pending.stage === 'confirm') {
          let facts = ''
          let online = state.network.online
          if (pending.wantsNet) {
            const net = await probeNetwork()
            dispatch({ type: 'network', network: net })
            online = net.online
            facts += net.online
              ? ` Internet is on (${net.label}).`
              : ' Internet looks offline.'
          }
          if (pending.wantsBrowser && online) {
            const href = pending.browseUrl || WEB_HOME
            dispatch({ type: 'browse-target', href })
            dispatch({ type: 'sandbox', sandbox: 'web' })
            dispatch({ type: 'phase', phase: 'landing' })
            dispatch({
              type: 'pending-guide',
              guide: { ...pending, stage: 'see-page' },
            })
            await pushCoach(
              dispatch,
              `The learner confirmed. Facts:${facts} Opened ${href}. Ask them in English to look at the page and say if they see it.`,
              `${facts} I opened ${href}. Do you see that page?`.trim(),
              prior,
            )
            dispatch({ type: 'busy', busy: false })
            return
          }
          let install = ''
          if (pending.installQuery) {
            try {
              const result = await planAppInstall(pending.installQuery, 'lui')
              const plan = result.plan
              install = plan ? ` ${plan.next ?? ''} ${plan.command}` : ''
            } catch {
              install = ' Could not build the install command yet.'
            }
          }
          dispatch({ type: 'pending-guide', guide: null })
          dispatch({ type: 'phase', phase: 'lui' })
          await pushCoach(
            dispatch,
            `The learner confirmed. Facts:${facts}${install} Speak those facts in English and ask what they see.`,
            `${facts}${install} What do you see?`.trim(),
            prior,
          )
          dispatch({ type: 'busy', busy: false })
          return
        }

        if (pending.stage === 'see-page') {
          let install = ''
          if (pending.installQuery) {
            try {
              const result = await planAppInstall(pending.installQuery, 'lui')
              const plan = result.plan
              install = plan ? `${plan.next ?? ''} ${plan.command}`.trim() : ''
            } catch {
              install = 'Could not build the install command yet.'
            }
          }
          dispatch({ type: 'pending-guide', guide: null })
          await pushCoach(
            dispatch,
            `The learner sees the page. Give the next step in English.${install ? ` Install command: ${install}` : ''} Ask if they want you to repeat it.`,
            install || 'Good. What should we do next?',
            prior,
          )
          dispatch({ type: 'busy', busy: false })
          return
        }
        dispatch({ type: 'busy', busy: false })
      }

      if (pending) {
        dispatch({ type: 'busy', busy: true })
        await pushCoach(
          dispatch,
          'The learner did not clearly say yes or no. Ask them again to look at the screen and say yes or no.',
          'Please look at this screen and say yes or no.',
          prior,
        )
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (/^install\s+os\.neu\b/i.test(raw) || /^install\s+osneu\b/i.test(raw)) {
        dispatch({ type: 'phase', phase: 'plant' })
        return
      }
      if (/^(uninstall|remove|delete)\s+os\.neu\b/i.test(raw) || /^os\.neu\s+(삭제|제거)/i.test(raw)) {
        dispatch({ type: 'exit', open: true })
        return
      }

      const guided = parseGuide(raw)
      if (guided) {
        dispatch({ type: 'pending-guide', guide: { ...guided, stage: 'confirm' } })
        dispatch({ type: 'busy', busy: true })
        await pushCoach(
          dispatch,
          `The learner asked: "${raw}". Restate that in one English sentence and ask them to look at this screen and say yes or no before we check the internet or open a browser.`,
          guided.confirm,
          prior,
        )
        dispatch({ type: 'busy', busy: false })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      const intent = classifyIntent(raw)

      // English study app (opt-in). Turns the NeuSpeak coach on; while on,
      // plain talk lines below go to the coach for practice.
      if (intent.kind === 'english') {
        dispatch({ type: 'english-mode', on: true })
        if (state.network.online) {
          dispatch({ type: 'busy', busy: true })
          await pushCoach(
            dispatch,
            `The learner wants to practice English. Start a short, friendly English conversation. Their line: "${raw}".`,
            'English practice is on. Say anything and I will reply in English. Say “영어 그만” to stop.',
            prior,
          )
          dispatch({ type: 'busy', busy: false })
        } else {
          dispatch({
            type: 'chat',
            turn: {
              id: `n-${Date.now()}`,
              role: 'neu',
              text: '영어 연습을 켰습니다. 다만 지금은 오프라인이라 음성 코치가 제한됩니다. 인터넷 연결 후 다시 해 주세요. (끄기: 영어 그만)',
            },
          })
        }
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (intent.kind === 'english-exit') {
        dispatch({ type: 'english-mode', on: false })
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: '영어 연습을 껐습니다. 이제 웹 검색·문서·앱 실행으로 돌아갑니다. (예: “강릉 날씨 조사해줘”, “보고서 만들어줘”, “크롬 설치해줘”)',
          },
        })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (intent.kind === 'talk') {
        // While the English app is on, keep practicing with the coach.
        if (state.englishMode) {
          if (state.network.online) {
            dispatch({ type: 'busy', busy: true })
            await pushCoach(dispatch, raw, replyToTalk(raw), prior)
            dispatch({ type: 'busy', busy: false })
          } else {
            dispatch({
              type: 'chat',
              turn: { id: `n-${Date.now()}`, role: 'neu', text: replyToTalk(raw) },
            })
          }
          dispatch({ type: 'phase', phase: 'lui' })
          return
        }
        // Default first screen = productivity router, NOT an English tutor.
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: routerHint(raw),
          },
        })
        dispatch({ type: 'phase', phase: 'lui' })
        return
      }

      if (intent.kind === 'app-install') {
        try {
          const result = await planAppInstall(raw, 'lui')
          const plan = result.plan
          const line = plan
            ? `${plan.next ?? ''} ${plan.command}`.trim()
            : 'Could not read this PC’s base yet.'
          if (state.network.online) {
            dispatch({ type: 'busy', busy: true })
            await pushCoach(
              dispatch,
              `The learner asked to install software: "${raw}". Restate it, then give this command and ask them to confirm before running it: ${line}`,
              line,
              prior,
            )
            dispatch({ type: 'busy', busy: false })
          } else {
            dispatch({
              type: 'chat',
              turn: { id: `n-${Date.now()}`, role: 'neu', text: line },
            })
          }
          if (result.preference?.installSurface === 'prompt') {
            dispatch({ type: 'phase', phase: 'jeos' })
          } else {
            dispatch({ type: 'phase', phase: 'lui' })
          }
        } catch {
          dispatch({
            type: 'chat',
            turn: { id: `n-${Date.now()}`, role: 'neu', text: 'Could not build an install guide.' },
          })
        }
        return
      }

      if (intent.kind === 'studio') {
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: 'Opening the four layers. Speech to the screen, eyes to pixels, brain to a plan, hands to clicks.',
          },
        })
        dispatch({ type: 'phase', phase: 'studio' })
        return
      }

      if (intent.kind === 'hardware') {
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: 'Back to the same check screen as right after power-on.',
          },
        })
        dispatch({ type: 'phase', phase: 'post' })
        return
      }

      if (intent.kind === 'web') {
        const href = intent.query ? searchUrl(intent.query) : 'https://www.neuavenue.com'
        const onlineText = intent.query
          ? `Looking up “${intent.query}”. Opening the results.`
          : 'Opening www.neuavenue.com. Surf from there.'
        dispatch({
          type: 'chat',
          turn: {
            id: `n-${Date.now()}`,
            role: 'neu',
            text: state.network.online
              ? onlineText
              : intent.query
                ? `No outside connection, so I cannot search “${intent.query}” yet. Check the internet first.`
                : 'No outside connection. The local landing page is home.',
          },
        })
        if (state.network.online) {
          dispatch({ type: 'browse-target', href })
        }
        dispatch({ type: 'sandbox', sandbox: 'web' })
        dispatch({ type: 'phase', phase: 'landing' })
        return
      }

      if (intent.kind === 'sheet-report') {
        openOffice('sheet')
        return
      }
      if (intent.kind === 'doc') {
        openOffice('doc')
        return
      }
      if (intent.kind === 'slides') {
        openOffice('slides')
        return
      }
    },
    [state.busy, state.network, state.pendingGuide, openOffice],
  )

  const runPipelineOn = useCallback(
    async (root: HTMLElement) => {
      if (!state.pipeline || state.busy) return
      dispatch({ type: 'busy', busy: true })
      let pipeline = state.pipeline
      let driver = state.driver

      const box = sandboxRect(root)
      let sampled = false

      const look = (query: string) => {
        const frame = harvestUiGraph(root, query)
        dispatch({ type: 'vision', vision: frame })
        if (!sampled) {
          sampled = true
          void recordVisionSample({
            id: `vlm-${pipeline.id}`,
            query,
            capturedAt: Date.now(),
            boxes: frame.elements,
          })
        }
        return frame
      }

      const send = async (
        kind: 'click' | 'type' | 'hotkey' | 'isolate',
        label: string,
        extra?: { x?: number; y?: number; text?: string; keys?: string },
      ) => {
        try {
          const result = await actDriver({
            kind,
            sandbox: box,
            x: extra?.x !== undefined ? box.left + extra.x : undefined,
            y: extra?.y !== undefined ? box.top + extra.y : undefined,
            text: extra?.text,
            keys: extra?.keys,
          })
          const tag = result.dryRun ? `${label} · dry ${result.backend}` : `${label} · ${result.backend}`
          driver = pushEvent(driver, kind === 'isolate' ? 'isolate' : kind, tag)
        } catch {
          driver = pushEvent(driver, kind === 'isolate' ? 'isolate' : kind, `${label} · no bridge`)
        }
        dispatch({ type: 'driver', driver })
      }

      const mark = (id: string, status: 'running' | 'done' | 'heal' | 'fail', healNote?: string) => {
        pipeline = withStep(pipeline, id, { status, healNote })
        dispatch({ type: 'pipeline', pipeline })
      }

      try {
        for (const step of pipeline.steps) {
          mark(step.id, 'running')
          await wait(420)

          const title = step.title.toLowerCase()
          const mentions = (...needles: string[]) => needles.some((n) => title.includes(n.toLowerCase()))

          if (step.layer === 'vlm') {
            const query = mentions('save', '저장')
              ? 'save'
              : mentions('title', '제목')
                ? 'title'
                : 'input'
            look(query)
            await wait(360)
            mark(step.id, 'done')
            continue
          }

          if (mentions('isolate', 'open browser', '연다', '격리')) {
            driver = isolate(driver)
            dispatch({ type: 'driver', driver })
            await send('isolate', 'App isolated in its own space')
            mark(step.id, 'done')
            continue
          }

          const frame = harvestUiGraph(root, step.title)
          dispatch({ type: 'vision', vision: frame })

          const targetId = mentions('title', '제목')
            ? 'title'
            : mentions('body', 'numbers', 'sentences', 'fill', '본문', '숫자', '문장')
              ? state.sandbox === 'doc'
                ? 'editor'
                : 'cell-0-0'
              : mentions('save', '저장')
                ? 'save'
                : mentions('address', '주소')
                  ? 'url'
                  : 'title'

          const el = pick(frame, targetId)

          if (mentions('click save', '저장을 실행') && el) {
            mark(step.id, 'heal', 'Save was missed on the first look. Retrying with a hotkey.')
            await wait(500)
            await send('hotkey', 'Ctrl+S', { keys: 'ctrl+s' })
            if (state.sandbox === 'sheet') dispatch({ type: 'saved-sheet', value: true })
            if (state.sandbox === 'doc') dispatch({ type: 'saved-doc', value: true })
            mark(step.id, 'done', 'Healed save with a keyboard shortcut.')
            continue
          }

          if (el) {
            const pt = centerOf(el)
            driver = moveCursor(driver, pt.x, pt.y)
            const typing = mentions('type', 'fill', '입력', '채운', '받아')
            await send(
              typing ? 'type' : 'click',
              `${el.label} @ ${pt.x}, ${pt.y}`,
              typing
                ? { x: pt.x, y: pt.y, text: typing ? 'Weekly progress report' : undefined }
                : { x: pt.x, y: pt.y },
            )
            await wait(280)
          } else {
            await send('click', 'No target — falling back to the keyboard')
          }

          if (mentions('save to', 'click save', '남긴', '저장을')) {
            if (state.sandbox === 'sheet') dispatch({ type: 'saved-sheet', value: true })
            if (state.sandbox === 'doc') dispatch({ type: 'saved-doc', value: true })
          }

          mark(step.id, 'done')
        }
      } finally {
        dispatch({ type: 'busy', busy: false })
      }
    },
    [state.busy, state.driver, state.pipeline, state.sandbox],
  )

  const api = useMemo<NeuApi>(
    () => ({
      ...state,
      go,
      setHardware,
      setNetwork,
      submit,
      runPipelineOn,
      goHome,
      openExit,
      closeExit,
      chooseJeos,
      chooseLoop,
      quitApp,
      uninstallAndLeave,
      goBack,
      openOffice,
      setOfficeModel,
      setAccount,
      setAuthPanel,
      clearBrowseTarget,
      openWeb,
      openDaf,
      dismissDafPopup,
      toggleVitality,
      appendNeu,
      beginChat,
      patchChat,
      dropChat,
      openPath,
      clearInstallIntent,
      openManual,
      closeManual,
      openDownload,
      closeDownload,
      setChromeMenuOpen,
      toggleChromeMenu,
      chromeX,
    }),
    [state, go, setHardware, setNetwork, submit, runPipelineOn, goHome, openExit, closeExit, chooseJeos, chooseLoop, quitApp, uninstallAndLeave, goBack, openOffice, setOfficeModel, setAccount, setAuthPanel, clearBrowseTarget, openWeb, openDaf, dismissDafPopup, toggleVitality, appendNeu, beginChat, patchChat, dropChat, openPath, clearInstallIntent, openManual, closeManual, openDownload, closeDownload, setChromeMenuOpen, toggleChromeMenu, chromeX],
  )

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>
}

export function useNeu(): NeuApi {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('NeuProvider missing')
  return ctx
}
