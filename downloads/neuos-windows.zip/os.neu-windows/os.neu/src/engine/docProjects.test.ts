import { describe, expect, it } from 'vitest'
import {
  addDocProject,
  addFolderProject,
  childrenOf,
  flattenDocTree,
  moveDocProject,
  normalizeDocProjects,
  removeDocProject,
  upsertDocProject,
  type DocProject,
} from './docProjects'

describe('docProjects tree', () => {
  it('normalizes legacy flat rows', () => {
    const rows = normalizeDocProjects([{ id: 'a', name: 'A', title: 'A', body: 'x', updated: 1 }])
    expect(rows[0].kind).toBe('doc')
    expect(rows[0].parentId).toBe(null)
  })

  it('keeps each project body independent when updating one', () => {
    const a: DocProject = {
      id: 'a',
      name: 'A',
      title: 'A',
      body: 'alpha',
      updated: 1,
      kind: 'doc',
      parentId: null,
    }
    const b: DocProject = {
      id: 'b',
      name: 'B',
      title: 'B',
      body: '',
      updated: 1,
      kind: 'doc',
      parentId: null,
    }
    const next = upsertDocProject([a, b], { ...a, body: 'alpha edited', updated: 2 })
    expect(next.find((p) => p.id === 'a')?.body).toBe('alpha edited')
    expect(next.find((p) => p.id === 'b')?.body).toBe('')
  })

  it('builds hierarchy: folder → docs', () => {
    let rows: DocProject[] = []
    const folder = addFolderProject(rows, { name: 'Customers' })
    rows = folder.rows
    const d1 = addDocProject(rows, { parentId: folder.node.id, name: 'Acme', title: 'Acme' })
    rows = d1.rows
    const d2 = addDocProject(rows, { parentId: folder.node.id, name: 'Beta', title: 'Beta' })
    rows = d2.rows
    expect(childrenOf(rows, folder.node.id)).toHaveLength(2)
    const flat = flattenDocTree(rows, new Set([folder.node.id]))
    expect(flat.map((r) => r.name)).toEqual(['Customers', 'Acme', 'Beta'])
    expect(flat[1].depth).toBe(1)
  })

  it('collapses children when folder not expanded', () => {
    let rows: DocProject[] = []
    const folder = addFolderProject(rows, { name: 'Box' })
    rows = folder.rows
    rows = addDocProject(rows, { parentId: folder.node.id, name: 'Hidden' }).rows
    const flat = flattenDocTree(rows, new Set())
    expect(flat.map((r) => r.name)).toEqual(['Box'])
  })

  it('remove folder drops descendants', () => {
    let rows: DocProject[] = []
    const folder = addFolderProject(rows, { name: 'Drop' })
    rows = folder.rows
    const child = addDocProject(rows, { parentId: folder.node.id, name: 'Child' })
    rows = child.rows
    rows = upsertDocProject(rows, { ...child.node, body: 'bye' })
    rows = removeDocProject(rows, folder.node.id)
    expect(rows.find((r) => r.id === folder.node.id)).toBeUndefined()
    expect(rows.find((r) => r.id === child.node.id)).toBeUndefined()
  })

  it('move doc from folder A to folder B', () => {
    let rows: DocProject[] = []
    const a = addFolderProject(rows, { name: 'A' })
    rows = a.rows
    const b = addFolderProject(rows, { name: 'B' })
    rows = b.rows
    const doc = addDocProject(rows, { parentId: a.node.id, name: 'Memo' })
    rows = doc.rows
    rows = moveDocProject(rows, doc.node.id, b.node.id)
    expect(rows.find((r) => r.id === doc.node.id)?.parentId).toBe(b.node.id)
    expect(childrenOf(rows, a.node.id)).toHaveLength(0)
    expect(childrenOf(rows, b.node.id).map((r) => r.name)).toEqual(['Memo'])
  })
})
