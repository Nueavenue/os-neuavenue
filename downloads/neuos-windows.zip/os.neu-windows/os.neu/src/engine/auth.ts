const SESSION_KEY = 'os.neu.session'
const TOKEN_KEY = 'os.neu.token'

export type AuthUser = {
  name: string
  email: string
  admin: boolean
}

export function sessionId() {
  let id = localStorage.getItem(SESSION_KEY)
  if (!id) {
    id = `s-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    localStorage.setItem(SESSION_KEY, id)
  }
  return id
}

export function readToken() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

function headers() {
  const token = readToken()
  return {
    'content-type': 'application/json',
    ...(token ? { 'x-osneu-token': token } : {}),
  }
}

export async function trackEvent(kind: 'view' | 'click' | 'login' | 'logout' | 'open-app' | 'feedback', screen: string, label?: string) {
  try {
    const { ga4Track } = await import('./ga4')
    ga4Track(kind, screen, label)
  } catch {
    /* ga4 optional */
  }
  try {
    await fetch('/api/track', {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ session: sessionId(), kind, screen, label }),
    })
  } catch {
    /* tracking is best-effort */
  }
}

export async function loginRequest(email: string, password: string) {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  const body = (await res.json()) as { ok: boolean; token?: string; user?: AuthUser; reason?: string }
  if (body.ok && body.token && body.user) localStorage.setItem(TOKEN_KEY, body.token)
  return body
}

export async function registerRequest(name: string, email: string, password: string) {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  })
  const body = (await res.json()) as {
    ok: boolean
    token?: string
    user?: AuthUser
    reason?: string
    needsConfirm?: boolean
  }
  if (body.ok && body.token && body.user) localStorage.setItem(TOKEN_KEY, body.token)
  return body
}

export async function logoutRequest() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', headers: headers() })
  } finally {
    localStorage.removeItem(TOKEN_KEY)
  }
}

export async function fetchMe() {
  const token = readToken()
  if (!token) return null
  const res = await fetch('/api/auth/me', { headers: headers() })
  const body = (await res.json()) as { ok: boolean; user?: AuthUser | null }
  return body.user ?? null
}

export async function acceptSessionToken(token: string) {
  const neat = String(token || '').trim()
  if (!neat) return null
  localStorage.setItem(TOKEN_KEY, neat)
  return fetchMe()
}

export async function consumeAuthRedirect() {
  try {
    const url = new URL(window.location.href)
    const token = url.searchParams.get('osneu_token')
    if (!token) return null
    url.searchParams.delete('osneu_token')
    window.history.replaceState({}, '', url.pathname + url.search + url.hash)
    return acceptSessionToken(token)
  } catch {
    return null
  }
}

const HANDOFF_KEY = 'os.neu.oauth.handoff'

export function rememberOAuthHandoff(id: string) {
  const neat = String(id || '').trim()
  if (!neat) return
  try {
    sessionStorage.setItem(HANDOFF_KEY, neat)
  } catch {
    /* ignore */
  }
}

export function readRememberedOAuthHandoff() {
  try {
    return sessionStorage.getItem(HANDOFF_KEY) || ''
  } catch {
    return ''
  }
}

export function clearRememberedOAuthHandoff() {
  try {
    sessionStorage.removeItem(HANDOFF_KEY)
  } catch {
    /* ignore */
  }
}

export async function startGoogleOAuth() {
  const handoff = sessionId()
  rememberOAuthHandoff(handoff)
  const res = await fetch(`/api/auth/oauth/google?handoff=${encodeURIComponent(handoff)}`)
  const body = (await res.json()) as { ok: boolean; url?: string; reason?: string }
  if (!body.ok || !body.url) return body

  // Google blocks Electron / embedded WebViews ("This browser or app may not be secure").
  // Never navigate the main os.neu window away — closing that Google page would quit the app.
  const browse = window.neuos?.browse
  if (browse?.openExternal) {
    await browse.openExternal(body.url)
    return { ok: true as const, via: 'external' as const, handoff }
  }
  const popup = window.open(body.url, 'osneu-google-oauth', 'noopener,noreferrer,width=520,height=740')
  if (!popup) {
    return { ok: false as const, reason: 'popup-blocked', handoff }
  }
  return { ok: true as const, via: 'popup' as const, handoff }
}

/** Poll bridge until system-browser / popup OAuth posts the session token. */
export async function waitForGoogleHandoff(handoff: string, ms = 180_000) {
  const id = String(handoff || '').trim()
  if (!id) return null
  const started = Date.now()
  while (Date.now() - started < ms) {
    try {
      const res = await fetch(`/api/auth/oauth/handoff?handoff=${encodeURIComponent(id)}&peek=1`)
      const body = (await res.json()) as { ok?: boolean; token?: string; pending?: boolean }
      if (body.ok && body.token) {
        const user = await acceptSessionToken(body.token)
        if (user) {
          await fetch(`/api/auth/oauth/handoff?handoff=${encodeURIComponent(id)}`).catch(() => null)
          clearRememberedOAuthHandoff()
          return user
        }
      }
    } catch {
      /* keep waiting */
    }
    await new Promise((r) => setTimeout(r, 900))
  }
  return null
}

export async function sendFeedback(title: string, body: string) {
  const res = await fetch('/api/feedback', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ title, body }),
  })
  return (await res.json()) as { ok: boolean; reason?: string; cloud?: boolean }
}

/**
 * WO-UI-NEU-COMMAND-VIEW-ICON-121 (UI-B27) — gate for the os.neu Command
 * View chrome icon. Server-side check of `public.current_site_role()`
 * (ceo | leader | shareholder | admin), never the `AuthUser.admin` mailbox
 * heuristic. Fails closed (false) on signed-out, local-only accounts.json
 * sessions, supabase-off, or any request error.
 */
export async function fetchCommandViewEntitlement() {
  try {
    if (!readToken()) return false
    const res = await fetch('/api/auth/command-view', { headers: headers() })
    const body = (await res.json()) as { ok?: boolean; allowed?: boolean }
    return Boolean(body.ok && body.allowed)
  } catch {
    return false
  }
}

export async function fetchAdminStats() {
  const res = await fetch('/api/admin/stats', { headers: headers() })
  return res.json() as Promise<Record<string, unknown>>
}
