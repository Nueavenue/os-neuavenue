/**
 * WO-UI-NEU-PPT-PREVIEW-SCHEMA-123B (122B) — Preview slides from the same
 * contract as the planner (structure[] + packPolicy + layout primitives).
 */
import { expandStructureKeys, resolveSlideCount, storyboardRows } from './generationPlanner'
import type { LayoutPrimitiveId } from './layoutContract'
import type { PresentationTemplate } from './presentationTemplates'

export type PreviewSlide = {
  key: string
  title: string
  layout: LayoutPrimitiveId
}

export function previewSlidesFromTemplate(template: PresentationTemplate, requestedCount?: number): PreviewSlide[] {
  return storyboardRows(template, requestedCount).map((row) => ({
    key: row.key,
    title: row.title,
    layout: row.layout,
  }))
}

export function previewKeysForCount(template: PresentationTemplate, requestedCount?: number): string[] {
  const count = resolveSlideCount(template, requestedCount)
  return expandStructureKeys(template.structure, count)
}
