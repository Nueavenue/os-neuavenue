import { describe, expect, it } from 'vitest'
import {
  HOSTED_OPENAI_HEADER,
  hostedAssistHeaders,
  isHostedOsNeuFace,
  lookLikeOpenAiKey,
  readHostedOpenAiKey,
  writeHostedOpenAiKey,
} from './hostedLlm'

describe('hostedLlm', () => {
  it('detects Door B host only', () => {
    expect(isHostedOsNeuFace('os.neuavenue.com')).toBe(true)
    expect(isHostedOsNeuFace('docs.neuavenue.com')).toBe(false)
    expect(isHostedOsNeuFace('127.0.0.1')).toBe(false)
  })

  it('stores a session key and attaches the header on hosted only', () => {
    const mem = new Map<string, string>()
    const storage = {
      getItem: (k: string) => mem.get(k) ?? null,
      setItem: (k: string, v: string) => void mem.set(k, v),
      removeItem: (k: string) => void mem.delete(k),
    }
    expect(lookLikeOpenAiKey('nope')).toBe(false)
    expect(writeHostedOpenAiKey(storage, 'sk-testkey-12345678901234567890')).toBe(true)
    expect(readHostedOpenAiKey(storage).startsWith('sk-')).toBe(true)
    const hosted = hostedAssistHeaders('os.neuavenue.com', storage) as Record<string, string>
    expect(hosted[HOSTED_OPENAI_HEADER]).toMatch(/^sk-/)
    const local = hostedAssistHeaders('127.0.0.1', storage) as Record<string, string>
    expect(local[HOSTED_OPENAI_HEADER]).toBeUndefined()
  })
})
