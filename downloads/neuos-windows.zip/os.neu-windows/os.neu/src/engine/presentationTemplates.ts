/**
 * WO-UI-NEU-SLIDES-PPT-STUDIO-STEP1-VISUAL-121 — Leader spec §15 template contract.
 * Templates carry visual/style/structure metadata; runtime deck still loads generic
 * pitch | report | product packs (6 slides, title | bullets | table).
 */
import type { OutlinePackId } from './slideOutlines'
import { getLicensedPilot } from './licenseImport'

export type TemplateGroup = 'featured' | 'popular'

export type TemplateCategory =
  | 'Investor'
  | 'Business'
  | 'Product'
  | 'Tech'
  | 'Marketing'
  | 'Education'
  | 'Report'
  | 'Custom'

export type TemplatePreviewTheme = 'neu-investor' | 'modern-business' | 'tech-arch' | 'minimal-corp' | 'dark-tech' | 'pitch' | 'paper' | 'report' | 'marketing' | 'training'

export type PresentationTemplateStyle = {
  theme: string
  typography: string
  density: 'light' | 'medium' | 'dense'
  visualTone: string
  accent: string
}

export type TemplatePackPolicy = {
  defaultSlides: number
  minSlides: number
  maxSlides: number
}

/** 122E — license metadata on imported / pilot templates. Native five omit this. */
export type TemplateLicenseMeta = {
  source: string
  license: string
  licenseUrl: string
  attributionRequired: boolean
  attributionText: string
}

export type PresentationTemplate = {
  id: string
  name: string
  nameKo: string
  category: TemplateCategory
  /** Category pill filter id (lowercase) */
  categoryFilter: string
  description: string
  descriptionKo: string
  /** Short line under title on card */
  cardSubtitle: string
  cardSubtitleKo: string
  aspectRatio: '16:9'
  /** Leader §15; `ppt-preview://` maps to CSS 16:9 until `.webp` assets ship */
  previewImage?: string
  previewTheme: TemplatePreviewTheme
  style: PresentationTemplateStyle
  structure: string[]
  /** Slide count policy (Leader runtime §4). */
  packPolicy: TemplatePackPolicy
  group: TemplateGroup
  pack: OutlinePackId
  license?: TemplateLicenseMeta
}

export const CATEGORY_FILTERS: { id: string; en: string; ko: string }[] = [
  { id: 'all', en: 'All', ko: '전체' },
  { id: 'investor', en: 'Investor', ko: '투자' },
  { id: 'business', en: 'Business', ko: '비즈니스' },
  { id: 'product', en: 'Product', ko: '제품' },
  { id: 'tech', en: 'Tech', ko: '기술' },
  { id: 'marketing', en: 'Marketing', ko: '마케팅' },
  { id: 'education', en: 'Education', ko: '교육' },
  { id: 'report', en: 'Report', ko: '보고' },
  { id: 'custom', en: 'Custom', ko: '사용자' },
]

export const PRESENTATION_TEMPLATES: PresentationTemplate[] = [
  {
    id: 'neu-investor-dark',
    name: 'NEU Investor Deck',
    nameKo: 'NEU 투자 덱',
    category: 'Investor',
    categoryFilter: 'investor',
    description: 'Professional investor deck for funding, partnerships and strategic discussions.',
    descriptionKo: '펀딩·파트너십·전략 논의용 투자 프레젠테이션.',
    cardSubtitle: 'For funding and partnerships',
    cardSubtitleKo: '펀딩 및 파트너십',
    aspectRatio: '16:9',
    previewTheme: 'neu-investor',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'premium',
      accent: 'blue-purple',
    },
    structure: [
      'cover',
      'problem',
      'solution',
      'market',
      'product',
      'technology',
      'business-model',
      'traction',
      'roadmap',
      'team',
      'funding',
      'closing',
    ],
    packPolicy: { defaultSlides: 12, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'pitch',
  },
  {
    id: 'modern-business',
    name: 'Modern Business',
    nameKo: '모던 비즈니스',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Clean and professional business narrative.',
    descriptionKo: '깔끔하고 전문적인 비즈니스 내러티브.',
    cardSubtitle: 'Clean & professional',
    cardSubtitleKo: '단정 · 프로페셔널',
    aspectRatio: '16:9',
    previewTheme: 'modern-business',
    style: {
      theme: 'light-minimal',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'calm',
      accent: 'slate',
    },
    structure: ['cover', 'agenda', 'overview', 'highlights', 'next-steps'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'pitch',
  },
  {
    id: 'tech-architecture',
    name: 'Tech Architecture',
    nameKo: '기술 아키텍처',
    category: 'Tech',
    categoryFilter: 'tech',
    description: 'Technical diagrams and system overview.',
    descriptionKo: '기술 다이어그램과 시스템 개요.',
    cardSubtitle: 'Technical diagrams',
    cardSubtitleKo: '기술 다이어그램',
    aspectRatio: '16:9',
    previewTheme: 'tech-arch',
    style: {
      theme: 'dark-grid',
      typography: 'space-grotesk',
      density: 'medium',
      visualTone: 'technical',
      accent: 'electric-blue',
    },
    structure: [
      'cover',
      'context',
      'architecture',
      'components',
      'data-flow',
      'security',
      'scalability',
      'integration',
      'roadmap',
      'closing',
    ],
    packPolicy: { defaultSlides: 10, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
  },
  {
    id: 'minimal-corporate',
    name: 'Minimal Corporate',
    nameKo: '미니멀 코퍼레이트',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Simple and elegant corporate reporting.',
    descriptionKo: '단순하고 우아한 기업 보고.',
    cardSubtitle: 'Simple & elegant',
    cardSubtitleKo: '심플 · 우아함',
    aspectRatio: '16:9',
    previewTheme: 'minimal-corp',
    style: {
      theme: 'light-typography',
      typography: 'ibm-plex',
      density: 'light',
      visualTone: 'corporate',
      accent: 'neutral',
    },
    structure: ['cover', 'summary', 'vision', 'progress', 'metrics', 'risks', 'team', 'next'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'report',
  },
  {
    id: 'dark-tech',
    name: 'Dark Tech',
    nameKo: '다크 테크',
    category: 'Tech',
    categoryFilter: 'tech',
    description: 'Bold modern product story on dark canvas.',
    descriptionKo: '다크 캔버스의 대담한 제품 스토리.',
    cardSubtitle: 'Bold & modern',
    cardSubtitleKo: '볼드 · 모던',
    aspectRatio: '16:9',
    previewTheme: 'dark-tech',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'premium',
      accent: 'purple-blue',
    },
    structure: ['cover', 'problem', 'product', 'features', 'comparison', 'next'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
  },
  {
    id: 'product-launch',
    name: 'Product Launch',
    nameKo: '제품 런치',
    category: 'Product',
    categoryFilter: 'product',
    description: 'Launch narrative: problem, steps, comparison, and next.',
    descriptionKo: '런치 내러티브: 문제, 단계, 비교, 다음.',
    cardSubtitle: 'Ship the story',
    cardSubtitleKo: '출시 이야기',
    aspectRatio: '16:9',
    previewTheme: 'dark-tech',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'launch',
      accent: 'purple-blue',
    },
    structure: ['cover', 'problem', 'audience', 'steps', 'feature-comparison', 'benefits', 'timeline', 'next'],
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'featured',
    pack: 'product',
  },
  {
    id: 'popular-pitch-deck',
    name: 'Pitch Deck',
    nameKo: '피치 덱',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Classic pitch flow in six slides.',
    descriptionKo: '6장 클래식 피치 흐름.',
    cardSubtitle: 'Problem → Ask',
    cardSubtitleKo: '문제 → 요청',
    aspectRatio: '16:9',
    previewTheme: 'pitch',
    style: {
      theme: 'dark-tech',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'startup',
      accent: 'blue-purple',
    },
    structure: ['cover', 'problem', 'solution', 'market', 'team', 'ask'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
  },
  {
    id: 'business-plan',
    name: 'Business Plan',
    nameKo: '사업 계획',
    category: 'Business',
    categoryFilter: 'business',
    description: 'Plan outline from cover through next steps.',
    descriptionKo: '표지부터 다음 단계까지 사업 계획 개요.',
    cardSubtitle: 'Strategy outline',
    cardSubtitleKo: '전략 개요',
    aspectRatio: '16:9',
    previewTheme: 'paper',
    style: {
      theme: 'light-minimal',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'professional',
      accent: 'slate',
    },
    structure: ['cover', 'vision', 'market', 'model', 'plan', 'milestones'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
  },
  {
    id: 'research-report',
    name: 'Research Report',
    nameKo: '리서치 보고',
    category: 'Report',
    categoryFilter: 'report',
    description: 'Findings, metrics table, and recommendations.',
    descriptionKo: '발견, 지표 표, 권고.',
    cardSubtitle: 'Findings & metrics',
    cardSubtitleKo: '발견 · 지표',
    aspectRatio: '16:9',
    previewTheme: 'report',
    style: {
      theme: 'mist',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'analytical',
      accent: 'teal',
    },
    structure: ['cover', 'summary', 'method', 'findings', 'metrics', 'recommendations'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'report',
  },
  {
    id: 'marketing-plan',
    name: 'Marketing Plan',
    nameKo: '마케팅 계획',
    category: 'Marketing',
    categoryFilter: 'marketing',
    description: 'Campaign narrative and roadmap table.',
    descriptionKo: '캠페인 내러티브와 로드맵 표.',
    cardSubtitle: 'Campaign focus',
    cardSubtitleKo: '캠페인 중심',
    aspectRatio: '16:9',
    previewTheme: 'marketing',
    style: {
      theme: 'light-vivid',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'energetic',
      accent: 'coral',
    },
    structure: ['cover', 'audience', 'message', 'channels', 'timeline', 'kpis'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'pitch',
  },
  {
    id: 'training-education',
    name: 'Training & Education',
    nameKo: '교육 · 트레이닝',
    category: 'Education',
    categoryFilter: 'education',
    description: 'Step-by-step learning deck with feature table.',
    descriptionKo: '단계별 학습 덱과 기능 표.',
    cardSubtitle: 'Steps & exercises',
    cardSubtitleKo: '단계 · 실습',
    aspectRatio: '16:9',
    previewTheme: 'training',
    style: {
      theme: 'grid',
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'friendly',
      accent: 'green',
    },
    structure: ['cover', 'objectives', 'steps', 'demo', 'quiz', 'resources'],
    packPolicy: { defaultSlides: 6, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack: 'product',
  },
]

export function packPolicyFor(template: PresentationTemplate): TemplatePackPolicy {
  return template.packPolicy
}

export function resolvePreviewImage(t: PresentationTemplate): string {
  return t.previewImage ?? `ppt-preview://${t.id}`
}

export function titleColorForTemplate(t: PresentationTemplate | null | undefined): string | undefined {
  if (!t) return undefined
  const accent = t.style.accent
  if (accent.includes('purple') || accent.includes('blue')) return '4F46E5'
  if (accent.includes('teal')) return '0D9488'
  if (accent.includes('coral')) return 'EA580C'
  if (accent.includes('green')) return '059669'
  return '1E293B'
}

export function getTemplateById(id: string): PresentationTemplate | undefined {
  const native = PRESENTATION_TEMPLATES.find((t) => t.id === id)
  if (native) return native
  return getLicensedPilot(id)
}

export function filterTemplates(
  templates: PresentationTemplate[],
  categoryId: string,
  query: string,
): PresentationTemplate[] {
  const q = query.trim().toLowerCase()
  return templates.filter((t) => {
    if (categoryId !== 'all') {
      if (categoryId === 'custom') {
        if (t.category !== 'Custom') return false
      } else if (categoryId === 'product') {
        if (t.pack !== 'product' && t.categoryFilter !== 'product') return false
      } else if (t.categoryFilter !== categoryId) return false
    }
    if (!q) return true
    const blob = `${t.name} ${t.nameKo} ${t.description} ${t.category} ${t.cardSubtitle}`.toLowerCase()
    return blob.includes(q)
  })
}
