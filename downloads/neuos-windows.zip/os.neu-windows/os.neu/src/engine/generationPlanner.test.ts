import { describe, expect, it } from 'vitest'
import { exportSlidesToPptx } from './pptxExport'
import { getTemplateById } from './presentationTemplates'
import {
  allowedSlideCounts,
  planSlidesFromTemplate,
  parseRequestedSlideCount,
  resolveSlideCount,
  storyboardRows,
} from './generationPlanner'
import { themeForTemplate, themeToPptxHints } from './presentationThemes'
import { serializeRecipe } from './slidesRecipe'

describe('generationPlanner — Leader Tests A/B/C', () => {
  it('Test A: NEU Investor Deck → 12 slides', () => {
    const t = getTemplateById('neu-investor-dark')!
    const slides = planSlidesFromTemplate(t)
    expect(slides).toHaveLength(12)
    expect(slides[1].title).toMatch(/Problem/i)
    expect(slides[11].title).toMatch(/Closing/i)
  })

  it('Test B: Technical Architecture → 10 slides', () => {
    const t = getTemplateById('tech-architecture')!
    expect(planSlidesFromTemplate(t)).toHaveLength(10)
  })

  it('Test C: Minimal Corporate → 8 slides', () => {
    const t = getTemplateById('minimal-corporate')!
    expect(planSlidesFromTemplate(t)).toHaveLength(8)
  })

  it('parseRequestedSlideCount from prompt text', () => {
    const t = getTemplateById('neu-investor-dark')!
    expect(parseRequestedSlideCount('Create a 12-slide investor presentation', t)).toBe(12)
  })

  it('allowedSlideCounts stays inside packPolicy 6–20 and the allow-list', () => {
    const t = getTemplateById('neu-investor-dark')!
    const counts = allowedSlideCounts(t)
    expect(counts[0]).toBeGreaterThanOrEqual(6)
    expect(counts[counts.length - 1]).toBeLessThanOrEqual(20)
    expect(counts).toContain(12)
    expect(counts).not.toContain(7)
    expect(resolveSlideCount(t, 7)).toBe(12)
    expect(resolveSlideCount(t, 20)).toBe(20)
  })

  it('122C planner stamps primitive so PPTX can emit layout shapes', () => {
    const t = getTemplateById('neu-investor-dark')!
    const slides = planSlidesFromTemplate(t)
    expect(slides[0].primitive).toBe('title')
    expect(slides.find((s) => /Problem/i.test(s.title))?.primitive).toBe('two-column')
    expect(slides.find((s) => /Traction/i.test(s.title))?.primitive).toBe('metric')
    expect(slides[slides.length - 1].primitive).toBe('section-divider')
    const text = new TextDecoder().decode(exportSlidesToPptx(serializeRecipe('Investor', slides), new Date('2026-09-27T00:00:00Z')))
    expect(text).toContain('TwoColumnLeft')
    expect(text).toContain('MetricValue')
    expect(text).toContain('SectionDivider')
  })

  it('storyboardRows match planned length and feed planSlidesFromTemplate', () => {
    const t = getTemplateById('neu-investor-dark')!
    const rows = storyboardRows(t, 8)
    expect(rows).toHaveLength(8)
    expect(rows[0].role).toBe('title')
    expect(rows.map((r) => r.key)).toContain('cover')
    const planned = planSlidesFromTemplate(t, 8)
    expect(planned).toHaveLength(rows.length)
    expect(planned[0].layout).toBe('title')
  })
})

describe('themed PPTX export', () => {
  it('Investor vs Minimal themes produce different accent colors in OOXML', () => {
    const investor = getTemplateById('neu-investor-dark')!
    const minimal = getTemplateById('minimal-corporate')!
    const slide = planSlidesFromTemplate(investor)[0]
    const bytesA = exportSlidesToPptx(serializeRecipe('A', [slide]), new Date('2026-09-23T00:00:00Z'), themeToPptxHints(themeForTemplate(investor)))
    const bytesB = exportSlidesToPptx(serializeRecipe('B', [slide]), new Date('2026-09-23T00:00:00Z'), themeToPptxHints(themeForTemplate(minimal)))
    const textA = new TextDecoder().decode(bytesA)
    const textB = new TextDecoder().decode(bytesB)
    expect(textA).toContain('6366F1')
    expect(textB).toContain('334155')
    expect(textA).not.toEqual(textB)
  })
})
