import { describe, expect, it } from 'vitest'
import { getTemplateById } from './presentationTemplates'
import { slidesFromTemplate } from './templateSlides'

describe('slidesFromTemplate', () => {
  it('builds 12 slides for neu-investor-dark', () => {
    const t = getTemplateById('neu-investor-dark')
    expect(t).toBeTruthy()
    const slides = slidesFromTemplate(t!)
    expect(slides.length).toBe(12)
    expect(slides[0].layout).toBe('title')
    expect(slides[0].title).toContain('NEU')
  })
})
