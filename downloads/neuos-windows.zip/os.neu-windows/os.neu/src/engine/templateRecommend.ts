import { assistOffice } from './office'
import { PRESENTATION_TEMPLATES, type PresentationTemplate } from './presentationTemplates'

function scoreTemplate(t: PresentationTemplate, query: string): number {
  const q = query.toLowerCase()
  const blob = `${t.name} ${t.nameKo} ${t.category} ${t.description} ${t.cardSubtitle} ${t.structure.join(' ')}`.toLowerCase()
  let score = 0
  for (const word of q.split(/\s+/).filter(Boolean)) {
    if (blob.includes(word)) score += 2
  }
  if (q.includes('invest') && t.categoryFilter === 'investor') score += 5
  if (q.includes('tech') && t.categoryFilter === 'tech') score += 4
  if (q.includes('report') && t.categoryFilter === 'report') score += 4
  if (q.includes('market') && t.structure.includes('market')) score += 3
  return score
}

export function rankTemplatesByQuery(query: string): PresentationTemplate[] {
  const ranked = [...PRESENTATION_TEMPLATES]
    .map((t) => ({ t, score: scoreTemplate(t, query) }))
    .sort((a, b) => b.score - a.score)
  return ranked.map((r) => r.t)
}

export async function recommendTemplates(query: string, model: string): Promise<PresentationTemplate[]> {
  const trimmed = query.trim()
  if (!trimmed) return PRESENTATION_TEMPLATES

  const local = rankTemplatesByQuery(trimmed)
  try {
    const catalog = PRESENTATION_TEMPLATES.map((t) => ({ id: t.id, name: t.name, category: t.category })).slice(0, 12)
    const result = await assistOffice({
      model,
      app: 'slides',
      instruction:
        'Pick up to 5 template ids that best match the user goal. Reply JSON only: {"ids":["id1","id2"]}. No dollar amounts.',
      content: JSON.stringify({ query: trimmed, templates: catalog }),
    })
    if (result.ok && result.text) {
      const match = result.text.match(/\{[\s\S]*\}/)
      if (match) {
        const parsed = JSON.parse(match[0]) as { ids?: string[] }
        if (Array.isArray(parsed.ids) && parsed.ids.length) {
          const byId = new Map(PRESENTATION_TEMPLATES.map((t) => [t.id, t]))
          const picked = parsed.ids.map((id) => byId.get(id)).filter(Boolean) as PresentationTemplate[]
          if (picked.length) {
            const rest = local.filter((t) => !picked.some((p) => p.id === t.id))
            return [...picked, ...rest]
          }
        }
      }
    }
  } catch {
    /* local rank only */
  }
  return local
}
