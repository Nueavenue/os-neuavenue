import { describe, expect, it } from 'vitest'
import { NATIVE_FIVE_IDS } from './layoutContract'
import {
  PACK_PICKER_PRIMARY,
  designLanguageFor,
  nativeFiveHaveDesignLanguage,
  structureBlurb,
  structureLabel,
} from './designLanguage'
import { getTemplateById } from './presentationTemplates'
import { phaseAfterGalleryCardUse } from './studioPhase'

describe('125B design language + structure labels', () => {
  it('native five each have typography, layout, visualStyle', () => {
    expect(nativeFiveHaveDesignLanguage()).toBe(true)
    for (const id of NATIVE_FIVE_IDS) {
      const lang = designLanguageFor(getTemplateById(id)!)
      expect(lang.typography.en.length).toBeGreaterThan(2)
      expect(lang.layout.en.length).toBeGreaterThan(2)
      expect(lang.visualStyle.en.length).toBeGreaterThan(2)
    }
  })

  it('numbers structure keys like the mock (01 Cover, 02 Problem)', () => {
    expect(structureLabel('cover', 0, false)).toBe('01 Cover')
    expect(structureLabel('problem', 1, false)).toBe('02 Problem')
    expect(structureLabel('cover', 0, true)).toBe('01 표지')
    expect(structureBlurb('market', false)).toMatch(/Market/)
  })
})

describe('125E pack UX is not primary', () => {
  it('hides Pitch/Report/Product as the studio deck story', () => {
    expect(PACK_PICKER_PRIMARY).toBe(false)
  })

  it('Q1 KEEP-EDITOR-DIRECT still lands on editor', () => {
    expect(phaseAfterGalleryCardUse()).toBe('editor')
  })
})
