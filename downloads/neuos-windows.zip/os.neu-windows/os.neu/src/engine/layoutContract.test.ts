import { describe, expect, it } from 'vitest'
import { defaultSlideCount, resolveSlideCount, storyboardRows } from './generationPlanner'
import {
  LAYOUT_PRIMITIVES,
  NATIVE_FIVE_IDS,
  isLayoutPrimitive,
  layoutForStructureKey,
  nativeFiveTemplates,
  recipeLayoutFor,
} from './layoutContract'
import { PRESENTATION_TEMPLATES } from './presentationTemplates'

describe('122A layout contract + native five', () => {
  it('registers six layout primitives including two-column, metric, section-divider', () => {
    expect(LAYOUT_PRIMITIVES).toEqual(['title', 'bullets', 'table', 'two-column', 'metric', 'section-divider'])
    expect(isLayoutPrimitive('two-column')).toBe(true)
    expect(recipeLayoutFor('two-column')).toBe('bullets')
    expect(recipeLayoutFor('metric')).toBe('table')
    expect(recipeLayoutFor('section-divider')).toBe('title')
  })

  it('each native five resolves structure, packPolicy, and default count', () => {
    const five = nativeFiveTemplates(PRESENTATION_TEMPLATES)
    expect(five).toHaveLength(5)
    expect(five.map((t) => t.id)).toEqual([...NATIVE_FIVE_IDS])
    for (const t of five) {
      expect(t.structure.length).toBeGreaterThanOrEqual(6)
      expect(t.packPolicy.minSlides).toBe(6)
      expect(t.packPolicy.maxSlides).toBe(20)
      const def = defaultSlideCount(t)
      expect(def).toBeGreaterThanOrEqual(6)
      expect(def).toBeLessThanOrEqual(20)
      expect(resolveSlideCount(t)).toBe(def)
      const rows = storyboardRows(t)
      expect(rows).toHaveLength(def)
      expect(rows[0].layout).toBe('title')
      expect(layoutForStructureKey(t.structure[0], 0)).toBe('title')
    }
  })
})
