import type { Phase } from '../types'

const QUERY_PHASES: Phase[] = [
  'home',
  'splash',
  'lui',
  'landing',
  'studio',
  'post',
  'workspace',
  'network',
  'install',
  'jeos',
  'announce',
  'plant',
  'admin',
  'preview-hub',
  'preview-a',
  'preview-b',
  'preview-c',
]

export function phaseFromQuery(go: string | null): Phase | null {
  if (!go) return null
  return QUERY_PHASES.includes(go as Phase) ? (go as Phase) : null
}

/** Splash-only auto-advance. Later screens must not be yanked back.
 * WO-UI-NEU-ONE-PAGE-LANDING-121: one scroll landing replaces the old
 * install→post fork — both planted and not-yet-planted land on the same
 * four-block page (it still contains the install cards either way). */
export function bootAfterSplash(_planted: boolean): Phase {
  return 'home'
}

export function shouldRunBootTimer(phase: Phase): boolean {
  return phase === 'splash'
}

/** Skip splash when URL already targets a screen (e.g. ?go=preview-a).
 * WO-UI-NEU-LANDING-FIRST-PAINT-121: `/` first paint is the four-block
 * `home` landing directly — no 1.8s splash on root. `?go=splash` still
 * works for debug (see QUERY_PHASES), it just no longer auto-advances
 * since the boot timer only fires when landed on splash via the timer
 * path, not this explicit query path. */
export function initialPhaseFromWindow(): Phase {
  if (typeof window === 'undefined') return 'home'
  const go = new URLSearchParams(window.location.search).get('go')
  return phaseFromQuery(go) ?? 'home'
}

export function isPreviewPhase(phase: Phase): boolean {
  return phase.startsWith('preview')
}
