import { describe, expect, it } from 'vitest'
import { fitDeck, fitSlide, slideFromOutline } from './contentFitter'
import type { RecipeSlide } from './slidesRecipe'

function slide(partial: Partial<RecipeSlide> & Pick<RecipeSlide, 'layout'>): RecipeSlide {
  return { title: '', body: '', bullets: [], table: null, ...partial }
}

describe('122D contentFitter', () => {
  it('short title / bullets stay clean', () => {
    const title = fitSlide(slide({ layout: 'title', title: 'Welcome', body: 'os.neu' }))
    expect(title.overflow).toBe(false)
    expect(title.severity).toBe('ok')
    const bullets = fitSlide(
      slide({ layout: 'bullets', title: 'Why', bullets: ['Fast', 'Local'], body: 'Fast\nLocal' }),
    )
    expect(bullets.overflow).toBe(false)
  })

  it('known long title and long bullets trigger overflow', () => {
    const longTitle = 'A'.repeat(120)
    expect(fitSlide(slide({ layout: 'title', title: longTitle, body: 'ok' })).overflow).toBe(true)
    expect(fitSlide(slide({ layout: 'title', title: longTitle })).messageKey).toBe('title-long')
    const longBullet = slide({
      layout: 'bullets',
      title: 'Why',
      bullets: ['B'.repeat(200)],
      body: 'B'.repeat(200),
    })
    expect(fitSlide(longBullet).overflow).toBe(true)
    expect(fitSlide(longBullet).messageKey).toBe('bullet-long')
  })

  it('too many bullets and two-column long lines overflow', () => {
    const many = slide({
      layout: 'bullets',
      title: 'List',
      bullets: ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
      body: '',
    })
    expect(fitSlide(many).overflow).toBe(true)
    expect(fitSlide(many).messageKey).toBe('too-many-bullets')
    const cols = slide({
      layout: 'bullets',
      primitive: 'two-column',
      title: 'Split',
      bullets: ['C'.repeat(90), 'Right'],
      body: '',
    })
    expect(fitSlide(cols).overflow).toBe(true)
    expect(fitSlide(cols).messageKey).toBe('bullet-long')
  })

  it('metric and section-divider use their own budgets', () => {
    const metricOk = slide({
      layout: 'table',
      primitive: 'metric',
      title: 'Users',
      table: { headers: ['Topic', 'Notes'], rows: [['Users', '10k']] },
    })
    expect(fitSlide(metricOk).overflow).toBe(false)
    const metricLong = slide({
      layout: 'table',
      primitive: 'metric',
      title: 'Users',
      table: { headers: ['Topic', 'Notes'], rows: [['Users', 'N'.repeat(40)]] },
    })
    expect(fitSlide(metricLong).overflow).toBe(true)
    expect(fitSlide(metricLong).messageKey).toBe('metric-long')
    const divider = slide({ layout: 'title', primitive: 'section-divider', title: 'D'.repeat(60) })
    expect(fitSlide(divider).overflow).toBe(true)
    expect(fitSlide(divider).messageKey).toBe('divider-long')
  })

  it('S2/S4 outline titles use the same fitter', () => {
    expect(fitSlide(slideFromOutline('Short', 'title')).overflow).toBe(false)
    expect(fitSlide(slideFromOutline('D'.repeat(60), 'section-divider')).overflow).toBe(true)
  })

  it('fitDeck counts overflows without implying export is blocked', () => {
    const deck = fitDeck([
      slide({ layout: 'title', title: 'Hi', body: 'ok' }),
      slide({ layout: 'title', title: 'T'.repeat(200), body: '' }),
    ])
    expect(deck.overflowCount).toBe(1)
    expect(deck.results).toHaveLength(2)
  })
})
