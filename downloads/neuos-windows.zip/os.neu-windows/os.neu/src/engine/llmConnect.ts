import { hostedAssistHeaders, isHostedOsNeuFace, readHostedOpenAiKey, writeHostedOpenAiKey } from './hostedLlm'

function browserHost(): string {
  return typeof location === 'undefined' ? '' : location.hostname
}

function browserSession(): Storage | null {
  return typeof sessionStorage === 'undefined' ? null : sessionStorage
}

/** Client helpers for AI connect dialog + readiness. */

export type LlmSettingsView = {
  ok: boolean
  provider?: string
  localModel?: string
  hasKey?: boolean
  keyHint?: string
  hosted?: boolean
  ready?: { ok: boolean; via?: string; models?: string[]; reason?: string }
  reason?: string
}

export async function fetchLlmSettings(): Promise<LlmSettingsView> {
  try {
    const res = await fetch('/api/llm/settings', {
      signal: AbortSignal.timeout(8_000),
      headers: hostedAssistHeaders(browserHost(), browserSession()),
    })
    const row = (await res.json()) as LlmSettingsView
    if (isHostedOsNeuFace(browserHost())) {
      const sessionKey = readHostedOpenAiKey(browserSession())
      return {
        ...row,
        ok: true,
        hasKey: Boolean(row.hasKey || sessionKey),
        keyHint: sessionKey ? 'session' : row.keyHint,
        ready:
          row.hasKey || sessionKey
            ? { ok: true, via: 'openai' }
            : row.ready || { ok: false, reason: 'hosted-no-local' },
      }
    }
    return row
  } catch {
    return { ok: false, reason: 'network' }
  }
}

export async function saveLlmSettings(body: {
  openaiKey?: string
  provider?: 'auto' | 'local' | 'openai'
  clearKey?: boolean
}) {
  if (isHostedOsNeuFace(browserHost())) {
    if (body.clearKey) writeHostedOpenAiKey(browserSession(), null)
    else if (body.openaiKey) {
      if (!writeHostedOpenAiKey(browserSession(), body.openaiKey)) {
        return { ok: false, reason: 'bad-key' }
      }
    }
  }
  const res = await fetch('/api/llm/settings', {
    method: 'POST',
    headers: hostedAssistHeaders(browserHost(), browserSession()),
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(12_000),
  })
  return (await res.json()) as { ok: boolean; hasKey?: boolean; provider?: string; reason?: string }
}

export async function pingLlm(model: string) {
  const res = await fetch('/api/llm/ping', {
    method: 'POST',
    headers: hostedAssistHeaders(browserHost(), browserSession()),
    body: JSON.stringify({ model }),
    signal: AbortSignal.timeout(90_000),
  })
  return (await res.json()) as {
    ok: boolean
    text?: string
    model?: string
    provider?: string
    reason?: string
    ms?: number
  }
}

/** Fire-and-forget: keep llama resident so the next Ask AI is faster. */
export function warmLocalLlm() {
  void fetch('/api/llm/warm', { method: 'POST' }).catch(() => undefined)
}

/**
 * AI Health Contract (WO-AI-RELIABILITY-1): before Ask AI runs, the UI must show
 * an explicit GREEN/YELLOW/RED state instead of a silent failure.
 *   GREEN  — Reliable tier available (user OpenAI key or hosted cloud model)
 *   YELLOW — Experimental tier only (local llama) — works, but first token can take 15-90s
 *   RED    — nothing usable: bridge unreachable, or no local model and no key
 */
export type AiHealthState = 'green' | 'yellow' | 'red'

export type AiHealth = {
  state: AiHealthState
  label: string
  labelKo: string
  detail: string
  detailKo: string
  /** Set when RED — the one action that unblocks Ask AI. */
  fix?: 'connect' | 'retry'
  code: string
}

export function deriveAiHealth(view: LlmSettingsView | null): AiHealth {
  if (!view || view.ok === false) {
    return {
      state: 'red',
      label: 'AI bridge unreachable',
      labelKo: 'AI 브리지에 연결할 수 없음',
      detail: 'The bridge service (port 4178) is not responding. Restart it, then retry.',
      detailKo: '브리지 서비스(4178 포트)가 응답하지 않습니다. 다시 시작한 뒤 재시도하세요.',
      fix: 'retry',
      code: 'OS-NEU-AI-000',
    }
  }
  if (view.hasKey) {
    return {
      state: 'green',
      label: 'Ready — Reliable tier',
      labelKo: '준비됨 — 신뢰 등급',
      detail: 'OpenAI key connected. Ask AI should answer quickly.',
      detailKo: 'OpenAI 키가 연결되어 있습니다. Ask AI가 빠르게 답합니다.',
      code: 'OS-NEU-AI-100',
    }
  }
  if (view.ready?.ok && view.ready.via === 'local') {
    return {
      state: 'yellow',
      label: 'Local AI only — first answer 15-90s',
      labelKo: '로컬 AI만 사용 — 첫 답변 15–90초',
      detail: 'Experimental local model (llama3.2:1b). Connect an OpenAI key for faster, Reliable-tier answers.',
      detailKo: '실험용 로컬 모델(llama3.2:1b)입니다. 더 빠른 신뢰 등급 응답을 원하면 OpenAI 키를 연결하세요.',
      fix: 'connect',
      code: 'OS-NEU-AI-200',
    }
  }
  return {
    state: 'red',
    label: 'Ask AI unavailable',
    labelKo: 'Ask AI 사용 불가',
    detail: 'No local model and no OpenAI key. Connect AI to add a key or pull the free local model.',
    detailKo: '로컬 모델도 OpenAI 키도 없습니다. AI 연결에서 키를 추가하거나 무료 로컬 모델을 받으세요.',
    fix: 'connect',
    code: 'OS-NEU-AI-001',
  }
}
