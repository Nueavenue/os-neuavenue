import { describe, expect, it } from 'vitest'
import { linuxPackHref, usbKitHref, windowsPackHref, windowsSourcePackHref } from './linuxPack'

describe('linux pack links', () => {
  it('uses the local bridge on this laptop', () => {
    expect(linuxPackHref('127.0.0.1')).toBe('/api/download/linux')
    expect(usbKitHref('localhost')).toBe('/api/download/pack')
    expect(windowsPackHref('127.0.0.1')).toBe('/api/download/windows')
  })

  it('uses the public /downloads file on os.neuavenue.com', () => {
    expect(linuxPackHref('os.neuavenue.com')).toBe('/downloads/neuos-linux.tar.gz')
    expect(usbKitHref('os.neuavenue.com')).toBe('/downloads/neuos-boot-kit.tar.gz')
    expect(windowsPackHref('os.neuavenue.com')).toBe('/downloads/os.neu-win-0.1.0-x64.zip')
    expect(windowsPackHref('os.neuavenue.com')).not.toContain('neuos-linux.tar.gz')
    expect(windowsPackHref('os.neuavenue.com')).not.toContain('neuos-windows.zip')
    expect(windowsSourcePackHref('os.neuavenue.com')).toBe('/downloads/neuos-windows.zip')
    expect(windowsSourcePackHref('os.neuavenue.com')).not.toContain('neuos-linux.tar.gz')
  })
})
