import { describe, expect, it } from 'vitest'
import {
  MAX_BULLETS,
  MAX_SLIDES,
  MAX_TABLE_COLS,
  MAX_TABLE_ROWS,
  applyAssistResult,
  bulletsFromBody,
  clampTable,
  parseAssistText,
  parseMarkdownFallback,
  parseRecipeJson,
  serializeRecipe,
  wantsFullDeckReplace,
} from './slidesRecipe'

const VALID_RECIPE = {
  version: 1,
  title: 'EXAMPLE deck',
  slides: [
    { layout: 'title', title: 'Welcome', body: 'os.neu Slides' },
    { layout: 'bullets', title: 'Why', bullets: ['Fast', 'Local-first', 'No lock-in'] },
    { layout: 'table', title: 'Numbers (EXAMPLE)', table: { headers: ['Metric', 'Value'], rows: [['Users', '10']] } },
  ],
}

describe('parseRecipeJson', () => {
  it('parses a valid version:1 recipe', () => {
    const result = parseRecipeJson(JSON.stringify(VALID_RECIPE))
    expect(result).not.toBeNull()
    expect(result?.slides).toHaveLength(3)
    expect(result?.slides[0].layout).toBe('title')
    expect(result?.slides[1].bullets).toEqual(['Fast', 'Local-first', 'No lock-in'])
    expect(result?.slides[2].table?.headers).toEqual(['Metric', 'Value'])
  })

  it('parses JSON inside a fenced ```json block', () => {
    const fenced = '```json\n' + JSON.stringify(VALID_RECIPE) + '\n```'
    const result = parseRecipeJson(fenced)
    expect(result?.slides).toHaveLength(3)
  })

  it('rejects wrong version', () => {
    expect(parseRecipeJson(JSON.stringify({ ...VALID_RECIPE, version: 2 }))).toBeNull()
  })

  it('rejects missing slides array', () => {
    expect(parseRecipeJson(JSON.stringify({ version: 1 }))).toBeNull()
  })

  it('rejects non-JSON / markdown text', () => {
    expect(parseRecipeJson('## Title\nbody text')).toBeNull()
  })

  it('rejects malformed JSON', () => {
    expect(parseRecipeJson('{ version: 1, slides: [')).toBeNull()
  })

  it('clamps slides beyond the max', () => {
    const many = { version: 1, slides: Array.from({ length: 20 }, (_, i) => ({ layout: 'bullets', title: `S${i}`, bullets: ['x'] })) }
    const result = parseRecipeJson(JSON.stringify(many))
    expect(result?.slides).toHaveLength(MAX_SLIDES)
  })

  it('clamps bullets beyond the max', () => {
    const recipe = { version: 1, slides: [{ layout: 'bullets', title: 'S', bullets: Array.from({ length: 20 }, (_, i) => `b${i}`) }] }
    const result = parseRecipeJson(JSON.stringify(recipe))
    expect(result?.slides[0].bullets).toHaveLength(MAX_BULLETS)
  })

  it('treats an unknown layout as bullets', () => {
    const recipe = { version: 1, slides: [{ layout: 'chart', title: 'S', body: 'a\nb' }] }
    const result = parseRecipeJson(JSON.stringify(recipe))
    expect(result?.slides[0].layout).toBe('bullets')
  })

  it('clamps table headers/rows beyond the max', () => {
    const headers = Array.from({ length: 9 }, (_, i) => `h${i}`)
    const rows = Array.from({ length: 12 }, (_, i) => [String(i)])
    const recipe = { version: 1, slides: [{ layout: 'table', title: 'S', table: { headers, rows } }] }
    const result = parseRecipeJson(JSON.stringify(recipe))
    expect(result?.slides[0].table?.headers).toHaveLength(MAX_TABLE_COLS)
    expect(result?.slides[0].table?.rows).toHaveLength(MAX_TABLE_ROWS)
  })
})

describe('clampTable', () => {
  it('pads short rows to the header width', () => {
    const table = clampTable({ headers: ['A', 'B', 'C'], rows: [['1']] })
    expect(table?.rows[0]).toEqual(['1', '', ''])
  })

  it('returns null when headers are missing', () => {
    expect(clampTable({ rows: [['1']] })).toBeNull()
  })
})

describe('bulletsFromBody', () => {
  it('splits lines, strips bullet markers, drops blanks, caps at 6', () => {
    const body = ['- one', '* two', '• three', '', 'four', 'five', 'six', 'seven'].join('\n')
    expect(bulletsFromBody(body)).toEqual(['one', 'two', 'three', 'four', 'five', 'six'])
  })
})

describe('parseMarkdownFallback (today\'s behavior, preserved)', () => {
  it('splits on ## headings into bullets-layout slides', () => {
    const text = '## First\nline a\nline b\n\n## Second\nline c'
    const slides = parseMarkdownFallback(text)
    expect(slides).toHaveLength(2)
    expect(slides[0]).toMatchObject({ layout: 'bullets', title: 'First' })
    expect(slides[0].bullets).toEqual(['line a', 'line b'])
    expect(slides[1].title).toBe('Second')
  })

  it('wraps plain text with no ## headings as a single slide (first line = title)', () => {
    const slides = parseMarkdownFallback('just some notes')
    expect(slides).toHaveLength(1)
    expect(slides[0].title).toBe('just some notes')
  })

  it('falls back to "New slide" only for empty/whitespace text', () => {
    const slides = parseMarkdownFallback('   \n  ')
    expect(slides).toHaveLength(1)
    expect(slides[0].title).toBe('New slide')
  })

  // WO-UI-NEU-SLIDES-ASK-PARSE-121: widen the split from `##`-only to `#`..`####`.
  it('splits on #### headings (the live-bug outline level) into more than one slide', () => {
    const text = '#### Intro\nwelcome\n\n#### Problem\n* pain one\n* pain two\n\n#### Solution\nos.neu Slides'
    const slides = parseMarkdownFallback(text)
    expect(slides.length).toBeGreaterThan(1)
    expect(slides.map((s) => s.title)).toEqual(['Intro', 'Problem', 'Solution'])
    expect(slides[1].bullets).toEqual(['pain one', 'pain two'])
  })

  it('splits on a single # heading', () => {
    const slides = parseMarkdownFallback('# Cover\nsubtitle line\n\n# Next\nmore')
    expect(slides).toHaveLength(2)
    expect(slides[0].title).toBe('Cover')
    expect(slides[1].title).toBe('Next')
  })

  it('splits on mixed heading levels (#, ##, ###, ####) in the same outline', () => {
    const text = '# One\na\n\n## Two\nb\n\n### Three\nc\n\n#### Four\nd'
    const slides = parseMarkdownFallback(text)
    expect(slides.map((s) => s.title)).toEqual(['One', 'Two', 'Three', 'Four'])
  })

  it('does not split on 5+ hashes (not a level 1-4 heading)', () => {
    const slides = parseMarkdownFallback('##### Not a slide break\nbody text')
    expect(slides).toHaveLength(1)
    expect(slides[0].title).toBe('##### Not a slide break')
  })

  it('drops headings past MAX_SLIDES', () => {
    const text = Array.from({ length: MAX_SLIDES + 1 }, (_, i) => `#### Slide ${i + 1}\npoint ${i + 1}`).join('\n\n')
    const slides = parseMarkdownFallback(text)
    expect(slides).toHaveLength(MAX_SLIDES)
    expect(slides.map((s) => s.title)).not.toContain(`Slide ${MAX_SLIDES + 1}`)
  })
})

describe('parseAssistText', () => {
  it('prefers JSON when valid', () => {
    const result = parseAssistText(JSON.stringify(VALID_RECIPE))
    expect(result.slides).toHaveLength(3)
    expect(result.title).toBe('EXAMPLE deck')
  })

  it('JSON still beats markdown even when a #### heading also appears', () => {
    const recipeWithHeadingLikeText = {
      version: 1,
      slides: [{ layout: 'bullets', title: '#### looks like a heading but is JSON data', bullets: ['a'] }],
    }
    const result = parseAssistText(JSON.stringify(recipeWithHeadingLikeText))
    expect(result.slides).toHaveLength(1)
    expect(result.slides[0].title).toBe('#### looks like a heading but is JSON data')
  })

  it('falls back to markdown when JSON is absent/invalid', () => {
    const result = parseAssistText('## Only slide\nsome body')
    expect(result.slides).toHaveLength(1)
    expect(result.slides[0].title).toBe('Only slide')
  })
})

describe('applyAssistResult (WO-UI-NEU-SLIDES-ASK-ONE-SLIDE-121)', () => {
  const pitch: ReturnType<typeof serializeRecipe>['slides'] = [
    { layout: 'title', title: 'Cover', body: 'Working title', bullets: [], table: null },
    { layout: 'bullets', title: 'Problem', body: 'Pain point one', bullets: ['Pain point one'], table: null },
    { layout: 'bullets', title: 'Solution', body: 'Core idea', bullets: ['Core idea'], table: null },
    { layout: 'table', title: 'Roadmap', body: '', bullets: [], table: { headers: ['Phase', 'Focus'], rows: [['Phase 1', 'Discovery']] } },
    { layout: 'bullets', title: 'Team', body: 'Founder', bullets: ['Founder'], table: null },
    { layout: 'bullets', title: 'Ask', body: 'What we need', bullets: ['What we need'], table: null },
  ]

  it('Cover-only ask on a 6-slide Pitch writes one slot and keeps the other five', () => {
    const fromModel = [
      { layout: 'title' as const, title: 'Cover', body: 'A short value line', bullets: [], table: null },
      { layout: 'bullets' as const, title: 'Problem', body: 'model tried to rewrite this too', bullets: ['no'], table: null },
    ]
    const next = applyAssistResult(pitch, 3, 'Put this into the Cover slide: A short value line', fromModel)
    expect(next.slides).toHaveLength(6)
    expect(next.slides[0]).toEqual(fromModel[0])
    expect(next.slides[1]).toEqual(pitch[1])
    expect(next.slides[2]).toEqual(pitch[2])
    expect(next.slides[3]).toEqual(pitch[3])
    expect(next.slides[4]).toEqual(pitch[4])
    expect(next.slides[5]).toEqual(pitch[5])
    expect(next.index).toBe(0)
  })

  it('with no named title, writes the selected slide and does not jump selection to 0', () => {
    const fromModel = [{ layout: 'bullets' as const, title: 'Team', body: 'Founder\nAdvisor', bullets: ['Founder', 'Advisor'], table: null }]
    const next = applyAssistResult(pitch, 4, 'Rewrite this slide with two short bullets', fromModel)
    expect(next.slides).toHaveLength(6)
    expect(next.slides[4]).toEqual(fromModel[0])
    expect(next.slides[0]).toEqual(pitch[0])
    expect(next.slides[3]).toEqual(pitch[3])
    expect(next.index).toBe(4)
  })

  it('still replaces the whole deck when the deck has only one slide', () => {
    const one = [{ layout: 'title' as const, title: 'Title slide', body: 'Click to add notes', bullets: [], table: null }]
    const fromModel = [
      { layout: 'title' as const, title: 'Cover', body: 'New deck', bullets: [], table: null },
      { layout: 'bullets' as const, title: 'Next', body: 'a', bullets: ['a'], table: null },
    ]
    const next = applyAssistResult(one, 0, 'Put this into the Cover slide', fromModel)
    expect(next.slides).toEqual(fromModel)
    expect(next.index).toBe(0)
  })

  it('still replaces the whole deck when the instruction asks for a new deck', () => {
    const fromModel = [
      { layout: 'title' as const, title: 'One', body: '', bullets: [], table: null },
      { layout: 'bullets' as const, title: 'Two', body: 'b', bullets: ['b'], table: null },
      { layout: 'bullets' as const, title: 'Three', body: 'c', bullets: ['c'], table: null },
    ]
    expect(wantsFullDeckReplace('Make 3 slides about making coffee at home')).toBe(true)
    expect(wantsFullDeckReplace('replace the deck')).toBe(true)
    expect(wantsFullDeckReplace('모든 슬라이드 다시')).toBe(true)
    expect(wantsFullDeckReplace('Put this into the Cover slide')).toBe(false)
    const next = applyAssistResult(pitch, 4, 'Make 3 slides about making coffee at home', fromModel)
    expect(next.slides).toEqual(fromModel)
    expect(next.index).toBe(0)
  })
})

describe('serializeRecipe', () => {
  it('re-derives bullets from body so state can never drift', () => {
    const recipe = serializeRecipe('Deck', [{ layout: 'bullets', title: 'S', body: 'a\nb\nc', bullets: [], table: null }])
    expect(recipe.version).toBe(1)
    expect(recipe.slides[0].bullets).toEqual(['a', 'b', 'c'])
  })

  it('caps slide count at export time regardless of source array length', () => {
    const slides = Array.from({ length: 20 }, (_, i) => ({ layout: 'bullets' as const, title: `S${i}`, body: '', bullets: [], table: null }))
    expect(serializeRecipe(undefined, slides).slides).toHaveLength(MAX_SLIDES)
  })
})
