import { describe, expect, it } from 'vitest'
import { bootAfterSplash, initialPhaseFromWindow, phaseFromQuery, shouldRunBootTimer } from './bootRoute'

describe('boot route', () => {
  it('sends an unplanted splash to the one-page landing', () => {
    expect(bootAfterSplash(false)).toBe('home')
  })

  it('sends a planted splash to the same one-page landing (WO-UI-NEU-ONE-PAGE-LANDING-121)', () => {
    expect(bootAfterSplash(true)).toBe('home')
  })

  it('does not re-run the splash timer after the user leaves splash', () => {
    expect(shouldRunBootTimer('splash')).toBe(true)
    expect(shouldRunBootTimer('post')).toBe(false)
    expect(shouldRunBootTimer('announce')).toBe(false)
    expect(shouldRunBootTimer('install')).toBe(false)
  })

  it('honors ?go= only for known screens', () => {
    expect(phaseFromQuery('post')).toBe('post')
    expect(phaseFromQuery('announce')).toBe('announce')
    expect(phaseFromQuery('home')).toBe('home')
    expect(phaseFromQuery('splash')).toBe('splash')
    expect(phaseFromQuery('nope')).toBeNull()
  })

  it('lands on the four-block home with no window (SSR-safe default), not splash (WO-UI-NEU-LANDING-FIRST-PAINT-121)', () => {
    expect(initialPhaseFromWindow()).toBe('home')
  })
})
