const RECENT_KEY = 'neuos.ppt.recent'
const FAV_KEY = 'neuos.ppt.favorites'

function readIds(key: string): string[] {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return []
    const parsed = JSON.parse(raw) as unknown
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string') : []
  } catch {
    return []
  }
}

function writeIds(key: string, ids: string[]) {
  localStorage.setItem(key, JSON.stringify(ids.slice(0, 20)))
}

export function pushRecentTemplate(id: string) {
  const next = [id, ...readIds(RECENT_KEY).filter((x) => x !== id)]
  writeIds(RECENT_KEY, next)
}

export function recentTemplateIds(): string[] {
  return readIds(RECENT_KEY)
}

export function toggleFavoriteTemplate(id: string): boolean {
  const cur = readIds(FAV_KEY)
  const on = cur.includes(id)
  writeIds(FAV_KEY, on ? cur.filter((x) => x !== id) : [id, ...cur])
  return !on
}

export function favoriteTemplateIds(): string[] {
  return readIds(FAV_KEY)
}

export function isFavoriteTemplate(id: string): boolean {
  return readIds(FAV_KEY).includes(id)
}
