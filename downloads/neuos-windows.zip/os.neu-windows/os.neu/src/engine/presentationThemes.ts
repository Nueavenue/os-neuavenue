/**
 * WO-UI-NEU-SLIDES-PPT-STUDIO-TEMPLATE-RUNTIME-122 — template.style → runtime theme.
 */
import type { PresentationTemplate } from './presentationTemplates'
import type { PptxThemeHints } from './pptxExport'

export type PresentationTheme = {
  background: string
  surface: string
  foreground: string
  muted: string
  accent: string
  headingFont: string
  bodyFont: string
  titleSizePt: number
  bodySizePt: number
}

const NEU_INVESTOR_DARK: PresentationTheme = {
  background: '#050B16',
  surface: '#0B1628',
  foreground: '#F8FAFC',
  muted: '#94A3B8',
  accent: '#6366F1',
  headingFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 30,
  bodySizePt: 16,
}

const TECH_ARCH: PresentationTheme = {
  background: '#020617',
  surface: '#0F172A',
  foreground: '#E0F2FE',
  muted: '#7DD3FC',
  accent: '#2563EB',
  headingFont: '"Space Grotesk", Inter, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 28,
  bodySizePt: 15,
}

const MINIMAL_CORP: PresentationTheme = {
  background: '#FFFFFF',
  surface: '#F8FAFC',
  foreground: '#0F172A',
  muted: '#64748B',
  accent: '#334155',
  headingFont: '"IBM Plex Sans", Inter, sans-serif',
  bodyFont: '"IBM Plex Sans", Inter, sans-serif',
  titleSizePt: 26,
  bodySizePt: 15,
}

const MODERN_BUSINESS: PresentationTheme = {
  background: '#F8FAFC',
  surface: '#FFFFFF',
  foreground: '#0F172A',
  muted: '#64748B',
  accent: '#475569',
  headingFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 28,
  bodySizePt: 16,
}

const RESEARCH_REPORT: PresentationTheme = {
  background: '#F1F5F9',
  surface: '#FFFFFF',
  foreground: '#0F172A',
  muted: '#64748B',
  accent: '#0D9488',
  headingFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 26,
  bodySizePt: 15,
}

const PRODUCT_LAUNCH: PresentationTheme = {
  background: '#1E1033',
  surface: '#2A1848',
  foreground: '#F5F3FF',
  muted: '#C4B5FD',
  accent: '#A78BFA',
  headingFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 28,
  bodySizePt: 16,
}

const DEFAULT_DARK: PresentationTheme = {
  background: '#0F172A',
  surface: '#1E293B',
  foreground: '#F8FAFC',
  muted: '#94A3B8',
  accent: '#8B5CF6',
  headingFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  bodyFont: 'Inter, ui-sans-serif, system-ui, sans-serif',
  titleSizePt: 28,
  bodySizePt: 16,
}

export function themeForTemplate(template: PresentationTemplate): PresentationTheme {
  switch (template.id) {
    case 'neu-investor-dark':
      return NEU_INVESTOR_DARK
    case 'tech-architecture':
      return TECH_ARCH
    case 'minimal-corporate':
      return MINIMAL_CORP
    case 'modern-business':
      return MODERN_BUSINESS
    case 'research-report':
      return RESEARCH_REPORT
    case 'product-launch':
      return PRODUCT_LAUNCH
    default:
      if (template.style.theme.includes('light')) return MODERN_BUSINESS
      return DEFAULT_DARK
  }
}

export function themeToCssVars(theme: PresentationTheme): Record<string, string> {
  return {
    '--ppt-bg': theme.background,
    '--ppt-surface': theme.surface,
    '--ppt-fg': theme.foreground,
    '--ppt-muted': theme.muted,
    '--ppt-accent': theme.accent,
    '--ppt-heading-font': theme.headingFont,
    '--ppt-body-font': theme.bodyFont,
  }
}

function hexNoHash(hex: string): string {
  return hex.replace('#', '').toUpperCase()
}

export function themeToPptxHints(theme: PresentationTheme): PptxThemeHints {
  return {
    titleColor: hexNoHash(theme.accent),
    bodyColor: hexNoHash(theme.foreground),
    subtitleColor: hexNoHash(theme.muted),
    tableHeaderFill: hexNoHash(theme.surface),
    titleSize: theme.titleSizePt * 100,
    bodySize: theme.bodySizePt * 100,
    headingTypeface: theme.headingFont.split(',')[0].replace(/"/g, '').trim() || 'Inter',
    bodyTypeface: theme.bodyFont.split(',')[0].replace(/"/g, '').trim() || 'Inter',
  }
}
