export const HOME_HOST = 'os.neu.local'
export const WEB_HOME = 'https://www.neuavenue.com'
export const VITALITY_URL = 'https://www.neuavenue.com/vitality'
/**
 * Door A shareholder/Command View screen (WO-UI-NEU-COMMAND-VIEW-ICON-121 /
 * UI-B27). Screen of record lives on Door A only — this opens it via the
 * UI-B17 front-window path (openDaf), never an in-place navigate/iframe,
 * never a copy of ShareholderDashboard inside neuOS.
 */
export const COMMAND_VIEW_URL = 'https://neuavenue.com/?view=shareholder'
export const GOOGLE_SIGNIN = 'https://accounts.google.com/ServiceLogin'

/** Omnibox search — swap this helper later for a company search endpoint. */
export function searchUrl(query: string): string {
  return `https://www.google.com/search?q=${encodeURIComponent(query)}`
}

const HOME_ALIASES = ['os.neu.local', 'neuos.local']

export type Address =
  | { kind: 'home' }
  | { kind: 'url'; href: string }
  | { kind: 'invalid'; reason: string }

const BLOCKED = /^(javascript|data|file|vbscript|blob):/i
const DOMAIN = /^(localhost(:\d+)?|(\d{1,3}\.){3}\d{1,3}(:\d+)?|[a-z0-9-]+(\.[a-z0-9-]+)+)(:\d+)?([/:?#].*)?$/i
const LOCAL = /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])/i

export function normalizeAddress(raw: string): Address {
  const trimmed = raw.trim()
  if (!trimmed) return { kind: 'home' }
  if (HOME_ALIASES.some((host) => trimmed.toLowerCase().includes(host))) return { kind: 'home' }
  if (BLOCKED.test(trimmed)) {
    return { kind: 'invalid', reason: 'This kind of address cannot be opened.' }
  }

  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const url = new URL(trimmed)
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        return { kind: 'invalid', reason: 'Only http or https can be opened.' }
      }
      return { kind: 'url', href: url.toString() }
    } catch {
      return { kind: 'invalid', reason: 'Could not read that address.' }
    }
  }

  if (DOMAIN.test(trimmed)) {
    const protocol = LOCAL.test(trimmed) ? 'http' : 'https'
    return { kind: 'url', href: new URL(`${protocol}://${trimmed}`).toString() }
  }

  return {
    kind: 'url',
    href: searchUrl(trimmed),
  }
}

export function proxySrc(href: string): string {
  return `/api/browse?url=${encodeURIComponent(href)}`
}

export function isAuthHost(href: string): boolean {
  try {
    const url = new URL(href)
    const host = url.hostname
    if (host === 'accounts.google.com' || host === 'accounts.youtube.com') return true
    if (host === 'login.microsoftonline.com' || host === 'login.live.com') return true
    if (host === 'appleid.apple.com') return true
    if (host === 'github.com' && url.pathname.startsWith('/login')) return true
    return false
  } catch {
    return false
  }
}

export function googleLoginInIframe(href: string): boolean {
  return isAuthHost(href)
}

export function isLoopbackHost(href: string): boolean {
  try {
    const host = new URL(href).hostname
    return host === 'localhost' || host === '127.0.0.1' || host === '::1'
  } catch {
    return false
  }
}

/** Ollama listen port — local API, not a surfing website. */
export function isOllamaApiUrl(href: string): boolean {
  try {
    const url = new URL(href)
    return isLoopbackHost(href) && url.port === '11434'
  } catch {
    return false
  }
}
