/** Hosts that send X-Frame-Options DENY/SAMEORIGIN or CSP frame-ancestors. */
const FRAME_BLOCKED = [
  'github.com',
  'gist.github.com',
  'google.com',
  'developers.google.com',
  'accounts.google.com',
  'googleusercontent.com',
  'youtube.com',
  'youtu.be',
  'm.youtube.com',
  'dify.ai',
  'cloud.dify.ai',
  'facebook.com',
  'instagram.com',
  'x.com',
  'twitter.com',
  'linkedin.com',
  'apple.com',
  'microsoft.com',
]

export type FramePreview =
  | { kind: 'iframe'; src: string; host: string }
  | { kind: 'card'; host: string }

function hostnameOf(raw: string): string {
  try {
    return new URL(raw).hostname
  } catch {
    return raw
  }
}

function bareHost(host: string): string {
  return host.replace(/^www\./, '').toLowerCase()
}

export function hostBlocksFrames(host: string): boolean {
  const h = bareHost(host)
  return FRAME_BLOCKED.some((blocked) => h === blocked || h.endsWith(`.${blocked}`))
}

/** Official YouTube embed only — not a frame-ancestors bypass. */
export function youtubeEmbedSrc(url: string): string | null {
  try {
    const parsed = new URL(url)
    const host = bareHost(parsed.hostname)
    if (host === 'youtu.be') {
      const id = parsed.pathname.split('/').filter(Boolean)[0]
      return id ? `https://www.youtube-nocookie.com/embed/${id}` : null
    }
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtube-nocookie.com') {
      const id = parsed.searchParams.get('v')
      if (id) return `https://www.youtube-nocookie.com/embed/${id}`
      const parts = parsed.pathname.split('/').filter(Boolean)
      if ((parts[0] === 'embed' || parts[0] === 'shorts') && parts[1]) {
        return `https://www.youtube-nocookie.com/embed/${parts[1]}`
      }
    }
  } catch {
    return null
  }
  return null
}

export function framePreview(url: string): FramePreview {
  const host = hostnameOf(url)
  const youtube = youtubeEmbedSrc(url)
  if (youtube) return { kind: 'iframe', src: youtube, host }
  if (hostBlocksFrames(host)) return { kind: 'card', host }
  return { kind: 'iframe', src: url, host }
}

export function faviconForHost(host: string): string {
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(bareHost(host) || host)}&sz=64`
}
