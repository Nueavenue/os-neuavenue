/**
 * WO-UI-NEU-PPT-MOCK-S2-PREVIEW-CHROME-125B — named-template design language
 * and numbered structure labels. Pack ids stay in data; they are not UX copy.
 */
import { NATIVE_FIVE_IDS } from './layoutContract'
import type { PresentationTemplate, TemplatePreviewTheme } from './presentationTemplates'

export type Bilingual = { en: string; ko: string }

export type DesignLanguage = {
  typography: Bilingual
  layout: Bilingual
  visualStyle: Bilingual
}

const KEY_LABELS: Record<string, Bilingual> = {
  cover: { en: 'Cover', ko: '표지' },
  problem: { en: 'Problem', ko: '문제' },
  solution: { en: 'Solution', ko: '해결' },
  market: { en: 'Market Opportunity', ko: '시장' },
  product: { en: 'Product', ko: '제품' },
  technology: { en: 'Technology', ko: '기술' },
  'business-model': { en: 'Business Model', ko: '비즈니스 모델' },
  traction: { en: 'Traction', ko: '트랙션' },
  roadmap: { en: 'Roadmap', ko: '로드맵' },
  team: { en: 'Team', ko: '팀' },
  funding: { en: 'Funding', ko: '펀딩' },
  closing: { en: 'Closing', ko: '마무리' },
  agenda: { en: 'Agenda', ko: '아젠다' },
  overview: { en: 'Overview', ko: '개요' },
  highlights: { en: 'Highlights', ko: '하이라이트' },
  'next-steps': { en: 'Next Steps', ko: '다음 단계' },
  context: { en: 'Context', ko: '맥락' },
  architecture: { en: 'Architecture', ko: '아키텍처' },
  components: { en: 'Components', ko: '구성' },
  'data-flow': { en: 'Data Flow', ko: '데이터 흐름' },
  security: { en: 'Security', ko: '보안' },
  scalability: { en: 'Scalability', ko: '확장' },
  integration: { en: 'Integration', ko: '연동' },
  summary: { en: 'Summary', ko: '요약' },
  vision: { en: 'Vision', ko: '비전' },
  progress: { en: 'Progress', ko: '진행' },
  metrics: { en: 'Metrics', ko: '지표' },
  risks: { en: 'Risks', ko: '리스크' },
  next: { en: 'Next', ko: '다음' },
  features: { en: 'Features', ko: '기능' },
  comparison: { en: 'Comparison', ko: '비교' },
  audience: { en: 'Audience', ko: '청중' },
  steps: { en: 'Steps', ko: '단계' },
  'feature-comparison': { en: 'Feature Comparison', ko: '기능 비교' },
  benefits: { en: 'Benefits', ko: '이점' },
  timeline: { en: 'Timeline', ko: '일정' },
  ask: { en: 'Ask', ko: '요청' },
  method: { en: 'Method', ko: '방법' },
  findings: { en: 'Findings', ko: '발견' },
  recommendations: { en: 'Recommendations', ko: '권고' },
  message: { en: 'Message', ko: '메시지' },
  channels: { en: 'Channels', ko: '채널' },
  kpis: { en: 'KPIs', ko: 'KPI' },
  objectives: { en: 'Objectives', ko: '목표' },
  demo: { en: 'Demo', ko: '데모' },
  quiz: { en: 'Quiz', ko: '퀴즈' },
  resources: { en: 'Resources', ko: '자료' },
  model: { en: 'Model', ko: '모델' },
  plan: { en: 'Plan', ko: '계획' },
  milestones: { en: 'Milestones', ko: '마일스톤' },
}

const DESIGN_BY_ID: Record<string, DesignLanguage> = {
  'neu-investor-dark': {
    typography: { en: 'Inter / Grotesk', ko: '인터 · 그로테스크' },
    layout: { en: 'Writer / Reports', ko: '라이터 · 보고' },
    visualStyle: { en: 'Dark / Gradient / Clean', ko: '다크 · 그라데이션 · 클린' },
  },
  'minimal-corporate': {
    typography: { en: 'IBM Plex Sans', ko: 'IBM Plex Sans' },
    layout: { en: 'Board / Memo', ko: '보드 · 메모' },
    visualStyle: { en: 'Light / Editorial / Quiet', ko: '라이트 · 에디토리얼 · 정돈' },
  },
  'tech-architecture': {
    typography: { en: 'Space Grotesk', ko: 'Space Grotesk' },
    layout: { en: 'System / Split', ko: '시스템 · 분할' },
    visualStyle: { en: 'Dark / Grid / Electric', ko: '다크 · 그리드 · 일렉트릭' },
  },
  'research-report': {
    typography: { en: 'Inter / Paper', ko: '인터 · 페이퍼' },
    layout: { en: 'Findings / Table', ko: '발견 · 표' },
    visualStyle: { en: 'Mist / Teal / Analytical', ko: '미스트 · 틸 · 분석' },
  },
  'product-launch': {
    typography: { en: 'Inter / Display', ko: '인터 · 디스플레이' },
    layout: { en: 'Launch / Timeline', ko: '런치 · 타임라인' },
    visualStyle: { en: 'Violet / Glow / Bold', ko: '바이올렛 · 글로우 · 볼드' },
  },
  'modern-business': {
    typography: { en: 'Inter / Clean', ko: '인터 · 클린' },
    layout: { en: 'Narrative / Agenda', ko: '내러티브 · 아젠다' },
    visualStyle: { en: 'Light / Slate / Calm', ko: '라이트 · 슬레이트 · 차분' },
  },
  'dark-tech': {
    typography: { en: 'Inter / Modern', ko: '인터 · 모던' },
    layout: { en: 'Product / Feature', ko: '제품 · 기능' },
    visualStyle: { en: 'Dark / Purple / Bold', ko: '다크 · 퍼플 · 볼드' },
  },
}

function humanize(key: string): string {
  return key
    .split('-')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : ''))
    .join(' ')
}

export function structureLabel(key: string, index: number, ko: boolean): string {
  const n = String(index + 1).padStart(2, '0')
  const pair = KEY_LABELS[key]
  const name = pair ? (ko ? pair.ko : pair.en) : humanize(key)
  return `${n} ${name}`
}

export function structureBlurb(key: string, ko: boolean): string {
  const pair = KEY_LABELS[key]
  if (!pair) return ko ? '개요' : 'Outline'
  return ko ? `${pair.ko} 슬라이드 개요` : `${pair.en} slide outline`
}

export function designLanguageFor(template: PresentationTemplate): DesignLanguage {
  return (
    DESIGN_BY_ID[template.id] ?? {
      typography: { en: template.style.typography, ko: template.style.typography },
      layout: { en: template.style.density, ko: template.style.density },
      visualStyle: { en: template.style.visualTone, ko: template.style.visualTone },
    }
  )
}

export function cardArtModifier(theme: TemplatePreviewTheme): string {
  return `ppt-card-art--${theme}`
}

export function nativeFiveHaveDesignLanguage(): boolean {
  return NATIVE_FIVE_IDS.every((id) => Boolean(DESIGN_BY_ID[id]))
}

/** 125E — Pitch/Report/Product is not the primary studio metaphor. */
export const PACK_PICKER_PRIMARY = false
