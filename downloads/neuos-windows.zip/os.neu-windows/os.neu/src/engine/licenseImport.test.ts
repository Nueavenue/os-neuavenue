import { describe, expect, it } from 'vitest'
import { PRESENTATION_TEMPLATES, getTemplateById } from './presentationTemplates'
import {
  APPROVED_ATTRIBUTION,
  APPROVED_LICENSE,
  APPROVED_LICENSE_URL,
  APPROVED_SOURCE,
  LICENSED_PILOTS,
  PILOT_MAX,
  getLicensedPilot,
  importLicensedPilot,
  listLicensedPilots,
  normalizeImportedSchema,
  wouldExceedPilotCap,
} from './licenseImport'

describe('122E CC BY license pilot', () => {
  it('caps pilots at 3 and keeps them out of the gallery array', () => {
    expect(PILOT_MAX).toBe(3)
    expect(LICENSED_PILOTS).toHaveLength(3)
    expect(wouldExceedPilotCap(1)).toBe(true)
    const ids = LICENSED_PILOTS.map((t) => t.id)
    expect(PRESENTATION_TEMPLATES.some((t) => ids.includes(t.id))).toBe(false)
  })

  it('stores source / license / licenseUrl / attribution fields', () => {
    for (const t of listLicensedPilots()) {
      expect(t.license?.source).toBe(APPROVED_SOURCE)
      expect(t.license?.license).toBe(APPROVED_LICENSE)
      expect(t.license?.licenseUrl).toBe(APPROVED_LICENSE_URL)
      expect(t.license?.attributionRequired).toBe(true)
      expect(t.license?.attributionText).toBe(APPROVED_ATTRIBUTION)
      expect(t.description).toMatch(/No bundled \.pptx/)
    }
  })

  it('resolves pilots via getTemplateById without gallery membership', () => {
    expect(getLicensedPilot('ccby-pilot-business')?.id).toBe('ccby-pilot-business')
    expect(getTemplateById('ccby-pilot-education')?.license?.license).toBe(APPROVED_LICENSE)
    expect(getTemplateById('neu-investor-dark')?.license).toBeUndefined()
  })

  it('rejects Slidesgo / marketplace and non-CC-BY licenses', () => {
    expect(importLicensedPilot({ source: 'https://slidesgo.com/theme', license: APPROVED_LICENSE }).ok).toBe(false)
    expect(importLicensedPilot({ source: APPROVED_SOURCE, license: 'All rights reserved' }).ok).toBe(false)
    expect(importLicensedPilot({ source: 'envato-elements', license: APPROVED_LICENSE }).reason).toBe('source-forbidden')
  })

  it('accepts approved S2 source and refuses a fourth schema id', () => {
    const ok = importLicensedPilot({ source: APPROVED_SOURCE, license: APPROVED_LICENSE })
    expect(ok.ok).toBe(true)
    const fourth = normalizeImportedSchema({
      id: 'ccby-pilot-fourth',
      name: 'Fourth',
      structure: ['cover'],
      pack: 'pitch',
      category: 'Business',
      license: {
        source: APPROVED_SOURCE,
        license: APPROVED_LICENSE,
        licenseUrl: APPROVED_LICENSE_URL,
        attributionRequired: true,
        attributionText: APPROVED_ATTRIBUTION,
      },
    })
    expect('error' in fourth && fourth.error).toBe('over-cap')
  })
})
