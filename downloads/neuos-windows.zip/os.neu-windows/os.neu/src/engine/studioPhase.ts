/**
 * WO-UI-NEU-SLIDES-PPT-STUDIO-P1-STORYBOARD-123 — S3/S4 phase routing.
 * Q1 KEEP-EDITOR-DIRECT: gallery card Use still lands on editor.
 */
export type StudioPhase = 'gallery' | 'preview' | 'prompt' | 'storyboard' | 'editor' | 'export'

export function phaseAfterGalleryCardUse(): StudioPhase {
  return 'editor'
}

export function phaseAfterPreviewPrompt(): StudioPhase {
  return 'prompt'
}

export function phaseAfterPromptContinue(): StudioPhase {
  return 'storyboard'
}

export function phaseAfterStoryboardConfirm(): StudioPhase {
  return 'editor'
}

export function phaseAfterEditorExport(): StudioPhase {
  return 'export'
}

export function phaseAfterExportBack(): StudioPhase {
  return 'editor'
}
