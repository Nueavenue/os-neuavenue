/** Deep-link for PPT Studio without React Router (hash + query). */

const HASH_PREFIX = '#/ppt/templates/'

export function templateIdFromLocation(): string | null {
  if (typeof window === 'undefined') return null
  const hash = window.location.hash || ''
  if (hash.startsWith(HASH_PREFIX)) {
    const id = decodeURIComponent(hash.slice(HASH_PREFIX.length).split(/[?#]/)[0] || '')
    return id || null
  }
  const q = new URLSearchParams(window.location.search).get('pptTemplate')
  return q?.trim() || null
}

export function setTemplateLocation(id: string | null, mode: 'gallery' | 'preview' | 'editor'): void {
  if (typeof window === 'undefined') return
  const url = new URL(window.location.href)
  if (id && mode !== 'gallery') {
    url.searchParams.set('pptTemplate', id)
    url.hash = `${HASH_PREFIX}${encodeURIComponent(id)}`
  } else {
    url.searchParams.delete('pptTemplate')
    if (url.hash.startsWith(HASH_PREFIX)) url.hash = ''
  }
  window.history.replaceState({}, '', url.toString())
}
