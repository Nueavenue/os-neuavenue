import { describe, expect, it } from 'vitest'
import { PRESENTATION_TEMPLATES, filterTemplates, getTemplateById } from './presentationTemplates'

describe('presentationTemplates', () => {
  it('includes neu-investor-dark with structure contract', () => {
    const t = getTemplateById('neu-investor-dark')
    expect(t?.name).toBe('NEU Investor Deck')
    expect(t?.structure.length).toBeGreaterThan(6)
    expect(t?.aspectRatio).toBe('16:9')
  })

  it('filterTemplates matches investor category', () => {
    const investor = filterTemplates(PRESENTATION_TEMPLATES, 'investor', '')
    expect(investor.some((t) => t.id === 'neu-investor-dark')).toBe(true)
  })

  it('filterTemplates search narrows by name', () => {
    const hits = filterTemplates(PRESENTATION_TEMPLATES, 'all', 'architecture')
    expect(hits.some((t) => t.id === 'tech-architecture')).toBe(true)
  })
})
