/**
 * WO-UI-NEU-SLIDES-OUTLINE-PICKER-121 (OFFICE-S2a) — three static, generic
 * outline packs (Pitch, Report, Product) the Slides screen can drop in to
 * replace the current in-memory deck. Placeholders only: no NeuAvenue
 * revenue/ARR/억/$ figures anywhere in these strings.
 *
 * WO-UI-NEU-SLIDES-PPT-STUDIO-HOME-121 (OFFICE-S2d) — `GALLERY_CARDS` are
 * visual names only; every card still loads pitch | report | product.
 */
import { bodyFromBullets, type RecipeSlide } from './slidesRecipe'

export type OutlinePackId = 'pitch' | 'report' | 'product'

function titleSlide(title: string, subtitle: string): RecipeSlide {
  return { layout: 'title', title, body: subtitle, bullets: [], table: null }
}

function bulletsSlide(title: string, bullets: string[]): RecipeSlide {
  return { layout: 'bullets', title, body: bodyFromBullets(bullets), bullets, table: null }
}

function tableSlide(title: string, headers: string[], rows: string[][]): RecipeSlide {
  return { layout: 'table', title, body: '', bullets: [], table: { headers, rows } }
}

const PITCH: RecipeSlide[] = [
  titleSlide('Cover', 'Working title'),
  bulletsSlide('Problem', ['Pain point one', 'Pain point two', 'Why now']),
  bulletsSlide('Solution', ['Core idea', 'How it works', 'What makes it different']),
  tableSlide(
    'Roadmap',
    ['Phase', 'Focus'],
    [
      ['Phase 1', 'Discovery'],
      ['Phase 2', 'Build'],
      ['Phase 3', 'Launch'],
    ],
  ),
  bulletsSlide('Team', ['Founder', 'Advisor', 'Open role']),
  bulletsSlide('Ask', ['What we need', 'Timeline', 'Next steps']),
]

const REPORT: RecipeSlide[] = [
  titleSlide('Cover', 'Status report'),
  bulletsSlide('Summary', ['Highlight one', 'Highlight two', 'Highlight three']),
  bulletsSlide('Progress', ['Completed item', 'In progress item', 'Blocked item']),
  tableSlide(
    'Metrics',
    ['Metric', 'Status'],
    [
      ['Metric A', 'On track'],
      ['Metric B', 'At risk'],
    ],
  ),
  bulletsSlide('Risks', ['Risk one', 'Mitigation']),
  bulletsSlide('Next steps', ['Action one', 'Action two', 'Owner']),
]

const PRODUCT: RecipeSlide[] = [
  titleSlide('Cover', 'Product overview'),
  bulletsSlide('Problem', ['Pain point', 'Who has it', 'Why it matters']),
  bulletsSlide('Steps', ['Step one', 'Step two', 'Step three']),
  tableSlide(
    'Feature comparison',
    ['Feature', 'Status'],
    [
      ['Feature A', 'Shipped'],
      ['Feature B', 'Planned'],
    ],
  ),
  bulletsSlide('Benefits', ['Benefit one', 'Benefit two']),
  bulletsSlide('Next', ['Roadmap item', 'Feedback loop']),
]

export type GalleryGroup = 'featured' | 'popular'

export type GalleryCard = {
  id: string
  pack: OutlinePackId
  group: GalleryGroup
  tags: string[]
  en: string
  ko: string
  blurbEn: string
  blurbKo: string
  tone: 'night' | 'paper' | 'grid' | 'mist' | 'violet'
}

/** Visual names only. Every card loads one of the three generic packs. */
export const GALLERY_CARDS: GalleryCard[] = [
  { id: 'pitch-deck', pack: 'pitch', group: 'featured', tags: ['business'], en: 'Pitch Deck', ko: '피치 덱', blurbEn: 'Six slides · cover, problem, roadmap', blurbKo: '6장 · 표지, 문제, 로드맵', tone: 'night' },
  { id: 'modern-business', pack: 'pitch', group: 'featured', tags: ['business'], en: 'Modern Business', ko: '모던 비즈니스', blurbEn: 'Clean cover and a short ask', blurbKo: '단정한 표지와 짧은 요청', tone: 'paper' },
  { id: 'tech-architecture', pack: 'product', group: 'featured', tags: ['tech', 'product'], en: 'Tech Architecture', ko: '기술 구조', blurbEn: 'Problem, steps, feature table', blurbKo: '문제, 단계, 기능 표', tone: 'grid' },
  { id: 'minimal-corporate', pack: 'report', group: 'featured', tags: ['business', 'report'], en: 'Minimal Corporate', ko: '미니멀 회사', blurbEn: 'Status, progress, risks', blurbKo: '현황, 진행, 리스크', tone: 'mist' },
  { id: 'dark-tech', pack: 'product', group: 'featured', tags: ['tech', 'product'], en: 'Dark Tech', ko: '다크 테크', blurbEn: 'Product overview in six slides', blurbKo: '6장 제품 개요', tone: 'violet' },
  { id: 'popular-pitch', pack: 'pitch', group: 'popular', tags: ['business'], en: 'Pitch Deck', ko: '피치 덱', blurbEn: 'Same pitch outline', blurbKo: '같은 피치 개요', tone: 'night' },
  { id: 'business-plan', pack: 'pitch', group: 'popular', tags: ['business'], en: 'Business Plan', ko: '사업 개요', blurbEn: 'Cover through next steps', blurbKo: '표지부터 다음 단계', tone: 'paper' },
  { id: 'research-report', pack: 'report', group: 'popular', tags: ['report'], en: 'Research Report', ko: '조사 보고', blurbEn: 'Summary and a status table', blurbKo: '요약과 상태 표', tone: 'mist' },
  { id: 'marketing-plan', pack: 'pitch', group: 'popular', tags: ['business'], en: 'Marketing Plan', ko: '마케팅 개요', blurbEn: 'Problem, solution, roadmap', blurbKo: '문제, 해법, 로드맵', tone: 'paper' },
  { id: 'training', pack: 'product', group: 'popular', tags: ['education', 'product'], en: 'Training', ko: '교육', blurbEn: 'Steps and a feature table', blurbKo: '단계와 기능 표', tone: 'grid' },
]

export const GALLERY_TAGS: { id: string; en: string; ko: string }[] = [
  { id: 'all', en: 'All', ko: '전체' },
  { id: 'business', en: 'Business', ko: '비즈니스' },
  { id: 'product', en: 'Product', ko: '제품' },
  { id: 'tech', en: 'Tech', ko: '기술' },
  { id: 'report', en: 'Report', ko: '보고' },
  { id: 'education', en: 'Education', ko: '교육' },
]

export const OUTLINE_PACKS: Record<OutlinePackId, { en: string; ko: string; slides: RecipeSlide[] }> = {
  pitch: { en: 'Pitch', ko: '피치', slides: PITCH },
  report: { en: 'Report', ko: '보고서', slides: REPORT },
  product: { en: 'Product', ko: '제품', slides: PRODUCT },
}

/** Deep clone so editing a picked pack never mutates the shared static source. */
export function getOutlinePack(id: OutlinePackId): RecipeSlide[] {
  return OUTLINE_PACKS[id].slides.map((slide) => ({
    ...slide,
    bullets: [...slide.bullets],
    table: slide.table ? { headers: [...slide.table.headers], rows: slide.table.rows.map((row) => [...row]) } : null,
  }))
}
