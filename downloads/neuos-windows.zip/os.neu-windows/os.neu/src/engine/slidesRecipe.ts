/**
 * WO-UI-NEU-SLIDES-PPTX-121 (OFFICE-S1) — `version: 1` Slides recipe:
 * parse, validate/clamp, and the today's `## title` markdown fallback.
 * Schema locked by NOTE-CONTROL-SLIDES-PPTX-SCHEMA-2026-09-22.md.
 */

export type SlideLayout = 'title' | 'bullets' | 'table'

export type SlideTable = { headers: string[]; rows: string[][] }

export type RecipeSlide = {
  layout: SlideLayout
  title: string
  body: string
  bullets: string[]
  table: SlideTable | null
  /** 122C — semantic layout for PPTX (two-column / metric / section-divider). */
  primitive?: string
}

export type SlidesRecipe = {
  version: 1
  title?: string
  slides: RecipeSlide[]
}

export const MAX_SLIDES = 20

export function clampSlideCount(n: number): number {
  if (!Number.isFinite(n)) return 1
  return Math.max(1, Math.min(MAX_SLIDES, Math.round(n)))
}
export const MAX_BULLETS = 6
export const MAX_TABLE_COLS = 5
export const MAX_TABLE_ROWS = 8

function str(v: unknown): string {
  return typeof v === 'string' ? v : v == null ? '' : String(v)
}

function normalizeLayout(raw: unknown): SlideLayout {
  return raw === 'title' || raw === 'bullets' || raw === 'table' ? raw : 'bullets'
}

/** One bullet per non-empty line; strips a leading "- " / "* " / "• " marker. */
export function bulletsFromBody(body: string): string[] {
  return String(body || '')
    .split(/\r?\n/)
    .map((line) => line.replace(/^\s*[-*•]\s*/, '').trim())
    .filter(Boolean)
    .slice(0, MAX_BULLETS)
}

export function bodyFromBullets(bullets: string[]): string {
  return (bullets || []).join('\n')
}

export function clampTable(raw: unknown): SlideTable | null {
  if (!raw || typeof raw !== 'object') return null
  const obj = raw as { headers?: unknown; rows?: unknown }
  const headers = (Array.isArray(obj.headers) ? obj.headers : []).map(str).slice(0, MAX_TABLE_COLS)
  if (!headers.length) return null
  const rows = (Array.isArray(obj.rows) ? obj.rows : [])
    .slice(0, MAX_TABLE_ROWS)
    .map((row) => {
      const cells = (Array.isArray(row) ? row : []).map(str)
      const padded = Array.from({ length: headers.length }, (_, i) => cells[i] ?? '')
      return padded
    })
  return { headers, rows }
}

/**
 * `body` (one line per bullet) is the single source of truth for
 * `bullets`-layout slides — the SlidesApp textarea edits `body` only, and
 * `bullets` is always re-derived from it here so the two can never drift.
 * A JSON recipe that supplies `bullets` but no `body` gets `body` filled in
 * from those bullets on the way in, once.
 */
function clampSlide(raw: unknown): RecipeSlide {
  const obj = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const layout = normalizeLayout(obj.layout)
  const title = str(obj.title).slice(0, 120)
  let body = str(obj.body).slice(0, 2000)

  const primitive = typeof obj.primitive === 'string' ? obj.primitive.slice(0, 40) : undefined
  if (layout === 'bullets') {
    if (!body.trim() && Array.isArray(obj.bullets)) {
      body = bodyFromBullets(obj.bullets.map(str).slice(0, MAX_BULLETS))
    }
    return { layout, title, body, bullets: bulletsFromBody(body), table: null, primitive }
  }
  if (layout === 'table') {
    return { layout, title, body, bullets: [], table: clampTable(obj.table), primitive }
  }
  return { layout, title, body, bullets: [], table: null, primitive }
}

/** Extracts a fenced ```json ... ``` block if present, else the raw text. */
function extractJsonCandidate(raw: string): string {
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fence) return fence[1].trim()
  return raw.trim()
}

/** Returns a clamped `RecipeSlide[]` if `raw` is a valid version:1 JSON recipe, else `null`. */
export function parseRecipeJson(raw: string): { title?: string; slides: RecipeSlide[] } | null {
  const candidate = extractJsonCandidate(raw)
  if (!candidate.startsWith('{')) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(candidate)
  } catch {
    return null
  }
  if (!parsed || typeof parsed !== 'object') return null
  const obj = parsed as Record<string, unknown>
  if (obj.version !== 1) return null
  if (!Array.isArray(obj.slides)) return null
  const slides = obj.slides.slice(0, MAX_SLIDES).map(clampSlide)
  if (!slides.length) return null
  return { title: obj.title != null ? str(obj.title).slice(0, 120) : undefined, slides }
}

/**
 * WO-UI-NEU-SLIDES-ASK-PARSE-121 (OFFICE-S1d) — a slide starts at any line
 * that is `#` / `##` / `###` / `####` plus whitespace (widened from `##`
 * only). The heading text with the hashes stripped becomes the title;
 * following lines stay the body, and `*` / `-` bullets still flow through
 * `bulletsFromBody` unchanged. `#####`+ does not match (5 hashes can never
 * satisfy `#{1,4}` immediately followed by whitespace) and stays body text.
 */
export function parseMarkdownFallback(text: string): RecipeSlide[] {
  const chunks = text
    .split(/^#{1,4}\s+/m)
    .map((part) => part.trim())
    .filter(Boolean)
  if (!chunks.length) {
    return [{ layout: 'bullets', title: 'New slide', body: text, bullets: bulletsFromBody(text), table: null }]
  }
  return chunks.slice(0, MAX_SLIDES).map((chunk) => {
    const [titleLine, ...rest] = chunk.split('\n')
    const body = rest.join('\n').trim()
    return { layout: 'bullets' as const, title: titleLine.trim(), body, bullets: bulletsFromBody(body), table: null }
  })
}

/** JSON first (fenced or raw); else today's markdown fallback. Never throws. */
export function parseAssistText(raw: string): { title?: string; slides: RecipeSlide[] } {
  const json = parseRecipeJson(raw)
  if (json) return json
  return { slides: parseMarkdownFallback(raw) }
}

export function defaultSlide(index: number): RecipeSlide {
  return { layout: 'bullets', title: `Slide ${index + 1}`, body: '', bullets: [], table: null }
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/**
 * WO-UI-NEU-SLIDES-ASK-ONE-SLIDE-121 (OFFICE-S2c) — an instruction that
 * explicitly asks for a brand-new deck ("all slides", "whole deck",
 * "replace the deck", a slide count like "3 slides", or the Korean 전체 /
 * 모든 슬라이드) still replaces the whole list. Anything else, on a
 * multi-slide deck, edits one slide only (see `applyAssistResult`).
 */
const FULL_DECK_REQUEST_RE = /\b(all slides|whole deck|replace the deck)\b|\b\d+[\s-]*slides?\b|전체|모든\s*슬라이드/i

export function wantsFullDeckReplace(instruction: string): boolean {
  return FULL_DECK_REQUEST_RE.test(instruction || '')
}

/**
 * Which slide an Ask AI instruction targets on a multi-slide deck: the
 * first existing slide whose (non-empty) title is named, word-bounded and
 * case-insensitive, in the instruction text — else the currently selected
 * index (clamped to the deck).
 */
export function findTargetSlideIndex(instruction: string, slides: RecipeSlide[], selectedIndex: number): number {
  const text = instruction || ''
  for (let i = 0; i < slides.length; i++) {
    const title = (slides[i]?.title || '').trim()
    if (!title) continue
    const re = new RegExp(`\\b${escapeRegExp(title)}\\b`, 'i')
    if (re.test(text)) return i
  }
  return Math.min(Math.max(selectedIndex, 0), Math.max(slides.length - 1, 0))
}

/**
 * Which slide from the model's result to drop into the target slot: the
 * result slide whose title matches the slot being replaced (case-
 * insensitive, exact), else the model's first slide — even if the model
 * (harmlessly) echoed back a whole deck instead of one slide.
 */
export function pickResultSlide(resultSlides: RecipeSlide[], targetTitle: string): RecipeSlide {
  const title = (targetTitle || '').trim().toLowerCase()
  const match = title ? resultSlides.find((slide) => (slide.title || '').trim().toLowerCase() === title) : undefined
  return match || resultSlides[0]
}

/**
 * Merges an Ask AI result into the current deck for `SlidesApp`'s
 * `onAssist`. Live bug (Leader, 2026-09-23): a 6-slide Pitch outline, asked
 * to put text "into the Cover slide", had every other slide (Problem,
 * Solution, Roadmap, Team, Ask) silently replaced because `onAssist` always
 * did `setSlides(recipe.slides)` — whatever the model returned, whole.
 *
 * Now: a one-slide deck, or an instruction that asks for a new deck
 * (`wantsFullDeckReplace`), still replaces the whole list (selects slide 1,
 * matching prior behavior). Otherwise exactly one slot is written — the
 * slide named in the instruction, else the currently selected slide — and
 * every other slide is left as it was. Selection follows the edited slot
 * (not forced back to 0 unless that slot is 0).
 */
export function applyAssistResult(
  currentSlides: RecipeSlide[],
  selectedIndex: number,
  instruction: string,
  resultSlides: RecipeSlide[],
): { slides: RecipeSlide[]; index: number } {
  const result = resultSlides.length ? resultSlides : currentSlides
  if (currentSlides.length <= 1 || wantsFullDeckReplace(instruction)) {
    return { slides: result, index: 0 }
  }
  const targetIndex = findTargetSlideIndex(instruction, currentSlides, selectedIndex)
  const targetTitle = currentSlides[targetIndex]?.title || ''
  const picked = pickResultSlide(result, targetTitle)
  const nextSlides = currentSlides.map((slide, i) => (i === targetIndex ? picked : slide))
  return { slides: nextSlides, index: targetIndex }
}

/** Clamps again at the render/export boundary regardless of how state got there. */
export function serializeRecipe(title: string | undefined, slides: RecipeSlide[]): SlidesRecipe {
  const clamped = slides.slice(0, MAX_SLIDES).map((slide) => clampSlide(slide))
  return { version: 1, ...(title ? { title: title.slice(0, 120) } : {}), slides: clamped }
}
