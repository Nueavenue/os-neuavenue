import { describe, expect, it } from 'vitest'
import {
  phaseAfterEditorExport,
  phaseAfterExportBack,
  phaseAfterGalleryCardUse,
  phaseAfterPreviewPrompt,
  phaseAfterPromptContinue,
  phaseAfterStoryboardConfirm,
} from './studioPhase'

describe('studioPhase routing (P1-STORYBOARD-123)', () => {
  it('Q1 KEEP-EDITOR-DIRECT: gallery card Use goes to editor, not preview/prompt/storyboard', () => {
    expect(phaseAfterGalleryCardUse()).toBe('editor')
  })

  it('Preview → Prompt (S3) → Storyboard (S4) → Editor (S5)', () => {
    expect(phaseAfterPreviewPrompt()).toBe('prompt')
    expect(phaseAfterPromptContinue()).toBe('storyboard')
    expect(phaseAfterStoryboardConfirm()).toBe('editor')
  })

  it('S6 editor → export hub → editor', () => {
    expect(phaseAfterEditorExport()).toBe('export')
    expect(phaseAfterExportBack()).toBe('editor')
  })
})
