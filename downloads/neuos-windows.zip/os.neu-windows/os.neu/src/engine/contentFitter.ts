/**
 * WO-UI-NEU-PPT-OVERFLOW-123D (122D) — native overflow heuristics.
 * office-kit `auditTextLayout` concepts only (Q2 HOLD). No @office-kit/pptx.
 */
import { isLayoutPrimitive, recipeLayoutFor, type LayoutPrimitiveId } from './layoutContract'
import { MAX_BULLETS, MAX_TABLE_COLS, MAX_TABLE_ROWS, type RecipeSlide } from './slidesRecipe'

export type OverflowSeverity = 'ok' | 'warn' | 'error'

export type OverflowMessageKey =
  | 'title-long'
  | 'body-long'
  | 'too-many-bullets'
  | 'bullet-long'
  | 'metric-long'
  | 'table-wide'
  | 'divider-long'

export type FitResult = {
  overflow: boolean
  severity: OverflowSeverity
  messageKey?: OverflowMessageKey
  used: number
  budget: number
}

export const FIT_BUDGETS = {
  title: { titleChars: 80, bodyChars: 140 },
  bullets: { titleChars: 80, bulletChars: 90, maxBullets: MAX_BULLETS },
  'two-column': { titleChars: 80, bulletChars: 70, maxBullets: MAX_BULLETS },
  table: { titleChars: 80, cellChars: 40, maxCols: MAX_TABLE_COLS, maxRows: MAX_TABLE_ROWS },
  metric: { titleChars: 64, valueChars: 24, labelChars: 48 },
  'section-divider': { titleChars: 48 },
} as const

/** Outline-only slide for S2/S4 title budgets (no body yet). */
export function slideFromOutline(title: string, layout: LayoutPrimitiveId): RecipeSlide {
  return { layout: recipeLayoutFor(layout), primitive: layout, title, body: '', bullets: [], table: null }
}

export function primitiveOf(slide: RecipeSlide): LayoutPrimitiveId {
  if (slide.primitive && isLayoutPrimitive(slide.primitive)) return slide.primitive
  if (slide.layout === 'table') return 'table'
  if (slide.layout === 'title') return 'title'
  return 'bullets'
}

function severityFor(used: number, budget: number): OverflowSeverity {
  if (used <= budget) return 'ok'
  if (used <= budget * 1.3) return 'warn'
  return 'error'
}

function check(used: number, budget: number, messageKey: OverflowMessageKey): FitResult {
  const severity = severityFor(used, budget)
  return { overflow: severity !== 'ok', severity, messageKey: severity === 'ok' ? undefined : messageKey, used, budget }
}

function worst(results: FitResult[]): FitResult {
  const rank = { ok: 0, warn: 1, error: 2 }
  return results.reduce((a, b) => (rank[b.severity] > rank[a.severity] ? b : a))
}

function bulletsOf(slide: RecipeSlide): string[] {
  if (slide.bullets.length) return slide.bullets
  return String(slide.body || '')
    .split(/\r?\n/)
    .map((line) => line.replace(/^\s*[-*•]\s*/, '').trim())
    .filter(Boolean)
}

/** Estimate whether slide text exceeds the primitive's box (char/line budgets). */
export function fitSlide(slide: RecipeSlide): FitResult {
  const primitive = primitiveOf(slide)
  const title = slide.title || ''

  if (primitive === 'section-divider') {
    return check(title.length, FIT_BUDGETS['section-divider'].titleChars, 'divider-long')
  }

  if (primitive === 'title') {
    return worst([
      check(title.length, FIT_BUDGETS.title.titleChars, 'title-long'),
      check((slide.body || '').length, FIT_BUDGETS.title.bodyChars, 'body-long'),
    ])
  }

  if (primitive === 'metric') {
    const value = slide.table?.rows[0]?.[1] || slide.bullets[0] || slide.body || ''
    const label = slide.table?.rows[0]?.[0] || title
    return worst([
      check(title.length, FIT_BUDGETS.metric.titleChars, 'title-long'),
      check(value.length, FIT_BUDGETS.metric.valueChars, 'metric-long'),
      check(label.length, FIT_BUDGETS.metric.labelChars, 'title-long'),
    ])
  }

  if (primitive === 'table') {
    const cells = [
      ...(slide.table?.headers || []),
      ...(slide.table?.rows || []).flat(),
    ]
    const longest = cells.reduce((n, c) => Math.max(n, (c || '').length), 0)
    const cols = slide.table?.headers.length || 0
    const rows = slide.table?.rows.length || 0
    return worst([
      check(title.length, FIT_BUDGETS.table.titleChars, 'title-long'),
      check(longest, FIT_BUDGETS.table.cellChars, 'table-wide'),
      check(cols, FIT_BUDGETS.table.maxCols, 'table-wide'),
      check(rows, FIT_BUDGETS.table.maxRows, 'table-wide'),
    ])
  }

  const budget = primitive === 'two-column' ? FIT_BUDGETS['two-column'] : FIT_BUDGETS.bullets
  const bullets = bulletsOf(slide)
  const longest = bullets.reduce((n, b) => Math.max(n, b.length), 0)
  return worst([
    check(title.length, budget.titleChars, 'title-long'),
    check(bullets.length, budget.maxBullets, 'too-many-bullets'),
    check(longest, budget.bulletChars, 'bullet-long'),
  ])
}

export function fitDeck(slides: RecipeSlide[]): { overflowCount: number; results: FitResult[] } {
  const results = slides.map(fitSlide)
  return { overflowCount: results.filter((r) => r.overflow).length, results }
}
