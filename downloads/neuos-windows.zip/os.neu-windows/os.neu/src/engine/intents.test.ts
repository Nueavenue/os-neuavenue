import { describe, expect, it } from 'vitest'
import { classifyIntent, extractSearchQuery } from './intents'

describe('intents', () => {
  it('routes app install away from web', () => {
    expect(classifyIntent('크롬 설치해줘').kind).toBe('app-install')
    expect(classifyIntent('인터넷 열어줘').kind).toBe('web')
  })

  it('opens slides for powerpoint wording', () => {
    expect(classifyIntent('파워포인트 만들어줘').kind).toBe('slides')
  })

  it('does not steal a mixed internet+install request', () => {
    expect(classifyIntent('인터넷이 되는지 확인하고 브라우저를 띄워 node.js 설치를 부탁해').kind).toBe('web')
  })

  it('turns an investigate request into a web search with a query', () => {
    const ko = classifyIntent('강릉 날씨 조사해줘')
    expect(ko.kind).toBe('web')
    expect(ko.query).toBe('강릉 날씨')

    const en = classifyIntent('search tesla stock price')
    expect(en.kind).toBe('web')
    expect(en.query).toContain('tesla')
  })

  it('keeps office intents ahead of look-up verbs', () => {
    expect(classifyIntent('엑셀 보고서 조사해줘').kind).toBe('sheet-report')
    expect(classifyIntent('슬라이드 자료 찾아줘').kind).toBe('slides')
  })

  it('extractSearchQuery returns null for plain chat', () => {
    expect(extractSearchQuery('안녕하세요')).toBeNull()
    expect(extractSearchQuery('고마워')).toBeNull()
  })

  it('opens the English app only on explicit study wording', () => {
    expect(classifyIntent('영어 연습 하고 싶어').kind).toBe('english')
    expect(classifyIntent('practice English with me').kind).toBe('english')
    // plain greeting is NOT english study
    expect(classifyIntent('안녕').kind).toBe('talk')
  })

  it('exits the English app', () => {
    expect(classifyIntent('영어 그만').kind).toBe('english-exit')
    expect(classifyIntent('stop english').kind).toBe('english-exit')
  })
})
