import { describe, expect, it } from 'vitest'
import { ga4EventName, isValidGa4Id } from './ga4'

describe('ga4', () => {
  it('accepts standard measurement IDs', () => {
    expect(isValidGa4Id('G-ABCDEFGHIJ')).toBe(true)
    expect(isValidGa4Id('g-abc123xyz')).toBe(true)
  })

  it('rejects empty or malformed IDs', () => {
    expect(isValidGa4Id('')).toBe(false)
    expect(isValidGa4Id('UA-123456-1')).toBe(false)
    expect(isValidGa4Id('G-ABC')).toBe(false)
  })

  it('maps product event kinds to GA4 names', () => {
    expect(ga4EventName('click')).toBe('click')
    expect(ga4EventName('open-app')).toBe('open_app')
    expect(ga4EventName('login')).toBe('login')
  })
})
