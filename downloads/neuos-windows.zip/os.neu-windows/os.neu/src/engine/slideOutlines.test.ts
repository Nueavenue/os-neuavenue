import { describe, expect, it } from 'vitest'
import { MAX_SLIDES } from './slidesRecipe'
import { PRESENTATION_TEMPLATES } from './presentationTemplates'
import { OUTLINE_PACKS, getOutlinePack, type OutlinePackId } from './slideOutlines'

const PACK_IDS: OutlinePackId[] = ['pitch', 'report', 'product']

function allStrings(slides: ReturnType<typeof getOutlinePack>): string[] {
  const out: string[] = []
  for (const slide of slides) {
    out.push(slide.title, slide.body, ...slide.bullets)
    if (slide.table) {
      out.push(...slide.table.headers)
      for (const row of slide.table.rows) out.push(...row)
    }
  }
  return out
}

describe('OUTLINE_PACKS', () => {
  it('has exactly the three named packs (pitch, report, product)', () => {
    expect(Object.keys(OUTLINE_PACKS).sort()).toEqual(['pitch', 'product', 'report'])
  })

  for (const id of PACK_IDS) {
    it(`${id} pack has 1..MAX_SLIDES slides`, () => {
      expect(OUTLINE_PACKS[id].slides.length).toBeGreaterThan(0)
      expect(OUTLINE_PACKS[id].slides.length).toBeLessThanOrEqual(MAX_SLIDES)
    })

    it(`${id} pack uses only title | bullets | table layouts`, () => {
      for (const slide of OUTLINE_PACKS[id].slides) {
        expect(['title', 'bullets', 'table']).toContain(slide.layout)
      }
    })

    it(`${id} pack has no $ amounts and no ARR/revenue/억 figures in any string`, () => {
      for (const s of allStrings(OUTLINE_PACKS[id].slides)) {
        expect(s).not.toMatch(/\$/)
        expect(s).not.toMatch(/ARR/i)
        expect(s).not.toMatch(/revenue/i)
        expect(s).not.toMatch(/억/)
      }
    })
  }

  it('getOutlinePack deep-clones, so editing a picked pack never mutates the shared source', () => {
    const picked = getOutlinePack('report')
    picked[0].title = 'mutated title'
    picked[1].bullets.push('mutated bullet')
    const tableSlide = picked.find((s) => s.layout === 'table')
    if (tableSlide?.table) tableSlide.table.headers.push('mutated header')

    const again = getOutlinePack('report')
    expect(again[0].title).not.toBe('mutated title')
    expect(again[1].bullets).not.toContain('mutated bullet')
    const againTable = again.find((s) => s.layout === 'table')
    expect(againTable?.table?.headers).not.toContain('mutated header')
  })
})

describe('PRESENTATION_TEMPLATES', () => {
  it('points every template at pitch, report, or product and has no dollar KPI copy', () => {
    expect(PRESENTATION_TEMPLATES.length).toBeGreaterThan(0)
    for (const t of PRESENTATION_TEMPLATES) {
      expect(['pitch', 'report', 'product']).toContain(t.pack)
      const text = `${t.name} ${t.nameKo} ${t.description} ${t.cardSubtitle}`
      expect(text).not.toMatch(/\$|ARR|revenue|억/)
    }
  })
})
