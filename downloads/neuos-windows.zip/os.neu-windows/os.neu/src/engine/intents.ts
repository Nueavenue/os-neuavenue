import type { Intent } from '../types'

export function classifyIntent(raw: string): Intent {
  const text = raw.trim()
  if (!text) return { kind: 'talk', raw: text }

  // Leave the English coach app (highest priority so you can always get out).
  if (/영어\s*(그만|종료|끝|나가|닫)|그만할래|stop english|exit english|quit english|end english/i.test(text)) {
    return { kind: 'english-exit', raw: text }
  }
  // Enter the English study app (explicit — not the catch-all anymore).
  if (
    /영어\s*(공부|연습|회화|말하기|튜터|코치|배우|배울|배워)|영어로\s*(말|대화|연습)|english\s*(practice|lesson|tutor|coach|speaking|conversation)|practice english|teach me english|speak english/i.test(
      text,
    )
  ) {
    return { kind: 'english', raw: text }
  }

  if (/레이어|구조|원리|어떻게 작동|구성도|눈과 손|오케스트|layers|how this screen|wie das|cómo funciona|comment ça/i.test(text)) {
    return { kind: 'studio', raw: text }
  }
  if (/설치|깔아|깔게|uninstall|지우|다운로드|다운받|apt install|winget |brew install/i.test(text) && !/인터넷|웹\b|브라우저/i.test(text)) {
    return { kind: 'app-install', raw: text }
  }
  // Specific app/device intents win over a generic look-up (so "엑셀 보고서
  // 조사해줘" still opens the sheet, not a Google search).
  if (/파워포인트|슬라이드|ppt|slides|presentation|프레젠/i.test(text)) {
    return { kind: 'slides', raw: text }
  }
  if (/엑셀|시트|표|보고서|스프레드시트|sheet|excel|spreadsheet|informe|bericht|folha|bảng/i.test(text)) {
    return { kind: 'sheet-report', raw: text }
  }
  if (/워드|문서|메모|글 쓰|리포트|document|doc |memo|documento/i.test(text)) {
    return { kind: 'doc', raw: text }
  }
  if (/고장|하드웨어|상태|진단|컴퓨터가 괜찮|화면이 이상|배터리|hardware|computer is ok|device|gerät|ordinateur/i.test(text)) {
    return { kind: 'hardware', raw: text }
  }
  // Investigate / look up a term → real web search (not just the home page).
  const query = extractSearchQuery(text)
  if (query) {
    return { kind: 'web', raw: text, query }
  }
  if (/인터넷|브라우저|홈페이지|검색|웹|연결이 안|internet|open the web|abre internet|ouvre internet/i.test(text)) {
    return { kind: 'web', raw: text }
  }
  return { kind: 'talk', raw: text }
}

/**
 * Pull a search term out of an investigate/look-up request so voice or typed
 * lines actually run a search instead of only echoing "you want to know X".
 * Returns null when the line is not a look-up request.
 */
export function extractSearchQuery(raw: string): string | null {
  const text = raw.trim()
  if (!text) return null

  // Korean verbs: 조사/검색/찾아/알아봐/알려줘(…에 대해) + "~가 뭐야/무엇"
  const koVerb =
    /(조사|검색|찾아|찾아줘|알아봐|알아 봐|알아보|검색해|조사해|서치)/.test(text) ||
    /(에 ?대해|에 ?관해|에 ?대한).*(알려|설명|조사|검색|찾)/.test(text) ||
    /(뭐야|뭔가요|무엇|어떤 ?거|어떤 ?것|누구야|가격|시세|날씨)\??$/.test(text)
  // English verbs
  const enVerb = /\b(search|look ?up|google|find( out)?|what is|who is|how much|price of|weather)\b/i.test(text)

  if (!koVerb && !enVerb) return null

  let q = text
  // Strip leading/trailing request verbs and polite particles.
  q = q
    .replace(/\b(please|can you|could you|google|search for|search|look ?up|find out|find|what is|who is|how much is|tell me about|price of)\b/gi, ' ')
    .replace(/(에 ?대해서?|에 ?관해서?|에 ?대한|을|를|이|가|은|는|좀|자세히|인터넷에서|웹에서|검색해줘|검색해|조사해줘|조사해|찾아줘|찾아봐|찾아|알아봐줘|알아봐|알아보|알려줘|알려|해줘|해 ?주|해라|해|뭐야|뭔가요|무엇인가요|무엇|인가요|인가|야|니|\?)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

  // Guard: too short / became empty → treat as not a usable query.
  if (q.length < 2) return null
  // Avoid turning pure commands (install/hardware) into searches — those are
  // handled before this point, so here a leftover query is a genuine topic.
  return q
}

export function replyToTalk(raw: string): string {
  if (/안녕|헬로|하이|hello|hi\b|hola|bonjour|ciao/i.test(raw)) {
    return 'Hello. Skip Windows folders. Say one line for what you want.'
  }
  if (/도와|뭐 할|할 수|help|what can/i.test(raw)) {
    return 'Sheet report, document, internet, device health, or the four layers.'
  }
  return `OK. “${raw}” — name a sheet, document, or the web and the hands will move.`
}
