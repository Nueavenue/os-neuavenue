export const WINDOWS_PACK_FILE = 'os.neu-win-0.1.0-x64.zip'
export const WINDOWS_SOURCE_PACK_FILE = 'neuos-windows.zip'

export function linuxPackHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/api/download/linux'
  return '/downloads/neuos-linux.tar.gz'
}

export function usbKitHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/api/download/pack'
  return '/downloads/neuos-boot-kit.tar.gz'
}

export function windowsPackHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/api/download/windows'
  return `/downloads/${WINDOWS_PACK_FILE}`
}

export function windowsSourcePackHref(hostname = '') {
  if (hostname === 'localhost' || hostname === '127.0.0.1') return '/downloads/neuos-windows.zip'
  return `/downloads/${WINDOWS_SOURCE_PACK_FILE}`
}
