/**
 * WO-UI-NEU-PPT-LAYOUT-PRIMITIVES-123A (122A) — template contract + layout ids.
 * pptx-gen field/shape patterns only; no vendor tree. 122C binds these into PPTX.
 */
import type { SlideLayout } from './slidesRecipe'
import type { PresentationTemplate } from './presentationTemplates'

export const LAYOUT_PRIMITIVES = ['title', 'bullets', 'table', 'two-column', 'metric', 'section-divider'] as const

export type LayoutPrimitiveId = (typeof LAYOUT_PRIMITIVES)[number]

/** Leader §20 native five — ids in presentationTemplates.ts */
export const NATIVE_FIVE_IDS = [
  'neu-investor-dark',
  'minimal-corporate',
  'tech-architecture',
  'research-report',
  'product-launch',
] as const

export type NativeFiveId = (typeof NATIVE_FIVE_IDS)[number]

const TABLE_KEYS = new Set([
  'metrics',
  'roadmap',
  'feature-comparison',
  'comparison',
  'kpis',
  'funding',
  'business-model',
  'data-flow',
])

const METRIC_KEYS = new Set(['metrics', 'kpis', 'traction', 'funding'])
const TWO_COLUMN_KEYS = new Set(['architecture', 'components', 'market', 'solution', 'comparison', 'problem'])
const DIVIDER_KEYS = new Set(['closing', 'next', 'ask'])

export function layoutForStructureKey(key: string, index: number): LayoutPrimitiveId {
  if (index === 0 || key === 'cover') return 'title'
  if (DIVIDER_KEYS.has(key)) return 'section-divider'
  if (METRIC_KEYS.has(key)) return 'metric'
  if (TABLE_KEYS.has(key) && !METRIC_KEYS.has(key)) return 'table'
  if (TWO_COLUMN_KEYS.has(key)) return 'two-column'
  return 'bullets'
}

/** Editor canvas stays title | bullets | table; `RecipeSlide.primitive` carries 122C. */
export function recipeLayoutFor(layout: LayoutPrimitiveId): SlideLayout {
  if (layout === 'table' || layout === 'metric') return 'table'
  if (layout === 'title' || layout === 'section-divider') return 'title'
  return 'bullets'
}

export function isLayoutPrimitive(id: string): id is LayoutPrimitiveId {
  return (LAYOUT_PRIMITIVES as readonly string[]).includes(id)
}

export function nativeFiveTemplates(all: PresentationTemplate[]): PresentationTemplate[] {
  return NATIVE_FIVE_IDS.map((id) => {
    const t = all.find((row) => row.id === id)
    if (!t) throw new Error(`native-five missing: ${id}`)
    return t
  })
}
