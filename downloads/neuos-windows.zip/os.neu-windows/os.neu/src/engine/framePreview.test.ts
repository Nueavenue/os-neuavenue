import { describe, expect, it } from 'vitest'
import { faviconForHost, framePreview, youtubeEmbedSrc } from './framePreview'

describe('framePreview', () => {
  it('lets sites that allow framing use the live iframe', () => {
    expect(framePreview('https://neuavenue.com/')).toEqual({
      kind: 'iframe',
      src: 'https://neuavenue.com/',
      host: 'neuavenue.com',
    })
    expect(framePreview('https://bolt.new/').kind).toBe('iframe')
    expect(framePreview('https://kdc.day1company.co.kr/').kind).toBe('iframe')
  })

  it('shows a card when the host sends X-Frame-Options / CSP', () => {
    expect(framePreview('https://github.com/neuavenue').kind).toBe('card')
    expect(framePreview('https://developers.google.com/').kind).toBe('card')
    expect(framePreview('https://www.youtube.com/').kind).toBe('card')
    expect(framePreview('https://dify.ai/').kind).toBe('card')
  })

  it('uses the official YouTube embed for a watch URL', () => {
    expect(youtubeEmbedSrc('https://www.youtube.com/watch?v=dQw4w9WgXcQ')).toBe(
      'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ',
    )
    expect(framePreview('https://youtu.be/dQw4w9WgXcQ')).toEqual({
      kind: 'iframe',
      src: 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ',
      host: 'youtu.be',
    })
  })

  it('builds a favicon URL from the host', () => {
    expect(faviconForHost('www.github.com')).toContain('domain=github.com')
  })
})
