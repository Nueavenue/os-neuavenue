/** Google Analytics 4 — os.neu React shell only (not in-app BrowserView pages). */

export type Ga4TrackKind = 'view' | 'click' | 'login' | 'logout' | 'open-app' | 'feedback'

declare global {
  interface Window {
    dataLayer?: unknown[]
    gtag?: (...args: unknown[]) => void
  }
}

const MEASUREMENT_ID = String(import.meta.env.VITE_GA4_MEASUREMENT_ID || '').trim()

export function isValidGa4Id(id: string): boolean {
  return /^G-[A-Z0-9]{6,}$/i.test(id.trim())
}

export function ga4MeasurementId(): string {
  return isValidGa4Id(MEASUREMENT_ID) ? MEASUREMENT_ID : ''
}

export function ga4Enabled(): boolean {
  return Boolean(ga4MeasurementId())
}

let scriptReady = false
let loadPromise: Promise<boolean> | null = null

function gtag(...args: unknown[]) {
  window.dataLayer = window.dataLayer || []
  window.dataLayer.push(args)
}

/** Load gtag.js once. Resolves true when the script loaded. */
export function initGa4(): Promise<boolean> {
  const id = ga4MeasurementId()
  if (!id || typeof window === 'undefined') return Promise.resolve(false)
  if (scriptReady) return Promise.resolve(true)
  if (loadPromise) return loadPromise

  window.gtag = gtag
  gtag('js', new Date())
  gtag('config', id, { send_page_view: false })

  loadPromise = new Promise((resolve) => {
    const script = document.createElement('script')
    script.async = true
    script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`
    script.onload = () => {
      scriptReady = true
      resolve(true)
    }
    script.onerror = () => resolve(false)
    document.head.appendChild(script)
  })
  return loadPromise
}

export function ga4PageView(screen: string) {
  const id = ga4MeasurementId()
  if (!id || !window.gtag) return
  const path = `/${screen}`
  window.gtag('event', 'page_view', {
    page_title: `os.neu · ${screen}`,
    page_location: `${window.location.origin}${path}`,
    page_path: path,
    screen_name: screen,
    send_to: id,
  })
}

export function ga4EventName(kind: Ga4TrackKind): string {
  if (kind === 'open-app') return 'open_app'
  return kind
}

export function ga4Track(kind: Ga4TrackKind, screen: string, label?: string) {
  const id = ga4MeasurementId()
  if (!id || !window.gtag || kind === 'view') return
  window.gtag('event', ga4EventName(kind), {
    screen_name: screen,
    event_label: label,
    send_to: id,
  })
}

export function ga4SetUserId(userId: string | null) {
  const id = ga4MeasurementId()
  if (!id || !window.gtag) return
  window.gtag('config', id, { user_id: userId || undefined })
}
