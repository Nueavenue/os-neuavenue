/** Doc project tree: folders + documents (Word-style left rail). */

export type DocNodeKind = 'folder' | 'doc'

export type DocProject = {
  id: string
  name: string
  title: string
  body: string
  updated: number
  kind: DocNodeKind
  /** null = root level */
  parentId: string | null
}

const KEY = 'os.neu.doc.projects'
const MAX = 80

function newId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

function blankDoc(partial?: Partial<DocProject>): DocProject {
  const id = partial?.id || newId('p')
  return {
    id,
    name: partial?.name || 'Untitled',
    title: partial?.title || 'Untitled document',
    body: partial?.body || '',
    updated: partial?.updated || Date.now(),
    kind: 'doc',
    parentId: partial?.parentId ?? null,
  }
}

function blankFolder(partial?: Partial<DocProject>): DocProject {
  const id = partial?.id || newId('f')
  return {
    id,
    name: partial?.name || 'New folder',
    title: partial?.title || partial?.name || 'New folder',
    body: '',
    updated: partial?.updated || Date.now(),
    kind: 'folder',
    parentId: partial?.parentId ?? null,
  }
}

/** Normalize legacy flat rows (no kind/parentId) into the tree schema. */
export function normalizeDocProjects(rows: unknown): DocProject[] {
  if (!Array.isArray(rows) || !rows.length) return [blankDoc()]
  return rows.slice(0, MAX).map((raw, i) => {
    const row = (raw && typeof raw === 'object' ? raw : {}) as Partial<DocProject>
    const kind: DocNodeKind = row.kind === 'folder' ? 'folder' : 'doc'
    const id = String(row.id || `${kind}-${Date.now()}-${i}`)
    return {
      id,
      name: String(row.name || (kind === 'folder' ? 'Folder' : 'Untitled')),
      title: String(row.title || row.name || (kind === 'folder' ? 'Folder' : 'Untitled document')),
      body: kind === 'folder' ? '' : String(row.body || ''),
      updated: Number(row.updated) || Date.now(),
      kind,
      parentId: typeof row.parentId === 'string' ? row.parentId : null,
    }
  })
}

export function loadDocProjects(): DocProject[] {
  try {
    const raw = localStorage.getItem(KEY)
    const rows = raw ? (JSON.parse(raw) as unknown) : []
    const next = normalizeDocProjects(rows)
    saveDocProjects(next)
    return next
  } catch {
    /* fall through */
  }
  const seed = blankDoc({ name: 'Untitled', title: 'Untitled document' })
  saveDocProjects([seed])
  return [seed]
}

export function saveDocProjects(rows: DocProject[]) {
  try {
    if (typeof localStorage === 'undefined') return
    localStorage.setItem(KEY, JSON.stringify(normalizeDocProjects(rows).slice(0, MAX)))
  } catch {
    /* private mode / node tests */
  }
}

export function upsertDocProject(rows: DocProject[], next: DocProject) {
  const node = normalizeDocProjects([next])[0]
  const list = rows.some((row) => row.id === node.id)
    ? rows.map((row) => (row.id === node.id ? { ...row, ...node } : row))
    : [...rows, node]
  const final = normalizeDocProjects(list)
  saveDocProjects(final)
  return final
}

export function childrenOf(rows: DocProject[], parentId: string | null) {
  return rows
    .filter((row) => row.parentId === parentId)
    .sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === 'folder' ? -1 : 1
      return a.name.localeCompare(b.name)
    })
}

export type DocTreeRow = DocProject & { depth: number }

/** Depth-first flatten for the rail (respects which folders are expanded). */
export function flattenDocTree(rows: DocProject[], expanded: Set<string>): DocTreeRow[] {
  const out: DocTreeRow[] = []
  const walk = (parentId: string | null, depth: number) => {
    for (const row of childrenOf(rows, parentId)) {
      out.push({ ...row, depth })
      if (row.kind === 'folder' && expanded.has(row.id)) walk(row.id, depth + 1)
    }
  }
  walk(null, 0)
  return out
}

export function firstDoc(rows: DocProject[]): DocProject {
  const doc = rows.find((r) => r.kind === 'doc')
  return doc || blankDoc()
}

export function collectDescendantIds(rows: DocProject[], id: string): string[] {
  const kids = rows.filter((r) => r.parentId === id)
  return kids.flatMap((k) => [k.id, ...collectDescendantIds(rows, k.id)])
}

export function removeDocProject(rows: DocProject[], id: string) {
  const drop = new Set([id, ...collectDescendantIds(rows, id)])
  const list = rows.filter((row) => !drop.has(row.id))
  const next = list.length ? list : [blankDoc()]
  saveDocProjects(next)
  return next
}

export function addDocProject(
  rows: DocProject[],
  opts: { parentId?: string | null; name?: string; title?: string } = {},
) {
  const parentId = opts.parentId ?? null
  if (parentId) {
    const parent = rows.find((r) => r.id === parentId)
    if (!parent || parent.kind !== 'folder') {
      return { rows, node: blankDoc({ name: opts.name, title: opts.title, parentId: null }) }
    }
  }
  const node = blankDoc({
    name: opts.name || 'New doc',
    title: opts.title || opts.name || 'New document',
    parentId,
  })
  const list = upsertDocProject(rows, node)
  return { rows: list, node }
}

export function addFolderProject(
  rows: DocProject[],
  opts: { parentId?: string | null; name?: string } = {},
) {
  const parentId = opts.parentId ?? null
  if (parentId) {
    const parent = rows.find((r) => r.id === parentId)
    if (!parent || parent.kind !== 'folder') {
      return { rows, node: blankFolder({ name: opts.name, parentId: null }) }
    }
  }
  const node = blankFolder({ name: opts.name || 'New folder', parentId })
  const list = upsertDocProject(rows, node)
  return { rows: list, node }
}

/** Prevent cycles: cannot move under itself or a descendant. */
export function canReparent(rows: DocProject[], id: string, newParentId: string | null) {
  if (newParentId == null) return true
  if (newParentId === id) return false
  const blocked = new Set(collectDescendantIds(rows, id))
  return !blocked.has(newParentId) && rows.some((r) => r.id === newParentId && r.kind === 'folder')
}

export function moveDocProject(rows: DocProject[], id: string, newParentId: string | null) {
  if (!canReparent(rows, id, newParentId)) return rows
  const cur = rows.find((r) => r.id === id)
  if (!cur) return rows
  return upsertDocProject(rows, { ...cur, parentId: newParentId, updated: Date.now() })
}
