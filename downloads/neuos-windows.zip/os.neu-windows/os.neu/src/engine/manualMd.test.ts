import { describe, expect, it } from 'vitest'
import { htmlToMarkdown, markdownToHtml } from './manualMd'

describe('markdownToHtml', () => {
  it('renders headings, lists, and safe links', () => {
    const html = markdownToHtml('# Title\n\n- **Bold** item\n- See [docs](https://docs.neuavenue.com)\n\nType `install os.neu`.\n')
    expect(html).toContain('<h1>Title</h1>')
    expect(html).toContain('<strong>Bold</strong>')
    expect(html).toContain('href="https://docs.neuavenue.com"')
    expect(html).toContain('<code>install os.neu</code>')
    expect(html).not.toContain('<script')
  })

  it('escapes raw html', () => {
    const html = markdownToHtml('<img src=x onerror=alert(1)>')
    expect(html).toContain('&lt;img')
    expect(html).not.toContain('<img')
  })

  it('renders fenced commands and numbered steps', () => {
    const html = markdownToHtml('1. List disks\n\n```\nnpm run usb:list\n```\n')
    expect(html).toContain('<ol>')
    expect(html).toContain('<li>List disks</li>')
    expect(html).toContain('<pre><code>')
    expect(html).toContain('npm run usb:list')
  })

  it('renders blockquotes and gfm tables', () => {
    const html = markdownToHtml('> note\n\n| A | B |\n| --- | --- |\n| 1 | 2 |\n')
    expect(html).toContain('<blockquote>note</blockquote>')
    expect(html).toContain('<table>')
    expect(html).toContain('<th>A</th>')
    expect(html).toContain('<td>1</td>')
  })
})

describe('htmlToMarkdown round-trip', () => {
  it('keeps core markdown after preview conversion', () => {
    const src = '# Hello\n\nParagraph with **bold**.\n\n- one\n- two'
    const back = htmlToMarkdown(markdownToHtml(src))
    expect(back).toContain('# Hello')
    expect(back).toContain('**bold**')
    expect(back).toContain('- one')
    expect(back).toContain('- two')
  })

  it('ignores placeholder-only html', () => {
    expect(htmlToMarkdown('<p data-placeholder="1">Start writing…</p>')).toBe('')
    expect(htmlToMarkdown('<p><br></p>')).toBe('')
  })

  it('survives repeated convert cycles without wiping text', () => {
    let md = 'Keep me across Markdown and Preview toggles.'
    for (let i = 0; i < 5; i++) {
      md = htmlToMarkdown(markdownToHtml(md))
    }
    expect(md).toContain('Keep me across Markdown and Preview toggles.')
  })
})
