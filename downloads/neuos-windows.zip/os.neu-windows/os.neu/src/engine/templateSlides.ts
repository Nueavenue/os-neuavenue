import type { PresentationTemplate } from './presentationTemplates'
import { planSlidesFromTemplate } from './generationPlanner'
import type { RecipeSlide } from './slidesRecipe'

/** @deprecated name — use planSlidesFromTemplate */
export function slidesFromTemplate(template: PresentationTemplate, slideCount?: number): RecipeSlide[] {
  return planSlidesFromTemplate(template, slideCount)
}
