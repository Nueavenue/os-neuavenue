import { describe, expect, it, beforeEach } from 'vitest'
import {
  addBookmarkItem,
  addFolder,
  bookmarkKey,
  deleteFolder,
  loadBookmarkStore,
  moveBookmarkItem,
  saveBookmarkStore,
  toggleFolderCollapsed,
} from './bookmarks'

// Default vitest environment here is 'node' (see vitest.config.ts) — no DOM
// storage global. A minimal in-memory polyfill is enough for these tests.
if (typeof globalThis.localStorage === 'undefined') {
  const backing = new Map<string, string>()
  globalThis.localStorage = {
    getItem: (key: string) => (backing.has(key) ? backing.get(key)! : null),
    setItem: (key: string, value: string) => void backing.set(key, String(value)),
    removeItem: (key: string) => void backing.delete(key),
    clear: () => void backing.clear(),
    key: (index: number) => Array.from(backing.keys())[index] ?? null,
    get length() {
      return backing.size
    },
  } as Storage
}

describe('bookmarkKey', () => {
  it('normalizes casing and whitespace like ledgerStorageKey so the same account always resolves to one key', () => {
    expect(bookmarkKey('User@Example.com')).toBe(bookmarkKey('user@example.com'))
    expect(bookmarkKey('  user@example.com  ')).toBe(bookmarkKey('user@example.com'))
  })

  it('guest (no email) uses the plain device-global key', () => {
    expect(bookmarkKey(null)).toBe('os.neu.bookmarks')
  })
})

describe('loadBookmarkStore', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('migrates the legacy flat array into the new folder-aware shape, non-destructively', () => {
    localStorage.setItem('os.neu.bookmarks', JSON.stringify([{ id: 'b1', title: 'Old', url: 'https://old.example' }]))
    const store = loadBookmarkStore('new@example.com')
    expect(store.items).toHaveLength(1)
    expect(store.items[0].url).toBe('https://old.example')
    expect(store.items[0].folderId).toBeNull()
    // Legacy list is preserved, not deleted, so a second guest session still sees it.
    expect(localStorage.getItem('os.neu.bookmarks')).not.toBeNull()
  })

  it('does not re-migrate once a per-account key already exists', () => {
    localStorage.setItem('os.neu.bookmarks', JSON.stringify([{ id: 'b1', title: 'Old', url: 'https://old.example' }]))
    saveBookmarkStore('user@example.com', { folders: [], items: [] })
    const store = loadBookmarkStore('user@example.com')
    expect(store.items).toHaveLength(0)
  })

  it('two different-cased captures of the same email read/write the same bucket', () => {
    saveBookmarkStore('User@Example.com', addBookmarkItem({ folders: [], items: [] }, 'https://a.example', 'A'))
    const store = loadBookmarkStore('user@example.com')
    expect(store.items).toHaveLength(1)
    expect(store.items[0].url).toBe('https://a.example')
  })
})

describe('folders', () => {
  it('deleting a folder keeps its bookmarks by moving them back to the root', () => {
    let store = addFolder({ folders: [], items: [] }, 'Work')
    const folderId = store.folders[0].id
    store = addBookmarkItem(store, 'https://a.example', 'A', folderId)
    store = deleteFolder(store, folderId)
    expect(store.folders).toHaveLength(0)
    expect(store.items).toHaveLength(1)
    expect(store.items[0].folderId).toBeNull()
  })

  it('toggles collapsed state', () => {
    let store = addFolder({ folders: [], items: [] }, 'Work')
    const folderId = store.folders[0].id
    expect(store.folders[0].collapsed).toBe(false)
    store = toggleFolderCollapsed(store, folderId)
    expect(store.folders[0].collapsed).toBe(true)
  })

  it('moves a bookmark between folders', () => {
    let store = addFolder({ folders: [], items: [] }, 'Work')
    const folderId = store.folders[0].id
    store = addBookmarkItem(store, 'https://a.example', 'A', null)
    const itemId = store.items[0].id
    store = moveBookmarkItem(store, itemId, folderId)
    expect(store.items[0].folderId).toBe(folderId)
  })
})
