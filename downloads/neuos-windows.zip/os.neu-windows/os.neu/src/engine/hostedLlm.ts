/** Hosted Door B Ask AI — session key only. No Ollama on the CDN. */

export const HOSTED_OPENAI_STORAGE = 'neuos.hosted.openaiKey'
export const HOSTED_OPENAI_HEADER = 'x-neuos-openai-key'

export function isHostedOsNeuFace(hostname: string): boolean {
  const h = (hostname || '').toLowerCase()
  return h === 'os.neuavenue.com' || h.endsWith('.os-neuavenue.workers.dev')
}

export function lookLikeOpenAiKey(raw: string): boolean {
  const v = String(raw || '').trim()
  return v.startsWith('sk-') && v.length >= 20 && v.length < 500
}

export function readHostedOpenAiKey(storage: Pick<Storage, 'getItem'> | null | undefined): string {
  if (!storage) return ''
  try {
    const v = storage.getItem(HOSTED_OPENAI_STORAGE) || ''
    return lookLikeOpenAiKey(v) ? v.trim() : ''
  } catch {
    return ''
  }
}

export function writeHostedOpenAiKey(
  storage: Pick<Storage, 'setItem' | 'removeItem'> | null | undefined,
  key: string | null,
): boolean {
  if (!storage) return false
  try {
    if (!key) {
      storage.removeItem(HOSTED_OPENAI_STORAGE)
      return true
    }
    if (!lookLikeOpenAiKey(key)) return false
    storage.setItem(HOSTED_OPENAI_STORAGE, key.trim())
    return true
  } catch {
    return false
  }
}

export function hostedAssistHeaders(hostname: string, storage: Pick<Storage, 'getItem'> | null | undefined): HeadersInit {
  const headers: Record<string, string> = { 'content-type': 'application/json' }
  if (!isHostedOsNeuFace(hostname)) return headers
  const key = readHostedOpenAiKey(storage)
  if (key) headers[HOSTED_OPENAI_HEADER] = key
  return headers
}
