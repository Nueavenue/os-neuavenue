import { describe, expect, it } from 'vitest'
import { buildOAuthDeepLink, parseOAuthDeepLink } from './oauthDeepLink'

describe('oauth deep link', () => {
  it('round-trips token and handoff', () => {
    const href = buildOAuthDeepLink('tok-abc', 's-1')
    expect(href.startsWith('osneu://')).toBe(true)
    expect(parseOAuthDeepLink(href)).toEqual({ token: 'tok-abc', handoff: 's-1' })
  })

  it('rejects non-osneu or missing token', () => {
    expect(parseOAuthDeepLink('https://example.com/?token=x')).toBe(null)
    expect(parseOAuthDeepLink('osneu://oauth')).toBe(null)
  })
})
