import { describe, expect, it } from 'vitest'
import { detectGuestOs, heroPrimaryForGuestOs, packForGuestOs } from './detectOs'

describe('guest OS from the public site', () => {
  it('reads Windows, macOS, ChromeOS, and Linux from the user agent', () => {
    expect(detectGuestOs('Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'Windows')).toBe('windows')
    expect(detectGuestOs('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 'macOS')).toBe('macos')
    expect(detectGuestOs('Mozilla/5.0 (X11; CrOS x86_64 14541.0.0)', 'Linux')).toBe('chromeos')
    expect(detectGuestOs('Mozilla/5.0 (X11; Linux x86_64)', 'Linux')).toBe('linux')
  })

  it('ships Linux and Windows screen packs; not macOS or ChromeOS', () => {
    expect(packForGuestOs('linux', 'os.neuavenue.com').available).toBe(true)
    expect(packForGuestOs('linux', 'os.neuavenue.com').href).toBe('/downloads/neuos-linux.tar.gz')
    expect(packForGuestOs('windows', 'os.neuavenue.com').available).toBe(true)
    expect(packForGuestOs('windows', 'os.neuavenue.com').file).toBe('os.neu-win-0.1.0-x64.zip')
    expect(packForGuestOs('windows', 'os.neuavenue.com').href).toBe('/downloads/os.neu-win-0.1.0-x64.zip')
    expect(packForGuestOs('windows', 'os.neuavenue.com').href).not.toContain('neuos-linux.tar.gz')
    expect(packForGuestOs('windows', 'os.neuavenue.com').href).not.toContain('neuos-windows.zip')
    expect(packForGuestOs('macos').available).toBe(false)
    expect(packForGuestOs('chromeos').available).toBe(false)
  })

  it('welcome hero primary: Windows zip; linux/macos/unknown/chromeos boot kit; never linux tar on Windows', () => {
    const win = heroPrimaryForGuestOs('windows', 'os.neuavenue.com')
    expect(win.href).toBe('/downloads/os.neu-win-0.1.0-x64.zip')
    expect(win.label).toBe('Download os.neu on Windows')
    expect(win.href).not.toContain('neuos-linux.tar.gz')
    expect(heroPrimaryForGuestOs('linux', 'os.neuavenue.com').href).toBe('/downloads/neuos-boot-kit.tar.gz')
    expect(heroPrimaryForGuestOs('macos', 'os.neuavenue.com').href).toBe('/downloads/neuos-boot-kit.tar.gz')
    expect(heroPrimaryForGuestOs('unknown', 'os.neuavenue.com').href).toBe('/downloads/neuos-boot-kit.tar.gz')
    expect(heroPrimaryForGuestOs('chromeos', 'os.neuavenue.com').href).toBe('/downloads/neuos-boot-kit.tar.gz')
    expect(heroPrimaryForGuestOs('linux', 'os.neuavenue.com').label).toBe('Download boot kit')
  })
})
