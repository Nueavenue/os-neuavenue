export type CoachClip = { data: string; format: string }

let lastClip: CoachClip | null = null
let lastReply = ''
let activeAudio: HTMLAudioElement | null = null
let speaking = false
const speakingListeners = new Set<(on: boolean) => void>()

function setSpeaking(next: boolean) {
  speaking = next
  speakingListeners.forEach((listen) => listen(next))
}

export function onCoachSpeaking(listen: (on: boolean) => void): () => void {
  speakingListeners.add(listen)
  listen(speaking)
  return () => {
    speakingListeners.delete(listen)
  }
}

export function coachIsSpeaking(): boolean {
  return speaking
}

export function rememberCoach(reply: string, audio?: CoachClip) {
  lastReply = reply
  lastClip = audio ?? null
}

export function coachHasVoice(): boolean {
  return Boolean(lastClip || lastReply)
}

export function stopCoachAudio() {
  try {
    window.speechSynthesis?.cancel()
  } catch {
    /* ignore */
  }
  if (activeAudio) {
    try {
      activeAudio.pause()
      activeAudio.src = ''
    } catch {
      /* ignore */
    }
    activeAudio = null
  }
  setSpeaking(false)
}

export function speakBrowser(text: string): Promise<boolean> {
  if (typeof window === 'undefined' || !window.speechSynthesis || !text.trim()) {
    return Promise.resolve(false)
  }
  return new Promise((resolve) => {
    const utter = new SpeechSynthesisUtterance(text)
    utter.lang = 'en-US'
    utter.onend = () => {
      setSpeaking(false)
      resolve(true)
    }
    utter.onerror = () => {
      setSpeaking(false)
      resolve(false)
    }
    window.speechSynthesis.cancel()
    setSpeaking(true)
    window.speechSynthesis.speak(utter)
  })
}

export async function playCoachAudio(): Promise<boolean> {
  stopCoachAudio()
  if (lastClip) {
    const binary = atob(lastClip.data)
    const bytes = new Uint8Array(binary.length)
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i)
    const mime = lastClip.format === 'wav' ? 'audio/wav' : `audio/${lastClip.format}`
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }))
    const audio = new Audio(url)
    activeAudio = audio
    setSpeaking(true)
    return await new Promise((resolve) => {
      const finish = (ok: boolean) => {
        URL.revokeObjectURL(url)
        if (activeAudio === audio) activeAudio = null
        setSpeaking(false)
        resolve(ok)
      }
      audio.onended = () => finish(true)
      audio.onerror = () => finish(false)
      void audio.play().catch(() => finish(false))
    })
  }
  if (lastReply) return speakBrowser(lastReply)
  return false
}
