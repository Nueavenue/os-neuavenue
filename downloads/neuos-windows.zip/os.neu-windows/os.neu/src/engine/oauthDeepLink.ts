/**
 * Parse os.neu OAuth deep links.
 *
 * Preferred (WO-AUTH-ELECTRON-PKCE-1, opaque wake — no token in the URL):
 *   osneu://oauth?status=success&handoff=…
 * Legacy fallback (kept working until Console PKCE setup lands):
 *   osneu://oauth?token=…&handoff=…
 */

export type OAuthDeepLink = {
  token: string
  handoff: string
  status?: string
}

export function parseOAuthDeepLink(raw: string): OAuthDeepLink | null {
  const text = String(raw || '').trim()
  if (!text) return null
  try {
    const url = new URL(text)
    if (url.protocol !== 'osneu:') return null
    const host = url.hostname || url.host
    const path = (url.pathname || '').replace(/^\//, '')
    const kind = host || path.split('/')[0] || ''
    if (kind !== 'oauth' && path !== 'oauth' && !path.startsWith('oauth')) return null
    const token = String(url.searchParams.get('token') || '').trim()
    const handoff = String(url.searchParams.get('handoff') || '').trim()
    const status = String(url.searchParams.get('status') || '').trim()
    if (!token && !(status === 'success' && handoff)) return null
    return { token, handoff, status: status || undefined }
  } catch {
    return null
  }
}

/** Legacy deep link — carries the token in the URL. Kept for fallback only. */
export function buildOAuthDeepLink(token: string, handoff?: string) {
  const url = new URL('osneu://oauth')
  url.searchParams.set('token', String(token || '').trim())
  if (handoff) url.searchParams.set('handoff', String(handoff).trim())
  return url.toString()
}

/**
 * Preferred deep link — opaque wake only, no access/refresh token. The
 * renderer fetches the session via the existing handoff poll endpoint.
 */
export function buildOAuthWakeLink(handoff: string) {
  const url = new URL('osneu://oauth')
  url.searchParams.set('status', 'success')
  url.searchParams.set('handoff', String(handoff || '').trim())
  return url.toString()
}
