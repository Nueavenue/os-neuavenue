/**
 * Minimal ZIP (stored, no compression) writer — no npm dependency, matching
 * `docExport.ts`'s "no extra npm packages" convention. Stored entries are
 * spec-valid ZIP (PKWARE APPNOTE) and are read fine by PowerPoint,
 * LibreOffice Impress, Google Slides, and Python's `zipfile` — OOXML
 * packages do not require deflate.
 *
 * WO-UI-NEU-SLIDES-PPTX-121 (OFFICE-S1): built for `pptxExport.ts` so the
 * `.pptx` renderer stays JS-only, no `pptxgenjs` (avoids its transitive
 * `image-size` high-severity advisory — unneeded anyway since this GRANT
 * forbids embedding images/charts).
 */

export type ZipEntry = { name: string; data: Uint8Array }

const CRC_TABLE: Uint32Array = (() => {
  const table = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    }
    table[n] = c >>> 0
  }
  return table
})()

export function crc32(data: Uint8Array): number {
  let crc = 0xffffffff
  for (let i = 0; i < data.length; i++) {
    crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8)
  }
  return (crc ^ 0xffffffff) >>> 0
}

function dosDateTime(date: Date) {
  const time = ((date.getHours() & 0x1f) << 11) | ((date.getMinutes() & 0x3f) << 5) | ((Math.floor(date.getSeconds() / 2)) & 0x1f)
  const year = Math.max(0, date.getFullYear() - 1980)
  const dateVal = ((year & 0x7f) << 9) | (((date.getMonth() + 1) & 0xf) << 5) | (date.getDate() & 0x1f)
  return { time, date: dateVal }
}

function u16(n: number): number[] {
  return [n & 0xff, (n >> 8) & 0xff]
}

function u32(n: number): number[] {
  return [n & 0xff, (n >> 8) & 0xff, (n >> 16) & 0xff, (n >>> 24) & 0xff]
}

/** Build a stored (uncompressed) ZIP archive from name/bytes entries. */
export function buildZip(entries: ZipEntry[], when: Date = new Date()): Uint8Array {
  const { time, date } = dosDateTime(when)
  const body: number[] = []
  const central: number[] = []
  let offset = 0

  for (const entry of entries) {
    const nameBytes = Array.from(new TextEncoder().encode(entry.name))
    const data = entry.data
    const crc = crc32(data)
    const localOffset = offset

    const local = [
      ...u32(0x04034b50),
      ...u16(20), // version needed to extract
      ...u16(0), // general purpose flag
      ...u16(0), // method: stored
      ...u16(time),
      ...u16(date),
      ...u32(crc),
      ...u32(data.length), // compressed size == uncompressed (stored)
      ...u32(data.length),
      ...u16(nameBytes.length),
      ...u16(0), // extra field length
      ...nameBytes,
    ]
    body.push(...local, ...Array.from(data))
    offset += local.length + data.length

    central.push(
      ...u32(0x02014b50),
      ...u16(20), // version made by
      ...u16(20), // version needed
      ...u16(0), // flag
      ...u16(0), // method
      ...u16(time),
      ...u16(date),
      ...u32(crc),
      ...u32(data.length),
      ...u32(data.length),
      ...u16(nameBytes.length),
      ...u16(0), // extra
      ...u16(0), // comment
      ...u16(0), // disk number start
      ...u16(0), // internal attrs
      ...u32(0), // external attrs
      ...u32(localOffset),
      ...nameBytes,
    )
  }

  const centralOffset = offset
  const centralSize = central.length
  body.push(...central)

  const end = [
    ...u32(0x06054b50),
    ...u16(0), // disk number
    ...u16(0), // disk with cd start
    ...u16(entries.length),
    ...u16(entries.length),
    ...u32(centralSize),
    ...u32(centralOffset),
    ...u16(0), // comment length
  ]
  body.push(...end)

  return Uint8Array.from(body)
}
