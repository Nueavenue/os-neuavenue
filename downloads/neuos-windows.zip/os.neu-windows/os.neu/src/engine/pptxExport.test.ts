import { describe, expect, it } from 'vitest'
import { exportSlidesToPptx } from './pptxExport'
import { MAX_SLIDES, serializeRecipe } from './slidesRecipe'
import type { RecipeSlide } from './slidesRecipe'

function asText(bytes: Uint8Array): string {
  return new TextDecoder('utf-8').decode(bytes)
}

describe('exportSlidesToPptx', () => {
  const slides: RecipeSlide[] = [
    { layout: 'title', title: 'Welcome & <Intro>', body: 'os.neu Slides "demo"', bullets: [], table: null },
    { layout: 'bullets', title: 'Why', body: 'Fast\nLocal-first\nNo lock-in', bullets: ['Fast', 'Local-first', 'No lock-in'], table: null },
    {
      layout: 'table',
      title: 'Numbers (EXAMPLE)',
      body: '',
      bullets: [],
      table: { headers: ['Metric', 'Value'], rows: [['Users', '10'], ['Retention', '90%']] },
    },
  ]
  const recipe = serializeRecipe('Demo Deck', slides)
  const bytes = exportSlidesToPptx(recipe, new Date('2026-09-22T00:00:00Z'))

  it('starts with the ZIP magic bytes (PK)', () => {
    expect(bytes[0]).toBe(0x50) // 'P'
    expect(bytes[1]).toBe(0x4b) // 'K'
    expect(bytes[2]).toBe(0x03)
    expect(bytes[3]).toBe(0x04)
  })

  it('ends with the end-of-central-directory signature (0x06054b50)', () => {
    const eocd = bytes.slice(-22, -18)
    expect(Array.from(eocd)).toEqual([0x50, 0x4b, 0x05, 0x06])
  })

  it('lists [Content_Types].xml as the first zip entry name', () => {
    // stored (uncompressed) entries keep XML text scannable straight out of the buffer
    const text = asText(bytes)
    expect(text.indexOf('[Content_Types].xml')).toBeGreaterThan(-1)
    expect(text).toContain('ppt/presentation.xml')
  })

  it('embeds all required OOXML package parts', () => {
    const text = asText(bytes)
    for (const part of [
      'ppt/presentation.xml',
      'ppt/slideMasters/slideMaster1.xml',
      'ppt/slideLayouts/slideLayout1.xml',
      'ppt/theme/theme1.xml',
      'ppt/slides/slide1.xml',
      'ppt/slides/slide2.xml',
      'ppt/slides/slide3.xml',
      'docProps/core.xml',
      '_rels/.rels',
    ]) {
      expect(text).toContain(part)
    }
  })

  it('does not emit a 4th slide part beyond the given 3 slides', () => {
    const text = asText(bytes)
    expect(text).not.toContain('ppt/slides/slide4.xml')
  })

  it('caps at MAX_SLIDES even if given more', () => {
    const many = Array.from({ length: 25 }, (_, i) => ({
      layout: 'bullets' as const,
      title: `Slide ${i + 1}`,
      body: `point ${i}`,
      bullets: [`point ${i}`],
      table: null,
    }))
    const cappedBytes = exportSlidesToPptx(serializeRecipe(undefined, many))
    const text = asText(cappedBytes)
    expect(text).toContain(`ppt/slides/slide${MAX_SLIDES}.xml`)
    expect(text).not.toContain(`ppt/slides/slide${MAX_SLIDES + 1}.xml`)
  })

  it('escapes special XML characters from user text', () => {
    const text = asText(bytes)
    expect(text).toContain('Welcome &amp; &lt;Intro&gt;')
    expect(text).toContain('demo')
  })

  it('renders bullet text and table cell text into their slide parts', () => {
    const text = asText(bytes)
    expect(text).toContain('Local-first')
    expect(text).toContain('Retention')
    expect(text).toContain('90%')
  })

  it('never embeds an image or chart relationship (no image/chart parts this pass)', () => {
    const text = asText(bytes)
    expect(text).not.toContain('/ppt/media/')
    expect(text).not.toContain('graphicml/2006/chart')
  })
})

describe('122C pptxExport layout primitives', () => {
  it('emits TwoColumnLeft / TwoColumnRight shape names', () => {
    const slides: RecipeSlide[] = [
      {
        layout: 'bullets',
        primitive: 'two-column',
        title: 'Split',
        body: 'A\nB',
        bullets: ['A', 'B'],
        table: null,
      },
    ]
    const text = asText(exportSlidesToPptx(serializeRecipe('Cols', slides)))
    expect(text).toContain('TwoColumnLeft')
    expect(text).toContain('TwoColumnRight')
  })

  it('emits MetricValue / MetricLabel shape names', () => {
    const slides: RecipeSlide[] = [
      {
        layout: 'table',
        primitive: 'metric',
        title: 'Status',
        body: '',
        bullets: [],
        table: { headers: ['Topic', 'Notes'], rows: [['Users', '10']] },
      },
    ]
    const text = asText(exportSlidesToPptx(serializeRecipe('Metric', slides)))
    expect(text).toContain('MetricValue')
    expect(text).toContain('MetricLabel')
    expect(text).toContain('10')
  })

  it('emits SectionDivider shape name', () => {
    const slides: RecipeSlide[] = [
      { layout: 'title', primitive: 'section-divider', title: 'Closing', body: '', bullets: [], table: null },
    ]
    const text = asText(exportSlidesToPptx(serializeRecipe('Div', slides)))
    expect(text).toContain('SectionDivider')
    expect(text).toContain('Closing')
  })
})
