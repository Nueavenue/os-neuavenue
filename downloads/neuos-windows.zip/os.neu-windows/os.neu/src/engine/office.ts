import { hostedAssistHeaders } from './hostedLlm'

function officeHeaders(): HeadersInit {
  if (typeof location === 'undefined') return { 'content-type': 'application/json' }
  return hostedAssistHeaders(location.hostname, typeof sessionStorage === 'undefined' ? null : sessionStorage)
}

export type OfficeApp = 'sheet' | 'doc' | 'slides'

export const OFFICE_MODELS = [
  { id: 'os.neu-local', label: 'os.neu-local (llama3.2:1b)' },
  { id: 'gpt-4o-mini', label: 'GPT-4o mini' },
  { id: 'gpt-4o', label: 'GPT-4o' },
  { id: 'gpt-4.1-mini', label: 'GPT-4.1 mini' },
  { id: 'gpt-4.1', label: 'GPT-4.1' },
] as const

export async function assistOffice(body: {
  model: string
  app: OfficeApp
  instruction: string
  content?: string
  selection?: string
  mode?: 'write' | 'rewrite'
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
}) {
  try {
    const res = await fetch('/api/office/assist', {
      method: 'POST',
      headers: officeHeaders(),
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(130_000),
    })
    return (await res.json()) as { ok: boolean; text?: string; reason?: string; model?: string }
  } catch (err) {
    const reason = err instanceof Error && err.name === 'TimeoutError' ? 'timeout' : 'network'
    return { ok: false, reason }
  }
}

export type AssistStreamChunk = {
  ok: boolean
  piece?: string
  full?: string
  done?: boolean
  reason?: string
  model?: string
  provider?: string
}

type AssistStreamResult = { ok: boolean; text: string; reason?: string }

async function fakeTypeStream(text: string, onChunk: (chunk: AssistStreamChunk) => void): Promise<AssistStreamResult> {
  const step = Math.max(1, Math.floor(text.length / 56))
  let full = ''
  for (let i = 0; i < text.length; i += step) {
    const piece = text.slice(i, i + step)
    full += piece
    onChunk({ ok: true, piece, full, done: i + step >= text.length })
    await new Promise((r) => window.setTimeout(r, 12))
  }
  return { ok: Boolean(full.trim()), text: full }
}

/** Prefer NDJSON stream; if bridge is old (404/not-found), fall back to one-shot + typing UX. */
export async function assistOfficeStream(
  body: {
    model: string
    app: OfficeApp
    instruction: string
    content?: string
    selection?: string
    mode?: 'write' | 'rewrite'
    history?: Array<{ role: 'user' | 'assistant'; content: string }>
  },
  onChunk: (chunk: AssistStreamChunk) => void,
): Promise<AssistStreamResult> {
  let res: Response
  try {
    res = await fetch('/api/office/assist/stream', {
      method: 'POST',
      headers: officeHeaders(),
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(180_000),
    })
  } catch (err) {
    const reason = err instanceof Error && err.name === 'TimeoutError' ? 'timeout' : 'network'
    onChunk({ ok: false, reason, done: true })
    return { ok: false, text: '', reason }
  }

  const contentType = res.headers.get('content-type') || ''
  if (!res.ok || contentType.includes('application/json')) {
    const fail = (await res.json().catch(() => ({}))) as { reason?: string; ok?: boolean; text?: string }
    const reason = fail.reason || `http-${res.status}`
    if (reason === 'not-found' || res.status === 404) {
      const oneshot = await assistOffice(body)
      if (!oneshot.ok || !oneshot.text) {
        onChunk({ ok: false, reason: oneshot.reason || reason, done: true })
        return { ok: false, text: '', reason: oneshot.reason || reason }
      }
      return fakeTypeStream(oneshot.text, onChunk)
    }
    onChunk({ ok: false, reason, done: true })
    return { ok: false, text: '', reason }
  }

  if (!res.body) {
    onChunk({ ok: false, reason: 'no-body', done: true })
    return { ok: false, text: '', reason: 'no-body' }
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buf = ''
  let full = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += decoder.decode(value, { stream: true })
    const lines = buf.split('\n')
    buf = lines.pop() || ''
    for (const line of lines) {
      const raw = line.trim()
      if (!raw) continue
      try {
        const row = JSON.parse(raw) as AssistStreamChunk
        if (row.full) full = row.full
        else if (row.piece) full += row.piece
        onChunk({ ...row, full })
        if (row.ok === false && row.done) {
          return { ok: false, text: full, reason: row.reason || 'assist-error' }
        }
      } catch {
        /* skip */
      }
    }
  }
  return { ok: Boolean(full.trim()), text: full }
}
