/**
 * Folder-aware per-account bookmark storage (WO-BROWSER-SESSION-1 follow-up —
 * Leader asked for a Windows-Explorer-style show/hide folder tree, plus a
 * dedicated manager and a bookmarks bar). Replaces the flat `BrowserTab[]`
 * bookmark list with `{ folders, items }`, migrating the old flat shape
 * (and the even older device-global list) forward non-destructively.
 */

export type BookmarkFolder = {
  id: string
  title: string
  collapsed: boolean
  order: number
}

export type BookmarkItem = {
  id: string
  title: string
  url: string
  folderId: string | null
  order: number
}

export type BookmarkStore = {
  folders: BookmarkFolder[]
  items: BookmarkItem[]
}

const BOOKMARK_KEY = 'os.neu.bookmarks'

export function bookmarkKey(email: string | null) {
  // Normalize the same way ledgerStorageKey does — different casing/whitespace
  // for the *same* account (e.g. Google-returned vs. typed) must resolve to
  // the same key, or a user's own bookmarks can appear to "disappear" or get
  // "stuck" showing another session's list.
  const neat = String(email || '').trim().toLowerCase()
  return neat ? `${BOOKMARK_KEY}.${neat}` : BOOKMARK_KEY
}

export function emptyStore(): BookmarkStore {
  return { folders: [], items: [] }
}

function newId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
}

/** Oldest shape: a flat array of `{ id, title, url }` (pre-folders, pre-per-user). */
function migrateLegacyArray(raw: unknown[]): BookmarkStore {
  const items: BookmarkItem[] = []
  raw.forEach((row, index) => {
    if (!row || typeof row !== 'object') return
    const rec = row as { id?: unknown; title?: unknown; url?: unknown }
    const url = typeof rec.url === 'string' ? rec.url : ''
    if (!url) return
    items.push({
      id: typeof rec.id === 'string' && rec.id ? rec.id : newId('b'),
      title: typeof rec.title === 'string' && rec.title ? rec.title : url,
      url,
      folderId: null,
      order: index,
    })
  })
  return { folders: [], items }
}

function parseStore(raw: string): BookmarkStore {
  try {
    const parsed = JSON.parse(raw)
    if (Array.isArray(parsed)) return migrateLegacyArray(parsed)
    if (parsed && typeof parsed === 'object') {
      const folders = Array.isArray(parsed.folders)
        ? parsed.folders.filter((f: unknown): f is BookmarkFolder => Boolean(f) && typeof f === 'object')
        : []
      const items = Array.isArray(parsed.items)
        ? parsed.items.filter((it: unknown): it is BookmarkItem => Boolean(it) && typeof it === 'object')
        : []
      return { folders, items }
    }
    return emptyStore()
  } catch {
    return emptyStore()
  }
}

export function loadBookmarkStore(email: string | null): BookmarkStore {
  const key = bookmarkKey(email)
  const raw = localStorage.getItem(key)
  if (raw) return parseStore(raw)
  if (!email) return emptyStore()
  // One-time, non-destructive migration from the old device-global list —
  // never deletes it, so a second guest session still sees guest bookmarks.
  const legacyRaw = localStorage.getItem(BOOKMARK_KEY)
  if (!legacyRaw) return emptyStore()
  const migrated = parseStore(legacyRaw)
  if (migrated.items.length) localStorage.setItem(key, JSON.stringify(migrated))
  return migrated
}

export function saveBookmarkStore(email: string | null, store: BookmarkStore) {
  localStorage.setItem(bookmarkKey(email), JSON.stringify(store))
}

export function addBookmarkItem(store: BookmarkStore, url: string, title: string, folderId: string | null = null): BookmarkStore {
  const order = store.items.filter((it) => it.folderId === folderId).length
  const item: BookmarkItem = { id: newId('b'), title: title || url, url, folderId, order }
  return { ...store, items: [item, ...store.items.filter((it) => it.url !== url || it.folderId !== folderId)] }
}

export function editBookmarkItem(store: BookmarkStore, id: string, patch: { title: string; url: string }): BookmarkStore {
  return { ...store, items: store.items.map((it) => (it.id === id ? { ...it, ...patch } : it)) }
}

export function deleteBookmarkItem(store: BookmarkStore, id: string): BookmarkStore {
  return { ...store, items: store.items.filter((it) => it.id !== id) }
}

export function moveBookmarkItem(store: BookmarkStore, id: string, folderId: string | null): BookmarkStore {
  return { ...store, items: store.items.map((it) => (it.id === id ? { ...it, folderId } : it)) }
}

export function addFolder(store: BookmarkStore, title: string): BookmarkStore {
  const folder: BookmarkFolder = { id: newId('f'), title: title || 'New folder', collapsed: false, order: store.folders.length }
  return { ...store, folders: [...store.folders, folder] }
}

export function renameFolder(store: BookmarkStore, id: string, title: string): BookmarkStore {
  return { ...store, folders: store.folders.map((f) => (f.id === id ? { ...f, title } : f)) }
}

export function toggleFolderCollapsed(store: BookmarkStore, id: string): BookmarkStore {
  return { ...store, folders: store.folders.map((f) => (f.id === id ? { ...f, collapsed: !f.collapsed } : f)) }
}

/** Deleting a folder keeps its bookmarks — they move back to the root list. */
export function deleteFolder(store: BookmarkStore, id: string): BookmarkStore {
  return {
    folders: store.folders.filter((f) => f.id !== id),
    items: store.items.map((it) => (it.folderId === id ? { ...it, folderId: null } : it)),
  }
}
