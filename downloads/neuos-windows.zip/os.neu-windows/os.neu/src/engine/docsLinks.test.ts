import { describe, expect, it } from 'vitest'
import { frameForDocsDest, resolveDocsLink } from './docsLinks'

const ORIGIN = 'http://127.0.0.1:5173'

describe('resolveDocsLink', () => {
  it('maps the three manual links to local fonted pages', () => {
    expect(resolveDocsLink('https://os.neuavenue.com', ORIGIN)?.kind).toBe('public-home')
    expect(resolveDocsLink('https://docs.neuavenue.com', ORIGIN)?.kind).toBe('docs-home')
    expect(resolveDocsLink('https://os.neuavenue.com/tutorial', ORIGIN)?.kind).toBe('tutorial')
  })

  it('leaves the boot kit as a download', () => {
    const dest = resolveDocsLink('https://os.neuavenue.com/downloads/neuos-boot-kit.tar.gz', ORIGIN)
    expect(dest?.kind).toBe('download')
  })

  it('adds locale to framed hrefs', () => {
    const dest = resolveDocsLink('https://docs.neuavenue.com', ORIGIN)
    expect(dest).toBeTruthy()
    expect(frameForDocsDest(dest!, 'en')).toContain('lang=en')
    expect(frameForDocsDest(dest!, 'ko')).toContain('/docs/index.html')
  })
})
