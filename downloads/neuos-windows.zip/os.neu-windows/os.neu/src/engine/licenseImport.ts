/**
 * WO-UI-NEU-PPT-IMPORT-LICENSE-123E (122E) — CC BY 4.0 pilot only.
 * Schema + metadata. No bundled third-party `.pptx`. No Slidesgo.
 */
import type { OutlinePackId } from './slideOutlines'
import type { PresentationTemplate, TemplateCategory, TemplateLicenseMeta } from './presentationTemplates'

export const PILOT_MAX = 3
export const APPROVED_SOURCE = 'free-ppt-template'
export const APPROVED_LICENSE = 'CC BY 4.0'
export const APPROVED_LICENSE_URL = 'https://github.com/ai-ppt-template/free-ppt-template/blob/main/LICENSE'
export const APPROVED_ATTRIBUTION = 'Templates by ppttemplate.ai (CC BY 4.0)'

export const FREE_PPT_CC_BY: TemplateLicenseMeta = {
  source: APPROVED_SOURCE,
  license: APPROVED_LICENSE,
  licenseUrl: APPROVED_LICENSE_URL,
  attributionRequired: true,
  attributionText: APPROVED_ATTRIBUTION,
}

function pilot(
  id: string,
  name: string,
  nameKo: string,
  category: TemplateCategory,
  categoryFilter: string,
  pack: OutlinePackId,
  previewTheme: PresentationTemplate['previewTheme'],
  structure: string[],
  styleTheme: string,
): PresentationTemplate {
  return {
    id,
    name,
    nameKo,
    category,
    categoryFilter,
    description: 'CC BY 4.0 schema pilot normalized from free-ppt-template. No bundled .pptx.',
    descriptionKo: 'free-ppt-template CC BY 4.0 스키마 파일럿. .pptx 원본은 포함하지 않습니다.',
    cardSubtitle: 'CC BY 4.0 · schema only',
    cardSubtitleKo: 'CC BY 4.0 · 스키마만',
    aspectRatio: '16:9',
    previewTheme,
    style: {
      theme: styleTheme,
      typography: 'modern-sans',
      density: 'medium',
      visualTone: 'licensed-pilot',
      accent: 'slate',
    },
    structure,
    packPolicy: { defaultSlides: 8, minSlides: 6, maxSlides: 20 },
    group: 'popular',
    pack,
    license: { ...FREE_PPT_CC_BY },
  }
}

/** Cap 3. Not listed in PRESENTATION_TEMPLATES (no gallery bulk). */
export const LICENSED_PILOTS: PresentationTemplate[] = [
  pilot(
    'ccby-pilot-business',
    'Business Brief (CC BY pilot)',
    '비즈니스 브리프 (CC BY 파일럿)',
    'Business',
    'business',
    'pitch',
    'modern-business',
    ['cover', 'problem', 'solution', 'market', 'traction', 'roadmap', 'ask', 'closing'],
    'light-minimal',
  ),
  pilot(
    'ccby-pilot-education',
    'Education Outline (CC BY pilot)',
    '교육 개요 (CC BY 파일럿)',
    'Education',
    'education',
    'report',
    'report',
    ['cover', 'objectives', 'overview', 'steps', 'comparison', 'resources', 'next', 'closing'],
    'light-minimal',
  ),
  pilot(
    'ccby-pilot-marketing',
    'Marketing Update (CC BY pilot)',
    '마케팅 업데이트 (CC BY 파일럿)',
    'Marketing',
    'marketing',
    'product',
    'marketing',
    ['cover', 'problem', 'solution', 'market', 'product', 'metrics', 'roadmap', 'closing'],
    'dark-tech',
  ),
]

export function getLicensedPilot(id: string): PresentationTemplate | undefined {
  return LICENSED_PILOTS.find((t) => t.id === id)
}

export function listLicensedPilots(): PresentationTemplate[] {
  return LICENSED_PILOTS.slice()
}

export type LicenseImportInput = {
  source: string
  license: string
  licenseUrl?: string
}

export function importLicensedPilot(input: LicenseImportInput): { ok: true; meta: TemplateLicenseMeta } | { ok: false; reason: string } {
  const source = String(input.source || '').trim()
  const license = String(input.license || '').trim()
  const blob = `${source} ${input.licenseUrl || ''}`.toLowerCase()
  if (blob.includes('slidesgo') || blob.includes('envato') || blob.includes('graphicriver')) {
    return { ok: false, reason: 'source-forbidden' }
  }
  const sourceOk = source === APPROVED_SOURCE || source.includes('free-ppt-template')
  if (!sourceOk) return { ok: false, reason: 'source-not-approved' }
  if (license !== APPROVED_LICENSE && license !== 'CC-BY-4.0') {
    return { ok: false, reason: 'license-not-cc-by-40' }
  }
  return { ok: true, meta: { ...FREE_PPT_CC_BY } }
}

export function wouldExceedPilotCap(additionalCount: number): boolean {
  return LICENSED_PILOTS.length + additionalCount > PILOT_MAX
}

export function normalizeImportedSchema(partial: {
  id: string
  name: string
  nameKo?: string
  structure: string[]
  pack: OutlinePackId
  category: TemplateCategory
  license: TemplateLicenseMeta
}): PresentationTemplate | { error: string } {
  const gate = importLicensedPilot(partial.license)
  if (!gate.ok) return { error: gate.reason }
  if (wouldExceedPilotCap(1) && !getLicensedPilot(partial.id)) return { error: 'over-cap' }
  if (!partial.id.trim() || !partial.structure.length) return { error: 'invalid-schema' }
  const existing = getLicensedPilot(partial.id)
  if (existing) return existing
  return { error: 'over-cap' }
}
