export type DocsDestKind = 'docs-home' | 'manual' | 'tutorial' | 'public-home' | 'download'

export type DocsDest = {
  kind: DocsDestKind
  href: string
}

function originOf(raw: string, fallback: string) {
  try {
    return new URL(raw, fallback).origin
  } catch {
    return fallback
  }
}

/** Map the three manual links (and docs card) onto local pages that carry locale fonts. */
export function resolveDocsLink(raw: string, origin = 'http://127.0.0.1'): DocsDest | null {
  if (!raw) return null
  let url: URL
  try {
    url = new URL(raw, origin)
  } catch {
    return null
  }
  const host = url.hostname.replace(/^www\./, '').toLowerCase()
  const path = url.pathname.replace(/\/+$/, '') || '/'
  const isOs = host === 'os.neuavenue.com' || host === 'neuos.neuavenue.com'
  const isDocs = host === 'docs.neuavenue.com'
  const isLoop = host === 'localhost' || host === '127.0.0.1' || host === '::1'
  const sameHost = originOf(url.href, origin) === origin || isLoop

  if (path.includes('/downloads/') || path.endsWith('.tar.gz') || path.endsWith('.iso')) {
    return { kind: 'download', href: url.href }
  }
  if (isDocs && (path === '/' || path === '/docs' || path === '/docs/index.html' || path === '/index.html')) {
    return { kind: 'docs-home', href: `${origin}/docs/index.html` }
  }
  if (
    (isDocs || (sameHost && path.startsWith('/docs'))) &&
    (path.endsWith('manual.md') || path.endsWith('/manual') || path.endsWith('manual.en.md'))
  ) {
    const doc = path.endsWith('manual.en.md') ? 'manual.en.md' : 'manual.md'
    return { kind: 'manual', href: `${origin}/docs/view.html?doc=${doc}` }
  }
  if ((isOs || sameHost) && (path === '/tutorial' || path === '/tutorial.html')) {
    return { kind: 'tutorial', href: `${origin}/tutorial.html` }
  }
  if (isOs && (path === '/' || path === '')) {
    return { kind: 'public-home', href: `${origin}/docs/public-home.html` }
  }
  return null
}

export function frameForDocsDest(dest: DocsDest, lang: string): string {
  const join = dest.href.includes('?') ? '&' : '?'
  if (dest.kind === 'download') return dest.href
  return `${dest.href}${join}lang=${encodeURIComponent(lang)}&embed=1`
}
