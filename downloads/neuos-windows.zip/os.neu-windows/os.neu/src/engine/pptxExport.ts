/**
 * WO-UI-NEU-SLIDES-PPTX-121 (OFFICE-S1) — real `.pptx` (ZIP/OOXML) bytes
 * from the current in-memory slides. Hand-rolled minimal OOXML, built on
 * `zip.ts` (no `pptxgenjs` — see that file's header for why). Layouts this
 * pass: `title` | `bullets` | `table` plus 122C primitives (`two-column` ·
 * `metric` · `section-divider`). Cap is `MAX_SLIDES`. No images/charts.
 */

import { buildZip, type ZipEntry } from './zip'
import { MAX_SLIDES, type RecipeSlide, type SlidesRecipe } from './slidesRecipe'

const SLIDE_W = 12192000 // 16:9 widescreen, EMU (13.333in)
const SLIDE_H = 6858000 // 7.5in
const MARGIN_X = 457200 // 0.5in
const CONTENT_W = SLIDE_W - MARGIN_X * 2
const BODY_TOP = 1325563

function esc(text: string): string {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
}

/** Table cells / bullet lines render as a single paragraph run — collapse newlines. */
function oneLine(text: string): string {
  const flat = esc(String(text ?? '').replace(/[\r\n]+/g, ' ').trim())
  return flat || ' '
}

function paragraph(
  text: string,
  opts: { sz: number; b?: boolean; align?: 'l' | 'ctr'; bullet?: boolean; color?: string; typeface?: string },
): string {
  const face = opts.typeface || 'Arial'
  const pPr = opts.bullet
    ? `<a:pPr marL="285750" indent="-285750"${opts.align ? ` algn="${opts.align}"` : ''}><a:buFont typeface="${face}"/><a:buChar char="\u2022"/></a:pPr>`
    : opts.align
      ? `<a:pPr algn="${opts.align}"/>`
      : ''
  const color = opts.color ? `<a:solidFill><a:srgbClr val="${opts.color}"/></a:solidFill>` : ''
  const latin = `<a:latin typeface="${face}"/>`
  return `<a:p>${pPr}<a:r><a:rPr lang="en-US" sz="${opts.sz}"${opts.b ? ' b="1"' : ''} dirty="0">${color}${latin}</a:rPr><a:t>${oneLine(text)}</a:t></a:r></a:p>`
}

function textBox(id: number, name: string, x: number, y: number, cx: number, cy: number, bodyXml: string): string {
  return (
    `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${esc(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>` +
    `<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>` +
    `<p:txBody><a:bodyPr wrap="square" anchor="t"><a:normAutofit/></a:bodyPr><a:lstStyle/>${bodyXml}</p:txBody></p:sp>`
  )
}

function tableCell(text: string, header: boolean, headerFill = 'F4EFE6'): string {
  const border = (tag: string) => `<a:${tag} w="9525"><a:solidFill><a:srgbClr val="CCCCCC"/></a:solidFill></a:${tag}>`
  const fill = header ? `<a:solidFill><a:srgbClr val="${headerFill}"/></a:solidFill>` : ''
  return (
    `<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="1400"${header ? ' b="1"' : ''} dirty="0"/>` +
    `<a:t>${oneLine(text)}</a:t></a:r></a:p></a:txBody>` +
    `<a:tcPr marL="45720" marR="45720" marT="22860" marB="22860" anchor="ctr">${border('lnL')}${border('lnR')}${border('lnT')}${border('lnB')}${fill}</a:tcPr></a:tc>`
  )
}

function tableGraphicFrame(
  id: number,
  x: number,
  y: number,
  cx: number,
  headers: string[],
  rows: string[][],
  headerFill = 'F4EFE6',
): { xml: string; cy: number } {
  const cols = Math.max(1, headers.length)
  const colW = Math.floor(cx / cols)
  const rowH = 457200
  const grid = Array.from({ length: cols }, () => `<a:gridCol w="${colW}"/>`).join('')
  const headerRow = `<a:tr h="${rowH}">${headers.map((h) => tableCell(h, true, headerFill)).join('')}</a:tr>`
  const bodyRows = rows
    .map((row) => `<a:tr h="${rowH}">${Array.from({ length: cols }, (_, i) => tableCell(row[i] ?? '', false)).join('')}</a:tr>`)
    .join('')
  const cy = rowH * (1 + rows.length)
  const xml =
    `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${id}" name="Table"/>` +
    `<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>` +
    `<p:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></p:xfrm>` +
    `<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">` +
    `<a:tbl><a:tblPr firstRow="1" bandRow="1"/><a:tblGrid>${grid}</a:tblGrid>${headerRow}${bodyRows}</a:tbl>` +
    `</a:graphicData></a:graphic></p:graphicFrame>`
  return { xml, cy }
}

export type PptxThemeHints = {
  titleColor?: string
  bodyColor?: string
  subtitleColor?: string
  tableHeaderFill?: string
  titleSize?: number
  bodySize?: number
  headingTypeface?: string
  bodyTypeface?: string
}

function slideBody(slide: RecipeSlide, theme?: PptxThemeHints): string {
  const titleColor = theme?.titleColor
  const bodyColor = theme?.bodyColor
  const subtitleColor = theme?.subtitleColor || '5A5A5A'
  const titleSz = theme?.titleSize ?? 3200
  const bodySz = theme?.bodySize ?? 2000
  const headingFace = theme?.headingTypeface
  const bodyFace = theme?.bodyTypeface
  if (slide.primitive === 'section-divider') {
    return textBox(
      2,
      'SectionDivider',
      MARGIN_X,
      2500000,
      CONTENT_W,
      1600000,
      paragraph(slide.title || 'Section', { sz: titleSz + 400, b: true, align: 'ctr', color: titleColor, typeface: headingFace }),
    )
  }

  if (slide.primitive === 'two-column') {
    const mid = Math.ceil((slide.bullets.length || 2) / 2) || 1
    const left = (slide.bullets.length ? slide.bullets.slice(0, mid) : ['Left']).map((b) =>
      paragraph(b, { sz: bodySz, bullet: true, color: bodyColor, typeface: bodyFace }),
    ).join('')
    const right = (slide.bullets.length ? slide.bullets.slice(mid) : ['Right']).map((b) =>
      paragraph(b, { sz: bodySz, bullet: true, color: bodyColor, typeface: bodyFace }),
    ).join('')
    const colW = Math.floor((CONTENT_W - 200000) / 2)
    const heading = textBox(2, 'Title', MARGIN_X, 274638, CONTENT_W, 800000, paragraph(slide.title || 'Untitled', { sz: titleSz, b: true, color: titleColor, typeface: headingFace }))
    const leftBox = textBox(3, 'TwoColumnLeft', MARGIN_X, BODY_TOP, colW, SLIDE_H - BODY_TOP - MARGIN_X, left)
    const rightBox = textBox(4, 'TwoColumnRight', MARGIN_X + colW + 200000, BODY_TOP, colW, SLIDE_H - BODY_TOP - MARGIN_X, right)
    return heading + leftBox + rightBox
  }

  if (slide.primitive === 'metric') {
    const value = slide.table?.rows[0]?.[1] || slide.bullets[0] || slide.body || 'Outline'
    const label = slide.table?.rows[0]?.[0] || slide.title || 'Metric'
    const heading = textBox(2, 'Title', MARGIN_X, 274638, CONTENT_W, 800000, paragraph(slide.title || 'Untitled', { sz: titleSz, b: true, color: titleColor, typeface: headingFace }))
    const valueBox = textBox(3, 'MetricValue', MARGIN_X, 1800000, CONTENT_W, 1400000, paragraph(value, { sz: 4400, b: true, align: 'ctr', color: titleColor, typeface: headingFace }))
    const labelBox = textBox(4, 'MetricLabel', MARGIN_X, 3400000, CONTENT_W, 800000, paragraph(label, { sz: bodySz, align: 'ctr', color: subtitleColor, typeface: bodyFace }))
    return heading + valueBox + labelBox
  }

  if (slide.layout === 'title') {
    const coverTitleSz = theme?.titleSize ?? 4000
    const title = textBox(
      2,
      'Title',
      MARGIN_X,
      2130425,
      CONTENT_W,
      1143000,
      paragraph(slide.title || 'Untitled', { sz: coverTitleSz, b: true, align: 'ctr', color: titleColor, typeface: headingFace }),
    )
    const subtitle = textBox(
      3,
      'Subtitle',
      MARGIN_X,
      3600450,
      CONTENT_W,
      1143000,
      paragraph(slide.body || '', { sz: bodySz, align: 'ctr', color: subtitleColor, typeface: bodyFace }),
    )
    return title + subtitle
  }

  const title = textBox(
    2,
    'Title',
    MARGIN_X,
    274638,
    CONTENT_W,
    931862,
    paragraph(slide.title || 'Untitled', { sz: titleSz, b: true, align: 'l', color: titleColor, typeface: headingFace }),
  )

  if (slide.layout === 'table' && slide.table && slide.table.headers.length) {
    const { xml } = tableGraphicFrame(3, MARGIN_X, BODY_TOP, CONTENT_W, slide.table.headers, slide.table.rows, theme?.tableHeaderFill)
    return title + xml
  }

  const bullets = slide.bullets.length ? slide.bullets : [slide.body || ' ']
  const paras = bullets.map((b) => paragraph(b, { sz: bodySz, bullet: true, color: bodyColor, typeface: bodyFace })).join('')
  const body = textBox(3, 'Body', MARGIN_X, BODY_TOP, CONTENT_W, SLIDE_H - BODY_TOP - MARGIN_X, paras)
  return title + body
}

function slideXml(slide: RecipeSlide, theme?: PptxThemeHints): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">` +
    `<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>${slideBody(slide, theme)}</p:spTree></p:cSld>` +
    `<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`
  )
}

function slideRelsXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>` +
    `</Relationships>`
  )
}

function contentTypesXml(count: number): string {
  const slideOverrides = Array.from(
    { length: count },
    (_, i) => `<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`,
  ).join('')
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>` +
    `<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>` +
    `<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>` +
    `<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>` +
    slideOverrides +
    `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
    `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
    `</Types>`
  )
}

function rootRelsXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>` +
    `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
    `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
    `</Relationships>`
  )
}

function corePropsXml(title: string, when: Date): string {
  const iso = when.toISOString().replace(/\.\d+Z$/, 'Z')
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
    `<dc:title>${esc(title)}</dc:title><dc:creator>os.neu Slides</dc:creator><cp:lastModifiedBy>os.neu Slides</cp:lastModifiedBy>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${iso}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${iso}</dcterms:modified>` +
    `</cp:coreProperties>`
  )
}

function appPropsXml(count: number): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">` +
    `<Application>os.neu Slides</Application><PresentationFormat>Widescreen</PresentationFormat><Slides>${count}</Slides>` +
    `</Properties>`
  )
}

function presentationXml(count: number): string {
  const ids = Array.from({ length: count }, (_, i) => `<p:sldId id="${256 + i}" r:id="rId${2 + i}"/>`).join('')
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">` +
    `<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rIdMaster1"/></p:sldMasterIdLst>` +
    `<p:sldIdLst>${ids}</p:sldIdLst>` +
    `<p:sldSz cx="${SLIDE_W}" cy="${SLIDE_H}" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/>` +
    `</p:presentation>`
  )
}

function presentationRelsXml(count: number): string {
  const slideRels = Array.from(
    { length: count },
    (_, i) => `<Relationship Id="rId${2 + i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>`,
  ).join('')
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rIdMaster1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>` +
    slideRels +
    `</Relationships>`
  )
}

function themeXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="os.neu Theme"><a:themeElements>` +
    `<a:clrScheme name="os.neu">` +
    `<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>` +
    `<a:dk2><a:srgbClr val="1B1C18"/></a:dk2><a:lt2><a:srgbClr val="F4EFE6"/></a:lt2>` +
    `<a:accent1><a:srgbClr val="9BE7C8"/></a:accent1><a:accent2><a:srgbClr val="E0B36A"/></a:accent2>` +
    `<a:accent3><a:srgbClr val="E07A6A"/></a:accent3><a:accent4><a:srgbClr val="6A9BE0"/></a:accent4>` +
    `<a:accent5><a:srgbClr val="8A6AE0"/></a:accent5><a:accent6><a:srgbClr val="6AE0B3"/></a:accent6>` +
    `<a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink>` +
    `</a:clrScheme>` +
    `<a:fontScheme name="os.neu"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>` +
    `<a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>` +
    `<a:fmtScheme name="os.neu">` +
    `<a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>` +
    `<a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>` +
    `<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>` +
    `<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>` +
    `</a:fmtScheme></a:themeElements></a:theme>`
  )
}

function slideMasterXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">` +
    `<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>` +
    `<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>` +
    `<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>` +
    `</p:sldMaster>`
  )
}

function slideMasterRelsXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>` +
    `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>` +
    `</Relationships>`
  )
}

function slideLayoutXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1">` +
    `<p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>` +
    `<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`
  )
}

function slideLayoutRelsXml(): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>` +
    `</Relationships>`
  )
}

/** Real `.pptx` (ZIP/OOXML) bytes for the current in-memory recipe (max MAX_SLIDES). */
export function exportSlidesToPptx(recipe: SlidesRecipe, when: Date = new Date(), theme?: PptxThemeHints): Uint8Array {
  const slides = recipe.slides.length
    ? recipe.slides.slice(0, MAX_SLIDES)
    : [{ layout: 'bullets' as const, title: 'Untitled', body: '', bullets: [], table: null }]
  const count = slides.length

  const entries: ZipEntry[] = []
  const add = (name: string, xml: string) => entries.push({ name, data: new TextEncoder().encode(xml) })

  add('[Content_Types].xml', contentTypesXml(count))
  add('_rels/.rels', rootRelsXml())
  add('docProps/core.xml', corePropsXml(recipe.title || 'os.neu Slides', when))
  add('docProps/app.xml', appPropsXml(count))
  add('ppt/presentation.xml', presentationXml(count))
  add('ppt/_rels/presentation.xml.rels', presentationRelsXml(count))
  add('ppt/theme/theme1.xml', themeXml())
  add('ppt/slideMasters/slideMaster1.xml', slideMasterXml())
  add('ppt/slideMasters/_rels/slideMaster1.xml.rels', slideMasterRelsXml())
  add('ppt/slideLayouts/slideLayout1.xml', slideLayoutXml())
  add('ppt/slideLayouts/_rels/slideLayout1.xml.rels', slideLayoutRelsXml())

  slides.forEach((slide, i) => {
    add(`ppt/slides/slide${i + 1}.xml`, slideXml(slide, theme))
    add(`ppt/slides/_rels/slide${i + 1}.xml.rels`, slideRelsXml())
  })

  return buildZip(entries, when)
}

const PPTX_MIME = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'

/** Reuses `window.neuos.files.save` bytes when present (Electron); else `<a download>` blob (hosted web). */
export async function savePptxFile(bytes: Uint8Array, title: string) {
  const base = (title || 'slides').replace(/[^\w\- .]+/g, '_').slice(0, 60) || 'slides'
  const name = `${base}.pptx`
  if (window.neuos?.files?.save) {
    return window.neuos.files.save({
      defaultPath: name,
      mime: PPTX_MIME,
      bytes: Array.from(bytes),
      filters: [{ name: 'PowerPoint', extensions: ['pptx'] }],
    })
  }
  const blob = new Blob([new Uint8Array(bytes)], { type: PPTX_MIME })
  const href = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = href
  a.download = name
  a.click()
  URL.revokeObjectURL(href)
  return { ok: true, via: 'download' as const }
}
