/**
 * WO-UI-NEU-SLIDES-PPT-STUDIO-TEMPLATE-RUNTIME-122 — structure[] + slide count → RecipeSlide[].
 */
import { getOutlinePack } from './slideOutlines'
import type { PresentationTemplate } from './presentationTemplates'
import { packPolicyFor } from './presentationTemplates'
import { bodyFromBullets, clampSlideCount, type RecipeSlide } from './slidesRecipe'
import { layoutForStructureKey, recipeLayoutFor, type LayoutPrimitiveId } from './layoutContract'

export const ALLOWED_COUNTS = [6, 8, 10, 12, 15, 20] as const

export type StoryboardRow = {
  key: string
  title: string
  layout: LayoutPrimitiveId
  /** @deprecated use `layout` — kept for one-release storyboard callers */
  role: LayoutPrimitiveId
}

/** Slide counts the S3 picker may offer for this template (packPolicy ∩ allow-list). */
export function allowedSlideCounts(template: PresentationTemplate): number[] {
  const policy = packPolicyFor(template)
  return ALLOWED_COUNTS.filter((n) => n >= policy.minSlides && n <= policy.maxSlides)
}

function humanize(key: string): string {
  if (key.startsWith('detail-')) return `Section ${key.split('-')[1] || ''}`.trim()
  return key
    .split('-')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : ''))
    .join(' ')
}

export function defaultSlideCount(template: PresentationTemplate): number {
  const policy = packPolicyFor(template)
  return policy.defaultSlides
}

export function resolveSlideCount(template: PresentationTemplate, requested?: number): number {
  const policy = packPolicyFor(template)
  let count = requested ?? policy.defaultSlides
  if (!ALLOWED_COUNTS.includes(count as (typeof ALLOWED_COUNTS)[number])) {
    count = policy.defaultSlides
  }
  count = Math.max(policy.minSlides, Math.min(policy.maxSlides, count))
  return clampSlideCount(count)
}

export function expandStructureKeys(structure: string[], count: number): string[] {
  if (count <= structure.length) return structure.slice(0, count)
  const keys = [...structure]
  let n = 1
  while (keys.length < count) {
    keys.push(`detail-${n}`)
    n += 1
  }
  return keys.slice(0, count)
}

function slideForKey(key: string, template: PresentationTemplate, index: number): RecipeSlide {
  const title = humanize(key)
  const primitive = layoutForStructureKey(key, index)
  const layout = recipeLayoutFor(primitive)
  if (layout === 'title') {
    return {
      layout,
      title: index === 0 || key === 'cover' ? template.name : title,
      body: template.cardSubtitle,
      bullets: [],
      table: null,
      primitive,
    }
  }
  if (layout === 'table') {
    return {
      layout,
      title,
      body: '',
      bullets: [],
      table: {
        headers: ['Topic', 'Notes'],
        rows: [
          ['Item A', 'Outline'],
          ['Item B', 'Outline'],
        ],
      },
      primitive,
    }
  }
  return {
    layout: 'bullets',
    title,
    body: bodyFromBullets(['Key point one', 'Key point two', 'Key point three']),
    bullets: ['Key point one', 'Key point two', 'Key point three'],
    table: null,
    primitive,
  }
}

/** Merge seed content from generic pack where layouts match. */
function mergeSeed(slide: RecipeSlide, seed: RecipeSlide | undefined): RecipeSlide {
  if (!seed) return slide
  if (slide.layout === 'table' && seed.layout === 'table' && seed.table) {
    return {
      ...slide,
      primitive: slide.primitive,
      table: {
        headers: [...seed.table.headers],
        rows: seed.table.rows.map((r) => [...r]),
      },
    }
  }
  if (slide.layout === 'bullets' && seed.layout === 'bullets' && seed.bullets.length) {
    return { ...slide, bullets: [...seed.bullets], body: seed.body }
  }
  return slide
}

/** STATIC-PLANNER-FIRST — S4 rows from structure[] (no AI fill). */
export function storyboardRows(template: PresentationTemplate, requestedCount?: number): StoryboardRow[] {
  const count = resolveSlideCount(template, requestedCount)
  const keys = expandStructureKeys(template.structure, count)
  return keys.map((key, i) => {
    const layout = layoutForStructureKey(key, i)
    return {
      key,
      title: i === 0 || key === 'cover' ? template.name : humanize(key),
      layout,
      role: layout,
    }
  })
}

export function planSlidesFromTemplate(template: PresentationTemplate, requestedCount?: number): RecipeSlide[] {
  const count = resolveSlideCount(template, requestedCount)
  const keys = expandStructureKeys(template.structure, count)
  if (!keys.length) return getOutlinePack(template.pack)

  const base = getOutlinePack(template.pack)
  return keys.map((key, i) => mergeSeed(slideForKey(key, template, i), base[i] || base[base.length - 1]))
}

export function parseRequestedSlideCount(text: string, template: PresentationTemplate): number | undefined {
  const m = text.match(/\b(6|8|10|12|15|20)\s*-?\s*slide/i) || text.match(/\b(6|8|10|12|15|20)\s*장/i)
  if (m) return resolveSlideCount(template, Number(m[1]))
  return undefined
}
