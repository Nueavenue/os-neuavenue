/** Small markdown → safe HTML for the in-app manual card. No raw HTML. */

function escapeHtml(text: string) {
  return text
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
}

function inline(text: string) {
  const escaped = escapeHtml(text)
  return escaped
    .replaceAll(/`([^`]+)`/g, '<code>$1</code>')
    .replaceAll(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replaceAll(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
}

export function markdownToHtml(source: string) {
  const lines = source.replaceAll('\r\n', '\n').split('\n')
  const out: string[] = []
  let list: 'ul' | 'ol' | false = false
  let fence = false
  let inTable = false

  const closeList = () => {
    if (list) {
      out.push(list === 'ol' ? '</ol>' : '</ul>')
      list = false
    }
  }

  const closeTable = () => {
    if (inTable) {
      out.push('</table>')
      inTable = false
    }
  }

  const openList = (kind: 'ul' | 'ol') => {
    if (list !== kind) {
      closeList()
      out.push(kind === 'ol' ? '<ol>' : '<ul>')
      list = kind
    }
  }

  const splitCells = (line: string) =>
    line
      .replace(/^\|/, '')
      .replace(/\|$/, '')
      .split('|')
      .map((c) => c.trim())

  const isSep = (line: string) => /^\s*\|?(\s*:?-{3,}:?\s*\|)+\s*:?-{3,}:?\s*\|?\s*$/.test(line) || /^\s*\|?\s*:?-{3,}.*\|/.test(line)
  const isRow = (line: string) => line.includes('|') && !isSep(line) && /\|/.test(line) && splitCells(line).some((c) => c.length > 0)

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trimEnd()
    if (line.trim().startsWith('```')) {
      closeList()
      closeTable()
      if (!fence) {
        fence = true
        out.push('<pre><code>')
      } else {
        fence = false
        out.push('</code></pre>')
      }
      continue
    }
    if (fence) {
      out.push(`${escapeHtml(line)}\n`)
      continue
    }
    if (!line.trim()) {
      closeList()
      closeTable()
      continue
    }
    if (line.startsWith('### ')) {
      closeList()
      closeTable()
      out.push(`<h3>${inline(line.slice(4))}</h3>`)
      continue
    }
    if (line.startsWith('## ')) {
      closeList()
      closeTable()
      out.push(`<h2>${inline(line.slice(3))}</h2>`)
      continue
    }
    if (line.startsWith('# ')) {
      closeList()
      closeTable()
      out.push(`<h1>${inline(line.slice(2))}</h1>`)
      continue
    }
    if (line.startsWith('- ') || line.startsWith('* ')) {
      closeTable()
      openList('ul')
      out.push(`<li>${inline(line.slice(2))}</li>`)
      continue
    }
    const numbered = line.match(/^(\d+)\.\s+(.*)$/)
    if (numbered) {
      closeTable()
      openList('ol')
      out.push(`<li>${inline(numbered[2])}</li>`)
      continue
    }
    if (line.startsWith('> ')) {
      closeList()
      closeTable()
      out.push(`<blockquote>${inline(line.slice(2))}</blockquote>`)
      continue
    }
    if (isSep(line)) {
      continue
    }
    if (isRow(line)) {
      closeList()
      const cells = splitCells(line)
      const next = lines[i + 1] || ''
      const header = !inTable && isSep(next)
      if (!inTable) {
        out.push('<table>')
        inTable = true
      }
      const tag = header ? 'th' : 'td'
      out.push(`<tr>${cells.map((c) => `<${tag}>${inline(c)}</${tag}>`).join('')}</tr>`)
      continue
    }
    closeList()
    closeTable()
    out.push(`<p>${inline(line)}</p>`)
  }
  closeList()
  closeTable()
  if (fence) out.push('</code></pre>')
  return out.join('')
}

function inlineMarkdownFromHtml(html: string) {
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?(strong|b)>/gi, '**')
    .replace(/<\/?(em|i)>/gi, '_')
    .replace(/<\/?u>/gi, '')
    .replace(/<code>([\s\S]*?)<\/code>/gi, '`$1`')
    .replace(/<a[^>]*href="(https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, '[$2]($1)')
    .replace(/<[^>]+>/g, '')
    .replaceAll('&nbsp;', ' ')
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .trim()
}

/** Best-effort HTML (from our markdown renderer / contentEditable) → markdown. No DOM required. */
export function htmlToMarkdown(source: string) {
  let html = source.replace(/\r\n/g, '\n')
  html = html.replace(/<p[^>]*data-placeholder="1"[^>]*>[\s\S]*?<\/p>/gi, '')
  const lines: string[] = []
  const block =
    /<(table|h1|h2|h3|blockquote|pre|ul|ol|p)(\s[^>]*)?>([\s\S]*?)<\/\1>/gi
  let last = 0
  let m: RegExpExecArray | null
  while ((m = block.exec(html))) {
    const before = inlineMarkdownFromHtml(html.slice(last, m.index))
    if (before) lines.push(before)
    last = m.index + m[0].length
    const tag = m[1].toLowerCase()
    const inner = m[3]
    if (tag === 'h1') lines.push(`# ${inlineMarkdownFromHtml(inner)}`)
    else if (tag === 'h2') lines.push(`## ${inlineMarkdownFromHtml(inner)}`)
    else if (tag === 'h3') lines.push(`### ${inlineMarkdownFromHtml(inner)}`)
    else if (tag === 'blockquote') {
      const text = inlineMarkdownFromHtml(inner)
      if (text) lines.push(`> ${text}`)
    } else if (tag === 'pre') {
      const code = inner.replace(/<\/?code[^>]*>/gi, '')
      lines.push(`\`\`\`\n${inlineMarkdownFromHtml(code)}\n\`\`\``)
    } else if (tag === 'ul') {
      for (const item of inner.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
        lines.push(`- ${inlineMarkdownFromHtml(item[1])}`)
      }
    } else if (tag === 'ol') {
      let n = 1
      for (const item of inner.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
        lines.push(`${n}. ${inlineMarkdownFromHtml(item[1])}`)
        n += 1
      }
    } else if (tag === 'table') {
      const rows = [...inner.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
      rows.forEach((row, i) => {
        const cells = [...row[1].matchAll(/<(th|td)[^>]*>([\s\S]*?)<\/\1>/gi)].map(
          (c) => inlineMarkdownFromHtml(c[2]) || ' ',
        )
        if (!cells.length) return
        lines.push(`| ${cells.join(' | ')} |`)
        if (i === 0) lines.push(`| ${cells.map(() => '---').join(' | ')} |`)
      })
    } else if (tag === 'p') {
      const text = inlineMarkdownFromHtml(inner)
      if (text) lines.push(text)
    }
  }
  const tail = inlineMarkdownFromHtml(html.slice(last))
  if (tail) lines.push(tail)
  return lines.join('\n\n').replace(/\n{3,}/g, '\n\n').trim()
}

export const MANUAL_DOC = '/docs/manual.md'
export const MANUAL_DOC_EN = '/docs/manual.en.md'
export const DOCS_HOME = 'https://docs.neuavenue.com'
export const DOCS_MANUAL = `${DOCS_HOME}/manual.md`
export const DOCS_MANUAL_EN = `${DOCS_HOME}/manual.en.md`

export async function fetchManualMarkdown(locale: string) {
  const local = locale === 'ko' ? MANUAL_DOC : MANUAL_DOC_EN
  const remote = locale === 'ko' ? DOCS_MANUAL : DOCS_MANUAL_EN
  for (const url of [local, remote]) {
    try {
      const res = await fetch(url)
      if (res.ok) return await res.text()
    } catch {
      /* try next */
    }
  }
  return null
}
