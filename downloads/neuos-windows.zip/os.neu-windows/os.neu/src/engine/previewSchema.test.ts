import { describe, expect, it } from 'vitest'
import { defaultSlideCount, resolveSlideCount, storyboardRows } from './generationPlanner'
import { NATIVE_FIVE_IDS, nativeFiveTemplates } from './layoutContract'
import { previewKeysForCount, previewSlidesFromTemplate } from './previewSchema'
import { PRESENTATION_TEMPLATES } from './presentationTemplates'

describe('122B schema Preview parity', () => {
  it('preview slide list length and layout ids match the contract for default N', () => {
    for (const t of nativeFiveTemplates(PRESENTATION_TEMPLATES)) {
      const n = defaultSlideCount(t)
      const preview = previewSlidesFromTemplate(t, n)
      const planned = storyboardRows(t, n)
      expect(preview).toHaveLength(n)
      expect(preview.map((s) => s.key)).toEqual(previewKeysForCount(t, n))
      expect(preview.map((s) => s.layout)).toEqual(planned.map((s) => s.layout))
      expect(NATIVE_FIVE_IDS).toContain(t.id)
    }
  })

  it('124B gallery thumb uses the first schema preview slide', () => {
    const t = nativeFiveTemplates(PRESENTATION_TEMPLATES).find((row) => row.id === 'neu-investor-dark')!
    const first = previewSlidesFromTemplate(t)[0]
    expect(first?.key).toBe('cover')
    expect(first?.layout).toBe('title')
  })

  it('Investor at count 8: keys and layouts follow packPolicy clamp + structure', () => {
    const t = nativeFiveTemplates(PRESENTATION_TEMPLATES).find((row) => row.id === 'neu-investor-dark')!
    expect(resolveSlideCount(t, 8)).toBe(8)
    const preview = previewSlidesFromTemplate(t, 8)
    expect(preview).toHaveLength(8)
    expect(preview[0].layout).toBe('title')
    expect(preview.map((s) => s.key)).toEqual(t.structure.slice(0, 8))
  })
})
